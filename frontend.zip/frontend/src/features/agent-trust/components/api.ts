import axios, { type AxiosError } from "axios";
import { ENV } from "@/config";

const api = axios.create({
  baseURL: ENV.API_BASE_URL,
  timeout: 30_000,
  headers: { "Content-Type": "application/json" },
  withCredentials: true,
});

// ─── Error extraction ──────────────────────────────────────────────────────────

export interface ApiErrorBody {
  detail?: string;
  default?: string;
  message?: string;
  [key: string]: unknown;
}

export function extractApiError(
  err: unknown,
  fallback = "An unexpected error occurred.",
): string {
  if (!axios.isAxiosError(err)) return fallback;
  const axErr = err as AxiosError<ApiErrorBody>;
  const data = axErr.response?.data;
  if (data && typeof data === "object") {
    const msg = data["default"] ?? data.detail ?? data.message;
    if (typeof msg === "string" && msg.trim()) return msg.trim();
    if (Array.isArray(data.detail)) {
      const first = data.detail[0];
      if (first && typeof first === "object" && "msg" in first)
        return String((first as Record<string, unknown>).msg);
    }
  }
  if (axErr.message) return axErr.message;
  return fallback;
}

// ─── Shared types ──────────────────────────────────────────────────────────────

export type TrustState =
  | "UNREVIEWED"
  | "TRUSTED"
  | "NEEDS_REVIEW"
  | "HIGH_RISK";

export type CheckStatus =
  | "pass"
  | "partial"
  | "fail"
  | "not_configured"
  | "not_verified";

// ─── Dashboard ─────────────────────────────────────────────────────────────────
// GET /agent-trust/dashboard

export interface DashboardByTrustState {
  UNREVIEWED: number;
  TRUSTED: number;
  REVIEW_REQUIRED: number;
  HIGH_RISK: number;
}

export interface NeedsAttentionAgent {
  agent_id: string;
  name: string;
  trust_score: number | null;
  trust_state: TrustState;
  reason: string;
}

export interface TrendPoint {
  date: string;
  average_trust_score: number;
  reviews: number;
}

export interface DashboardResponse {
  total_agents: number;
  average_trust_score: number | null;
  by_trust_state: DashboardByTrustState;
  needs_attention: NeedsAttentionAgent[];
  needs_attention_total: number;
  trend: TrendPoint[];
}

export const fetchDashboard = async (
  scope: "mine" | "all" = "mine",
): Promise<DashboardResponse> => {
  const res = await api.get<DashboardResponse>("/agent-trust/dashboard", {
    params: { scope },
  });
  return res.data;
};

// ─── Agent list ────────────────────────────────────────────────────────────────
// GET /agent-trust/agents

export interface AgentOwner {
  user_id: string;
  name: string;
  email: string;
}

export interface AgentListItem {
  agent_id: string;
  name: string;
  owner: AgentOwner;
  environment: string | null;
  trust_score: number;
  trust_state: TrustState;
  last_reviewed_at: string | null;
  stale: boolean;
  total_runs: number;
  total_tokens: number;
  total_cost_usd: number;
  last_used_at: string | null;
  updated_at: string;
}

export interface AgentListResponse {
  total: number;
  limit: number;
  offset: number;
  items: AgentListItem[];
}

export const fetchAgents = async (params?: {
  scope?: "mine" | "all";
  search?: string;
  trust_state?: string;
  limit?: number;
  offset?: number;
}): Promise<AgentListResponse> => {
  const res = await api.get<AgentListResponse>("/agent-trust/agents", {
    params,
  });
  return res.data;
};

// ─── Agent overview ────────────────────────────────────────────────────────────
// GET /agent-trust/agents/{agent_id}

export interface TrustCheck {
  key: string;
  label: string;
  status: CheckStatus;
  points_earned: number;
  points_possible: number;
  points_available: number;
  summary: string;
  fix: string;
  detail: Record<string, unknown>;
}

export interface Improvement {
  key: string;
  label: string;
  points: number;
  status: CheckStatus;
  reason: string;
  action: string;
}

export interface AgentUsageSummary {
  window: string;
  total_runs: number;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  total_cost_usd: number;
  cost_is_estimated: boolean;
  last_used_at: string | null;
}

export interface UsedInData {
  workflows: { id: string; name: string }[];
  apps: { id: string; name: string }[];
}

export interface AgentOverview {
  agent_id: string;
  name: string;
  description: string | null;
  owner: AgentOwner;
  environment: string | null;
  tags: string[];
  trust_score: number | null;
  trust_state: TrustState;
  last_reviewed_at: string | null;
  stale: boolean;
  created_at: string;
  updated_at: string;
  checks: TrustCheck[];
  improvements: Improvement[];
  open_alerts: number;
  usage: AgentUsageSummary;
  used_in: UsedInData;
}

export const fetchAgentOverview = async (
  agentId: string,
): Promise<AgentOverview> => {
  const res = await api.get<AgentOverview>(`/agent-trust/agents/${agentId}`);
  return res.data;
};

// ─── Agent review workspace ────────────────────────────────────────────────────
// GET /agent-trust/agents/{agent_id}/review

export interface SecurityProbe {
  attack_type?: string;
  attack_name?: string;
  blocked: boolean;
  verdict?: string;
  rationale?: string;
  [key: string]: unknown;
}

export interface SecuritySummary {
  total_probes: number;
  blocked: number;
  last_scan_at: string | null;
  probes: SecurityProbe[];
}

export interface CredentialEntry {
  name: string;
  status?: string;
  safe_for_review?: boolean;
  [key: string]: unknown;
}

export interface CredentialDrift {
  name: string;
  detail?: string;
  [key: string]: unknown;
}

export interface CredentialsSummary {
  evaluated_at: string | null;
  declared: CredentialEntry[];
  drift: CredentialDrift[];
}

export interface TestSuiteResult {
  suite_id: string;
  name: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  last_run_at: string | null;
  test_cases: TestCaseResult[];
}

export interface TestCaseResult {
  name: string;
  input: string;
  expected: string;
  assertion_type: "semantic_judge" | "keyword_match";
  keywords: string[];
  rationale: string;
  status?: "passed" | "failed" | "pending";
}

export interface AssignedPolicy {
  policy_id: string;
  name: string;
  description: string;
  category: string;
}

export interface AgentReviewData {
  agent_id: string;
  name: string;
  trust_score: number | null;
  trust_state: TrustState;
  last_reviewed_at: string | null;
  stale: boolean;
  checks: TrustCheck[];
  improvements: Improvement[];
  policies: AssignedPolicy[];
  test_suites: TestSuiteResult[];
  security: SecuritySummary;
  credentials: CredentialsSummary;
}

export const fetchAgentReview = async (
  agentId: string,
): Promise<AgentReviewData> => {
  const res = await api.get<AgentReviewData>(
    `/agent-trust/agents/${agentId}/review`,
  );
  return res.data;
};

// ─── Run review ────────────────────────────────────────────────────────────────
// POST /agent-trust/review

export interface ReviewResult {
  agent_id: string;
  name: string;
  status: "reviewed" | "failed" | string;
  trust_score: number;
  trust_state: TrustState;
  previous_score: number;
  error?: string;
}

export interface RunReviewResponse {
  reviewed: number;
  failed: number;
  correlation_id: string;
  results: ReviewResult[];
}

export const runReview = async (
  agentIds: string[],
): Promise<RunReviewResponse> => {
  const res = await api.post<RunReviewResponse>("/agent-trust/review", {
    agent_ids: agentIds,
  });
  return res.data;
};

// ─── Timeline ──────────────────────────────────────────────────────────────────
// GET /agent-trust/agents/{agent_id}/timeline

export interface TimelineEvent {
  seq: number;
  event: string;
  category: string;
  title: string;
  at: string;
  actor: string | null;
  outcome: string | null;
  severity: string | null;
  details: Record<string, unknown>;
  hash: string;
  parent_hash: string | null;
}

export interface TimelineResponse {
  entries: TimelineEvent[];
  next_cursor: number | null;
  has_more: boolean;
}

export const fetchTimeline = async (
  agentId: string,
  params?: {
    category?: string[];
    cursor?: number;
    limit?: number;
  },
): Promise<TimelineResponse> => {
  const res = await api.get<TimelineResponse>(
    `/agent-trust/agents/${agentId}/timeline`,
    { params },
  );
  // Normalise: backend may return array or object
  if (Array.isArray(res.data)) {
    return {
      entries: res.data as TimelineEvent[],
      next_cursor: null,
      has_more: false,
    };
  }
  // Support both `entries` and legacy `items` key
  const data = res.data as unknown as Record<string, unknown>;
  if (!data.entries && data.items) {
    return {
      entries: data.items as TimelineEvent[],
      next_cursor: (data.next_cursor as number | null) ?? null,
      has_more: false,
    };
  }
  return res.data;
};

// ─── Usage ─────────────────────────────────────────────────────────────────────
// GET /agent-trust/agents/{agent_id}/usage

export type UsageWindow = "24h" | "7d" | "30d" | "all";

export interface AgentUsage {
  window: UsageWindow;
  total_runs: number;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  total_cost_usd: number;
  cost_is_estimated: boolean;
  last_used_at: string | null;
}

export const fetchUsage = async (
  agentId: string,
  window: UsageWindow = "all",
): Promise<AgentUsage> => {
  const res = await api.get<AgentUsage>(
    `/agent-trust/agents/${agentId}/usage`,
    { params: { window } },
  );
  return res.data;
};

// ─── Functional suites ─────────────────────────────────────────────────────────
// POST /agent-trust/agents/{agent_id}/functional-suites

export interface TestCaseInput {
  name: string;
  input: string;
  expected: string;
  assertion_type: "semantic_judge" | "keyword_match";
  keywords: string[];
  rationale: string;
}

export interface CreateSuitePayload {
  name: string;
  description?: string;
  source: "user" | "ai";
  test_cases: TestCaseInput[];
}

export const createFunctionalSuite = async (
  agentId: string,
  payload: CreateSuitePayload,
): Promise<TestSuiteResult> => {
  const res = await api.post<TestSuiteResult>(
    `/agent-trust/agents/${agentId}/functional-suites`,
    payload,
  );
  return res.data;
};

export const deleteFunctionalSuite = async (
  agentId: string,
  suiteId: string,
): Promise<void> => {
  await api.delete(
    `/agent-trust/agents/${agentId}/functional-suites/${suiteId}`,
  );
};

// ─── AI test recommendation ────────────────────────────────────────────────────
// POST /agent-trust/agents/{agent_id}/functional-suites/recommend

export interface RecommendGroundedOn {
  agent_name: string[];
  description: string[];
  connector_names: string[];
  tool_names: string[];
  workflow_names: string[];
}

export interface AiTestRecommendation {
  agent_id: string;
  suggested_name: string;
  grounded_on: RecommendGroundedOn;
  test_cases: TestCaseInput[];
}

export const recommendFunctionalSuite = async (
  agentId: string,
): Promise<AiTestRecommendation> => {
  const res = await api.post<AiTestRecommendation>(
    `/agent-trust/agents/${agentId}/functional-suites/recommend`,
  );
  return res.data;
};

// ─── Policies ──────────────────────────────────────────────────────────────────
// GET /agent-trust/policies

export interface PolicyRule {
  rule_id: string;
  description: string;
}

export interface Policy {
  id: string;
  name: string;
  description: string;
  category: string;
  framework: string;
  severity: string;
  enforcement_mode: string;
  rules: PolicyRule[];
  is_active: boolean;
  is_seeded: boolean;
  version: number;
  created_at: string;
  updated_at: string;
}

export const fetchPolicies = async (): Promise<Policy[]> => {
  const res = await api.get<Policy[]>("/agent-trust/policies");
  return res.data ?? [];
};

export const createPolicy = async (
  payload: Partial<Omit<Policy, "id" | "created_at" | "updated_at">>,
): Promise<Policy> => {
  const res = await api.post<Policy>("/agent-trust/policies", payload);
  return res.data;
};

export const updatePolicy = async (
  policyId: string,
  payload: Partial<Policy>,
): Promise<Policy> => {
  const res = await api.patch<Policy>(
    `/agent-trust/policies/${policyId}`,
    payload,
  );
  return res.data;
};

export const deletePolicy = async (policyId: string): Promise<void> => {
  await api.delete(`/agent-trust/policies/${policyId}`);
};

export const fetchAgentPolicies = async (
  agentId: string,
): Promise<Policy[]> => {
  const res = await api.get<Policy[]>(
    `/agent-trust/policies/agents/${agentId}/policies`,
  );
  return res.data ?? [];
};

export const assignPolicyToAgent = async (
  agentId: string,
  policyId: string,
): Promise<void> => {
  await api.post(
    `/agent-trust/policies/agents/${agentId}/policies/${policyId}`,
  );
};

export const removePolicyFromAgent = async (
  agentId: string,
  policyId: string,
): Promise<void> => {
  await api.delete(
    `/agent-trust/policies/agents/${agentId}/policies/${policyId}`,
  );
};

export interface PolicyRecommendation {
  policy_id: string;
  name: string;
  description: string;
  why: string;
}

export interface PolicyRecommendResponse {
  agent_id: string;
  recommendations: PolicyRecommendation[];
}

export const recommendPolicies = async (
  agentId: string,
): Promise<PolicyRecommendResponse> => {
  const res = await api.post<PolicyRecommendResponse>(
    `/agent-trust/policies/agents/${agentId}/policies/recommend`,
  );
  return res.data;
};

export interface PolicyViolation {
  policy_id: string;
  policy_name: string;
  agent_id: string;
  rule_id: string;
  severity: string;
  reason: string;
  occurred_at: string;
}

export const fetchPolicyViolations = async (): Promise<PolicyViolation[]> => {
  const res = await api.get<PolicyViolation[]>(
    "/agent-trust/policies/violations",
  );
  return res.data ?? [];
};
