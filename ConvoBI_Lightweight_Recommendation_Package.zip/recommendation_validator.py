"""Low-token ConvoBI recommendation generation and execution validation.

This module makes one LLM call to generate a batch of question/SQL pairs, then
uses ConvoBI's existing schema metadata and SQL schema validator to verify
candidates. It never invokes the full LangGraph workflow.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage
from langchain_community.utilities.sql_database import SQLDatabase
from sqlalchemy import text

from .main import _get_convobi_llm_async, get_schema_info, validate_sql_against_schema

LOG = logging.getLogger(__name__)
MAX_RECOMMENDATION_COUNT = 8
# One generation call; generate enough candidates to shortlist without asking
# the LLM to regenerate after individual candidates fail validation.
CANDIDATE_BATCH_SIZE = 10
FETCH_ROWS = 1


def _normalize_question(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", (value or "").lower())).strip()


def _schema_context(tables: Dict[str, Any]) -> str:
    """Serialize schema/metadata, not full table contents, for focused generation."""
    blocks: List[str] = []
    for table_name, info in sorted(tables.items(), key=lambda item: item[0].lower()):
        lines = [f"TABLE: {table_name}", f"ROW COUNT: {info.get('row_count', 'unknown')}", "COLUMNS:"]
        for col in info.get("columns", []):
            name = col.get("name")
            if not name:
                continue
            parts = [f"{name} ({col.get('type', 'unknown')})"]
            if col.get("primary_key"):
                parts.append("primary key")
            if col.get("foreign_key"):
                parts.append(f"foreign key -> {col['foreign_key']}")
            meaning = col.get("meaning") or col.get("description")
            if meaning:
                parts.append(f"meaning: {meaning}")
            examples = col.get("examples") or col.get("example_values") or []
            if examples:
                parts.append("examples: " + ", ".join(str(x)[:60] for x in examples[:3]))
            lines.append("- " + " | ".join(parts))
        relationships = info.get("relationships") or []
        if relationships:
            lines.append("RELATIONSHIPS:")
            lines.extend(f"- {relation}" for relation in relationships)
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


def _parse_candidates(content: Any, requested: int) -> List[Dict[str, str]]:
    if isinstance(content, list):
        content = "".join(str(part.get("text", "")) if isinstance(part, dict) else str(part) for part in content)
    raw = str(content or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE).strip()
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            raise ValueError("LLM returned no JSON candidate object")
        payload = json.loads(match.group(0))
    items = payload.get("candidates", []) if isinstance(payload, dict) else []
    output: List[Dict[str, str]] = []
    seen: set[str] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        question, sql = str(item.get("question") or "").strip(), str(item.get("sql") or "").strip()
        key = _normalize_question(question)
        if not key or key in seen or not sql:
            continue
        seen.add(key)
        output.append({"question": question, "sql": sql})
        if len(output) >= CANDIDATE_BATCH_SIZE:
            break
    return output


def _is_read_only_single_select(sql: str) -> bool:
    statement = (sql or "").strip()
    if not statement or "\x00" in statement:
        return False
    if statement.endswith(";"):
        statement = statement[:-1].rstrip()
    if ";" in statement or not re.match(r"^(SELECT|WITH)\b", statement, re.IGNORECASE):
        return False
    # Conservative keyword guard; the database connection should also use a
    # read-only role wherever supported.
    if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|MERGE|GRANT|REVOKE|CALL|EXEC(?:UTE)?)\b", statement, re.IGNORECASE):
        return False
    return True


def _has_rows(db: SQLDatabase, sql: str) -> bool:
    engine = getattr(db, "_engine", None)
    if engine is None:
        raise RuntimeError("SQLDatabase has no SQLAlchemy engine")
    # Do not rewrite SQL with LIMIT because SQL dialects differ. Fetch one row
    # from the result cursor; the query itself remains the generated query.
    with engine.connect() as connection:
        result = connection.execute(text(sql.strip().rstrip(";")))
        try:
            return result.fetchone() is not None
        finally:
            result.close()


async def _generate_candidates(user_id: Optional[str], schema: str) -> List[Dict[str, str]]:
    llm = await _get_convobi_llm_async(user_id)
    prompt = f"""You are ConvoBI's database recommendation planner.
Generate exactly {CANDIDATE_BATCH_SIZE} distinct, practical questions a user can ask about this database.
The purpose is to recommend questions that are likely to return actual records, not questions that require summaries or visualizations.
For EACH question provide the single read-only SQL SELECT query that answers that exact question.
Use only tables and columns below. Follow listed relationships. Prefer simple, reliable queries over complex analytics; avoid assumptions not supported by the schema. Avoid queries that commonly return no rows. Use dialect-appropriate SQL for the connected database where possible.
Return only JSON: {{"candidates":[{{"question":"...","sql":"SELECT ..."}}]}}
Do not use markdown, comments, multiple statements, or write operations.
DATABASE SCHEMA AND AVAILABLE METADATA:
{schema}
"""
    response = await asyncio.to_thread(llm.invoke, [HumanMessage(content=prompt)])
    return _parse_candidates(getattr(response, "content", ""), CANDIDATE_BATCH_SIZE)


async def generate_recommended_questions(
    *, user_id: Optional[str], db: SQLDatabase, question_count: int = 5,
    force_refresh: bool = False,
) -> Dict[str, Any]:
    """Generate one batch, validate sequentially, and stop at requested count.

    force_refresh is accepted for route compatibility. This implementation does
    not cache recommendations: each call validates against the current database.
    """
    del force_refresh
    requested = max(1, min(MAX_RECOMMENDATION_COUNT, int(question_count or 5)))
    generated_at = datetime.utcnow().isoformat()
    try:
        # ConvoBI's own schema discovery/metadata is the source of truth.
        tables = get_schema_info(db)
        schema = _schema_context(tables)
        if not schema.strip():
            return {"success": False, "questions": [], "generated_at": generated_at, "source": "no_schema"}
        # Exactly one LLM generation call per request; no repeated regeneration.
        candidates = await _generate_candidates(user_id, schema)
    except Exception:
        LOG.exception("[RECOMMEND] candidate generation failed")
        return {"success": False, "questions": [], "generated_at": generated_at, "source": "generation_failed"}

    selected: List[Dict[str, Any]] = []
    seen_sql: set[str] = set()
    for candidate in candidates:
        if len(selected) >= requested:
            break
        question, sql = candidate["question"], candidate["sql"].strip()
        fingerprint = re.sub(r"\s+", " ", sql).lower().rstrip(";")
        if fingerprint in seen_sql:
            continue
        seen_sql.add(fingerprint)
        if not _is_read_only_single_select(sql):
            continue
        try:
            valid, _reason = validate_sql_against_schema(sql, tables)
            if not valid:
                continue
            has_rows = await asyncio.to_thread(_has_rows, db, sql)
            if not has_rows:
                continue
        except Exception as exc:
            LOG.debug("[RECOMMEND] candidate rejected (%s)", type(exc).__name__)
            continue
        selected.append({"question": question, "sql": sql, "execution_success": True, "has_rows": True})

    LOG.info("[RECOMMEND] validated candidates=%s returned=%s requested=%s", len(candidates), len(selected), requested)
    return {
        "success": bool(selected),
        "questions": [item["question"] for item in selected],
        "generated_at": generated_at,
        "source": "lightweight_sql_validated",
        # Internal metadata is available to the route but need not be exposed.
        "validated_recommendations": selected,
    }
