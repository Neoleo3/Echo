"""Agent Trust write actions: one review pipeline and functional-suite management."""
from __future__ import annotations

import asyncio
from uuid import UUID, uuid4
from fastapi import APIRouter, Depends, HTTPException

from echolib.database import get_db_session
from echolib.security import require_admin_or_above, resolve_user_id
from echolib.service.agent_trust.audit_service import EVENT_SUITE_ADDED, EVENT_SUITE_REMOVED
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import normalize_agent_id
from apps.agent_trust.schemas import (
    ReviewRequest,
    ReviewResponse,
    RecommendedSuiteResponse,
    TestSuiteCreateRequest,
    TestSuiteResponse,
    RecommendFunctionalSuiteRequest,
)

router = APIRouter(tags=["Agent Trust"])

# Keep detached review tasks strongly referenced until completion. This is
# intentionally separate from FastAPI BackgroundTasks: the HTTP response must
# return the correlation_id immediately and the review must continue after the
# request handler has returned.
_REVIEW_TASKS: set[asyncio.Task] = set()


def _retain_review_task(task: asyncio.Task) -> None:
    _REVIEW_TASKS.add(task)
    task.add_done_callback(_REVIEW_TASKS.discard)


async def _run_review_background(
    *,
    agent_ids: list[str],
    user_id: str,
    actor: str,
    correlation_id: str,
) -> None:
    """Run a review outside the client HTTP request.

    A fresh DB session is mandatory: the request session is closed as soon as
    the 202 response is returned.
    """
    logger = __import__("logging").getLogger(__name__)
    try:
        async with get_db_session() as db:
            review_service = container.resolve("agent_trust.review")
            logger.info(
                "agent_trust_review_background_started",
                extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
            )
            await review_service.review_agents(
                db,
                agent_ids=agent_ids,
                user_id=user_id,
                actor=actor,
                correlation_id=correlation_id,
            )
            await db.commit()
            logger.info(
                "agent_trust_review_background_completed",
                extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
            )
    except Exception:
        logger.exception(
            "agent_trust_review_background_failed",
            extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
        )


@router.post("/review", response_model=ReviewResponse, status_code=202, summary="Start review for one or many agents")
async def review(
    payload: ReviewRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> ReviewResponse:
    async with get_db_session() as db:
        registry = container.resolve("agent_trust.registry")
        agent_ids = [normalize_agent_id(value) for value in payload.agent_ids]

        for agent_id in agent_ids:
            await registry.validate_owner(db, agent_id, user)

    correlation_id = uuid4().hex
    user_id = resolve_user_id(user)
    actor = user.email or user_id

    task = asyncio.create_task(
        _run_review_background(
            agent_ids=agent_ids,
            user_id=user_id,
            actor=actor,
            correlation_id=correlation_id,
        )
    )
    _retain_review_task(task)

    import logging
    logging.getLogger(__name__).info(
        "agent_trust_review_accepted",
        extra={
            "correlation_id": correlation_id,
            "agent_count": len(agent_ids),
            "agent_ids": agent_ids,
        },
    )

    return ReviewResponse(
        reviewed=0,
        failed=0,
        correlation_id=correlation_id,
        results=[],
        status="started",
    )


@router.post(
    "/agents/{agent_id}/functional-suites/recommend",
    response_model=RecommendedSuiteResponse,
    summary="Generate a grounded functional-test recommendation",
)
async def recommend_functional_suite(
    agent_id: str,
    payload: RecommendFunctionalSuiteRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> RecommendedSuiteResponse:
    async with get_db_session() as db:

        hexaid = normalize_agent_id(agent_id)

        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")

        await registry.validate_owner(db, hexaid, user)

        try:
            result = await testing.generate_recommended_suite(
                db,
                agent_id=hexaid,
                user_id=resolve_user_id(user),
                question_count=payload.question_count,
            )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        return RecommendedSuiteResponse(**result)


@router.post(
    "/agents/{agent_id}/functional-suites/recommend/{recommendation_id}/accept",
    response_model=TestSuiteResponse,
    summary="Accept a functional-test recommendation",
)
async def accept_functional_suite_recommendation(
    agent_id: str,
    recommendation_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
) -> TestSuiteResponse:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")

        await registry.validate_owner(db, hexaid, user)

        try:
            suite = await testing.accept_recommended_suite(
                db,
                agent_id=hexaid,
                recommendation_id=recommendation_id,
            )
            await audit.record(
                db,
                agent_id=hexaid,
                event_type=EVENT_SUITE_ADDED,
                action="suite_added",
                actor=user.email or resolve_user_id(user),
                details={
                    "suite_id": str(suite.id),
                    "suite_name": suite.name,
                    "source": "ai",
                    "recommendation_id": str(recommendation_id),
                },
            )
            await db.commit()
        except ValueError as exc:
            await db.rollback()
            raise HTTPException(status_code=404, detail=str(exc))

        return TestSuiteResponse(
            suite_id=str(suite.id),
            agent_id=hexaid,
            name=suite.name,
            description=suite.description,
            test_count=len(suite.test_cases or []),
            source="ai",
        )


@router.post(
    "/agents/{agent_id}/functional-suites",
    response_model=TestSuiteResponse,
    summary="Add a functional test suite",
)
async def create_functional_suite(
    agent_id: str,
    payload: TestSuiteCreateRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> TestSuiteResponse:
    async with get_db_session() as db:

        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")
        await registry.validate_owner(db, hexaid, user)

        try:
            suite = await testing.create_agent_suite(
                db,
                agent_id=hexaid,
                name=payload.name,
                description=payload.description,
                test_cases=[case.model_dump() for case in payload.test_cases],
                source=payload.source,
            )
            await audit.record(
                db,
                agent_id=hexaid,
                event_type=EVENT_SUITE_ADDED,
                action="suite_added",
                actor=user.email or resolve_user_id(user),
                details={"suite_id": str(suite.id), "suite_name": suite.name},
            )
            await db.commit()
        except ValueError as exc:
            await db.rollback()
            raise HTTPException(status_code=400, detail=str(exc))

        return TestSuiteResponse(
            suite_id=str(suite.id),
            agent_id=hexaid,
            name=suite.name,
            description=suite.description,
            test_count=len(suite.test_cases or []),
            source="ai" if suite.is_seeded else "user",
        )


@router.delete(
    "/agents/{agent_id}/functional-suites/{suite_id}",
    summary="Remove a functional test suite",
)
async def delete_functional_suite(
    agent_id: str,
    suite_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
):
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")
        await registry.validate_owner(db, hexaid, user)

        suite = await testing.delete_agent_suite(db, agent_id=hexaid, suite_id=suite_id)
        if suite is None:
            raise HTTPException(status_code=404, detail="Functional test suite not found")

        await audit.record(
            db,
            agent_id=hexaid,
            event_type=EVENT_SUITE_REMOVED,
            action="suite_removed",
            actor=user.email or resolve_user_id(user),
            details={"suite_id": str(suite.id), "suite_name": suite.name},
        )
        await db.commit()
        return {"status": "deleted", "suite_id": str(suite_id)}
