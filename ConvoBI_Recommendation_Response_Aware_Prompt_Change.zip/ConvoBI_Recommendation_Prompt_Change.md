# ConvoBI recommendation prompt change

## Files in this package

- `main.py` — full `convobi/main.py` from the supplied `convobi.zip`, with only the prompt inside `_generate_recommendation_candidates()` changed.
- `ConvoBI_Recommendation_Prompt_Change.md` — this guide.

## What changed in `main.py`

Only the LLM instruction text inside `_generate_recommendation_candidates()` was changed. The new prompt tells the model what the actual ConvoBI response contract looks like (`success`, `response`, `sql`, `data`, `row_count`, `columns`, `summary`, `visualization`, `visualization_html`, and the additional `/query` fields), and describes the existing chart-building behavior:

- category + numeric result columns can yield bar/pie charts;
- date-like + numeric result columns can yield line charts;
- single numeric aggregates are suitable for simple KPI-like answers, though the current chart builder may not create a chart for a single scalar result;
- the question generator should prefer simple, one-table counts and grouped aggregates, and avoid complex joins and compound questions by default;
- schema names must come from the supplied schema, never assumed examples;
- the LLM generates natural-language questions only, not SQL.

No executable code, endpoint model, SQL logic, visualization implementation, imports, or other `main.py` behavior was changed.

## What to change in `routes.py`

**Nothing is required for this prompt-only change.** The existing recommendation route already calls `generate_recommended_questions()` and returns its question strings in the existing recommendation response. The selected question will still be handled by the existing `/query` or `/invoke` endpoint when the user submits it.

## Important scope note

This patch changes candidate quality, not the recommendation validation mechanism. In the supplied source, `generate_recommended_questions()` still validates each candidate by calling `invoke_convobi_agent()`, which runs the full workflow. Therefore this prompt-only patch does **not** by itself deliver the previously discussed token savings from bypassing the full agent during validation. That requires a separate, tested extraction/reuse of ConvoBI's SQL generation and execution stage; this patch intentionally avoids changing production query behavior.

## Validation performed

- `python -m py_compile main.py` passed.
- No database-backed or endpoint integration test was run.
