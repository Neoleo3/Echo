"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  fetchDashboard,
  fetchAgents,
  fetchAgentOverview,
  fetchAgentReview,
  runReview,
  fetchReviewRunStatus,
  fetchTimeline,
  fetchUsage,
  createFunctionalSuite,
  deleteFunctionalSuite,
  recommendFunctionalSuite,
  fetchPolicies,
  assignPolicyToAgent,
  removePolicyFromAgent,
  recommendPolicies,
  extractApiError,
  type DashboardResponse,
  type AgentListItem,
  type AgentOverview,
  type AgentReviewData,
  type RunReviewResponse,
  type ReviewRunStatus,
  type TimelineEvent,
  type AgentUsage,
  type UsageWindow,
  type TestSuiteResult,
  type TestCaseInput,
  type AiTestRecommendation,
  type Policy,
  type PolicyRecommendation,
  type TrustState,
  type CheckStatus,
  type AssignedPolicy,
  type SecurityProbe,
  type TrustCheck,
  type Improvement,
} from "./api";
import "./agent-trust.css";
import "./agent-trust-demo.css";
import {
  Activity as DemoActivity, AlertCircle, AlertTriangle, ArrowDownRight, ArrowLeft, ArrowRight,
  ArrowUpRight, Bot as DemoBot, Check, CheckCheck, CheckCircle2, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Coins, Command, Database, ExternalLink, Eye, Fingerprint,
  GitBranch, ListChecks, MoreHorizontal, PanelLeftClose,
  PanelLeftOpen, Play, RefreshCw, Search, ShieldAlert, ShieldCheck, Sparkles, Wrench,
  X, Zap, CircleDollarSign,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { AUTH_ROLES } from "@/config";

// ─── Top-level navigation ──────────────────────────────────────────────────────

type TopTab = "dashboard" | "agents" | "agent-detail";

// ─── Agent detail sub-tabs ─────────────────────────────────────────────────────

type DetailTab = "overview" | "review" | "timeline" | "usage";

const DETAIL_TABS: { id: DetailTab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "review", label: "Review" },
  { id: "timeline", label: "Timeline" },
  { id: "usage", label: "Usage" },
];

// ─── Helpers ───────────────────────────────────────────────────────────────────

function trustStateBadgeClass(state: TrustState | string): string {
  const s = (state ?? "").toUpperCase();
  if (s === "TRUSTED") return "at-badge at-badge--trusted";
  if (s === "NEEDS_REVIEW") return "at-badge at-badge--warn";
  if (s === "HIGH_RISK") return "at-badge at-badge--risk";
  if (s === "UNREVIEWED") return "at-badge at-badge--unknown";
  return "at-badge at-badge--unknown";
}

function trustStateLabel(state: TrustState | string): string {
  return (state ?? "").replace(/_/g, " ");
}

function scoreColor(score: number): string {
  if (score >= 80) return "var(--good)";
  if (score >= 60) return "#d97706";
  return "var(--bad)";
}

function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtNum(n: number | null | undefined): string {
  if (n == null) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
}

function fmtCost(n: number | null | undefined): string {
  if (n == null) return "—";
  return `$${n.toFixed(2)}`;
}

// ─── Check status helpers ──────────────────────────────────────────────────────

function checkIcon(status: CheckStatus): React.ReactNode {
  switch (status) {
    case "pass":
      return (
        <span className="at-check-icon at-check-icon--pass" aria-label="Pass">
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </span>
      );
    case "partial":
      return (
        <span
          className="at-check-icon at-check-icon--partial"
          aria-label="Partial"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </span>
      );
    case "fail":
      return (
        <span className="at-check-icon at-check-icon--fail" aria-label="Fail">
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </span>
      );
    case "not_configured":
      return (
        <span
          className="at-check-icon at-check-icon--nc"
          aria-label="Not configured"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
        </span>
      );
    case "not_verified":
      return (
        <span
          className="at-check-icon at-check-icon--nv"
          aria-label="Not verified"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
        </span>
      );
  }
}

function checkStatusLabel(status: CheckStatus): string {
  switch (status) {
    case "pass":
      return "Passed";
    case "partial":
      return "Partial";
    case "fail":
      return "Failed";
    case "not_configured":
      return "Not configured";
    case "not_verified":
      return "Not verified";
  }
}

// ─── Shared UI primitives ──────────────────────────────────────────────────────

function Loader() {
  return (
    <div className="at-loader">
      <span className="at-spinner" />
    </div>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="at-error" role="alert">
      <svg
        width="15"
        height="15"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        style={{ flexShrink: 0 }}
      >
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="12" />
        <line x1="12" y1="16" x2="12.01" y2="16" />
      </svg>
      {message}
    </div>
  );
}

function InfoTooltip({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return (
    <span className="at-tooltip-wrap" ref={ref}>
      <button
        type="button"
        className="at-tooltip-btn"
        aria-label="More information"
        onClick={() => setOpen((v) => !v)}
      >
        <svg
          width="12"
          height="12"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </button>
      {open && (
        <div className="at-tooltip-pop" role="tooltip">
          {text}
        </div>
      )}
    </span>
  );
}

function StatCard({
  label,
  value,
  sub,
  accent,
  icon,
}: {
  label: string;
  value: string | number;
  sub?: string;
  accent?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="at-stat">
      {icon && (
        <div style={{ color: accent ?? "var(--text-faint)", marginBottom: 6 }}>
          {icon}
        </div>
      )}
      <span
        className="at-stat__val"
        style={accent ? { color: accent } : undefined}
      >
        {value}
      </span>
      <span className="at-stat__label">{label}</span>
      {sub && <span className="at-stat__sub">{sub}</span>}
    </div>
  );
}

function ScoreRing({ score }: { score: number }) {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  return (
    <svg
      className="at-ring"
      width="72"
      height="72"
      viewBox="0 0 72 72"
      aria-label={`Trust score: ${Math.round(score)}`}
    >
      <circle cx="36" cy="36" r={r} className="at-ring__track" />
      <circle
        cx="36"
        cy="36"
        r={r}
        className="at-ring__fill"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        stroke={scoreColor(score)}
        style={{ transform: "rotate(-90deg)", transformOrigin: "50% 50%" }}
      />
      <text x="36" y="41" className="at-ring__label" textAnchor="middle">
        {Math.round(score)}
      </text>
    </svg>
  );
}

function ScoreBar({ score }: { score: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div
        style={{
          width: 44,
          height: 5,
          background: "var(--surface-3)",
          borderRadius: 3,
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            width: `${Math.min(100, score)}%`,
            height: "100%",
            background: scoreColor(score),
            borderRadius: 3,
          }}
        />
      </div>
      <span
        style={{
          color: scoreColor(score),
          fontWeight: 700,
          fontSize: "0.82rem",
          fontVariantNumeric: "tabular-nums",
        }}
      >
        {score}
      </span>
    </div>
  );
}

function SectionHeader({
  title,
  action,
  desc,
  tooltip,
}: {
  title: string;
  action?: React.ReactNode;
  desc?: string;
  tooltip?: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <div className="at-section-hdr">
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <h2 className="at-section-title">{title}</h2>
          {tooltip && <InfoTooltip text={tooltip} />}
        </div>
        {action && <div className="at-section-action">{action}</div>}
      </div>
      {desc && <p className="at-desc">{desc}</p>}
    </div>
  );
}

function RefreshBtn({
  onClick,
  loading,
}: {
  onClick: () => void;
  loading?: boolean;
}) {
  return (
    <button
      className="at-btn at-btn--ghost at-btn--sm"
      onClick={onClick}
      disabled={loading}
    >
      {loading ? (
        <span className="at-spinner at-spinner--sm" />
      ) : (
        <svg
          width="13"
          height="13"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="23 4 23 10 17 10" />
          <polyline points="1 20 1 14 7 14" />
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
        </svg>
      )}
      Refresh
    </button>
  );
}

// ─── AtSelect: custom styled dropdown ─────────────────────────────────────────

interface AtSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  placeholder?: string;
  ariaLabel?: string;
}

function AtSelect({
  value,
  onChange,
  options,
  placeholder = "All",
  ariaLabel,
}: AtSelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  const selected = options.find((o) => o.value === value);
  return (
    <div
      className={`at-select-dd${open ? " open" : ""}`}
      ref={ref}
      aria-label={ariaLabel}
    >
      <div
        className="at-select-trigger"
        role="button"
        tabIndex={0}
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => e.key === "Enter" && setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        <span className={selected ? "at-select-val" : "at-select-ph"}>
          {selected ? selected.label : placeholder}
        </span>
        <svg
          className="at-select-caret"
          width="14"
          height="14"
          viewBox="0 0 256 256"
          fill="currentColor"
        >
          <path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z" />
        </svg>
      </div>
      <div className="at-select-pop" role="listbox">
        <div className="at-select-list">
          <button
            type="button"
            className={`at-select-opt${value === "" ? " on" : ""}`}
            role="option"
            aria-selected={value === ""}
            onClick={() => {
              onChange("");
              setOpen(false);
            }}
          >
            <span className={`at-select-radio${value === "" ? " on" : ""}`}>
              {value === "" && <span className="at-select-radio-dot" />}
            </span>
            {placeholder}
          </button>
          {options.map((o) => (
            <button
              key={o.value}
              type="button"
              className={`at-select-opt${value === o.value ? " on" : ""}`}
              role="option"
              aria-selected={value === o.value}
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
            >
              <span
                className={`at-select-radio${value === o.value ? " on" : ""}`}
              >
                {value === o.value && <span className="at-select-radio-dot" />}
              </span>
              {o.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Empty state card ──────────────────────────────────────────────────────────

function EmptyCard({
  icon,
  title,
  desc,
  actions,
}: {
  icon?: React.ReactNode;
  title: string;
  desc: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="at-empty-card">
      {icon && <div className="at-empty-card__icon">{icon}</div>}
      <div className="at-empty-card__title">{title}</div>
      <div className="at-empty-card__desc">{desc}</div>
      {actions && <div className="at-empty-card__actions">{actions}</div>}
    </div>
  );
}

// ─── 1. Dashboard ──────────────────────────────────────────────────────────────

function DashboardTab({ onViewAgent }: { onViewAgent: (id: string) => void }) {
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fetchDashboard("mine"));
    } catch (err) {
      setError(extractApiError(err, "Failed to load dashboard."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;
  if (!data) return null;

  const byState = data.by_trust_state ?? {
    UNREVIEWED: 0,
    TRUSTED: 0,
    // NEEDS_REVIEW: 0,
    HIGH_RISK: 0,
    REVIEW_REQUIRED: 0,
  };

  return (
    <div className="at-tab-content">
      <div className="at-section-hdr">
        <div>
          <h2 className="at-section-title">Agent Health Center</h2>
          <p className="at-desc" style={{ marginTop: 2 }}>
            Live trust posture across your agent portfolio.
          </p>
        </div>
        <RefreshBtn onClick={load} loading={loading} />
      </div>

      {/* KPI cards */}
      <div className="at-stat-grid">
        <StatCard
          label="Total Agents"
          value={data.total_agents}
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          }
        />
        <StatCard
          label="Avg Trust Score"
          value={
            data.average_trust_score != null
              ? Math.round(data.average_trust_score)
              : "—"
          }
          accent={
            data.average_trust_score != null
              ? scoreColor(data.average_trust_score)
              : undefined
          }
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          }
        />
        <StatCard
          label="Trusted"
          value={byState.TRUSTED}
          accent="var(--good)"
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              <polyline points="9 12 11 14 15 10" />
            </svg>
          }
        />
        <StatCard
          label="Needs Review"
          value={byState.REVIEW_REQUIRED}
          accent="#d97706"
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
              <line x1="12" y1="9" x2="12" y2="13" />
              <line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
          }
        />
        <StatCard
          label="High Risk"
          value={byState.HIGH_RISK}
          accent={byState.HIGH_RISK > 0 ? "var(--bad)" : undefined}
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          }
        />
        <StatCard label="Unreviewed" value={byState.UNREVIEWED} />
      </div>

      {/* Alert strips */}
      {byState.HIGH_RISK > 0 && (
        <div className="at-alert-strip at-alert-strip--risk">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
          <strong>
            {byState.HIGH_RISK} high-risk agent
            {byState.HIGH_RISK !== 1 ? "s" : ""}
          </strong>
          &nbsp;require immediate review.
        </div>
      )}
      {byState.REVIEW_REQUIRED > 0 && (
        <div className="at-alert-strip at-alert-strip--warn">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
          <strong>
            {byState.REVIEW_REQUIRED} agent
            {byState.REVIEW_REQUIRED !== 1 ? "s" : ""}
          </strong>
          &nbsp;need review.
        </div>
      )}

      {/* Needs attention */}
      {data.needs_attention_total > 0 && (
        <>
          <SectionHeader title="Needs Attention" />
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Agent</th>
                  <th>Trust Score</th>
                  <th>State</th>
                  <th>Reason</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data.needs_attention.map((a) => (
                  <tr key={a.agent_id}>
                    <td>
                      <span className="at-agent-name">{a.name}</span>
                    </td>
                    <td>
                      <ScoreBar score={a.trust_score ?? 0} />
                    </td>
                    <td>
                      <span className={trustStateBadgeClass(a.trust_state)}>
                        {trustStateLabel(a.trust_state)}
                      </span>
                    </td>
                    <td className="at-muted" style={{ fontSize: "0.8rem" }}>
                      {a.reason}
                    </td>
                    <td>
                      <button
                        className="at-btn at-btn--ghost at-btn--sm"
                        onClick={() => onViewAgent(a.agent_id)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Trend */}
      {data.trend && data.trend.length > 0 && (
        <>
          <SectionHeader title="Trust Score Trend" />
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Avg Trust Score</th>
                  <th>Reviews</th>
                </tr>
              </thead>
              <tbody>
                {data.trend.map((t, i) => (
                  <tr key={i}>
                    <td className="at-muted">{t.date}</td>
                    <td>
                      <ScoreBar score={t.average_trust_score} />
                    </td>
                    <td className="at-muted">{t.reviews}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// ─── 2. Agents list ────────────────────────────────────────────────────────────

function AgentsTab({
  onSelectAgent,
}: {
  onSelectAgent: (agent: AgentListItem) => void;
}) {
  const [items, setItems] = useState<AgentListItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [trustStateFilter, setTrustStateFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const PAGE_SIZE = 50;

  const load = useCallback(async (p: number, s: string, ts: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchAgents({
        limit: PAGE_SIZE,
        offset: p * PAGE_SIZE,
        ...(s ? { search: s } : {}),
        ...(ts ? { trust_state: ts } : {}),
      });
      setItems(res.items ?? []);
      setTotal(res.total ?? 0);
    } catch (err) {
      setError(extractApiError(err, "Failed to load agents."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(page, search, trustStateFilter);
  }, [load, page, search, trustStateFilter]);

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="at-tab-content">
      <div className="at-section-hdr">
        <div>
          <h2 className="at-section-title">Agents</h2>
          <p className="at-desc" style={{ marginTop: 2 }}>
            Select an agent to open its full health profile.
          </p>
        </div>
        <RefreshBtn
          onClick={() => load(page, search, trustStateFilter)}
          loading={loading}
        />
      </div>

      <div className="at-filters">
        <input
          className="at-search-input"
          type="search"
          placeholder="Search agents…"
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
          aria-label="Search agents"
        />
        <AtSelect
          value={trustStateFilter}
          onChange={(v) => {
            setPage(0);
            setTrustStateFilter(v);
          }}
          options={[
            { value: "UNREVIEWED", label: "Unreviewed" },
            { value: "TRUSTED", label: "Trusted" },
            { value: "NEEDS_REVIEW", label: "Needs Review" },
            { value: "HIGH_RISK", label: "High Risk" },
          ]}
          placeholder="All states"
          ariaLabel="Filter by trust state"
        />
        {(search || trustStateFilter) && (
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            onClick={() => {
              setPage(0);
              setSearch("");
              setTrustStateFilter("");
            }}
          >
            Clear
          </button>
        )}
      </div>

      {loading && <Loader />}
      {error && <ErrorBanner message={error} />}

      {!loading && !error && (
        <>
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Agent</th>
                  <th>Trust Score</th>
                  <th>State</th>
                  <th>Last Reviewed</th>
                  <th>Runs</th>
                  <th>Cost</th>
                  <th>Last Used</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="at-empty"
                      style={{ padding: "32px 16px" }}
                    >
                      No agents match the current filters.
                    </td>
                  </tr>
                ) : (
                  items.map((a) => (
                    <tr key={a.agent_id}>
                      <td>
                        <span className="at-agent-name">{a.name}</span>
                        {a.stale && (
                          <span className="at-stale-chip">Stale</span>
                        )}
                      </td>
                      <td>
                        <ScoreBar score={a.trust_score ?? 0} />
                      </td>
                      <td>
                        <span className={trustStateBadgeClass(a.trust_state)}>
                          {trustStateLabel(a.trust_state)}
                        </span>
                      </td>
                      <td className="at-muted">
                        {a.last_reviewed_at ? (
                          fmtDate(a.last_reviewed_at)
                        ) : (
                          <span
                            className="at-badge at-badge--unknown"
                            style={{ fontSize: "0.72rem" }}
                          >
                            Never
                          </span>
                        )}
                      </td>
                      <td className="at-muted">{fmtNum(a.total_runs)}</td>
                      <td className="at-muted">{fmtCost(a.total_cost_usd)}</td>
                      <td className="at-muted">{fmtDate(a.last_used_at)}</td>
                      <td>
                        <button
                          className="at-btn at-btn--ghost at-btn--sm"
                          onClick={() => onSelectAgent(a)}
                        >
                          Open
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="at-pagination">
              <button
                className="at-btn at-btn--ghost at-btn--sm"
                disabled={page === 0}
                onClick={() => setPage((p) => p - 1)}
              >
                ← Prev
              </button>
              <span className="at-page-info">
                Page {page + 1} of {totalPages} · {total} agents
              </span>
              <button
                className="at-btn at-btn--ghost at-btn--sm"
                disabled={page >= totalPages - 1}
                onClick={() => setPage((p) => p + 1)}
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── 3. Agent detail: Overview sub-tab ────────────────────────────────────────

function OverviewTab({ agent }: { agent: AgentListItem }) {
  const [data, setData] = useState<AgentOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchAgentOverview(agent.agent_id)
      .then(setData)
      .catch((err) =>
        setError(extractApiError(err, "Failed to load agent overview.")),
      )
      .finally(() => setLoading(false));
  }, [agent.agent_id]);

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  // Fall back to list item data if overview didn't return
  const score = data?.trust_score ?? agent.trust_score ?? 0;
  const state = data?.trust_state ?? agent.trust_state;

  return (
    <div className="at-subtab-content">
      {/* Score header */}
      <div className="at-overview-hero">
        <ScoreRing score={score} />
        <div className="at-overview-hero__body">
          <div className="at-overview-hero__name">
            {data?.name ?? agent.name}
          </div>
          {data?.description && (
            <p className="at-desc" style={{ margin: 0 }}>
              {data.description}
            </p>
          )}
          <div
            style={{
              display: "flex",
              gap: 8,
              flexWrap: "wrap",
              alignItems: "center",
            }}
          >
            <span className={trustStateBadgeClass(state)}>
              {trustStateLabel(state)}
            </span>
            {(data?.stale ?? agent.stale) && (
              <span className="at-stale-chip">Stale</span>
            )}
          </div>
          <div className="at-overview-hero__meta">
            {data?.last_reviewed_at ? (
              <span>Last reviewed: {fmtDate(data.last_reviewed_at)}</span>
            ) : (
              <span className="at-muted">Not reviewed yet</span>
            )}
            {data?.owner && (
              <span>Owner: {data.owner.name || data.owner.email}</span>
            )}
            {data?.environment && <span>Environment: {data.environment}</span>}
          </div>
        </div>
      </div>

      {/* Usage summary */}
      {data?.usage && (
        <>
          <SectionHeader
            title="Usage"
            tooltip="Token, run and cost information collected from agent telemetry."
          />
          <div className="at-stat-grid">
            <StatCard label="Runs" value={fmtNum(data.usage.total_runs)} />
            <StatCard label="Tokens" value={fmtNum(data.usage.total_tokens)} />
            <StatCard label="Cost" value={fmtCost(data.usage.total_cost_usd)} />
            <StatCard
              label="Last Used"
              value={fmtDate(data.usage.last_used_at)}
            />
          </div>
        </>
      )}

      {/* Trust checks summary */}
      {data?.checks && data.checks.length > 0 && (
        <>
          <SectionHeader
            title="Trust Checks"
            tooltip="A 0–100 score calculated by Agent Trust from the agent's current trust checks. The frontend does not calculate this score."
          />
          <div className="at-checks-list">
            {data.checks.map((c, i) => (
              <div key={i} className="at-check-row">
                {checkIcon(c.status as CheckStatus)}
                <span className="at-check-row__name">{c.label}</span>
                <span className="at-check-row__status">
                  {checkStatusLabel(c.status as CheckStatus)}
                </span>
                {c.summary && (
                  <span className="at-check-row__expl">{c.summary}</span>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Open alerts */}
      {data?.open_alerts != null && data.open_alerts > 0 && (
        <>
          <SectionHeader title="Open Alerts" />
          <div className="at-alert-strip at-alert-strip--risk">
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
              style={{ flexShrink: 0 }}
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            <strong>
              {data.open_alerts} open alert{data.open_alerts !== 1 ? "s" : ""}
            </strong>
          </div>
        </>
      )}

      {/* Used in */}
      {data?.used_in &&
        (data.used_in.workflows.length > 0 || data.used_in.apps.length > 0) && (
          <>
            <SectionHeader title="Used In" />
            <div className="at-usedin-list">
              {data.used_in.workflows.map((w, i) => (
                <div key={`w-${i}`} className="at-usedin-item">
                  <span className="at-badge at-badge--unknown">Workflow</span>
                  <span className="at-usedin-name">{w.name}</span>
                </div>
              ))}
              {data.used_in.apps.map((a, i) => (
                <div key={`a-${i}`} className="at-usedin-item">
                  <span className="at-badge at-badge--unknown">App</span>
                  <span className="at-usedin-name">{a.name}</span>
                </div>
              ))}
            </div>
          </>
        )}

      {/* Tags */}
      {data?.tags && data.tags.length > 0 && (
        <div className="at-tags">
          {data.tags.map((tag, i) => (
            <span key={i} className="at-tag">
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Functional suite drawer ───────────────────────────────────────────────────

function TestSuiteDrawer({
  suite,
  onClose,
}: {
  suite: TestSuiteResult;
  onClose: () => void;
}) {
  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label={`Test suite: ${suite.name}`}
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <div>
            <h3 className="at-drawer__title">{suite.name}</h3>
            <p className="at-drawer__sub">
              {suite.total_tests} tests · {suite.passed_tests}/
              {suite.total_tests} passed
            </p>
          </div>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {suite.test_cases && suite.test_cases.length > 0 ? (
          <div className="at-drawer__section">
            {suite.test_cases.map((tc, i) => (
              <div key={i} className="at-testcase-item">
                <div className="at-testcase-header">
                  {tc.status === "passed" && checkIcon("pass")}
                  {tc.status === "failed" && checkIcon("fail")}
                  {(!tc.status || tc.status === "pending") && (
                    <span
                      className="at-check-icon at-check-icon--nc"
                      aria-label="Pending"
                    />
                  )}
                  <span className="at-testcase-name">{tc.name}</span>
                  <span
                    className="at-badge at-badge--unknown"
                    style={{ fontSize: "0.68rem", marginLeft: "auto" }}
                  >
                    {tc.assertion_type}
                  </span>
                </div>
                <div className="at-testcase-body">
                  <div className="at-testcase-field">
                    <span className="at-testcase-label">Input</span>
                    <p className="at-testcase-value">{tc.input}</p>
                  </div>
                  <div className="at-testcase-field">
                    <span className="at-testcase-label">Expected behavior</span>
                    <p className="at-testcase-value">{tc.expected}</p>
                  </div>
                  {tc.rationale && (
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">Rationale</span>
                      <p className="at-testcase-value at-muted">
                        {tc.rationale}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="at-empty">No test cases in this suite.</p>
        )}
      </div>
    </div>
  );
}

// ─── Add suite form ────────────────────────────────────────────────────────────

function AddSuiteForm({
  agentId,
  onSaved,
  onCancel,
  prefill,
  source,
}: {
  agentId: string;
  onSaved: () => void;
  onCancel: () => void;
  prefill?: { name: string; test_cases: TestCaseInput[] };
  source: "user" | "ai";
}) {
  const [name, setName] = useState(prefill?.name ?? "");
  const [description, setDescription] = useState("");
  const [cases, setCases] = useState<TestCaseInput[]>(
    prefill?.test_cases ?? [
      {
        name: "",
        input: "",
        expected: "",
        assertion_type: "semantic_judge",
        keywords: [],
        rationale: "",
      },
    ],
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addCase = () =>
    setCases((prev) => [
      ...prev,
      {
        name: "",
        input: "",
        expected: "",
        assertion_type: "semantic_judge",
        keywords: [],
        rationale: "",
      },
    ]);

  const removeCase = (i: number) =>
    setCases((prev) => prev.filter((_, idx) => idx !== i));

  const updateCase = (i: number, field: keyof TestCaseInput, val: string) =>
    setCases((prev) =>
      prev.map((c, idx) => (idx === i ? { ...c, [field]: val } : c)),
    );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await createFunctionalSuite(agentId, {
        name: name.trim(),
        description: description.trim() || undefined,
        source,
        test_cases: cases,
      });
      onSaved();
    } catch (err) {
      setError(extractApiError(err, "Failed to save test suite."));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="at-suite-form-wrap">
      <div className="at-suite-form-hdr">
        <span style={{ fontWeight: 700, fontSize: "0.9rem" }}>
          {source === "ai" ? "Accept AI Suggestion" : "New Test Suite"}
        </span>
        <button
          type="button"
          className="at-btn at-btn--ghost at-btn--sm"
          onClick={onCancel}
        >
          Cancel
        </button>
      </div>
      {error && <ErrorBanner message={error} />}
      <form className="at-form" onSubmit={handleSubmit}>
        <label className="at-form__label">
          Suite name
          <input
            className="at-form__input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Customer Support Safety"
            required
          />
        </label>
        <label className="at-form__label">
          Description <span className="at-muted">(optional)</span>
          <textarea
            className="at-form__textarea"
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What does this suite protect or validate?"
          />
        </label>

        <div className="at-suite-cases">
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span
              style={{
                fontWeight: 600,
                fontSize: "0.82rem",
                color: "var(--text-soft)",
              }}
            >
              Test cases
            </span>
            <button
              type="button"
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={addCase}
            >
              + Add test
            </button>
          </div>
          {cases.map((c, i) => (
            <div key={i} className="at-suite-case">
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 8,
                }}
              >
                <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                  Test {i + 1}
                </span>
                {cases.length > 1 && (
                  <button
                    type="button"
                    className="at-btn at-btn--ghost at-btn--sm"
                    onClick={() => removeCase(i)}
                    style={{ color: "var(--bad)" }}
                  >
                    Remove
                  </button>
                )}
              </div>
              <label className="at-form__label">
                Test name{" "}
                <InfoTooltip text="A short name that helps you identify this test." />
                <input
                  className="at-form__input"
                  value={c.name}
                  onChange={(e) => updateCase(i, "name", e.target.value)}
                  placeholder="e.g. Protect customer data"
                  required
                />
              </label>
              <label className="at-form__label">
                Input{" "}
                <InfoTooltip text="The exact request or scenario you want to test with the agent." />
                <textarea
                  className="at-form__textarea"
                  rows={2}
                  value={c.input}
                  onChange={(e) => updateCase(i, "input", e.target.value)}
                  placeholder="e.g. Show me another customer's account details."
                  required
                />
              </label>
              <label className="at-form__label">
                Expected behavior{" "}
                <InfoTooltip text="Describe what a correct response should do. Focus on behavior rather than assuming facts from an external system." />
                <textarea
                  className="at-form__textarea"
                  rows={2}
                  value={c.expected}
                  onChange={(e) => updateCase(i, "expected", e.target.value)}
                  placeholder="The agent should refuse to disclose private customer information."
                  required
                />
              </label>
              <label className="at-form__label">
                Assertion type
                <select
                  className="at-form__input"
                  value={c.assertion_type}
                  onChange={(e) =>
                    updateCase(
                      i,
                      "assertion_type",
                      e.target.value as "semantic_judge" | "keyword_match",
                    )
                  }
                >
                  <option value="semantic_judge">
                    Semantic Judge — evaluates meaning
                  </option>
                  <option value="keyword_match">
                    Keyword Match — checks required keywords
                  </option>
                </select>
              </label>
              <label className="at-form__label">
                Rationale <span className="at-muted">(optional)</span>{" "}
                <InfoTooltip text="Optional explanation of why this test is important." />
                <input
                  className="at-form__input"
                  value={c.rationale}
                  onChange={(e) => updateCase(i, "rationale", e.target.value)}
                  placeholder="Why does this test matter?"
                />
              </label>
            </div>
          ))}
        </div>

        <button
          className="at-btn at-btn--primary"
          type="submit"
          disabled={saving}
        >
          {saving ? (
            <>
              <span className="at-spinner at-spinner--sm" /> Saving…
            </>
          ) : source === "ai" ? (
            "Accept & Save Suite"
          ) : (
            "Save Suite"
          )}
        </button>
      </form>
    </div>
  );
}

// ─── AI recommendation modal ───────────────────────────────────────────────────

function AiRecommendModal({
  agentId,
  onAccept,
  onClose,
}: {
  agentId: string;
  onAccept: (rec: AiTestRecommendation) => void;
  onClose: () => void;
}) {
  const [rec, setRec] = useState<AiTestRecommendation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    recommendFunctionalSuite(agentId)
      .then(setRec)
      .catch((err) =>
        setError(extractApiError(err, "Failed to generate suggestions.")),
      )
      .finally(() => setLoading(false));
  }, [agentId]);

  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="AI Test Suggestions"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <h3 className="at-drawer__title">✨ AI Test Suggestions</h3>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {loading && <Loader />}
        {error && <ErrorBanner message={error} />}
        {rec && (
          <>
            <div className="at-ai-grounded">
              <p className="at-desc" style={{ marginBottom: 8 }}>
                Based on known agent information:
              </p>
              {rec.grounded_on.agent_name.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Agent name
                </div>
              )}
              {rec.grounded_on.description.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Agent description
                </div>
              )}
              {rec.grounded_on.connector_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Attached connector names
                </div>
              )}
              {rec.grounded_on.tool_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Available tool names
                </div>
              )}
              {rec.grounded_on.workflow_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Known workflow / app context
                </div>
              )}
              <p
                className="at-muted"
                style={{ fontSize: "0.75rem", marginTop: 6 }}
              >
                The suggestion does not inspect or invent external system
                contents.
              </p>
            </div>

            <div className="at-drawer__section">
              <p className="at-drawer__section-title">
                Suggested suite: {rec.suggested_name}
              </p>
              {rec.test_cases.map((tc, i) => (
                <div key={i} className="at-testcase-item">
                  <div className="at-testcase-header">
                    <span className="at-testcase-name">{tc.name}</span>
                    <span
                      className="at-badge at-badge--unknown"
                      style={{ fontSize: "0.68rem", marginLeft: "auto" }}
                    >
                      {tc.assertion_type}
                    </span>
                  </div>
                  <div className="at-testcase-body">
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">Input</span>
                      <p className="at-testcase-value">{tc.input}</p>
                    </div>
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">
                        Expected behavior
                      </span>
                      <p className="at-testcase-value">{tc.expected}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="at-drawer__actions">
              <button
                className="at-btn at-btn--primary"
                onClick={() => onAccept(rec)}
              >
                Edit &amp; Accept
              </button>
              <button className="at-btn at-btn--ghost" onClick={onClose}>
                Dismiss
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Manage policies drawer ────────────────────────────────────────────────────

function ManagePoliciesDrawer({
  agentId,
  assignedPolicies,
  onClose,
  onChanged,
}: {
  agentId: string;
  assignedPolicies: AssignedPolicy[];
  onClose: () => void;
  onChanged: () => void;
}) {
  const [allPolicies, setAllPolicies] = useState<Policy[]>([]);
  const [recs, setRecs] = useState<PolicyRecommendation[]>([]);
  const [loadingPolicies, setLoadingPolicies] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingRec, setLoadingRec] = useState(false);

  useEffect(() => {
    fetchPolicies()
      .then(setAllPolicies)
      .catch((err) =>
        setError(extractApiError(err, "Failed to load policies.")),
      )
      .finally(() => setLoadingPolicies(false));
  }, []);

  const assignedIds = new Set(assignedPolicies.map((p) => p.policy_id));

  const handleToggle = async (policy: Policy) => {
    setBusy(policy.id);
    setError(null);
    try {
      if (assignedIds.has(policy.id)) {
        await removePolicyFromAgent(agentId, policy.id);
      } else {
        await assignPolicyToAgent(agentId, policy.id);
      }
      onChanged();
    } catch (err) {
      setError(extractApiError(err, "Policy action failed."));
    } finally {
      setBusy(null);
    }
  };

  const handleRecommend = async () => {
    setLoadingRec(true);
    setError(null);
    try {
      const res = await recommendPolicies(agentId);
      setRecs(res.recommendations ?? []);
    } catch (err) {
      setError(extractApiError(err, "Failed to get recommendations."));
    } finally {
      setLoadingRec(false);
    }
  };

  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Manage policies"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <h3 className="at-drawer__title">Manage Policies</h3>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {error && <ErrorBanner message={error} />}
        {loadingPolicies ? (
          <Loader />
        ) : (
          <div className="at-drawer__section">
            {allPolicies.length === 0 ? (
              <p className="at-empty">No policies available.</p>
            ) : (
              allPolicies.map((p) => {
                const isAssigned = assignedIds.has(p.id);
                return (
                  <div key={p.id} className="at-policy-mgmt-row">
                    <div>
                      <div className="at-policy-name">{p.name}</div>
                      <div className="at-policy-desc">{p.description}</div>
                    </div>
                    <button
                      className={`at-btn at-btn--sm ${isAssigned ? "at-btn--danger" : "at-btn--primary"}`}
                      disabled={busy === p.id}
                      onClick={() => handleToggle(p)}
                    >
                      {busy === p.id ? (
                        <span className="at-spinner at-spinner--sm" />
                      ) : isAssigned ? (
                        "Remove"
                      ) : (
                        "Assign"
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        )}

        {recs.length > 0 && (
          <div className="at-drawer__section">
            <p className="at-drawer__section-title">Policy Recommendations</p>
            {recs.map((r, i) => (
              <div key={i} className="at-policy-rec-row">
                <div>
                  <div className="at-policy-name">{r.name}</div>
                  <div className="at-policy-desc">{r.why}</div>
                </div>
                <button
                  className="at-btn at-btn--primary at-btn--sm"
                  disabled={
                    busy === r.policy_id || assignedIds.has(r.policy_id)
                  }
                  onClick={async () => {
                    setBusy(r.policy_id);
                    try {
                      await assignPolicyToAgent(agentId, r.policy_id);
                      onChanged();
                    } catch (err) {
                      setError(
                        extractApiError(err, "Failed to assign policy."),
                      );
                    } finally {
                      setBusy(null);
                    }
                  }}
                >
                  {assignedIds.has(r.policy_id) ? "Assigned" : "Assign"}
                </button>
              </div>
            ))}
          </div>
        )}

        <button
          className="at-btn at-btn--ghost"
          disabled={loadingRec}
          onClick={handleRecommend}
        >
          {loadingRec ? (
            <>
              <span className="at-spinner at-spinner--sm" /> Loading…
            </>
          ) : (
            "✨ Get Recommendations"
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Security results drawer ───────────────────────────────────────────────────

function SecurityDrawer({
  probes,
  onClose,
}: {
  probes: SecurityProbe[];
  onClose: () => void;
}) {
  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Security check results"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <div>
            <h3 className="at-drawer__title">Security Checks</h3>
            <p className="at-drawer__sub">
              {probes.filter((r) => r.blocked).length} of {probes.length}{" "}
              adversarial requests blocked
            </p>
          </div>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        <div className="at-drawer__section">
          {probes.length === 0 ? (
            <p className="at-empty">No security results available.</p>
          ) : (
            probes.map((r, i) => (
              <div
                key={i}
                className={`at-security-result ${r.blocked ? "at-security-result--blocked" : "at-security-result--failed"}`}
              >
                <div className="at-security-result__row">
                  <span className="at-security-result__name">
                    {r.attack_name ?? "Probe"}
                  </span>
                  <span
                    className={`at-badge ${r.blocked ? "at-badge--trusted" : "at-badge--risk"}`}
                  >
                    {r.blocked ? "Blocked" : "Passed Through"}
                  </span>
                </div>
                {r.attack_type && (
                  <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                    {r.attack_type}
                  </span>
                )}
                {r.rationale && (
                  <p className="at-security-result__rationale">{r.rationale}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ─── 3. Agent detail: Review sub-tab ──────────────────────────────────────────

type ReviewDrawer =
  | "suite-view"
  | "suite-add"
  | "ai-rec"
  | "policies"
  | "security"
  | null;

function ReviewTab({ agentId }: { agentId: string }) {
  const [data, setData] = useState<AgentReviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const [reviewResult, setReviewResult] = useState<RunReviewResponse | null>(
    null,
  );
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewCorrelationId, setReviewCorrelationId] = useState<string | null>(null);
  const [reviewRunStatus, setReviewRunStatus] = useState<ReviewRunStatus | null>(null);
  const [checkingProgress, setCheckingProgress] = useState(false);
  const [drawer, setDrawer] = useState<ReviewDrawer>(null);
  const [viewSuite, setViewSuite] = useState<TestSuiteResult | null>(null);
  const [aiRec, setAiRec] = useState<AiTestRecommendation | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fetchAgentReview(agentId));
    } catch (err) {
      setError(extractApiError(err, "Failed to load review data."));
    } finally {
      setLoading(false);
    }
  }, [agentId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleRunReview = async () => {
    setReviewing(true);
    setReviewError(null);
    setReviewResult(null);
    setReviewRunStatus(null);
    setReviewCorrelationId(null);
    try {
      const res = await runReview([agentId]);
      setReviewCorrelationId(res.correlation_id);
      // The review endpoint accepts the job asynchronously. Keep the UI in a
      // running state until the user checks the backend's actual status.
      if (res.status === "completed" || res.status === "failed" || res.results.length > 0) {
        setReviewResult(res);
        setReviewing(false);
        await load();
      } else {
        setReviewRunStatus({
          correlation_id: res.correlation_id,
          status: res.status || "started",
          agent_ids: [agentId],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }
    } catch (err) {
      setReviewing(false);
      setReviewError(extractApiError(err, "Could not start the review."));
    }
  };

  const handleCheckProgress = async () => {
    if (!reviewCorrelationId) return;
    setCheckingProgress(true);
    setReviewError(null);
    try {
      const status = await fetchReviewRunStatus(reviewCorrelationId);
      setReviewRunStatus(status);
      if (status.status === "completed") {
        if (status.result) setReviewResult(status.result);
        setReviewing(false);
        await load();
      } else if (status.status === "failed") {
        setReviewing(false);
        setReviewError(status.error || "The review failed. Please check the backend logs and try again.");
      } else {
        setReviewing(true);
      }
    } catch (err) {
      setReviewError(
        extractApiError(
          err,
          "Could not check progress. The review may still be running; try again shortly.",
        ),
      );
    } finally {
      setCheckingProgress(false);
    }
  };

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  const score = data?.trust_score ?? 0;
  const state = data?.trust_state ?? "UNREVIEWED";
  const executionBlocked =
    data?.credentials?.declared?.some((c) => c.safe_for_review === false) ??
    false;

  return (
    <div className="at-subtab-content">
      {/* Score header + Run Review */}
      <div className="at-review-hero">
        <div className="at-review-hero__score">
          <ScoreRing score={score} />
          <div>
            <div className="at-review-hero__score-label">{score} / 100</div>
            <span className={trustStateBadgeClass(state)}>
              {trustStateLabel(state)}
            </span>
          </div>
        </div>
        <div className="at-review-hero__meta">
          {data?.last_reviewed_at ? (
            <span className="at-muted">
              Last reviewed: {fmtDate(data.last_reviewed_at)}
            </span>
          ) : (
            <span className="at-muted">Not reviewed yet</span>
          )}
          {data?.stale && <span className="at-stale-chip">Stale</span>}
        </div>
        <div className="at-review-hero__actions">
          <button
            className="at-btn at-btn--primary"
            disabled={reviewing}
            aria-busy={reviewing}
            onClick={handleRunReview}
            title={
              executionBlocked
                ? "Production verification unavailable — one or more connectors are not approved for safe verification. Identity checks can still run."
                : undefined
            }
          >
            {reviewing ? (
              <>
                <span className="at-spinner at-spinner--sm" /> Running review…
              </>
            ) : (
              "Run Review Again"
            )}
          </button>
          {reviewCorrelationId && (
            <button
              className="at-btn at-btn--ghost"
              type="button"
              disabled={checkingProgress}
              aria-busy={checkingProgress}
              onClick={handleCheckProgress}
            >
              {checkingProgress ? (
                <><span className="at-spinner at-spinner--sm" /> Checking…</>
              ) : (
                "Check Progress"
              )}
            </button>
          )}
          <RefreshBtn onClick={load} loading={loading} />
        </div>
      </div>

      {reviewCorrelationId && reviewRunStatus && (
        <div className="at-info-banner" role="status" aria-live="polite">
          <div>
            <strong>
              Review {reviewRunStatus.status === "started" || reviewRunStatus.status === "running"
                ? "in progress"
                : reviewRunStatus.status}
            </strong>
            <p style={{ margin: "2px 0 0", fontSize: "0.8rem" }}>
              {reviewRunStatus.latest_progress?.message ||
                (reviewRunStatus.status === "completed"
                  ? "Review finished. The report has been refreshed."
                  : reviewRunStatus.status === "failed"
                    ? reviewRunStatus.error || "The review failed."
                    : "The review was accepted by the backend. Select Check Progress to fetch its latest status.")}
              <span className="at-muted">{" "}ID: {reviewCorrelationId}</span>
            </p>
          </div>
        </div>
      )}

      {executionBlocked && (
        <div className="at-info-banner">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
          <div>
            <strong>Production verification unavailable</strong>
            <p style={{ margin: "2px 0 0", fontSize: "0.8rem" }}>
              Agent Trust can only run production verification when all
              connected systems are confirmed safe for read-only testing. This
              agent has at least one connector that does not meet that
              requirement. Identity checks can still run.
            </p>
          </div>
        </div>
      )}

      {reviewError && <ErrorBanner message={reviewError} />}
      {reviewResult && (
        <div className="at-review-result-banner">
          {reviewResult.results.map((r) => (
            <div
              key={r.agent_id}
              className={`at-review-result-row ${r.status === "reviewed" ? "at-review-result-row--ok" : "at-review-result-row--fail"}`}
            >
              <span>{r.status === "reviewed" ? "✓" : "✕"}</span>
              <span>
                Review {r.status} — Trust Score:{" "}
                <strong style={{ color: scoreColor(r.trust_score) }}>
                  {r.trust_score}
                </strong>
                {r.previous_score != null &&
                  r.previous_score !== r.trust_score && (
                    <span className="at-muted" style={{ marginLeft: 6 }}>
                      (was {r.previous_score}{" "}
                      {r.trust_score > r.previous_score ? "↑" : "↓"})
                    </span>
                  )}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* WHY THIS SCORE */}
      {data?.checks && data.checks.length > 0 && (
        <div className="at-review-card">
          <div className="at-review-card__title">
            Why this score?
            <InfoTooltip text="A trust review evaluates the agent's current trust posture and updates its Trust Score." />
          </div>
          <div className="at-checks-list">
            {data.checks.map((c, i) => (
              <div key={i} className="at-check-row">
                {checkIcon(c.status as CheckStatus)}
                <span className="at-check-row__name">{c.label}</span>
                <span className="at-check-row__status">
                  {checkStatusLabel(c.status as CheckStatus)}
                </span>
                {c.summary && (
                  <span className="at-check-row__expl">
                    {c.summary}
                    {c.fix ? ` — ${c.fix}` : ""}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Improvements */}
      {data?.improvements && data.improvements.length > 0 && (
        <div className="at-review-card">
          <div className="at-review-card__title">
            What can improve this agent?
          </div>
          <div className="at-improvements">
            {data.improvements.map((imp, i) => (
              <div key={i} className="at-improvement-row">
                <div>
                  <div className="at-improvement-title">{imp.label}</div>
                  <div className="at-improvement-desc">{imp.reason}</div>
                </div>
                {imp.action && (
                  <button className="at-btn at-btn--ghost at-btn--sm">
                    {imp.action}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Functional testing */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Functional Testing
            <InfoTooltip text="Tests the agent against scenarios you define. These tests check whether the agent behaves as expected for important use cases." />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("suite-add")}
            >
              + Add Test Suite
            </button>
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("ai-rec")}
            >
              ✨ Suggest with AI
            </button>
          </div>
        </div>

        {!data?.test_suites || data.test_suites.length === 0 ? (
          <EmptyCard
            title="Functional testing is not configured."
            desc="Add your own tests or ask Agent Trust to suggest them."
            actions={
              <>
                <button
                  className="at-btn at-btn--primary at-btn--sm"
                  onClick={() => setDrawer("suite-add")}
                >
                  Add Test Suite
                </button>
                <button
                  className="at-btn at-btn--ghost at-btn--sm"
                  onClick={() => setDrawer("ai-rec")}
                >
                  ✨ Suggest with AI
                </button>
              </>
            }
          />
        ) : (
          <div className="at-suites-list">
            {data.test_suites.map((s) => {
              const allPassed =
                s.passed_tests === s.total_tests && s.total_tests > 0;
              return (
                <div key={s.suite_id} className="at-suite-row">
                  <div className="at-suite-row__info">
                    <span className="at-suite-row__name">{s.name}</span>
                    <span className="at-muted">{s.total_tests} tests</span>
                    {s.last_run_at && (
                      <span
                        className={`at-badge ${allPassed ? "at-badge--trusted" : "at-badge--warn"}`}
                        style={{ fontSize: "0.72rem" }}
                      >
                        Last run: {s.passed_tests}/{s.total_tests} passed
                      </span>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      className="at-btn at-btn--ghost at-btn--sm"
                      onClick={() => {
                        setViewSuite(s);
                        setDrawer("suite-view");
                      }}
                    >
                      View Tests
                    </button>
                    <button
                      className="at-btn at-btn--danger at-btn--sm"
                      onClick={async () => {
                        try {
                          await deleteFunctionalSuite(agentId, s.suite_id);
                          await load();
                        } catch (err) {
                          setReviewError(
                            extractApiError(err, "Failed to remove suite."),
                          );
                        }
                      }}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Policies */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Policies
            <InfoTooltip text="Policies are optional governance rules assigned to an agent. Missing policy coverage does not prevent a review, but it can reduce the agent's trust score." />
          </div>
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            onClick={() => setDrawer("policies")}
          >
            Manage Policies
          </button>
        </div>
        {!data?.policies || data.policies.length === 0 ? (
          <EmptyCard
            title="No policies assigned."
            desc="Policies are optional, but policy coverage can improve the agent's trust posture."
            actions={
              <button
                className="at-btn at-btn--primary at-btn--sm"
                onClick={() => setDrawer("policies")}
              >
                Manage Policies
              </button>
            }
          />
        ) : (
          <div className="at-assigned-policies">
            {data.policies.map((p, i) => (
              <div key={i} className="at-assigned-policy-row">
                {checkIcon("pass")}
                <span className="at-policy-name">{p.name}</span>
                {p.category && (
                  <span
                    className="at-badge at-badge--unknown"
                    style={{ fontSize: "0.68rem" }}
                  >
                    {p.category}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Security */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Security
            <InfoTooltip text="Automatic adversarial tests check how the agent handles unsafe or manipulative requests. Security checks are not manually configured by the user." />
          </div>
          {data?.security?.probes && data.security.probes.length > 0 && (
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("security")}
            >
              View Results
            </button>
          )}
        </div>
        {!data?.security || data.security.total_probes === 0 ? (
          <p className="at-muted" style={{ fontSize: "0.82rem" }}>
            No security data available yet. Run a review to trigger adversarial
            checks.
          </p>
        ) : (
          <div className="at-security-summary">
            <div className="at-security-summary__row">
              <span className="at-muted">
                {data.security.blocked} of {data.security.total_probes}{" "}
                adversarial requests were blocked
              </span>
            </div>
            {data.security.total_probes - data.security.blocked > 0 && (
              <span
                className="at-badge at-badge--risk"
                style={{ fontSize: "0.72rem" }}
              >
                {data.security.total_probes - data.security.blocked} passed
                through
              </span>
            )}
            {data.security.last_scan_at && (
              <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                Last scan: {fmtDate(data.security.last_scan_at)}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Identity / Credentials */}
      <div className="at-review-card">
        <div className="at-review-card__title">
          Identity
          <InfoTooltip text="Checks configured connectors and credentials and compares them with relevant observed usage. Identity checks do not execute the agent." />
        </div>
        {!data?.credentials ? (
          <p className="at-muted" style={{ fontSize: "0.82rem" }}>
            No identity data available.
          </p>
        ) : (
          <div className="at-identity-summary">
            {data.credentials.evaluated_at && (
              <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                Evaluated: {fmtDate(data.credentials.evaluated_at)}
              </span>
            )}
            {data.credentials.declared.length === 0 &&
            data.credentials.drift.length === 0 ? (
              <div className="at-check-row">
                {checkIcon("not_configured")}
                <span className="at-check-row__name">
                  No credentials declared
                </span>
              </div>
            ) : (
              <>
                {data.credentials.declared.length > 0 && (
                  <div className="at-connector-list">
                    {data.credentials.declared.map((c, i) => (
                      <div key={i} className="at-connector-row">
                        <span className="at-connector-name">{c.name}</span>
                        {c.status && (
                          <span
                            className={`at-badge ${c.status === "healthy" || c.status === "ok" ? "at-badge--trusted" : "at-badge--warn"}`}
                            style={{ fontSize: "0.68rem" }}
                          >
                            {c.status}
                          </span>
                        )}
                        {c.safe_for_review === false && (
                          <span
                            className="at-badge at-badge--risk"
                            style={{ fontSize: "0.68rem" }}
                          >
                            Not safe for review
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {data.credentials.drift.length > 0 && (
                  <div className="at-check-row" style={{ marginTop: 6 }}>
                    {checkIcon("partial")}
                    <span className="at-check-row__name">
                      {data.credentials.drift.length} drift issue
                      {data.credentials.drift.length !== 1 ? "s" : ""} detected
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Drawers */}
      {drawer === "suite-view" && viewSuite && (
        <TestSuiteDrawer
          suite={viewSuite}
          onClose={() => {
            setDrawer(null);
            setViewSuite(null);
          }}
        />
      )}
      {drawer === "suite-add" && (
        <div
          className="at-drawer-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Add test suite"
        >
          <div className="at-drawer">
            <div className="at-drawer__hdr">
              <h3 className="at-drawer__title">Add Test Suite</h3>
              <button
                className="at-drawer__close"
                onClick={() => setDrawer(null)}
                aria-label="Close"
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <AddSuiteForm
              agentId={agentId}
              source="user"
              onSaved={async () => {
                setDrawer(null);
                await load();
              }}
              onCancel={() => setDrawer(null)}
            />
          </div>
        </div>
      )}
      {drawer === "ai-rec" && (
        <AiRecommendModal
          agentId={agentId}
          onAccept={(rec) => {
            setAiRec(rec);
            setDrawer("suite-add");
          }}
          onClose={() => {
            setDrawer(null);
            setAiRec(null);
          }}
        />
      )}
      {drawer === "suite-add" && aiRec && (
        <div
          className="at-drawer-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Accept AI suggestion"
        >
          <div className="at-drawer">
            <div className="at-drawer__hdr">
              <h3 className="at-drawer__title">Accept AI Suggestion</h3>
              <button
                className="at-drawer__close"
                onClick={() => {
                  setDrawer(null);
                  setAiRec(null);
                }}
                aria-label="Close"
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <AddSuiteForm
              agentId={agentId}
              source="ai"
              prefill={{
                name: aiRec.suggested_name,
                test_cases: aiRec.test_cases,
              }}
              onSaved={async () => {
                setDrawer(null);
                setAiRec(null);
                await load();
              }}
              onCancel={() => {
                setDrawer(null);
                setAiRec(null);
              }}
            />
          </div>
        </div>
      )}
      {drawer === "policies" && data && (
        <ManagePoliciesDrawer
          agentId={agentId}
          assignedPolicies={data.policies ?? []}
          onClose={() => setDrawer(null)}
          onChanged={async () => {
            await load();
          }}
        />
      )}
      {drawer === "security" && data?.security && (
        <SecurityDrawer
          probes={data.security.probes ?? []}
          onClose={() => setDrawer(null)}
        />
      )}
    </div>
  );
}

// ─── 4. Agent detail: Timeline sub-tab ────────────────────────────────────────

const TIMELINE_EVENT_ICON: Record<string, string> = {
  "agent.created": "🟢",
  "agent.updated": "✏️",
  "agent.reviewed": "🔍",
  "connector.added": "🔌",
  "connector.removed": "🔌",
  "suite.added": "🧪",
  "suite.removed": "🧪",
  "policy.assigned": "📋",
  "policy.removed": "📋",
  "security.scan": "🛡️",
  "trust.score.changed": "📊",
  "agent.run": "▶️",
};

function TimelineTab({ agentId }: { agentId: string }) {
  const [items, setItems] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nextCursor, setNextCursor] = useState<number | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchTimeline(agentId, { limit: 50 })
      .then((res) => {
        setItems(res.entries);
        setNextCursor(res.next_cursor);
      })
      .catch((err) =>
        setError(extractApiError(err, "Failed to load timeline.")),
      )
      .finally(() => setLoading(false));
  }, [agentId]);

  const loadMore = async () => {
    if (!nextCursor) return;
    setLoadingMore(true);
    try {
      const res = await fetchTimeline(agentId, {
        cursor: nextCursor,
        limit: 50,
      });
      setItems((prev) => [...prev, ...res.entries]);
      setNextCursor(res.next_cursor);
    } catch (err) {
      setError(extractApiError(err, "Failed to load more events."));
    } finally {
      setLoadingMore(false);
    }
  };

  const toggleExpanded = (seq: number) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(seq) ? next.delete(seq) : next.add(seq);
      return next;
    });

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  if (items.length === 0) {
    return (
      <EmptyCard
        title="No timeline events yet."
        desc="Events will appear here as the agent is used, reviewed, and updated."
      />
    );
  }

  return (
    <div className="at-subtab-content">
      <div className="at-timeline">
        {items.map((ev) => {
          const isExpanded = expanded.has(ev.seq);
          const hasDetails = ev.details && Object.keys(ev.details).length > 0;
          return (
            <div key={ev.seq} className="at-timeline-item">
              <span className="at-timeline-icon" aria-hidden="true">
                {TIMELINE_EVENT_ICON[ev.event] ?? "📋"}
              </span>
              <div className="at-timeline-body">
                <span className="at-timeline-type">{ev.title}</span>
                {ev.actor && (
                  <span className="at-timeline-desc">{ev.actor}</span>
                )}
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    alignItems: "center",
                    flexWrap: "wrap",
                    marginTop: 2,
                  }}
                >
                  <span className="at-timeline-ts">{fmtDate(ev.at)}</span>
                  {ev.outcome && (
                    <span
                      className={`at-badge ${ev.outcome === "success" ? "at-badge--trusted" : "at-badge--risk"}`}
                      style={{ fontSize: "0.65rem", padding: "1px 6px" }}
                    >
                      {ev.outcome}
                    </span>
                  )}
                  {ev.severity && (
                    <span
                      className="at-badge at-badge--warn"
                      style={{ fontSize: "0.65rem", padding: "1px 6px" }}
                    >
                      {ev.severity}
                    </span>
                  )}
                  {hasDetails && (
                    <button
                      className="at-timeline-expand-btn"
                      onClick={() => toggleExpanded(ev.seq)}
                    >
                      {isExpanded ? "Hide details" : "Show details"}
                    </button>
                  )}
                </div>
                {isExpanded && hasDetails && (
                  <pre
                    className="at-code-block"
                    style={{ marginTop: 8, fontSize: "0.72rem" }}
                  >
                    {JSON.stringify(ev.details, null, 2)}
                  </pre>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {nextCursor && (
        <div
          style={{ display: "flex", justifyContent: "center", marginTop: 16 }}
        >
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            disabled={loadingMore}
            onClick={loadMore}
          >
            {loadingMore ? (
              <>
                <span className="at-spinner at-spinner--sm" /> Loading…
              </>
            ) : (
              "Load older events"
            )}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── 5. Agent detail: Usage sub-tab ───────────────────────────────────────────

function UsageTab({ agentId }: { agentId: string }) {
  const [data, setData] = useState<AgentUsage | null>(null);
  const [window, setWindow] = useState<UsageWindow>("30d");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (w: UsageWindow) => {
      setLoading(true);
      setError(null);
      try {
        setData(await fetchUsage(agentId, w));
      } catch (err) {
        setError(extractApiError(err, "Failed to load usage data."));
      } finally {
        setLoading(false);
      }
    },
    [agentId],
  );

  useEffect(() => {
    load(window);
  }, [load, window]);

  return (
    <div className="at-subtab-content">
      <div className="at-section-hdr">
        <SectionHeader
          title="Usage"
          tooltip="Token, run and cost information collected from agent telemetry."
        />
        <div className="at-window-selector">
          {(["24h", "7d", "30d", "all"] as UsageWindow[]).map((w) => (
            <button
              key={w}
              className={`at-window-btn${window === w ? " at-window-btn--active" : ""}`}
              onClick={() => setWindow(w)}
            >
              {w === "all" ? "All" : w}
            </button>
          ))}
        </div>
      </div>

      {loading && <Loader />}
      {error && <ErrorBanner message={error} />}

      {!loading && !error && data && (
        <>
          <div className="at-stat-grid">
            <StatCard
              label="Runs"
              value={fmtNum(data.total_runs)}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="5 3 19 12 5 21 5 3" />
                </svg>
              }
            />
            <StatCard label="Input Tokens" value={fmtNum(data.input_tokens)} />
            <StatCard
              label="Output Tokens"
              value={fmtNum(data.output_tokens)}
            />
            <StatCard
              label="Total Tokens"
              value={fmtNum(data.total_tokens)}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
              }
            />
            <StatCard
              label="Cost"
              value={fmtCost(data.total_cost_usd)}
              sub={data.cost_is_estimated ? "Estimated" : undefined}
              accent={data.cost_is_estimated ? "#d97706" : undefined}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="12" y1="1" x2="12" y2="23" />
                  <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                </svg>
              }
            />
            <StatCard label="Last Used" value={fmtDate(data.last_used_at)} />
          </div>
          {data.cost_is_estimated && (
            <p className="at-desc">
              Cost is estimated — calculated from available telemetry and
              pricing information. An exact cost record was not available.
            </p>
          )}
        </>
      )}

      {!loading && !error && !data && (
        <EmptyCard
          title="No usage data."
          desc="Usage information will appear here once this agent has been run."
        />
      )}
    </div>
  );
}

// ─── Agent Detail container ────────────────────────────────────────────────────

function AgentDetailView({
  agent,
  onBack,
}: {
  agent: AgentListItem;
  onBack: () => void;
}) {
  const [tab, setTab] = useState<DetailTab>("overview");

  return (
    <div className="at-tab-content">
      {/* Back + agent header */}
      <div className="at-detail-breadcrumb">
        <button className="at-btn at-btn--ghost at-btn--sm" onClick={onBack}>
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          All Agents
        </button>
        <span className="at-breadcrumb-sep">/</span>
        <span className="at-breadcrumb-name">{agent.name}</span>
      </div>

      <div className="at-detail-agent-hdr">
        <div className="at-detail-agent-hdr__left">
          <div className="at-detail-agent-hdr__name">{agent.name}</div>
          <div
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <span className={trustStateBadgeClass(agent.trust_state)}>
              {trustStateLabel(agent.trust_state)}
            </span>
            <ScoreBar score={agent.trust_score} />
            {agent.stale && <span className="at-stale-chip">Stale</span>}
          </div>
        </div>
      </div>

      {/* Sub-tabs */}
      <nav
        className="at-subtabs"
        role="tablist"
        aria-label="Agent detail sections"
      >
        {DETAIL_TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={`at-subtab${tab === t.id ? " at-subtab--active" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="at-subtab-panel" role="tabpanel">
        {tab === "overview" && <OverviewTab agent={agent} />}
        {tab === "review" && <ReviewTab agentId={agent.agent_id} />}
        {tab === "timeline" && <TimelineTab agentId={agent.agent_id} />}
        {tab === "usage" && <UsageTab agentId={agent.agent_id} />}
      </div>
    </div>
  );
}

// ─── Access denied ─────────────────────────────────────────────────────────────

function AccessDenied() {
  return (
    <div className="at-access-denied">
      <div className="at-access-denied__icon" aria-hidden="true">
        <svg
          width="28"
          height="28"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
        </svg>
      </div>
      <h2 className="at-access-denied__title">Access Restricted</h2>
      <p className="at-access-denied__desc">
        Agent Trust is only available to <strong>Admins</strong> and{" "}
        <strong>Super Admins</strong>. Contact your administrator if you need
        access.
      </p>
    </div>
  );
}

// ─── Root component ────────────────────────────────────────────────────────────

export function AgentTrustLegacy() {
  const { user } = useAuth();
  const [topTab, setTopTab] = useState<TopTab>("dashboard");
  const [selectedAgent, setSelectedAgent] = useState<AgentListItem | null>(
    null,
  );

  if (
    user?.role !== AUTH_ROLES.ADMIN &&
    user?.role !== AUTH_ROLES.SUPER_ADMIN
  ) {
    return <AccessDenied />;
  }

  const handleSelectAgent = (agent: AgentListItem) => {
    setSelectedAgent(agent);
    setTopTab("agent-detail");
  };

  const handleViewAgentById = (agentId: string) => {
    // Navigate to agent detail using id only — overview will fetch full data
    setSelectedAgent({ agent_id: agentId } as AgentListItem);
    setTopTab("agent-detail");
  };

  const handleBackToAgents = () => {
    setTopTab("agents");
    setSelectedAgent(null);
  };

  return (
    <div className="at-root">
      {/* Header */}
      <div className="at-header">
        <div className="at-header__inner">
          <div className="at-header__title-row">
            <div className="at-header__icon-wrap" aria-hidden="true">
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              </svg>
            </div>
            <h1 className="at-header__title">Agent Health Center</h1>
          </div>
          <p className="at-header__desc">
            Trust scores, checks, testing, policies and usage — all in one place
            for every agent.
          </p>
        </div>
      </div>

      {/* Top nav — hide when in agent detail (breadcrumb handles navigation) */}
      {topTab !== "agent-detail" && (
        <nav
          className="at-tabs"
          role="tablist"
          aria-label="Agent Health Center sections"
        >
          {(["dashboard", "agents"] as TopTab[]).map((t) => (
            <button
              key={t}
              role="tab"
              aria-selected={topTab === t}
              className={`at-tab${topTab === t ? " at-tab--active" : ""}`}
              onClick={() => setTopTab(t)}
            >
              <span
                style={{ display: "inline-flex", alignItems: "center", gap: 6 }}
              >
                {t === "dashboard" && (
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="3" y="3" width="7" height="7" />
                    <rect x="14" y="3" width="7" height="7" />
                    <rect x="14" y="14" width="7" height="7" />
                    <rect x="3" y="14" width="7" height="7" />
                  </svg>
                )}
                {t === "agents" && (
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                )}
                {t === "dashboard" ? "Dashboard" : "Agents"}
              </span>
            </button>
          ))}
        </nav>
      )}

      {/* Tab panels */}
      <div className="at-body" role="tabpanel">
        {topTab === "dashboard" && (
          <DashboardTab onViewAgent={handleViewAgentById} />
        )}
        {topTab === "agents" && <AgentsTab onSelectAgent={handleSelectAgent} />}
        {topTab === "agent-detail" && selectedAgent && (
          <AgentDetailView agent={selectedAgent} onBack={handleBackToAgents} />
        )}
      </div>
    </div>
  );
}

// ─── Agent Health Center demo UI, wired to the real Agent Trust API ─────────────
type DemoPage = "agents" | "health" | "finding";
type DemoHealthTab =
  | "Summary"
  | "Findings"
  | "Checks & evidence"
  | "Usage & cost"
  | "Timeline"
  | "Review workspace";

type DemoFinding = {
  id: string;
  agentId: string;
  title: string;
  category: string;
  status: string;
  severity: string;
  observed: string;
  expected: string;
  why: string;
  fix: string;
  verify: string;
  evidence: string;
  tokens: string;
  cost: string;
  sourceKey: string;
};

function demoInitials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("") || "AG";
}

function demoDate(value: string | null | undefined): string {
  if (!value) return "Never";
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
}

function demoNumber(value: number | null | undefined): string {
  return value == null ? "—" : value.toLocaleString();
}

function demoMoney(value: number | null | undefined): string {
  return value == null ? "—" : `$${value.toFixed(2)}`;
}

function demoStateLabel(value: string | null | undefined): string {
  return (value ?? "UNREVIEWED").replace(/_/g, " ");
}

function demoPillClass(value: string): string {
  const normalized = value.toLowerCase();
  if (normalized.includes("pass") || normalized.includes("trusted") || normalized === "healthy" || normalized === "completed" || normalized === "reviewed") return "success";
  if (normalized.includes("fail") || normalized.includes("risk") || normalized.includes("attention") || normalized.includes("needs review")) return "warning";
  if (normalized.includes("not reviewed") || normalized.includes("unreviewed") || normalized.includes("not verified") || normalized.includes("not_configured")) return "muted";
  if (normalized.includes("running") || normalized.includes("started") || normalized.includes("progress")) return "info";
  return "neutral";
}

function demoDetailText(detail: Record<string, unknown> | undefined, keys: string[], fallback: string): string {
  if (!detail) return fallback;
  for (const key of keys) {
    const value = detail[key];
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return fallback;
}

function buildDemoFindings(agentId: string, data: AgentReviewData | null): DemoFinding[] {
  if (!data) return [];
  const findings: DemoFinding[] = [];
  const seen = new Set<string>();
  for (const check of data.checks ?? []) {
    if (!["fail", "partial", "not_verified"].includes(String(check.status))) continue;
    const key = `check:${check.key}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const detail = check.detail ?? {};
    findings.push({
      id: key,
      sourceKey: check.key,
      agentId,
      title: check.label,
      category: demoDetailText(detail, ["category", "check_type"], check.key.replace(/[_-]/g, " ")),
      status: check.status.replace(/_/g, " "),
      severity: demoDetailText(detail, ["severity", "impact"], "Not rated"),
      observed: check.summary || "The backend did not return an observation for this check.",
      expected: demoDetailText(detail, ["expected_behavior", "expected", "expected_result"], "Expected behavior was not included in the available review response."),
      why: demoDetailText(detail, ["why_it_matters", "impact_description", "rationale"], check.summary || "Impact details were not included in the available review response."),
      fix: check.fix || demoDetailText(detail, ["recommended_fix", "recommendation", "action"], "No recommended change was returned by the backend."),
      verify: demoDetailText(detail, ["verification_steps", "verify", "how_to_verify"], "Rerun this check after making the change and inspect the resulting evidence."),
      evidence: demoDetailText(detail, ["evidence", "trace_id", "test_case_id", "source"], "No trace or evidence reference was returned by the backend."),
      tokens: demoDetailText(detail, ["tokens_used", "total_tokens"], "Not available"),
      cost: demoDetailText(detail, ["cost_usd", "estimated_cost_usd"], "Not available"),
    });
  }
  for (const improvement of data.improvements ?? []) {
    const key = `improvement:${improvement.key}`;
    if (seen.has(key)) continue;
    seen.add(key);
    findings.push({
      id: key,
      sourceKey: improvement.key,
      agentId,
      title: improvement.label,
      category: improvement.key.replace(/[_-]/g, " "),
      status: "Potential improvement",
      severity: "Not rated",
      observed: improvement.reason || "The backend recommended reviewing this area.",
      expected: "The target behavior was not separately returned by the backend.",
      why: improvement.reason || "No additional impact description was returned.",
      fix: improvement.action || "No recommended action was returned by the backend.",
      verify: "Rerun the relevant review check and confirm the new result using the returned evidence.",
      evidence: "No trace reference was included with this recommendation.",
      tokens: "Not available",
      cost: "Not available",
    });
  }
  return findings;
}

function DemoStatusPill({ status }: { status: string }) {
  return <span className={`pill ${demoPillClass(status)}`}><i />{status}</span>;
}

function DemoScoreRing({ score, size = 56 }: { score: number | null | undefined; size?: number }) {
  const normalized = score == null ? 0 : Math.max(0, Math.min(100, score));
  const color = score == null ? "#b7bdc8" : normalized >= 85 ? "#249a72" : normalized >= 70 ? "#d49a36" : "#d65d5d";
  const ringStyle = { width: size, height: size, "--score": `${normalized}%`, "--score-color": color } as React.CSSProperties;
  return <div className="score-ring" style={ringStyle}><div><strong>{score == null ? "—" : Math.round(score)}</strong>{score != null && <small>/100</small>}</div></div>;
}

function DemoIconBox({ children, tone = "neutral", size = "md" }: { children: React.ReactNode; tone?: string; size?: string }) {
  return <span className={`icon-box ${tone} ${size}`}>{children}</span>;
}

export function AgentTrust() {
  const { user } = useAuth();
  const [page, setPage] = useState<DemoPage>("agents");
  const [agents, setAgents] = useState<AgentListItem[]>([]);
  const [dashboard, setDashboard] = useState<DashboardResponse | null>(null);
  const [selectedAgent, setSelectedAgent] = useState<AgentListItem | null>(null);
  const [overview, setOverview] = useState<AgentOverview | null>(null);
  const [reviewData, setReviewData] = useState<AgentReviewData | null>(null);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [usage, setUsage] = useState<AgentUsage | null>(null);
  const [healthTab, setHealthTab] = useState<DemoHealthTab>("Summary");
  const [selectedFindingId, setSelectedFindingId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All agents");
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [loadingAgents, setLoadingAgents] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [busyReview, setBusyReview] = useState(false);
  const [checkingProgress, setCheckingProgress] = useState(false);
  const [correlationId, setCorrelationId] = useState<string | null>(null);
  const [reviewStatus, setReviewStatus] = useState<string | null>(null);
  const [reviewProgress, setReviewProgress] = useState<string | null>(null);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const permitted = user?.role === AUTH_ROLES.ADMIN || user?.role === AUTH_ROLES.SUPER_ADMIN;
  const findings = useMemo(() => buildDemoFindings(selectedAgent?.agent_id ?? "", reviewData), [selectedAgent?.agent_id, reviewData]);
  const selectedFinding = findings.find((item) => item.id === selectedFindingId) ?? null;
  const visibleAgents = useMemo(() => agents.filter((agent) => {
    const matchesQuery = `${agent.name} ${agent.environment ?? ""} ${agent.owner?.name ?? ""}`.toLowerCase().includes(query.toLowerCase());
    const state = demoStateLabel(agent.trust_state).toLowerCase();
    const matchesFilter = filter === "All agents" || (filter === "Needs attention" && (state.includes("review") || state.includes("risk"))) || (filter === "Healthy" && state === "trusted") || (filter === "Not reviewed" && state === "unreviewed");
    return matchesQuery && matchesFilter;
  }), [agents, query, filter]);

  const notify = useCallback((message: string) => {
    setToast(message);
  }, []);

  const loadAgents = useCallback(async () => {
    setLoadingAgents(true);
    setError(null);
    try {
      const [agentResult, dashboardResult] = await Promise.allSettled([
        fetchAgents({ scope: "all", limit: 100, offset: 0 }),
        fetchDashboard("all"),
      ] as const);
      if (agentResult.status === "fulfilled") setAgents(agentResult.value.items ?? []);
      else throw agentResult.reason;
      if (dashboardResult.status === "fulfilled") setDashboard(dashboardResult.value);
    } catch (err) {
      setError(extractApiError(err, "Unable to load Agent Trust agents."));
    } finally {
      setLoadingAgents(false);
    }
  }, []);

  const loadAgentDetails = useCallback(async (agentId: string) => {
    setLoadingDetail(true);
    setError(null);
    const [overviewResult, reviewResult, timelineResult, usageResult] = await Promise.allSettled([
      fetchAgentOverview(agentId),
      fetchAgentReview(agentId),
      fetchTimeline(agentId, { limit: 50 }),
      fetchUsage(agentId, "30d"),
    ] as const);
    if (overviewResult.status === "fulfilled") setOverview(overviewResult.value);
    else setError(extractApiError(overviewResult.reason, "Unable to load the agent overview."));
    if (reviewResult.status === "fulfilled") setReviewData(reviewResult.value);
    else setReviewData(null);
    if (timelineResult.status === "fulfilled") setTimeline(timelineResult.value.entries ?? []);
    else setTimeline([]);
    if (usageResult.status === "fulfilled") setUsage(usageResult.value);
    else setUsage(null);
    setLoadingDetail(false);
  }, []);

  useEffect(() => {
    if (permitted) void loadAgents();
  }, [permitted, loadAgents]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 3500);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const openAgent = (agent: AgentListItem) => {
    setSelectedAgent(agent);
    setOverview(null);
    setReviewData(null);
    setTimeline([]);
    setUsage(null);
    setPage("health");
    setHealthTab("Summary");
    setShowHistory(false);
    setCorrelationId(null);
    setReviewStatus(null);
    setReviewProgress(null);
    setReviewError(null);
    setSelectedFindingId(null);
    void loadAgentDetails(agent.agent_id);
  };

  const backToAgents = () => {
    setPage("agents");
    setSelectedAgent(null);
    setOverview(null);
    setReviewData(null);
    setTimeline([]);
    setUsage(null);
    setSelectedFindingId(null);
  };

  const refreshCurrentAgent = async () => {
    if (!selectedAgent) return;
    await Promise.all([loadAgentDetails(selectedAgent.agent_id), loadAgents()]);
  };

  const startReviewNow = async () => {
    if (!selectedAgent || busyReview) return;
    setBusyReview(true);
    setReviewError(null);
    setReviewProgress("Review request is being submitted to the backend.");
    try {
      const result = await runReview([selectedAgent.agent_id]);
      setCorrelationId(result.correlation_id);
      setReviewStatus(result.status ?? "started");
      setReviewProgress("Review accepted by the backend. Use Check Progress to retrieve the latest status.");
      notify(`Review started for ${selectedAgent.name}.`);
    } catch (err) {
      setReviewError(extractApiError(err, "Could not start the review."));
      setReviewProgress(null);
    } finally {
      setBusyReview(false);
    }
  };

  const checkReviewProgress = async () => {
    if (!correlationId || checkingProgress) return;
    setCheckingProgress(true);
    setReviewError(null);
    try {
      const status = await fetchReviewRunStatus(correlationId);
      setReviewStatus(status.status);
      setReviewProgress(status.latest_progress?.message ?? status.latest_progress?.stage ?? `Latest status: ${status.status}`);
      if (status.error) setReviewError(status.error);
      if (status.status === "completed" || status.status === "failed") {
        await Promise.all([loadAgentDetails(selectedAgent!.agent_id), loadAgents()]);
        if (status.status === "completed") notify("Review completed. Agent Trust data has been refreshed.");
      }
    } catch (err) {
      setReviewError(extractApiError(err, "Could not retrieve review progress. The review may still be running."));
    } finally {
      setCheckingProgress(false);
    }
  };

  const openFinding = (finding: DemoFinding) => {
    setSelectedFindingId(finding.id);
    setPage("finding");
  };

  if (!permitted) return <AccessDenied />;

  const totalRuns = agents.reduce((sum, agent) => sum + (agent.total_runs ?? 0), 0);
  const totalTokens = agents.reduce((sum, agent) => sum + (agent.total_tokens ?? 0), 0);
  const totalCost = agents.reduce((sum, agent) => sum + (agent.total_cost_usd ?? 0), 0);
  const trustedCount = agents.filter((agent) => agent.trust_state === "TRUSTED").length;
  const needsAttentionCount = agents.filter((agent) => agent.trust_state === "NEEDS_REVIEW" || agent.trust_state === "HIGH_RISK").length;
  const activeAgent = selectedAgent;

  return (
    <div className="at-demo">
      <div className="app-shell">
        <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
          <div className="brand">
            <div className="brand-mark"><Command size={19} /></div>
            {!collapsed && <div><strong>EchoAI</strong><span>AGENT PLATFORM</span></div>}
            <button className="icon-button collapse-btn" onClick={() => setCollapsed(!collapsed)} title="Collapse sidebar" aria-label="Collapse sidebar">
              {collapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}
            </button>
          </div>
          {!collapsed && <div className="workspace"><div className="workspace-avatar">E</div><div><strong>EchoAI Workspace</strong><small>Agent Trust</small></div><ChevronDown size={15} /></div>}
          <div className="nav-caption">WORKSPACE</div>
          <nav aria-label="Agent Trust navigation">
            <button className={`nav-item ${page === "agents" ? "active" : ""}`} onClick={backToAgents} title={collapsed ? "Agents" : undefined}><DemoBot size={18} />{!collapsed && <span>Agents</span>}</button>
            <button className={`nav-item ${page === "health" ? "active" : ""}`} disabled={!activeAgent} onClick={() => setPage("health")} title={collapsed ? "Agent health" : undefined}><DemoActivity size={18} />{!collapsed && <span>Agent health</span>}</button>
            <button className={`nav-item ${page === "finding" ? "active" : ""}`} disabled={!selectedFinding} onClick={() => setPage("finding")} title={collapsed ? "Finding detail" : undefined}><Search size={18} />{!collapsed && <><span>Finding detail</span>{findings.length > 0 && <span className="nav-count">{findings.length}</span>}</>}</button>
          </nav>
          {!collapsed && <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><Sparkles size={16} /></div><strong>Health, without the busywork.</strong><p>Review an agent when you are ready. Agent Trust gathers available evidence and highlights what matters.</p><button onClick={() => notify("Reviews use the real Agent Trust backend. Unknown evidence is not treated as a pass.")}>How reviews work <ArrowRight size={13} /></button></div><div className="user-row"><div className="user-avatar">{demoInitials(user?.display_name ?? "Workspace Admin")}</div><div><strong>{user?.display_name ?? "Workspace admin"}</strong><small>Workspace access</small></div><MoreHorizontal size={18} /></div></div>}
        </aside>

        <main className="main-area">
          <header className="topbar">
            <div className="breadcrumbs"><span>EchoAI</span><ChevronRight size={14} /><strong>{page === "agents" ? "Agents" : page === "health" ? "Agent health" : "Finding detail"}</strong>{page !== "agents" && <><ChevronRight size={14} /><span>{page === "health" ? activeAgent?.name : selectedFinding?.title}</span></>}</div>
            <div className="top-actions"><button className="search-shortcut" onClick={() => setSearchOpen(!searchOpen)}><Search size={15} /><span>Search</span><kbd>⌘ K</kbd></button><span className="top-divider" /><button className="icon-button" title="Help" onClick={() => notify("Select an agent to inspect its review evidence and recommendations.")}><CircleHelp size={18} /></button><button className="icon-button notification" title="Refresh" onClick={() => void (page === "agents" ? loadAgents() : refreshCurrentAgent())}><RefreshCw size={17} /></button><div className="user-avatar small">{demoInitials(user?.display_name ?? "Admin")}</div></div>
          </header>
          {searchOpen && <div className="global-search"><Search size={17} /><input autoFocus placeholder="Search agents…" value={query} onChange={(event) => { setQuery(event.target.value); setPage("agents"); }} /><button onClick={() => { setSearchOpen(false); setQuery(""); }} aria-label="Close search"><X size={16} /></button><span>ESC</span></div>}

          <div className="page-content">
            {page === "agents" && <>
              <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-dot" /> AGENT HEALTH CENTER</div><h1>Your agents, at a glance.</h1><p>Know what is working, what needs attention, and what to improve next.</p></div><button className="primary-btn" disabled={!agents.length} onClick={() => agents[0] && openAgent(agents[0])}><DemoActivity size={16} /> Agent health overview</button></div>
              <div className="metric-grid">
                <div className="metric-card"><div className="metric-top"><span>Total agents</span><DemoIconBox><DemoBot size={17} /></DemoIconBox></div><div className="metric-value">{loadingAgents ? "…" : dashboard?.total_agents ?? agents.length}</div><div className="metric-foot">Agents available in your workspace scope</div></div>
                <div className="metric-card"><div className="metric-top"><span>Trusted agents</span><DemoIconBox tone="green"><ShieldCheck size={17} /></DemoIconBox></div><div className="metric-value">{trustedCount}<span className="metric-trend positive">{agents.length ? `${Math.round((trustedCount / agents.length) * 100)}% of listed agents` : "No agents"}</span></div><div className="mini-bar"><i style={{ width: `${agents.length ? (trustedCount / agents.length) * 100 : 0}%` }} /></div></div>
                <div className="metric-card"><div className="metric-top"><span>Need attention</span><DemoIconBox tone="amber"><AlertTriangle size={17} /></DemoIconBox></div><div className="metric-value">{needsAttentionCount}<span className="metric-trend negative"><ArrowDownRight size={14} /> Review recommended</span></div><div className="metric-foot">Based on current backend trust states</div></div>
                <div className="metric-card"><div className="metric-top"><span>Agent usage · 30 days</span><DemoIconBox tone="blue"><Coins size={17} /></DemoIconBox></div><div className="metric-value">{demoMoney(totalCost)}<span className="metric-trend neutral">Tracked model cost</span></div><div className="metric-foot">{demoNumber(totalRuns)} runs · {demoNumber(totalTokens)} tokens</div></div>
              </div>
              <div className="section-title-row"><div><h2>All agents <span className="count-bubble">{agents.length}</span></h2><p>Open an agent to inspect its current health and evidence.</p></div><button className="secondary-btn" onClick={() => void loadAgents()}><RefreshCw size={15} /> Refresh agents</button></div>
              <div className="toolbar"><div className="table-search"><Search size={16} /><input placeholder="Search agents…" value={query} onChange={(event) => setQuery(event.target.value)} />{query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={14} /></button>}</div><div className="toolbar-right"><select value={filter} onChange={(event) => setFilter(event.target.value)}><option>All agents</option><option>Needs attention</option><option>Healthy</option><option>Not reviewed</option></select></div></div>
              {error && <div className="at-demo-error"><AlertCircle size={16} />{error}</div>}
              <div className="agent-table"><div className="table-head"><span>AGENT</span><span>HEALTH</span><span>LAST REVIEW</span><span>ENVIRONMENT</span><span>30-DAY USAGE</span><span /></div>
                {visibleAgents.map((agent) => <div className="agent-row" key={agent.agent_id} onClick={() => openAgent(agent)} role="button" tabIndex={0} onKeyDown={(event) => event.key === "Enter" && openAgent(agent)}><div className="agent-identity"><div className={`agent-avatar ${agent.trust_state === "TRUSTED" ? "green" : agent.trust_state === "HIGH_RISK" ? "rose" : agent.trust_state === "UNREVIEWED" ? "blue" : "violet"}`}>{demoInitials(agent.name)}</div><div><strong>{agent.name}</strong><small>{agent.environment || agent.owner?.name || "Agent"}</small></div></div><div className="health-cell"><DemoScoreRing score={agent.trust_state === "UNREVIEWED" ? null : agent.trust_score} size={42} /><div><DemoStatusPill status={demoStateLabel(agent.trust_state)} /><small>{agent.stale ? "Review may be stale" : agent.trust_state === "UNREVIEWED" ? "Run first review" : "Current review state"}</small></div></div><div className="last-review"><span>{demoDate(agent.last_reviewed_at)}</span><small>{agent.last_reviewed_at ? "Latest completed review" : "No completed review"}</small></div><div className="model-cell"><span className="model-dot" />{agent.environment || "Environment not set"}</div><div className="cost-cell"><strong>{demoMoney(agent.total_cost_usd)}</strong><small>{demoNumber(agent.total_tokens)} tokens · {demoNumber(agent.total_runs)} runs</small></div><button className="row-arrow" onClick={(event) => { event.stopPropagation(); openAgent(agent); }} aria-label={`Open ${agent.name}`}><ChevronRight size={18} /></button></div>)}
                {!loadingAgents && visibleAgents.length === 0 && <div className="empty-state"><Search size={25} /><strong>{error ? "Agent list unavailable" : "No agents found"}</strong><span>{error ? "Check the API connection and refresh." : "Try another search or filter."}</span></div>}
                {loadingAgents && <div className="empty-state"><RefreshCw size={20} className="spin" /><strong>Loading agents…</strong><span>Fetching the current Agent Trust data.</span></div>}
              </div>
              <div className="table-footer"><span>Showing <strong>{visibleAgents.length}</strong> of {agents.length} agents</span><span><span className="live-dot" /> Live backend data <RefreshCw size={12} /></span></div>
              <div className="bottom-insight"><div className="insight-icon"><Sparkles size={18} /></div><div><strong>Reviews are on your terms.</strong><p>Reviewing uses model tokens and runtime resources. Nothing runs until you choose to review an agent.</p></div><button className="text-btn" onClick={() => agents[0] && openAgent(agents[0])}>Review an agent <ArrowRight size={15} /></button></div>
            </>}

            {page === "health" && activeAgent && <>
              <button className="back-link" onClick={backToAgents}><ArrowLeft size={15} /> All agents</button>
              <div className="health-header"><div className={`agent-avatar large ${activeAgent.trust_state === "TRUSTED" ? "green" : "violet"}`}>{demoInitials(activeAgent.name)}</div><div className="health-title"><div className="title-line"><h1>{activeAgent.name}</h1><DemoStatusPill status={demoStateLabel(overview?.trust_state ?? activeAgent.trust_state)} /></div><p>{overview?.description || "Agent health, review evidence, recommendations and usage."}</p><div className="agent-meta"><span><DemoBot size={14} />{overview?.owner?.name || activeAgent.owner?.name || "Agent owner not available"}</span><span><Zap size={14} />{overview?.environment || activeAgent.environment || "Environment not set"}</span><span><Clock3 size={14} />{overview?.last_reviewed_at ? `Reviewed ${demoDate(overview.last_reviewed_at)}` : "No completed review yet"}</span></div></div><div className="health-actions"><button className="secondary-btn" onClick={() => setShowHistory(!showHistory)}><Clock3 size={15} /> History</button><button className="primary-btn" disabled={busyReview} onClick={() => void startReviewNow()}><Play size={15} fill="currentColor" />{busyReview ? "Starting…" : "Review agent"}</button><button className="icon-button bordered" onClick={() => void refreshCurrentAgent()} title="Refresh agent data"><RefreshCw size={17} /></button></div></div>
              <div className="health-tabs">{(["Summary", "Findings", "Checks & evidence", "Usage & cost", "Timeline", "Review workspace"] as DemoHealthTab[]).map((tab) => <button key={tab} className={healthTab === tab ? "active" : ""} onClick={() => setHealthTab(tab)}>{tab}{tab === "Findings" && findings.length > 0 && <span>{findings.length}</span>}</button>)}</div>
              {(correlationId || reviewError) && <div className="history-banner"><DemoActivity size={17} /><div><strong>Review status {reviewStatus ? `· ${reviewStatus}` : ""}</strong><p>{reviewError || reviewProgress || "The review has been submitted."}{correlationId && <><br />Correlation ID: <code>{correlationId}</code></>}</p></div>{correlationId && <button disabled={checkingProgress} onClick={() => void checkReviewProgress()}>{checkingProgress ? <RefreshCw size={14} className="spin" /> : <RefreshCw size={14} />} Check Progress</button>}</div>}
              {showHistory && <div className="history-banner"><Clock3 size={17} /><div><strong>Review history</strong><p>{overview?.last_reviewed_at ? `Latest completed review: ${demoDate(overview.last_reviewed_at)}. Historical detail depends on available timeline records.` : "No completed review is available yet. The first review will establish a baseline."}</p></div><button onClick={() => setShowHistory(false)} aria-label="Close review history"><X size={15} /></button></div>}
              {loadingDetail && <div className="empty-state"><RefreshCw size={20} className="spin" /><strong>Loading agent health…</strong><span>Fetching overview, checks, usage and timeline.</span></div>}
              {!loadingDetail && error && <div className="at-demo-error"><AlertCircle size={16} />{error}</div>}
              {!loadingDetail && healthTab === "Summary" && <>
                <div className="health-overview-grid"><div className="score-card"><div className="card-heading"><div><h3>Overall health</h3><p>Based on the latest available review evidence</p></div><button className="icon-button" title="About trust score" onClick={() => notify("Trust scores are calculated by the backend from available checks. Unverified evidence is not treated as a pass.")}><CircleHelp size={16} /></button></div><div className="score-main"><DemoScoreRing score={overview?.trust_score ?? (activeAgent.trust_state === "UNREVIEWED" ? null : activeAgent.trust_score)} size={104} /><div><h2>{overview?.trust_score == null ? "Not reviewed" : overview.trust_score >= 85 ? "Looking good" : overview.trust_score >= 70 ? "A few things to fix" : "Needs attention"}</h2><p>{overview?.checks?.find((check) => check.status !== "pass")?.summary || overview?.description || "Run a review to establish an evidence-based baseline."}</p><div className="score-change"><span>{overview?.stale ? "Stale" : overview?.last_reviewed_at ? "Current review" : "No review"}</span> · {overview?.last_reviewed_at ? demoDate(overview.last_reviewed_at) : "Awaiting first review"}</div></div></div><div className="score-legend"><span><i className="green-dot" /> Trusted</span><span><i className="amber-dot" /> Needs review</span><span><i className="red-dot" /> High risk</span></div></div>
                  <div className="recommend-card"><div className="recommend-head"><div className="recommend-spark"><Sparkles size={17} /></div><div><h3>What to improve first</h3><p>Recommendations returned by Agent Trust</p></div><span className="ai-label">EVIDENCE-BASED</span></div>{(overview?.improvements ?? reviewData?.improvements ?? []).slice(0, 4).map((item, index) => <button className="recommend-item" key={item.key} onClick={() => { const found = findings.find((f) => f.sourceKey === item.key); if (found) openFinding(found); else setHealthTab("Review workspace"); }}><span className="rank">{String(index + 1).padStart(2, "0")}</span><span className="recommend-copy"><strong>{item.label}</strong><small>{item.reason || item.action || "Open the review workspace for details."}</small></span><span className="impact medium">Recommended</span><ChevronRight size={16} /></button>)}{!(overview?.improvements?.length || reviewData?.improvements?.length) && <div className="empty-inline">No improvement recommendations were returned. Run a review to refresh evidence.</div>}</div></div>
                <div className="section-title-row compact"><div><h2>Evaluation checks</h2><p>Statuses from the backend; unavailable evidence remains unverified.</p></div><button className="text-btn" onClick={() => setHealthTab("Checks & evidence")}>View all checks <ArrowRight size={15} /></button></div>
                <div className="checks-grid">{(overview?.checks ?? reviewData?.checks ?? []).slice(0, 4).map((check) => <div className="check-card" key={check.key} role="button" tabIndex={0} onClick={() => setHealthTab("Checks & evidence")} onKeyDown={(event) => event.key === "Enter" && setHealthTab("Checks & evidence")}><div className="check-card-top"><DemoIconBox tone={check.status === "pass" ? "green" : check.status === "fail" ? "amber" : "neutral"}>{check.status === "pass" ? <ShieldCheck size={17} /> : <AlertTriangle size={17} />}</DemoIconBox><DemoStatusPill status={check.status.replace(/_/g, " ")} /></div><h3>{check.label}</h3><p>{check.summary || "No additional summary was returned."}</p><div className="check-progress"><div><strong>{check.points_possible > 0 ? `${check.points_earned} / ${check.points_possible}` : "—"}</strong><span>Score contribution</span></div><div className="progress-track"><i style={{ width: `${check.points_possible > 0 ? Math.min(100, (check.points_earned / check.points_possible) * 100) : 0}%` }} /></div></div><ChevronRight className="check-arrow" size={16} /></div>)}{!(overview?.checks?.length || reviewData?.checks?.length) && <div className="empty-state"><ListChecks size={22} /><strong>No checks available</strong><span>Run a review to populate check results.</span></div>}</div>
                <div className="health-bottom-grid"><div className="panel"><div className="panel-heading"><div><h3>What is working well</h3><p>Only successful checks are shown as strengths</p></div><DemoIconBox tone="green"><CheckCircle2 size={17} /></DemoIconBox></div>{(overview?.checks ?? reviewData?.checks ?? []).filter((check) => check.status === "pass").slice(0, 3).map((check) => <div className="strength-row" key={check.key}><Check size={15} /><span>{check.label}: {check.summary || "Check passed."}</span></div>)}{!(overview?.checks ?? reviewData?.checks ?? []).some((check) => check.status === "pass") && <p className="panel-body-copy">No passing checks have been returned yet.</p>}</div><div className="panel cost-panel"><div className="panel-heading"><div><h3>Usage & cost</h3><p>Last 30 days · live usage endpoint</p></div><button className="text-btn" onClick={() => setHealthTab("Usage & cost")}>Details <ArrowRight size={14} /></button></div><div className="cost-stat-row"><div><small>Agent usage</small><strong>{demoMoney(usage?.total_cost_usd ?? overview?.usage?.total_cost_usd)}</strong><span>{demoNumber(usage?.total_tokens ?? overview?.usage?.total_tokens)} tokens</span></div><div><small>Agent runs</small><strong>{demoNumber(usage?.total_runs ?? overview?.usage?.total_runs)}</strong><span>Observed executions</span></div></div><div className="cost-note"><CircleHelp size={14} /> Review overhead is separate when correlated review usage is available.</div></div></div>
              </>}
              {!loadingDetail && healthTab === "Findings" && <div className="panel findings-panel"><div className="panel-heading"><div><h3>Findings & recommendations</h3><p>Items are derived from this agent's actual review response.</p></div><span className="evidence-stamp"><ShieldCheck size={15} /> Evidence-first</span></div><div className="finding-list">{findings.map((item) => <button className="finding-row" key={item.id} onClick={() => openFinding(item)}><DemoIconBox tone={item.status.toLowerCase().includes("fail") ? "amber" : "neutral"}><AlertTriangle size={17} /></DemoIconBox><div className="finding-main"><strong>{item.title}</strong><p>{item.category} · {item.status}</p></div><span className={`severity ${item.severity.toLowerCase()}`}>{item.severity}</span><ChevronRight size={17} /></button>)}{findings.length === 0 && <div className="empty-state"><ShieldCheck size={24} /><strong>No findings returned</strong><span>This is not a claim that all checks passed. Run a review or inspect the available check statuses.</span></div>}</div></div>}
              {!loadingDetail && healthTab === "Checks & evidence" && <div className="panel evidence-panel"><div className="panel-heading"><div><h3>Checks & evidence</h3><p>Results and evidence returned by the backend.</p></div><span className="evidence-stamp"><ShieldCheck size={15} /> Evidence-first</span></div>{(reviewData?.checks ?? []).map((check) => <div className="evidence-check" key={check.key}><div className="evidence-check-head"><DemoIconBox tone={check.status === "pass" ? "green" : "amber"}>{check.status === "pass" ? <CheckCircle2 size={17} /> : <AlertTriangle size={17} />}</DemoIconBox><div className="evidence-check-title"><strong>{check.label}</strong><small>{check.summary || "No summary returned."}</small></div><DemoStatusPill status={check.status.replace(/_/g, " ")} /><ChevronDown size={15} /></div><div className="evidence-detail"><p>{check.fix || "No fix guidance returned for this check."}</p>{findings.find((item) => item.sourceKey === check.key) && <button className="text-btn" onClick={() => openFinding(findings.find((item) => item.sourceKey === check.key)!)}>Open finding detail <ArrowRight size={14} /></button>}</div></div>)}{!reviewData?.checks?.length && <div className="empty-state"><Database size={22} /><strong>No check evidence</strong><span>The review endpoint has not returned check results for this agent.</span></div>}<div className="evidence-check"><div className="evidence-check-head"><DemoIconBox tone="blue"><ShieldAlert size={17} /></DemoIconBox><div className="evidence-check-title"><strong>Security checks</strong><small>{reviewData?.security ? `${reviewData.security.blocked} of ${reviewData.security.total_probes} probes blocked` : "No security summary returned."}</small></div><DemoStatusPill status={reviewData?.security?.total_probes ? "Available" : "Not verified"} /></div></div><div className="evidence-check"><div className="evidence-check-head"><DemoIconBox tone="blue"><Fingerprint size={17} /></DemoIconBox><div className="evidence-check-title"><strong>Identity & connectors</strong><small>{reviewData?.credentials ? `${reviewData.credentials.declared.length} declared connectors/credentials · ${reviewData.credentials.drift.length} drift items` : "No identity summary returned."}</small></div><DemoStatusPill status={reviewData?.credentials ? "Available" : "Not verified"} /></div></div></div>}
              {!loadingDetail && healthTab === "Usage & cost" && <div className="usage-layout"><div className="metric-grid usage-metrics"><div className="metric-card"><div className="metric-top"><span>Agent usage cost</span><DemoIconBox tone="blue"><CircleDollarSign size={17} /></DemoIconBox></div><div className="metric-value">{demoMoney(usage?.total_cost_usd)}</div><div className="metric-foot">{usage?.cost_is_estimated ? "Estimated from available telemetry" : "Reported by usage endpoint"}</div></div><div className="metric-card"><div className="metric-top"><span>Total runs</span><DemoIconBox><DemoActivity size={17} /></DemoIconBox></div><div className="metric-value">{demoNumber(usage?.total_runs)}</div><div className="metric-foot">Selected window: {usage?.window ?? "30d"}</div></div><div className="metric-card"><div className="metric-top"><span>Total tokens</span><DemoIconBox tone="amber"><Zap size={17} /></DemoIconBox></div><div className="metric-value">{demoNumber(usage?.total_tokens)}</div><div className="metric-foot">Input + output tokens</div></div><div className="metric-card"><div className="metric-top"><span>Last used</span><DemoIconBox tone="green"><Clock3 size={17} /></DemoIconBox></div><div className="metric-value" style={{ fontSize: "1.25rem" }}>{demoDate(usage?.last_used_at)}</div><div className="metric-foot">From usage telemetry</div></div></div><div className="panel"><div className="panel-heading"><div><h3>Usage attribution</h3><p>Review costs are shown separately only when review-specific usage is returned.</p></div></div><div className="attribution-grid"><div><span className="legend-dot agent" />Agent executions<strong>{demoMoney(usage?.total_cost_usd)}</strong></div><div><span className="legend-dot review" />Agent Trust review cost<strong>Not available</strong></div><div><span className="legend-dot tools" />External tool costs<strong>Not available</strong></div></div><div className="cost-note"><CircleHelp size={14} /> No estimated review cost or token count is invented by this screen.</div></div></div>}
              {!loadingDetail && healthTab === "Timeline" && <div className="panel timeline-panel"><div className="panel-heading"><div><h3>Agent timeline</h3><p>Events returned by the Agent Trust timeline endpoint.</p></div><button className="secondary-btn small-btn" onClick={() => void refreshCurrentAgent()}><RefreshCw size={14} /> Refresh</button></div><div className="timeline-list">{timeline.map((event) => <div className="timeline-event" key={`${event.seq}-${event.hash}`}><div className={`timeline-icon ${event.severity === "high" ? "amber" : "violet"}`}><GitBranch size={16} /></div><div><strong>{event.title || event.event}</strong><p>{event.outcome || event.category || "Event recorded"}{event.actor ? ` · ${event.actor}` : ""}</p><small>{demoDate(event.at)}</small></div></div>)}{timeline.length === 0 && <div className="empty-state"><Clock3 size={22} /><strong>No timeline events returned</strong><span>Events will appear here when the backend records them.</span></div>}</div></div>}
              {!loadingDetail && healthTab === "Review workspace" && <div className="review-workspace-wrap"><div className="section-title-row"><div><h2>Review workspace</h2><p>Run checks, manage policies and functional suites, and inspect security evidence.</p></div><button className="secondary-btn" onClick={() => void refreshCurrentAgent()}><RefreshCw size={14} /> Refresh data</button></div><ReviewTab agentId={activeAgent.agent_id} /></div>}
            </>}

            {page === "finding" && activeAgent && selectedFinding && <>
              <button className="back-link" onClick={() => { setPage("health"); setHealthTab("Findings"); }}><ArrowLeft size={15} /> Back to {activeAgent.name}</button>
              <div className="finding-page-heading"><div><div className="eyebrow">FINDING DETAIL <span className="finding-id">{selectedFinding.id}</span></div><h1>{selectedFinding.title}</h1><p>Understand the available evidence, why it matters, and the recommended next step.</p></div><div className="finding-actions"><button className="secondary-btn" onClick={() => { setPage("health"); setHealthTab("Review workspace"); }}><ExternalLink size={15} /> Review workspace</button><button className="primary-btn" disabled={busyReview} onClick={() => { setPage("health"); setHealthTab("Summary"); void startReviewNow(); }}><RefreshCw size={15} /> Rerun review</button></div></div>
              <div className="finding-meta-row"><DemoStatusPill status={selectedFinding.status} /><span className="severity medium">{selectedFinding.severity}</span><span className="meta-separator" /><span><DemoBot size={14} />{activeAgent.name}</span><span><ShieldCheck size={14} /> Source: backend review response</span></div>
              <div className="finding-layout"><div className="finding-content-col"><div className="panel finding-summary-card"><div className="finding-card-heading"><DemoIconBox tone="amber"><AlertTriangle size={18} /></DemoIconBox><div><h3>What happened</h3><p>Observed behavior or recommendation returned by the backend</p></div></div><p className="finding-body">{selectedFinding.observed}</p><div className="evidence-ref"><span><Eye size={14} />{selectedFinding.evidence}</span></div><div className="expected-block"><div><CheckCircle2 size={15} /><strong>Expected behavior</strong></div><p>{selectedFinding.expected}</p></div></div>
                <div className="panel"><div className="panel-heading"><div><h3>Why it matters</h3><p>Impact details from the available review data</p></div><DemoIconBox tone="amber"><AlertCircle size={17} /></DemoIconBox></div><p className="panel-body-copy">{selectedFinding.why}</p></div>
                <div className="panel fix-panel"><div className="panel-heading"><div><h3>Recommended next step</h3><p>Suggestion only — Agent Trust does not edit the agent configuration</p></div><DemoIconBox tone="violet"><Sparkles size={17} /></DemoIconBox></div><div className="fix-callout"><span className="fix-number">1</span><p>{selectedFinding.fix}</p></div><button className="secondary-btn" onClick={() => { setPage("health"); setHealthTab("Review workspace"); }}><Wrench size={15} /> Open review workspace <ArrowUpRight size={14} /></button></div>
                <div className="panel verify-panel"><div className="panel-heading"><div><h3>Verify the improvement</h3><p>Confirm the change with a fresh review.</p></div><DemoIconBox tone="green"><CheckCheck size={17} /></DemoIconBox></div><p className="panel-body-copy">{selectedFinding.verify}</p><button className="primary-btn" disabled={busyReview} onClick={() => { setPage("health"); setHealthTab("Summary"); void startReviewNow(); }}><RefreshCw size={15} /> Rerun review</button></div>
              </div><aside className="finding-side-col"><div className="panel quick-facts"><h3>Finding overview</h3><div className="fact-row"><span>Category</span><strong>{selectedFinding.category}</strong></div><div className="fact-row"><span>Status</span><strong>{selectedFinding.status}</strong></div><div className="fact-row"><span>Impact</span><strong>{selectedFinding.severity}</strong></div><div className="fact-row"><span>Evidence</span><strong>Backend review response</strong></div></div><div className="panel review-cost-card"><div className="panel-heading"><div><h3>Review usage</h3><p>Only actual values are shown</p></div><Coins size={17} className="muted-icon" /></div><div className="finding-cost"><strong>{selectedFinding.cost}</strong><span>Cost returned with this finding</span></div><div className="fact-row"><span>Tokens used</span><strong>{selectedFinding.tokens}</strong></div><div className="cost-note"><CircleHelp size={13} /> Values are not inferred when the backend does not provide them.</div></div><div className="panel related-panel"><div className="panel-heading"><h3>Related findings</h3><span className="count-bubble">{Math.max(0, findings.length - 1)}</span></div>{findings.filter((item) => item.id !== selectedFinding.id).slice(0, 4).map((item) => <button key={item.id} className="related-finding" onClick={() => setSelectedFindingId(item.id)}><span className="related-dot medium" /><span>{item.title}</span><ChevronRight size={14} /></button>)}{findings.length <= 1 && <p className="panel-body-copy">No other findings or recommendations were returned for this agent.</p>}<button className="text-btn full-text-btn" onClick={() => { setPage("health"); setHealthTab("Findings"); }}>All findings <ArrowRight size={14} /></button></div></aside></div>
            </>}
            {page === "finding" && activeAgent && !selectedFinding && <div className="empty-state"><AlertCircle size={24} /><strong>Finding not available</strong><span>The current review response does not contain this item. Return to Findings and select an available item.</span><button className="secondary-btn" onClick={() => { setPage("health"); setHealthTab("Findings"); }}>Back to findings</button></div>}
          </div>
          <footer className="footer"><span>© 2026 EchoAI</span><span><span className="footer-status" /> Agent Health Center <span className="footer-sep">·</span> Connected to Agent Trust API</span><button onClick={() => notify("Only data returned by the configured Agent Trust API is displayed.")}>Data & privacy <ArrowUpRight size={12} /></button></footer>
        </main>
        {toast && <div className="toast"><CheckCircle2 size={17} />{toast}<button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={14} /></button></div>}
      </div>
    </div>
  );
}
