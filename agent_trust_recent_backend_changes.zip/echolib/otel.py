"""
EchoAI OpenTelemetry Observability Module

Centralized OTel bootstrap for traces and metrics.
All LLM calls, tool executions, agent loops, RAG pipelines, and workflows
are instrumented through this module.

Exports:
    init_otel()          - Initialize OTel providers (call once at startup)
    shutdown_otel()      - Flush and shut down providers (call at shutdown)
    get_tracer()         - Get the app-wide Tracer
    get_meter()          - Get the app-wide Meter
    llm_metrics          - Pre-created LLM metric instruments
    tool_metrics         - Pre-created Tool metric instruments
    agent_metrics        - Pre-created Agent metric instruments
    rag_metrics          - Pre-created RAG metric instruments
    workflow_metrics     - Pre-created Workflow metric instruments
    chat_metrics         - Pre-created Chat metric instruments
    convobi_metrics      - Pre-created ConvoBI metric instruments
    trace_llm_call()     - Context manager for LLM call spans + metrics
    trace_operation()    - Context manager for general operation spans
    MetricsCollector     - In-process metrics aggregator for REST API
"""

import logging
import threading
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional
from langchain_core.embeddings import Embeddings
from echolib.config import settings

logger = logging.getLogger(__name__)


def _get_user_id() -> str:
    """Read the current user_id from request-scoped ContextVar."""
    try:
        from echolib.security import get_current_user_id
        return get_current_user_id() or "anonymous"
    except Exception:
        return "anonymous"

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------
_tracer = None
_meter = None
_tracer_provider = None
_meter_provider = None
_initialized = False

# ---------------------------------------------------------------------------
# Singleton metrics collector for REST API
# ---------------------------------------------------------------------------
_metrics_collector: Optional["MetricsCollector"] = None


def _otel_enabled() -> bool:
    return getattr(settings, "OTEL_ENABLED", True)


# ============================================================================
# Init / Shutdown
# ============================================================================

def init_otel(
    service_name: Optional[str] = None,
    otlp_endpoint: Optional[str] = None,
) -> None:
    """
    Initialize OpenTelemetry MeterProvider and optionally TracerProvider.

    Safe to call multiple times — subsequent calls are no-ops.
    When OTEL_ENABLED is False, creates no-op providers so instrumentation
    code can run without conditional checks.
    """
    global _tracer, _meter, _tracer_provider, _meter_provider, _initialized, _metrics_collector

    if _initialized:
        return

    if not _otel_enabled():
        logger.info("OTel disabled (OTEL_ENABLED=false) — using no-op providers")
        _initialized = True
        _metrics_collector = MetricsCollector()
        return

    service_name = service_name or getattr(settings, "OTEL_SERVICE_NAME", "echoai-backend")
    otlp_endpoint = otlp_endpoint or getattr(settings, "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
    export_interval = getattr(settings, "OTEL_METRICS_EXPORT_INTERVAL_MS", 15000)

    try:
        from opentelemetry import trace, metrics
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
        from opentelemetry.sdk.resources import Resource

        resource = Resource.create({"service.name": service_name})
        collector_enabled = getattr(settings, "OTEL_COLLECTOR_ENABLED", False)

        # --- Traces ---
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        _tracer_provider = TracerProvider(resource=resource)
        if collector_enabled:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
            span_exporter = OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True)
            _tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))
        trace.set_tracer_provider(_tracer_provider)
        _tracer = trace.get_tracer("echoai")

        # --- Metrics (always create our own MeterProvider) ---
        readers: list = []
        if collector_enabled:
            try:
                from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
                metric_exporter = OTLPMetricExporter(endpoint=otlp_endpoint, insecure=True)
                metric_reader = PeriodicExportingMetricReader(
                    metric_exporter, export_interval_millis=export_interval
                )
                readers.append(metric_reader)
            except ImportError:
                logger.debug("gRPC metric exporter not available — skipping")

        # Optional Prometheus exporter for /metrics scrape endpoint
        try:
            from opentelemetry.exporter.prometheus import PrometheusMetricReader
            prom_reader = PrometheusMetricReader()
            readers.append(prom_reader)
            logger.info("Prometheus /metrics exporter enabled")
        except ImportError:
            logger.debug("opentelemetry-exporter-prometheus not installed — skipping")

        _meter_provider = MeterProvider(resource=resource, metric_readers=readers)
        metrics.set_meter_provider(_meter_provider)
        _meter = metrics.get_meter("echoai")

        _initialized = True
        _metrics_collector = MetricsCollector()
        _create_metric_instruments()

        logger.info(
            "OTel initialized: service=%s, collector=%s, endpoint=%s, export_interval=%dms",
            service_name, "enabled" if collector_enabled else "disabled (local only)",
            otlp_endpoint, export_interval,
        )

    except Exception as e:
        logger.warning("OTel initialization failed (app continues without telemetry): %s", e)
        _initialized = True
        _metrics_collector = MetricsCollector()


def shutdown_otel() -> None:
    """Flush pending spans/metrics and shut down providers."""
    global _tracer_provider, _meter_provider
    try:
        if _tracer_provider and hasattr(_tracer_provider, "shutdown"):
            _tracer_provider.shutdown()
        if _meter_provider and hasattr(_meter_provider, "shutdown"):
            _meter_provider.shutdown()
        logger.info("OTel providers shut down")
    except Exception as e:
        logger.warning("OTel shutdown error: %s", e)


# ============================================================================
# Accessors
# ============================================================================

def get_tracer(name: str = "echoai"):
    """Return the app-wide OTel Tracer (or no-op if not initialized)."""
    global _tracer
    if _tracer:
        return _tracer
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except Exception:
        return _NoOpTracer()


def get_meter():
    """Return the app-wide OTel Meter (or no-op if not initialized)."""
    global _meter
    if _meter:
        return _meter
    try:
        from opentelemetry import metrics
        return metrics.get_meter("echoai")
    except Exception:
        return _NoOpMeter()


def get_metrics_collector() -> "MetricsCollector":
    """Return the singleton MetricsCollector for REST API access."""
    global _metrics_collector
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector()
    return _metrics_collector


# ============================================================================
# Metric Instrument Definitions
# ============================================================================

class _MetricInstruments:
    """Container for all pre-created OTel metric instruments."""
    pass


llm_metrics = _MetricInstruments()
tool_metrics = _MetricInstruments()
agent_metrics = _MetricInstruments()
rag_metrics = _MetricInstruments()
workflow_metrics = _MetricInstruments()
chat_metrics = _MetricInstruments()
convobi_metrics = _MetricInstruments()


def _create_metric_instruments() -> None:
    """Create all metric instruments on the global meter. Called once during init."""
    meter = get_meter()

    # --- LLM Metrics ---
    llm_metrics.calls_total = meter.create_counter(
        "llm.calls.total", description="Total LLM calls", unit="1",
    )
    llm_metrics.call_duration = meter.create_histogram(
        "llm.call.duration_ms", description="LLM call latency in milliseconds", unit="ms",
    )
    llm_metrics.tokens_input = meter.create_histogram(
        "llm.tokens.input", description="Input token count per LLM call", unit="1",
    )
    llm_metrics.tokens_output = meter.create_histogram(
        "llm.tokens.output", description="Output token count per LLM call", unit="1",
    )
    llm_metrics.tokens_total = meter.create_counter(
        "llm.tokens.total", description="Cumulative total tokens across all calls", unit="1",
    )
    llm_metrics.errors_total = meter.create_counter(
        "llm.errors.total", description="Total LLM call errors", unit="1",
    )
    llm_metrics.streaming_first_token = meter.create_histogram(
        "llm.streaming.first_token_ms", description="Time to first token for streaming calls", unit="ms",
    )

    # --- Tool Metrics ---
    tool_metrics.executions_total = meter.create_counter(
        "tool.executions.total", description="Total tool executions", unit="1",
    )
    tool_metrics.execution_duration = meter.create_histogram(
        "tool.execution.duration_ms", description="Tool execution latency in milliseconds", unit="ms",
    )
    tool_metrics.errors_total = meter.create_counter(
        "tool.errors.total", description="Total tool execution errors", unit="1",
    )

    # --- Agent Metrics ---
    agent_metrics.chats_total = meter.create_counter(
        "agent.chats.total", description="Total agent chat invocations", unit="1",
    )
    agent_metrics.chat_duration = meter.create_histogram(
        "agent.chat.duration_ms", description="Agent chat latency in milliseconds", unit="ms",
    )
    agent_metrics.loop_iterations = meter.create_histogram(
        "agent.loop.iterations", description="Number of ReAct loop iterations per chat", unit="1",
    )

    # --- RAG Metrics ---
    rag_metrics.queries_total = meter.create_counter(
        "rag.queries.total", description="Total RAG queries", unit="1",
    )
    rag_metrics.query_duration = meter.create_histogram(
        "rag.query.duration_ms", description="RAG query latency in milliseconds", unit="ms",
    )
    rag_metrics.retrieval_duration = meter.create_histogram(
        "rag.retrieval.duration_ms", description="RAG retrieval latency in milliseconds", unit="ms",
    )
    rag_metrics.embedding_duration = meter.create_histogram(
        "embedding.duration_ms", description="Embedding generation latency in milliseconds", unit="ms",
    )
    rag_metrics.embedding_calls_total = meter.create_counter(
        "embedding.calls.total", description="Total embedding calls", unit="1",
    )
    # the below metrics are for embeddings
    rag_metrics.embedding_tokens_input = meter.create_histogram(
    "embedding.tokens.input",
    description="Input token count per embedding call",
    unit="1",
    )

    rag_metrics.embedding_tokens_total = meter.create_counter(
        "embedding.tokens.total",
        description="Total embedding tokens consumed",
        unit="1",
    )


    # --- Workflow Metrics ---
    workflow_metrics.executions_total = meter.create_counter(
        "workflow.executions.total", description="Total workflow executions", unit="1",
    )
    workflow_metrics.execution_duration = meter.create_histogram(
        "workflow.execution.duration_ms", description="Workflow execution latency in milliseconds", unit="ms",
    )
    workflow_metrics.node_duration = meter.create_histogram(
        "workflow.node.duration_ms", description="Workflow node execution latency in milliseconds", unit="ms",
    )

    # --- Chat Metrics ---
    chat_metrics.requests_total = meter.create_counter(
        "chat.requests.total", description="Total chat orchestration requests", unit="1",
    )
    chat_metrics.orchestrate_duration = meter.create_histogram(
        "chat.orchestrate.duration_ms", description="Chat orchestration latency in milliseconds", unit="ms",
    )

    # --- ConvoBI Metrics ---
    convobi_metrics.queries_total = meter.create_counter(
        "convobi.queries.total", description="Total ConvoBI queries", unit="1",
    )
    convobi_metrics.query_duration = meter.create_histogram(
        "convobi.query.duration_ms", description="ConvoBI query latency in milliseconds", unit="ms",
    )


# ============================================================================
# Instrumentation Helpers
# ============================================================================

def _safe_attr(val: Any) -> str:
    """Coerce a value to a safe span attribute string."""
    if val is None:
        return "unknown"
    return str(val)


def _extract_token_usage(response: Any) -> Dict[str, int]:
    """
    Best-effort extraction of token usage from an LLM response.

    Checks LangChain response_metadata, usage_metadata, and OpenAI
    SDK patterns.
    """
    usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    try:
        # LangChain AIMessage with response_metadata
        meta = getattr(response, "response_metadata", None) or {}
        token_usage = meta.get("token_usage") or meta.get("usage") or {}
        if token_usage:
            usage["input_tokens"] = token_usage.get("prompt_tokens", 0) or token_usage.get("input_tokens", 0)
            usage["output_tokens"] = token_usage.get("completion_tokens", 0) or token_usage.get("output_tokens", 0)
            usage["total_tokens"] = token_usage.get("total_tokens", 0)
            if not usage["total_tokens"]:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
            return usage

        # LangChain usage_metadata
        umeta = getattr(response, "usage_metadata", None)
        if umeta and isinstance(umeta, dict):
            usage["input_tokens"] = umeta.get("input_tokens", 0)
            usage["output_tokens"] = umeta.get("output_tokens", 0)
            usage["total_tokens"] = umeta.get("total_tokens", 0)
            return usage

        # OpenAI SDK style
        sdk_usage = getattr(response, "usage", None)
        if sdk_usage:
            usage["input_tokens"] = getattr(sdk_usage, "prompt_tokens", 0) or 0
            usage["output_tokens"] = getattr(sdk_usage, "completion_tokens", 0) or 0
            usage["total_tokens"] = getattr(sdk_usage, "total_tokens", 0) or 0
            return usage

    except Exception:
        pass

    return usage


@contextmanager
def trace_llm_call(
    method: str,
    model: str = "unknown",
    provider: str = "unknown",
    feature: str = "unknown",
    user_id: Optional[str] = None,
    resolution_meta=None,
) -> Generator[Dict[str, Any], None, None]:
    """
    Context manager that creates an OTel span and records LLM metrics.

    Usage:
        with trace_llm_call("invoke", model="gpt-4o", provider="azure", feature="agent") as ctx:
            response = llm.invoke(prompt)
            ctx["response"] = response  # optional: enables token tracking

    Yields a mutable dict where callers can set:
        - "response": the raw LLM response (for token extraction)
        - "input_tokens" / "output_tokens": explicit token overrides
        - "error": exception if one occurred
    """
    tracer = get_tracer()
    resolved_user = user_id or _get_user_id()
    ctx: Dict[str, Any] = {}
    start = time.perf_counter()
    resolution_meta = resolution_meta or {}
    attrs = {
        "llm.model": _safe_attr(model),
        "llm.provider": _safe_attr(provider),
        "llm.feature": _safe_attr(feature),
        "llm.method": _safe_attr(method),
        "user.id": _safe_attr(resolved_user),
    }
    base_metric_attrs = {
        "model": _safe_attr(model),
        "provider": _safe_attr(provider),
        "feature": _safe_attr(feature),
        "method": _safe_attr(method),
        "user_id": _safe_attr(resolved_user),
        "credential_id": resolution_meta.get(
            "credential_id"
        ),
        "credential_name": resolution_meta.get(
            "credential_name"
        ),
        "billing_source": resolution_meta.get(
            "billing_source"
        ),
    }

    # --- Sync token-budget check (fast, in-memory) ---
    enforcement = getattr(settings, "TOKEN_BUDGET_ENFORCEMENT", "soft")
    if enforcement != "disabled" and resolved_user != "anonymous":
        try:
            collector = get_metrics_collector()
            budget = collector.check_budget_sync(resolved_user)
            if budget and not budget["allowed"]:
                if enforcement == "hard":
                    from echolib.token_budget import TokenBudgetExceeded
                    raise TokenBudgetExceeded(
                        resolved_user, budget["used"], budget["limit"],
                    )
                else:
                    logger.warning(
                        "Token budget exceeded (soft) for user %s: used=%d limit=%d",
                        resolved_user, budget["used"], budget["limit"],
                    )
                    attrs["token_budget.exceeded"] = True
        except ImportError:
            pass

    span = None
    try:
        span = tracer.start_span(f"llm.{method}", attributes=attrs)
    except Exception:
        pass

    try:
        yield ctx
        # Success path
        duration_ms = (time.perf_counter() - start) * 1000

        # Extract tokens
        response = ctx.get("response")
        tokens = _extract_token_usage(response) if response else {}
        input_t = ctx.get("input_tokens") or tokens.get("input_tokens", 0)
        output_t = ctx.get("output_tokens") or tokens.get("output_tokens", 0)
        total_t = input_t + output_t

        metric_attrs = base_metric_attrs

        _record_llm_metrics(
            metric_attrs, duration_ms, input_t, output_t, total_t, status="success"
        )
        _record_llm_collector(
            metric_attrs, duration_ms, input_t, output_t, total_t, status="success"
        )

        if span:
            span.set_attribute("llm.tokens.input", input_t)
            span.set_attribute("llm.tokens.output", output_t)
            span.set_attribute("llm.tokens.total", total_t)
            span.set_attribute("llm.duration_ms", duration_ms)
            span.set_attribute("user.id", resolved_user)
            try:
                from opentelemetry.trace import StatusCode
                span.set_status(StatusCode.OK)
            except Exception:
                pass

    except Exception as exc:
        duration_ms = (time.perf_counter() - start) * 1000
        metric_attrs = base_metric_attrs

        _record_llm_error(metric_attrs, type(exc).__name__)
        _record_llm_collector(
            metric_attrs, duration_ms, 0, 0, 0, status="error"
        )

        if span:
            span.record_exception(exc)
            try:
                from opentelemetry.trace import StatusCode
                span.set_status(StatusCode.ERROR, str(exc))
            except Exception:
                pass
        raise

    finally:
        if span:
            try:
                span.end()
            except Exception:
                pass


@contextmanager
def trace_operation(
    operation_name: str,
    attributes: Optional[Dict[str, str]] = None,
) -> Generator[Dict[str, Any], None, None]:
    """
    General-purpose span context manager for non-LLM operations.

    Usage:
        with trace_operation("tool.invoke", {"tool.name": "calculator"}) as ctx:
            result = await tool.invoke(...)
    """
    tracer = get_tracer()
    ctx: Dict[str, Any] = {"start_time": time.perf_counter()}
    attrs = {k: _safe_attr(v) for k, v in (attributes or {}).items()}

    span = None
    try:
        span = tracer.start_span(operation_name, attributes=attrs)
    except Exception:
        pass

    try:
        yield ctx
        if span:
            try:
                from opentelemetry.trace import StatusCode
                span.set_status(StatusCode.OK)
            except Exception:
                pass
    except Exception as exc:
        if span:
            span.record_exception(exc)
            try:
                from opentelemetry.trace import StatusCode
                span.set_status(StatusCode.ERROR, str(exc))
            except Exception:
                pass
        raise
    finally:
        if span:
            try:
                span.end()
            except Exception:
                pass


# ============================================================================
# Internal metric recording helpers
# ============================================================================

def _record_llm_metrics(
    attrs: Dict[str, str],
    duration_ms: float,
    input_tokens: int,
    output_tokens: int,
    total_tokens: int,
    status: str = "success",
) -> None:
    """Record LLM metrics on OTel metric instruments."""
    try:
        metric_labels = {**attrs, "status": status}
        if hasattr(llm_metrics, "calls_total"):
            llm_metrics.calls_total.add(1, metric_labels)
            llm_metrics.call_duration.record(duration_ms, metric_labels)
            if input_tokens:
                llm_metrics.tokens_input.record(input_tokens, attrs)
            if output_tokens:
                llm_metrics.tokens_output.record(output_tokens, attrs)
            if total_tokens:
                llm_metrics.tokens_total.add(total_tokens, attrs)
    except Exception:
        pass
def _record_embedding_metrics(
    attrs: Dict[str, str],
    duration_ms: float,
    input_tokens: int,
    total_tokens: int,
    status: str = "success",
) -> None:
    """Record embedding metrics on OTel metric instruments."""
    try:
        metric_labels = {**attrs, "status": status}

        if hasattr(rag_metrics, "embedding_calls_total"):
            rag_metrics.embedding_calls_total.add(
                1,
                metric_labels,
            )

            rag_metrics.embedding_duration.record(
                duration_ms,
                metric_labels,
            )

            if input_tokens:
                rag_metrics.embedding_tokens_input.record(
                    input_tokens,
                    attrs,
                )

            if total_tokens:
                rag_metrics.embedding_tokens_total.add(
                    total_tokens,
                    attrs,
                )

    except Exception:
        pass

def _record_llm_error(attrs: Dict[str, str], error_type: str) -> None:
    """Record LLM error on OTel metric instruments."""
    try:
        if hasattr(llm_metrics, "errors_total"):
            llm_metrics.errors_total.add(1, {**attrs, "error_type": error_type})
    except Exception:
        pass


def _record_llm_collector(
    attrs: Dict[str, str],
    duration_ms: float,
    input_tokens: int,
    output_tokens: int,
    total_tokens: int,
    status: str = "success",
) -> None:
    """Record LLM call data in the in-process MetricsCollector."""
    collector = get_metrics_collector()
    collector.record_llm_call(
        model=attrs.get("model", "unknown"),
        provider=attrs.get("provider", "unknown"),
        feature=attrs.get("feature", "unknown"),
        method=attrs.get("method", "unknown"),
        duration_ms=duration_ms,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        status=status,
        user_id=attrs.get("user_id", "anonymous"),
        credential_id=attrs.get("credential_id"),
        credential_name=attrs.get("credential_name"),
        billing_source=attrs.get("billing_source"),
    )
def _record_embedding_collector(
    attrs: Dict[str, str],
    duration_ms: float,
    input_tokens: int,
    total_tokens: int,
    status: str = "success",
) -> None:
    """Record embedding call data in the in-process MetricsCollector."""

    collector = get_metrics_collector()

    collector.record_embedding_call(
        model=attrs.get("model", "unknown"),
        provider=attrs.get("provider", "unknown"),
        feature=attrs.get("feature", "knowledge"),
        method=attrs.get("method", "embed_documents"),
        duration_ms=duration_ms,
        input_tokens=input_tokens,
        total_tokens=total_tokens,
        status=status,
        user_id=attrs.get("user_id", "anonymous"),
    )
# ============================================================================
# Transparent class to be used in wrapping 
# ============================================================================
class OTelLLMWrapper:
    """
    Transparent wrapper around LangChain models.

    Intercepts:
        invoke()
        stream()

    Preserves:
        with_structured_output()
        bind_tools()

    Delegates everything else.
    """

    def __init__(
        self,
        llm,
        provider,
        model,
        resolution_meta=None,
    ):
        self._llm = llm
        self._provider = provider
        self._model = model
        self._resolution_meta = resolution_meta or {}

        logger.info(
            "[OTEL WRAPPER] created provider=%s model=%s wrapped_type=%s",
            provider,
            model,
            type(llm).__name__,
        )

    def __getattr__(self, name):
        """
        Forward everything else to the underlying model.
        """
        return getattr(self._llm, name)
    def invoke(self, *args, **kwargs):
        feature = kwargs.pop("_otel_feature", "general")

        logger.info(
            "[OTEL INVOKE] provider=%s model=%s feature=%s",
            self._provider,
            self._model,
            feature,
        )
        with trace_llm_call(
            "invoke",
            model=self._model,
            provider=self._provider,
            feature=feature,
            resolution_meta=self._resolution_meta,
        ) as ctx:
            result = self._llm.invoke(*args, **kwargs)
            ctx["response"] = result
            logger.info(
                "[OTEL INVOKE SUCCESS] provider=%s model=%s",
                self._provider,
                self._model,
            )
            return result
        
    # Async ainvoke for async invokation
    async def ainvoke(self, *args, **kwargs):
        feature = kwargs.pop("_otel_feature", "general")

        logger.info(
            "[OTEL AINVOKE] provider=%s model=%s feature=%s",
            self._provider,
            self._model,
            feature,
        )

        with trace_llm_call(
            "ainvoke",
            model=self._model,
            provider=self._provider,
            resolution_meta=self._resolution_meta,
            feature=feature,
        ) as ctx:

            result = await self._llm.ainvoke(
                *args,
                **kwargs,
            )

            ctx["response"] = result

            return result
    def stream(self, *args, **kwargs):
        feature = kwargs.pop("_otel_feature", "general")

        accumulated_text = ""
        last_chunk = None

        with trace_llm_call(
            "stream",
            model=self._model,
            provider=self._provider,
            resolution_meta=self._resolution_meta,
            feature=feature,
        ) as ctx:

            for chunk in self._llm.stream(
                *args,
                **kwargs,
            ):
                last_chunk = chunk

                content = getattr(chunk, "content", "")

                if content:
                    accumulated_text += content

                yield chunk

            ctx["response"] = last_chunk

    async def astream(self, *args, **kwargs):
        feature = kwargs.pop("_otel_feature", "general")

        accumulated_text = ""
        last_chunk = None

        with trace_llm_call(
            "astream",
            model=self._model,
            provider=self._provider,
            resolution_meta=self._resolution_meta,
            feature=feature,
        ) as ctx:

            async for chunk in self._llm.astream(
                *args,
                **kwargs,
            ):
                last_chunk = chunk

                content = getattr(chunk, "content", "")

                if content:
                    accumulated_text += content

                yield chunk

            ctx["response"] = last_chunk
    def with_structured_output(self, *args, **kwargs):
        logger.info(
            "[OTEL STRUCTURED OUTPUT] provider=%s model=%s",
            self._provider,
            self._model,
        )

        structured_llm = self._llm.with_structured_output(
            *args,
            **kwargs,
        )

        logger.info(
            "[OTEL STRUCTURED OUTPUT] returned_type=%s",
            type(structured_llm).__name__,
        )

        return OTelLLMWrapper(
            structured_llm,
            provider=self._provider,
            model=self._model,
            resolution_meta=self._resolution_meta,
        )

    def bind_tools(self, *args, **kwargs):
        logger.info(
            "[OTEL BIND TOOLS] wrapping tool-enabled model"
        )

        tool_llm = self._llm.bind_tools(
            *args,
            **kwargs,
        )

        return OTelLLMWrapper(
            tool_llm,
            provider=self._provider,
            model=self._model,
            resolution_meta=self._resolution_meta,
        )
    # Added the below functionality for frameworks like SQLDatabaseToolkit
    @property
    def wrapped_llm(self):
        """
        Return the underlying LangChain model.
        Used for framework components that perform
        strict BaseLanguageModel validation.
        10
        """
        return self._llm

class OTelEmbeddingWrapper(Embeddings):
    """
    Transparent wrapper around LangChain Embeddings.

    Intercepts:
        embed_query()
        embed_documents()
        aembed_query()
        aembed_documents()

    Delegates everything else.
    """

    def __init__(self, embeddings, provider: str, model: str):
        self._embeddings = embeddings
        self._provider = provider
        self._model = model

    def __getattr__(self, name):
        return getattr(self._embeddings, name)

    def embed_query(self, text: str):
        logger.warning(
        "[OTEL EMBEDDING] embed_query model=%s chars=%d",
        self._model,
        len(text),
        )
        logger.warning(
            "[OTEL EMBEDDING ATTRS] %s",
            self.__dict__,
        )
        start = time.perf_counter()

        metric_attrs = {
            "model": self._model,
            "provider": self._provider,
            "feature": "knowledge",
            "method": "embed_query",
            "user_id": _get_user_id(),
        }

        try:
            result = self._embeddings.embed_query(text)

            duration_ms = (time.perf_counter() - start) * 1000
            input_tokens = max(1, len(text) // 4)
            total_tokens = input_tokens

            _record_embedding_metrics(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            return result

        except Exception:
            duration_ms = (time.perf_counter() - start) * 1000

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                0,
                0,
                status="error",
            )

            raise

    def embed_documents(self, texts):
        logger.warning(
        "[OTEL EMBEDDING] embed_documents model=%s docs=%d",
        self._model,
        len(texts),
        )
        logger.warning(
            "[OTEL EMBEDDING ATTRS] %s",
            self.__dict__,
        )
        start = time.perf_counter()

        metric_attrs = {
            "model": self._model,
            "provider": self._provider,
            "feature": "knowledge",
            "method": "embed_documents",
            "user_id": _get_user_id(),
        }

        try:
            result = self._embeddings.embed_documents(texts)

            duration_ms = (time.perf_counter() - start) * 1000

            input_tokens = sum(len(t or "") // 4 for t in texts)
            total_tokens = input_tokens

            _record_embedding_metrics(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            return result

        except Exception:
            duration_ms = (time.perf_counter() - start) * 1000

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                0,
                0,
                status="error",
            )

            raise

    async def aembed_query(self, text: str):
        logger.warning(
        "[OTEL EMBEDDING] embed_query model=%s chars=%d",
        self._model,
        len(text),
        )
        start = time.perf_counter()

        metric_attrs = {
            "model": self._model,
            "provider": self._provider,
            "feature": "knowledge",
            "method": "aembed_query",
            "user_id": _get_user_id(),
        }

        try:
            result = await self._embeddings.aembed_query(text)

            duration_ms = (time.perf_counter() - start) * 1000
            input_tokens = max(1, len(text) // 4)
            total_tokens = input_tokens

            _record_embedding_metrics(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            return result

        except Exception:
            duration_ms = (time.perf_counter() - start) * 1000

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                0,
                0,
                status="error",
            )

            raise

    async def aembed_documents(self, texts):
        start = time.perf_counter()

        metric_attrs = {
            "model": self._model,
            "provider": self._provider,
            "feature": "knowledge",
            "method": "aembed_documents",
            "user_id": _get_user_id(),
        }

        try:
            result = await self._embeddings.aembed_documents(texts)

            duration_ms = (time.perf_counter() - start) * 1000

            input_tokens = sum(len(t or "") // 4 for t in texts)
            total_tokens = input_tokens

            _record_embedding_metrics(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                input_tokens,
                total_tokens,
                status="success",
            )

            return result

        except Exception:
            duration_ms = (time.perf_counter() - start) * 1000

            _record_embedding_collector(
                metric_attrs,
                duration_ms,
                0,
                0,
                status="error",
            )

            raise
    
# ============================================================================
# LLM OTel Wrapper (patches invoke + stream on raw LangChain clients)
# ============================================================================
def _wrap_llm_with_otel(
    llm,
    provider_name="unknown",
    model_name="unknown",
    resolution_meta=None,
):
    logger.info(
        "[OTEL WRAP REQUEST] provider=%s model=%s type=%s",
        provider_name,
        model_name,
        type(llm).__name__,
    )

    if isinstance(llm, OTelLLMWrapper):
        logger.info(
            "[OTEL WRAP SKIPPED] already wrapped type=%s provider=%s model=%s",
            type(llm).__name__,
            provider_name,
            model_name,
        )

        if resolution_meta:
            llm._resolution_meta = resolution_meta

        return llm

    wrapped = OTelLLMWrapper(
    llm,
    provider=provider_name,
    model=model_name,
    resolution_meta=resolution_meta,
    )

    logger.info(
        "[OTEL WRAP SUCCESS] original_type=%s wrapped_type=%s provider=%s model=%s",
        type(llm).__name__,
        type(wrapped).__name__,
        provider_name,
        model_name,
    )

    return wrapped
def _wrap_embeddings_with_otel(
    embeddings,
    provider_name="unknown",
    model_name="unknown",
):
    logger.warning(
        "[OTEL EMBEDDING WRAP] provider=%s model=%s type=%s",
        provider_name,
        model_name,
        type(embeddings).__name__,
    )

    if isinstance(embeddings, OTelEmbeddingWrapper):
        return embeddings

    return OTelEmbeddingWrapper(
        embeddings,
        provider=provider_name,
        model=model_name,
    )

# ------- Legacy Wrapper ----------
# def _wrap_llm_with_otel(llm, provider: str = None, model: str = None, *, provider_name: str = None, model_name: str = None):
#     # Accept both (provider, model) and (provider_name=, model_name=) for backward compat
#     provider = provider or provider_name or "unknown"
#     model = model or model_name or "unknown"
#     """
#     Monkey-patch ``llm.invoke`` and ``llm.stream`` with OTel
#     tracing + metrics. Returns the same object (mutated in-place).

#     Works with raw LangChain chat models returned by llm_resolver
#     and legacy LLMFactory paths.
#     """
#     if getattr(llm, "_otel_wrapped", False):
#         return llm

#     original_invoke = getattr(llm, "invoke", None)
#     original_stream = getattr(llm, "stream", None)

#     if original_invoke:
#         def instrumented_invoke(*args, **kwargs):
#             logger.warning(
#                 "[OTEL INVOKE] model=%s provider=%s",
#                 model,
#                 provider,
#             )
#             feature = kwargs.pop("_otel_feature", "general")
#             with trace_llm_call("invoke", model=model, provider=provider, feature=feature) as ctx:
#                 result = original_invoke(*args, **kwargs)
#                 ctx["response"] = result
#             return result
#         llm.invoke = instrumented_invoke

#     if original_stream:
#         def instrumented_stream(*args, **kwargs):
#             feature = kwargs.pop("_otel_feature", "general")
#             tracer = get_tracer()
#             resolved_user = _get_user_id()

#             span = None
#             try:
#                 span = tracer.start_span("llm.stream", attributes={
#                     "llm.model": _safe_attr(model),
#                     "llm.provider": _safe_attr(provider),
#                     "llm.feature": _safe_attr(feature),
#                     "llm.method": "stream",
#                     "user.id": _safe_attr(resolved_user),
#                 })
#             except Exception:
#                 pass

#             start = time.perf_counter()
#             accumulated_text = ""
#             last_chunk = None

#             try:
#                 for chunk in original_stream(*args, **kwargs):
#                     last_chunk = chunk
#                     content = getattr(chunk, "content", "")
#                     if content:
#                         accumulated_text += content
#                     yield chunk

#                 duration_ms = (time.perf_counter() - start) * 1000

#                 # Extract tokens from last chunk or estimate
#                 tokens = _extract_token_usage(last_chunk) if last_chunk else {}
#                 input_t = tokens.get("input_tokens", 0)
#                 output_t = tokens.get("output_tokens", 0)
#                 if not output_t and accumulated_text:
#                     output_t = len(accumulated_text) // 4
#                 total_t = input_t + output_t

#                 metric_attrs = {
#                     "model": _safe_attr(model),
#                     "provider": _safe_attr(provider),
#                     "feature": _safe_attr(feature),
#                     "method": "stream",
#                     "user_id": _safe_attr(resolved_user),
#                 }
#                 _record_llm_metrics(metric_attrs, duration_ms, input_t, output_t, total_t)
#                 get_metrics_collector().record_llm_call(
#                     model=model, provider=provider, feature=feature, method="stream",
#                     duration_ms=duration_ms, input_tokens=input_t,
#                     output_tokens=output_t, total_tokens=total_t,
#                     status="success", user_id=resolved_user,
#                 )

#                 if span:
#                     span.set_attribute("llm.tokens.input", input_t)
#                     span.set_attribute("llm.tokens.output", output_t)
#                     span.set_attribute("llm.tokens.total", total_t)
#                     span.set_attribute("llm.duration_ms", duration_ms)
#                     try:
#                         from opentelemetry.trace import StatusCode
#                         span.set_status(StatusCode.OK)
#                     except Exception:
#                         pass

#             except Exception as exc:
#                 duration_ms = (time.perf_counter() - start) * 1000
#                 metric_attrs = {
#                     "model": _safe_attr(model),
#                     "provider": _safe_attr(provider),
#                     "feature": _safe_attr(feature),
#                     "method": "stream",
#                     "user_id": _safe_attr(resolved_user),
#                 }
#                 _record_llm_error(metric_attrs, type(exc).__name__)
#                 get_metrics_collector().record_llm_call(
#                     model=model, provider=provider, feature=feature, method="stream",
#                     duration_ms=duration_ms, input_tokens=0, output_tokens=0,
#                     total_tokens=0, status="error", user_id=resolved_user,
#                 )
#                 if span:
#                     span.record_exception(exc)
#                     try:
#                         from opentelemetry.trace import StatusCode
#                         span.set_status(StatusCode.ERROR, str(exc))
#                     except Exception:
#                         pass
#                 raise
#             finally:
#                 if span:
#                     try:
#                         span.end()
#                     except Exception:
#                         pass

#         llm.stream = instrumented_stream

#     llm._otel_wrapped = True
#     logger.warning(
#     "######## OTEL WRAP CALLED ######## type=%s",
#     type(llm).__name__,
#     )
#     return llm


# ============================================================================
# MetricsCollector — In-Process Aggregator for REST API
# ============================================================================

class MetricsCollector:
    """
    Thread-safe in-process metrics aggregator.

    Maintains running aggregates that the REST /api/analytics/metrics/*
    endpoints read directly — no dependency on Grafana or Prometheus.
    """

    # Max recent tool calls kept per tool (ring buffer)
    _TOOL_RECENT_MAX = 50

    def __init__(self):
        self._lock = threading.Lock()
        self._event_bus = None  # set later by telemetry_stream
        self._batch_writer = None  # set later by telemetry_repo

        # LLM metrics
        self.llm_calls: list = []
        self.llm_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0,
            "total_input_tokens": 0, "total_output_tokens": 0,
            "total_tokens": 0, "errors": 0,
        })
        # Embedding metrics
        self.embedding_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0,
            "total_duration_ms": 0.0,
            "total_input_tokens": 0,
            "total_tokens": 0,
            "errors": 0,
        })

        # Per-user LLM token tracking
        self.user_llm_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0,
            "total_input_tokens": 0, "total_output_tokens": 0,
            "total_tokens": 0, "errors": 0,
        })
        self.user_embedding_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0,
            "total_duration_ms": 0.0,
            "total_input_tokens": 0,
            "total_tokens": 0,
            "errors": 0,
        })

        # Tool metrics
        self.tool_calls: list = []
        self.tool_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })
        self.tool_recent_calls: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=self._TOOL_RECENT_MAX)
        )

        # Agent metrics
        self.agent_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0,
            "total_iterations": 0, "errors": 0,
        })

        # RAG metrics
        self.rag_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })

        # Workflow metrics
        self.workflow_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })

        # Chat metrics
        self.chat_summary: Dict[str, Any] = {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        }

        # ConvoBI metrics
        self.convobi_summary: Dict[str, Any] = {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        }

        # --- Per-user sub-summaries for ALL subsystems ---
        self.user_tool_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })
        self.user_agent_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0,
            "total_iterations": 0, "errors": 0,
        })
        self.user_rag_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })
        self.user_workflow_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })
        self.user_chat_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })
        self.user_convobi_summary: Dict[str, Any] = defaultdict(lambda: {
            "count": 0, "total_duration_ms": 0.0, "errors": 0,
        })

    # --- LLM ---
    def record_llm_call(
    self,
    model,
    provider,
    feature,
    method,
    duration_ms,
    input_tokens,
    output_tokens,
    total_tokens,
    status,
    user_id="anonymous",
    credential_id=None,
    credential_name=None,
    billing_source=None,
    ) -> None:
        with self._lock:
            key = f"{model}|{provider}|{feature}"
            s = self.llm_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            s["total_input_tokens"] += input_tokens
            s["total_output_tokens"] += output_tokens
            s["total_tokens"] += total_tokens
            if status != "success":
                s["errors"] += 1

            uid = user_id or "anonymous"
            u = self.user_llm_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            u["total_input_tokens"] += input_tokens
            u["total_output_tokens"] += output_tokens
            u["total_tokens"] += total_tokens
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "llm_call", "timestamp": time.time(),
            "user_id": uid, "model": model, "provider": provider,
            "credential_id": credential_id,
            "credential_name": credential_name,
            "billing_source": billing_source,
            "feature": feature, "method": method,
            "duration_ms": round(duration_ms, 2),
            "input_tokens": input_tokens, "output_tokens": output_tokens,
            "total_tokens": total_tokens, "status": status,
        })
    # The below is to record all embedding operations
    def record_embedding_call(
    self,
    *,
    model: str,
    provider: str,
    feature: str,
    method: str,
    duration_ms: float,
    input_tokens: int,
    total_tokens: int,
    status: str,
    user_id: str = "anonymous",
    ):
        with self._lock:
            key = f"{model}|{provider}|{feature}"

            s = self.embedding_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            s["total_input_tokens"] += input_tokens
            s["total_tokens"] += total_tokens

            if status != "success":
                s["errors"] += 1

            uid = user_id or "anonymous"

            u = self.user_embedding_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            u["total_input_tokens"] += input_tokens
            u["total_tokens"] += total_tokens

            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "embedding_call",
            "timestamp": time.time(),
            "user_id": uid,
            "model": model,
            "provider": provider,
            "feature": feature,
            "method": method,
            "duration_ms": round(duration_ms, 2),
            "input_tokens": input_tokens,
            "output_tokens": 0,
            "total_tokens": total_tokens,
            "status": status,
        })


    def _publish_event(self, event: Dict[str, Any]) -> None:
        """Fan out a telemetry event to SSE subscribers and DB batch writer."""
        try:
            from echolib.telemetry_context import current_telemetry_context
            context = current_telemetry_context()
            if context:
                existing = event.get("metadata")
                merged = dict(existing) if isinstance(existing, dict) else {}
                merged.update(context)
                event["metadata"] = merged

                # Agent Trust correlation must be promoted to the columns
                # used by CostService and Agent Usage queries. Keep the rest
                # of the context in metadata_json.
                if context.get("agent_trust_agent_id"):
                    event["agent_id"] = context["agent_trust_agent_id"]
                if context.get("workflow_id"):
                    event["workflow_id"] = context["workflow_id"]
        except Exception:
            # Telemetry correlation must never affect application execution.
            pass
        try:
            if self._event_bus:
                self._event_bus.publish(event)
        except Exception:
            pass
        try:
            if self._batch_writer:
                self._batch_writer.enqueue(event)
        except Exception:
            pass

    # --- Tool ---
    def record_tool_call(
        self, tool_name: str, tool_type: str,
        duration_ms: float, status: str,
        user_id: str = "anonymous",
        tool_input: str = "", tool_output: str = "",
        agent_id: str = "",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            key = f"{tool_name}|{tool_type}"
            s = self.tool_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            if status != "success":
                s["errors"] += 1

            u = self.user_tool_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            if status != "success":
                u["errors"] += 1

            self.tool_recent_calls[key].append({
                "timestamp": time.time(),
                "tool_name": tool_name,
                "user_id": uid,
                "duration_ms": round(duration_ms, 2),
                "status": status,
                "input": (tool_input or "")[:2000],
                "output": (tool_output or "")[:2000],
            })

        self._publish_event({
            "event_type": "tool_call", "timestamp": time.time(),
            "user_id": uid, "tool_name": tool_name, "tool_type": tool_type,
            "duration_ms": round(duration_ms, 2), "status": status,
            "agent_id": agent_id,
        })

    # --- Agent ---
    def record_agent_chat(
        self, agent_id: str, model: str,
        duration_ms: float, iterations: int, status: str,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            key = f"{agent_id}|{model}"
            s = self.agent_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            s["total_iterations"] += iterations
            if status != "success":
                s["errors"] += 1

            u = self.user_agent_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            u["total_iterations"] += iterations
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "agent_chat", "timestamp": time.time(),
            "user_id": uid, "agent_id": agent_id, "model": model,
            "duration_ms": round(duration_ms, 2), "iterations": iterations,
            "status": status,
        })

    # --- RAG ---
    def record_rag_query(
        self, rag_type: str, model: str,
        duration_ms: float, status: str,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            key = f"{rag_type}|{model}"
            s = self.rag_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            if status != "success":
                s["errors"] += 1

            u = self.user_rag_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "rag_query", "timestamp": time.time(),
            "user_id": uid, "rag_type": rag_type, "model": model,
            "duration_ms": round(duration_ms, 2), "status": status,
        })

    # --- Workflow ---
    def record_workflow_execution(
        self, workflow_id: str, execution_mode: str,
        duration_ms: float, status: str,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            key = f"{workflow_id}|{execution_mode}"
            s = self.workflow_summary[key]
            s["count"] += 1
            s["total_duration_ms"] += duration_ms
            if status != "success":
                s["errors"] += 1

            u = self.user_workflow_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "workflow_execution", "timestamp": time.time(),
            "user_id": uid, "workflow_id": workflow_id,
            "execution_mode": execution_mode,
            "duration_ms": round(duration_ms, 2), "status": status,
        })

    # --- Chat ---
    def record_chat_request(
        self, duration_ms: float, status: str,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            self.chat_summary["count"] += 1
            self.chat_summary["total_duration_ms"] += duration_ms
            if status != "success":
                self.chat_summary["errors"] += 1

            u = self.user_chat_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "chat_request", "timestamp": time.time(),
            "user_id": uid, "duration_ms": round(duration_ms, 2),
            "status": status,
        })

    # --- ConvoBI ---
    def record_convobi_query(
        self, duration_ms: float, status: str,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        with self._lock:
            self.convobi_summary["count"] += 1
            self.convobi_summary["total_duration_ms"] += duration_ms
            if status != "success":
                self.convobi_summary["errors"] += 1

            u = self.user_convobi_summary[uid]
            u["count"] += 1
            u["total_duration_ms"] += duration_ms
            if status != "success":
                u["errors"] += 1

        self._publish_event({
            "event_type": "convobi_query", "timestamp": time.time(),
            "user_id": uid, "duration_ms": round(duration_ms, 2),
            "status": status,
        })

    # --- Feature use (generic) ---
    def record_feature_use(
        self, feature: str, duration_ms: float, success: bool = True,
        user_id: str = "anonymous",
    ) -> None:
        uid = user_id or "anonymous"
        status = "success" if success else "error"
        self._publish_event({
            "event_type": "feature_use", "timestamp": time.time(),
            "user_id": uid, "feature": feature,
            "duration_ms": round(duration_ms, 2), "status": status,
        })

    # --- Snapshot for REST API ---
    def get_llm_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for key, s in self.llm_summary.items():
                parts = key.split("|")
                avg_duration = s["total_duration_ms"] / s["count"] if s["count"] else 0
                result[key] = {
                    "model": parts[0], "provider": parts[1], "feature": parts[2],
                    "total_calls": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "total_input_tokens": s["total_input_tokens"],
                    "total_output_tokens": s["total_output_tokens"],
                    "total_tokens": s["total_tokens"],
                    "errors": s["errors"],
                    "error_rate": round(s["errors"] / s["count"], 4) if s["count"] else 0,
                }
            return result

    def get_tool_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for key, s in self.tool_summary.items():
                parts = key.split("|")
                avg_duration = s["total_duration_ms"] / s["count"] if s["count"] else 0
                result[key] = {
                    "tool_name": parts[0], "tool_type": parts[1],
                    "total_executions": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "errors": s["errors"],
                    "error_rate": round(s["errors"] / s["count"], 4) if s["count"] else 0,
                    "recent_calls": list(self.tool_recent_calls.get(key, [])),
                }
            return result
    def get_embedding_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}

            for key, s in self.embedding_summary.items():
                parts = key.split("|")

                avg_duration = (
                    s["total_duration_ms"] / s["count"]
                    if s["count"]
                    else 0
                )

                result[key] = {
                    "model": parts[0],
                    "provider": parts[1],
                    "feature": parts[2],
                    "total_calls": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "total_input_tokens": s["total_input_tokens"],
                    "total_tokens": s["total_tokens"],
                    "errors": s["errors"],
                    "error_rate": round(
                        s["errors"] / s["count"],
                        4,
                    ) if s["count"] else 0,
                }

            return result

    def get_agent_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for key, s in self.agent_summary.items():
                parts = key.split("|")
                avg_duration = s["total_duration_ms"] / s["count"] if s["count"] else 0
                avg_iter = s["total_iterations"] / s["count"] if s["count"] else 0
                result[key] = {
                    "agent_id": parts[0], "model": parts[1],
                    "total_chats": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "avg_iterations": round(avg_iter, 2),
                    "errors": s["errors"],
                }
            return result

    def get_rag_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for key, s in self.rag_summary.items():
                parts = key.split("|")
                avg_duration = s["total_duration_ms"] / s["count"] if s["count"] else 0
                result[key] = {
                    "rag_type": parts[0], "model": parts[1],
                    "total_queries": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "errors": s["errors"],
                }
            return result

    def get_workflow_metrics(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for key, s in self.workflow_summary.items():
                parts = key.split("|")
                avg_duration = s["total_duration_ms"] / s["count"] if s["count"] else 0
                result[key] = {
                    "workflow_id": parts[0], "execution_mode": parts[1],
                    "total_executions": s["count"],
                    "avg_duration_ms": round(avg_duration, 2),
                    "errors": s["errors"],
                }
            return result

    def get_overview(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        with self._lock:
            if user_id:
                u_llm = self.user_llm_summary.get(user_id, {})
                u_embedding = self.user_embedding_summary.get(
                    user_id,
                    {},
                )
                u_tool = self.user_tool_summary.get(user_id, {})
                u_agent = self.user_agent_summary.get(user_id, {})
                u_rag = self.user_rag_summary.get(user_id, {})
                u_wf = self.user_workflow_summary.get(user_id, {})
                u_chat = self.user_chat_summary.get(user_id, {})
                u_convobi = self.user_convobi_summary.get(user_id, {})
                return {
                    "user_id": user_id,
                    "llm": {
                        "total_calls": u_llm.get("count", 0),
                        "total_errors": u_llm.get("errors", 0),
                        "total_tokens": u_llm.get("total_tokens", 0),
                        "total_input_tokens": u_llm.get("total_input_tokens", 0),
                        "total_output_tokens": u_llm.get("total_output_tokens", 0),
                        "error_rate": round(u_llm.get("errors", 0) / u_llm["count"], 4) if u_llm.get("count") else 0,
                    },
                    "embeddings": {
                        "total_calls": u_embedding.get("count", 0),
                        "total_errors": u_embedding.get("errors", 0),
                        "total_tokens": u_embedding.get("total_tokens", 0),
                        "total_input_tokens": u_embedding.get(
                            "total_input_tokens",
                            0,
                        ),
                        "error_rate": round(
                            u_embedding.get("errors", 0)
                            / u_embedding["count"],
                            4,
                        ) if u_embedding.get("count") else 0,
                    },
                    "tools": {
                        "total_executions": u_tool.get("count", 0),
                        "total_errors": u_tool.get("errors", 0),
                        "error_rate": round(u_tool.get("errors", 0) / u_tool["count"], 4) if u_tool.get("count") else 0,
                    },
                    "agents": {"total_chats": u_agent.get("count", 0)},
                    "rag": {"total_queries": u_rag.get("count", 0)},
                    "workflows": {"total_executions": u_wf.get("count", 0)},
                    "chat": {"count": u_chat.get("count", 0), "total_duration_ms": u_chat.get("total_duration_ms", 0), "errors": u_chat.get("errors", 0)},
                    "convobi": {"count": u_convobi.get("count", 0), "total_duration_ms": u_convobi.get("total_duration_ms", 0), "errors": u_convobi.get("errors", 0)},
                }

            llm_total = sum(s["count"] for s in self.llm_summary.values())
            llm_errors = sum(s["errors"] for s in self.llm_summary.values())
            llm_tokens = sum(s["total_tokens"] for s in self.llm_summary.values())
            llm_input_tokens = sum(s["total_input_tokens"] for s in self.llm_summary.values())
            llm_output_tokens = sum(s["total_output_tokens"] for s in self.llm_summary.values())
            embedding_total = sum(
                s["count"]
                for s in self.embedding_summary.values()
            )

            embedding_errors = sum(
                s["errors"]
                for s in self.embedding_summary.values()
            )

            embedding_tokens = sum(
                s["total_tokens"]
                for s in self.embedding_summary.values()
            )

            embedding_input_tokens = sum(
                s["total_input_tokens"]
                for s in self.embedding_summary.values()
            )
            tool_total = sum(s["count"] for s in self.tool_summary.values())
            tool_errors = sum(s["errors"] for s in self.tool_summary.values())
            active_users = len(
                set(self.user_llm_summary.keys())
                |
                set(self.user_embedding_summary.keys())
            )

            return {
                "llm": {
                    "total_calls": llm_total,
                    "total_errors": llm_errors,
                    "total_tokens": llm_tokens,
                    "total_input_tokens": llm_input_tokens,
                    "total_output_tokens": llm_output_tokens,
                    "error_rate": round(llm_errors / llm_total, 4) if llm_total else 0,
                },
                "embeddings": {
                    "total_calls": embedding_total,
                    "total_errors": embedding_errors,
                    "total_tokens": embedding_tokens,
                    "total_input_tokens": embedding_input_tokens,
                    "error_rate": round(
                        embedding_errors / embedding_total,
                        4,
                    ) if embedding_total else 0,
                },
                "tools": {
                    "total_executions": tool_total,
                    "total_errors": tool_errors,
                    "error_rate": round(tool_errors / tool_total, 4) if tool_total else 0,
                },
                "agents": {
                    "total_chats": sum(s["count"] for s in self.agent_summary.values()),
                },
                "rag": {
                    "total_queries": sum(s["count"] for s in self.rag_summary.values()),
                },
                "workflows": {
                    "total_executions": sum(s["count"] for s in self.workflow_summary.values()),
                },
                "chat": dict(self.chat_summary),
                "convobi": dict(self.convobi_summary),
                "active_users": active_users,
            }

    def _build_user_record(self, uid: str) -> Dict[str, Any]:
        """Build a comprehensive per-user metrics record across all subsystems."""
        llm = self.user_llm_summary.get(uid, {})
        embedding = self.user_embedding_summary.get(uid, {})
        tool = self.user_tool_summary.get(uid, {})
        agent = self.user_agent_summary.get(uid, {})
        rag = self.user_rag_summary.get(uid, {})
        wf = self.user_workflow_summary.get(uid, {})
        chat = self.user_chat_summary.get(uid, {})
        convobi = self.user_convobi_summary.get(uid, {})
        llm_count = llm.get("count", 0)
        return {
            "total_calls": llm_count,
            "avg_duration_ms": round(llm.get("total_duration_ms", 0) / llm_count, 2) if llm_count else 0,
            "total_input_tokens": llm.get("total_input_tokens", 0),
            "total_output_tokens": llm.get("total_output_tokens", 0),
            "total_tokens": llm.get("total_tokens", 0),
            "errors": llm.get("errors", 0),
            "error_rate": round(llm.get("errors", 0) / llm_count, 4) if llm_count else 0,
            "embedding_calls": embedding.get("count", 0),
            "embedding_total_tokens": embedding.get("total_tokens", 0),
            "embedding_input_tokens": embedding.get(
                "total_input_tokens",
                0,
            ),
            "tool_calls": tool.get("count", 0),
            "tool_errors": tool.get("errors", 0),
            "tool_avg_duration_ms": round(tool.get("total_duration_ms", 0) / tool["count"], 2) if tool.get("count") else 0,
            "agent_chats": agent.get("count", 0),
            "rag_queries": rag.get("count", 0),
            "workflow_executions": wf.get("count", 0),
            "chat_requests": chat.get("count", 0),
            "convobi_queries": convobi.get("count", 0),
        }

    def get_user_metrics(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """Per-user metrics across ALL subsystems. Filter by user_id or get all."""
        with self._lock:
            if user_id:
                return {user_id: self._build_user_record(user_id)}

            all_uids: set = set()
            all_uids.update(self.user_llm_summary.keys())
            all_uids.update(
            self.user_embedding_summary.keys()
            )
            all_uids.update(self.user_tool_summary.keys())
            all_uids.update(self.user_agent_summary.keys())
            all_uids.update(self.user_rag_summary.keys())
            all_uids.update(self.user_workflow_summary.keys())
            all_uids.update(self.user_chat_summary.keys())
            all_uids.update(self.user_convobi_summary.keys())

            return {uid: self._build_user_record(uid) for uid in all_uids}

    # --- Budget cache (sync, in-memory) ---

    _allocation_cache: Dict[str, Dict[str, Any]] = {}
    _allocation_cache_ts: float = 0.0

    def set_allocation_cache(self, allocs: Dict[str, Dict[str, Any]]) -> None:
        """Refresh the cached {user_id: {token_limit, token_duration}} map."""
        with self._lock:
            self._allocation_cache = allocs
            self._allocation_cache_ts = time.time()

    def check_budget_sync(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Sync budget check using in-memory token totals + cached allocations.
        Returns None if no allocation found.
        Returns dict with allowed, remaining, limit, used, budget_status.
        """
        with self._lock:
            alloc = self._allocation_cache.get(user_id)
            if not alloc:
                return None
            limit = alloc.get("token_limit", 0)
            if limit == 0:
                return None  # 0 = unlimited
            llm_used = self.user_llm_summary.get(
                user_id,
                {},
            ).get("total_tokens", 0)

            embedding_used = self.user_embedding_summary.get(
                user_id,
                {},
            ).get("total_tokens", 0)

            used = llm_used + embedding_used
            remaining = max(0, limit - used)
            return {
                "allowed": remaining > 0,
                "remaining": remaining,
                "limit": limit,
                "used": used,
                "budget_status": "exceeded" if used >= limit
                    else "approaching_limit" if used >= limit * 0.8
                    else "within_budget",
            }


# ============================================================================
# No-op fallback classes
# ============================================================================

class _NoOpSpan:
    def set_attribute(self, *a, **kw): pass
    def set_status(self, *a, **kw): pass
    def record_exception(self, *a, **kw): pass
    def end(self): pass
    def __enter__(self): return self
    def __exit__(self, *a): pass


class _NoOpTracer:
    def start_span(self, *a, **kw): return _NoOpSpan()
    def start_as_current_span(self, *a, **kw): return _NoOpSpan()


class _NoOpMeter:
    def create_counter(self, *a, **kw): return _NoOpCounter()
    def create_histogram(self, *a, **kw): return _NoOpHistogram()


class _NoOpCounter:
    def add(self, *a, **kw): pass


class _NoOpHistogram:
    def record(self, *a, **kw): pass
