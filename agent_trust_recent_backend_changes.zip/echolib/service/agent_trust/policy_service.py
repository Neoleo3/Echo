"""
Policy engine -- catalog CRUD, agent assignment, LLM recommendation and the
judge-based policy evaluation, all in one module so the whole policy surface
is readable in a single file.

Rule evaluators are self-contained (regex/keyword based, no LLM, no DB
dependency) so they can run cheaply as a Stage-1 check.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID, uuid4

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent
from echolib.models.agent_trust import (
    Budget,
    Policy,
    PolicyAgentLink,
    PolicyEvaluation,
    PolicyRecommendation,
    PolicyViolation,
)
from echolib.service.agent_trust.judge_llm import JudgeParseError, ask_judge


import logging
logger = logging.getLogger(__name__)

_PII_PATTERNS: Dict[str, re.Pattern] = {
    "email": re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),
    "phone": re.compile(r"\b(?:\+?\d{1,3}[ -]?)?(?:\d[ -]?){9,13}\d\b"),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d[ -]?){13,16}\b"),
    "ip_address": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}

def _eval_blocked_keywords(text: str, params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    keywords = [k.lower() for k in params.get("keywords", [])]
    lowered = text.lower()
    matches = [k for k in keywords if k in lowered]
    if matches:
        return False, f"Blocked keyword(s) found: {', '.join(matches)}", matches
    return True, "No blocked keywords found", []


def _eval_pii_detection(text: str, params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    categories = params.get("categories") or list(_PII_PATTERNS.keys())
    matches = [c for c in categories if c in _PII_PATTERNS and _PII_PATTERNS[c].search(text)]
    if matches:
        return False, f"PII detected: {', '.join(matches)}", matches
    return True, "No PII detected", []


def _eval_resource_whitelist(resource: str, params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    allowed = params.get("allowed_patterns", [])
    if not allowed:
        return True, "No whitelist configured", []
    if any(re.fullmatch(pattern, resource or "") for pattern in allowed):
        return True, "Resource matches whitelist", []
    return False, f"Resource '{resource}' not in whitelist", []


def _eval_tool_allowed(tools_used: List[str], params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    allowed = set(params.get("allowed_tools", []))
    disallowed = [t for t in tools_used if allowed and t not in allowed]
    if disallowed:
        return False, f"Disallowed tool(s) used: {', '.join(disallowed)}", disallowed
    return True, "All tools allowed", []


def _eval_model_allowed(model: str, params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    allowed = params.get("allowed_models", [])
    if allowed and model not in allowed:
        return False, f"Model '{model}' not allowed", [model]
    return True, "Model allowed", []


def _eval_framework_required(framework: Optional[str], params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    required = params.get("framework")
    if required and framework != required:
        return False, f"Framework '{framework}' does not match required '{required}'", []
    return True, "Framework matches", []


def _eval_cost_check(estimated_cost: float, params: Dict[str, Any]) -> Tuple[bool, str, List[str]]:
    threshold = params.get("max_cost_usd")
    if threshold is not None and estimated_cost > threshold:
        return False, f"Estimated cost {estimated_cost} exceeds threshold {threshold}", []
    return True, "Within cost threshold", []

class PolicyService:
    """CRUD over policies/assignments + the rule evaluator used by ``evaluate()``."""
    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def list_policies(self, db: AsyncSession, *, is_active: Optional[bool] = None) -> List[Policy]:
        stmt = select(Policy)
        if is_active is not None:
            stmt = stmt.where(Policy.is_active == is_active)
        return list((await db.execute(stmt.order_by(Policy.name))).scalars().all())

    async def get_policy(self, db: AsyncSession, policy_id: UUID) -> Optional[Policy]:
        return await db.get(Policy, policy_id)

    async def create_policy(
        self,
        db: AsyncSession,
        **fields: Any,
    ) -> Policy:

        fields.pop("category", None)
        fields.pop("rules", None)
        fields.pop("enforcement_mode", None)

        policy = Policy(
            id=uuid4(),
            **fields,
        )

        db.add(policy)

        await db.flush()

        return policy

    
    async def update_policy(
        self,
        db: AsyncSession,
        policy_id: UUID,
        fields: Any,
    ) -> Optional[Policy]:
        policy = await db.get(
            Policy,
            policy_id,
        )

        if policy is None:
            return None

        if policy.is_system_policy:
            raise ValueError(
                "System policies cannot be modified"
            )

        for key, value in fields.items():
            if value is not None:
                setattr(policy, key, value)

        await db.flush()
        return policy

    async def delete_policy(
        self,
        db: AsyncSession,
        policy_id: UUID,
    ) -> bool:
        policy = await db.get(
            Policy,
            policy_id,
        )

        if policy is None:
            return False

        if policy.is_system_policy:
            raise ValueError(
                "System policies cannot be deleted"
            )

        await db.delete(policy)
        await db.flush()

        return True
    
    async def assign_policy(
        self, db: AsyncSession, *, policy_id: UUID, agent_id: str,
        assigned_by: str = "human", rationale: Optional[str] = None,
    ) -> PolicyAgentLink:
        existing = (
            await db.execute(
                select(PolicyAgentLink).where(
                    PolicyAgentLink.policy_id == policy_id,
                    PolicyAgentLink.agent_id == agent_id,
                )
            )
        ).scalar_one_or_none()
        if existing:
            existing.assigned_by = assigned_by
            existing.rationale = rationale
            await db.flush()
            return existing

        link = PolicyAgentLink(
            id=uuid4(), policy_id=policy_id, agent_id=agent_id,
            assigned_by=assigned_by, rationale=rationale,
        )
        db.add(link)
        await db.flush()
        return link

    async def unassign_policy(self, db: AsyncSession, *, policy_id: UUID, agent_id: str) -> bool:
        link = (
            await db.execute(
                select(PolicyAgentLink).where(
                    PolicyAgentLink.policy_id == policy_id,
                    PolicyAgentLink.agent_id == agent_id,
                )
            )
        ).scalar_one_or_none()
        if link is None:
            return False
        await db.delete(link)
        await db.flush()
        return True

    async def list_agent_policies(self, db: AsyncSession, agent_id: str) -> List[Policy]:
        stmt = (
            select(Policy)
            .join(PolicyAgentLink, PolicyAgentLink.policy_id == Policy.id)
            .where(PolicyAgentLink.agent_id == agent_id, Policy.is_active.is_(True))
        )
        return list((await db.execute(stmt)).scalars().all())

    async def list_violations(
        self, db: AsyncSession, *, agent_id: Optional[str] = None, limit: int = 50,
    ) -> List[PolicyViolation]:
        stmt = select(PolicyViolation)
        if agent_id:
            stmt = stmt.where(PolicyViolation.agent_id == agent_id)
        stmt = stmt.order_by(PolicyViolation.occurred_at.desc()).limit(limit)
        return list((await db.execute(stmt)).scalars().all())

    async def get_stats(self, db: AsyncSession) -> Dict[str, Any]:
        from sqlalchemy import func

        total = (await db.execute(select(func.count()).select_from(Policy))).scalar_one()
        active = (
            await db.execute(select(func.count()).select_from(Policy).where(Policy.is_active.is_(True)))
        ).scalar_one()
        violations_24h = (
            await db.execute(
                select(func.count()).select_from(PolicyViolation).where(
                    PolicyViolation.occurred_at >= datetime.now(timezone.utc).replace(
                        hour=0, minute=0, second=0, microsecond=0,
                    )
                )
            )
        ).scalar_one()
        return {"total_policies": total, "active_policies": active, "violations_today": violations_24h}

    async def _evaluate_cost_governance(
        self,
        db: AsyncSession,
        agent_id: str,
    ) -> float:
        budget = (
            await db.execute(
                select(Budget).where(
                    Budget.scope == "agent",
                    Budget.scope_id == agent_id,
                    Budget.is_active.is_(True),
                )
            )
        ).scalar_one_or_none()

        if budget is None:
            return 0.0

        return 100.0
    # ------------------------------------------------------------------
    # Evaluation 
    # ------------------------------------------------------------------


    async def evaluate_policy(
        self,
        db: AsyncSession,
        policy_id: UUID,
        agent_id: str,
        user_id: str,
        *,
        invoker: Any = None,
        review_id: Optional[str] = None,
    ):
        if invoker is None:
            from echolib.service.agent_trust.testing_service import IsolatedAgentInvoker
            invoker = IsolatedAgentInvoker()
        policy = await db.get(
            Policy,
            policy_id,
        )
        if policy is None:
            raise ValueError(
                "Policy not found"
            )
        agent = (
            await db.execute(
                select(Agent).where(
                    Agent.hexaid == agent_id
                )
            )
        ).scalar_one_or_none()

        if agent is None:
            raise ValueError(
                "Agent not found"
            )
        logger.info(
            "policy_evaluation_started",
            extra={
                "policy_id": str(policy.id),
                "policy_name": policy.name,
                "agent_id": agent_id,
            },
        )

        #
        # Special handling for Cost Governance
        #

        if policy.name == "Cost Governance":
            score = await self._evaluate_cost_governance(
                db,
                agent_id,
            )

            passed = score >= 80

            evaluation = PolicyEvaluation(
                id=uuid4(),
                policy_id=policy.id,
                agent_id=agent_id,
                passed=passed,
                score=score,
                agent_response=None,
                judge_response={
                    "result": (
                        "PASS"
                        if passed
                        else "FAIL"
                    )
                },
                evaluated_at=datetime.now(
                    timezone.utc,
                ),
            )
            db.add(evaluation)

            if not passed:
                db.add(
                    PolicyViolation(
                        id=uuid4(),
                        policy_id=policy.id,
                        agent_id=agent_id,
                        severity=policy.severity,
                        reason="Cost governance failed",
                        context={
                            "score": score,
                        },
                        occurred_at=datetime.now(
                            timezone.utc,
                        ),
                    )
                )

            await db.flush()
            return {
                "policy_id": str(policy.id),
                "policy_name": policy.name,
                "passed": passed,
                "score": score,
            }

        #
        # Prompt driven policy
        #

        if not policy.policy_prompt:
            raise ValueError(
                "Policy prompt missing"
            )

        if not policy.judge_prompt:
            raise ValueError(
                "Judge prompt missing"
            )

        try:
            invoke_result = await invoker.invoke(
                agent,
                policy.policy_prompt,
                db=db,
                user_id=user_id,
                review_id=review_id,
            )
            if not invoke_result.executed:
                evaluation = PolicyEvaluation(
                    id=uuid4(),
                    policy_id=policy.id,
                    agent_id=agent_id,
                    passed=False,
                    score=0,
                    agent_response=invoke_result.text or None,
                    judge_response={
                        "result": "NOT_VERIFIED",
                        "review_id": review_id,
                        "reason": "Target agent was not executed in its runtime environment.",
                        "execution_run_id": invoke_result.execution_run_id,
                        "workflow_id": invoke_result.workflow_id,
                    },
                    evaluated_at=datetime.now(timezone.utc),
                )
                db.add(evaluation)
                await db.flush()
                return {
                    "policy_id": str(policy.id),
                    "policy_name": policy.name,
                    "passed": False,
                    "score": 0,
                    "status": "not_verified",
                }
            verdict = await ask_judge(
                component="agent_trust_policy_judge",
                system_prompt=policy.judge_prompt,
                user_prompt=invoke_result.text,
                user_id=user_id,
            )
        except JudgeParseError:
            verdict = {
                "result": "FAIL",
                "reason": "judge_parse_failed",
            }
        passed = (
            verdict.get("result")
            == "PASS"
        )
        score = (
            100
            if passed
            else 0
        )
        db.add(
            PolicyEvaluation(
                id=uuid4(),
                policy_id=policy.id,
                agent_id=agent_id,
                passed=passed,
                score=score,
                agent_response=invoke_result.text,
                judge_response={**verdict, "review_id": review_id},
                evaluated_at=datetime.now(
                    timezone.utc,
                ),
            )
        )
        if not passed:
            db.add(
                PolicyViolation(
                    id=uuid4(),
                    policy_id=policy.id,
                    agent_id=agent_id,
                    severity=policy.severity,
                    reason=verdict.get(
                        "reason"
                    ),
                    context=verdict,
                    occurred_at=datetime.now(
                        timezone.utc,
                    ),
                )
            )
        await db.flush()
        logger.info(
            "policy_evaluation_completed",
            extra={
                "policy_name": policy.name,
                "agent_id": agent_id,
                "passed": passed,
                "score": score,
            },
        )
        return {
            "policy_id": str(policy.id),
            "policy_name": policy.name,
            "passed": passed,
            "score": score,
            "judge_response": verdict,
        }

    async def get_agent_policies(
        self,
        db: AsyncSession,
        agent_id: str,
    ):
        result = await db.execute(
            select(
                Policy,
                PolicyAgentLink,
            )
            .join(
                PolicyAgentLink,
                Policy.id == PolicyAgentLink.policy_id,
            )
            .where(
                PolicyAgentLink.agent_id == agent_id
            )
        )
        return [
            {
                "policy_id": policy.id,
                "name": policy.name,
                "framework": policy.framework,
                "severity": policy.severity,
                "assigned_by": link.assigned_by,
                "assigned_at": link.created_at,
            }
            for policy, link in result.all()
        ]


_POLICY_JUDGE_PROMPT = """You are a governance policy judge for an AI agent platform.
Given an agent's declared purpose, instructions, tools and connectors, decide which of the
provided policies genuinely apply -- based on what the agent actually does (its tools,
connectors and instructions), never based on its name or label alone.
Respond with ONLY a JSON array: [{"policy_id": "...", "applies": true|false, "rationale": "..."}]
for every policy_id given. No prose outside the JSON."""


class PolicyRecommendationService:
    """
    Produces a reviewable policy recommendation for one agent and applies it
    once the user accepts. Never runs automatically.
    """

    async def recommend_policies(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        user_id: str,
        force_refresh: bool = False,
    ) -> PolicyRecommendation:
        logger.info(
            "policy_recommendation_started",
            extra={
                "agent_id": agent_id,
                "user_id": user_id,
                "force_refresh": force_refresh,
            },
        )

        if not force_refresh:
            existing = (
                await db.execute(
                    select(PolicyRecommendation)
                    .where(
                        PolicyRecommendation.agent_id == agent_id,
                        PolicyRecommendation.accepted.is_(False),
                    )
                    .order_by(PolicyRecommendation.created_at.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()

            if existing:
                return existing

        policies = (
            await db.execute(select(Policy).where(Policy.is_active.is_(True)))
        ).scalars().all()
        recommended_policies = policies[:5]

        recommendation = PolicyRecommendation(
            id=uuid4(),
            agent_id=agent_id,
            recommended_policy_ids=[str(policy.id) for policy in recommended_policies],
            recommendation_reasoning={},
            created_by=user_id,
        )
        db.add(recommendation)
        await db.flush()

        logger.info(
            "policy_recommendation_created",
            extra={
                "agent_id": agent_id,
                "recommendation_id": str(recommendation.id),
                "policy_count": len(recommendation.recommended_policy_ids),
            },
        )
        return recommendation

    async def recommend_policies_for_agent(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        user_id: str,
    ) -> Dict[str, Any]:
        """Return LLM policy recommendations without assigning anything."""
        agent = await db.get(Agent, agent_id)
        if agent is None:
            raise ValueError("Agent not found")

        policy_service = PolicyService()

        policies = await policy_service.list_policies(
            db,
            is_active=True,
        )
        if not policies:
            return {"agent_id": agent_id, "recommendations": []}

        definition = agent.definition or {}
        agent_summary = {
            "name": agent.name,
            "instructions": definition.get("instructions") or definition.get("prompt"),
            "tools": definition.get("tools", []),
            "connectors": definition.get("connectors", []),
            "model_config": definition.get("model_config", {}),
        }
        policy_catalog = [
            {
                "policy_id": str(p.id),
                "name": p.name,
                "description": p.description,
                "framework": p.framework,
                "severity": p.severity,
            }
            for p in policies
        ]

        try:
            verdicts = await ask_judge(
                component="agent_trust_policy_recommendation",
                system_prompt=_POLICY_JUDGE_PROMPT,
                user_prompt=f"AGENT:\n{agent_summary}\n\nCANDIDATE POLICIES:\n{policy_catalog}",
                user_id=user_id,
            )
            if not isinstance(verdicts, list):
                raise JudgeParseError("Expected a JSON array of verdicts")
        except JudgeParseError as exc:
            logger.warning("Policy recommendation failed for agent %s: %s", agent_id, exc)
            raise ValueError("Policy recommendation could not be generated") from exc

        recommendations = []
        recommended_policy_ids = []

        for verdict in verdicts:
            if not verdict.get("applies") or not verdict.get("policy_id"):
                continue
            policy = next(
                (p for p in policies if str(p.id) == str(verdict["policy_id"])),
                None,
            )
            if policy is None:
                continue

            recommended_policy_ids.append(str(policy.id))
            recommendations.append({
                "policy_id": str(policy.id),
                "name": policy.name,
                "framework": policy.framework,
                "severity": policy.severity,
                "reason": verdict.get("rationale")
                or "Recommended based on the agent configuration.",
            })

        recommendation = PolicyRecommendation(
            id=uuid4(),
            agent_id=agent_id,
            recommended_policy_ids=recommended_policy_ids,
            recommendation_reasoning={
                "recommendations": recommendations,
            },
            created_by=user_id,
        )
        db.add(recommendation)
        await db.flush()

        return {
            "recommendation_id": str(recommendation.id),
            "agent_id": agent_id,
            "recommendations": recommendations,
        }

    async def accept_recommendation(
        self,
        db: AsyncSession,
        recommendation_id: UUID,
        *,
        agent_id: Optional[str] = None,
    ) -> PolicyRecommendation:
        recommendation = await db.get(PolicyRecommendation, recommendation_id)

        if recommendation is None:
            raise ValueError("Recommendation not found")

        if agent_id is not None and recommendation.agent_id != agent_id:
            raise ValueError("Recommendation not found for this agent")

        if recommendation.accepted:
            return recommendation

        policy_service = PolicyService()

        for policy_id in recommendation.recommended_policy_ids:
            await policy_service.assign_policy(
                db,
                policy_id=UUID(policy_id),
                agent_id=recommendation.agent_id,
                assigned_by="ai_recommendation",
                rationale="Accepted AI recommendation",
            )

        recommendation.accepted = True
        recommendation.accepted_at = datetime.now(timezone.utc)
        await db.flush()

        logger.info(
            "policy_recommendation_accepted",
            extra={
                "recommendation_id": str(recommendation.id),
                "agent_id": recommendation.agent_id,
            },
        )
        return recommendation


class PolicyAssignmentService:
    """
    Judge-LLM policy assignment. On-demand only -- an admin explicitly
    triggers it; manual assign/unassign stays available independently.
    """

    def __init__(self) -> None:
        self._policy_service = PolicyService()

    async def assign_policies_for_agent(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        user_id,
    ) -> Dict[str, Any]:
        agent = await db.get(Agent, agent_id)
        if agent is None:
            return {"assigned": [], "error": "agent_not_found"}

        policies = await self._policy_service.list_policies(db, is_active=True)
        if not policies:
            return {"assigned": [], "error": "no_active_policies"}

        definition = agent.definition or {}
        agent_summary = {
            "name": agent.name,
            "instructions": definition.get("instructions") or definition.get("prompt"),
            "tools": definition.get("tools", []),
            "connectors": definition.get("connectors", []),
            "model_config": definition.get("model_config", {}),
        }
        policy_catalog = [
            {
                "policy_id": str(p.id),
                "name": p.name,
                "description": p.description,
                "framework": p.framework,
                "severity": p.severity,
            }
            for p in policies
        ]

        try:
            verdicts: List[Dict[str, Any]] = await ask_judge(
                component="agent_trust_policy_judge",
                system_prompt=_POLICY_JUDGE_PROMPT,
                user_prompt=f"AGENT:\n{agent_summary}\n\nCANDIDATE POLICIES:\n{policy_catalog}",
                user_id=user_id,
            )
            if not isinstance(verdicts, list):
                raise JudgeParseError("Expected a JSON array of verdicts")
        except JudgeParseError as exc:
            logger.warning("Policy judge failed for agent %s: %s", agent_id, exc)
            return {"assigned": [], "error": "judge_parse_failed", "detail": str(exc)}

        assigned = []
        for verdict in verdicts:
            if not verdict.get("applies"):
                continue
            policy_id = verdict.get("policy_id")
            if not policy_id:
                continue
            try:
                await self._policy_service.assign_policy(
                    db,
                    policy_id=policy_id,
                    agent_id=agent_id,
                    assigned_by="judge_llm",
                    rationale=verdict.get("rationale"),
                )
                assigned.append(verdict)
            except Exception:
                logger.warning(
                    "Failed to apply judge verdict for policy %s", policy_id, exc_info=True
                )

        return {"assigned": assigned, "error": None}