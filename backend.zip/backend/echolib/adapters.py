
from typing import Callable, Dict, List
from .interfaces import IEventBus, ISessionStore, IAuthProvider, ICredentialStore, ILogger
from .types import Event, Session, UserContext
from .config import settings
from .logging import logger
from .security import decode_token

class KafkaEventBus(IEventBus):
    def __init__(self) -> None:
        self._topics: Dict[str, List[Callable[[Event], None]]] = {}
    def publish(self, topic: str, event: Event) -> None:
        for h in self._topics.get(topic, []):
            try:
                h(event)
            except Exception as ex:
                logger.error(f'bus handler error: {ex}')
    def subscribe(self, topic: str, handler: Callable[[Event], None]) -> None:
        self._topics.setdefault(topic, []).append(handler)
    def createTopic(self, topic: str) -> None:
        self._topics.setdefault(topic, [])

class MemcachedSessionStore(ISessionStore):
    def __init__(self) -> None:
        self._sessions: Dict[str, Session] = {}
    def createSession(self, userId: str, data: dict) -> Session:
        sid = f'sess_{len(self._sessions)+1}'
        s = Session(id=sid, user_id=userId, data=data)
        self._sessions[sid] = s
        return s
    def getSession(self, sessionId: str) -> Session | None:
        return self._sessions.get(sessionId)
    def invalidateSession(self, sessionId: str) -> None:
        self._sessions.pop(sessionId, None)

class AzureADAuth(IAuthProvider):
    def validateToken(self, jwt_str: str) -> UserContext:
        payload = decode_token(jwt_str)
        if not payload:
            raise ValueError('invalid token')
        return UserContext(user_id=payload['sub'], email=payload.get('email',''))
    def getLoginUrl(self) -> str:
        return 'https://login.microsoftonline.com/common/oauth2/authorize'

class KeyVaultClient(ICredentialStore):
    """
    Credential store backed by SecretsProvider.

    Delegates to the centralized SecretsProvider singleton which resolves
    secrets from Azure Key Vault (when enabled) with os.environ fallback.
    """

    def __init__(self) -> None:
        from .secrets_provider import secrets as _secrets_provider
        self._provider = _secrets_provider

    def getSecret(self, name: str) -> str:
        return self._provider.get_secret(name, '')

    def setSecret(self, name: str, value: str) -> None:
        # Persist to Key Vault only.  Customer credentials must NEVER be
        # written to the process environment (os.environ).
        self._provider.store_llm_config(name, {"value": value})

    def rotateKey(self, name: str) -> None:
        # Rotation is handled at the Key Vault level.
        # Refresh the provider cache to pick up the new value.
        self._provider.refresh()

class OTelLogger(ILogger):
    """
    OTel-backed logger implementation.

    Creates real OpenTelemetry spans for each log/trace call.
    The spans are automatically forwarded to any configured
    OTel exporter via the global TracerProvider set up during app startup.

    Falls back to standard Python logging if OTel is not initialized.
    """

    def __init__(self) -> None:
        try:
            from opentelemetry import trace
            self._tracer = trace.get_tracer("echoai.logger")
        except ImportError:
            self._tracer = None

    def info(self, msg: str, ctx: dict) -> None:
        logger.info(msg + ' ' + str(ctx))
        if self._tracer:
            with self._tracer.start_as_current_span("log.info") as span:
                span.set_attribute("log.message", msg)
                for k, v in ctx.items():
                    span.set_attribute(f"log.ctx.{k}", str(v))

    def warn(self, msg: str, ctx: dict) -> None:
        logger.warning(msg + ' ' + str(ctx))
        if self._tracer:
            with self._tracer.start_as_current_span("log.warn") as span:
                span.set_attribute("log.message", msg)
                span.set_attribute("log.severity", "WARN")
                for k, v in ctx.items():
                    span.set_attribute(f"log.ctx.{k}", str(v))

    def error(self, msg: str, ctx: dict) -> None:
        logger.error(msg + ' ' + str(ctx))
        if self._tracer:
            with self._tracer.start_as_current_span("log.error") as span:
                span.set_attribute("log.message", msg)
                span.set_attribute("log.severity", "ERROR")
                for k, v in ctx.items():
                    span.set_attribute(f"log.ctx.{k}", str(v))

    def trace(self, span_name: str, ctx: dict) -> None:
        if self._tracer:
            with self._tracer.start_as_current_span(span_name) as span:
                for k, v in ctx.items():
                    span.set_attribute(k, str(v))
        else:
            logger.debug(f'TRACE {span_name} {ctx}')