"""
Shared KPMG branding for every downloadable document (docx, pptx, pdf, ...).

Single source of truth so the logo + brand colour stay identical across all
generators and the format is consistent throughout the application.

Drop the official KPMG logo at any of these (first existing wins):
  1. ``KPMG_LOGO_PATH`` env var
  2. ``backend/AgentTools/docx_generator/assets/kpmg_logo.png`` (bundled)
  3. ``frontend/public/kpmg-logo.png``
"""

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

# KPMG primary blue (#00338D)
KPMG_BLUE_HEX = "00338D"
KPMG_BLUE_RGB = (0x00, 0x33, 0x8D)
# KPMG medium blue (#005EB8) for accents
KPMG_MEDIUM_BLUE_RGB = (0x00, 0x5E, 0xB8)


def resolve_kpmg_logo() -> Optional[str]:
    """Return an absolute path to the KPMG logo PNG, or None if not found.

    Location-independent: candidates are computed from this file (``echolib/``)
    so every caller resolves the same asset regardless of where it lives.
    """
    candidates = []
    env_path = os.getenv("KPMG_LOGO_PATH")
    if env_path:
        candidates.append(env_path)
    here = os.path.dirname(os.path.abspath(__file__))   # .../backend/echolib
    backend_root = os.path.dirname(here)                # .../backend
    candidates.append(
        os.path.join(backend_root, "AgentTools", "docx_generator", "assets", "kpmg_logo.png")
    )
    repo_root = os.path.dirname(backend_root)           # .../echo
    candidates.append(os.path.join(repo_root, "frontend", "public", "kpmg-logo.png"))
    for c in candidates:
        try:
            if c and os.path.isfile(c):
                return os.path.abspath(c)
        except OSError:
            continue
    return None
