"""
EchoAI Canonical Agent Contract.

Single source of truth for the shape of ``agents.definition`` (JSONB).

Replaces the four divergent agent shapes that previously reached
``AgentRepository.upsert`` with one contract, in three tiers:

Tier 1 — user-authored (the only thing the UI shows or edits)
    name, description, instructions, knowledge_sources[], tools[],
    model_config{model, temperature, top_p, max_tokens, provider?}

Tier 2 — system-managed, never user-facing
    agent_id, connectors[], connector_settings{}, files[], skills[],
    required_inputs[], collaboration_context{}, created_via, config_version,
    credential_id, icon

Tier 3 — deprecated mirror, written here, deleted in Phase 10
    prompt (= instructions), settings{}, model

The mirror exists because three live readers would otherwise silently
degrade before Phases 2-3 rewire them:

    apps/agent/factory/factory.py:434            reads ``prompt``
    apps/workflow/runtime/langchain_adapter.py   reads ``settings``, ``model``

Role, Goal, Backstory, Persona, Agent Variables and Collaboration Settings
are removed concepts. They are never emitted on a write. Rows that already
carry them keep them on read — nothing deletes historical data.

This module is pure: it never mutates its inputs, never touches the database,
and never imports from ``apps.*``.
"""

from __future__ import annotations

import copy
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import jsonschema

from echolib.connector_permissions import clean_operations, normalize_access_level
from echolib.schemas import AGENT_SCHEMA
from echolib.utils import new_id as _new_id

logger = logging.getLogger(__name__)


CONTRACT_VERSION = 1

DEFAULT_MODEL = "gpt-4o"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_TOP_P = 0.9
DEFAULT_MAX_TOKENS = 2000

# Legacy ``settings`` mirror default; langchain_adapter reads max_iteration.
DEFAULT_MAX_ITERATION = 3

# Connector kinds an agent may attach. ``database`` is the canonical spelling;
# migration 062 wrote ``api``/``mcp`` from the synthetic tools' connector_source.
CONNECTOR_KINDS = ("api", "mcp", "database")
CONNECTOR_KIND_ALIASES = {
    "api": "api",
    "rest": "api",
    "mcp": "mcp",
    "db": "database",
    "database": "database",
    "sql": "database",
}

# Ceiling on upstream context handed to an agent inside a workflow.
# Consumed in Phase 8, which replaces the hardcoded 4000-char truncation in
# langchain_adapter._build_task. Recorded per agent so it is tunable.
DEFAULT_MAX_CONTEXT_CHARS = 8000

# Generation scaffold ordering. The generation LLM produces these parts; the
# backend concatenates them into the single ``instructions`` string. The
# breakdown is an internal scaffold and is never persisted or rendered as
# separate fields (spec section 6).
#
# Spec section 7.5 defines eight parts. Six more are added for enterprise
# completeness — business objective, responsibilities, decision logic,
# limitations, guardrails and worked examples — matching what production agent
# builders generate. The spec's eight keep their relative order.
#
# Design-time material (example user requests, future extensibility,
# assumptions, success criteria) is NOT here: it describes the agent rather
# than instructing it, and lives in ``metadata`` instead of in the runtime
# system prompt.
INSTRUCTION_SECTIONS: Tuple[Tuple[str, str], ...] = (
    ("purpose", "Purpose"),
    ("business_objective", "Business Objective"),
    ("responsibilities", "Responsibilities"),
    ("behavior", "Behavior"),
    ("decision_logic", "Decision Logic"),
    ("response_style", "Response Style"),
    ("reasoning_guidelines", "Reasoning Guidelines"),
    ("tool_usage_rules", "Tool Usage Rules"),
    ("knowledge_usage_rules", "Knowledge Usage Rules"),
    ("output_format", "Output Format"),
    ("limitations", "Limitations"),
    ("restrictions", "Restrictions"),
    ("guardrails", "Guardrails"),
    ("examples", "Examples"),
)

# Config-chat transcript — spec section 7.2.
#
# "Store the config-chat history keyed to the agent, not the session, so a user
# can leave and resume refining the same agent later." It lives inside
# ``definition.metadata`` rather than in its own table: no DDL, and it matches
# the codebase's existing store-the-whole-definition design. It is scoped to
# how the agent was *configured* and never holds the agent's runtime
# conversations with end users.
CONFIG_CHAT_KEY = "config_chat"
MAX_CONFIG_CHAT_TURNS = 20
MAX_CONFIG_CHAT_CHARS = 8000
CONFIG_CHAT_ROLES = ("user", "assistant")

# Concepts removed from the product. Never written on a new definition.
# Read paths leave them untouched wherever they already exist.
REMOVED_CONCEPT_KEYS = frozenset({
    "role",
    "goal",
    "backstory",
    "persona",
    "agent_variables",
    "variables",
    "collaboration",
    "llm",
})

CREATED_VIA_VALUES = frozenset({
    "standalone",
    "workflow_runtime",
    "template",
    "agentic_app",
})

BUILDER_ONLY_KEYS = frozenset({
    "event",
    "event_type",
    "next_actions",
    "transition_state",
    "state_from",
    "state_to",
    "transition_blocked_reason",
    "legal_transition",
    "warnings",
    "draft_status",
    "draft_changed",
    "save_blocked_reason",
    "similar_agent_suggestions",
    "similarAgents",
    "draftId",
    "draft_id",
    "fields",
    "legacy",
    "schema_version",
    "envelope_version",
    "policy_applied",
    "no_tools_confirmed",
})


# ---------------------------------------------------------------------------
# Coercion helpers
# ---------------------------------------------------------------------------

def _clean_str(value: Any) -> str:
    """Coerce any value to a stripped string, treating None as empty."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return str(value).strip()


def _clean_str_list(value: Any) -> List[str]:
    """Coerce to a de-duplicated list of non-empty strings, order preserved."""
    if isinstance(value, str):
        items = [value]
    elif isinstance(value, (list, tuple)):
        items = list(value)
    else:
        return []

    cleaned = [_clean_str(item) for item in items]
    return list(dict.fromkeys(item for item in cleaned if item))


def _as_dict_list(value: Any) -> List[Dict[str, Any]]:
    """Coerce to a list of dicts, discarding entries of any other type."""
    if not isinstance(value, (list, tuple)):
        return []
    return [copy.deepcopy(item) for item in value if isinstance(item, dict)]


def _as_number(value: Any, fallback: float) -> float:
    """Coerce to float, falling back when the value is absent or unparseable."""
    if value is None or isinstance(value, bool):
        return fallback
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _as_int(value: Any, fallback: int) -> int:
    """Coerce to int, falling back when the value is absent or unparseable."""
    if value is None or isinstance(value, bool):
        return fallback
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def extract_selected_tools(tools: Any) -> List[str]:
    """Normalize selected tools from either draft buckets or a flat list."""
    if isinstance(tools, dict):
        selected = tools.get("selected") or []
    elif isinstance(tools, list):
        selected = tools
    else:
        selected = []

    return _clean_str_list(selected)


# ---------------------------------------------------------------------------
# Instructions
# ---------------------------------------------------------------------------

def concat_instructions(parts: Any) -> str:
    """
    Concatenate the eight-part generation scaffold into one instructions block.

    Accepts the spec section 7.5 dict, a plain string, or a list of lines.
    Section headings are emitted only for the dict form, and only for parts
    that carry content — an empty section never produces a dangling heading.

    Args:
        parts: Scaffold dict, instructions string, or list of instruction lines.

    Returns:
        A single instructions string; empty when there is no content.
    """
    if isinstance(parts, str):
        return parts.strip()

    if isinstance(parts, (list, tuple)):
        lines = [_clean_str(line) for line in parts]
        return "\n".join(f"- {line}" for line in lines if line)

    if not isinstance(parts, dict):
        return ""

    blocks: List[str] = []
    for key, heading in INSTRUCTION_SECTIONS:
        body = parts.get(key)
        if isinstance(body, (list, tuple)):
            body = "\n".join(f"- {_clean_str(x)}" for x in body if _clean_str(x))
        body = _clean_str(body)
        if body:
            blocks.append(f"{heading}:\n{body}")

    # Tolerate scaffolds carrying keys outside the eight known sections.
    known = {key for key, _ in INSTRUCTION_SECTIONS}
    for key, body in parts.items():
        if key in known:
            continue
        body = _clean_str(body)
        if body:
            blocks.append(body)

    return "\n\n".join(blocks).strip()


# A block repeated verbatim inside one instructions string is corruption, not
# authored content. Only substantial blocks are considered, so a short repeated
# line a user really wrote — a separator, a one-word heading — is never removed.
MIN_DEDUPE_BLOCK_CHARS = 40


def _collapse_repeated_blocks(text: str) -> str:
    """
    Drop paragraphs that repeat one already present, keeping the first.

    WHAT: Exact-duplicate paragraph removal, first occurrence wins.
    WHY:  Until the mirror merge below became idempotent, every conversational
          refinement appended to ``prompt`` and the merge then prepended the
          whole block to itself — doubling the instructions on every turn. Rows
          written by that path repair themselves the next time they are read.
    OUTPUT: The identical string when nothing repeats. This must be a no-op for
            every agent that was never corrupted, so only exact matches count.
    """
    if not text:
        return text

    blocks = text.split("\n\n")
    if len(blocks) < 2:
        return text

    seen: set = set()
    kept: List[str] = []
    dropped = False

    for block in blocks:
        key = block.strip()
        if len(key) < MIN_DEDUPE_BLOCK_CHARS:
            kept.append(block)
            continue
        if key in seen:
            dropped = True
            continue
        seen.add(key)
        kept.append(block)

    if not dropped:
        return text

    logger.info("Collapsed %d repeated instruction block(s)", len(blocks) - len(kept))
    return "\n\n".join(kept)


def _resolve_instructions(definition: Dict[str, Any], metadata: Dict[str, Any]) -> str:
    """
    Resolve the authoritative instructions string from any legacy shape.

    Precedence: explicit ``instructions`` (string, list, or scaffold dict),
    then ``prompt``, then ``metadata.prompt`` (the template shape nested
    everything inside metadata). ``output_format`` is folded in under its
    scaffold heading when it is not already represented.

    **``instructions`` wins outright when it carries anything.** ``prompt`` is
    the Tier-3 mirror written by :func:`legacy_mirror` on every single write, so
    a stored row always carries ``prompt == instructions``. Any client that
    reads a row, replaces ``instructions`` and posts the whole object back --
    which is what the agent builder does, because a partial payload would reset
    every capability field it does not display -- therefore arrives here with a
    *new* ``instructions`` beside a *stale* ``prompt``.

    This used to merge the two, prepending the mirror. The result was written
    back and re-mirrored, so the next edit prepended again and the block grew by
    one paragraph per save ("Hi\\n\\nhello\\n\\ntest hello 123"). Not a
    duplicate, so ``_collapse_repeated_blocks`` could not see it either.

    A divergent ``prompt`` is now ignored rather than merged. Nothing is lost by
    that: the canvas is the only producer that authors ``prompt`` without
    ``instructions``, and it sends no ``instructions`` key at all, so it falls
    through to the branch below exactly as before.
    """
    instructions = concat_instructions(definition.get("instructions"))

    if not instructions:
        # No canonical value. The mirror -- or the template shape's nested copy
        # -- is the only instruction text this producer has.
        instructions = (
            _clean_str(definition.get("prompt"))
            or _clean_str(definition.get("system_prompt"))
            or _clean_str(metadata.get("prompt"))
        )

    instructions = _collapse_repeated_blocks(instructions)

    output_format = definition.get("output_format")
    if isinstance(output_format, (list, tuple)):
        lines = [_clean_str(x) for x in output_format]
        output_format = "\n".join(
            f"{idx + 1}. {line}" for idx, line in enumerate(l for l in lines if l)
        )
    output_format = _clean_str(output_format)

    if output_format and "Output Format:" not in instructions:
        instructions = f"{instructions}\n\nOutput Format:\n{output_format}".strip()

    return instructions


# ---------------------------------------------------------------------------
# Model configuration
# ---------------------------------------------------------------------------

def _resolve_model_config(definition: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
    """
    Resolve ``model_config`` from any legacy shape.

    Precedence: explicit ``model_config`` > flat ``model`` plus ``settings``
    > deprecated ``llm{}`` > metadata-nested settings (template shape)
    > module defaults.
    """
    explicit = definition.get("model_config") if isinstance(definition.get("model_config"), dict) else {}
    settings = definition.get("settings") if isinstance(definition.get("settings"), dict) else {}
    old_llm = definition.get("llm") if isinstance(definition.get("llm"), dict) else {}
    meta_settings = metadata.get("settings") if isinstance(metadata.get("settings"), dict) else {}

    model = (
        _clean_str(explicit.get("model"))
        or _clean_str(definition.get("model") if isinstance(definition.get("model"), str) else "")
        or _clean_str(old_llm.get("model"))
        or _clean_str(metadata.get("model"))
        or DEFAULT_MODEL
    )

    # settings uses ``max_token`` (singular); llm{} uses ``max_tokens``.
    temperature = explicit.get("temperature")
    if temperature is None:
        temperature = settings.get("temperature")
    if temperature is None:
        temperature = old_llm.get("temperature")
    if temperature is None:
        temperature = meta_settings.get("temperature")

    max_tokens = explicit.get("max_tokens")
    if max_tokens is None:
        max_tokens = settings.get("max_token")
    if max_tokens is None:
        max_tokens = old_llm.get("max_tokens")
    if max_tokens is None:
        max_tokens = meta_settings.get("max_token")

    top_p = explicit.get("top_p")
    if top_p is None:
        top_p = settings.get("top_p")
    if top_p is None:
        top_p = meta_settings.get("top_p")

    model_config: Dict[str, Any] = {
        "model": model,
        "temperature": _as_number(temperature, DEFAULT_TEMPERATURE),
        "top_p": _as_number(top_p, DEFAULT_TOP_P),
        # ``max_tokens`` is deliberately **absent when the author never set it**,
        # rather than defaulted to a number.
        #
        # It used to be written as ``_as_int(max_tokens, DEFAULT_MAX_TOKENS)``,
        # so every agent ever created stored a considered-looking 2000 that
        # nobody considered -- and "unset" became indistinguishable from "the
        # author chose 2000" the moment the row was written. That number is a
        # hard stop on the completion, so long answers were cut mid-sentence and
        # raising the field looked like fighting the platform rather than
        # changing a setting.
        #
        # A stated value is still authoritative and is never clamped. An absent
        # one is resolved at build time against the credential's registered
        # ``max_output_tokens`` and then a provider-aware floor
        # (``llm_resolver._effective_max_tokens``), which is the only layer that
        # knows which provider is about to be called.
        **(
            {"max_tokens": _as_int(max_tokens, DEFAULT_MAX_TOKENS)}
            if max_tokens is not None
            else {}
        ),
    }

    provider = (
        _clean_str(explicit.get("provider"))
        or _clean_str(definition.get("provider"))
        or _clean_str(settings.get("provider"))
        or _clean_str(old_llm.get("provider"))
    )
    if provider:
        model_config["provider"] = provider

    return model_config


# ---------------------------------------------------------------------------
# Structured Tier-2 fields
# ---------------------------------------------------------------------------

def _resolve_required_inputs(value: Any) -> List[Dict[str, Any]]:
    """
    Normalize ``required_inputs`` to the spec section 5.1 shape.

    Each entry is ``{type, label, blocking}`` with ``type`` constrained to
    file / knowledge_source / variable. Entries without a label are dropped —
    an unlabelled required input cannot be reported to the user by the
    Phase 7 readiness gate.
    """
    allowed_types = {"file", "knowledge_source", "variable"}
    resolved: List[Dict[str, Any]] = []

    for entry in _as_dict_list(value):
        label = _clean_str(entry.get("label"))
        if not label:
            continue
        input_type = _clean_str(entry.get("type")).lower()
        resolved.append({
            "type": input_type if input_type in allowed_types else "variable",
            "label": label,
            "blocking": bool(entry.get("blocking", True)),
        })

    return resolved


def _resolve_connectors(value: Any) -> List[Dict[str, Any]]:
    """
    Normalize and validate ``connectors`` — the single write boundary.

    Each entry is ``{connector_id, kind, alias, access_level,
    allowed_operations[], enabled}`` plus any extra keys the entry already
    carried (migration ``062`` records ``migrated_from_tool_id``, which is audit
    material and is preserved).

    **Permissions are validated here, not only at the attach endpoint.** Every
    write path reaches this function -- the attach endpoint, the generic
    ``PUT /agents/{id}``, workflow-embedded agents and bulk upsert -- so a
    crafted request cannot store a grant the invocation boundary is unable to
    interpret. Values that are meaningless for the connector's kind are dropped
    and logged; an uninterpretable grant is either a silent denial or, worse, a
    silent allowance.

    ``access_level`` defaults to ``read_only``: an attachment that never stated
    a level, including every attachment migration ``062`` created, is least
    privileged rather than inheriting whatever the runtime happened to expose.

    An entry without a ``connector_id`` is not an attachment and is dropped --
    unresolvable migration entries live in
    ``metadata.connector_migration.needs_review``, never here.
    """
    resolved: List[Dict[str, Any]] = []
    seen: set = set()

    for entry in _as_dict_list(value):
        connector_id = _clean_str(entry.get("connector_id")) or _clean_str(entry.get("id"))
        if not connector_id or connector_id in seen:
            continue
        seen.add(connector_id)

        raw_kind = _clean_str(entry.get("kind")).lower()
        kind = CONNECTOR_KIND_ALIASES.get(raw_kind, raw_kind if raw_kind in CONNECTOR_KINDS else "")

        operations, dropped = clean_operations(kind, entry.get("allowed_operations"))
        if dropped:
            logger.warning(
                "Dropped %d invalid operation(s) from %s connector '%s': %s",
                len(dropped), kind or "unknown", connector_id, dropped,
            )

        normalized = dict(entry)
        normalized.pop("id", None)
        normalized["connector_id"] = connector_id
        normalized["kind"] = kind
        normalized["alias"] = _clean_str(entry.get("alias")) or connector_id
        normalized["access_level"] = normalize_access_level(entry.get("access_level"))
        normalized["allowed_operations"] = operations
        normalized["enabled"] = bool(entry.get("enabled", True))
        resolved.append(normalized)

    return resolved


def _resolve_connector_settings(value: Any) -> Dict[str, Any]:
    """
    Normalize the agent-level connector capability flag (spec section 6.1).

    Connector Settings is off by default for every agent. While it is off the
    server refuses attachment and the middleware exposes nothing, whatever a
    client sends — the UI's disabled state is never the enforcement point.

    An object rather than a bare boolean so further per-agent capability flags
    can be added without another contract change.
    """
    source = value if isinstance(value, dict) else {}
    settings = dict(source)
    settings["enabled"] = bool(source.get("enabled", False))
    return settings


def connectors_enabled(definition: Optional[Dict[str, Any]]) -> bool:
    """True when Connector Settings is switched on for this agent."""
    if not isinstance(definition, dict):
        return False
    settings = definition.get("connector_settings")
    return bool(settings.get("enabled")) if isinstance(settings, dict) else False


ORIGIN_APPLICATION = "application"

# Where a loader records the agent's owner on a definition it read for
# execution. The owner lives on the ``agents.user_id`` column, not inside the
# definition JSONB, so every path that loads a row for a run has to carry it
# explicitly: ``StandaloneAgentRunner._load_definition`` and
# ``AgentRepository.get_definitions`` both do.
#
# It is the **resource principal** — the identity an attachment's stored row is
# read and invoked under. Scoping those reads to the *caller* instead is what
# made a published agent lose every knowledge base and connector for anyone but
# its author. Stripped on write by :func:`to_persisted`: it describes this run,
# not the agent, and a stale owner frozen into a row would outlive the fact.
OWNER_USER_ID_KEY = "_owner_user_id"

# The account an agent's LLM credential is resolved under, when that is not the
# agent's owner: an agent that inherits its application's LLM runs on the
# credential the *application's* owner chose, which may be a different person.
# Run-scoped like ``OWNER_USER_ID_KEY`` and stripped on write for the same
# reason. Absent, the LLM credential follows ``OWNER_USER_ID_KEY``.
LLM_OWNER_USER_ID_KEY = "_llm_owner_user_id"


def _merge_source_list(
    own: Any, contributed: Any, key: str
) -> List[Dict[str, Any]]:
    """
    Union two attachment lists, the agent's own entry winning on a collision.

    An agent that deliberately attached a source keeps its own configuration
    for it — alias, allowed operations, access level. The application only adds
    what the agent does not already have.
    """
    merged: List[Dict[str, Any]] = [
        dict(entry) for entry in (own or []) if isinstance(entry, dict)
    ]
    seen = {str(entry.get(key)) for entry in merged if entry.get(key)}

    for entry in (contributed or []):
        if not isinstance(entry, dict):
            continue
        identifier = str(entry.get(key) or "")
        if not identifier or identifier in seen:
            continue
        merged.append(dict(entry))
        seen.add(identifier)

    return merged


def merge_application_sources(
    definition: Optional[Dict[str, Any]],
    contribution: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Return a new definition that also carries an application's sources.

    WHAT: Unions ``connectors`` and ``knowledge_sources`` from a contribution,
          and records the session documents the agent may search.
    WHY:  An agent running inside an application should be able to reach that
          application's datasources, but the application's configuration must
          not be written into an agent record it does not own. Merging at build
          time gives an agent used by two applications each one's sources while
          it runs there, and leaves the stored definition untouched.
    INPUT: A stored agent definition and a JSON-able contribution carrying
           ``connectors`` / ``knowledge_sources`` / ``session_documents``.
    OUTPUT: A **new** dict. Inputs are never mutated — the same definition
            object is reused across turns and, on the workflow path, across
            nodes of one run.

    Lives here rather than in the application layer because both the
    application layer (which builds contributions) and the agent factory (which
    consumes them) need it, and neither may import the other.
    """
    base: Dict[str, Any] = dict(definition or {})
    if not isinstance(contribution, dict) or not contribution:
        return base

    connectors = contribution.get("connectors")
    knowledge_sources = contribution.get("knowledge_sources")
    session_documents = contribution.get("session_documents")

    if connectors:
        base["connectors"] = _merge_source_list(
            base.get("connectors"), connectors, "connector_id"
        )
    if knowledge_sources:
        base["knowledge_sources"] = _merge_source_list(
            base.get("knowledge_sources"), knowledge_sources, "knowledge_base_id"
        )
    if session_documents:
        # Not an attachment: these belong to the conversation rather than to
        # the agent, and are resolved against the index the upload already
        # built rather than through the agent's own file registry.
        base["session_documents"] = [
            dict(entry) for entry in session_documents if isinstance(entry, dict)
        ]
        if contribution.get("chat_session_id"):
            base["_chat_session_id"] = contribution["chat_session_id"]
        # Carried so a document search can be widened past this one
        # conversation to everything the same user uploaded into this
        # application, when the deployment asks for that scope.
        if contribution.get("application_id"):
            base["_application_id"] = contribution["application_id"]

    return base


def _is_application_origin(entry: Any) -> bool:
    """
    True for an entry lent by the application rather than attached by the author.

    The Connector Settings toggle is the *agent author's* control over the
    agent's *own* attachments. An application's datasources are the application
    owner's configuration and are merged in at build time, so they are not
    subject to it — otherwise an agent whose toggle happened to be off would
    silently drop the application's database, and the failure would look like a
    resolution bug rather than a policy decision.
    """
    return (
        isinstance(entry, dict)
        and str(entry.get("origin") or "").lower() == ORIGIN_APPLICATION
    )


def attached_connectors(definition: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Return the connectors this agent may actually use.

    Empty while Connector Settings is off — except for connectors lent by the
    application, which the toggle does not govern (see
    :func:`_is_application_origin`). Disabled individual entries are excluded
    here rather than at every consumer.
    """
    entries = [
        entry
        for entry in _resolve_connectors((definition or {}).get("connectors"))
        if entry.get("enabled", True)
    ]
    if connectors_enabled(definition):
        return entries
    return [entry for entry in entries if _is_application_origin(entry)]


def _resolve_files(value: Any) -> List[Dict[str, Any]]:
    """
    Normalize ``files`` — the agent's attached documents and URLs.

    Each entry is ``{file_id, name, source_type, format, ingest_mode, enabled}``
    plus any extra key the entry already carried. This is stable *identity*
    only: conversion state, chunk counts and errors live in the ``agent_files``
    row, so a background ingest updating them never rewrites the definition and
    never inflates ``config_version``.

    An entry without a ``file_id`` is not an attachment and is dropped — the
    middleware joins these against the registry by id, and a half-entry would
    resolve to nothing while still being described to the model.
    """
    allowed_types = {"file", "url"}
    allowed_modes = {"inline", "retrieval"}
    resolved: List[Dict[str, Any]] = []
    seen: set = set()

    for entry in _as_dict_list(value):
        file_id = _clean_str(entry.get("file_id")) or _clean_str(entry.get("id"))
        if not file_id or file_id in seen:
            continue
        seen.add(file_id)

        source_type = _clean_str(entry.get("source_type")).lower()
        ingest_mode = _clean_str(entry.get("ingest_mode")).lower()

        normalized = dict(entry)
        normalized.pop("id", None)
        normalized["file_id"] = file_id
        normalized["name"] = _clean_str(entry.get("name")) or file_id
        normalized["source_type"] = source_type if source_type in allowed_types else "file"
        normalized["format"] = _clean_str(entry.get("format"))
        normalized["ingest_mode"] = ingest_mode if ingest_mode in allowed_modes else "retrieval"
        normalized["enabled"] = bool(entry.get("enabled", True))
        resolved.append(normalized)

    return resolved


def _resolve_knowledge_sources(value: Any) -> List[Dict[str, Any]]:
    """
    Normalize ``knowledge_sources`` — knowledge bases linked to the agent.

    Each entry is ``{knowledge_base_id, name, enabled}``. Tolerant of the older
    freeform shape this field carried before Phase 6 gave it meaning: an entry
    with no resolvable id is kept verbatim rather than dropped, because prompt
    generation writes *suggested* sources here (spec Rule 4) and discarding a
    suggestion would lose the record of what the user asked for.
    """
    resolved: List[Dict[str, Any]] = []
    seen: set = set()

    for entry in _as_dict_list(value):
        kb_id = (
            _clean_str(entry.get("knowledge_base_id"))
            or _clean_str(entry.get("kb_id"))
            or _clean_str(entry.get("id"))
        )
        normalized = dict(entry)

        if not kb_id:
            # A suggestion, not a link. Preserved as-is.
            resolved.append(normalized)
            continue

        if kb_id in seen:
            continue
        seen.add(kb_id)

        normalized.pop("kb_id", None)
        normalized.pop("id", None)
        normalized["knowledge_base_id"] = kb_id
        normalized["name"] = _clean_str(entry.get("name")) or kb_id
        normalized["enabled"] = bool(entry.get("enabled", True))
        resolved.append(normalized)

    return resolved


def attached_files(definition: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Return the files and URLs this agent may actually use.

    Empty while Connector Settings is off. Spec section 6.1 gates uploading a
    file and attaching a connector with the same switch — "a user can only
    upload a file or attach a connector after explicitly toggling Connector
    Settings on" — so the gate lives here and no consumer has to remember it.
    Individually disabled entries are excluded here rather than at every
    consumer.
    """
    if not connectors_enabled(definition):
        return []
    return [
        entry
        for entry in _resolve_files((definition or {}).get("files"))
        if entry.get("enabled", True)
    ]


def attached_knowledge_sources(definition: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Return the linked knowledge bases this agent may actually search.

    Same gate as :func:`attached_files`, and the same exemption for knowledge
    bases lent by the application. Suggestions with no ``knowledge_base_id``
    are excluded: they record what the user described, not something the agent
    can read.
    """
    entries = [
        entry
        for entry in _resolve_knowledge_sources((definition or {}).get("knowledge_sources"))
        if entry.get("knowledge_base_id") and entry.get("enabled", True)
    ]
    if connectors_enabled(definition):
        return entries
    return [entry for entry in entries if _is_application_origin(entry)]


def _resolve_readiness(value: Any) -> Dict[str, Any]:
    """
    Normalize ``readiness`` — the per-agent Context Readiness Gate policy.

    Spec section 4.3 makes the gate mandatory, but turning it on hard would
    break agents that work today, so the mode is per agent:

    - ``off``   the gate does not run at all
    - ``warn``  it runs and records findings but never stops a run (the default)
    - ``block`` a blocking finding stops the run before the model is called

    Absent means "no opinion" rather than "off": ``mode`` is only recorded when
    the agent states one, so an agent that says nothing follows the deployment
    default and moves with it. Writing a default here would freeze every agent
    at whatever the platform happened to be set to on the day it was saved.

    ``grading_enabled`` is the same: the LLM sufficiency call is one extra model
    round trip per run, off by default, and recorded only when chosen.
    """
    source = value if isinstance(value, dict) else {}
    resolved: Dict[str, Any] = {}

    mode = _clean_str(source.get("mode")).lower()
    if mode in ("off", "warn", "block"):
        resolved["mode"] = mode

    grading = source.get("grading_enabled")
    if isinstance(grading, bool):
        resolved["grading_enabled"] = grading

    freshness = _as_int(source.get("freshness_days"), 0)
    if freshness > 0:
        resolved["freshness_days"] = freshness

    return resolved


def _resolve_collaboration_context(value: Any) -> Dict[str, Any]:
    """
    Normalize ``collaboration_context`` — server-managed cross-agent handoff.

    Replaces the removed user-facing Collaboration Settings. This carries the
    per-agent policy for how a workflow propagates context between nodes,
    which Phase 8 consumes when it types the handoff currently done by
    string-concatenating ``last_node_output``.

    ``system_managed`` is always True: this object is written by the backend
    and is never user-editable.
    """
    source = value if isinstance(value, dict) else {}

    return {
        "system_managed": True,
        # Receive the accumulated output of upstream nodes on every execution.
        "inherit_upstream": bool(source.get("inherit_upstream", True)),
        # Contribute this agent's output to the shared context for downstream
        # nodes, including sibling branches that fan back in.
        "publish_downstream": bool(source.get("publish_downstream", True)),
        "max_context_chars": _as_int(
            source.get("max_context_chars"), DEFAULT_MAX_CONTEXT_CHARS
        ),
    }


def collaboration_settings(definition: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Read an agent's cross-node context policy, defaulted.

    Tolerant of a raw definition that has not been normalized: workflow node
    functions receive whatever the executor resolved, and a missing block must
    mean "the defaults" rather than an error.
    """
    source = (definition or {}).get("collaboration_context")
    return _resolve_collaboration_context(source if isinstance(source, dict) else {})


def collaboration_inherits(definition: Optional[Dict[str, Any]]) -> bool:
    """
    True when this agent receives the accumulated output of upstream nodes.

    Consumed by ``build_agent_task`` from Phase 8. Before that, the field was
    written by Phase 1 and read by nothing.
    """
    return bool(collaboration_settings(definition).get("inherit_upstream", True))


def collaboration_publishes(definition: Optional[Dict[str, Any]]) -> bool:
    """
    True when this agent's output joins the shared context for later nodes.

    False makes an agent a leaf: it still runs and still returns its result to
    its own output keys, but it does not contribute to the fan-in summary that
    downstream agents read.
    """
    return bool(collaboration_settings(definition).get("publish_downstream", True))


def collaboration_context_limit(definition: Optional[Dict[str, Any]]) -> int:
    """
    Ceiling on upstream context handed to this agent, in characters.

    Replaces the hardcoded 4000 in ``langchain_adapter``. Per agent, because a
    node that fans in six branches needs a very different allowance from one
    that follows a single predecessor.

    **Read as a floor against the configured platform allowance, not as the
    final word.** ``collaboration_context`` is ``system_managed`` -- the block
    says so itself -- and ``normalize_agent_definition`` writes the resolved
    value into every agent it persists. So every agent already in the database
    carries the historical 8,000, and nothing a user can edit will change it.

    At 8,000 characters an agent late in a fifteen-agent workflow received a
    prefix of the first two agents and nothing else; the rest of the run's work
    was cut off before it ever reached the model. Taking the larger of the
    stored value and the configured one lifts every existing agent without a
    migration, and still lets a future per-agent value above the platform
    allowance win. It never lowers anything.

    The caller clamps the result to what the model's context window can hold --
    this function does not know which model is about to be built.
    """
    stored = _as_int(
        collaboration_settings(definition).get("max_context_chars"),
        DEFAULT_MAX_CONTEXT_CHARS,
    )
    if stored <= 0:
        stored = DEFAULT_MAX_CONTEXT_CHARS

    try:
        from echolib.config import settings

        configured = int(
            getattr(settings, "agent_upstream_context_chars", DEFAULT_MAX_CONTEXT_CHARS)
        )
    except Exception:  # noqa: BLE001 -- tuning must never fail a node
        configured = DEFAULT_MAX_CONTEXT_CHARS

    return max(stored, configured if configured > 0 else DEFAULT_MAX_CONTEXT_CHARS)


# ---------------------------------------------------------------------------
# Normalization (read path)
# ---------------------------------------------------------------------------

def normalize_agent_definition(
    raw: Optional[Dict[str, Any]],
    *,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Normalize any historical agent shape to the canonical contract.

    Read-path tolerant: fills defaults, never raises, and never drops keys it
    does not recognize. Legacy concepts already stored on a row survive this
    call untouched — only :func:`to_persisted` removes them, and only on write.

    Handles all four historical producers:
        - workflow designer      role / goal / llm{}
        - agent designer         role / prompt / settings{} / credential_id
        - service templates      everything nested inside metadata{}
        - draft adapters         instructions merged into prompt

    Args:
        raw: Definition dict from any producer or persisted row.
        source: Optional ``created_via`` hint applied when the row has none.

    Returns:
        A new canonical definition dict. The input is never mutated.
    """
    definition = copy.deepcopy(raw) if isinstance(raw, dict) else {}

    metadata = definition.get("metadata")
    metadata = copy.deepcopy(metadata) if isinstance(metadata, dict) else {}

    agent_id = _clean_str(definition.get("agent_id")) or _clean_str(definition.get("id"))
    definition["agent_id"] = agent_id or _new_id("agt_")

    # ``agent_name`` is accepted on input and folded onto ``name``, which is
    # what the agents.name column and every reader use.
    name = _clean_str(definition.get("name")) or _clean_str(definition.get("agent_name"))
    definition.pop("agent_name", None)
    definition["name"] = name

    # goal was the closest legacy equivalent of a user-facing description.
    definition["description"] = (
        _clean_str(definition.get("description"))
        or _clean_str(definition.get("goal"))
        or _clean_str(metadata.get("description"))
    )

    definition["instructions"] = _resolve_instructions(definition, metadata)

    definition["tools"] = extract_selected_tools(definition.get("tools"))
    definition["knowledge_sources"] = _resolve_knowledge_sources(
        definition.get("knowledge_sources")
    )
    definition["connectors"] = _resolve_connectors(definition.get("connectors"))
    definition["connector_settings"] = _resolve_connector_settings(
        definition.get("connector_settings")
    )
    definition["files"] = _resolve_files(definition.get("files"))
    definition["skills"] = _clean_str_list(definition.get("skills"))

    definition["model_config"] = _resolve_model_config(definition, metadata)
    definition["required_inputs"] = _resolve_required_inputs(definition.get("required_inputs"))
    definition["readiness"] = _resolve_readiness(definition.get("readiness"))
    definition["collaboration_context"] = _resolve_collaboration_context(
        definition.get("collaboration_context")
    )

    created_via = _clean_str(definition.get("created_via")) or _clean_str(source)
    definition["created_via"] = created_via if created_via in CREATED_VIA_VALUES else "standalone"

    config_version = definition.get("config_version")
    definition["config_version"] = (
        config_version if isinstance(config_version, int) and config_version > 0
        else CONTRACT_VERSION
    )

    icon = _clean_str(definition.get("icon")) or _clean_str(metadata.get("icon"))
    if icon:
        definition["icon"] = icon

    credential_id = _clean_str(definition.get("credential_id"))
    if credential_id:
        definition["credential_id"] = credential_id
    else:
        definition.pop("credential_id", None)

    metadata["schema_version"] = "agent_contract_v1"
    definition["metadata"] = metadata

    return definition


# ---------------------------------------------------------------------------
# Persistence (write path)
# ---------------------------------------------------------------------------

def legacy_mirror(definition: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build the deprecated Tier-3 mirror block.

    Phases 2 and 3 move every reader onto ``instructions`` and ``model_config``;
    Phase 10 deletes this function and the keys it produces. Until then these
    three keys are what keeps existing runtime paths working unchanged.

    Args:
        definition: A canonical definition (post-normalization).

    Returns:
        Dict of mirror keys to merge onto the definition.
    """
    model_config = definition.get("model_config") or {}

    settings: Dict[str, Any] = {
        "temperature": model_config.get("temperature", DEFAULT_TEMPERATURE),
        "top_p": model_config.get("top_p", DEFAULT_TOP_P),
        "max_iteration": DEFAULT_MAX_ITERATION,
    }
    # Mirrored only when actually set. Defaulting it here would defeat the
    # omission above on the very next round trip: ``normalize_agent_definition``
    # reads ``settings["max_token"]`` as a source (line ~416), so a mirror that
    # invented 2000 would be read back as an explicit authored choice the next
    # time the agent was saved. Both readers of this key tolerate its absence
    # (``node_mapper:1240``, ``compiler:2369``).
    if model_config.get("max_tokens") is not None:
        settings["max_token"] = model_config["max_tokens"]
    if model_config.get("provider"):
        settings["provider"] = model_config["provider"]

    return {
        "prompt": definition.get("instructions", ""),
        "model": model_config.get("model", DEFAULT_MODEL),
        "settings": settings,
    }


def to_persisted(
    raw: Optional[Dict[str, Any]],
    *,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Produce the definition exactly as it should be written to ``agents``.

    This is the single write boundary. It normalizes, strips the removed
    concepts, and attaches the deprecated mirror. Every path that persists an
    agent goes through here, so the removed concepts cannot re-enter the
    agents table from any producer.

    Args:
        raw: Definition dict from any producer.
        source: Optional ``created_via`` hint applied when the row has none.

    Returns:
        A new dict ready for the ``definition`` JSONB column.
    """
    definition = normalize_agent_definition(raw, source=source)

    for key in REMOVED_CONCEPT_KEYS:
        definition.pop(key, None)

    # output_format is a scaffold section, folded into instructions above.
    definition.pop("output_format", None)
    definition.pop("system_prompt", None)

    # Run-scoped, never stored. Set by a loader for this execution only; writing
    # it back would freeze one run's principal onto the agent.
    definition.pop(OWNER_USER_ID_KEY, None)
    definition.pop(LLM_OWNER_USER_ID_KEY, None)

    definition.update(legacy_mirror(definition))

    return definition


# ---------------------------------------------------------------------------
# Config-chat transcript (spec section 7.2)
# ---------------------------------------------------------------------------

def get_config_chat(definition: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Read the config-chat transcript from a definition.

    Args:
        definition: Agent definition dict, in any shape.

    Returns:
        A copy of the transcript; empty when the agent has no config chat yet.
    """
    if not isinstance(definition, dict):
        return []

    metadata = definition.get("metadata")
    if not isinstance(metadata, dict):
        return []

    history = metadata.get(CONFIG_CHAT_KEY)
    if not isinstance(history, list):
        return []

    turns: List[Dict[str, Any]] = []
    for turn in history:
        if not isinstance(turn, dict):
            continue
        content = _clean_str(turn.get("content"))
        if not content:
            continue
        role = _clean_str(turn.get("role")).lower()
        turns.append({
            "role": role if role in CONFIG_CHAT_ROLES else "user",
            "content": content,
            "at": _clean_str(turn.get("at")),
        })

    return turns


def append_config_chat(
    definition: Optional[Dict[str, Any]],
    role: str,
    content: Any,
) -> Dict[str, Any]:
    """
    Append one turn to a definition's config-chat transcript.

    The transcript is capped at :data:`MAX_CONFIG_CHAT_TURNS`, oldest first, so
    the definition JSONB cannot grow without bound during a long authoring
    session.

    Args:
        definition: Agent definition dict. Never mutated.
        role: ``"user"`` or ``"assistant"``.
        content: Message text.

    Returns:
        A new definition dict carrying the extended transcript.
    """
    updated = copy.deepcopy(definition) if isinstance(definition, dict) else {}

    text = _clean_str(content)
    if not text:
        return updated

    metadata = updated.get("metadata")
    metadata = dict(metadata) if isinstance(metadata, dict) else {}

    history = get_config_chat(updated)
    history.append({
        "role": role if role in CONFIG_CHAT_ROLES else "user",
        "content": text,
        "at": datetime.now(timezone.utc).isoformat(),
    })

    metadata[CONFIG_CHAT_KEY] = history[-MAX_CONFIG_CHAT_TURNS:]
    updated["metadata"] = metadata

    return updated


def render_config_chat(
    history: Any,
    *,
    max_chars: int = MAX_CONFIG_CHAT_CHARS,
) -> str:
    """
    Render a transcript for inclusion in a generation prompt.

    Renders newest-last and drops the oldest turns first when over budget, so
    the most recent instructions always survive truncation.

    Args:
        history: Transcript list, or a definition to read one from.
        max_chars: Character ceiling for the rendered block.

    Returns:
        A ``role: content`` block, or an empty string when there is no history.
    """
    turns = history if isinstance(history, list) else get_config_chat(history)

    lines: List[str] = []
    total = 0
    for turn in reversed(turns):
        if not isinstance(turn, dict):
            continue
        content = _clean_str(turn.get("content"))
        if not content:
            continue
        role = _clean_str(turn.get("role")).lower()
        line = f"{'User' if role != 'assistant' else 'Assistant'}: {content}"
        if total + len(line) > max_chars:
            break
        lines.append(line)
        total += len(line)

    return "\n".join(reversed(lines))


def comparable_definition(definition: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Project a definition down to what determines ``config_version``.

    The config chat and the mutable metadata timestamps change on every
    authoring turn without changing the agent's configuration; counting them as
    changes would inflate the version on every message.

    Args:
        definition: Agent definition dict. Never mutated.

    Returns:
        A comparable copy with version-irrelevant keys removed.
    """
    if not isinstance(definition, dict):
        return {}

    comparable = {k: v for k, v in definition.items() if k != "config_version"}

    metadata = comparable.get("metadata")
    if isinstance(metadata, dict):
        comparable["metadata"] = {
            k: v for k, v in metadata.items()
            if k not in (CONFIG_CHAT_KEY, "updated_at", "lastUpdatedAt")
        }

    return comparable


def strip_builder_only_fields(payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Strip builder-only metadata that must never reach runtime or workflows."""
    cleaned = copy.deepcopy(payload) if isinstance(payload, dict) else {}

    for key in BUILDER_ONLY_KEYS:
        cleaned.pop(key, None)

    metadata = cleaned.get("metadata")
    if isinstance(metadata, dict):
        metadata.pop("no_tools_confirmed", None)

    return cleaned


def draft_to_definition(draft: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Convert an Agent Builder draft into the canonical persisted definition.

    Replaces ``map_agent_draft_to_saved_agent``, which merged ``instructions``
    and ``output_format`` into ``prompt`` and then discarded both — the write
    boundary at which the specification's central field was being destroyed.
    Here ``instructions`` is authoritative and ``prompt`` is derived from it.

    Args:
        draft: AgentDraft payload from the builder.

    Returns:
        Canonical definition dict ready for persistence.
    """
    cleaned = strip_builder_only_fields(draft)
    cleaned.pop("status", None)

    # Drop the Tier-3 instruction mirror when the draft states the canonical
    # field. The builder posts the stored definition with only ``instructions``
    # replaced, so the ``prompt`` riding along is the *previous* revision.
    # ``_resolve_instructions`` already refuses to merge it; removing it here
    # means it never reaches ``legacy_mirror`` to be written back either.
    #
    # Conditional on purpose. ``strip_builder_only_fields`` is shared with the
    # canvas write path (``node_mapper``, ``workflow_repo``), where ``prompt``
    # is the *only* instruction field a node carries -- stripping it there
    # would empty every agent on the canvas.
    if concat_instructions(cleaned.get("instructions")):
        cleaned.pop("prompt", None)
        cleaned.pop("system_prompt", None)

    # Draft-only camelCase LLM block, folded onto model_config.
    llm_config = cleaned.pop("llmConfig", None)
    alt_llm_config = cleaned.pop("llm_config", None)
    if not isinstance(llm_config, dict):
        llm_config = alt_llm_config

    if isinstance(llm_config, dict):
        model_config = cleaned.get("model_config")
        model_config = dict(model_config) if isinstance(model_config, dict) else {}
        for source_key, target_key in (
            ("model", "model"),
            ("temperature", "temperature"),
            ("maxTokens", "max_tokens"),
            ("topP", "top_p"),
            ("provider", "provider"),
        ):
            if llm_config.get(source_key) is not None and target_key not in model_config:
                model_config[target_key] = llm_config[source_key]
        cleaned["model_config"] = model_config

    return to_persisted(cleaned, source="standalone")


# ---------------------------------------------------------------------------
# Gating and validation
# ---------------------------------------------------------------------------

def is_explicit_no_tools_confirmation(draft: Optional[Dict[str, Any]]) -> bool:
    """Return True when a draft explicitly confirms saving without tools."""
    if not isinstance(draft, dict):
        return False

    if bool(draft.get("no_tools_confirmed")):
        return True

    metadata = draft.get("metadata")
    if isinstance(metadata, dict) and bool(metadata.get("no_tools_confirmed")):
        return True

    return False


def missing_required_fields(draft: Optional[Dict[str, Any]]) -> List[str]:
    """
    Return required draft fields that are empty or absent, for save gating.

    ``role`` and ``goal`` are no longer required: they are removed concepts
    and resolve into ``instructions``. ``output_format`` remains a required
    *draft* field because it is one of the eight scaffold sections, even
    though it is not persisted as a separate key.

    Args:
        draft: AgentDraft payload from the builder.

    Returns:
        List of missing field names; empty when the draft may be saved.
    """
    if not isinstance(draft, dict):
        return ["name", "instructions", "output_format"]

    missing: List[str] = []

    for field in ("name", "instructions", "output_format"):
        value = draft.get(field)
        if value is None:
            missing.append(field)
        elif isinstance(value, str) and not value.strip():
            missing.append(field)
        elif isinstance(value, (list, dict)) and len(value) == 0:
            missing.append(field)

    if not extract_selected_tools(draft.get("tools")) and not is_explicit_no_tools_confirmation(draft):
        missing.append("tools.selected_or_explicit_no_tools_confirm")

    return missing


def looks_like_agent_draft(payload: Any) -> bool:
    """Detect whether an incoming payload is an AgentDraft-like object."""
    if not isinstance(payload, dict):
        return False
    if payload.get("schema_version") == "agent_builder_v2":
        return True
    if any(k in payload for k in ("draftId", "draft_id", "event", "state_from", "state_to", "next_actions")):
        return True
    tools = payload.get("tools")
    if isinstance(tools, dict) and any(k in tools for k in ("selected", "recommended", "optional", "rejected")):
        return True
    return False


# Agent-owned keys. The agents table is the source of truth for every one of
# these, so a workflow must not persist its own copy: a copy is what goes stale
# when the agent is edited elsewhere (Finding 8).
#
# A deny-list, not an allow-list, and deliberately. ``workflows.definition
# ["agents"]`` holds *every* node on the canvas -- API, MCP, Code, Self-Review,
# Conditional, Start, End and HITL as well as agents -- and those carry
# node-kind-specific config this module has no business enumerating. Removing
# named keys from agent nodes only cannot silently drop an API node's endpoint.
AGENT_OWNED_KEYS = frozenset({
    # Behaviour
    "instructions", "prompt", "system_prompt", "description",
    # Model binding
    "model", "model_config", "settings", "credential_id", "provider",
    "temperature", "max_tokens", "maxTokens", "top_p", "topP", "llm",
    # How much detail this agent was asked for. Agent-owned like every other
    # behavioural setting, so a workflow node carrying it hands it to the agent
    # record rather than keeping a per-workflow copy that can drift.
    "response_depth",
    # Capabilities
    "tools", "skills", "connectors", "connector_settings",
    "files", "knowledge_sources", "required_inputs",
    # System-managed policy
    "collaboration_context", "readiness", "config_version", "created_via",
    "metadata", "icon", "constraints", "permissions",
    # Removed concepts that legacy rows still carry
    "role", "goal", "backstory", "persona", "variables", "collaboration",
})

# Node types whose entries are agents. Everything else on the canvas keeps its
# definition in the workflow, because it has nowhere else to live.
AGENT_NODE_TYPES = frozenset({"", "agent", "hitl"})

# Keys inside ``metadata`` that describe the node's place on the canvas rather
# than the agent itself, and so must survive stripping.
#
# ``metadata`` is listed in AGENT_OWNED_KEYS because most of it -- the config
# chat transcript, ``created_at``, ``schema_version`` -- genuinely belongs to
# the agent. But ``node_mapper`` also writes the canvas position and node kind
# in there, and those are per-workflow: the same agent can sit at different
# coordinates in two workflows. Dropping the whole dict took the layout with
# it, so a reopened canvas fell back to auto-layout and every agent node
# rendered as a generic "Agent".
WORKFLOW_OWNED_METADATA_KEYS = ("node_type", "ui_layout")


def _entry_node_type(entry: Dict[str, Any]) -> str:
    """Read a canvas node's type the same way the compiler's dispatcher does."""
    metadata = entry.get("metadata") if isinstance(entry.get("metadata"), dict) else {}
    config = entry.get("config") if isinstance(entry.get("config"), dict) else {}
    raw = entry.get("type") or metadata.get("node_type") or config.get("type") or "agent"
    return str(raw).strip().lower()


def is_agent_node(entry: Optional[Dict[str, Any]]) -> bool:
    """
    True when a canvas entry is an agent, rather than an API/MCP/Code/etc node.

    HITL counts: a HITL node wraps an agent and is executed through the same
    factory, so its agent state belongs in the agents table too.
    """
    if not isinstance(entry, dict):
        return False
    return _entry_node_type(entry) in AGENT_NODE_TYPES


def to_workflow_node_reference(entry: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Strip agent-owned state from a canvas entry, keeping its wiring.

    WHAT: Removes the keys the ``agents`` table owns, leaving identity,
          position, graph contract and node-kind config.
    WHY:  Phase 8, §13 item 4 option (a). The workflow JSON holds references,
          not values -- the model n8n uses, where a node points at a stored
          entity and updating that entity propagates everywhere instantly with
          no per-workflow copy to fall out of sync. Keeping a copy is what made
          the agent one entity on write and two on read.
    INPUT: One entry from ``workflows.definition["agents"]``.
    OUTPUT: A new dict. The input is never mutated. Non-agent nodes are
            returned unchanged -- an API node's endpoint is workflow-owned and
            has nowhere else to be stored.

    ``name`` is kept: it is the label the canvas renders, and a node with no
    label is unusable while the agent record is being resolved.
    """
    if not isinstance(entry, dict):
        return {}

    if not is_agent_node(entry):
        return dict(entry)

    reference = {
        key: copy.deepcopy(value)
        for key, value in entry.items()
        if key not in AGENT_OWNED_KEYS
    }

    # Identity must survive even if the entry only carried it under `id`.
    agent_id = _clean_str(entry.get("agent_id")) or _clean_str(entry.get("id"))
    if agent_id:
        reference["agent_id"] = agent_id

    # `metadata` is agent-owned as a whole, but carries the canvas position and
    # node kind, which are not. Keep exactly those two.
    metadata = entry.get("metadata")
    if isinstance(metadata, dict):
        wiring = {
            key: copy.deepcopy(metadata[key])
            for key in WORKFLOW_OWNED_METADATA_KEYS
            if metadata.get(key)
        }
        if wiring:
            reference["metadata"] = wiring

    return reference


def carries_agent_state(entry: Optional[Dict[str, Any]]) -> bool:
    """
    True when a canvas entry holds agent *state* rather than a bare reference.

    WHAT: Looks for any key the ``agents`` table owns and the canvas authors.
    WHY:  After Phase 8 a saved workflow stores references. Writing one of
          those back through the agent write path cannot add anything -- it can
          only blank the keys the reference does not carry, because
          ``normalize_agent_definition`` rebuilds every field from what it is
          handed. Re-saving such an entry is therefore never an update; it is
          silent deletion, and it is what made cloning a workflow drop its
          agents' tools and model.
    INPUT: One entry from ``workflows.definition["agents"]``.
    OUTPUT: True when there is something worth persisting.

    Mirrors ``agent_resolution._has_definition``, which decides the same
    question on the read side.
    """
    if not isinstance(entry, dict):
        return False

    return any(
        entry.get(key)
        for key in (
            "instructions",
            "prompt",
            "description",
            "model",
            "model_config",
            "settings",
            "tools",
            "skills",
            "connectors",
            "files",
            "knowledge_sources",
            "credential_id",
        )
    )


def to_workflow_reference(definition: Dict[str, Any], node_id: str) -> Dict[str, Any]:
    """
    Project a canonical definition into the workflow-embedded node shape.

    Predates Phase 8 and is unchanged. Phase 8's stripping happens at the save
    boundary through :func:`to_workflow_node_reference`; this remains the
    projection used when a saved agent is first placed on a canvas.
    """
    definition = definition if isinstance(definition, dict) else {}

    return {
        "agent_id": definition.get("agent_id"),
        "node_id": node_id,
        "name": definition.get("name", ""),
        "description": definition.get("description", ""),
        "tools": definition.get("tools", []),
        "input_mapping": {},
        "output_mapping": {},
    }


def validate(definition: Dict[str, Any]) -> None:
    """
    Validate a definition against the agent JSON schema.

    Raises:
        jsonschema.ValidationError: When the definition does not conform.
    """
    jsonschema.validate(instance=definition, schema=AGENT_SCHEMA)


__all__ = [
    "CONFIG_CHAT_KEY",
    "CONNECTOR_KINDS",
    "CONNECTOR_KIND_ALIASES",
    "CONTRACT_VERSION",
    "DEFAULT_MAX_CONTEXT_CHARS",
    "DEFAULT_MAX_ITERATION",
    "DEFAULT_MAX_TOKENS",
    "DEFAULT_MODEL",
    "DEFAULT_TEMPERATURE",
    "DEFAULT_TOP_P",
    "INSTRUCTION_SECTIONS",
    "MAX_CONFIG_CHAT_CHARS",
    "MAX_CONFIG_CHAT_TURNS",
    "REMOVED_CONCEPT_KEYS",
    "append_config_chat",
    "attached_connectors",
    "attached_files",
    "AGENT_NODE_TYPES",
    "AGENT_OWNED_KEYS",
    "collaboration_context_limit",
    "collaboration_inherits",
    "collaboration_publishes",
    "collaboration_settings",
    "attached_knowledge_sources",
    "comparable_definition",
    "concat_instructions",
    "connectors_enabled",
    "get_config_chat",
    "render_config_chat",
    "draft_to_definition",
    "extract_selected_tools",
    "is_agent_node",
    "is_explicit_no_tools_confirmation",
    "legacy_mirror",
    "looks_like_agent_draft",
    "missing_required_fields",
    "normalize_agent_definition",
    "strip_builder_only_fields",
    "to_persisted",
    "to_workflow_node_reference",
    "to_workflow_reference",
    "validate",
]
