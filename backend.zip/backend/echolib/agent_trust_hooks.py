"""
Agent Trust registration hook.

WHAT: The single call site invoked from ``AgentRepository.upsert()`` right
      after an agent row is written -- covers individual agent saves and
      workflow-embedded agent upserts alike, since both funnel through that
      one function.
WHY:  Registration must be zero-friction and never break a save. Every
      failure here is caught and logged by the caller; this module also
      guards internally so a bug in governance code can never surface as a
      product-facing error.

Workflow canvases persist pseudo-nodes (Start, End, API, Code, ...) as agent
rows. Those are not agents and are never registered.

Only registration runs here. Policy assignment, identity evaluation and
testing are on-demand, triggered explicitly by an admin -- this hook only
flips staleness flags for them to notice.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


def _definition_hash(definition: dict) -> str:
    canonical = json.dumps(definition or {}, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


async def on_agent_upserted(agent: Any, db: Any, *, is_new: bool) -> None:
    """
    Register or refresh the governance profile for an upserted agent.

    Args:
        agent: The persisted ``echolib.models.Agent`` instance (already
            flushed by the caller).
        db: The AsyncSession from the caller -- MUST NOT be committed here
            since this hook runs within the caller's transaction.
        is_new: Whether this write created the row (True) or updated an
            existing one (False).
    """
    from echolib.service.agent_trust.agent_registry_service import (
        AgentRegistryService,
        is_real_agent,
        node_type_of,
    )

    if not is_real_agent(agent.definition):
        logger.debug(
            "agent_trust_registration_skipped_non_agent_node",
            extra={
                "agent_id": agent.hexaid,
                "node_type": node_type_of(agent.definition),
            },
        )
        return

    service = AgentRegistryService()
    profile = await service.register_agent(
        db=db,
        agent_id=agent.hexaid,
        owner_user_id=str(agent.user_id),
    )

    if is_new or profile is None:
        return

    await service.mark_definition_changed(
        db,
        agent_id=agent.hexaid,
        new_hash=_definition_hash(agent.definition),
    )
