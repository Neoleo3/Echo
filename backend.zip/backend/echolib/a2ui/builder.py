"""
A2UIStreamBuilder

Helper class that produces A2UI v0.8 JSONL strings for the EchoAI execution
step-list surface. All methods return strings or lists of strings, ready to be
put into an asyncio.Queue for SSE streaming.

Surface layout:
  Column
    +-- header (Text h3, data-bound to /title)
    +-- steps  (List, template bound to /steps, each step is a Card)
    |     Card: [step-icon (Icon), step-label (Text h5), step-detail (Text caption),
    |            step-status (Text caption), step-output (Text body, data-bound to /steps[*]/output)]
    +-- output (Card -> output-text (Text body, data-bound to /final_output))

Step dict shape:
  {
    "id":     str,   # unique step identifier
    "icon":   str,   # Material Icons name
    "label":  str,   # human-readable stage name
    "detail": str,   # extra context (may be empty)
    "status": str,   # pending | running | completed | failed | interrupted | skipped
    "output": str,   # rich output data from the stage (JSON string or plain text, may be empty)
  }
"""

from __future__ import annotations

import json
from typing import Any, Dict, List


class A2UIStreamBuilder:
    """
    Builds A2UI v0.8 JSONL messages for the EchoAI execution step-list surface.

    Usage:
        builder = A2UIStreamBuilder()
        # On stream start:
        for line in builder.build_initial_surface(run_id, "My App"):
            await queue.put(line)
        # On each stage change:
        await queue.put(builder.step_update(run_id, steps))
        # On completion:
        await queue.put(builder.final_output_update(run_id, result_text))
    """

    @staticmethod
    def surface_id(run_id: str) -> str:
        return f"exec_{run_id}"

    def build_initial_surface(self, run_id: str, title: str) -> List[str]:
        """
        Returns a list of 3 JSONL lines:
          1. surfaceUpdate   -- component tree definition
          2. dataModelUpdate -- initial empty data model
          3. beginRendering  -- signal client to render
        """
        sid = self.surface_id(run_id)

        surface_update = {
            "type": "surfaceUpdate",
            "surfaceId": sid,
            "catalog": "std:v1",
            "components": [
                {
                    "id": "root",
                    "type": "Column",
                    "children": {"explicitList": ["header", "steps", "output"]},
                },
                {
                    "id": "header",
                    "type": "Text",
                    "content": {"path": "/title"},
                    "hint": "h3",
                },
                {
                    "id": "steps",
                    "type": "List",
                    "children": {
                        "template": {
                            "dataPath": "/steps",
                            "componentType": "Card",
                            "childIds": [
                                "step-icon",
                                "step-label",
                                "step-detail",
                                "step-status",
                                "step-output",
                            ],
                        }
                    },
                },
                {
                    "id": "step-icon",
                    "type": "Icon",
                    "name": {"path": "/steps[*]/icon"},
                },
                {
                    "id": "step-label",
                    "type": "Text",
                    "content": {"path": "/steps[*]/label"},
                    "hint": "h5",
                },
                {
                    "id": "step-detail",
                    "type": "Text",
                    "content": {"path": "/steps[*]/detail"},
                    "hint": "caption",
                },
                {
                    "id": "step-status",
                    "type": "Text",
                    "content": {"path": "/steps[*]/status"},
                    "hint": "caption",
                },
                {
                    "id": "step-output",
                    "type": "Text",
                    "content": {"path": "/steps[*]/output"},
                    "hint": "body",
                },
                {
                    "id": "output",
                    "type": "Card",
                    "children": {"explicitList": ["output-text"]},
                },
                {
                    "id": "output-text",
                    "type": "Text",
                    "content": {"path": "/final_output"},
                    "hint": "body",
                },
            ],
        }

        data_model_update = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {
                "title": title,
                "steps": [],
                "final_output": "",
            },
        }

        begin_rendering = {
            "type": "beginRendering",
            "surfaceId": sid,
            "rootComponentId": "root",
        }

        return [
            json.dumps(surface_update, separators=(",", ":")),
            json.dumps(data_model_update, separators=(",", ":")),
            json.dumps(begin_rendering, separators=(",", ":")),
        ]

    def step_update(self, run_id: str, steps: List[Dict[str, str]]) -> str:
        """
        Returns a single JSONL line: dataModelUpdate with the full steps array.

        Each step dict must have: id, icon, label, detail, status.
        The full array is always sent (client replaces /steps entirely).
        """
        sid = self.surface_id(run_id)
        msg = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {"steps": steps},
        }
        return json.dumps(msg, separators=(",", ":"))

    def output_delta(self, run_id: str, text: str, seq: int) -> str:
        """
        Returns a single JSONL line carrying an incremental fragment of the answer.

        WHAT: ``dataModelUpdate`` setting ``/output_delta`` to ``{seq, text}``.
        WHY:  Until this existed the application stream could only deliver
              ``final_output`` -- the whole answer, once, after every step had
              finished -- so a reader watched a spinner for the entire model
              round trip. This is the channel that makes the application chat
              behave the way Copilot and ChatGPT do: activity first, then the
              answer arriving as it is written.

        A **fragment**, not the running total, with a monotonic ``seq`` the
        client appends in order. The steps array is sent whole because the client
        replaces ``/steps`` outright; doing the same for text would re-send the
        entire answer on every flush, which is quadratic in the answer length.
        SSE preserves order within one response body, so appending is safe; the
        only loss case is a disconnect, which ends the run regardless.

        ``final_output`` still follows and remains the single commit event, so a
        client that ignores this key behaves exactly as it did before.

        Args:
            run_id: Run identifier; selects the surface.
            text: The fragment to append.
            seq: Zero-based index of this fragment within the run.
        """
        sid = self.surface_id(run_id)
        msg = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {"output_delta": {"seq": seq, "text": text}},
        }
        return json.dumps(msg, separators=(",", ":"))

    def final_output_update(self, run_id: str, text: str) -> str:
        """
        Returns a single JSONL line: dataModelUpdate that sets /final_output.
        Call this after all steps are complete.
        """
        sid = self.surface_id(run_id)
        msg = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {"final_output": text},
        }
        return json.dumps(msg, separators=(",", ":"))

    def session_update(self, run_id: str, session_id: str, chat_session_id: str = None) -> str:
        """Returns a JSONL line that sends session_id and chat_session_id to the frontend."""
        sid = self.surface_id(run_id)
        msg = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {
                "session_id": session_id,
                "chat_session_id": chat_session_id or session_id,
            },
        }
        return json.dumps(msg, separators=(",", ":"))

    def title_update(self, run_id: str, title: str) -> str:
        """Returns a JSONL line that updates just the /title field."""
        sid = self.surface_id(run_id)
        msg = {
            "type": "dataModelUpdate",
            "surfaceId": sid,
            "data": {"title": title},
        }
        return json.dumps(msg, separators=(",", ":"))

    def delete_surface(self, run_id: str) -> str:
        """Returns a JSONL line to remove the surface from the client."""
        sid = self.surface_id(run_id)
        msg = {"type": "deleteSurface", "surfaceId": sid}
        return json.dumps(msg, separators=(",", ":"))

    @staticmethod
    def make_step(
        step_id: str,
        icon: str,
        label: str,
        status: str,
        detail: str = "",
        output: str = "",
    ) -> Dict[str, str]:
        """Convenience factory for a step dict.

        Args:
            step_id: Unique step identifier.
            icon: Material Icons name.
            label: Human-readable stage name.
            status: Step status (pending/running/completed/failed/interrupted/skipped).
            detail: Short extra context string (may be empty).
            output: Rich output data from the stage as a string
                (JSON-encoded dict or plain text). Defaults to empty string
                to not break existing callers.
        """
        return {
            "id": step_id,
            "icon": icon,
            "label": label,
            "detail": detail,
            "status": status,
            "output": output,
        }
