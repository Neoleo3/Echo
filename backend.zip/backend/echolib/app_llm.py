"""
Which LLM an application runs on.

WHAT: Reads the single LLM an application is linked to and works out *what kind
      of identifier* it is, so the credential cascade can be entered at the
      right tier.
WHY:  ``app-plan.md`` Issue 3. An application's selected LLM is stored and then
      never used: ``credential_resolver`` reaches app-level credentials only
      through the ``kv://`` Key Vault convention, and that tier sits *below* the
      user's personal default — so for any user who has a credential, which is
      everyone, the application's own choice is unreachable. The platform
      advertises bring-your-own-LLM and silently runs on whatever the chatting
      user happens to have set as their default.

**The identifier is ambiguous, and that is the whole problem.**
``application_llm_links.llm_id`` is a ``String(255)`` that in practice holds one
of four things, because the model picker and the Key Vault route write different
values into the same column::

    "9f3c…"                  a user_llm_credentials UUID   -> Tier 1
    "gpt-4o"                 a model_id slug               -> Tier 1b
    "kv://{app_id}-{role}"   a Key Vault reference         -> existing app tier
    ""                       the picker sent an empty id   -> unresolvable

``GET /llm/models/list`` returns ``{"id": config_metadata.model_id, "credential_id": …}``
per model, and ``config_metadata.model_id`` may be absent — so which of the
first two forms arrives depends on which field the caller picked, and the empty
case is reachable.

Passing a slug where a UUID is expected fails the parse and drops silently to
the user's default. That is precisely the defect ``Plan_1.md`` Phase 6 found in
``knowledge_bases.embedding_model`` (deviation 22), where a column held either a
credential UUID or a model name and the mismatch embedded queries in a different
vector space than the passages. Same trap, same fix: **discriminate, never
guess.**

This module resolves the identifier only. It builds nothing and reads no
secret — the caller passes the result to ``resolve_and_build_llm``, which owns
the cascade and the Key Vault reads exactly as it does today.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional
from uuid import UUID

logger = logging.getLogger(__name__)

SOURCE_CREDENTIAL = "credential"
SOURCE_MODEL_ID = "model_id"
SOURCE_KEY_VAULT = "kv"
SOURCE_NONE = "none"

KV_PREFIX = "kv://"


@dataclass(frozen=True)
class AppLlmSelection:
    """
    The application's chosen LLM, in the form the resolver can act on.

    Exactly one of ``credential_id`` / ``model_id`` is set, or neither when the
    application has made no usable choice.

    ``owner_user_id`` is the application's owner. The chosen credential lives
    in that account, and an application shared with others through RBAC must
    run on the owner's models for every user it is shared with -- never on the
    chatting user's own credentials.
    """

    credential_id: Optional[str] = None
    model_id: Optional[str] = None
    source: str = SOURCE_NONE
    raw: str = ""
    owner_user_id: Optional[str] = None

    @property
    def is_usable(self) -> bool:
        """True when this selection can pin a tier of the credential cascade."""
        return bool(self.credential_id or self.model_id)

    def resolver_kwargs(self) -> Dict[str, Any]:
        """
        The keyword arguments to hand ``resolve_and_build_llm``.

        Always carries ``credential_owner_id`` when the owner is known, so every
        tier of the credential lookup -- the pin, and the default when the
        application pinned nothing -- runs in the owner's account. For the
        owner chatting with their own application that is the caller, so the
        behaviour is unchanged. Empty when neither is known.
        """
        kwargs: Dict[str, Any] = {}
        if self.credential_id:
            kwargs["credential_id"] = self.credential_id
        elif self.model_id:
            kwargs["model_id"] = self.model_id
        if self.owner_user_id:
            kwargs["credential_owner_id"] = self.owner_user_id
        return kwargs

    def describe(self) -> Dict[str, Any]:
        """Identity only — safe to persist on an execution record."""
        return {
            "source": self.source,
            "credential_id": self.credential_id,
            "model_id": self.model_id,
            "owner_user_id": self.owner_user_id,
        }


NONE_SELECTION = AppLlmSelection()


def classify_llm_id(llm_id: Optional[str]) -> AppLlmSelection:
    """
    Decide what an ``llm_id`` is, without querying anything.

    WHAT: Maps the raw column value onto the tier that can resolve it.
    WHY:  Both forms already resolve correctly — Tier 1 for a credential UUID,
          Tier 1b for a model_id slug, and both fall back to platform-owned
          system credentials — but only if the value is handed over as the right
          kind. Guessing wrong is a silent downgrade to the user's default.
    INPUT: The raw ``application_llm_links.llm_id`` value.
    OUTPUT: An :class:`AppLlmSelection`. Never raises.

    A ``kv://`` reference resolves to *neither*: the Key Vault app tier already
    handles it inside the resolver and is deliberately left untouched.
    """
    raw = str(llm_id or "").strip()
    if not raw:
        return NONE_SELECTION

    if raw.lower().startswith(KV_PREFIX):
        return AppLlmSelection(source=SOURCE_KEY_VAULT, raw=raw)

    try:
        UUID(raw)
    except (ValueError, AttributeError, TypeError):
        return AppLlmSelection(model_id=raw, source=SOURCE_MODEL_ID, raw=raw)

    return AppLlmSelection(credential_id=raw, source=SOURCE_CREDENTIAL, raw=raw)


async def resolve_app_llm_selection(
    application_id: Optional[str],
    *,
    db: Any = None,
) -> AppLlmSelection:
    """
    Read the application's linked LLM and classify it.

    WHAT: Loads ``application_llm_links`` for the application, prefers the row
          whose role is ``orchestrator``, and classifies its ``llm_id``.
    WHY:  This is the one place the application's choice becomes actionable.
          Everything downstream simply forwards the result into the existing
          cascade.
    INPUT: The application id; optionally an open session to reuse.
    OUTPUT: An :class:`AppLlmSelection`, never ``None``. An application with no
            link, or an unusable one, yields the neutral selection so the caller
            behaves exactly as it does today.

    Never raises: an application whose LLM cannot be read must still answer, on
    the cascade that served it before.
    """
    if not application_id:
        return NONE_SELECTION

    from dataclasses import replace

    from echolib.models.application import Application, ApplicationLlmLink
    from echolib.repositories.base import safe_uuid
    from sqlalchemy import select

    app_uuid = safe_uuid(str(application_id))
    if app_uuid is None:
        return NONE_SELECTION

    stmt = select(ApplicationLlmLink).where(
        ApplicationLlmLink.application_id == app_uuid
    )
    owner_stmt = select(Application.user_id).where(
        Application.application_id == app_uuid
    )

    async def _read(session: Any) -> Any:
        link_rows = (await session.execute(stmt)).scalars().all()
        owner = (await session.execute(owner_stmt)).scalar_one_or_none()
        return link_rows, owner

    try:
        if db is not None:
            rows, owner = await _read(db)
        else:
            from echolib.database import get_db_session

            async with get_db_session() as session:
                rows, owner = await _read(session)
    except Exception:
        logger.warning(
            "Could not read the LLM link for application %s; "
            "orchestration falls back to the existing credential cascade",
            application_id,
            exc_info=True,
        )
        return NONE_SELECTION

    owner_user_id = str(owner) if owner else None

    if not rows:
        return replace(NONE_SELECTION, owner_user_id=owner_user_id)

    # One LLM per application is the rule (app-plan.md Decision 4), but rows
    # written before that rule may still be plural. Prefer the orchestrator
    # role, then whatever is first, so behaviour is deterministic either way.
    chosen = next(
        (r for r in rows if str(getattr(r, "role", "") or "").lower() == "orchestrator"),
        rows[0],
    )

    selection = replace(
        classify_llm_id(getattr(chosen, "llm_id", "")), owner_user_id=owner_user_id
    )

    if selection.source == SOURCE_NONE:
        logger.warning(
            "Application %s has an LLM link with an empty identifier; "
            "orchestration falls back to the application owner's default credential. "
            "Re-select the model for this application to fix it.",
            application_id,
        )
    elif len(rows) > 1:
        logger.warning(
            "Application %s has %d LLM links; using role='%s' (%s). "
            "One LLM per application is the supported configuration.",
            application_id, len(rows), getattr(chosen, "role", ""), selection.source,
        )

    return selection


__all__ = [
    "NONE_SELECTION",
    "SOURCE_CREDENTIAL",
    "SOURCE_KEY_VAULT",
    "SOURCE_MODEL_ID",
    "SOURCE_NONE",
    "AppLlmSelection",
    "classify_llm_id",
    "resolve_app_llm_selection",
]
