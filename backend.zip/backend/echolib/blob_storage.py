"""
Blob Storage Helper — Azure Blob upload/download for file-based DB persistence.

Ensures SQLite/DuckDB files uploaded via the connector endpoint survive
container restarts on Azure App Service (ephemeral filesystem).

Environment Variables:
    AZURE_BLOB_ACCOUNT_URL: e.g. https://<account>.blob.core.windows.net
    AZURE_BLOB_SAS_TOKEN:   SAS token (without leading '?').  Generated via
        Azure Portal → Storage Account → Shared access signature.
    AZURE_BLOB_CONTAINER_NAME: container name (default: echo-connector-files)
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

LOG = logging.getLogger(__name__)

_CONNECTION_STRING: Optional[str] = None
_CONTAINER_NAME: Optional[str] = None
_client = None  # Lazy-initialised ContainerClient


def _get_config():
    global _CONNECTION_STRING, _CONTAINER_NAME

    if _CONNECTION_STRING is None:
        _CONNECTION_STRING = os.getenv(
            "AZURE_STORAGE_CONNECTION_STRING",
            "",
        )

        _CONTAINER_NAME = os.getenv(
            "AZURE_BLOB_CONTAINER_NAME",
            "",
        )

    return _CONNECTION_STRING, _CONTAINER_NAME


def _is_configured() -> bool:
    connection_string, _ = _get_config()
    return bool(connection_string)


def _get_container_client():
    global _client

    if _client is not None:
        return _client

    connection_string, container = _get_config()

    if not connection_string:
        return None

    try:
        from azure.storage.blob import BlobServiceClient

        service = BlobServiceClient.from_connection_string(
            connection_string
        )

        _client = service.get_container_client(container)

        return _client

    except Exception as exc:
        LOG.warning("Blob storage init failed: %s", exc)
        return None



def upload_to_blob(local_path: str | Path, blob_name: str) -> bool:
    """
    Upload a local file to Azure Blob Storage.

    Args:
        local_path: Absolute path to the local file.
        blob_name: Blob key (e.g. 'connector-dbs/{uuid}.db').

    Returns:
        True if upload succeeded, False otherwise.
    """
    if not _is_configured():
        return False
    container = _get_container_client()
    if not container:
        return False
    try:
        local_path = Path(local_path)
        with open(local_path, "rb") as fh:
            container.upload_blob(name=blob_name, data=fh, overwrite=True)
        LOG.info(
            "[AZURE_BLOB] File uploaded successfully. blob=%s size=%d bytes",
            blob_name,
            local_path.stat().st_size,
        )
        return True
    except Exception as exc:
        LOG.warning("Blob upload failed for %s: %s", blob_name, exc)
        return False


def download_from_blob(blob_name: str, local_path: str | Path) -> bool:
    """
    Download a blob to a local file path.

    Creates parent directories if needed.

    Args:
        blob_name: Blob key to download.
        local_path: Target local file path.

    Returns:
        True if download succeeded and file exists, False otherwise.
    """
    if not _is_configured():
        return False
    container = _get_container_client()
    if not container:
        return False
    try:
        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        blob_client = container.get_blob_client(blob_name)
        with open(local_path, "wb") as fh:
            stream = blob_client.download_blob()
            stream.readinto(fh)
        LOG.info(
            "[AZURE_BLOB] File restored from Azure Blob. blob=%s local=%s",
            blob_name,
            local_path,
        )
        return True
    except Exception as exc:
        LOG.warning("Blob download failed for %s: %s", blob_name, exc)
        return False


def blob_exists(blob_name: str) -> bool:
    """Check if a blob exists in the container."""
    if not _is_configured():
        return False
    container = _get_container_client()
    if not container:
        return False
    try:
        blob_client = container.get_blob_client(blob_name)
        blob_client.get_blob_properties()
        return True
    except Exception:
        return False


def derive_blob_name_from_path(file_path: str | Path) -> str:
    """
    Derive the blob name from a local file path.

    Convention: connector-dbs/{filename}
    e.g. /app/apps/connector/uploads/abc123.db → connector-dbs/abc123.db
    """
    return f"connector-dbs/{Path(file_path).name}"


def get_blob_url(blob_name: str) -> str:
    account_url = os.getenv(
        "AZURE_BLOB_ACCOUNT_URL",
        ""
    ).rstrip("/")

    sas_token = os.getenv(
        "AZURE_BLOB_SAS_TOKEN",
        ""
    ).lstrip("?")

    _, container_name = _get_config()

    if not account_url or not container_name:
        return ""

    url = (
        f"{account_url}/"
        f"{container_name}/"
        f"{blob_name}"
    )

    if sas_token:
        url = f"{url}?{sas_token}"

        LOG.info(
            "ACCOUNT_URL=%s",
            account_url,
            )
        
        LOG.info(
            "CONTAINER_NAME=%s",
            container_name,
        )

        LOG.info(
            "SAS_TOKEN=%s",
            sas_token,
        )
        LOG.info(
            "SAS length=%s", 
            len(sas_token)
        )

        LOG.info(
            "FINAL_URL=%s",
            url,
        )

    return url

