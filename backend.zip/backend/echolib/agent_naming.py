"""
Agent naming rules — specification section 7.4, Rule 2.

Agent names are plainly descriptive of function, the way production assistants
(Copilot, ChatGPT) name them: Title Case, 2-5 words, no trailing punctuation,
no quotes. The previous generation prompt demanded the opposite ("creative,
memorable" names such as "CodeCraft Pro"), which is the defect this module and
the structured generation path replace.

Two consumers need identical rules, so they live here rather than in the
designer package:

    apps/agent/designer/generation   normalizes the generated name
    echolib/repositories/agent_repo  disambiguates a colliding name

``agent_repo`` must not import from ``apps.*`` (Finding 13), which is why this
is an echolib module. It is pure: no I/O, no database, no mutation of inputs.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, List

# Rule 2: concise, 2-5 words.
MAX_NAME_WORDS = 5

# agents.name is String(255); keep well inside it and inside what a UI can show.
MAX_NAME_CHARS = 100

FALLBACK_AGENT_NAME = "Custom Agent"

_QUOTE_CHARS = "\"'“”‘’`"
_TRAILING_PUNCTUATION = ".,;:!?-–—"

# Command framing stripped only on the deterministic no-LLM path. On the LLM
# path Rule 1 removes it during generation — regex-scraping model output is the
# anti-pattern specification section 7.1 rules out.
_LEADING_COMMAND = re.compile(
    r"^(?:please\s+)?"
    r"(?:(?:can|could|would)\s+you\s+)?"
    r"(?:i\s+(?:want|need|would\s+like)\s+)?"
    r"(?:(?:to\s+)?(?:create|make|build|design|generate|set\s+up|give|call|name)\s+)?"
    r"(?:me\s+)?"
    # Word boundary matters: without the trailing space this eats the "a" of
    # "agent" and leaves "gent".
    r"(?:(?:an?|the)\s+)?",
    re.IGNORECASE,
)

_STOP_WORDS = frozenset({
    "a", "an", "the", "for", "with", "that", "this", "and", "or", "of", "to",
    "in", "on", "at", "by", "from", "into", "about", "it", "its", "my", "our",
    "me", "we", "us", "is", "are", "be", "will", "should", "can", "which",
    "who", "what", "when", "where", "how", "agent", "bot", "assistant", "ai",
})


def _coerce(value: Any) -> str:
    """Coerce any value to a stripped string, treating None as empty."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return str(value).strip()


def _strip_wrapping_quotes(text: str) -> str:
    """Remove matched or stray wrapping quote characters."""
    while len(text) >= 2 and text[0] in _QUOTE_CHARS and text[-1] in _QUOTE_CHARS:
        text = text[1:-1].strip()
    return text.strip(_QUOTE_CHARS).strip()


def _title_case_word(word: str) -> str:
    """Title-case a word while preserving acronyms and deliberate casing."""
    if not word:
        return word
    # "KGS", "CRM", "OKRs", "eCommerce" keep the casing the user chose.
    if word.islower():
        return word[0].upper() + word[1:]
    return word


def normalize_agent_name(value: Any, *, fallback: str = FALLBACK_AGENT_NAME) -> str:
    """
    Apply Rule 2 formatting to a name.

    Formatting only — meaning extraction (stripping "give name ...") is the
    generation model's job under Rule 1. This never rewrites words, it only
    normalizes casing, whitespace, quoting, punctuation and length.

    Args:
        value: Candidate name from any source.
        fallback: Returned when nothing usable remains.

    Returns:
        A Rule 2 conformant name.
    """
    text = _coerce(value)
    if not text:
        return fallback

    text = re.sub(r"\s+", " ", text)
    text = _strip_wrapping_quotes(text)
    text = text.strip().strip(_TRAILING_PUNCTUATION).strip()
    if not text:
        return fallback

    words = [_title_case_word(word) for word in text.split(" ") if word]
    if not words:
        return fallback

    if len(words) > MAX_NAME_WORDS:
        words = words[:MAX_NAME_WORDS]

    name = " ".join(words).strip(_TRAILING_PUNCTUATION).strip()

    if len(name) > MAX_NAME_CHARS:
        cut = name[:MAX_NAME_CHARS].rsplit(" ", 1)[0].strip()
        name = cut or name[:MAX_NAME_CHARS].strip()

    return name or fallback


def derive_fallback_name(prompt: Any, *, fallback: str = FALLBACK_AGENT_NAME) -> str:
    """
    Derive a name deterministically, without an LLM.

    Used only when generation is unavailable, so that the degraded path still
    produces something recognizable instead of the literal string "Custom
    Agent" for every agent a user creates during an outage.

    Args:
        prompt: The user's original description.
        fallback: Returned when no meaningful words survive.

    Returns:
        A Rule 2 conformant name derived from the prompt.
    """
    text = _coerce(prompt)
    if not text:
        return fallback

    # First clause only — what follows describes behavior, not identity.
    text = re.split(r"[.!?\n,;]", text, maxsplit=1)[0]

    # Twice, because requests stack framing: "give name sales insight" is a
    # verb followed by a second framing word.
    for _ in range(2):
        stripped = _LEADING_COMMAND.sub("", text, count=1).strip()
        if stripped == text:
            break
        text = stripped

    words: List[str] = []
    for raw in text.split():
        word = raw.strip(_QUOTE_CHARS + _TRAILING_PUNCTUATION + "()[]{}")
        if not word or not any(ch.isalnum() for ch in word):
            continue
        if word.lower() in _STOP_WORDS:
            continue
        words.append(word)
        if len(words) >= 4:
            break

    if not words:
        return fallback

    return normalize_agent_name(" ".join(words), fallback=fallback)


def disambiguate_name(name: Any, taken: Iterable[Any]) -> str:
    """
    Resolve a name collision deterministically by numeric suffix.

    Rule 2 names are less distinctive than the invented ones they replace, so
    collisions against ``UniqueConstraint(user_id, name)`` become more likely.
    The write boundary previously resolved a collision by overwriting the other
    agent's row; appending a suffix keeps both agents.

    Comparison is case-insensitive because the constraint is not, and a
    case-variant name would still read as a duplicate to the user.

    Args:
        name: Desired name.
        taken: Names already in use by this user.

    Returns:
        ``name`` when free, otherwise ``"<name> 2"``, ``"<name> 3"``, ...
    """
    base = normalize_agent_name(name)
    used = {_coerce(item).casefold() for item in taken if _coerce(item)}

    if base.casefold() not in used:
        return base

    # Bounded by the number of conflicting rows, so a free suffix always exists.
    for suffix in range(2, len(used) + 3):
        candidate = f"{base} {suffix}"
        if len(candidate) > MAX_NAME_CHARS:
            trimmed = base[: MAX_NAME_CHARS - len(str(suffix)) - 1].strip()
            candidate = f"{trimmed} {suffix}"
        if candidate.casefold() not in used:
            return candidate

    return base


__all__ = [
    "FALLBACK_AGENT_NAME",
    "MAX_NAME_CHARS",
    "MAX_NAME_WORDS",
    "derive_fallback_name",
    "disambiguate_name",
    "normalize_agent_name",
]
