/**
 * PowerPoint Generator using pptxgenjs
 * 
 * Accepts JSON input via stdin or command-line argument.
 * Generates PPTX file and outputs file path.
 * 
 * Usage:
 *   node pptgen.js '{"title": "My PPT", ...}'
 *   echo '{"title": "My PPT", ...}' | node pptgen.js
 */

import PptxGenJs from 'pptxgenjs';
import fs from 'fs';
import path from 'path';

/**
 * Main PPT generation function
 */
async function generatePPT(configStr) {
  try {
    // Parse input
    const config = JSON.parse(configStr);
    
    // Validate config
    if (!config.title) {
      throw new Error('title is required');
    }
    
    // Create presentation
    const prs = new PptxGenJs();
    
    // Configure presentation
    prs.defineLayout({ 
      name: 'WIDESCREEN', 
      width: parseFloat(config.slide_width || 13.333), 
      height: parseFloat(config.slide_height || 7.5) 
    });
    prs.defineLayout({
      name: 'LAYOUT1',
      width: 13.333,
      height: 7.5
    });
    
    // Apply theme
    applyTheme(prs, config.theme || {});
    
    // Add title slide
    addTitleSlide(prs, config);
    
    // Add content slides
    if (config.slides && Array.isArray(config.slides)) {
      for (const slide of config.slides) {
        addContentSlide(prs, slide, config.theme || {});
      }
    }
    
    // Generate output file
    const outputDir = config.output_dir || '/tmp/echo_ppt';
    const fileName = sanitizeFileName(config.title);
    const filePath = path.join(outputDir, `${fileName}.pptx`);
    
    // Ensure directory exists
    fs.mkdirSync(outputDir, { recursive: true });
    
    // Save presentation
    await prs.writeFile({ fileName: filePath });
    
    // Output result as JSON
    console.log(JSON.stringify({
      success: true,
      file_path: filePath,
      filename: `${fileName}.pptx`,
      file_id: generateFileId(),
      message: 'PPT generated successfully'
    }));
    
  } catch (error) {
    console.error(JSON.stringify({
      success: false,
      error: error.message,
      stack: error.stack
    }));
    process.exit(1);
  }
}

/**
 * Apply theme configuration to presentation
 */
function applyTheme(prs, theme) {\n  if (!theme) return;
  
  // Set master slide colors
  if (theme.primary_color) {
    prs.theme = {
      name: 'echo',
      colorScheme: {
        accent1: theme.primary_color,
        accent2: theme.accent_color || '2E75B6'
      }
    };
  }
}

/**
 * Add title slide
 */
function addTitleSlide(prs, config) {
  const slide = prs.addSlide();
  
  const theme = config.theme || {};
  const colors = {
    primary_dark: theme.primary_dark || '1F4E79',
    white: theme.white || 'FFFFFF',
  };
  const fonts = {
    title_main: parseInt(theme.title_main_size || 44),
    title_subtitle: parseInt(theme.title_subtitle_size || 24),
  };
  
  // Background
  slide.background = { color: colors.primary_dark };
  
  // Title
  slide.addText(config.title, {
    x: 0.5,
    y: 2.5,
    w: 12.333,
    h: 1.5,
    fontSize: fonts.title_main,
    bold: true,
    color: colors.white,
    align: 'center',
    valign: 'middle'
  });
  
  // Subtitle
  if (config.subtitle) {
    slide.addText(config.subtitle, {
      x: 0.5,
      y: 4.2,
      w: 12.333,
      h: 0.8,
      fontSize: fonts.title_subtitle,
      color: colors.white,
      align: 'center',
      valign: 'middle'
    });
  }
}

/**
 * Add content slide
 */
function addContentSlide(prs, slideConfig, theme) {
  const slide = prs.addSlide();
  
  const colors = {
    primary_dark: theme.primary_dark || '1F4E79',
    primary_light: theme.primary_light || '2E75B6',
    body: theme.body_color || '202020',
    white: theme.white || 'FFFFFF',
    light_grey: theme.light_grey || 'DEEBF7',
  };
  const fonts = {
    heading: parseInt(theme.slide_title_size || 28),
    body: parseInt(theme.body_size || 14),
    bullet: parseInt(theme.bullet_size || 14),
  };
  
  // Background
  slide.background = { color: colors.white };
  
  // Header bar
  slide.addShape(prs.ShapeType.rect, {
    x: 0,
    y: 0,
    w: '100%',
    h: 0.8,
    fill: { color: colors.primary_dark },
    line: { type: 'none' }
  });
  
  // Title
  slide.addText(slideConfig.title || '', {
    x: 0.5,
    y: 0.15,
    w: 12.333,
    h: 0.5,
    fontSize: fonts.heading,
    bold: true,
    color: colors.white,
    align: 'left',
    valign: 'middle'
  });
  
  let yPos = 1.1;
  
  // Content text
  if (slideConfig.content) {
    slide.addText(slideConfig.content, {
      x: 0.8,
      y: yPos,
      w: 11.733,
      h: 1.2,\n      fontSize: fonts.body,
      color: colors.body,
      align: 'left',
      valign: 'top',
      wordWrap: true
    });
    yPos += 1.4;
  }
  
  // Bullet points
  if (slideConfig.bullet_points && Array.isArray(slideConfig.bullet_points)) {
    const bullets = slideConfig.bullet_points.map(point => ({
      text: point,
      level: 0
    }));
    
    slide.addText(bullets, {
      x: 0.8,
      y: yPos,
      w: 11.733,
      h: 4.5,
      fontSize: fonts.bullet,
      color: colors.body,
      bullet: true,
      align: 'left',
      valign: 'top',
      wordWrap: true
    });
  }
  
  // Table
  if (slideConfig.table_data && slideConfig.table_data.headers) {
    addTableToSlide(slide, slideConfig.table_data, colors, fonts);
  }
}

/**
 * Add table to slide
 */
function addTableToSlide(slide, tableData, colors, fonts) {
  const headers = tableData.headers || [];
  const rows = tableData.rows || [];
  
  // Convert to pptxgenjs table format
  const tableRows = [
    headers.map(h => ({
      text: h,
      fill: { color: colors.primary_dark },
      color: colors.white,
      bold: true,
      fontSize: fonts.table_header || 11
    })),
    ...rows.map(row =>
      row.map((cell, idx) => ({
        text: String(cell),
        fill: { color: idx % 2 === 0 ? colors.light_grey : colors.white },
        color: colors.body,
        fontSize: fonts.table_body || 10
      }))
    )
  ];
  
  slide.addTable(tableRows, {
    x: 0.8,
    y: 2.0,
    w: 11.733,
    h: 4.5,
    border: { pt: 1, color: 'CCCCCC' },
    align: 'center'
  });
}

/**
 * Sanitize filename
 */
function sanitizeFileName(name) {
  return name
    .replace(/[^a-zA-Z0-9\s\-_]/g, '')
    .replace(/\s+/g, '_')
    .substring(0, 50)
    .toLowerCase() || 'presentation';
}

/**
 * Generate file ID
 */
function generateFileId() {
  return 'file_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Parse input from command line or stdin
 */
async function main() {
  let input = process.argv[2];
  
  if (!input) {
    // Read from stdin
    const chunks = [];
    for await (const chunk of process.stdin) {
      chunks.push(chunk);
    }
    input = Buffer.concat(chunks).toString();
  }
  
  if (!input) {
    console.error('No input provided');
    process.exit(1);
  }
  
  await generatePPT(input);
}

// Run
main().catch(error => {
  console.error(JSON.stringify({
    success: false,
    error: error.message
  }));
  process.exit(1);
});
