"""
Word (.docx) report generator using Doxygen.

Uses Doxygen for professional document generation via RTF → DOCX conversion.
All styling is configurable, with ZERO hardcoding.
"""

from __future__ import annotations

import io
import logging
import os
import re
import uuid
from typing import Any, Dict, List, Optional, Set, Tuple

from ..config import get_config
from ..exceptions import InvalidDocumentStructureError
from .doxygen_handler import DoxygenHandler
from .doxygen_input_builder import DoxygenInputBuilder

logger = logging.getLogger(__name__)

_NOT_DISCLOSED = "Not disclosed in provided documents"
_PLACEHOLDER_CELL = re.compile(
    r"^placeholder(\s+for\s+[\w\s,.'-]+)?$",
    re.IGNORECASE,
)


def _sanitize_docx_text(val: Any) -> str:
    """Replace LLM placeholder tokens with grounded wording."""
    if val is None:
        return _NOT_DISCLOSED
    s = str(val).strip()
    if not s:
        return _NOT_DISCLOSED
    low = s.lower()
    if low == "placeholder" or _PLACEHOLDER_CELL.match(s):
        return _NOT_DISCLOSED
    if "placeholder" in low:
        return _NOT_DISCLOSED
    return s


def _coerce_chart_scalar(v: Any) -> float:
    """Parse numeric chart values from ints, floats, or strings like '(274,594)' or '435,713'."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        try:
            x = float(v)
        except (TypeError, ValueError, OverflowError):
            return 0.0
        if x != x or x in (float("inf"), float("-inf")):  # NaN / inf
            return 0.0
        return x
    s = str(v).strip()
    if not s:
        return 0.0
    low = s.lower()
    if "not disclosed" in low or low in ("n/a", "-", "—", "n.a.", "na"):
        return 0.0
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1].strip()
    for sym in (",", "₹", "$", "€", "%"):
        s = s.replace(sym, "")
    s = s.strip()
    try:
        x = float(s)
        return -x if neg else x
    except ValueError:
        return 0.0


def _align_chart_labels_values(ch: Dict[str, Any]) -> Dict[str, Any]:
    """
    LLMs often emit len(labels) > len(values). Align by trimming the longer list
    (prefer keeping trailing labels, which are usually period labels).
    When labels is empty but values is non-empty, auto-generate numeric labels.
    Heatmaps use ``matrix`` + optional ``row_labels`` / ``col_labels`` — do not trim.
    """
    ct = str(ch.get("chart_type") or "").lower()
    if ct == "heatmap":
        return dict(ch)
    labels = [str(x) for x in (ch.get("labels") or [])]
    vals_raw = ch.get("values") or []
    values: List[float] = []
    for v in vals_raw:
        values.append(_coerce_chart_scalar(v))
    nl, nv = len(labels), len(values)
    # Auto-generate labels when values are present but labels are missing
    if nl == 0 and nv > 0:
        labels = [str(i + 1) for i in range(nv)]
        return {**ch, "labels": labels, "values": values}
    if nl == 0 or nv == 0:
        return {**ch, "labels": labels, "values": values}
    if nl > nv:
        logger.info(
            "Chart %r: %d labels vs %d values — trimming labels to match",
            ch.get("title"),
            nl,
            nv,
        )
        labels = labels[nl - nv :]
    elif nv > nl:
        logger.info(
            "Chart %r: %d labels vs %d values — trimming values to match",
            ch.get("title"),
            nl,
            nv,
        )
        values = values[nv - nl :]
    return {**ch, "labels": labels, "values": values}


_FY_VALUE_LINE = re.compile(
    r"^\s*(FY\s*\d{2,4}(?:[-–]\d{2,4})?)\s+(\d+(?:\.\d+)?)\s*$",
    re.IGNORECASE,
)

# Prefer these header substrings for the Y-axis column (column 0 = categories).
_CHART_VALUE_HEADER_HINT = re.compile(
    r"(z[-\s]?score|outlier|anomaly|score|value|amount|revenue|growth|"
    r"pct|percent|%|qty|quantity|headcount|count|total|mean|median|std|"
    r"variance|delta|change|rate|index|yoy|mom)",
    re.IGNORECASE,
)


def _pick_chart_value_column_index(headers: List[str], rows: List[Any]) -> int:
    """
    Choose which column holds numeric values for auto-charts. Column 0 is labels.
    Multi-column tables often put text in column 1 (e.g. Zone) and metrics in column 2+;
    always using row[1] coerces text to 0 and yields empty-looking bar charts.
    """
    max_w = 0
    for row in rows:
        if isinstance(row, (list, tuple)):
            max_w = max(max_w, len(row))
    if max_w < 2:
        return 1
    ncols = max(max_w, len(headers))
    # Header-based preference (exact column when headers align)
    for j in range(1, min(len(headers), ncols)):
        h = str(headers[j] or "").strip()
        if h and _CHART_VALUE_HEADER_HINT.search(h):
            return j
    # Scan all data columns for strongest numeric signal (sum of |coerced|)
    best_j, best_score = 1, -1.0
    for j in range(1, ncols):
        total_abs = 0.0
        for row in rows:
            if not isinstance(row, (list, tuple)) or len(row) <= j:
                continue
            total_abs += abs(_coerce_chart_scalar(row[j]))
        if total_abs > best_score:
            best_score = total_abs
            best_j = j
    return best_j


def _coerce_matrix(m: Any) -> List[List[float]]:
    """Parse a 2-D numeric matrix from JSON (list of lists)."""
    if not isinstance(m, list) or not m:
        return []
    out: List[List[float]] = []
    for row in m:
        if isinstance(row, (list, tuple)):
            out.append([_coerce_chart_scalar(x) for x in row])
        else:
            return []
    return out


def _heatmap_matrix_from_chart(ch: Dict[str, Any]) -> Tuple[List[List[float]], List[str], List[str]]:
    """
    Build row-major matrix and axis labels for a heatmap.

    Prefer explicit ``matrix`` (list of rows). Otherwise accept ``labels`` + flat
    ``values`` of length n*n (square correlation grid) or length n (single-row strip).
    """
    matrix = _coerce_matrix(ch.get("matrix"))
    row_labels = [str(x).strip() for x in (ch.get("row_labels") or [])]
    col_labels = [str(x).strip() for x in (ch.get("col_labels") or [])]
    labels = [str(x).strip() for x in (ch.get("labels") or [])]
    vals = [_coerce_chart_scalar(v) for v in (ch.get("values") or [])]

    if matrix:
        n_r, n_c = len(matrix), len(matrix[0]) if matrix else 0
        if not n_c or any(len(row) != n_c for row in matrix):
            return [], [], []
        if not row_labels:
            row_labels = labels[:n_r] if len(labels) >= n_r else [f"R{i + 1}" for i in range(n_r)]
        if not col_labels:
            col_labels = (
                labels[:n_c]
                if len(labels) >= n_c
                else [f"C{i + 1}" for i in range(n_c)]
            )
        return matrix, row_labels[:n_r], col_labels[:n_c]

    n = len(labels)
    if n > 0 and len(vals) == n * n:
        mat = [vals[i * n : (i + 1) * n] for i in range(n)]
        return mat, list(labels), list(labels)

    if n > 0 and len(vals) == n:
        return [vals], ["Series"], list(labels)

    return [], [], []


def _render_heatmap_png(
    title: str,
    matrix: List[List[float]],
    row_labels: List[str],
    col_labels: List[str],
) -> Optional[bytes]:
    if not matrix or not matrix[0]:
        return None
    n_r, n_c = len(matrix), len(matrix[0])
    if any(len(row) != n_c for row in matrix):
        return None
    while len(row_labels) < n_r:
        row_labels.append(f"R{len(row_labels) + 1}")
    while len(col_labels) < n_c:
        col_labels.append(f"C{len(col_labels) + 1}")
    row_labels = row_labels[:n_r]
    col_labels = col_labels[:n_c]

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not available; skipping heatmap")
        return None

    flat = [x for row in matrix for x in row]
    vmin, vmax = min(flat), max(flat)
    if vmin == vmax:
        vmax = vmin + 1e-9
    has_neg = vmin < -1e-9
    has_pos = vmax > 1e-9
    if has_neg and has_pos:
        cmap_name = "RdBu_r"
        mx = max(abs(vmin), abs(vmax), 1e-9)
        vmin, vmax = -mx, mx
    elif not has_neg and vmax <= 1.0 + 1e-6:
        cmap_name = "Blues"
        vmin, vmax = 0.0, max(1.0, vmax)
    else:
        cmap_name = "viridis"

    try:
        w = max(7.5, 0.45 * n_c + 2.5)
        h = max(4.0, 0.4 * n_r + 2.0)
        fig, ax = plt.subplots(figsize=(w, h))
        im = ax.imshow(matrix, cmap=cmap_name, vmin=vmin, vmax=vmax, aspect="auto")
        for i in range(n_r):
            for j in range(n_c):
                v = matrix[i][j]
                txt = f"{v:.3g}" if abs(v) < 1000 else f"{v:.3e}"
                ax.text(j, i, txt, ha="center", va="center", fontsize=8, color="#1a1a1a")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ax.set_xticks(range(n_c))
        ax.set_yticks(range(n_r))
        ax.set_xticklabels(col_labels, rotation=35, ha="right")
        ax.set_yticklabels(row_labels)
        if title:
            ax.set_title(title[:120])
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
        plt.close(fig)
        raw = buf.getvalue()
        if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
            logger.error("Heatmap %r: invalid PNG (%d bytes)", title, len(raw))
            return None
        return raw
    except Exception:
        logger.exception("Heatmap render failed")
        try:
            plt.close("all")
        except Exception:
            pass
        return None


def _render_chart_png(
    title: str,
    labels: List[str],
    values: List[float],
    chart_type: str = "bar",
) -> Optional[bytes]:
    """Bar or line chart. Unknown types default to bar."""
    # Need at least values to plot something
    if not values:
        return None
    # Auto-generate numeric labels when the LLM omitted them
    if not labels:
        labels = [str(i + 1) for i in range(len(values))]
    # Auto-align mismatched lengths by trimming to the shorter list
    if len(labels) != len(values):
        min_len = min(len(labels), len(values))
        labels = labels[:min_len]
        values = values[:min_len]
        logger.info(
            "Chart %r: auto-trimmed to %d point(s) to align labels/values",
            title,
            min_len,
        )
    if not labels:
        return None
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not available; skipping chart")
        return None

    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    ct = (chart_type or "bar").lower()
    if ct not in ("line", "bar"):
        ct = "bar"
    try:
        if ct == "line":
            ax.plot(range(len(labels)), values, marker="o", color="#2E5090")
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=35, ha="right")
        else:
            ax.bar(range(len(labels)), values, color="#2E5090")
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=35, ha="right")
        if title:
            ax.set_title(title[:120])
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
        plt.close(fig)
        raw = buf.getvalue()
        if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
            logger.error("Chart %r: matplotlib produced invalid PNG (%d bytes)", title, len(raw))
            return None
        return raw
    except Exception:
        logger.exception("Chart render failed")
        try:
            plt.close("all")
        except Exception:
            pass
        return None


def _render_chart_image(title: str, ch: Dict[str, Any]) -> Optional[bytes]:
    """Dispatch bar, line, or heatmap (matrix) to PNG bytes."""
    ct = str(ch.get("chart_type") or "bar").lower()
    if ct == "heatmap":
        matrix, rows, cols = _heatmap_matrix_from_chart(ch)
        if matrix:
            return _render_heatmap_png(title, matrix, rows, cols)
        logger.warning("Heatmap %r: missing or invalid matrix / labels+values", title)
        return None
    labels = [str(x) for x in (ch.get("labels") or [])]
    vals_raw = ch.get("values") or []
    values = [_coerce_chart_scalar(v) for v in vals_raw]
    return _render_chart_png(title, labels, values, ct)


def _charts_are_renderable(charts: List[Dict[str, Any]]) -> bool:
    """True if at least one chart has aligned labels/values and can be drawn."""
    for ch in charts or []:
        if not isinstance(ch, dict):
            continue
        ch2 = _align_chart_labels_values(dict(ch))
        ct = str(ch2.get("chart_type") or "").lower()
        if ct == "heatmap":
            if _coerce_matrix(ch2.get("matrix")):
                return True
            labs = [str(x) for x in (ch2.get("labels") or [])]
            vals = [_coerce_chart_scalar(v) for v in (ch2.get("values") or [])]
            n = len(labs)
            if n > 0 and len(vals) == n * n:
                return True
            if n > 0 and len(vals) == n:
                return True
            continue
        labels = ch2.get("labels") or []
        values = ch2.get("values") or []
        if len(values) > 0 and len(labels) == len(values):
            return True
    return False


def _auto_charts_from_table(table: Any) -> List[Dict[str, Any]]:
    """
    Build one bar/line chart from a table: labels from column 0, values from an
    auto-detected numeric column (header hints like Z-score, else max |value|).
    """
    if not isinstance(table, dict):
        return []
    headers = [str(h).strip() for h in (table.get("headers") or [])]
    rows = table.get("rows") or []
    if not rows:
        return []
    max_w = max(
        (len(r) if isinstance(r, (list, tuple)) else 0) for r in rows
    )
    if max_w < 2:
        return []
    vc = _pick_chart_value_column_index(headers, rows)
    labels: List[str] = []
    values: List[float] = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 2:
            continue
        labels.append(str(row[0]).strip())
        if len(row) > vc:
            values.append(_coerce_chart_scalar(row[vc]))
        else:
            values.append(0.0)
    if not labels:
        return []
    vh = headers[vc] if vc < len(headers) else f"Column {vc}"
    title = f"{vh} by {headers[0]}" if headers else vh
    lab_joined = " ".join(labels[:3]).upper()
    ct = (
        "line"
        if ("FY" in lab_joined or "20" in lab_joined)
        else "bar"
    )
    return [
        {
            "title": title[:120],
            "labels": labels,
            "values": values,
            "chart_type": ct,
        }
    ]


def _parse_fy_series_from_body(body: Any) -> List[Dict[str, Any]]:
    """
    Detect lines like 'FY26  250' or 'FY26\t250' embedded in narrative (no JSON table).
    """
    if not isinstance(body, str) or not body.strip():
        return []
    labels: List[str] = []
    values: List[float] = []
    for line in body.splitlines():
        line = line.strip()
        if not line or line.lower().startswith("fiscal year"):
            continue
        m = _FY_VALUE_LINE.match(line)
        if m:
            labels.append(m.group(1).strip().replace(" ", ""))
            values.append(_coerce_chart_scalar(m.group(2)))
    if len(labels) < 2:
        return []
    return [
        {
            "title": "Outlook (values parsed from narrative)",
            "labels": labels,
            "values": values,
            "chart_type": "line",
        }
    ]


def _parse_inline_kv_series_from_body(
    body: Any,
) -> Tuple[List[Dict[str, Any]], Set[str]]:
    """
    Parse LLM prose lines like:
      'Indian IT Industry Growth Projections: FY24=200, FY25=220, FY26=240'
      'IT Export Distribution by Region: USA=60, Europe=25, APAC/Middle East=15'
    Each line with a title, colon, and at least two comma-separated key=value pairs
    becomes one chart.

    Returns (charts, matched_line_strips) so callers can remove duplicate prose lines.
    """
    matched: Set[str] = set()
    if not isinstance(body, str) or not body.strip():
        return [], matched
    out: List[Dict[str, Any]] = []
    for line in body.splitlines():
        raw = line
        line = line.strip()
        if ":" not in line or "=" not in line:
            continue
        title_part, rest = line.split(":", 1)
        rest = rest.strip()
        if rest.count("=") < 2:
            continue
        labels: List[str] = []
        values: List[float] = []
        for segment in rest.split(","):
            segment = segment.strip()
            if "=" not in segment:
                continue
            key, val = segment.rsplit("=", 1)
            key = key.strip()
            if not key:
                continue
            labels.append(key)
            values.append(_coerce_chart_scalar(val.strip()))
        if len(labels) < 2:
            continue
        tl = (title_part.strip() or "Series")[:120]
        fy_like = sum(
            1
            for lb in labels
            if re.match(r"^FY\d", lb, re.I) or re.match(r"^\d{4}$", lb)
        )
        ct = "line" if fy_like >= max(1, len(labels) // 2) else "bar"
        out.append(
            {
                "title": tl,
                "labels": labels,
                "values": values,
                "chart_type": ct,
            }
        )
        matched.add(line)
        matched.add(raw.strip())
    return out, matched


def _fill_missing_charts(sections: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    When the LLM omits `charts` or passes empty label/value arrays, synthesize charts
    from `table` or from FY+number lines in `body` so the .docx is not chart-free.
    """
    for sec in sections or []:
        if not isinstance(sec, dict):
            continue
        charts = sec.get("charts") or []
        if _charts_are_renderable(charts):
            continue
        auto: List[Dict[str, Any]] = []
        auto.extend(_auto_charts_from_table(sec.get("table")))
        if not auto:
            auto.extend(_parse_fy_series_from_body(sec.get("body")))
        if not auto:
            kv_charts, kv_matched = _parse_inline_kv_series_from_body(sec.get("body"))
            auto.extend(kv_charts)
            if kv_charts and kv_matched and isinstance(sec.get("body"), str):
                new_lines = [
                    ln
                    for ln in sec["body"].splitlines()
                    if ln.strip() not in kv_matched
                ]
                sec["body"] = "\n".join(new_lines).strip()
        if auto:
            h = (sec.get("heading") or "").strip()
            if h:
                for ch in auto:
                    t = str(ch.get("title") or "Chart").strip()
                    ch["title"] = f"{h}: {t}"[:120]
            sec["charts"] = auto
    return sections


def normalize_docx_sections(
    sections: List[Dict[str, Any]],
    *,
    include_charts: bool = False,
) -> List[Dict[str, Any]]:
    """
    Accept LLM quirks: ``title`` instead of ``heading``; ``text`` instead of ``body``;
    ``charts`` as list of strings (no image) or misaligned labels/values.

    When ``include_charts`` is False (default), section ``charts`` are cleared and
    auto-charts from tables/body are not synthesized. Set True when the caller
    wants chart images (e.g. after matching user intent or model flag).
    """
    out: List[Dict[str, Any]] = []
    for raw in sections or []:
        if not isinstance(raw, dict):
            continue
        sec = dict(raw)
        head = (sec.get("heading") or "").strip()
        if not head:
            t = sec.get("title")
            if isinstance(t, str) and t.strip():
                sec["heading"] = t.strip()
            else:
                sec["heading"] = "Section"
        sec.pop("title", None)

        # Narrative: many LLMs use "text" instead of "body"
        b = sec.get("body")
        tx = sec.get("text")
        if isinstance(b, str) and b.strip():
            merged = b
        elif isinstance(tx, str) and tx.strip():
            merged = tx
        elif isinstance(b, str):
            merged = b
        else:
            merged = ""
        sec.pop("text", None)

        if isinstance(merged, str):
            lines = []
            for line in merged.split("\n"):
                t = line.strip()
                lines.append(_sanitize_docx_text(t) if t else "")
            sec["body"] = "\n".join(lines)
        else:
            sec["body"] = ""

        charts_raw = sec.get("charts")
        charts_norm: List[Dict[str, Any]] = []
        if include_charts and isinstance(charts_raw, list):
            for ch in charts_raw:
                if isinstance(ch, dict):
                    charts_norm.append(_align_chart_labels_values(dict(ch)))
                elif isinstance(ch, str) and ch.strip():
                    charts_norm.append(
                        {
                            "title": ch.strip(),
                            "labels": [],
                            "values": [],
                            "chart_type": "bar",
                        }
                    )
        sec["charts"] = charts_norm

        if isinstance(sec.get("table"), dict):
            tb = dict(sec["table"])
            hdrs = [_sanitize_docx_text(x) for x in (tb.get("headers") or [])]
            rows = []
            for row in tb.get("rows") or []:
                if isinstance(row, (list, tuple)):
                    rows.append([_sanitize_docx_text(c) for c in row])
                else:
                    rows.append([_sanitize_docx_text(row)])
            tb["headers"] = hdrs
            tb["rows"] = rows
            sec["table"] = tb

        out.append(sec)
    if include_charts:
        return _fill_missing_charts(out)
    return out


TOOL_DEFINITION = {
    "tool_id": "docx_generator",
    "name": "Word Document Generator",
    "description": (
        "ONLY use when the user EXPLICITLY asks for a Word document, .docx file, or "
        "an editable report as Word. "
        "Each section uses `heading` (or alias `title`). "
        "Put comparative KPIs in `table`: {{ \"headers\": [...], \"rows\": [[...], ...] }}. "
        "Never use the word Placeholder in cells—use figures from uploaded context only, else "
        "write \"Not disclosed in provided documents\". "
        "Set top-level `include_charts` to true when the report should embed chart images "
        "(or omit/false for text-only). The API may set this from the user message and/or "
        "the model flag. "
        "When `include_charts` is true, optional `charts`: each object must have the SAME "
        "length for `labels` and `values` (e.g. labels [\"FY23-24\",\"FY24-25\"] with values [140,138]). "
        "If `charts` is omitted but a `table` is present, FY+number lines, or "
        "lines like `Title: FY24=200, FY25=220, USA=60, Europe=25` appear in `body`, "
        "charts are auto-generated: first column = categories; the numeric series column "
        "is chosen from headers (e.g. Z-score) or the column with the largest numeric values. "
        "Use `body` or `text` for narrative paragraphs (Executive Summary, analysis). "
        "For each operator in a comparison, take KPIs from that operator's PDF in the session. "
        "GFM markdown pipe tables (| col | col | with --- separator) in `body` are rendered as "
        "native Word tables. HTML <table> blocks in `body` are also converted. "
        "Prefer structured `table` {{headers, rows}} when the model emits JSON. "
        "If the user asks to extend a report, call again with the full sections list "
        "(existing content summarized or repeated plus new sections). "
        "Returns a downloadable file path."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Document title (shown in the document)",
            },
            "include_charts": {
                "type": "boolean",
                "default": False,
                "description": (
                    "True to embed chart images and auto-charts from tables when applicable. "
                    "Use true whenever the brief requires figures/charts."
                ),
            },
            "sections": {
                "type": "array",
                "description": "Ordered sections",
                "items": {
                    "type": "object",
                    "properties": {
                        "heading": {
                            "type": "string",
                            "description": "Section heading (alias: title)",
                        },
                        "title": {
                            "type": "string",
                            "description": "Same as heading if heading omitted",
                        },
                        "body": {
                            "type": "string",
                            "description": "Plain text paragraphs (newlines); alias: text",
                        },
                        "text": {
                            "type": "string",
                            "description": "Same as body — narrative for this section",
                        },
                        "table": {
                            "type": "object",
                            "description": "KPI / data table as headers + rows",
                            "properties": {
                                "headers": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "rows": {
                                    "type": "array",
                                    "items": {"type": "array"},
                                },
                            },
                        },
                        "charts": {
                            "type": "array",
                            "description": (
                                "Bar, line, or heatmap images. For heatmap set chart_type=heatmap "
                                "and provide matrix (NxN correlation grid) plus row_labels/col_labels; "
                                "or labels + values where values has length n*n (row-major)."
                            ),
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {"type": "string"},
                                    "labels": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "values": {
                                        "type": "array",
                                        "items": {"type": "number"},
                                    },
                                    "chart_type": {
                                        "type": "string",
                                        "enum": ["bar", "line", "heatmap"],
                                    },
                                    "matrix": {
                                        "type": "array",
                                        "description": "For heatmap: N rows of N numbers (correlation matrix)",
                                        "items": {"type": "array", "items": {"type": "number"}},
                                    },
                                    "row_labels": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "col_labels": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                            },
                        },
                    },
                    "required": [],
                },
            },
        },
        "required": ["title", "sections"],
    },
    "capabilities": ["docx_generation", "word_export"],
}


def _safe_docx_filename(title: str) -> str:
    """Human-readable .docx filename; avoid aggressive truncation mid-token."""
    raw = (title or "").strip() or "Report"
    slug = "".join(c if c.isalnum() or c in " -_" else " " for c in raw)
    slug = re.sub(r"\s+", " ", slug).strip(" ._")[:100]
    if not slug:
        slug = "Report"
    if not slug.lower().endswith(".docx"):
        slug = f"{slug}.docx"
    return slug


def _strip_html_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s).strip()


def _apply_table_grid_borders(table: Any) -> None:
    """Ensure visible grid on all cells (default template may omit inner lines)."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tbl = table._tbl
    tbl_pr = tbl.tblPr
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        tbl.insert(0, tbl_pr)
    old = tbl_pr.find(qn("w:tblBorders"))
    if old is not None:
        tbl_pr.remove(old)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), "8")
        e.set(qn("w:space"), "0")
        e.set(qn("w:color"), "2E5090")
        borders.append(e)
    tbl_pr.append(borders)


def _md_row_cells(line: str) -> Optional[List[str]]:
    """Split a markdown pipe row into cell strings, or None if not a table row."""
    s = line.strip()
    if not s.startswith("|"):
        return None
    parts = [p.strip() for p in s.split("|")]
    while parts and parts[0] == "":
        parts.pop(0)
    while parts and parts[-1] == "":
        parts.pop()
    if len(parts) < 2:
        return None
    return parts


def _is_md_separator_cells(cells: List[str]) -> bool:
    """True if this row is a GFM markdown column-alignment row (---, :---:, etc.)."""
    if not cells:
        return False
    ok = 0
    for c in cells:
        t = c.strip()
        if not t:
            continue
        ok += 1
        if not re.match(r"^:?-{3,}:?$", t):
            return False
    return ok > 0


def _parse_md_table_block(block: List[str]) -> Optional[Tuple[List[str], List[List[str]]]]:
    """
    Parse a GFM pipe table block (header, optional --- separator, data rows)
    into headers and data rows.
    """
    if len(block) < 2:
        return None
    rows: List[List[str]] = []
    for raw in block:
        cells = _md_row_cells(raw)
        if cells is None:
            return None
        rows.append(cells)
    hdr = rows[0]
    rest = rows[1:]
    if rest and _is_md_separator_cells(rest[0]):
        rest = rest[1:]
    if not rest:
        return None
    return hdr, rest


def _extract_markdown_pipe_tables(body: str) -> Tuple[str, List[Tuple[List[str], List[List[str]]]]]:
    """
    Find GFM-style pipe tables in narrative text; return body with those blocks
    removed and a list of (headers, rows) in document order.
    """
    if not body or "|" not in body:
        return body, []
    lines = body.splitlines()
    out: List[str] = []
    tables: List[Tuple[List[str], List[List[str]]]] = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("|") and stripped.count("|") >= 2:
            block: List[str] = []
            j = i
            while j < n:
                L = lines[j]
                st = L.strip()
                if not st:
                    break
                if st.startswith("|") and st.count("|") >= 2:
                    block.append(L)
                    j += 1
                else:
                    break
            parsed = _parse_md_table_block(block)
            if parsed:
                tables.append(parsed)
                i = j
                continue
        out.append(line)
        i += 1
    return "\n".join(out), tables


def _parse_simple_html_table(html: str) -> Optional[Tuple[List[str], List[List[str]]]]:
    """Best-effort parse of a single HTML table into headers + rows."""
    if not html or "<table" not in html.lower():
        return None
    rows_raw: List[List[str]] = []
    for tr_m in re.finditer(r"<tr[^>]*>(.*?)</tr>", html, re.DOTALL | re.IGNORECASE):
        row_html = tr_m.group(1)
        cells = re.findall(
            r"<t[hd][^>]*>(.*?)</t[hd]>", row_html, re.DOTALL | re.IGNORECASE
        )
        if not cells:
            continue
        rows_raw.append([_strip_html_tags(c) for c in cells])
    if len(rows_raw) < 1:
        return None
    headers = rows_raw[0]
    data_rows = rows_raw[1:] if len(rows_raw) > 1 else []
    return headers, data_rows


def _abs_path_for_write(path: str) -> str:
    """
    Normalize path for python-docx save. On Windows, very long paths under deep
    directories (e.g. OneDrive) can exceed legacy MAX_PATH and raise FileNotFoundError;
    use the extended-length prefix when needed.
    """
    if os.name != "nt":
        return path
    abs_p = os.path.abspath(path)
    if abs_p.startswith("\\\\?\\"):
        return abs_p
    if len(abs_p) < 240:
        return abs_p
    if abs_p.startswith("\\\\"):
        return "\\\\?\\UNC\\" + abs_p[2:].replace("/", "\\")
    return "\\\\?\\" + abs_p.replace("/", "\\")


class DocxGeneratorService:
    """
    DOCX generation service using Doxygen.
    
    Generates professional Word documents via Doxygen RTF output and Pandoc conversion.
    All styling is config-driven with no hardcoding.
    """
    
    def __init__(self):
        """Initialize DOCX generator service."""
        self.config = get_config()
        self.output_dir = self.config.paths.doc_dir
        self.doxygen_handler = DoxygenHandler()
        self.input_builder = DoxygenInputBuilder()
        
        logger.info(
            "DocxGeneratorService initialized with config: "
            "doxygen=%s, pandoc=%s, timeout=%d",
            self.config.doxygen_generator.doxygen_executable,
            self.config.doxygen_generator.pandoc_executable,
            self.config.doxygen_generator.subprocess_timeout
        )
    
    def generate(
        self,
        title: str,
        sections: List[Dict[str, Any]],
        *,
        include_charts: bool = False,
    ) -> Dict[str, str]:
        """
        Generate DOCX document using Doxygen.
        
        Args:
            title: Document title
            sections: List of section dicts with 'heading', 'body', 'table', 'charts'
            include_charts: Whether to include chart descriptions (charts themselves
                           are included as table captions in the output)
        
        Returns:
            Dict with 'file_path', 'filename', 'file_id'
            
        Raises:
            InvalidDocumentStructureError: Document structure is invalid
            DoxygenGenerationError: Doxygen generation failed
            RTFToDOCXConversionError: Pandoc conversion failed
        """
        # Normalize sections
        sections = normalize_docx_sections(
            [dict(s) for s in (sections or []) if isinstance(s, dict)],
            include_charts=include_charts,
        )
        
        logger.debug(
            "Generating DOCX: title=%s, sections=%d, include_charts=%s",
            title,
            len(sections),
            include_charts
        )
        
        try:
            # Build Doxygen input
            dox_content = self.input_builder.build_dox_input(
                title=title,
                sections=sections,
                author=self.config.doxygen_generator.doc_author,
                company=self.config.doxygen_generator.doc_company
            )
            
            logger.debug("Doxygen input built: %d bytes", len(dox_content))
            
            # Generate unique file ID
            file_id = str(uuid.uuid4())
            display_name = _safe_docx_filename(title)
            disk_name = f"{file_id}.docx"
            output_path = os.path.join(self.output_dir, disk_name)
            
            # Ensure output directory exists
            os.makedirs(self.output_dir, exist_ok=True)
            
            # Generate DOCX via Doxygen
            success, message = self.doxygen_handler.generate_docx(
                dox_content=dox_content,
                output_docx_path=output_path
            )
            
            if not success or not os.path.exists(output_path):
                raise InvalidDocumentStructureError(
                    f"DOCX generation failed: {message}"
                )
            
            logger.info(
                "DOCX generated successfully: %s (display=%s, size=%d bytes)",
                disk_name,
                display_name,
                os.path.getsize(output_path)
            )
            
            return {
                "file_path": output_path,
                "filename": display_name,
                "file_id": file_id
            }
            
        except Exception as e:
            logger.error("DOCX generation failed: %s", str(e), exc_info=True)
            raise
    """Create .docx files from structured sections, tables, and optional charts."""

    def __init__(self, output_dir: str) -> None:
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _add_table(
        self,
        doc: Any,
        headers: List[str],
        rows: List[List[Any]],
    ) -> None:
        from docx.enum.table import WD_TABLE_ALIGNMENT
        from docx.shared import Inches, Pt

        hdr = [_sanitize_docx_text(h) for h in (headers or [])]
        rws = rows or []
        ncols = max(len(hdr), max((len(r) for r in rws), default=0))
        if ncols == 0:
            return
        nrows = 1 + len(rws)
        table = doc.add_table(rows=nrows, cols=ncols)
        table.style = "Table Grid"
        _apply_table_grid_borders(table)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        hdr_cells = table.rows[0].cells
        for j in range(ncols):
            cell = hdr_cells[j]
            cell.text = hdr[j] if j < len(hdr) else ""
            for p in cell.paragraphs:
                for run in p.runs:
                    run.bold = True
                    run.font.size = Pt(10)
        for i, row in enumerate(rws, start=1):
            cells = table.rows[i].cells
            for j in range(ncols):
                val = row[j] if j < len(row) else ""
                cells[j].text = _sanitize_docx_text(val)

        doc.add_paragraph()

    def _add_section_content(
        self,
        doc: Any,
        sec: Dict[str, Any],
    ) -> None:
        from docx.shared import Inches

        body = sec.get("body") or ""
        table_obj = sec.get("table")
        charts = sec.get("charts") or []

        # Strip "Chart omitted" lines the LLM sometimes writes in body text instead of
        # passing proper chart objects — remove them so they never appear in the docx.
        if isinstance(body, str) and "chart omitted" in body.lower():
            body = "\n".join(
                ln for ln in body.split("\n")
                if "chart omitted" not in ln.lower()
            )

        # HTML tables in body → each becomes a native Word table (borders via _add_table)
        if isinstance(body, str):
            while "<table" in body.lower():
                parsed = _parse_simple_html_table(body)
                if not parsed:
                    break
                h, r = parsed
                self._add_table(doc, h, r)
                body = re.sub(
                    r"<table[^>]*>.*?</table>",
                    "",
                    body,
                    count=1,
                    flags=re.DOTALL | re.IGNORECASE,
                ).strip()

        # Markdown pipe tables (| col | col |) → native Word tables (LLMs often put
        # tables only in body text; without this each | line becomes a separate paragraph.)
        if isinstance(body, str):
            body, md_tables = _extract_markdown_pipe_tables(body)
            for h, r in md_tables:
                self._add_table(doc, h, r)

        # Narrative before tabular data (Executive Summary, etc.)
        if isinstance(body, str):
            for line in body.split("\n"):
                line = line.strip()
                if line:
                    doc.add_paragraph(_sanitize_docx_text(line))

        # Structured table after narrative in the same section
        if isinstance(table_obj, dict):
            h = table_obj.get("headers") or []
            r = table_obj.get("rows") or []
            if h or r:
                self._add_table(doc, list(h), [list(x) for x in r])

        for ch in charts:
            if not isinstance(ch, dict):
                continue
            title = str(ch.get("title") or "Chart")
            labels = [str(x) for x in (ch.get("labels") or [])]
            vals_raw = ch.get("values") or []
            values = [_coerce_chart_scalar(v) for v in vals_raw]
            png = _render_chart_image(title, ch)
            png_ok = (
                png is not None
                and len(png) >= 24
                and png[:8] == b"\x89PNG\r\n\x1a\n"
            )
            inserted = False
            if png_ok:
                try:
                    doc.add_paragraph(title, style="Heading 3")
                    stream = io.BytesIO(png)
                    stream.seek(0)
                    doc.add_picture(stream, width=Inches(6.2))
                    doc.add_paragraph()
                    inserted = True
                except Exception:
                    logger.exception(
                        "docx add_picture failed for chart %r (PNG %d bytes)",
                        title,
                        len(png or b""),
                    )
            if not inserted:
                ct = str(ch.get("chart_type") or "").lower()
                if ct == "heatmap":
                    hm, _, _ = _heatmap_matrix_from_chart(ch)
                    if hm:
                        cap = doc.add_paragraph(style="Caption")
                        cap.add_run(f"{title}: ").bold = True
                        cap.add_run(
                            " | ".join(
                                "[" + ", ".join(f"{x:.4g}" for x in row) + "]"
                                for row in hm
                            )
                        )
                        cap.add_run(
                            " (Install matplotlib on the API server for chart images.)"
                        )
                        doc.add_paragraph()
                elif labels and values and len(labels) == len(values):
                    # Matplotlib missing, invalid PNG, or add_picture failed — show series text.
                    cap = doc.add_paragraph(style="Caption")
                    cap.add_run(f"{title}: ").bold = True
                    pairs = ", ".join(
                        f"{lb}={val:.4g}" for lb, val in zip(labels, values)
                    )
                    cap.add_run(pairs)
                    if png_ok:
                        note = " (PNG generated but Word embedding failed.)"
                    else:
                        note = " (Install matplotlib on the API server for chart images.)"
                    cap.add_run(note)
                    doc.add_paragraph()

    def generate(
        self,
        title: str,
        sections: List[Dict[str, Any]],
        *,
        include_charts: bool = False,
    ) -> Dict[str, str]:
        from docx import Document
        from docx.shared import Pt

        sections = normalize_docx_sections(
            [dict(s) for s in (sections or []) if isinstance(s, dict)],
            include_charts=include_charts,
        )

        doc = Document()
        style = doc.styles["Normal"]
        style.font.size = Pt(11)

        doc.add_heading(title.strip() or "Report", level=0)

        for sec in sections or []:
            heading = (sec.get("heading") or "Section").strip()
            doc.add_heading(heading, level=1)
            self._add_section_content(doc, sec if isinstance(sec, dict) else {})

        file_id = str(uuid.uuid4())
        # Short on-disk name avoids Windows MAX_PATH failures (long title + deep base path).
        display_name = _safe_docx_filename(title)
        disk_name = f"{file_id}.docx"
        file_path = os.path.join(self.output_dir, disk_name)
        os.makedirs(self.output_dir, exist_ok=True)
        doc.save(_abs_path_for_write(file_path))
        logger.info("DOCX generated: %s (display=%s)", disk_name, display_name)
        return {"file_path": file_path, "filename": display_name, "file_id": file_id}
