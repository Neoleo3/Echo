## 19/08/26 - updates

"""
Word (.docx) report generator.

Uses python-docx + matplotlib (Agg) for charts. Writes under uploads/generated/docx
and returns paths for [GENERATED_FILE:...] registration.
"""

from __future__ import annotations

import io
import logging
# import json
import html
import os
import re
import uuid
from typing import Any, Dict, List, Optional, Set, Tuple
from echolib.blob_storage import (
    upload_to_blob,
    get_blob_url,
)

logger = logging.getLogger(__name__)

# KPMG brand — shared single source of truth so every downloadable document
# (docx, pptx, pdf) uses the same logo + colour.
from echolib.branding import (
    resolve_kpmg_logo as _resolve_kpmg_logo,
    KPMG_BLUE_HEX as _KPMG_BLUE_HEX,
)
from docx.shared import RGBColor, Pt, Inches


def _apply_kpmg_branding(doc: Any, title: str) -> None:
    """Stamp KPMG identity on the document: logo in the page header (repeats on
    every page) + a KPMG-blue title. Never raises — a branding failure must not
    block document generation."""
    try:
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        blue = RGBColor(0x00, 0x33, 0x8D)
        section = doc.sections[0]

        # Logo in the running header (appears on every page).
        logo = _resolve_kpmg_logo()
        header = section.header
        header.is_linked_to_previous = False
        hp = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        if logo:
            try:
                hp.add_run().add_picture(logo, width=Inches(0.9))
            except Exception:
                logger.exception("KPMG header logo embed failed (%s)", logo)
        else:
            # Text fallback so the header still carries the brand.
            r = hp.add_run("KPMG")
            r.bold = True
            r.font.color.rgb = blue
            r.font.size = Pt(20)

        # Title in KPMG blue.
        tp = doc.add_paragraph()
        tp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        tr = tp.add_run((title or "Report").strip() or "Report")
        tr.bold = True
        tr.font.size = Pt(22)
        tr.font.color.rgb = blue

        tp.paragraph_format.space_after = Pt(18)
    except Exception:
        logger.exception("KPMG branding could not be applied; continuing")


_NOT_DISCLOSED = "Not disclosed in provided documents"
_PLACEHOLDER_CELL = re.compile(
    r"^placeholder(\s+for\s+[\w\s,.'-]+)?$",
    re.IGNORECASE,
)


def _sanitize_docx_text(val: Any) -> str:
    """Replace LLM placeholder tokens with grounded wording."""
    if val is None:
        return _NOT_DISCLOSED
    s = str(val).strip()
    if not s:
        return _NOT_DISCLOSED
    low = s.lower()
    if low == "placeholder" or _PLACEHOLDER_CELL.match(s):
        return _NOT_DISCLOSED
    if "placeholder" in low:
        return _NOT_DISCLOSED
    return s

def _normalize_markdown_text(value: Any) -> str:
    """
    Normalize Markdown received from the LLM before rendering it into Word.

    This converts escaped Markdown into ordinary Markdown. It does not remove
    Markdown formatting; the Word renderer handles that afterward.
    """
    if value is None:
        return ""

    text = str(value)

    # Decode HTML entities:
    # &lt; becomes <
    # &gt; becomes >
    # &amp; becomes &
    text = html.unescape(text)

    # Normalize real line endings.
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "\n")

    # Normalize serialized escape sequences received from JSON/tool calls.
    text = text.replace("\\r\\n", "\n")
    text = text.replace("\\n", "\n")
    text = text.replace("\\t", "\t")

    # Unescape Markdown punctuation.
    #
    # Examples:
    # \| -> |
    # \* -> *
    # \# -> #
    # \- -> -
    # \> -> >
    text = re.sub(
        r"\\([\\`*_\[\]{}()#+\-.!|>])",
        r"\1",
        text,
    )

    # Replace non-breaking spaces with ordinary spaces.
    text = text.replace("\u00a0", " ")

    return text

# def _infer_heading(sec: Dict[str, Any], idx: int) -> str:
#     """
#     Derive a heading when the LLM omitted heading/title.
#     """

#     heading = str(sec.get("heading") or "").strip()
#     if heading:
#         return heading

#     title = str(sec.get("title") or "").strip()
#     if title:
#         return title

#     body = (
#         sec.get("body")
#         or sec.get("text")
#         or sec.get("content")
#         or ""
#     )

#     if isinstance(body, str) and body.strip():

#         lines = [
#             l.strip()
#             for l in body.splitlines()
#             if l.strip()
#         ]

#         #
#         # Markdown headings
#         #
#         for line in lines[:10]:
#             for prefix in ("#### ", "### ", "## ", "# "):
#                 if line.startswith(prefix):
#                     return line[len(prefix):].strip()

#         #
#         # Numbered section headings
#         # Example:
#         # 4. Identified Gaps Against Template
#         #
#         for line in lines[:10]:
#             m = re.match(
#                 r"^\d+(?:\.\d+)*\.?\s+(.+)$",
#                 line
#             )
#             if m:
#                 text = m.group(1).strip()
#                 if len(text) <= 120:
#                     return text

#         #
#         # Colon headings
#         # Example:
#         # Recommendations: The following actions...
#         #
#         for line in lines[:5]:
#             if (
#                 ":" in line
#                 and len(line) <= 120
#                 and not line.startswith("-")
#             ):
#                 left = line.split(":", 1)[0].strip()
#                 if 2 <= len(left.split()) <= 12:
#                     return left

#         #
#         # First short meaningful line
#         #
#         first = lines[0]

#         if (
#             len(first.split()) <= 12
#             and len(first) <= 100
#         ):
#             return first.rstrip(".:")

#     return f"Untitled Section {idx}"


def _infer_heading(sec: Dict[str, Any], idx: int) -> str:
    """
    Resolve the section heading from supported aliases.

    Priority:
    1. heading
    2. title
    3. section_title
    4. infer from body/content only for backward compatibility
    5. deterministic fallback
    """

    # Explicit metadata must always win over body inference.
    for key in ("heading", "title", "section_title"):
        value = sec.get(key)

        if value is None:
            continue

        candidate = _normalize_markdown_text(value).strip()

        if candidate:
            return candidate

    body = (
        sec.get("body")
        or sec.get("text")
        or sec.get("content")
        or ""
    )

    if isinstance(body, str) and body.strip():
        normalized_body = _normalize_markdown_text(body)

        lines = [
            line.strip()
            for line in normalized_body.splitlines()
            if line.strip()
        ]

        # Markdown heading, for example:
        # ## Executive Summary
        for line in lines[:10]:
            match = re.match(
                r"^#{1,6}\s+(.+?)\s*#*\s*$",
                line,
            )

            if match:
                candidate = match.group(1).strip()

                if candidate:
                    return candidate

        # Numbered heading, for example:
        # 4. Executive Summary
        # 4.1 Security Architecture
        for line in lines[:10]:
            match = re.match(
                r"^\d+(?:\.\d+)*\.?\s+(.+)$",
                line,
            )

            if match:
                candidate = match.group(1).strip()

                if candidate and len(candidate) <= 120:
                    return candidate

        # Colon-style heading, for example:
        # Recommendations: Complete the approval records.
        for line in lines[:5]:
            if (
                ":" in line
                and len(line) <= 120
                and not line.startswith(("-", "+", "*", "|", ">"))
            ):
                left = line.split(":", 1)[0].strip()

                if 2 <= len(left.split()) <= 12:
                    return left

        # Last-resort inference from a short first line.
        # Never use table rows, list items, or prose sentences ending in a period.
        first = lines[0]

        looks_like_table = "|" in first
        looks_like_list = bool(
            re.match(r"^(?:[-+*]|\d+[.)])\s+", first)
        )
        looks_like_sentence = first.endswith(
            (".", "!", "?")
        )

        if (
            not looks_like_table
            and not looks_like_list
            and not looks_like_sentence
            and len(first.split()) <= 12
            and len(first) <= 100
        ):
            return first.rstrip(":")

    logger.warning(
        "No section heading supplied or inferred for section %s",
        idx,
    )

    return f"Section {idx}"

def _coerce_chart_scalar(v: Any) -> float:
    """Parse numeric chart values from ints, floats, or strings like '(274,594)' or '435,713'."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        try:
            x = float(v)
        except (TypeError, ValueError, OverflowError):
            return 0.0
        if x != x or x in (float("inf"), float("-inf")):  # NaN / inf
            return 0.0
        return x
    s = str(v).strip()
    if not s:
        return 0.0
    low = s.lower()
    if "not disclosed" in low or low in ("n/a", "-", "—", "n.a.", "na"):
        return 0.0
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1].strip()
    for sym in (",", "₹", "$", "€", "%"):
        s = s.replace(sym, "")
    s = s.strip()
    try:
        x = float(s)
        return -x if neg else x
    except ValueError:
        return 0.0


def _align_chart_labels_values(ch: Dict[str, Any]) -> Dict[str, Any]:
    """
    LLMs often emit len(labels) > len(values). Align by trimming the longer list
    (prefer keeping trailing labels, which are usually period labels).
    When labels is empty but values is non-empty, auto-generate numeric labels.
    Heatmaps use ``matrix`` + optional ``row_labels`` / ``col_labels`` — do not trim.
    """
    ct = str(ch.get("chart_type") or "").lower()
    if ct == "heatmap":
        return dict(ch)
    labels = [str(x) for x in (ch.get("labels") or [])]
    vals_raw = ch.get("values") or []
    values: List[float] = []
    for v in vals_raw:
        values.append(_coerce_chart_scalar(v))
    nl, nv = len(labels), len(values)
    # Auto-generate labels when values are present but labels are missing
    if nl == 0 and nv > 0:
        labels = [str(i + 1) for i in range(nv)]
        return {**ch, "labels": labels, "values": values}
    if nl == 0 or nv == 0:
        return {**ch, "labels": labels, "values": values}
    if nl > nv:
        logger.info(
            "Chart %r: %d labels vs %d values — trimming labels to match",
            ch.get("title"),
            nl,
            nv,
        )
        labels = labels[nl - nv :]
    elif nv > nl:
        logger.info(
            "Chart %r: %d labels vs %d values — trimming values to match",
            ch.get("title"),
            nl,
            nv,
        )
        values = values[nv - nl :]
    return {**ch, "labels": labels, "values": values}


_FY_VALUE_LINE = re.compile(
    r"^\s*(FY\s*\d{2,4}(?:[-–]\d{2,4})?)\s+(\d+(?:\.\d+)?)\s*$",
    re.IGNORECASE,
)

# Prefer these header substrings for the Y-axis column (column 0 = categories).
_CHART_VALUE_HEADER_HINT = re.compile(
    r"(z[-\s]?score|outlier|anomaly|score|value|amount|revenue|growth|"
    r"pct|percent|%|qty|quantity|headcount|count|total|mean|median|std|"
    r"variance|delta|change|rate|index|yoy|mom)",
    re.IGNORECASE,
)


def _pick_chart_value_column_index(headers: List[str], rows: List[Any]) -> int:
    """
    Choose which column holds numeric values for auto-charts. Column 0 is labels.
    Multi-column tables often put text in column 1 (e.g. Zone) and metrics in column 2+;
    always using row[1] coerces text to 0 and yields empty-looking bar charts.
    """
    max_w = 0
    for row in rows:
        if isinstance(row, (list, tuple)):
            max_w = max(max_w, len(row))
    if max_w < 2:
        return 1
    ncols = max(max_w, len(headers))
    # Header-based preference (exact column when headers align)
    for j in range(1, min(len(headers), ncols)):
        h = str(headers[j] or "").strip()
        if h and _CHART_VALUE_HEADER_HINT.search(h):
            return j
    # Scan all data columns for strongest numeric signal (sum of |coerced|)
    best_j, best_score = 1, -1.0
    for j in range(1, ncols):
        total_abs = 0.0
        for row in rows:
            if not isinstance(row, (list, tuple)) or len(row) <= j:
                continue
            total_abs += abs(_coerce_chart_scalar(row[j]))
        if total_abs > best_score:
            best_score = total_abs
            best_j = j
    return best_j


def _coerce_matrix(m: Any) -> List[List[float]]:
    """Parse a 2-D numeric matrix from JSON (list of lists)."""
    if not isinstance(m, list) or not m:
        return []
    out: List[List[float]] = []
    for row in m:
        if isinstance(row, (list, tuple)):
            out.append([_coerce_chart_scalar(x) for x in row])
        else:
            return []
    return out


def _heatmap_matrix_from_chart(ch: Dict[str, Any]) -> Tuple[List[List[float]], List[str], List[str]]:
    """
    Build row-major matrix and axis labels for a heatmap.

    Prefer explicit ``matrix`` (list of rows). Otherwise accept ``labels`` + flat
    ``values`` of length n*n (square correlation grid) or length n (single-row strip).
    """
    matrix = _coerce_matrix(ch.get("matrix"))
    row_labels = [str(x).strip() for x in (ch.get("row_labels") or [])]
    col_labels = [str(x).strip() for x in (ch.get("col_labels") or [])]
    labels = [str(x).strip() for x in (ch.get("labels") or [])]
    vals = [_coerce_chart_scalar(v) for v in (ch.get("values") or [])]

    if matrix:
        n_r, n_c = len(matrix), len(matrix[0]) if matrix else 0
        if not n_c or any(len(row) != n_c for row in matrix):
            return [], [], []
        if not row_labels:
            row_labels = labels[:n_r] if len(labels) >= n_r else [f"R{i + 1}" for i in range(n_r)]
        if not col_labels:
            col_labels = (
                labels[:n_c]
                if len(labels) >= n_c
                else [f"C{i + 1}" for i in range(n_c)]
            )
        return matrix, row_labels[:n_r], col_labels[:n_c]

    n = len(labels)
    if n > 0 and len(vals) == n * n:
        mat = [vals[i * n : (i + 1) * n] for i in range(n)]
        return mat, list(labels), list(labels)

    if n > 0 and len(vals) == n:
        return [vals], ["Series"], list(labels)

    return [], [], []


def _render_heatmap_png(
    title: str,
    matrix: List[List[float]],
    row_labels: List[str],
    col_labels: List[str],
) -> Optional[bytes]:
    if not matrix or not matrix[0]:
        return None
    n_r, n_c = len(matrix), len(matrix[0])
    if any(len(row) != n_c for row in matrix):
        return None
    while len(row_labels) < n_r:
        row_labels.append(f"R{len(row_labels) + 1}")
    while len(col_labels) < n_c:
        col_labels.append(f"C{len(col_labels) + 1}")
    row_labels = row_labels[:n_r]
    col_labels = col_labels[:n_c]

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not available; skipping heatmap")
        return None

    flat = [x for row in matrix for x in row]
    vmin, vmax = min(flat), max(flat)
    if vmin == vmax:
        vmax = vmin + 1e-9
    has_neg = vmin < -1e-9
    has_pos = vmax > 1e-9
    if has_neg and has_pos:
        cmap_name = "RdBu_r"
        mx = max(abs(vmin), abs(vmax), 1e-9)
        vmin, vmax = -mx, mx
    elif not has_neg and vmax <= 1.0 + 1e-6:
        cmap_name = "Blues"
        vmin, vmax = 0.0, max(1.0, vmax)
    else:
        cmap_name = "viridis"

    try:
        w = max(7.5, 0.45 * n_c + 2.5)
        h = max(4.0, 0.4 * n_r + 2.0)
        fig, ax = plt.subplots(figsize=(w, h))
        im = ax.imshow(matrix, cmap=cmap_name, vmin=vmin, vmax=vmax, aspect="auto")
        for i in range(n_r):
            for j in range(n_c):
                v = matrix[i][j]
                txt = f"{v:.3g}" if abs(v) < 1000 else f"{v:.3e}"
                ax.text(j, i, txt, ha="center", va="center", fontsize=8, color="#1a1a1a")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ax.set_xticks(range(n_c))
        ax.set_yticks(range(n_r))
        ax.set_xticklabels(col_labels, rotation=35, ha="right")
        ax.set_yticklabels(row_labels)
        if title:
            ax.set_title(title[:120])
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
        plt.close(fig)
        raw = buf.getvalue()
        if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
            logger.error("Heatmap %r: invalid PNG (%d bytes)", title, len(raw))
            return None
        return raw
    except Exception:
        logger.exception("Heatmap render failed")
        try:
            plt.close("all")
        except Exception:
            pass
        return None


def _render_chart_png(
    title: str,
    labels: List[str],
    values: List[float],
    chart_type: str = "bar",
) -> Optional[bytes]:
    """Bar or line chart. Unknown types default to bar."""
    # Need at least values to plot something
    if not values:
        return None
    # Auto-generate numeric labels when the LLM omitted them
    if not labels:
        labels = [str(i + 1) for i in range(len(values))]
    # Auto-align mismatched lengths by trimming to the shorter list
    if len(labels) != len(values):
        min_len = min(len(labels), len(values))
        labels = labels[:min_len]
        values = values[:min_len]
        logger.info(
            "Chart %r: auto-trimmed to %d point(s) to align labels/values",
            title,
            min_len,
        )
    if not labels:
        return None
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not available; skipping chart")
        return None

    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    ct = (chart_type or "bar").lower()
    if ct not in ("line", "bar"):
        ct = "bar"
    try:
        if ct == "line":
            ax.plot(range(len(labels)), values, marker="o", color="#00338D")
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=35, ha="right")
        else:
            ax.bar(range(len(labels)), values, color="#00338D")
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=35, ha="right")
        if title:
            ax.set_title(title[:120])
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
        plt.close(fig)
        raw = buf.getvalue()
        if len(raw) < 24 or raw[:8] != b"\x89PNG\r\n\x1a\n":
            logger.error("Chart %r: matplotlib produced invalid PNG (%d bytes)", title, len(raw))
            return None
        return raw
    except Exception:
        logger.exception("Chart render failed")
        try:
            plt.close("all")
        except Exception:
            pass
        return None


def _render_chart_image(title: str, ch: Dict[str, Any]) -> Optional[bytes]:
    """Dispatch bar, line, or heatmap (matrix) to PNG bytes."""
    ct = str(ch.get("chart_type") or "bar").lower()
    if ct == "heatmap":
        matrix, rows, cols = _heatmap_matrix_from_chart(ch)
        if matrix:
            return _render_heatmap_png(title, matrix, rows, cols)
        logger.warning("Heatmap %r: missing or invalid matrix / labels+values", title)
        return None
    labels = [str(x) for x in (ch.get("labels") or [])]
    vals_raw = ch.get("values") or []
    values = [_coerce_chart_scalar(v) for v in vals_raw]
    return _render_chart_png(title, labels, values, ct)


def _charts_are_renderable(charts: List[Dict[str, Any]]) -> bool:
    """True if at least one chart has aligned labels/values and can be drawn."""
    for ch in charts or []:
        if not isinstance(ch, dict):
            continue
        ch2 = _align_chart_labels_values(dict(ch))
        ct = str(ch2.get("chart_type") or "").lower()
        if ct == "heatmap":
            if _coerce_matrix(ch2.get("matrix")):
                return True
            labs = [str(x) for x in (ch2.get("labels") or [])]
            vals = [_coerce_chart_scalar(v) for v in (ch2.get("values") or [])]
            n = len(labs)
            if n > 0 and len(vals) == n * n:
                return True
            if n > 0 and len(vals) == n:
                return True
            continue
        labels = ch2.get("labels") or []
        values = ch2.get("values") or []
        if len(values) > 0 and len(labels) == len(values):
            return True
    return False


def _auto_charts_from_table(table: Any) -> List[Dict[str, Any]]:
    """
    Build one bar/line chart from a table: labels from column 0, values from an
    auto-detected numeric column (header hints like Z-score, else max |value|).
    """
    if not isinstance(table, dict):
        return []
    headers = [str(h).strip() for h in (table.get("headers") or [])]
    rows = table.get("rows") or []
    if not rows:
        return []
    max_w = max(
        (len(r) if isinstance(r, (list, tuple)) else 0) for r in rows
    )
    if max_w < 2:
        return []
    vc = _pick_chart_value_column_index(headers, rows)
    labels: List[str] = []
    values: List[float] = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 2:
            continue
        labels.append(str(row[0]).strip())
        if len(row) > vc:
            values.append(_coerce_chart_scalar(row[vc]))
        else:
            values.append(0.0)
    if not labels:
        return []
    vh = headers[vc] if vc < len(headers) else f"Column {vc}"
    title = f"{vh} by {headers[0]}" if headers else vh
    lab_joined = " ".join(labels[:3]).upper()
    ct = (
        "line"
        if ("FY" in lab_joined or "20" in lab_joined)
        else "bar"
    )
    return [
        {
            "title": title[:120],
            "labels": labels,
            "values": values,
            "chart_type": ct,
        }
    ]


def _parse_fy_series_from_body(body: Any) -> List[Dict[str, Any]]:
    """
    Detect lines like 'FY26  250' or 'FY26\t250' embedded in narrative (no JSON table).
    """
    if not isinstance(body, str) or not body.strip():
        return []
    labels: List[str] = []
    values: List[float] = []
    for line in body.splitlines():
        line = line.strip()
        if not line or line.lower().startswith("fiscal year"):
            continue
        m = _FY_VALUE_LINE.match(line)
        if m:
            labels.append(m.group(1).strip().replace(" ", ""))
            values.append(_coerce_chart_scalar(m.group(2)))
    if len(labels) < 2:
        return []
    return [
        {
            "title": "Outlook (values parsed from narrative)",
            "labels": labels,
            "values": values,
            "chart_type": "line",
        }
    ]


def _parse_inline_kv_series_from_body(
    body: Any,
) -> Tuple[List[Dict[str, Any]], Set[str]]:
    """
    Parse LLM prose lines like:
      'Indian IT Industry Growth Projections: FY24=200, FY25=220, FY26=240'
      'IT Export Distribution by Region: USA=60, Europe=25, APAC/Middle East=15'
    Each line with a title, colon, and at least two comma-separated key=value pairs
    becomes one chart.

    Returns (charts, matched_line_strips) so callers can remove duplicate prose lines.
    """
    matched: Set[str] = set()
    if not isinstance(body, str) or not body.strip():
        return [], matched
    out: List[Dict[str, Any]] = []
    for line in body.splitlines():
        raw = line
        line = line.strip()
        if ":" not in line or "=" not in line:
            continue
        title_part, rest = line.split(":", 1)
        rest = rest.strip()
        if rest.count("=") < 2:
            continue
        labels: List[str] = []
        values: List[float] = []
        for segment in rest.split(","):
            segment = segment.strip()
            if "=" not in segment:
                continue
            key, val = segment.rsplit("=", 1)
            key = key.strip()
            if not key:
                continue
            labels.append(key)
            values.append(_coerce_chart_scalar(val.strip()))
        if len(labels) < 2:
            continue
        tl = (title_part.strip() or "Series")[:120]
        fy_like = sum(
            1
            for lb in labels
            if re.match(r"^FY\d", lb, re.I) or re.match(r"^\d{4}$", lb)
        )
        ct = "line" if fy_like >= max(1, len(labels) // 2) else "bar"
        out.append(
            {
                "title": tl,
                "labels": labels,
                "values": values,
                "chart_type": ct,
            }
        )
        matched.add(line)
        matched.add(raw.strip())
    return out, matched


def _fill_missing_charts(sections: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    When the LLM omits `charts` or passes empty label/value arrays, synthesize charts
    from `table` or from FY+number lines in `body` so the .docx is not chart-free.
    """
    for sec in sections or []:
        if not isinstance(sec, dict):
            continue
        charts = sec.get("charts") or []
        if _charts_are_renderable(charts):
            continue
        auto: List[Dict[str, Any]] = []
        auto.extend(_auto_charts_from_table(sec.get("table")))
        if not auto:
            auto.extend(_parse_fy_series_from_body(sec.get("body")))
        if not auto:
            kv_charts, kv_matched = _parse_inline_kv_series_from_body(sec.get("body"))
            auto.extend(kv_charts)
            if kv_charts and kv_matched and isinstance(sec.get("body"), str):
                new_lines = [
                    ln
                    for ln in sec["body"].splitlines()
                    if ln.strip() not in kv_matched
                ]
                sec["body"] = "\n".join(new_lines).strip()
        if auto:
            # h = (sec.get("heading") or sec.get("title") or "").strip()
            h = str(sec.get("heading") or "").strip()
            if h:
                for ch in auto:
                    t = str(ch.get("title") or "Chart").strip()
                    ch["title"] = f"{h}: {t}"[:120]
            sec["charts"] = auto
    return sections


def normalize_docx_sections(
    sections: List[Dict[str, Any]],
    *,
    include_charts: bool = False,
) -> List[Dict[str, Any]]:
    """
    Accept LLM quirks: ``title`` instead of ``heading``; ``text`` instead of ``body``;
    ``charts`` as list of strings (no image) or misaligned labels/values.

    When ``include_charts`` is False (default), section ``charts`` are cleared and
    auto-charts from tables/body are not synthesized. Set True when the caller
    wants chart images (e.g. after matching user intent or model flag).
    """
    out: List[Dict[str, Any]] = []
    for raw in sections or []:
        if not isinstance(raw, dict):
            continue
        sec = dict(raw)
        # head = (sec.get("heading") or sec.get("title","")).strip()
        # if not head:
        #     t = sec.get("title")
        #     if isinstance(t, str) and t.strip():
        #         sec["heading"] = t.strip()
        #     else:
        #         sec["heading"] = "Section"

        # sec["heading"] = _infer_heading(
        #     sec,
        #     len(out) + 1,
        # )
        # sec.pop("title", None)

        sec["heading"] = _infer_heading(
            sec,
            len(out) + 1,
        )

        # Remove aliases after converting them to the canonical "heading" field.
        sec.pop("title", None)
        sec.pop("section_title", None)

        # Narrative: many LLMs use "text" instead of "body"
        b = sec.get("body")
        tx = sec.get("text")
        ct = sec.get("content")
        if isinstance(b, str) and b.strip():
            merged = b
        elif isinstance(tx, str) and tx.strip():
            merged = tx
        elif isinstance(ct, str) and ct.strip():
            merged = ct
        elif isinstance(b, str):
            merged = b
        else:
            merged = ""
        # sec.pop("text", None)
        # Remove body aliases after converting them to the canonical "body" field.
        sec.pop("text", None)
        sec.pop("content", None)

        # if isinstance(merged, str):
        #     # LLMs sometimes emit literal "\n" escape sequences instead of
        #     # real newlines — convert them so pipe-table detection works.
        #     merged = merged.replace("\\n", "\n")
        #     merged = re.sub(r'\\([*_#`])', r'\1', merged)
        #     lines = []
        #     for line in merged.split("\n"):
        #         t = line.strip()
        #         lines.append(_sanitize_docx_text(t) if t else "")
        #     sec["body"] = "\n".join(lines)
        # else:
        #     sec["body"] = ""

        if isinstance(merged, str):
            merged = _normalize_markdown_text(merged)

            # Preserve indentation because nested lists and code blocks may depend on it.
            # Only remove trailing whitespace.
            lines = [
                line.rstrip()
                for line in merged.split("\n")
            ]

            # Remove excessive blank lines while preserving paragraph separation.
            cleaned_lines: List[str] = []
            previous_blank = False

            for line in lines:
                is_blank = not line.strip()

                if is_blank and previous_blank:
                    continue

                cleaned_lines.append(line)
                previous_blank = is_blank

            body = "\n".join(cleaned_lines).strip()

            # _infer_heading() may have derived the section heading from the first
            # Markdown heading in the body. Remove that heading from the body when it
            # is the same as the section heading, so Word does not display it twice.
            body_lines = body.splitlines()

            if body_lines:
                first_non_empty_index = next(
                    (
                        i
                        for i, line in enumerate(body_lines)
                        if line.strip()
                    ),
                    None,
                )

                if first_non_empty_index is not None:
                    first_line = body_lines[first_non_empty_index].strip()

                    heading_match = re.match(
                        r"^#{1,6}\s+(.+?)\s*#*\s*$",
                        first_line,
                    )

                    if heading_match:
                        markdown_heading = heading_match.group(1).strip()
                        section_heading = str(sec.get("heading") or "").strip()

                        if markdown_heading.casefold() == section_heading.casefold():
                            del body_lines[first_non_empty_index]
                            body = "\n".join(body_lines).strip()

            sec["body"] = body
        else:
            sec["body"] = ""

        charts_raw = sec.get("charts")
        charts_norm: List[Dict[str, Any]] = []
        if include_charts and isinstance(charts_raw, list):
            for ch in charts_raw:
                if isinstance(ch, dict):
                    charts_norm.append(_align_chart_labels_values(dict(ch)))
                elif isinstance(ch, str) and ch.strip():
                    charts_norm.append(
                        {
                            "title": ch.strip(),
                            "labels": [],
                            "values": [],
                            "chart_type": "bar",
                        }
                    )
        sec["charts"] = charts_norm

        if isinstance(sec.get("table"), dict):
            tb = dict(sec["table"])
            hdrs = [_sanitize_docx_text(x) for x in (tb.get("headers") or [])]
            rows = []
            for row in tb.get("rows") or []:
                if isinstance(row, (list, tuple)):
                    rows.append([_sanitize_docx_text(c) for c in row])
                else:
                    rows.append([_sanitize_docx_text(row)])
            tb["headers"] = hdrs
            tb["rows"] = rows
            sec["table"] = tb

        out.append(sec)
    if include_charts:
        return _fill_missing_charts(out)
    return out


TOOL_DEFINITION = {
    "tool_id": "tool_docx_generator",
    "name": "Word Document Generator",
    "description": (
    "Creates a professionally formatted Word (.docx) document from "
    "structured sections. Call file_reader first for each uploaded "
    "source document. Call this tool exactly once with all sections. "
    "Every section must include a non-empty `heading` and must contain "
    "content through `body`, `table`, `charts`, or a combination of "
    "these fields. Use `heading` rather than `title` or "
    "`section_title`; those fields are accepted only as "
    "backward-compatible aliases. Markdown in body content is converted "
    "into native Word formatting. Structured tables are preferred, but "
    "Markdown pipe tables are accepted. Set include_charts=true only "
    "when visualizations are required."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Document title (shown in the document)"
            },
            "include_charts": {
                "type": "boolean",
                "default": False
            },
            "sections": {
                "type": "array",
                "minItems": 1,
                "description": "Ordered sections",
                "items": {
                    "type": "object",
                    "properties": {
                        "heading": {
                            "type": "string",
                            "description": "Section heading (preferred)"
                        },
                        "title": {
                            "type": "string",
                            "description": "Alias for heading"
                        },
                        "section_title": {
                            "type": "string",
                            "description": (
                                "Alias for heading. Accepted for backward compatibility. "
                                "The preferred field is heading."
                            ),
                        },
                        "body": {
                            "type": "string",
                            "description": (
                                    "Section content. Markdown is allowed and will be converted into native "
                                    "Word formatting. Supported elements include headings, bold, italics, "
                                    "bullets, numbered lists, quotes, links, inline code, and pipe tables."
                                )
                        },
                        "text": {
                            "type": "string",
                            "description": "Alias for body"
                        },
                        
                        "content": {
                            "type": "string",
                            "description": "Alias for body (LLM often emits content)"
                        },
                        "table": {
                            "type": "object",
                            "properties": {
                                "headers": {
                                    "type": "array",
                                    "items": { "type": "string" }
                                },
                                "rows": {
                                    "type": "array",
                                    "items": { "type": "array" }
                                }
                            }
                        },
                        "charts": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": { "type": "string" },
                                    "labels": {
                                        "type": "array",
                                        "items": { "type": "string" }
                                    },
                                    "values": {
                                        "type": "array",
                                        "items": { "type": "number" }
                                    },
                                    "chart_type": {
                                        "type": "string",
                                        "enum": ["bar", "line", "heatmap"]
                                    },
                                    "matrix": {
                                        "type": "array",
                                        "items": {
                                            "type": "array",
                                            "items": { "type": "number" }
                                        }
                                    },
                                    "row_labels": {
                                        "type": "array",
                                        "items": { "type": "string" }
                                    },
                                    "col_labels": {
                                        "type": "array",
                                        "items": { "type": "string" }
                                    }
                                }
                            }
                        }
                    },
                    "required": []   # ✅ ONLY place this belongs
                }
            }
        },
        "required": ["title", "sections"]
    },
    "capabilities": ["docx_generation", "word_export"]
}

def _safe_docx_filename(title: str) -> str:
    raw = (title or "").strip() or "Report"

    raw = re.sub(
        r"\s*\.?\s*docx$",
        "",
        raw,
        flags=re.IGNORECASE,
    ).strip()

    slug = re.sub(r"[^A-Za-z0-9_-]", "_", raw)
    slug = re.sub(r"_+", "_", slug).strip("_")

    return f"{slug or 'Report'}.docx"

# def _strip_html_tags(s: str) -> str:
#     return re.sub(r"<[^>]+>", "", s).strip()

def _strip_html_tags(s: str) -> str:
    """
    Convert basic HTML content into plain text suitable for a Word table cell.
    """
    text = html.unescape(str(s or ""))

    # Preserve line breaks before removing tags.
    text = re.sub(
        r"<\s*br\s*/?\s*>",
        "\n",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"</\s*p\s*>",
        "\n",
        text,
        flags=re.IGNORECASE,
    )
    # Remove remaining HTML tags.
    text = re.sub(
        r"<[^>]*>",
        "",
        text,
    )

    return text.strip()


def _apply_table_grid_borders(table: Any) -> None:
    """Ensure visible grid on all cells (default template may omit inner lines)."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tbl = table._tbl
    tbl_pr = tbl.tblPr
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        tbl.insert(0, tbl_pr)
    old = tbl_pr.find(qn("w:tblBorders"))
    if old is not None:
        tbl_pr.remove(old)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), "8")
        e.set(qn("w:space"), "0")
        e.set(qn("w:color"), _KPMG_BLUE_HEX)
        borders.append(e)
    tbl_pr.append(borders)


# def _md_row_cells(line: str) -> Optional[List[str]]:
#     """Split a markdown pipe row into cell strings, or None if not a table row."""
#     s = line.strip()
#     if not s.startswith("|"):
#         return None
#     parts = [p.strip() for p in s.split("|")]
#     while parts and parts[0] == "":
#         parts.pop(0)
#     while parts and parts[-1] == "":
#         parts.pop()
#     if len(parts) < 2:
#         return None
#     return parts

def _md_row_cells(line: str) -> Optional[List[str]]:
    """
    Split a Markdown pipe-table row into cells.

    Supports:
        | A | B |
        A | B

    Escaped pipes should already have been normalized by
    _normalize_markdown_text().
    """
    if not isinstance(line, str):
        return None

    s = _normalize_markdown_text(line).strip()

    if "|" not in s:
        return None

    # Remove only the optional outside pipes.
    if s.startswith("|"):
        s = s[1:]

    if s.endswith("|"):
        s = s[:-1]

    parts = [
        part.strip()
        for part in s.split("|")
    ]

    if len(parts) < 2:
        return None

    return parts


def _is_md_separator_cells(cells: List[str]) -> bool:
    """True if this row is a GFM markdown column-alignment row (---, :---:, etc.)."""
    if not cells:
        return False
    ok = 0
    for c in cells:
        t = c.strip()
        if not t:
            continue
        ok += 1
        if not re.match(r"^:?-{3,}:?$", t):
            return False
    return ok > 0


# def _parse_md_table_block(block: List[str]) -> Optional[Tuple[List[str], List[List[str]]]]:
#     """
#     Parse a GFM pipe table block (header, optional --- separator, data rows)
#     into headers and data rows.
#     """
#     if len(block) < 2:
#         return None
#     rows: List[List[str]] = []
#     for raw in block:
#         cells = _md_row_cells(raw)
#         if cells is None:
#             return None
#         rows.append(cells)
#     hdr = rows[0]
#     rest = rows[1:]
#     if rest and _is_md_separator_cells(rest[0]):
#         rest = rest[1:]
#     if not rest:
#         return None
#     return hdr, rest

def _parse_md_table_block(
    block: List[str],
) -> Optional[Tuple[List[str], List[List[str]]]]:
    """
    Parse a GitHub-flavoured Markdown table.

    A valid table requires:
    - a header row;
    - a separator row such as --- | ---;
    - zero or more data rows.
    """
    if len(block) < 2:
        return None

    parsed_rows: List[List[str]] = []

    for raw in block:
        cells = _md_row_cells(raw)

        if cells is None:
            return None

        parsed_rows.append(cells)

    headers = parsed_rows[0]
    separator = parsed_rows[1]

    # Requiring the separator prevents ordinary prose containing pipes from
    # being incorrectly converted into a table.
    if not _is_md_separator_cells(separator):
        return None

    data_rows = parsed_rows[2:]
    width = len(headers)

    # Normalize all rows to the header width.
    normalized_rows: List[List[str]] = []

    for row in data_rows:
        if len(row) < width:
            row = row + [""] * (width - len(row))
        elif len(row) > width:
            row = row[:width]

        normalized_rows.append(row)

    return headers, normalized_rows


def _extract_markdown_pipe_tables(body: str) -> Tuple[str, List[Tuple[List[str], List[List[str]]]]]:
    """
    Find GFM-style pipe tables in narrative text; return body with those blocks
    removed and a list of (headers, rows) in document order.
    """
    if not body or "|" not in body:
        return body, []
    lines = body.splitlines()
    out: List[str] = []
    tables: List[Tuple[List[str], List[List[str]]]] = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("|") and stripped.count("|") >= 2:
            block: List[str] = []
            j = i
            while j < n:
                L = lines[j]
                st = L.strip()
                if not st:
                    break
                if st.startswith("|") and st.count("|") >= 2:
                    block.append(L)
                    j += 1
                else:
                    break
            parsed = _parse_md_table_block(block)
            if parsed:
                tables.append(parsed)
                i = j
                continue
        out.append(line)
        i += 1
    return "\n".join(out), tables


# def _parse_simple_html_table(html: str) -> Optional[Tuple[List[str], List[List[str]]]]:
#     """Best-effort parse of a single HTML table into headers + rows."""
#     if not html or "<table" not in html.lower():
#         return None
#     rows_raw: List[List[str]] = []
#     for tr_m in re.finditer(r"<tr[^>]*>(.*?)</tr>", html, re.DOTALL | re.IGNORECASE):
#         row_html = tr_m.group(1)
#         cells = re.findall(
#             r"<t[hd][^>]*>(.*?)</t[hd]>", row_html, re.DOTALL | re.IGNORECASE
#         )
#         if not cells:
#             continue
#         rows_raw.append([_strip_html_tags(c) for c in cells])
#     if len(rows_raw) < 1:
#         return None
#     headers = rows_raw[0]
#     data_rows = rows_raw[1:] if len(rows_raw) > 1 else []
#     return headers, data_rows

def _parse_simple_html_table(
    html_text: str,
) -> Optional[Tuple[List[str], List[List[str]]]]:
    """
    Parse the first HTML table into headers and rows.

    Supports both actual HTML and entity-escaped HTML.
    """
    if not html_text:
        return None

    html_text = html.unescape(html_text)

    if "<table" not in html_text.lower():
        return None

    table_match = re.search(
        r"<table\b[^>]*>(.*?)</table\s*>",
        html_text,
        flags=re.DOTALL | re.IGNORECASE,
    )

    if not table_match:
        return None

    table_html = table_match.group(1)
    rows_raw: List[List[str]] = []

    for tr_match in re.finditer(
        r"<tr\b[^>]*>(.*?)</tr\s*>",
        table_html,
        flags=re.DOTALL | re.IGNORECASE,
    ):
        row_html = tr_match.group(1)

        cells = re.findall(
            r"<t[hd]\b[^>]*>(.*?)</t[hd]\s*>",
            row_html,
            flags=re.DOTALL | re.IGNORECASE,
        )

        if not cells:
            continue

        rows_raw.append([
            _strip_html_tags(cell)
            for cell in cells
        ])

    if not rows_raw:
        return None

    headers = rows_raw[0]
    data_rows = rows_raw[1:]

    return headers, data_rows


def _abs_path_for_write(path: str) -> str:
    """
    Normalize path for python-docx save. On Windows, very long paths under deep
    directories (e.g. OneDrive) can exceed legacy MAX_PATH and raise FileNotFoundError;
    use the extended-length prefix when needed.
    """
    if os.name != "nt":
        return path
    abs_p = os.path.abspath(path)
    if abs_p.startswith("\\\\?\\"):
        return abs_p
    if len(abs_p) < 240:
        return abs_p
    if abs_p.startswith("\\\\"):
        return "\\\\?\\UNC\\" + abs_p[2:].replace("/", "\\")
    return "\\\\?\\" + abs_p.replace("/", "\\")

_HEADING_ALIASES = (
    "heading",
    "title",
    "section_title",
)

_BODY_ALIASES = (
    "body",
    "text",
    "content",
)


def _first_non_empty_alias(
    obj: Dict[str, Any],
    aliases: Tuple[str, ...],
) -> str:
    for key in aliases:
        value = obj.get(key)

        if value is None:
            continue

        normalized = _normalize_markdown_text(value).strip()

        if normalized:
            return normalized

    return ""

def _is_redundant_title_section(
    sec: Dict[str, Any],
    document_title: str,
) -> bool:
    heading = str(
        sec.get("heading")
        or ""
    ).strip().casefold()

    body = str(
        sec.get("body")
        or ""
    ).strip().casefold()

    normalized_title = str(
        document_title
        or ""
    ).strip().casefold()

    title_page_headings = {
        "title page",
        "1. title page",
    }

    return (
        heading in title_page_headings
        and body == normalized_title
    )


# Below this there is no document to render -- a title and a few words. The
# previous gate also rejected when *most* sections were thin, which discarded
# the sections that were not; a partial document a reader can see is worth more
# than an error they cannot act on, so only the empty case is refused now.
_MIN_DOCUMENT_CONTENT_CHARS = 200


class DocxGeneratorService:
    """Create .docx files from structured sections, tables, and optional charts."""

    def __init__(self, output_dir: str = None) -> None:
        self.output_dir = output_dir or os.path.join("uploads", "generated", "docx")
        os.makedirs(self.output_dir, exist_ok=True)

    def _add_table(
        self,
        doc: Any,
        headers: List[str],
        rows: List[List[Any]],
    ) -> None:
        from docx.enum.table import WD_TABLE_ALIGNMENT
        from docx.shared import Inches, Pt

        # hdr = [_sanitize_docx_text(h) for h in (headers or [])]
        hdr = [
            _sanitize_docx_text(
                self._clean_markdown_cell_text(h)
            )
            for h in (headers or [])
        ]
        rws = rows or []
        ncols = max(len(hdr), max((len(r) for r in rws), default=0))
        if ncols == 0:
            return
        nrows = 1 + len(rws)
        table = doc.add_table(rows=nrows, cols=ncols)
        table.style = "Table Grid"
        table.autofit = True
        _apply_table_grid_borders(table)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        hdr_cells = table.rows[0].cells

        from docx.oxml import parse_xml
        from docx.oxml.ns import nsdecls

        for j in range(ncols):
            cell = hdr_cells[j]
            cell.text = hdr[j] if j < len(hdr) else ""

            shading = parse_xml(
            r'<w:shd {} w:fill="00338D"/>'.format(
                nsdecls("w")
            )
            )
        
            cell._tc.get_or_add_tcPr().append(shading)
        
            for p in cell.paragraphs:
                for run in p.runs:
                    run.bold = True
                    run.font.size = Pt(10)
                    run.font.color.rgb = RGBColor(
                        255,
                        255,
                        255
                    )

        for i, row in enumerate(rws, start=1):
            cells = table.rows[i].cells
            if i % 2 == 0:
                from docx.oxml import parse_xml
                from docx.oxml.ns import nsdecls

                for cell in cells:

                    shading = parse_xml(
                        r'<w:shd {} w:fill="F5F7FA"/>'.format(
                            nsdecls("w")
                        )
                    )

                    cell._tc.get_or_add_tcPr().append(
                        shading
                    )
            for j in range(ncols):
                # val = row[j] if j < len(row) else ""
                # cells[j].text = _sanitize_docx_text(val)
                val = row[j] if j < len(row) else ""

                cells[j].text = _sanitize_docx_text(
                    self._clean_markdown_cell_text(val)
                )

        doc.add_paragraph()


    def _add_markdown_runs(
            self,
            paragraph: Any,
            text: str,
        ) -> None:
            """
            Convert common inline Markdown into native Word runs.

            Supported:
            - bold
            - italic
            - bold italic
            - inline code
            - Markdown links
            - strikethrough
            """
            if not text:
                return

            text = _normalize_markdown_text(text)

            token_pattern = re.compile(
                r"(\*\*\*.+?\*\*\*"
                r"|___.+?___"
                r"|\*\*.+?\*\*"
                r"|__.+?__"
                r"|~~.+?~~"
                r"|`[^`]+`"
                r"|\[[^\]]+\]\([^)]+\)"
                r"|\*[^*\n]+\*"
                r"|_[^_\n]+_)"
            )

            position = 0

            for match in token_pattern.finditer(text):
                start, end = match.span()

                if start > position:
                    paragraph.add_run(text[position:start])

                token = match.group(0)

                if token.startswith("***") and token.endswith("***"):
                    run = paragraph.add_run(token[3:-3])
                    run.bold = True
                    run.italic = True

                elif token.startswith("___") and token.endswith("___"):
                    run = paragraph.add_run(token[3:-3])
                    run.bold = True
                    run.italic = True

                elif token.startswith("**") and token.endswith("**"):
                    run = paragraph.add_run(token[2:-2])
                    run.bold = True

                elif token.startswith("__") and token.endswith("__"):
                    run = paragraph.add_run(token[2:-2])
                    run.bold = True

                elif token.startswith("~~") and token.endswith("~~"):
                    run = paragraph.add_run(token[2:-2])
                    run.font.strike = True

                elif token.startswith("`") and token.endswith("`"):
                    run = paragraph.add_run(token[1:-1])
                    run.font.name = "Consolas"

                elif token.startswith("["):
                    link_match = re.match(
                        r"^\[([^\]]+)\]\(([^)]+)\)$",
                        token,
                    )

                    if link_match:
                        label = link_match.group(1)
                        url = link_match.group(2)

                        run = paragraph.add_run(label)
                        run.font.color.rgb = RGBColor(
                            0x05,
                            0x63,
                            0xC1,
                        )
                        run.underline = True

                        # This displays the URL but does not create a true Word
                        # hyperlink relationship.
                        paragraph.add_run(f" ({url})")
                    else:
                        paragraph.add_run(token)

                elif token.startswith("*") and token.endswith("*"):
                    run = paragraph.add_run(token[1:-1])
                    run.italic = True

                elif token.startswith("_") and token.endswith("_"):
                    run = paragraph.add_run(token[1:-1])
                    run.italic = True

                else:
                    paragraph.add_run(token)

                position = end

            if position < len(text):
                paragraph.add_run(text[position:])


    def _clean_markdown_cell_text(self, value: Any) -> str:
        """
        Remove inline Markdown markers from table-cell text.

        Table cells are kept as plain text because a cell may contain multiple
        runs and paragraphs, but the Markdown markers must not leak through.
        """
        text = _normalize_markdown_text(value)

        text = re.sub(r"\*\*\*(.+?)\*\*\*", r"\1", text)
        text = re.sub(r"___(.+?)___", r"\1", text)
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        text = re.sub(r"__(.+?)__", r"\1", text)
        text = re.sub(r"~~(.+?)~~", r"\1", text)
        text = re.sub(r"`([^`]+)`", r"\1", text)
        text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", text)
        text = re.sub(r"\*([^*\n]+)\*", r"\1", text)
        text = re.sub(r"_([^_\n]+)_", r"\1", text)

        return text.strip()

    # def _render_rich_text(self, doc, text):
    
    #             bold_pattern = re.compile(r"\*\*(.*?)\*\*")
    
    #             for raw_line in text.splitlines():
    #                 line = raw_line.strip()
    #                 # line = line.replace("__", "**")
    #                 # line = line.replace("\\*", "*")
    #                 line = line.replace("__", "**")

    #                 line = re.sub(
    #                     r'\\([*_#`])',
    #                     r'\1',
    #                     line
    #                 )
    
    #                 if not line:
    #                     continue
    
    #                 if line.startswith("#### "):
    #                     doc.add_heading(line[5:].strip(),level=4)
    #                     continue

    #                 if line.startswith("### "):
    #                     doc.add_heading(line[4:].strip(), level=3)
    #                     continue

    #                 elif line.startswith("## "):
    #                     doc.add_heading(line[3:].strip(), level=2)
    #                     continue

    #                 elif line.startswith("# "):
    #                     continue
                
    #                 # Bullet lists
    #                 if line.startswith("- "):
    #                     doc.add_paragraph(
    #                         line[2:].strip(),
    #                         style="List Bullet"
    #                     )
    #                     continue
    
    #                 # Numbered lists
    #                 # if re.match(r"^\d+\.\s+", line):
    #                 #     txt = re.sub(r"^\d+\.\s+", "", line)
    #                 #     doc.add_paragraph(
    #                 #         txt,
    #                 #         style="List Number"
    #                 #     )
    #                 #     continue
    #                 if re.match(r"^\d+\.\s+", line):
    #                     txt = re.sub(
    #                         r"^\d+\.\s+",
    #                         "",
    #                         line
    #                     )

    #                     p = doc.add_paragraph(
    #                         style="List Number"
    #                     )

    #                     pos = 0

    #                     for match in bold_pattern.finditer(txt):

    #                         start, end = match.span()

    #                         if start > pos:
    #                             p.add_run(txt[pos:start])

    #                         r = p.add_run(match.group(1))
    #                         r.bold = True

    #                         pos = end

    #                     if pos < len(txt):
    #                         p.add_run(txt[pos:])

    #                     continue
    
    #                 # Normal paragraph with bold support
    #                 p = doc.add_paragraph()
    
    #                 pos = 0
    #                 for match in bold_pattern.finditer(line):
    
    #                     start, end = match.span()
    
    #                     if start > pos:
    #                         p.add_run(line[pos:start])
    
    #                     r = p.add_run(match.group(1))
    #                     r.bold = True
    
    #                     pos = end
    
    #                 if pos < len(line):
    #                     p.add_run(line[pos:])
        
    def _render_rich_text(
            self,
            doc: Any,
            text: str,
        ) -> None:
            """
            Render Markdown narrative into native Word elements.

            This method handles non-table Markdown. Markdown tables are processed
            by _render_markdown_body() so that their original document position is
            preserved.
            """
            if not isinstance(text, str) or not text.strip():
                return

            text = _normalize_markdown_text(text)

            for raw_line in text.splitlines():
                line = raw_line.rstrip()
                stripped = line.strip()

                if not stripped:
                    continue

                # Ignore fenced-code markers themselves. Code content is rendered
                # as an ordinary paragraph with a monospace font when supplied as
                # inline code.
                if stripped.startswith("```"):
                    continue

                # Horizontal rule: do not print --- into Word.
                if re.fullmatch(r"[-*_]\s*([-*_]\s*){2,}", stripped):
                    p = doc.add_paragraph()
                    p.paragraph_format.space_before = Pt(3)
                    p.paragraph_format.space_after = Pt(6)

                    run = p.add_run("─" * 72)
                    run.font.color.rgb = RGBColor(
                        0xD0,
                        0xD7,
                        0xDE,
                    )
                    continue

                # Markdown headings.
                heading_match = re.match(
                    r"^(#{1,6})\s+(.+?)\s*#*\s*$",
                    stripped,
                )

                if heading_match:
                    markdown_level = len(heading_match.group(1))
                    heading_text = heading_match.group(2).strip()

                    # Section headings are already Heading 1 in generate().
                    # Nested Markdown headings therefore start at Word Heading 2.
                    word_level = min(markdown_level + 1, 4)

                    doc.add_heading(
                        self._clean_markdown_cell_text(heading_text),
                        level=word_level,
                    )
                    continue

                # Block quotes.
                quote_match = re.match(r"^>\s?(.*)$", stripped)

                if quote_match:
                    try:
                        paragraph = doc.add_paragraph(
                            style="Intense Quote"
                        )
                    except KeyError:
                        paragraph = doc.add_paragraph()

                    self._add_markdown_runs(
                        paragraph,
                        quote_match.group(1),
                    )
                    continue

                # Unordered lists: -, *, or +.
                bullet_match = re.match(
                    r"^\s*[-+*]\s+(.+)$",
                    line,
                )

                if bullet_match:
                    paragraph = doc.add_paragraph(
                        style="List Bullet"
                    )

                    self._add_markdown_runs(
                        paragraph,
                        bullet_match.group(1).strip(),
                    )
                    continue

                # Ordered lists: 1. or 1)
                numbered_match = re.match(
                    r"^\s*\d+[.)]\s+(.+)$",
                    line,
                )

                if numbered_match:
                    paragraph = doc.add_paragraph(
                        style="List Number"
                    )

                    self._add_markdown_runs(
                        paragraph,
                        numbered_match.group(1).strip(),
                    )
                    continue

                # Ordinary paragraph.
                paragraph = doc.add_paragraph()

                self._add_markdown_runs(
                    paragraph,
                    stripped,
                )

    def _render_markdown_body(
        self,
        doc: Any,
        body: str,
    ) -> None:
        """
        Render Markdown in its original order.

        Unlike the previous approach, this method does not extract every table
        and place it before all narrative. It walks through the body and emits
        prose and tables in the sequence in which they appeared.
        """
        if not isinstance(body, str) or not body.strip():
            return

        body = _normalize_markdown_text(body)
        lines = body.splitlines()

        narrative_buffer: List[str] = []

        def flush_narrative() -> None:
            if not narrative_buffer:
                return

            narrative = "\n".join(narrative_buffer).strip("\n")
            narrative_buffer.clear()

            if narrative.strip():
                self._render_rich_text(
                    doc,
                    narrative,
                )

        i = 0

        while i < len(lines):
            current = lines[i]
            current_cells = _md_row_cells(current)

            # A Markdown table starts when the current row contains cells and
            # the immediately following row is a separator row.
            if (
                current_cells is not None
                and i + 1 < len(lines)
            ):
                separator_cells = _md_row_cells(lines[i + 1])

                if (
                    separator_cells is not None
                    and _is_md_separator_cells(separator_cells)
                ):
                    flush_narrative()

                    block = [
                        current,
                        lines[i + 1],
                    ]

                    i += 2

                    while i < len(lines):
                        row_cells = _md_row_cells(lines[i])

                        if row_cells is None:
                            break

                        block.append(lines[i])
                        i += 1

                    parsed = _parse_md_table_block(block)

                    if parsed:
                        headers, rows = parsed

                        clean_headers = [
                            self._clean_markdown_cell_text(value)
                            for value in headers
                        ]

                        clean_rows = [
                            [
                                self._clean_markdown_cell_text(value)
                                for value in row
                            ]
                            for row in rows
                        ]

                        self._add_table(
                            doc,
                            clean_headers,
                            clean_rows,
                        )
                    else:
                        # Safe fallback: if parsing fails, render the source as
                        # ordinary text without dropping content.
                        self._render_rich_text(
                            doc,
                            "\n".join(block),
                        )

                    continue

            narrative_buffer.append(current)
            i += 1

        flush_narrative()            
                
    # def _add_section_content(
    #     self,
    #     doc: Any,
    #     sec: Dict[str, Any],
    # ) -> None:
    #     from docx.shared import Inches

    #     body = sec.get("body") or ""
    #     table_obj = sec.get("table")
    #     charts = sec.get("charts") or []

    #     # Strip "Chart omitted" lines the LLM sometimes writes in body text instead of
    #     # passing proper chart objects — remove them so they never appear in the docx.
    #     if isinstance(body, str) and "chart omitted" in body.lower():
    #         body = "\n".join(
    #             ln for ln in body.split("\n")
    #             if "chart omitted" not in ln.lower()
    #         )

        

    #     # HTML tables in body → each becomes a native Word table (borders via _add_table)
    #     if isinstance(body, str):
    #         while "<table" in body.lower():
    #             parsed = _parse_simple_html_table(body)
    #             if not parsed:
    #                 break
    #             h, r = parsed
    #             self._add_table(doc, h, r)
    #             body = re.sub(
    #                 r"<table[^>]*>.*?</table>",
    #                 "",
    #                 body,
    #                 count=1,
    #                 flags=re.DOTALL | re.IGNORECASE,
    #             ).strip()

    #     # Markdown pipe tables (| col | col |) → native Word tables (LLMs often put
    #     # tables only in body text; without this each | line becomes a separate paragraph.)
    #     if isinstance(body, str):
    #         body, md_tables = _extract_markdown_pipe_tables(body)
    #         for h, r in md_tables:
    #             self._add_table(doc, h, r)

    #     # Narrative before tabular data (Executive Summary, etc.)
    #     # if isinstance(body, str):
    #     #     for line in body.split("\n"):
    #     #         line = line.strip()
    #     #         if line:
    #     #             doc.add_paragraph(_sanitize_docx_text(line))

    #     if isinstance(body, str):
    #         self._render_rich_text(doc, body)

    #     # Structured table after narrative in the same section
    #     if isinstance(table_obj, dict):
    #         h = table_obj.get("headers") or []
    #         r = table_obj.get("rows") or []
    #         if h or r:
    #             self._add_table(doc, list(h), [list(x) for x in r])

    #     for ch in charts:
    #         if not isinstance(ch, dict):
    #             continue
    #         title = str(ch.get("title") or "Chart")
    #         labels = [str(x) for x in (ch.get("labels") or [])]
    #         vals_raw = ch.get("values") or []
    #         values = [_coerce_chart_scalar(v) for v in vals_raw]
    #         png = _render_chart_image(title, ch)
    #         png_ok = (
    #             png is not None
    #             and len(png) >= 24
    #             and png[:8] == b"\x89PNG\r\n\x1a\n"
    #         )
    #         inserted = False
    #         if png_ok:
    #             try:
    #                 doc.add_paragraph(title, style="Heading 3")
    #                 stream = io.BytesIO(png)
    #                 stream.seek(0)
    #                 doc.add_picture(stream, width=Inches(6.2))
    #                 doc.add_paragraph()
    #                 inserted = True
    #             except Exception:
    #                 logger.exception(
    #                     "docx add_picture failed for chart %r (PNG %d bytes)",
    #                     title,
    #                     len(png or b""),
    #                 )
    #         if not inserted:
    #             ct = str(ch.get("chart_type") or "").lower()
    #             if ct == "heatmap":
    #                 hm, _, _ = _heatmap_matrix_from_chart(ch)
    #                 if hm:
    #                     cap = doc.add_paragraph(style="Caption")
    #                     cap.add_run(f"{title}: ").bold = True
    #                     cap.add_run(
    #                         " | ".join(
    #                             "[" + ", ".join(f"{x:.4g}" for x in row) + "]"
    #                             for row in hm
    #                         )
    #                     )
    #                     cap.add_run(
    #                         " (Install matplotlib on the API server for chart images.)"
    #                     )
    #                     doc.add_paragraph()
    #             elif labels and values and len(labels) == len(values):
    #                 # Matplotlib missing, invalid PNG, or add_picture failed — show series text.
    #                 cap = doc.add_paragraph(style="Caption")
    #                 cap.add_run(f"{title}: ").bold = True
    #                 pairs = ", ".join(
    #                     f"{lb}={val:.4g}" for lb, val in zip(labels, values)
    #                 )
    #                 cap.add_run(pairs)
    #                 if png_ok:
    #                     note = " (PNG generated but Word embedding failed.)"
    #                 else:
    #                     note = " (Install matplotlib on the API server for chart images.)"
    #                 cap.add_run(note)
    #                 doc.add_paragraph()

    def _add_section_content(
        self,
        doc: Any,
        sec: Dict[str, Any],
    ) -> None:
        from docx.shared import Inches

        body = sec.get("body") or ""
        table_obj = sec.get("table")
        charts = sec.get("charts") or []

        if isinstance(body, str):
            body = _normalize_markdown_text(body)

            body = "\n".join(
                line
                for line in body.splitlines()
                if "chart omitted" not in line.lower()
            ).strip()

            self._render_markdown_body(
                doc,
                body,
            )

        # Structured table supplied separately by the tool caller.
        if isinstance(table_obj, dict):
            h = table_obj.get("headers") or []
            r = table_obj.get("rows") or []

            if h or r:
                self._add_table(
                    doc,
                    list(h),
                    [
                        list(row)
                        for row in r
                        if isinstance(row, (list, tuple))
                    ],
                )

        for ch in charts:
            if not isinstance(ch, dict):
                continue
            title = str(ch.get("title") or "Chart")
            labels = [str(x) for x in (ch.get("labels") or [])]
            vals_raw = ch.get("values") or []
            values = [_coerce_chart_scalar(v) for v in vals_raw]
            png = _render_chart_image(title, ch)
            png_ok = (
                png is not None
                and len(png) >= 24
                and png[:8] == b"\x89PNG\r\n\x1a\n"
            )
            inserted = False
            if png_ok:
                try:
                    doc.add_paragraph(title, style="Heading 3")
                    stream = io.BytesIO(png)
                    stream.seek(0)
                    doc.add_picture(stream, width=Inches(6.2))
                    doc.add_paragraph()
                    inserted = True
                except Exception:
                    logger.exception(
                        "docx add_picture failed for chart %r (PNG %d bytes)",
                        title,
                        len(png or b""),
                    )
            if not inserted:
                ct = str(ch.get("chart_type") or "").lower()
                if ct == "heatmap":
                    hm, _, _ = _heatmap_matrix_from_chart(ch)
                    if hm:
                        cap = doc.add_paragraph(style="Caption")
                        cap.add_run(f"{title}: ").bold = True
                        cap.add_run(
                            " | ".join(
                                "[" + ", ".join(f"{x:.4g}" for x in row) + "]"
                                for row in hm
                            )
                        )
                        cap.add_run(
                            " (Install matplotlib on the API server for chart images.)"
                        )
                        doc.add_paragraph()
                elif labels and values and len(labels) == len(values):
                    # Matplotlib missing, invalid PNG, or add_picture failed — show series text.
                    cap = doc.add_paragraph(style="Caption")
                    cap.add_run(f"{title}: ").bold = True
                    pairs = ", ".join(
                        f"{lb}={val:.4g}" for lb, val in zip(labels, values)
                    )
                    cap.add_run(pairs)
                    if png_ok:
                        note = " (PNG generated but Word embedding failed.)"
                    else:
                        note = " (Install matplotlib on the API server for chart images.)"
                    cap.add_run(note)
                    doc.add_paragraph()
   
    def generate(self, input_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Entry point for Word document generation.
        Called by ToolExecutor with a single input_data dict.
        """

        # -----------------------------
        # 1. Extract inputs safely
        # -----------------------------
        # title = input_data.get("title", "Report")
        # sections = input_data.get("sections") or []
        # # include_charts = input_data.get("include_charts", True)
        # include_charts = bool(
        #     input_data.get("include_charts", False)
        # )

        # logger.info("========== DOCX TOOL INVOKED ==========")

        # logger.info(
        #     "RAW_DATA_TYPE=%s",
        #     type(input_data).__name__
        # )

        # logger.info(
        #     "DOCX request received: title=%r sections=%d "
        #     "include_charts=%s",
        #     title,
        #     len(sections) if isinstance(sections, list) else 0,
        #     include_charts,
        # )

        # logger.info(
        #     "TITLE=%s",
        #     title,
        # )

        # logger.info(
        #         "SECTIONS_TYPE=%s",
        #         type(sections).__name__,
        #     )
        

        # logger.info(
        #     "SECTION_COUNT=%s",
        #     len(sections),
        # )

        # logger.info(
        #     "INCLUDE_CHARTS=%s",
        #     include_charts,
        # )

        # session_id = (
        # input_data.get("session_id")
        # or input_data.get("chat_session_id")
        # or str(uuid.uuid4())
        # )

        raw_title = input_data.get("title")

        title = (
            _normalize_markdown_text(raw_title).strip()
            if raw_title is not None
            else ""
        ) or "Report"

        sections = input_data.get("sections")

        include_charts = bool(
            input_data.get("include_charts", False)
        )

        session_id = (
            input_data.get("session_id")
            or input_data.get("chat_session_id")
            or str(uuid.uuid4())
        )

        if not isinstance(sections, list):
            return {
                "result": (
                    "ERROR: 'sections' must be a non-empty array "
                    "of section objects."
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        if not sections:
            return {
                "result": (
                    "ERROR: At least one document section is required."
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        logger.info("========== DOCX TOOL INVOKED ==========")

        logger.info(
            "DOCX request received: title=%r sections=%d "
            "include_charts=%s",
            title,
            len(sections),
            include_charts,
        )

        # # -----------------------------
        # # 1b. Reject sparse content — force file_reader first
        # # -----------------------------
        # _sparse_phrases = (
        #     "not disclosed", "not available", "n/a", "placeholder",
        #     "to be determined", "data not provided", "information not available",
        # )
        # if sections:
        #     sparse_count = 0
        #     total_body_len = 0
        #     for sec in sections:
        #         body = ""
        #         if isinstance(sec, dict):
        #             body = sec.get("body") or sec.get("text") or sec.get("content") or ""
        #         if isinstance(body, str):
        #             total_body_len += len(body.strip())
        #             low = body.strip().lower()
        #             # if not low or any(p in low for p in _sparse_phrases):
        #             #     sparse_count += 1
        #             placeholder_only = (
        #                 low in _sparse_phrases
        #                 or low.startswith("placeholder")
        #             )

        #             if not low or placeholder_only:
        #                 sparse_count += 1
        #     # If most sections are sparse or total content is very thin,
        #     # reject and tell LLM to call file_reader first
        #     if len(sections) > 1 and (
        #         sparse_count > len(sections) // 2
        #         or total_body_len < 200
        #     ):
        #         return {
        #             "result": (
        #                 "ERROR: The document content is too sparse or contains mostly "
        #                 "'Not disclosed' / placeholder text. Provide richer grounded sections "
        #                 "with concrete data, tables, and charts. If source documents were "
        #                 "uploaded, you can optionally use file_reader first to improve "
        #                 "content quality before calling word_document_generator again."
        #             ),
        #             "file_path": "",
        #             "filename": "",
        #             "file_id": "",
        #         }

        #             # -----------------------------
        # # 1c. Validate section structure
        # # -----------------------------

        # -----------------------------
        # 1b. Reject genuinely sparse content
        # -----------------------------
        sparse_phrases = {
            "not disclosed",
            "not available",
            "n/a",
            "placeholder",
            "to be determined",
            "data not provided",
            "information not available",
        }

        sparse_count = 0
        total_content_size = 0

        for sec in sections:
            if not isinstance(sec, dict):
                sparse_count += 1
                continue

            raw_body = (
                sec.get("body")
                or sec.get("text")
                or sec.get("content")
                or ""
            )

            body_text = (
                _normalize_markdown_text(raw_body).strip()
                if isinstance(raw_body, str)
                else ""
            )

            table_obj = sec.get("table")
            table_headers: List[Any] = []
            table_rows: List[Any] = []

            if isinstance(table_obj, dict):
                table_headers = table_obj.get("headers") or []
                table_rows = table_obj.get("rows") or []

            table_size = sum(
                len(str(value))
                for value in table_headers
            )

            table_size += sum(
                len(str(cell))
                for row in table_rows
                if isinstance(row, (list, tuple))
                for cell in row
            )

            charts_obj = sec.get("charts")
            chart_size = 0

            if include_charts and isinstance(charts_obj, list):
                chart_size = sum(
                    len(str(chart))
                    for chart in charts_obj
                )

            section_content_size = (
                len(body_text)
                + table_size
                + chart_size
            )

            total_content_size += section_content_size

            lower_body = body_text.casefold()

            placeholder_only = (
                lower_body in sparse_phrases
                or lower_body.startswith("placeholder")
            )

            if section_content_size == 0 or placeholder_only:
                sparse_count += 1

        # Reject only a document that would be genuinely empty.
        #
        # This gate exists to stop a placeholder document reaching a reader, and
        # that is worth keeping. But it used to fire on two conditions, and one
        # of them was wrong: rejecting because *most* sections were thin threw
        # away the sections that were not. A twelve-section report with seven
        # thin ones still carries five real ones, and a partial document a
        # reader can see beats an error they cannot act on.
        #
        # What remains is the honest floor: below this there is no document to
        # render at all. Everything above it is generated, and a thin section is
        # reported in the result rather than used to discard the work.
        if total_content_size < _MIN_DOCUMENT_CONTENT_CHARS:
            return {
                "result": (
                    "ERROR: There is not enough content to generate a document "
                    f"({total_content_size} characters across "
                    f"{len(sections)} section(s)). Each section needs real "
                    "narrative text in 'body', and tables where the data "
                    "supports them. If source documents were uploaded, read "
                    "them with file_reader first, then call this tool again "
                    "with the full content."
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        # -----------------------------
        # 1c. Validate section structure
        # -----------------------------
        # if not isinstance(sections, list):
        #     return {
        #         "result": (
        #             "ERROR: 'sections' must be an array of section objects."
        #         ),
        #         "file_path": "",
        #         "filename": "",
        #         "file_id": "",
        #         "download_url": "",
        #         "session_id": session_id,
        #     }

        invalid_section_types: List[int] = []
        missing_heading_sections: List[int] = []
        missing_content_sections: List[int] = []

        for idx, sec in enumerate(sections, start=1):
            if not isinstance(sec, dict):
                invalid_section_types.append(idx)
                continue

            resolved_heading = _first_non_empty_alias(
                sec,
                _HEADING_ALIASES,
            )

            resolved_body = _first_non_empty_alias(
                sec,
                _BODY_ALIASES,
            )

            table_obj = sec.get("table")

            has_structured_table = (
                isinstance(table_obj, dict)
                and bool(
                    table_obj.get("headers")
                    or table_obj.get("rows")
                )
            )

            charts_obj = sec.get("charts")

            # has_charts = (
            #     include_charts
            #     and isinstance(charts_obj, list)
            #     and bool(charts_obj)
            # )

            has_charts = (
                include_charts
                and isinstance(charts_obj, list)
                and _charts_are_renderable(
                    [
                        chart
                        for chart in charts_obj
                        if isinstance(chart, dict)
                    ]
                )
            )

            logger.info(
                "[RAW SECTION %s] heading=%r title=%r "
                "section_title=%r resolved_heading=%r "
                "body_present=%s table_present=%s charts_present=%s",
                idx,
                sec.get("heading"),
                sec.get("title"),
                sec.get("section_title"),
                resolved_heading,
                bool(resolved_body),
                has_structured_table,
                has_charts,
            )

            if not resolved_heading:
                missing_heading_sections.append(idx)

            if (
                not resolved_body
                and not has_structured_table
                and not has_charts
            ):
                missing_content_sections.append(idx)

        if invalid_section_types:
            return {
                "result": (
                    "ERROR: Every section must be an object. "
                    f"Invalid section indexes: {invalid_section_types}"
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        if missing_heading_sections:
            return {
                "result": (
                    "ERROR: Every section must include a non-empty heading. "
                    "Accepted heading fields are: heading, title, and "
                    "section_title. "
                    f"Missing heading at section indexes: "
                    f"{missing_heading_sections}"
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        if missing_content_sections:
            return {
                "result": (
                    "ERROR: Every section must include body content, a "
                    "structured table, or chart data. "
                    f"Missing content at section indexes: "
                    f"{missing_content_sections}"
                ),
                "file_path": "",
                "filename": "",
                "file_id": "",
                "download_url": "",
                "session_id": session_id,
            }

        # -----------------------------
        # 2. Normalize sections
        # -----------------------------
        # logger.info(
        #     "RAW_SECTIONS=%s",
        #     json.dumps(
        #         sections,
        #         default=str,
        #         indent=2,
        #     )
        # )

        # for idx, sec in enumerate(sections, start=1):
        #     logger.info(
        #         "[RAW SECTION %s] heading=%r title=%r",
        #         idx,
        #         sec.get("heading"),
        #         sec.get("title"),
        #     )

        # for idx, sec in enumerate(sections, start=1):
        #     if not isinstance(sec, dict):
        #         logger.warning(
        #             "[RAW SECTION %s] ignored because value is not an object: %r",
        #             idx,
        #             sec,
        #         )
        #         continue

        #     logger.info(
        #         "[RAW SECTION %s] heading=%r title=%r",
        #         idx,
        #         sec.get("heading"),
        #         sec.get("title"),
        #     )

        sections = normalize_docx_sections(
            [dict(s) for s in sections if isinstance(s, dict)],
            include_charts=include_charts,
        )

        invalid_normalized_headings = [
            idx
            for idx, sec in enumerate(sections, start=1)
            if not str(sec.get("heading") or "").strip()
        ]

        if invalid_normalized_headings:
            raise ValueError(
                "Section normalization produced empty headings at "
                f"indexes: {invalid_normalized_headings}"
            )

        # logger.info(
        #     "NORMALIZED_SECTIONS=%s",
        #     json.dumps(
        #         sections,
        #         default=str,
        #         indent=2,
        #     )
        # )

        # for idx, sec in enumerate(sections, start=1):
        #     logger.info(
        #         "[NORMALIZED SECTION %s] heading=%r",
        #         idx,
        #         sec.get("heading"),
        #     )

        for idx, sec in enumerate(sections, start=1):
            logger.info(
                "[NORMALIZED SECTION %s] heading=%r "
                "body_length=%d table_present=%s chart_count=%d",
                idx,
                sec.get("heading"),
                len(str(sec.get("body") or "")),
                isinstance(sec.get("table"), dict),
                len(sec.get("charts") or []),
            )

        # -----------------------------
        # 3. Build Word document
        # -----------------------------
        from docx import Document
        from docx.shared import Pt

        doc = Document()
        from docx.shared import Inches

        section = doc.sections[0]

        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

        from docx.shared import RGBColor, Pt, Inches

        for style_name in [
            "Heading 1",
            "Heading 2",
            "Heading 3"
        ]:

            style = doc.styles[style_name]

            style.font.color.rgb = RGBColor(
                0x00,
                0x33,
                0x8D
            )

            style.font.name = "Aptos Display"

        style = doc.styles["Normal"]
        style.font.size = Pt(11)
        style.font.name = "Aptos"

        style.paragraph_format.space_after = Pt(6)

        # KPMG format: logo header on every page + KPMG-blue title (default for
        # every document so the downloadable file is always KPMG-branded).
        _apply_kpmg_branding(doc, title)

        # for sec in sections:
        #     heading = (sec.get("heading") or "Section").strip()
        #     doc.add_heading(heading, level=1)
        #     self._add_section_content(doc, sec)

        # for idx, sec in enumerate(sections, start=1):

        #     heading = (
        #         sec.get("heading")
        #         or f"Untitled Section {idx}"
        #     ).strip()

        #     doc.add_heading(
        #         heading,
        #         level=1
        #     )

        #     self._add_section_content(doc, sec)

        # for idx, sec in enumerate(sections, start=1):
        #     heading = str(
        #         sec.get("heading")
        #         or ""
        #     ).strip()

        #     if not heading:
        #         raise ValueError(
        #             f"Normalized section {idx} has no heading"
        #         )

        #     doc.add_heading(
        #         heading,
        #         level=1,
        #     )

        #     self._add_section_content(
        #         doc,
        #         sec,
        #     )

        for idx, sec in enumerate(sections, start=1):
            heading = str(
                sec.get("heading")
                or ""
            ).strip()

            if not heading:
                raise ValueError(
                    f"Normalized section {idx} has no heading"
                )

            if _is_redundant_title_section(
                sec,
                title,
            ):
                logger.info(
                    "Skipping redundant title-page section at index %s",
                    idx,
                )
                continue

            doc.add_heading(
                heading,
                level=1,
            )

            self._add_section_content(
                doc,
                sec,
            )

        # -----------------------------
        # 4. Save file
        # -----------------------------
        file_id = str(uuid.uuid4())
        filename = _safe_docx_filename(title)

        path = os.path.join(
            self.output_dir,
            f"{file_id}_{filename}"
        )
        abs_file_path = _abs_path_for_write(path)

        os.makedirs(self.output_dir, exist_ok=True)
        doc.save(abs_file_path)

        logger.info(
            "DOCX generated: %s",
            filename,
        )


        blob_name = (
            f"generated/doc/"
            f"{session_id}/"
            f"{file_id}/"
            f"{filename}"
        )

        uploaded = upload_to_blob(
            local_path=abs_file_path,
            blob_name=blob_name,
        )

        if not uploaded:
            raise RuntimeError(
                f"Failed to upload DOCX to Azure Blob Storage: {blob_name}"
            )

        download_url = get_blob_url(blob_name)

        logger.info(
            "DOWNLOAD_URL=%s",
            download_url,
        )

        try:
            os.remove(abs_file_path)
        except Exception:
            logger.warning(
                "Failed to remove local DOCX: %s",
                abs_file_path,
            )

        # -----------------------------
        # 5. Emit generated file
        # -----------------------------
        
        # return {
        #     "result": (
        #         f"Word document '{title}' generated successfully.\n\n"
        #         f"Download URL:\n{download_url}"
        #         ),
        #         "filename": display_name,
        #         "file_id": file_id,
        #         "blob_name": blob_name,
        #         "download_url": download_url,
        #         "session_id": session_id,
        #         }

        return {
            "file_path": download_url,
            "filename": filename,
            "file_id": file_id,
            "download_url": download_url,
            "session_id": session_id,
            "result": (
                f"File generated successfully.\n\n"
                f"Download URL:\n{download_url}"
            ),
        }