"""
Build a Python module whose docstrings doxypypy can translate for Doxygen.

Sections are emitted as functions with docstrings to avoid a single giant
module docstring that could break on user ``\"\"\"`` sequences.
"""

from __future__ import annotations

import re
import textwrap
from typing import Any, Dict, List, Optional


def _strip_triple_quote_risk(s: str) -> str:
    """Avoid closing a triple-quoted docstring early."""
    if not s:
        return ""
    return s.replace('"""', "〝〝〝")


def _escape_backslashes_for_docstring(s: str) -> str:
    return (s or "").replace("\\", "\\\\")


def _format_table_verbatim(headers: List[str], rows: List[List[str]], max_rows: int = 200) -> str:
    if not headers:
        return ""
    lines = []
    col_w = [len(str(h)) for h in headers]
    norm_rows: List[List[str]] = []
    for row in rows[:max_rows]:
        cells = [str(c) for c in row]
        norm_rows.append(cells)
        for i, c in enumerate(cells):
            if i < len(col_w):
                col_w[i] = max(col_w[i], len(c))
    sep = " | ".join(str(h).ljust(col_w[i]) for i, h in enumerate(headers))
    lines.append(sep)
    lines.append("-" * len(sep))
    for cells in norm_rows:
        padded = []
        for i in range(len(headers)):
            t = cells[i] if i < len(cells) else ""
            padded.append(t.ljust(col_w[i]))
        lines.append(" | ".join(padded))
    if len(rows) > max_rows:
        lines.append(f"... ({len(rows) - max_rows} more rows omitted)")
    inner = "\n".join(lines)
    return f"\\verbatim\n{inner}\n\\endverbatim\n"


def build_python_source_for_doxygen(
    title: str,
    sections: List[Dict[str, Any]],
    *,
    author: Optional[str] = None,
    company: Optional[str] = None,
    generate_toc: bool = True,
) -> str:
    """
    Produce UTF-8 Python source for doxypypy → Doxygen → RTF → docx.

    Args:
        title: Document title (@mainpage).
        sections: Normalized section dicts (heading, body, optional table).
        author: Optional @author line in module docstring.
        company: Optional extra metadata line.
        generate_toc: When True, request table of contents in module docstring.
    """
    title = (title or "").strip() or "Report"
    title_line = _strip_triple_quote_risk(_escape_backslashes_for_docstring(title))

    meta_lines: List[str] = []
    if author:
        au = _strip_triple_quote_risk(_escape_backslashes_for_docstring(author))
        meta_lines.append(f"\\author {au}")
    if company:
        co = _strip_triple_quote_risk(_escape_backslashes_for_docstring(company))
        meta_lines.append(f"\\par Organization:\n{co}")
    toc_line = "\\tableofcontents" if generate_toc else ""
    meta_block = "\n".join(x for x in meta_lines if x)

    module_doc = f'''"""
@mainpage {title_line}

{meta_block}

{toc_line}
"""

# EchoAI auto-generated documentation source for Doxygen (filtered by doxypypy).
# pylint: disable=missing-function-docstring,unused-argument

'''

    parts: List[str] = [module_doc]

    for idx, sec in enumerate(sections):
        if not isinstance(sec, dict):
            continue
        heading = _strip_triple_quote_risk(
            _escape_backslashes_for_docstring((sec.get("heading") or "Section").strip())
        )
        body = _strip_triple_quote_risk(
            _escape_backslashes_for_docstring((sec.get("body") or "").strip())
        )
        body_wrapped = textwrap.dedent(body).strip()

        sub: List[str] = [heading, "", body_wrapped]

        tb = sec.get("table")
        if isinstance(tb, dict):
            hdrs = tb.get("headers") or []
            rws = tb.get("rows") or []
            if hdrs and rws:
                sub.append("")
                sub.append(_format_table_verbatim([str(x) for x in hdrs], rws))

        inner = "\n".join(sub).strip()
        inner = inner.replace('"""', "〝〝〝")

        safe_id = re.sub(r"[^0-9a-zA-Z_]+", "_", heading)[:40].strip("_") or "section"
        func_name = f"section_{idx:03d}_{safe_id}"

        parts.append(
            f"def {func_name}():\n"
            f'    r"""\n'
            f"{inner}\n"
            f'    """\n'
            f"    pass\n\n"
        )

    return "".join(parts)
