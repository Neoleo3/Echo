"""
Word (.docx) report generator using Doxygen.

Uses Doxygen for professional document generation via RTF → DOCX conversion.
All styling is configurable, with ZERO hardcoding.
"""

import logging
import os
import re
import uuid
from typing import Any, Dict, List, Optional, Set, Tuple

from ..config import get_config
from ..exceptions import InvalidDocumentStructureError
from .doxygen_handler import DoxygenHandler
from .doxygen_input_builder import DoxygenInputBuilder

logger = logging.getLogger(__name__)


# =============================================================================
# HELPER FUNCTIONS - Text sanitization and normalization
# =============================================================================

_NOT_DISCLOSED = "Not disclosed in provided documents"
_PLACEHOLDER_CELL = re.compile(
    r"^placeholder(\s+for\s+[\w\s,.'-]+)?$",
    re.IGNORECASE,
)


def _sanitize_docx_text(val: Any) -> str:
    """Replace LLM placeholder tokens with grounded wording."""
    if val is None:
        return _NOT_DISCLOSED
    s = str(val).strip()
    if not s:
        return _NOT_DISCLOSED
    low = s.lower()
    if low == "placeholder" or _PLACEHOLDER_CELL.match(s):
        return _NOT_DISCLOSED
    if "placeholder" in low:
        return _NOT_DISCLOSED
    return s


def _safe_docx_filename(title: str) -> str:
    """Human-readable .docx filename; avoid aggressive truncation mid-token."""
    raw = (title or "").strip() or "Report"
    slug = "".join(c if c.isalnum() or c in " -_" else " " for c in raw)
    slug = re.sub(r"\s+", " ", slug).strip(" ._")[:100]
    if not slug:
        slug = "Report"
    if not slug.lower().endswith(".docx"):
        slug = f"{slug}.docx"
    return slug


def normalize_docx_sections(
    sections: List[Dict[str, Any]],
    *,
    include_charts: bool = False,
) -> List[Dict[str, Any]]:
    """
    Accept LLM quirks: ``title`` instead of ``heading``; ``text`` instead of ``body``;
    normalize section data for Doxygen input.
    
    When ``include_charts`` is False (default), section ``charts`` are cleared.
    Set True when the caller wants chart descriptions to be included as captions.
    """
    out: List[Dict[str, Any]] = []
    for raw in sections or []:
        if not isinstance(raw, dict):
            continue
        sec = dict(raw)
        head = (sec.get("heading") or "").strip()
        if not head:
            t = sec.get("title")
            if isinstance(t, str) and t.strip():
                sec["heading"] = t.strip()
            else:
                sec["heading"] = "Section"
        sec.pop("title", None)

        # Narrative: many LLMs use "text" instead of "body"
        b = sec.get("body")
        tx = sec.get("text")
        if isinstance(b, str) and b.strip():
            merged = b
        elif isinstance(tx, str) and tx.strip():
            merged = tx
        elif isinstance(b, str):
            merged = b
        else:
            merged = ""
        sec.pop("text", None)

        if isinstance(merged, str):
            lines = []
            for line in merged.split("\n"):
                t = line.strip()
                lines.append(_sanitize_docx_text(t) if t else "")
            sec["body"] = "\n".join(lines)
        else:
            sec["body"] = ""

        # Process chart list
        charts_raw = sec.get("charts")
        charts_norm: List[Dict[str, Any]] = []
        if include_charts and isinstance(charts_raw, list):
            for ch in charts_raw:
                if isinstance(ch, dict):
                    charts_norm.append(dict(ch))
                elif isinstance(ch, str) and ch.strip():
                    charts_norm.append({
                        "title": ch.strip(),
                        "labels": [],
                        "values": [],
                        "chart_type": "bar",
                    })
        sec["charts"] = charts_norm

        # Process table
        if isinstance(sec.get("table"), dict):
            tb = dict(sec["table"])
            hdrs = [_sanitize_docx_text(x) for x in (tb.get("headers") or [])]
            rows = []
            for row in tb.get("rows") or []:
                if isinstance(row, (list, tuple)):
                    rows.append([_sanitize_docx_text(c) for c in row])
                else:
                    rows.append([_sanitize_docx_text(row)])
            tb["headers"] = hdrs
            tb["rows"] = rows
            sec["table"] = tb

        out.append(sec)
    return out


# =============================================================================
# TOOL DEFINITION
# =============================================================================

TOOL_DEFINITION = {
    "tool_id": "docx_generator",
    "name": "Word Document Generator",
    "description": (
        "ONLY use when the user EXPLICITLY asks for a Word document, .docx file, or "
        "an editable report as Word. "
        "Each section uses `heading` (or alias `title`). "
        "Put comparative KPIs in `table`: { \"headers\": [...], \"rows\": [[...], ...] }. "
        "Never use the word Placeholder in cells—use figures from uploaded context only, else "
        "write \"Not disclosed in provided documents\". "
        "Set top-level `include_charts` to true when the report should include chart descriptions. "
        "Use `body` or `text` for narrative paragraphs (Executive Summary, analysis). "
        "GFM markdown pipe tables (| col | col | with --- separator) in `body` are supported. "
        "If the user asks to extend a report, call again with the full sections list "
        "(existing content summarized or repeated plus new sections). "
        "Returns a downloadable file path. "
        "Documents are generated using Doxygen for professional formatting."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Document title (shown in the document)",
            },
            "include_charts": {
                "type": "boolean",
                "default": False,
                "description": (
                    "True to include chart descriptions. "
                    "Use true whenever the brief requires figures/charts."
                ),
            },
            "sections": {
                "type": "array",
                "description": "Ordered sections",
                "items": {
                    "type": "object",
                    "properties": {
                        "heading": {
                            "type": "string",
                            "description": "Section heading (alias: title)",
                        },
                        "title": {
                            "type": "string",
                            "description": "Same as heading if heading omitted",
                        },
                        "body": {
                            "type": "string",
                            "description": "Plain text paragraphs (newlines); alias: text",
                        },
                        "text": {
                            "type": "string",
                            "description": "Same as body — narrative for this section",
                        },
                        "table": {
                            "type": "object",
                            "description": "KPI / data table as headers + rows",
                            "properties": {
                                "headers": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "rows": {
                                    "type": "array",
                                    "items": {"type": "array"},
                                },
                            },
                        },
                        "charts": {
                            "type": "array",
                            "description": "Chart descriptions (included as captions in output)",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {"type": "string"},
                                    "chart_type": {
                                        "type": "string",
                                        "enum": ["bar", "line", "heatmap"],
                                    },
                                },
                            },
                        },
                    },
                    "required": [],
                },
            },
        },
        "required": ["title", "sections"],
    },
    "capabilities": ["docx_generation", "word_export", "doxygen_powered"],
}


# =============================================================================
# MAIN SERVICE CLASS
# =============================================================================

class DocxGeneratorService:
    """
    DOCX generation service using Doxygen.
    
    Generates professional Word documents via Doxygen RTF output and Pandoc conversion.
    All styling is config-driven with no hardcoding.
    """
    
    def __init__(self):
        """Initialize DOCX generator service."""
        self.config = get_config()
        self.output_dir = self.config.paths.doc_dir
        self.doxygen_handler = DoxygenHandler()
        self.input_builder = DoxygenInputBuilder()
        
        logger.info(
            "DocxGeneratorService initialized - Doxygen: %s, Pandoc: %s, Timeout: %ds",
            self.config.doxygen_generator.doxygen_executable,
            self.config.doxygen_generator.pandoc_executable,
            self.config.doxygen_generator.subprocess_timeout
        )
    
    def generate(
        self,
        title: str,
        sections: List[Dict[str, Any]],
        *,
        include_charts: bool = False,
    ) -> Dict[str, str]:
        """
        Generate DOCX document using Doxygen.
        
        Args:
            title: Document title
            sections: List of section dicts with 'heading', 'body', 'table', 'charts'
            include_charts: Whether to include chart descriptions as captions
        
        Returns:
            Dict with 'file_path', 'filename', 'file_id'
            
        Raises:
            InvalidDocumentStructureError: Document structure is invalid
            DoxygenGenerationError: Doxygen generation failed
            RTFToDOCXConversionError: Pandoc conversion failed
        """
        # Normalize sections
        sections = normalize_docx_sections(
            [dict(s) for s in (sections or []) if isinstance(s, dict)],
            include_charts=include_charts,
        )
        
        logger.debug(
            "Generating DOCX: title=%s, sections=%d, include_charts=%s",
            title,
            len(sections),
            include_charts
        )
        
        try:
            # Build Doxygen input
            dox_content = self.input_builder.build_dox_input(
                title=title,
                sections=sections,
                author=self.config.doxygen_generator.doc_author,
                company=self.config.doxygen_generator.doc_company
            )
            
            logger.debug("Doxygen input built: %d bytes", len(dox_content))
            
            # Generate unique file ID
            file_id = str(uuid.uuid4())
            display_name = _safe_docx_filename(title)
            disk_name = f"{file_id}.docx"
            output_path = os.path.join(self.output_dir, disk_name)
            
            # Ensure output directory exists
            os.makedirs(self.output_dir, exist_ok=True)
            
            # Generate DOCX via Doxygen
            success, message = self.doxygen_handler.generate_docx(
                dox_content=dox_content,
                output_docx_path=output_path
            )
            
            if not success or not os.path.exists(output_path):
                raise InvalidDocumentStructureError(
                    f"DOCX generation failed: {message}"
                )
            
            file_size = os.path.getsize(output_path)
            logger.info(
                "DOCX generated successfully: %s (display=%s, size=%d bytes)",
                disk_name,
                display_name,
                file_size
            )
            
            return {
                "file_path": output_path,
                "filename": display_name,
                "file_id": file_id
            }
            
        except Exception as e:
            logger.error("DOCX generation failed: %s", str(e), exc_info=True)
            raise
