"""Word (.docx) report generator for agent downloads."""

from .service import DocxGeneratorService, TOOL_DEFINITION

__all__ = ["DocxGeneratorService", "TOOL_DEFINITION"]
