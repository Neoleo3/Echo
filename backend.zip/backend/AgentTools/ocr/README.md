# OCR Tool - Production Ready

Complete OCR (Optical Character Recognition) tool for extracting text and structured data from receipt images and documents.

## Features

✅ **Multiple OCR Engines**
- Tesseract (open-source, default)
- Google Cloud Vision API
- AWS Textract

✅ **6 Operations**
- Extract raw text
- Extract structured receipt data
- Detect text regions
- Extract table/line items
- Get confidence metrics
- Batch processing

✅ **Production Ready**
- Real OCR integration (not hardcoded samples)
- Works with any scanned document
- Automatic preprocessing
- Multi-language support
- Error handling

## Installation

### 1. Install Python Dependencies

```bash
# For Tesseract (recommended for local development)
pip install pytesseract pillow

# For Google Cloud Vision
pip install google-cloud-vision

# For AWS Textract
pip install boto3
```

### 2. Install Tesseract OCR Engine

**Ubuntu/Debian:**
```bash
sudo apt-get install tesseract-ocr
```

**macOS:**
```bash
brew install tesseract
```

**Windows:**
Download from: https://github.com/UB-Mannheim/tesseract/wiki

### 3. Verify Installation

```bash
tesseract --version
```

## Quick Start

```python
from ocr.service import OCRService

# Initialize with Tesseract
service = OCRService(engine="tesseract")

# Extract text from receipt
result = service.execute(
    operation="extract_receipt_data",
    image_path="path/to/receipt.jpg"
)

if result["success"]:
    receipt = result["receipt_data"]
    print(f"Merchant: {receipt['merchant_name']}")
    print(f"Total: ${receipt['total_amount']:.2f}")
    print(f"Date: {receipt['date']}")
```

## Operations

### 1. extract_text

Extract raw text from any image.

```python
result = service.execute(
    operation="extract_text",
    image_path="document.jpg",
    language="eng",           # Language code
    preprocessing=True,       # Apply enhancement
    confidence_threshold=0.7  # Minimum confidence
)

print(result["extracted_text"])
print(f"Confidence: {result['confidence_score']:.1%}")
```

**Output:**
```python
{
    "operation": "extract_text",
    "success": True,
    "extracted_text": "Full extracted text...",
    "confidence_score": 0.92,
    "character_count": 425,
    "line_count": 18,
    "warnings": []
}
```

### 2. extract_receipt_data

Extract structured data from receipts.

```python
result = service.execute(
    operation="extract_receipt_data",
    image_path="receipt.jpg"
)

receipt = result["receipt_data"]
```

**Output:**
```python
{
    "success": True,
    "receipt_data": {
        "merchant_name": "WALMART",
        "date": "01/15/2024",
        "time": "14:32",
        "total_amount": 23.49,
        "subtotal": 21.75,
        "tax_amount": 1.74,
        "payment_method": "VISA ****1234",
        "items": [
            {
                "description": "Milk 2%",
                "quantity": 1,
                "amount": 3.99,
                "unit_price": 3.99
            }
        ]
    },
    "confidence_score": 0.92,
    "validation": {
        "is_valid": True,
        "has_required_fields": True
    }
}
```

### 3. detect_text_regions

Get text locations with bounding boxes.

```python
result = service.execute(
    operation="detect_text_regions",
    image_path="document.jpg"
)

for region in result["text_regions"]:
    print(f"{region['text']} at ({region['bbox']['x']}, {region['bbox']['y']})")
```

### 4. extract_table_data

Extract line items and tables.

```python
result = service.execute(
    operation="extract_table_data",
    image_path="receipt.jpg"
)

for item in result["line_items"]:
    print(f"{item['description']}: ${item['amount']:.2f}")
```

### 5. get_text_confidence

Get detailed confidence metrics.

```python
result = service.execute(
    operation="get_text_confidence",
    image_path="document.jpg"
)

print(f"Overall: {result['overall_confidence']:.1%}")
print(f"Quality: {result['image_quality']:.1%}")
```

### 6. batch_process

Process multiple images at once.

```python
result = service.execute(
    operation="batch_process",
    image_paths=[
        "receipts/receipt1.jpg",
        "receipts/receipt2.jpg",
        "receipts/receipt3.jpg"
    ]
)

print(f"Processed: {result['successful']}/{result['total_processed']}")
```

## Using Different OCR Engines

### Tesseract (Default)

```python
service = OCRService(engine="tesseract")
```

**Pros:**
- Free and open-source
- No API costs
- Works offline
- Fast for local processing

**Cons:**
- Requires local installation
- Lower accuracy on poor quality images

### Google Cloud Vision

```python
# Setup
export GOOGLE_APPLICATION_CREDENTIALS="path/to/credentials.json"

# Usage
service = OCRService(engine="google_vision")
result = service.execute(
    operation="extract_receipt_data",
    image_path="receipt.jpg"
)
```

**Pros:**
- Highest accuracy
- Excellent with poor quality images
- No local installation
- Handles handwriting

**Cons:**
- API costs
- Requires internet
- Rate limits

### AWS Textract

```python
# Setup AWS credentials first
service = OCRService(engine="aws_textract")
```

**Pros:**
- Excellent table extraction
- Form field detection
- High accuracy on receipts
- AWS ecosystem integration

**Cons:**
- API costs
- Requires internet

## Base64 Image Support

Process images from base64 strings:

```python
import base64

# Convert image to base64
with open("receipt.jpg", "rb") as f:
    image_data = base64.b64encode(f.read()).decode('utf-8')

# Process
result = service.execute(
    operation="extract_receipt_data",
    image_data=image_data
)
```

## Multi-Language Support

```python
# Spanish
result = service.execute(
    operation="extract_text",
    image_path="recibo.jpg",
    language="spa"
)

# French
result = service.execute(
    operation="extract_text",
    image_path="reçu.jpg",
    language="fra"
)

# German
result = service.execute(
    operation="extract_text",
    image_path="beleg.jpg",
    language="deu"
)
```

Supported languages: `eng`, `spa`, `fra`, `deu`, `ita`, `por`, `rus`, `jpn`, `kor`, `chi_sim`, `chi_tra`, and many more.

## Image Preprocessing

The tool automatically applies preprocessing for better accuracy:

- Grayscale conversion
- Contrast enhancement
- Sharpening
- Noise reduction

Control it with the `preprocessing` parameter:

```python
result = service.execute(
    operation="extract_text",
    image_path="poor_quality.jpg",
    preprocessing=True  # Enable preprocessing
)
```

## Error Handling

```python
result = service.execute(
    operation="extract_receipt_data",
    image_path="receipt.jpg"
)

if not result["success"]:
    print(f"Error: {result['message']}")
    if "warnings" in result:
        for warning in result["warnings"]:
            print(f"Warning: {warning}")
else:
    # Process successful result
    receipt = result["receipt_data"]
```

## Testing

Run the test suite:

```bash
python test_service.py
```

All 16 tests should pass:
```
Tests run: 16
Successes: 16
Failures: 0
Errors: 0
```

## Examples

See `examples.py` for complete working examples:

```bash
python examples.py
```

## Integration with Expense Workflow

```python
from ocr.service import OCRService
from document_analysis.service import DocumentAnalysisService

# Step 1: Extract receipt data with OCR
ocr = OCRService(engine="tesseract")
ocr_result = ocr.execute(
    operation="extract_receipt_data",
    image_path=uploaded_receipt
)

# Step 2: Analyze for compliance
analyzer = DocumentAnalysisService()
analysis = analyzer.execute(
    operation="analyze_receipt",
    receipt_data=ocr_result["receipt_data"],
    expense_data=employee_claim
)

# Step 3: Make decision
if analysis["compliance_status"] == "compliant":
    approve_expense()
else:
    flag_for_review(analysis["violations"])
```

## Performance Tips

1. **Use appropriate engine:**
   - Tesseract: Simple receipts, offline
   - Google Vision: Poor quality, handwriting
   - AWS Textract: Complex forms, tables

2. **Enable preprocessing:**
   - Always enable for poor quality images
   - Disable for high-quality scans to save time

3. **Batch processing:**
   - Process multiple receipts together
   - Reduces overhead

4. **Image quality:**
   - Use 300 DPI or higher
   - Ensure good lighting
   - Avoid blur and skew

## Troubleshooting

**"Tesseract not found"**
```bash
# Install Tesseract first
sudo apt-get install tesseract-ocr
```

**Low confidence scores**
- Enable preprocessing
- Check image quality
- Increase image resolution
- Try different OCR engine

**Missing fields in receipt**
- Ensure receipt is properly aligned
- Check if text is readable
- Try with Google Vision for better accuracy

**Batch processing fails**
- Check all image paths are valid
- Ensure images are in supported format
- Look at individual error messages

## Supported Image Formats

- JPG/JPEG
- PNG
- BMP
- TIFF
- GIF

## License

Internal use only - EchoAI Production

## Support

For issues or questions, contact the development team.
