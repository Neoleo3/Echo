"""
OCR Tool Package

Optical Character Recognition tool for extracting text and data from 
receipt images and documents for expense report processing.
"""

from .service import OCRService

__version__ = "1.0"
__author__ = "EchoAI"

__all__ = ["OCRService"]
