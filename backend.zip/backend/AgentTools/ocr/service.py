"""
Superseded OCR module -- kept only so old references still resolve.

WHAT: Re-exports the real OCR service from :mod:`AgentTools.ocr_markitdown`.
WHY:  What used to live here was a simulator. ``_simulate_ocr`` returned one of
      a handful of hardcoded sample receipts -- a merchant, a date, line items,
      a total -- and every operation in the module was built on it:
      ``extract_text`` reported a character count and a confidence score for
      text that was never read, ``extract_receipt_data`` parsed the invented
      text into structured fields, and ``batch_process`` did it per file. The
      module was registered as ``tool_ocr`` and attachable to any agent, so an
      agent asked to read a receipt received fabricated data and had no way to
      tell. That is the failure the readiness gate and the connector descriptors
      exist to prevent, sitting inside a tool.

      The replacement was already in the tree: ``AgentTools/ocr_markitdown``,
      which converts through ``apps/markitdown`` -- real extraction, the
      platform credential cascade for the vision model, PDFium OCR for scanned
      pages and embedded images, and an explicit reason recorded when images
      could not be read.

``tool_ocr.json`` now points at that module directly. This shim exists because
a tool definition stored in the database before that change may still name this
one; resolving to real OCR is the only safe answer. It will be removed once no
stored definition references it.
"""
from __future__ import annotations

import warnings

from AgentTools.ocr_markitdown.service import (  # noqa: F401
    DocumentConversionError,
    DocumentSecurityError,
    MarkItDownService,
    OCRService,
    get_service,
)

warnings.warn(
    "AgentTools.ocr is superseded by AgentTools.ocr_markitdown, which performs "
    "real extraction. This module previously returned simulated OCR results.",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    "DocumentConversionError",
    "DocumentSecurityError",
    "MarkItDownService",
    "OCRService",
    "get_service",
]
