"""
AgentTools Configuration - Centralized, NO HARDCODING

This module provides all configuration for AgentTools components.
All values are configurable via environment variables or direct overrides.
"""

import os
from typing import Dict, Any, List
from dataclasses import dataclass, field


# =============================================================================
# PATHS & DIRECTORIES
# =============================================================================

@dataclass
class PathConfig:
    """File output paths for generated files."""
    output_base: str = field(default_factory=lambda: os.getenv(
        "AGENTTOOLS_OUTPUT_DIR",
        "/tmp/agenttools_output"
    ))
    
    @property
    def excel_dir(self) -> str:
        path = os.path.join(self.output_base, "excel")
        os.makedirs(path, exist_ok=True)
        return path
    
    @property
    def ppt_dir(self) -> str:
        path = os.path.join(self.output_base, "ppt")
        os.makedirs(path, exist_ok=True)
        return path
    
    @property
    def doc_dir(self) -> str:
        path = os.path.join(self.output_base, "documents")
        os.makedirs(path, exist_ok=True)
        return path

    @property
    def charts_dir(self) -> str:
        """Directory for data_analyst chart PNG exports (config-driven, no cwd hardcoding)."""
        path = os.path.join(self.output_base, "generated", "charts")
        os.makedirs(path, exist_ok=True)
        return path
    
    @property
    def node_scripts_dir(self) -> str:
        """Directory for Node.js helper scripts."""
        return os.getenv(
            "AGENTTOOLS_NODE_SCRIPTS_DIR",
            os.path.join(os.path.dirname(__file__), "node_scripts")
        )


# =============================================================================
# THEME & STYLING
# =============================================================================

@dataclass
class ColorPalette:
    """RGB Colors - configurable via env vars."""
    # Primary brand colors
    primary_dark: str = field(default_factory=lambda: os.getenv(
        "THEME_PRIMARY_DARK", "1F4E79"
    ))
    primary_light: str = field(default_factory=lambda: os.getenv(
        "THEME_PRIMARY_LIGHT", "2E75B6"
    ))
    accent: str = field(default_factory=lambda: os.getenv(
        "THEME_ACCENT", "70AD47"
    ))
    
    # Neutrals
    white: str = field(default_factory=lambda: os.getenv(
        "THEME_WHITE", "FFFFFF"
    ))
    near_black: str = field(default_factory=lambda: os.getenv(
        "THEME_NEAR_BLACK", "202020"
    ))
    light_grey: str = field(default_factory=lambda: os.getenv(
        "THEME_LIGHT_GREY", "DEEBF7"
    ))
    medium_grey: str = field(default_factory=lambda: os.getenv(
        "THEME_MEDIUM_GREY", "D9E1F2"
    ))
    
    # For warnings/errors
    warning: str = field(default_factory=lambda: os.getenv(
        "THEME_WARNING", "FFC000"
    ))
    error: str = field(default_factory=lambda: os.getenv(
        "THEME_ERROR", "FF0000"
    ))
    success: str = field(default_factory=lambda: os.getenv(
        "THEME_SUCCESS", "00B050"
    ))


@dataclass
class FontConfig:
    """Font sizes in points - configurable."""
    # PPT/Document fonts (in points)
    title_main: int = field(default_factory=lambda: int(os.getenv(
        "FONT_TITLE_MAIN", "36"
    )))
    title_subtitle: int = field(default_factory=lambda: int(os.getenv(
        "FONT_TITLE_SUBTITLE", "20"
    )))
    slide_title: int = field(default_factory=lambda: int(os.getenv(
        "FONT_SLIDE_TITLE", "28"
    )))
    heading: int = field(default_factory=lambda: int(os.getenv(
        "FONT_HEADING", "16"
    )))
    body: int = field(default_factory=lambda: int(os.getenv(
        "FONT_BODY", "14"
    )))
    bullet: int = field(default_factory=lambda: int(os.getenv(
        "FONT_BULLET", "14"
    )))
    table_header: int = field(default_factory=lambda: int(os.getenv(
        "FONT_TABLE_HEADER", "12"
    )))
    table_body: int = field(default_factory=lambda: int(os.getenv(
        "FONT_TABLE_BODY", "11"
    )))
    
    # Default fonts
    font_family_main: str = field(default_factory=lambda: os.getenv(
        "FONT_FAMILY_MAIN", "Calibri"
    ))
    font_family_code: str = field(default_factory=lambda: os.getenv(
        "FONT_FAMILY_CODE", "Courier New"
    ))


@dataclass
class ThemeConfig:
    """Complete theme configuration."""
    colors: ColorPalette = field(default_factory=ColorPalette)
    fonts: FontConfig = field(default_factory=FontConfig)
    
    # PPT specific
    ppt_author: str = field(default_factory=lambda: os.getenv(
        "PPT_AUTHOR", "EchoAI"
    ))
    ppt_company: str = field(default_factory=lambda: os.getenv(
        "PPT_COMPANY", "KPMG"
    ))
    
    # Excel specific
    excel_default_sheet: str = field(default_factory=lambda: os.getenv(
        "EXCEL_DEFAULT_SHEET", "Sheet1"
    ))
    excel_enable_autofilter: bool = field(default_factory=lambda: os.getenv(
        "EXCEL_ENABLE_AUTOFILTER", "true"
    ).lower() == "true")


# =============================================================================
# FILE READER CONFIGURATION
# =============================================================================

@dataclass
class FileReaderConfig:
    """File reader constraints and behavior."""
    # Size limits (in bytes)
    max_file_size: int = field(default_factory=lambda: int(os.getenv(
        "FILE_READER_MAX_SIZE_MB", "50"
    )) * 1024 * 1024)
    
    # Chunk configuration for vectorization
    default_chunk_size: int = field(default_factory=lambda: int(os.getenv(
        "FILE_READER_CHUNK_SIZE", "1000"
    )))
    default_chunk_overlap: int = field(default_factory=lambda: int(os.getenv(
        "FILE_READER_CHUNK_OVERLAP", "200"
    )))
    
    # CSV agent settings
    csv_enable_code_execution: bool = field(default_factory=lambda: os.getenv(
        "CSV_ENABLE_CODE_EXECUTION", "false"
    ).lower() == "true")
    
    # Supported MIME types
    supported_mime_types: Dict[str, str] = field(default_factory=lambda: {
        "application/pdf": "pdf",
        "application/json": "json",
        "text/json": "json",
        "application/xml": "xml",
        "text/xml": "xml",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
        "text/csv": "csv",
        "application/vnd.ms-excel": "xls",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    })


# =============================================================================
# PPT GENERATOR CONFIGURATION (pptxgenjs)
# =============================================================================

@dataclass
class PPTGeneratorConfig:
    """PPT generation settings using pptxgenjs via Node.js."""
    # Node.js execution
    node_executable: str = field(default_factory=lambda: os.getenv(
        "NODE_EXECUTABLE", "node"
    ))
    
    # PPT dimensions (in inches for widescreen 16:9)
    slide_width: float = field(default_factory=lambda: float(os.getenv(
        "PPT_SLIDE_WIDTH", "13.333"
    )))
    slide_height: float = field(default_factory=lambda: float(os.getenv(
        "PPT_SLIDE_HEIGHT", "7.5"
    )))
    
    # Margins
    margin_left: float = field(default_factory=lambda: float(os.getenv(
        "PPT_MARGIN_LEFT", "0.8"
    )))
    margin_top: float = field(default_factory=lambda: float(os.getenv(
        "PPT_MARGIN_TOP", "1.6"
    )))
    margin_right: float = field(default_factory=lambda: float(os.getenv(
        "PPT_MARGIN_RIGHT", "0.8"
    )))
    margin_bottom: float = field(default_factory=lambda: float(os.getenv(
        "PPT_MARGIN_BOTTOM", "0.8"
    )))
    
    # Features
    enable_animations: bool = field(default_factory=lambda: os.getenv(
        "PPT_ENABLE_ANIMATIONS", "true"
    ).lower() == "true")
    
    # Subprocess timeout (seconds)
    subprocess_timeout: int = field(default_factory=lambda: int(os.getenv(
        "PPT_SUBPROCESS_TIMEOUT", "30"
    )))


# =============================================================================
# EXCEL GENERATOR CONFIGURATION
# =============================================================================

@dataclass
class ExcelGeneratorConfig:
    """Excel generation settings with formulas and charts."""
    freeze_header_rows: int = field(default_factory=lambda: int(os.getenv(
        "EXCEL_FREEZE_HEADER_ROWS", "1"
    )))
    enable_autofilter: bool = field(default_factory=lambda: os.getenv(
        "EXCEL_ENABLE_AUTOFILTER", "true"
    ).lower() == "true")
    enable_autofit: bool = field(default_factory=lambda: os.getenv(
        "EXCEL_ENABLE_AUTOFIT", "true"
    ).lower() == "true")
    min_column_width: int = field(default_factory=lambda: int(os.getenv(
        "EXCEL_MIN_COL_WIDTH", "10"
    )))
    max_column_width: int = field(default_factory=lambda: int(os.getenv(
        "EXCEL_MAX_COL_WIDTH", "50"
    )))
    enable_charts: bool = field(default_factory=lambda: os.getenv(
        "EXCEL_ENABLE_CHARTS", "true"
    ).lower() == "true")


# =============================================================================
# PDF GENERATOR CONFIGURATION
# =============================================================================

@dataclass
class PDFGeneratorConfig:
    """PDF generation settings (fpdf2-backed)."""
    page_margin_mm: int = field(default_factory=lambda: int(os.getenv(
        "PDF_PAGE_MARGIN_MM", "10"
    )))
    auto_page_break_margin_mm: int = field(default_factory=lambda: int(os.getenv(
        "PDF_AUTO_PAGE_BREAK_MARGIN_MM", "20"
    )))


# =============================================================================
# DOXYGEN / DOCX PIPELINE CONFIGURATION
# =============================================================================

@dataclass
class DoxygenGeneratorConfig:
    """
    DOCX generation via Doxygen (RTF) + Pandoc, with Python sources filtered by doxypypy.

    External binaries must be on PATH or paths set explicitly — never embed tenant URLs or IDs.
    """

    doxygen_executable: str = field(default_factory=lambda: os.getenv(
        "DOXYGEN_EXECUTABLE", "doxygen"
    ).strip() or "doxygen")
    pandoc_executable: str = field(default_factory=lambda: os.getenv(
        "PANDOC_EXECUTABLE", "pandoc"
    ).strip() or "pandoc")
    # Console script from `pip install doxypypy`; override if not on PATH
    doxypypy_executable: str = field(default_factory=lambda: os.getenv(
        "DOXPYPY_EXECUTABLE", ""
    ).strip())
    python_executable: str = field(default_factory=lambda: os.getenv(
        "DOXYGEN_PYTHON_EXECUTABLE", ""
    ).strip())
    subprocess_timeout: int = field(default_factory=lambda: int(os.getenv(
        "DOXYGEN_SUBPROCESS_TIMEOUT", "120"
    )))
    doc_author: str = field(default_factory=lambda: os.getenv("DOXYGEN_DOC_AUTHOR", "").strip())
    doc_company: str = field(default_factory=lambda: os.getenv("DOXYGEN_DOC_COMPANY", "").strip())
    generate_toc: bool = field(default_factory=lambda: os.getenv(
        "DOXYGEN_GENERATE_TOC", "true"
    ).lower() == "true")


# =============================================================================
# DATA ANALYST (PANDAS AGENT)
# =============================================================================

@dataclass
class DataAnalystConfig:
    """Bounds and defaults for the native data_analyst tool."""

    max_rows_per_file: int = field(default_factory=lambda: int(os.getenv(
        "DATA_ANALYST_MAX_ROWS", "200000"
    )))
    agent_verbose: bool = field(default_factory=lambda: os.getenv(
        "DATA_ANALYST_AGENT_VERBOSE", "false"
    ).lower() == "true")


# =============================================================================
# DOCUMENT ANALYSIS CONFIGURATION
# =============================================================================

@dataclass
class DocumentAnalysisConfig:
    """Expense/receipt analysis settings."""
    # Duplicate detection
    duplicate_detection_method: str = field(default_factory=lambda: os.getenv(
        "DOC_ANALYSIS_DUPLICATE_METHOD", "fuzzy"
    ))
    fuzzy_match_threshold: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_FUZZY_THRESHOLD", "0.85"
    )))
    
    # Default policy
    default_max_meal: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_MAX_MEAL", "75.0"
    )))
    default_max_single_expense: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_MAX_SINGLE", "1000.0"
    )))
    default_max_daily: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_MAX_DAILY", "250.0"
    )))
    ocr_llm_provider: str = field(default_factory=lambda: os.getenv(
        "DOC_ANALYSIS_OCR_LLM_PROVIDER", ""
    ).strip())
    ocr_llm_model: str = field(default_factory=lambda: os.getenv(
        "DOC_ANALYSIS_OCR_LLM_MODEL", ""
    ).strip())
    ocr_llm_max_tokens: int = field(default_factory=lambda: int(os.getenv(
        "DOC_ANALYSIS_OCR_LLM_MAX_TOKENS", "1500"
    )))
    ocr_temperature: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_OCR_TEMPERATURE", "0"
    )))
    ocr_system_prompt: str = field(default_factory=lambda: os.getenv(
        "DOC_ANALYSIS_OCR_SYSTEM_PROMPT",
        "You are a receipt OCR extraction assistant. Extract only what is visible in the image. Return strict JSON and never include markdown fences.",
    ).strip())
    ocr_json_instruction: str = field(default_factory=lambda: os.getenv(
        "DOC_ANALYSIS_OCR_JSON_INSTRUCTION",
        "Analyze the receipt image and return a strict JSON object with these keys: merchant_name, date, total_amount, subtotal, tax_amount, currency, raw_text, items. The items value must be an array of objects with keys description, amount, quantity. Use null for unknown scalar fields and [] for unknown items. Preserve raw visible text in raw_text. Do not add commentary.",
    ).strip())
    ocr_timeout_seconds: int = field(default_factory=lambda: int(os.getenv(
        "DOC_ANALYSIS_OCR_TIMEOUT", "30"
    )))
    ocr_max_file_size: int = field(default_factory=lambda: int(os.getenv(
        "DOC_ANALYSIS_OCR_MAX_SIZE_MB", "15"
    )) * 1024 * 1024)
    ocr_confidence_warning_threshold: float = field(default_factory=lambda: float(os.getenv(
        "DOC_ANALYSIS_OCR_CONFIDENCE_WARN", "0.6"
    )))
    ocr_supported_image_mime_types: List[str] = field(default_factory=lambda: [
        item.strip().lower()
        for item in os.getenv(
            "DOC_ANALYSIS_OCR_IMAGE_MIME_TYPES",
            "image/png,image/jpeg,image/jpg,image/webp,image/bmp,image/tiff,image/gif",
        ).split(",")
        if item.strip()
    ])
    ocr_supported_image_extensions: List[str] = field(default_factory=lambda: [
        item.strip().lower()
        for item in os.getenv(
            "DOC_ANALYSIS_OCR_IMAGE_EXTENSIONS",
            ".png,.jpg,.jpeg,.webp,.bmp,.tiff,.tif,.gif",
        ).split(",")
        if item.strip()
    ])
    ocr_supported_document_mime_types: List[str] = field(default_factory=lambda: [
        item.strip().lower()
        for item in os.getenv(
            "DOC_ANALYSIS_OCR_DOCUMENT_MIME_TYPES",
            "application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ).split(",")
        if item.strip()
    ])
    ocr_supported_document_extensions: List[str] = field(default_factory=lambda: [
        item.strip().lower()
        for item in os.getenv(
            "DOC_ANALYSIS_OCR_DOCUMENT_EXTENSIONS",
            ".pdf,.docx",
        ).split(",")
        if item.strip()
    ])


# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

@dataclass
class LoggingConfig:
    """Logging settings."""
    log_level: str = field(default_factory=lambda: os.getenv(
        "AGENTTOOLS_LOG_LEVEL", "INFO"
    ))
    include_timestamps: bool = field(default_factory=lambda: os.getenv(
        "AGENTTOOLS_LOG_TIMESTAMPS", "true"
    ).lower() == "true")


# =============================================================================
# MASTER CONFIGURATION
# =============================================================================

@dataclass
class AgentToolsConfig:
    """Master configuration for all AgentTools."""
    paths: PathConfig = field(default_factory=PathConfig)
    theme: ThemeConfig = field(default_factory=ThemeConfig)
    file_reader: FileReaderConfig = field(default_factory=FileReaderConfig)
    ppt_generator: PPTGeneratorConfig = field(default_factory=PPTGeneratorConfig)
    doxygen_generator: DoxygenGeneratorConfig = field(default_factory=DoxygenGeneratorConfig)
    excel_generator: ExcelGeneratorConfig = field(default_factory=ExcelGeneratorConfig)
    pdf_generator: PDFGeneratorConfig = field(default_factory=PDFGeneratorConfig)
    data_analyst: DataAnalystConfig = field(default_factory=DataAnalystConfig)
    document_analysis: DocumentAnalysisConfig = field(default_factory=DocumentAnalysisConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)


# =============================================================================
# SINGLETON INSTANCE
# =============================================================================

_config_instance: AgentToolsConfig = None


def get_config() -> AgentToolsConfig:
    """Get global configuration instance."""
    global _config_instance
    if _config_instance is None:
        _config_instance = AgentToolsConfig()
    return _config_instance


def reload_config() -> AgentToolsConfig:
    """Reload configuration (useful for testing)."""
    global _config_instance
    _config_instance = AgentToolsConfig()
    return _config_instance
