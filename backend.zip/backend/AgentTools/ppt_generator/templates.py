"""
PPT Generator — Professional theme constants and layout helpers.

WHY: Centralises all colour, font, and spacing constants so service.py
stays readable and theme changes only require edits in one place.
"""

from pptx.util import Pt, Inches
from pptx.dml.color import RGBColor

# ---------------------------------------------------------------------------
# Colour palette  (KPMG brand)
# ---------------------------------------------------------------------------
COLOUR_TITLE_BG = RGBColor(0x00, 0x33, 0x8D)   # KPMG blue — title slide bg
COLOUR_SLIDE_BG = RGBColor(0xFF, 0xFF, 0xFF)   # White
COLOUR_HEADING = RGBColor(0x00, 0x33, 0x8D)   # KPMG blue headings
COLOUR_BODY = RGBColor(0x20, 0x20, 0x20)       # Near-black body text
COLOUR_ACCENT = RGBColor(0x00, 0x5E, 0xB8)    # KPMG medium blue accents
COLOUR_WHITE = RGBColor(0xFF, 0xFF, 0xFF)      # Pure white
COLOUR_TABLE_HEADER_BG = RGBColor(0x00, 0x33, 0x8D)  # KPMG blue
COLOUR_TABLE_ALT_ROW = RGBColor(0xDE, 0xE6, 0xF2)  # Light KPMG-blue tint

# ---------------------------------------------------------------------------
# Font sizes
# ---------------------------------------------------------------------------
FONT_TITLE_MAIN = Pt(36)
FONT_TITLE_SUBTITLE = Pt(20)
FONT_SLIDE_TITLE = Pt(28)
FONT_BODY = Pt(16)
FONT_BULLET = Pt(16)
FONT_TABLE_HEADER = Pt(12)
FONT_TABLE_BODY = Pt(11)

# ---------------------------------------------------------------------------
# Layout dimensions (16:9 widescreen)
# ---------------------------------------------------------------------------
SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)

# Content area margins
MARGIN_LEFT = Inches(0.8)
MARGIN_TOP_CONTENT = Inches(1.6)
CONTENT_WIDTH = Inches(11.733)
CONTENT_HEIGHT = Inches(5.2)
