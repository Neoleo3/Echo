"""
PPT Generator AgentTool package.

Creates professional PowerPoint presentations (.pptx) from structured
content provided by the agent LLM. Uses python-pptx (MIT license).
"""
