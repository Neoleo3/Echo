#!/usr/bin/env node
/**
 * PptxGenJS Bridge — called by the Python PPT generator service.
 *
 * Usage:
 *   node pptxgenjs_bridge.js <json_payload_file> <output_pptx_path>
 *
 * The JSON payload matches the Python PPTGeneratorService.generate() schema:
 * {
 *   "title":    "My Presentation",
 *   "subtitle": "Optional subtitle",
 *   "theme": {                          // optional, all fields optional
 *     "primary":   "1F4E79",            // hex, no #
 *     "accent":    "2E75B6",
 *     "text":      "202020",
 *     "white":     "FFFFFF",
 *     "alt_row":   "DEE9F7"
 *   },
 *   "slides": [
 *     {
 *       "title":        "Slide title",
 *       "content":      "Paragraph text",
 *       "bullet_points": ["Point 1", "Point 2"],
 *       "layout":       "content" | "table" | "two_column",
 *       "table_data": {
 *         "headers": ["Col A", "Col B"],
 *         "rows":    [["a1", "b1"], ["a2", "b2"]]
 *       },
 *       "image_path": "/abs/path/to/image.png",
 *       "notes": "Speaker notes text"
 *     }
 *   ]
 * }
 *
 * Install once in the backend directory:
 *   npm install pptxgenjs
 */

"use strict";

const fs   = require("fs");
const path = require("path");

// ── Arg validation ──────────────────────────────────────────────────────────
if (process.argv.length < 4) {
  console.error("Usage: node pptxgenjs_bridge.js <payload.json> <output.pptx>");
  process.exit(1);
}

const payloadPath = process.argv[2];
const outputPath  = process.argv[3];

let payload;
try {
  payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));
} catch (e) {
  console.error("Failed to read payload:", e.message);
  process.exit(1);
}

// ── Load PptxGenJS ─────────────────────────────────────────────────────────
let PptxGenJS;
try {
  PptxGenJS = require("pptxgenjs");
} catch (e) {
  console.error("pptxgenjs not installed. Run: npm install pptxgenjs");
  process.exit(1);
}

// ── Theme ──────────────────────────────────────────────────────────────────
const t = payload.theme || {};
const THEME = {
  primary : t.primary  || "1F4E79",
  accent  : t.accent   || "2E75B6",
  text    : t.text     || "202020",
  white   : t.white    || "FFFFFF",
  alt_row : t.alt_row  || "DEE9F7",
};

// ── Slide dimensions (16:9 widescreen) ────────────────────────────────────
const W = 13.333;  // inches
const H = 7.5;

// ── Presentation object ───────────────────────────────────────────────────
const pres = new PptxGenJS();
pres.layout = "LAYOUT_WIDE";
pres.author  = payload.author  || "EchoAI";
pres.company = payload.company || "";
pres.subject = payload.title   || "";
pres.title   = payload.title   || "";

// ── Slide master ──────────────────────────────────────────────────────────
pres.defineSlideMaster({
  title : "MASTER",
  background : { color: "FFFFFF" },
  objects : [
    // Top accent bar
    { rect: { x: 0, y: 0, w: W, h: 0.08, fill: { color: THEME.accent } } },
  ],
});

// ── Helper: title slide ───────────────────────────────────────────────────
function addTitleSlide(title, subtitle) {
  const slide = pres.addSlide();
  // Full-bleed background
  slide.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: W, h: H,
    fill: { color: THEME.primary },
  });
  // Title
  slide.addText(title || "", {
    x: 0.8, y: 2.4, w: W - 1.6, h: 1.8,
    fontSize: 36, bold: true, color: THEME.white,
    wrap: true, valign: "middle",
  });
  // Subtitle
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.8, y: 4.4, w: W - 1.6, h: 0.9,
      fontSize: 20, color: THEME.white, wrap: true,
    });
  }
}

// ── Helper: content slide ─────────────────────────────────────────────────
function addContentSlide(s) {
  const slide = pres.addSlide({ masterName: "MASTER" });

  // Slide title
  slide.addText(s.title || "", {
    x: 0.8, y: 0.15, w: W - 1.0, h: 1.1,
    fontSize: 26, bold: true, color: THEME.primary,
    wrap: true,
  });

  const bullets = s.bullet_points || [];
  const content = s.content || "";

  // Body
  if (bullets.length > 0) {
    const items = bullets.map(b => ({
      text: String(b),
      options: { bullet: { type: "bullet" }, fontSize: 16, color: THEME.text, paraSpaceAfter: 6 },
    }));
    slide.addText(items, {
      x: 0.8, y: 1.5, w: W - 1.6, h: H - 2.0,
      wrap: true, valign: "top",
    });
  } else if (content) {
    slide.addText(content, {
      x: 0.8, y: 1.5, w: W - 1.6, h: H - 2.0,
      fontSize: 16, color: THEME.text, wrap: true, valign: "top",
    });
  }

  // Speaker notes
  if (s.notes) {
    slide.addNotes(s.notes);
  }

  // Optional image
  if (s.image_path && fs.existsSync(s.image_path)) {
    slide.addImage({
      path: s.image_path,
      x: W - 4.5, y: 1.6, w: 3.5, h: 3.5,
    });
  }
}

// ── Helper: two-column slide ──────────────────────────────────────────────
function addTwoColumnSlide(s) {
  const slide = pres.addSlide({ masterName: "MASTER" });
  slide.addText(s.title || "", {
    x: 0.8, y: 0.15, w: W - 1.0, h: 1.1,
    fontSize: 26, bold: true, color: THEME.primary, wrap: true,
  });

  const colW = (W - 1.8) / 2;
  const cols = s.columns || [s.content || "", ""];

  for (let i = 0; i < 2; i++) {
    const x = 0.8 + i * (colW + 0.2);
    slide.addText(String(cols[i] || ""), {
      x, y: 1.5, w: colW, h: H - 2.0,
      fontSize: 15, color: THEME.text, wrap: true, valign: "top",
    });
  }
  if (s.notes) slide.addNotes(s.notes);
}

// ── Helper: table slide ───────────────────────────────────────────────────
function addTableSlide(s) {
  const td      = s.table_data || {};
  const headers = (td.headers || []).map(String);
  const rows    = (td.rows    || []).map(r => r.map(String));

  if (!headers.length) return addContentSlide(s);

  const slide = pres.addSlide({ masterName: "MASTER" });
  slide.addText(s.title || "", {
    x: 0.8, y: 0.15, w: W - 1.0, h: 1.1,
    fontSize: 26, bold: true, color: THEME.primary, wrap: true,
  });

  // Build pptxgenjs table rows
  const headerRow = headers.map(h => ({
    text: h,
    options: {
      bold: true, color: THEME.white,
      fill: { color: THEME.primary },
      fontSize: 12, align: "center",
    },
  }));

  const dataRows = rows.map((row, ri) =>
    row.map(cell => ({
      text: cell,
      options: {
        fontSize: 11, color: THEME.text,
        fill: { color: ri % 2 === 1 ? THEME.alt_row : "FFFFFF" },
      },
    }))
  );

  const tableData = [headerRow, ...dataRows];
  const colW = (W - 1.6) / Math.max(1, headers.length);

  slide.addTable(tableData, {
    x: 0.8, y: 1.5,
    w: W - 1.6,
    colW: Array(headers.length).fill(colW),
    border: { type: "solid", pt: 0.5, color: "CCCCCC" },
    autoPage: true,
    autoPageRepeatHeader: true,
  });

  if (s.notes) slide.addNotes(s.notes);
}

// ── Build the presentation ────────────────────────────────────────────────
addTitleSlide(payload.title, payload.subtitle);

for (const s of (payload.slides || [])) {
  const layout = (s.layout || "content").toLowerCase();
  if (layout === "table" && s.table_data) {
    addTableSlide(s);
  } else if (layout === "two_column") {
    addTwoColumnSlide(s);
  } else {
    addContentSlide(s);
  }
}

// ── Write file ────────────────────────────────────────────────────────────
pres.writeFile({ fileName: outputPath })
  .then(() => {
    console.log("OK:" + outputPath);
    process.exit(0);
  })
  .catch(err => {
    console.error("ERROR:" + err.message);
    process.exit(1);
  });
