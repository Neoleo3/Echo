"""
PowerPoint Presentation Generator Tool.

WHY: Users frequently request "make a PPT from the uploaded PDF" or
"create slides summarising this analysis". Without this tool the agent
can only reply with text. With it, the agent produces an actual .pptx
file that the user can download and use directly in PowerPoint/Keynote.

Uses python-pptx (MIT license) — no AGPL risk.

DESCRIPTION-GATED: The tool description explicitly states it should ONLY
be called when the user explicitly requests a presentation/PPT/slides.
The agent will NOT call it for general queries.
"""

import logging
import os
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool definition (used by the auto-bind registry)
# ---------------------------------------------------------------------------

TOOL_DEFINITION = {
    "tool_id": "ppt_generator",
    "name": "PowerPoint Presentation Generator",
    "description": (
        "ONLY use this tool when the user EXPLICITLY asks to create a PowerPoint, "
        "presentation, slides, or deck. Do NOT use this tool for any other purpose. "
        "Do NOT call this tool unless the user's message specifically requests "
        "a presentation or PPT file. Creates professional .pptx files with titles, "
        "bullet points, tables, and formatted content. Returns a downloadable file path."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Presentation title",
            },
            "subtitle": {
                "type": "string",
                "description": "Optional subtitle for the title slide",
            },
            "slides": {
                "type": "array",
                "description": "List of slides to create",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "Slide heading",
                        },
                        "content": {
                            "type": "string",
                            "description": "Paragraph text for the slide",
                        },
                        "bullet_points": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Bullet point items",
                        },
                        "table_data": {
                            "type": "object",
                            "description": "Table with headers and rows",
                            "properties": {
                                "headers": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "rows": {
                                    "type": "array",
                                    "items": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                            },
                        },
                        "layout": {
                            "type": "string",
                            "enum": ["title", "content", "two_column", "table"],
                            "description": "Slide layout type",
                        },
                    },
                    "required": ["title"],
                },
            },
        },
        "required": ["title", "slides"],
    },
    "capabilities": ["ppt_generation", "presentation_creation", "slide_creation"],
}


class PPTGeneratorService:
    """
    Creates professional PowerPoint presentations from structured content.

    WHY: Wraps python-pptx to abstract away low-level slide manipulation.
    Provides a clean API that the agent LLM can call via the tool schema.
    """

    def __init__(self, output_dir: str) -> None:
        """
        Initialize with the directory where .pptx files will be saved.

        Args:
            output_dir: Absolute path for saving generated .pptx files.
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate(
        self,
        title: str,
        slides: List[Dict[str, Any]],
        subtitle: str = "",
        author: str = "EchoAI",
    ) -> Dict[str, str]:
        """
        Generate a .pptx file from structured slide data.

        WHY: Accepts the clean dict structure that the LLM produces from the
        tool schema and converts it into a fully formatted presentation.

        Args:
            title: Presentation title (used on the title slide).
            slides: List of slide dicts, each with:
                - title (str): Slide title
                - content (str, optional): Paragraph text
                - bullet_points (list[str], optional): Bullet items
                - table_data (dict, optional): {"headers": [...], "rows": [[...]]}
                - layout (str, optional): "title"|"content"|"two_column"|"table"
            subtitle: Optional subtitle for the title slide.
            author: Author name for metadata.

        Returns:
            Dict with "file_path" (str), "filename" (str), "file_id" (str).
        """
        from pptx import Presentation
        from pptx.util import Inches

        from .templates import SLIDE_WIDTH, SLIDE_HEIGHT

        prs = Presentation()
        prs.slide_width = SLIDE_WIDTH
        prs.slide_height = SLIDE_HEIGHT

        # Title slide
        self._add_title_slide(prs, title, subtitle)

        # Content slides
        for slide_data in slides:
            layout = slide_data.get("layout", "content")
            if layout == "table" and slide_data.get("table_data"):
                self._add_table_slide(prs, slide_data)
            else:
                self._add_content_slide(prs, slide_data)

        # Save to disk
        file_id = str(uuid.uuid4())
        safe_title = "".join(c for c in title if c.isalnum() or c in " -_")[:50].strip()
        filename = f"{safe_title or 'Presentation'}.pptx"
        file_path = os.path.join(self.output_dir, f"{file_id}_{filename}")
        prs.save(file_path)

        logger.info("PPT generated: %s (%d slides)", filename, len(slides) + 1)
        return {
            "file_path": file_path,
            "filename": filename,
            "file_id": file_id,
        }

    def _add_title_slide(
        self, prs: Any, title: str, subtitle: str
    ) -> None:
        """
        Add the title slide using the presentation's title layout.

        Args:
            prs: python-pptx Presentation object.
            title: Main title text.
            subtitle: Subtitle text (may be empty).
        """
        from pptx.util import Pt
        from .templates import (
            COLOUR_TITLE_BG, COLOUR_WHITE,
            FONT_TITLE_MAIN, FONT_TITLE_SUBTITLE,
        )

        # Use blank layout and manually place text boxes for full control
        blank_layout = prs.slide_layouts[6]  # Blank layout
        slide = prs.slides.add_slide(blank_layout)

        # Background fill
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = COLOUR_TITLE_BG

        # Title text box
        from pptx.util import Inches
        txBox = slide.shapes.add_textbox(
            Inches(0.8), Inches(2.5), Inches(11.733), Inches(1.8)
        )
        tf = txBox.text_frame
        tf.word_wrap = True
        para = tf.paragraphs[0]
        para.text = title
        run = para.runs[0]
        run.font.size = FONT_TITLE_MAIN
        run.font.bold = True
        run.font.color.rgb = COLOUR_WHITE

        # Subtitle text box (if provided)
        if subtitle:
            txBox2 = slide.shapes.add_textbox(
                Inches(0.8), Inches(4.4), Inches(11.733), Inches(0.8)
            )
            tf2 = txBox2.text_frame
            para2 = tf2.paragraphs[0]
            para2.text = subtitle
            run2 = para2.runs[0]
            run2.font.size = FONT_TITLE_SUBTITLE
            run2.font.color.rgb = COLOUR_WHITE

    def _add_content_slide(self, prs: Any, slide_data: Dict[str, Any]) -> None:
        """
        Add a content slide with title + body (text or bullet points).

        Args:
            prs: python-pptx Presentation object.
            slide_data: Dict with "title", optional "content", optional "bullet_points".
        """
        from pptx.util import Inches, Pt
        from pptx.enum.text import PP_ALIGN
        from .templates import (
            COLOUR_HEADING, COLOUR_BODY, COLOUR_ACCENT,
            FONT_SLIDE_TITLE, FONT_BODY, FONT_BULLET,
            MARGIN_LEFT, MARGIN_TOP_CONTENT, CONTENT_WIDTH, CONTENT_HEIGHT,
        )

        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)

        # Title bar accent strip
        accent_bar = slide.shapes.add_shape(
            1,  # MSO_SHAPE_TYPE.RECTANGLE
            Inches(0), Inches(0), prs.slide_width, Inches(0.08),
        )
        accent_bar.fill.solid()
        accent_bar.fill.fore_color.rgb = COLOUR_ACCENT
        accent_bar.line.fill.background()

        # Slide title
        title_box = slide.shapes.add_textbox(
            MARGIN_LEFT, Inches(0.2), CONTENT_WIDTH, Inches(1.2)
        )
        tf = title_box.text_frame
        tf.word_wrap = True
        para = tf.paragraphs[0]
        para.text = slide_data.get("title", "")
        run = para.runs[0]
        run.font.size = FONT_SLIDE_TITLE
        run.font.bold = True
        run.font.color.rgb = COLOUR_HEADING

        # Body content
        body_box = slide.shapes.add_textbox(
            MARGIN_LEFT, MARGIN_TOP_CONTENT, CONTENT_WIDTH, CONTENT_HEIGHT
        )
        tf_body = body_box.text_frame
        tf_body.word_wrap = True

        bullet_points = slide_data.get("bullet_points") or []
        content_text = slide_data.get("content", "")

        if bullet_points:
            for i, point in enumerate(bullet_points):
                if i == 0:
                    para = tf_body.paragraphs[0]
                else:
                    para = tf_body.add_paragraph()
                para.text = f"• {point}"
                run = para.runs[0]
                run.font.size = FONT_BULLET
                run.font.color.rgb = COLOUR_BODY
        elif content_text:
            para = tf_body.paragraphs[0]
            para.text = content_text
            run = para.runs[0]
            run.font.size = FONT_BODY
            run.font.color.rgb = COLOUR_BODY

    def _add_table_slide(self, prs: Any, slide_data: Dict[str, Any]) -> None:
        """
        Add a slide containing a formatted table.

        Args:
            prs: python-pptx Presentation object.
            slide_data: Dict with "title" and "table_data" (headers + rows).
        """
        from pptx.util import Inches, Pt
        from .templates import (
            COLOUR_HEADING, COLOUR_WHITE, COLOUR_BODY,
            COLOUR_TABLE_HEADER_BG, COLOUR_TABLE_ALT_ROW,
            FONT_SLIDE_TITLE, FONT_TABLE_HEADER, FONT_TABLE_BODY,
            MARGIN_LEFT, CONTENT_WIDTH,
        )

        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)

        # Slide title
        title_box = slide.shapes.add_textbox(
            MARGIN_LEFT, Inches(0.2), CONTENT_WIDTH, Inches(1.2)
        )
        tf = title_box.text_frame
        para = tf.paragraphs[0]
        para.text = slide_data.get("title", "")
        run = para.runs[0]
        run.font.size = FONT_SLIDE_TITLE
        run.font.bold = True
        run.font.color.rgb = COLOUR_HEADING

        table_data = slide_data.get("table_data", {})
        headers = table_data.get("headers", [])
        rows = table_data.get("rows", [])

        if not headers:
            return

        num_cols = len(headers)
        num_rows = len(rows) + 1  # +1 for header row
        col_width = CONTENT_WIDTH / num_cols

        table = slide.shapes.add_table(
            num_rows, num_cols,
            MARGIN_LEFT, Inches(1.6),
            CONTENT_WIDTH, Inches(5.0),
        ).table

        # Header row
        for col_idx, header in enumerate(headers):
            cell = table.cell(0, col_idx)
            cell.text = str(header)
            cell.fill.solid()
            cell.fill.fore_color.rgb = COLOUR_TABLE_HEADER_BG
            para = cell.text_frame.paragraphs[0]
            run = para.runs[0] if para.runs else para.add_run()
            run.font.size = FONT_TABLE_HEADER
            run.font.bold = True
            run.font.color.rgb = COLOUR_WHITE

        # Data rows
        for row_idx, row in enumerate(rows, start=1):
            # Alternate row background
            is_alt = row_idx % 2 == 0
            for col_idx in range(num_cols):
                cell = table.cell(row_idx, col_idx)
                value = str(row[col_idx]) if col_idx < len(row) else ""
                cell.text = value
                if is_alt:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = COLOUR_TABLE_ALT_ROW
                para = cell.text_frame.paragraphs[0]
                run = para.runs[0] if para.runs else para.add_run()
                run.font.size = FONT_TABLE_BODY
                run.font.color.rgb = COLOUR_BODY
