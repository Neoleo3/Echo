"""
PowerPoint Presentation Generator Tool.

WHY: Users frequently request "make a PPT from the uploaded PDF" or
"create slides summarising this analysis". Without this tool the agent
can only reply with text. With it, the agent produces an actual .pptx
file that the user can download and use directly in PowerPoint/Keynote.

Uses python-pptx (MIT license) — no AGPL risk.

DESCRIPTION-GATED: The tool description explicitly states it should ONLY
be called when the user explicitly requests a presentation/PPT/slides.
The agent will NOT call it for general queries.
"""

import logging
import os
import uuid
import re

from typing import Any, Dict, List, Optional
from echolib.blob_storage import (
    upload_to_blob,
    get_blob_url,
)

logger = logging.getLogger(__name__)


# Shared single source of truth for the KPMG logo (echolib/branding.py).
from echolib.branding import resolve_kpmg_logo as _resolve_kpmg_logo


# ---------------------------------------------------------------------------
# Tool definition (used by the auto-bind registry)
# ---------------------------------------------------------------------------

TOOL_DEFINITION = {
    "tool_id": "ppt_generator",
    "name": "PowerPoint Presentation Generator",
    "description": (
        "ONLY use this tool when the user EXPLICITLY asks to create a PowerPoint, "
        "presentation, slides, or deck. Do NOT use this tool for any other purpose. "
        "Do NOT call this tool unless the user's message specifically requests "
        "a presentation or PPT file. Creates professional .pptx files with titles, "
        "bullet points, tables, and formatted content. Returns a downloadable file path."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Presentation title",
            },
            "subtitle": {
                "type": "string",
                "description": "Optional subtitle for the title slide",
            },
            "slides": {
                "type": "array",
                "description": "List of slides to create",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "Slide heading",
                        },
                        "content": {
                            "type": "string",
                            "description": "Paragraph text for the slide",
                        },
                        "bullet_points": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Bullet point items",
                        },
                        "table_data": {
                            "type": "object",
                            "description": "Table with headers and rows",
                            "properties": {
                                "headers": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "rows": {
                                    "type": "array",
                                    "items": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                            },
                        },
                        "layout": {
                            "type": "string",
                            "enum": ["title", "content", "two_column", "table"],
                            "description": "Slide layout type",
                        },
                    },
                    "required": ["title"],
                },
            },
        },
        "required": ["title", "slides"],
    },
    "capabilities": ["ppt_generation", "presentation_creation", "slide_creation"],
}


class PPTGeneratorService:
    """
    Creates professional PowerPoint presentations from structured content.

    WHY: Wraps python-pptx to abstract away low-level slide manipulation.
    Provides a clean API that the agent LLM can call via the tool schema.
    """

    def __init__(self, output_dir: str = None) -> None:
        """
        Initialize with the directory where .pptx files will be saved.

        Args:
            output_dir: Directory for generated .pptx files. Defaults to
                ``uploads/generated/ppt`` so the tool can be instantiated with
                no args by the workflow ToolExecutor (which calls ``cls()``).
        """
        uploads_root = os.getenv("APP_UPLOADS_DIR")
        default_output_dir = (
            os.path.join(uploads_root, "generated", "ppt")
            if uploads_root
            else os.path.join("uploads", "generated", "ppt")
        )
        self.output_dir = os.path.abspath(output_dir or default_output_dir)
        os.makedirs(self.output_dir, exist_ok=True)
        self._logo_path = _resolve_kpmg_logo()

    def _add_logo(self, prs: Any, slide: Any, *, on_dark: bool = False) -> None:
        """Place the KPMG logo in the top-right corner of a slide. Never raises.

        ``on_dark`` is accepted for callers on the dark title slide; the logo PNG
        has a transparent background so it sits on either surface.
        """
        if not self._logo_path:
            return
        try:
            from pptx.util import Inches
            width = Inches(1.4)
            left = prs.slide_width - width - Inches(0.4)
            slide.shapes.add_picture(
                self._logo_path, left, Inches(0.25), width=width
            )
        except Exception:
            logger.exception("KPMG logo could not be added to slide")

    def _extract_slide_content(
    self,
    slide_data: Dict[str, Any]
    ):
        """
        Normalize LLM slide payloads into:
        - content_text (str)
        - bullet_points (list)
        """

        content_text = ""
        bullet_points = []

        # Standard content string
        content = slide_data.get("content")

        if isinstance(content, str):
            content_text = content

        # Content provided as list
        elif isinstance(content, list):
            bullet_points.extend(
                str(item)
                for item in content
                if item
            )

        # Content provided as dictionary
        elif isinstance(content, dict):

            for key, value in content.items():

                if isinstance(value, list):

                    bullet_points.append(str(key))

                    bullet_points.extend(
                        f"  • {item}"
                        for item in value
                    )

                else:

                    bullet_points.append(
                        f"{key}: {value}"
                    )


        # Standard bullet field
        bullets = slide_data.get("bullet_points")

        if isinstance(bullets, list):
            bullet_points.extend(
                str(item)
                for item in bullets
                if item
            )

        # Alternative field names frequently generated by LLMs
        for field in [
            "body",
            "summary",
            "overview",
            "description",
            "details",
            "key_points",
            "takeaways",
            "points",
            "highlights",
            "findings",
            "recommendations"
        ]:
            value = slide_data.get(field)

            if isinstance(value, str):
                if content_text:
                    content_text += "\n\n"

                content_text += value

            elif isinstance(value, list):
                bullet_points.extend(
                    str(item)
                    for item in value
                    if item
                )

        # Markdown bullet detection
        if content_text:

            md_bullets = re.findall(
                r'^\s*[-*]\s+(.*)$',
                content_text,
                flags=re.MULTILINE
            )

            if md_bullets:
                bullet_points.extend(md_bullets)
                content_text = ""

        # Long paragraph -> bullet conversion
        if (
            content_text
            and not bullet_points
            and len(content_text) > 350
        ):
            sentences = re.split(
                r'(?<=[.!?])\s+',
                content_text
            )

            bullet_points.extend(
                [
                    item.strip()
                    for item in sentences
                    if item.strip()
                ]
            )

            content_text = ""

        return (
            content_text.strip(),
            bullet_points
        )

    def generate(
    self,
    title: str,
    slides: List[Dict[str, Any]],
    subtitle: str = "",
    author: str = "EchoAI",
    **kwargs: Any,
) -> Dict[str, str]:
        """
        Generate a .pptx file from structured slide data.

        WHY: Accepts the clean dict structure that the LLM produces from the
        tool schema and converts it into a fully formatted presentation.

        Args:
            title: Presentation title (used on the title slide).
            slides: List of slide dicts, each with:
                - title (str): Slide title
                - content (str, optional): Paragraph text
                - bullet_points (list[str], optional): Bullet items
                - table_data (dict, optional): {"headers": [...], "rows": [[...]]}
                - layout (str, optional): "title"|"content"|"two_column"|"table"
            subtitle: Optional subtitle for the title slide.
            author: Author name for metadata.

        Returns:
            Dict with "file_path" (str), "filename" (str), "file_id" (str).
        """

        logger.info("========== PPT GENERATOR TOOL INVOKED ==========")
        
        from pptx import Presentation
        from pptx.util import Inches

        from .templates import SLIDE_WIDTH, SLIDE_HEIGHT

        prs = Presentation()
        prs.slide_width = SLIDE_WIDTH
        prs.slide_height = SLIDE_HEIGHT

        # Title slide
        self._add_title_slide(prs, title, subtitle)

        # Content slides
        # for slide_data in slides:
        #     layout = slide_data.get("layout", "content")
        #     if layout == "table" and slide_data.get("table_data"):
        #         self._add_table_slide(prs, slide_data)
        #     else:
        #         self._add_content_slide(prs, slide_data)

        for idx, slide_data in enumerate(slides, start=1):

            logger.info(
                "RAW_SLIDE_%s=%s",
                idx,
                slide_data
            )

            if not isinstance(slide_data, dict):
                logger.warning(
                    "Invalid slide payload received: %s",
                    slide_data
                )
                continue

            layout = slide_data.get("layout", "content")

            if layout == "table" and slide_data.get("table_data"):
                self._add_table_slide(prs, slide_data)
            else:
                self._add_content_slide(prs, slide_data)

        # Save to disk
        file_id = str(uuid.uuid4())
        safe_title = str(title or "Presentation").strip()

        safe_title = re.sub(
            r"\s*\.?\s*pptx$",
            "",
            safe_title,
            flags=re.IGNORECASE,
        ).strip()

        safe_title = re.sub(r"[^A-Za-z0-9_-]", "_", safe_title)
        safe_title = re.sub(r"_+", "_", safe_title).strip("_")

        filename = f"{safe_title or 'Presentation'}.pptx"

        file_path = os.path.join(
                self.output_dir,
                f"{file_id}_{filename}"
        )

        prs.save(file_path)

        # logger.info("PPT generated: %s (%d slides)", filename, len(slides) + 1)

        abs_path = os.path.abspath(file_path)

        session_id = (
            kwargs.get("session_id")
            or kwargs.get("chat_session_id")
            or str(uuid.uuid4())
        )

        blob_name = (
            f"generated/doc/"
            f"{session_id}/"
            f"{file_id}/"
            f"{filename}"
        )

        uploaded = upload_to_blob(
            local_path=abs_path,
            blob_name=blob_name,
        )

        if not uploaded:
            logger.error("Blob upload failed: %s",
                         blob_name,)
            raise RuntimeError(
                f"Failed to upload PPT to Azure Blob Storage: {blob_name}"
            )

        download_url = get_blob_url(blob_name)
        logger.info(
                    "DOWNLOAD_URL=%s",
                    download_url,
                )
        try:
            os.remove(abs_path)
        except Exception:
            logger.warning(
                "Failed to remove local PPT: %s",
                abs_path,
            )

        logger.info(f"Template populated: {filename} → {abs_path}")
        marker = f"[GENERATED_FILE:{download_url}|{filename}]"
        logger.info(
            "MARKER_PAYLOAD=%s",
            marker
            )
        # # Emit the [GENERATED_FILE:<abs_path>:<filename>] marker in `result` so
        # # EVERY caller — the LangGraph/workflow tool path included — produces a
        # # downloadable link (the workflow registration helper scans for this
        # # marker). file_path/filename/file_id are kept for the CrewAI wrapper.
        # abs_path = os.path.abspath(file_path)
        # marker = f"[GENERATED_FILE:{abs_path}:{filename}]"
        # return {
        #     "result": (
        #         f"PowerPoint presentation '{title}' generated successfully.\n\n"
        #         f"{marker}\n\n"
        #         f"Include the [GENERATED_FILE:...] line above EXACTLY ONCE in your "
        #         f"final answer, verbatim — it becomes the download link."
        #     ),
        #     "file_path": abs_path,
        #     "filename": filename,
        #     "file_id": file_id,
        # }

        # return {
        #     "result": (
        #         f"PowerPoint presentation '{title}' generated successfully.\n\n"
        #         f"Download URL: {download_url}"
        #     ),
        #     "file_path": abs_path,
        #     "filename": filename,
        #     "file_id": file_id,
        #     "blob_name": blob_name,
        #     "download_url": download_url,
        #     "session_id": session_id,
        # }

        return {
            "file_path": download_url,
            "filename": filename,
            "file_id": file_id,
            "download_url": download_url,
            "session_id": session_id,
            "result": (
                f"File generated successfully.\n\n"
                f"Download URL:\n{download_url}"
            ),
        }

    def _add_title_slide(
        self, prs: Any, title: str, subtitle: str
    ) -> None:
        """
        Add the title slide using the presentation's title layout.

        Args:
            prs: python-pptx Presentation object.
            title: Main title text.
            subtitle: Subtitle text (may be empty).
        """
        from pptx.util import Pt
        from .templates import (
            COLOUR_TITLE_BG, COLOUR_WHITE,
            FONT_TITLE_MAIN, FONT_TITLE_SUBTITLE,
        )

        # Use blank layout and manually place text boxes for full control
        blank_layout = prs.slide_layouts[6]  # Blank layout
        slide = prs.slides.add_slide(blank_layout)

        # Background fill
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = COLOUR_TITLE_BG

        # KPMG logo (top-right)
        self._add_logo(prs, slide, on_dark=True)

        # Title text box
        from pptx.util import Inches
        txBox = slide.shapes.add_textbox(
            Inches(0.8), Inches(2.5), Inches(11.733), Inches(1.8)
        )
        tf = txBox.text_frame
        tf.word_wrap = True
        para = tf.paragraphs[0]
        para.text = title
        run = (
            para.runs[0]
            if para.runs
            else para.add_run()
        )
        run.font.size = FONT_TITLE_MAIN
        run.font.bold = True
        run.font.color.rgb = COLOUR_WHITE

        # Subtitle text box (if provided)
        if subtitle:
            txBox2 = slide.shapes.add_textbox(
                Inches(0.8), Inches(4.4), Inches(11.733), Inches(0.8)
            )
            tf2 = txBox2.text_frame
            para2 = tf2.paragraphs[0]
            para2.text = subtitle
            run2 = (
                para2.runs[0]
                if para2.runs
                else para2.add_run()
            )
            run2.font.size = FONT_TITLE_SUBTITLE
            run2.font.color.rgb = COLOUR_WHITE

    def _add_content_slide(self, prs: Any, slide_data: Dict[str, Any]) -> None:
        """
        Add a content slide with title + body (text or bullet points).

        Args:
            prs: python-pptx Presentation object.
            slide_data: Dict with "title", optional "content", optional "bullet_points".
        """
        from pptx.util import Inches, Pt
        from pptx.enum.text import PP_ALIGN
        from .templates import (
            COLOUR_HEADING, COLOUR_BODY, COLOUR_ACCENT,
            FONT_SLIDE_TITLE, FONT_BODY, FONT_BULLET,
            MARGIN_LEFT, MARGIN_TOP_CONTENT, CONTENT_WIDTH, CONTENT_HEIGHT,
        )

        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)

        # Title bar accent strip
        accent_bar = slide.shapes.add_shape(
            1,  # MSO_SHAPE_TYPE.RECTANGLE
            Inches(0), Inches(0), prs.slide_width, Inches(0.08),
        )
        accent_bar.fill.solid()
        accent_bar.fill.fore_color.rgb = COLOUR_ACCENT
        accent_bar.line.fill.background()

        # KPMG logo (top-right)
        self._add_logo(prs, slide)

        # Slide title
        title_box = slide.shapes.add_textbox(
            MARGIN_LEFT, Inches(0.2), CONTENT_WIDTH, Inches(1.2)
        )
        tf = title_box.text_frame
        tf.word_wrap = True
        para = tf.paragraphs[0]
        para.text = slide_data.get("title", "")
        run = (
            para.runs[0]
            if para.runs
            else para.add_run()
        )
        run.font.size = FONT_SLIDE_TITLE
        run.font.bold = True
        run.font.color.rgb = COLOUR_HEADING

        # Body content
        body_box = slide.shapes.add_textbox(
            MARGIN_LEFT, MARGIN_TOP_CONTENT, CONTENT_WIDTH, CONTENT_HEIGHT
        )
        tf_body = body_box.text_frame
        tf_body.word_wrap = True

        # bullet_points = slide_data.get("bullet_points") or []
        # content_text = slide_data.get("content", "")
        
        content_text, bullet_points = (
            self._extract_slide_content(
                slide_data
            )
        )

        if not content_text and not bullet_points:

            content_text = (
                "No slide content was supplied by the agent."
            )

        logger.info(
            "NORMALIZED_SLIDE_CONTENT=%s",
            {
                "title": slide_data.get("title"),
                "content": content_text,
                "bullets": bullet_points,
            }
        )

        # if bullet_points:
        #     for i, point in enumerate(bullet_points):
        #         if i == 0:
        #             para = tf_body.paragraphs[0]
        #         else:
        #             para = tf_body.add_paragraph()
        #         para.text = f"• {point}"
        #         run = para.runs[0]
        #         run.font.size = FONT_BULLET
        #         run.font.color.rgb = COLOUR_BODY
        # elif content_text:
        #     para = tf_body.paragraphs[0]
        #     para.text = content_text
        #     run = para.runs[0]
        #     run.font.size = FONT_BODY
        #     run.font.color.rgb = COLOUR_BODY


        if content_text:

            para = tf_body.paragraphs[0]

            para.text = content_text

            run = (
                para.runs[0]
                if para.runs
                else para.add_run()
            )

            run.font.size = FONT_BODY
            run.font.color.rgb = COLOUR_BODY

        # for point in bullet_points:

        #     para = tf_body.add_paragraph()

        #     para.text = str(point)

        for i, point in enumerate(bullet_points):

            if i == 0 and not content_text:
                para = tf_body.paragraphs[0]
            else:
                para = tf_body.add_paragraph()

            para.text = str(point)
            para.level = 0

            run = (
                para.runs[0]
                if para.runs
                else para.add_run()
            )

            run.font.size = FONT_BULLET
            run.font.color.rgb = COLOUR_BODY

    def _add_table_slide(self, prs: Any, slide_data: Dict[str, Any]) -> None:
        """
        Add a slide containing a formatted table.

        Args:
            prs: python-pptx Presentation object.
            slide_data: Dict with "title" and "table_data" (headers + rows).
        """
        from pptx.util import Inches, Pt
        from .templates import (
            COLOUR_HEADING, COLOUR_WHITE, COLOUR_BODY,
            COLOUR_TABLE_HEADER_BG, COLOUR_TABLE_ALT_ROW,
            FONT_SLIDE_TITLE, FONT_TABLE_HEADER, FONT_TABLE_BODY,
            MARGIN_LEFT, CONTENT_WIDTH,
        )

        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)

        # KPMG logo (top-right)
        self._add_logo(prs, slide)

        # Slide title
        title_box = slide.shapes.add_textbox(
            MARGIN_LEFT, Inches(0.2), CONTENT_WIDTH, Inches(1.2)
        )
        tf = title_box.text_frame
        para = tf.paragraphs[0]
        para.text = slide_data.get("title", "")
        # run = para.runs[0]
        run = (
            para.runs[0]
            if para.runs
            else para.add_run()
        )
        run.font.size = FONT_SLIDE_TITLE
        run.font.bold = True
        run.font.color.rgb = COLOUR_HEADING

        table_data = slide_data.get("table_data", {})
        headers = table_data.get("headers", [])
        rows = table_data.get("rows", [])

        if not headers:
            return

        num_cols = len(headers)
        num_rows = len(rows) + 1  # +1 for header row
        col_width = CONTENT_WIDTH / num_cols

        table = slide.shapes.add_table(
            num_rows, num_cols,
            MARGIN_LEFT, Inches(1.6),
            CONTENT_WIDTH, Inches(5.0),
        ).table

        # Header row
        for col_idx, header in enumerate(headers):
            cell = table.cell(0, col_idx)
            cell.text = str(header)
            cell.fill.solid()
            cell.fill.fore_color.rgb = COLOUR_TABLE_HEADER_BG
            para = cell.text_frame.paragraphs[0]
            run = (
                para.runs[0]
                if para.runs
                else para.add_run()
            )
            run.font.size = FONT_TABLE_HEADER
            run.font.bold = True
            run.font.color.rgb = COLOUR_WHITE

        # Data rows
        for row_idx, row in enumerate(rows, start=1):
            # Alternate row background
            is_alt = row_idx % 2 == 0
            for col_idx in range(num_cols):
                cell = table.cell(row_idx, col_idx)
                value = str(row[col_idx]) if col_idx < len(row) else ""
                cell.text = value
                if is_alt:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = COLOUR_TABLE_ALT_ROW
                para = cell.text_frame.paragraphs[0]
                run = (
                    para.runs[0]
                    if para.runs
                    else para.add_run()
                )
                run.font.size = FONT_TABLE_BODY
                run.font.color.rgb = COLOUR_BODY
