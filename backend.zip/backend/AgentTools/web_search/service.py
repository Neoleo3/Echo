"""
Web Search — multi-provider router.

Selects the active provider based on environment variables.
No API keys or endpoints are hard-coded.

Priority (first match wins):
  1. TAVILY_API_KEY       → TavilyProvider   (best for AI RAG pipelines)
  2. SERPAPI_API_KEY      → SerpAPIProvider
  3. GOOGLE_CSE_API_KEY + GOOGLE_CSE_ID → GoogleCSEProvider
  4. BING_SEARCH_API_KEY  → BingRESTProvider  (Bing Web Search v7 REST API)
  5. AZURE_AI_ENDPOINT + AZURE_BING_AGENT_ID → AzureAIBingProvider (legacy)

If no provider is configured, a clear error is returned.

Required env vars per provider
────────────────────────────────────────────────────────
Tavily     : TAVILY_API_KEY
SerpAPI    : SERPAPI_API_KEY
Google CSE : GOOGLE_CSE_API_KEY, GOOGLE_CSE_ID
Bing REST  : BING_SEARCH_API_KEY
Azure Bing : AZURE_AI_ENDPOINT, AZURE_BING_AGENT_ID
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result normalisation helper
# ---------------------------------------------------------------------------

def _normalise(results: List[Dict]) -> List[Dict]:
    """Ensure every result has title, url, snippet, and position."""
    out = []
    for i, r in enumerate(results, start=1):
        out.append({
            "title": str(r.get("title") or ""),
            "url": str(r.get("url") or r.get("link") or ""),
            "snippet": str(r.get("snippet") or r.get("content") or r.get("body") or ""),
            "position": r.get("position", i),
        })
    return out


# ---------------------------------------------------------------------------
# Tavily
# ---------------------------------------------------------------------------

class TavilyProvider:
    """
    Tavily Search API — designed for AI / RAG.
    Env: TAVILY_API_KEY
    """

    def __init__(self) -> None:
        self.api_key = os.environ["TAVILY_API_KEY"]

    def search(self, query: str, max_results: int = 10, **kwargs) -> Dict[str, Any]:
        import requests

        resp = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": self.api_key,
                "query": query,
                "max_results": max(1, min(max_results, 20)),
                "include_answer": False,
                "search_depth": kwargs.get("search_depth", "basic"),
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        raw = data.get("results") or []
        results = _normalise([
            {"title": r.get("title"), "url": r.get("url"), "snippet": r.get("content")}
            for r in raw
        ])
        return {"query": query, "provider": "tavily", "results": results,
                "total_results": len(results)}


# ---------------------------------------------------------------------------
# SerpAPI
# ---------------------------------------------------------------------------

class SerpAPIProvider:
    """
    SerpAPI — wraps Google, Bing, Yahoo, etc.
    Env: SERPAPI_API_KEY, SERPAPI_ENGINE (default: "google")
    """

    def __init__(self) -> None:
        self.api_key = os.environ["SERPAPI_API_KEY"]
        self.engine = os.environ.get("SERPAPI_ENGINE", "google")

    def search(self, query: str, max_results: int = 10,
               language: str = "en", **kwargs) -> Dict[str, Any]:
        import requests

        params = {
            "q": query,
            "api_key": self.api_key,
            "engine": self.engine,
            "num": max(1, min(max_results, 100)),
            "hl": language,
            "safe": "active" if kwargs.get("safe_search", True) else "off",
        }
        resp = requests.get("https://serpapi.com/search", params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        raw = data.get("organic_results") or []
        results = _normalise([
            {"title": r.get("title"), "url": r.get("link"), "snippet": r.get("snippet")}
            for r in raw[:max_results]
        ])
        return {"query": query, "provider": "serpapi", "results": results,
                "total_results": len(results)}


# ---------------------------------------------------------------------------
# Google Custom Search Engine
# ---------------------------------------------------------------------------

class GoogleCSEProvider:
    """
    Google Programmable Search Engine (Custom Search JSON API).
    Env: GOOGLE_CSE_API_KEY, GOOGLE_CSE_ID
    """

    BASE_URL = "https://www.googleapis.com/customsearch/v1"

    def __init__(self) -> None:
        self.api_key = os.environ["GOOGLE_CSE_API_KEY"]
        self.cx = os.environ["GOOGLE_CSE_ID"]

    def search(self, query: str, max_results: int = 10,
               language: str = "en", **kwargs) -> Dict[str, Any]:
        import requests

        # Google CSE returns max 10 per page; paginate if needed
        all_items: List[Dict] = []
        start = 1
        while len(all_items) < max_results:
            batch = min(10, max_results - len(all_items))
            params = {
                "key": self.api_key,
                "cx": self.cx,
                "q": query,
                "num": batch,
                "start": start,
                "hl": language,
                "safe": "active" if kwargs.get("safe_search", True) else "off",
            }
            resp = requests.get(self.BASE_URL, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            items = data.get("items") or []
            if not items:
                break
            all_items.extend(items)
            if len(items) < batch:
                break
            start += batch

        results = _normalise([
            {"title": r.get("title"), "url": r.get("link"),
             "snippet": r.get("snippet")}
            for r in all_items[:max_results]
        ])
        return {"query": query, "provider": "google_cse", "results": results,
                "total_results": len(results)}


# ---------------------------------------------------------------------------
# Bing Web Search v7 REST API
# ---------------------------------------------------------------------------

class BingRESTProvider:
    """
    Bing Web Search API v7 (Azure Cognitive Services).
    Env: BING_SEARCH_API_KEY
         BING_SEARCH_ENDPOINT  (default: https://api.bing.microsoft.com)
    """

    def __init__(self) -> None:
        self.api_key = os.environ["BING_SEARCH_API_KEY"]
        self.endpoint = os.environ.get(
            "BING_SEARCH_ENDPOINT", "https://api.bing.microsoft.com"
        ).rstrip("/")

    def search(self, query: str, max_results: int = 10,
               language: str = "en", safe_search: bool = True, **kwargs) -> Dict[str, Any]:
        import requests

        url = f"{self.endpoint}/v7.0/search"
        headers = {"Ocp-Apim-Subscription-Key": self.api_key}
        params = {
            "q": query,
            "count": max(1, min(max_results, 50)),
            "setLang": language,
            "safeSearch": "Strict" if safe_search else "Off",
            "responseFilter": "Webpages",
        }
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        raw = (data.get("webPages") or {}).get("value") or []
        results = _normalise([
            {"title": r.get("name"), "url": r.get("url"),
             "snippet": r.get("snippet")}
            for r in raw[:max_results]
        ])
        return {"query": query, "provider": "bing", "results": results,
                "total_results": len(results)}


# ---------------------------------------------------------------------------
# Azure AI Foundry Bing agent (legacy / optional)
# ---------------------------------------------------------------------------

class AzureAIBingProvider:
    """
    Azure AI Projects agent with Bing grounding (legacy path).
    Env: AZURE_AI_ENDPOINT, AZURE_BING_AGENT_ID
    """

    def __init__(self) -> None:
        self.endpoint = os.environ["AZURE_AI_ENDPOINT"]
        self.agent_id = os.environ["AZURE_BING_AGENT_ID"]
        self._client: Any = None
        self._init_client()

    def _init_client(self) -> None:
        try:
            from azure.ai.projects import AIProjectClient
            from azure.identity import DefaultAzureCredential

            self._client = AIProjectClient(
                credential=DefaultAzureCredential(),
                endpoint=self.endpoint,
            )
        except Exception as exc:
            logger.warning("Azure AI Bing client init failed: %s", exc)
            self._client = None

    def search(self, query: str, **kwargs) -> Dict[str, Any]:
        import re

        if self._client is None:
            raise RuntimeError("Azure AI client not initialised — check env vars and SDK install")

        try:
            from azure.ai.agents.models import ListSortOrder
        except ImportError as exc:
            raise ImportError("Install azure-ai-agents: pip install azure-ai-agents") from exc

        agents = self._client.agents
        agent = agents.get_agent(self.agent_id)
        thread = agents.threads.create()
        agents.messages.create(thread_id=thread.id, role="user", content=query)
        run = agents.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)

        if run.status == "failed":
            raise RuntimeError(f"Agent run failed: {run.last_error}")

        messages = list(agents.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING))
        text = messages[-1].text_messages[-1].text.value
        cleaned = re.sub(r"[\u3010].*?[\u3011]", "", text).strip()

        return {
            "query": query,
            "provider": "azure_bing",
            "results": [{"title": "Bing Result", "url": "", "snippet": cleaned, "position": 1}],
            "total_results": 1,
        }


# ---------------------------------------------------------------------------
# Provider factory — zero hardcoding
# ---------------------------------------------------------------------------

def _build_provider() -> Optional[object]:
    """
    Instantiate the first available provider based on env vars.
    Returns None if no provider is configured.
    """
    checks = [
        ("TAVILY_API_KEY", TavilyProvider),
        ("SERPAPI_API_KEY", SerpAPIProvider),
        ("GOOGLE_CSE_API_KEY", lambda: GoogleCSEProvider() if os.environ.get("GOOGLE_CSE_ID") else None),
        ("BING_SEARCH_API_KEY", BingRESTProvider),
        ("AZURE_AI_ENDPOINT", lambda: AzureAIBingProvider() if os.environ.get("AZURE_BING_AGENT_ID") else None),
    ]
    for env_key, factory in checks:
        if os.environ.get(env_key):
            try:
                provider = factory()
                if provider is not None:
                    logger.info("Web search provider: %s", type(provider).__name__)
                    return provider
            except Exception as exc:
                logger.warning("Provider %s failed to init: %s", factory, exc)
    return None


# ---------------------------------------------------------------------------
# WebSearchService — the entry point called by the tool executor
# ---------------------------------------------------------------------------

class WebSearchService:
    """
    Provider-agnostic web search tool.

    The provider is resolved once at construction time from environment
    variables. No keys or endpoints are hard-coded.
    """

    def __init__(self) -> None:
        self._provider = _build_provider()

    def search(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a web search.

        Args:
            input_data (dict):
                query       (str, required)
                max_results (int, default 10)
                language    (str, default "en")
                safe_search (bool, default True)

        Returns:
            dict with query, provider, results, total_results.
        """
        query: str = (input_data.get("query") or "").strip()
        if not query:
            raise ValueError("Missing required field: 'query'")

        if self._provider is None:
            return {
                "query": query,
                "provider": "none",
                "results": [
                    {
                        "title": "No search provider configured",
                        "url": "",
                        "snippet": (
                            "Set one of: TAVILY_API_KEY, SERPAPI_API_KEY, "
                            "GOOGLE_CSE_API_KEY+GOOGLE_CSE_ID, or BING_SEARCH_API_KEY"
                        ),
                        "position": 1,
                    }
                ],
                "total_results": 0,
                "error": "no_provider_configured",
            }

        max_results = int(input_data.get("max_results") or 10)
        language = str(input_data.get("language") or "en")
        safe_search = bool(input_data.get("safe_search", True))

        try:
            return self._provider.search(
                query=query,
                max_results=max_results,
                language=language,
                safe_search=safe_search,
            )
        except Exception as exc:
            logger.error("Web search failed (%s): %s", type(self._provider).__name__, exc)
            raise
