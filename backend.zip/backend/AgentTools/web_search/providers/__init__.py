"""
Web search providers package.
"""
