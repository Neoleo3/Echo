import os
import re
import logging

from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.agents.models import ListSortOrder

logger = logging.getLogger(__name__)


class BingSearchProvider:
    """Bing web search via Azure AI Foundry Agent.

    Uses a pre-configured Bing grounded agent on Azure AI Foundry.
    No-arg constructor reads config from environment variables so that
    ToolExecutor can instantiate via cls() with zero arguments.
    """

    def __init__(self):
        self.endpoint = os.environ.get("AZURE_AI_ENDPOINT", "https://kdnaaifndry.services.ai.azure.com/api/projects/kdnkbot-project")
        self.agent_id = os.environ.get("AZURE_BING_AGENT_ID", "asst_Hn7isUA8vLCTQQOSCDDHlv4m")
        self._client = AIProjectClient(
            credential=DefaultAzureCredential(),
            endpoint=self.endpoint,
        )

    def search(self, input_data: dict) -> dict:
        """Perform web search via Azure Bing agent.

        This is the method invoked by ToolExecutor. It is synchronous;
        ToolExecutor automatically offloads sync methods to a thread pool.

        Args:
            input_data: Dict with keys:
                - query (str): Search query string (required)

        Returns:
            Dict with query, provider, results list, and total_results count
        """
        query = input_data.get("query")
        if not query:
            raise ValueError("Missing required field: 'query'")

        agents = self._client.agents

        # Retrieve the pre-existing Bing agent
        agent = agents.get_agent(self.agent_id)

        # Create a fresh thread for this query
        thread = agents.threads.create()

        # Post the user query as a message
        agents.messages.create(
            thread_id=thread.id,
            role="user",
            content=query,
        )

        # Execute the agent and wait for completion
        run = agents.runs.create_and_process(
            thread_id=thread.id,
            agent_id=agent.id,
        )

        if run.status == "failed":
            raise RuntimeError(
                f"Azure Bing agent run failed: {run.last_error}"
            )

        # Collect the assistant's last text message
        messages = agents.messages.list(
            thread_id=thread.id,
            order=ListSortOrder.ASCENDING,
        )
        messages_list = list(messages)
        last_text = messages_list[-1].text_messages[-1].text.value

        # Strip Azure citation annotations
        cleaned = re.sub(r'[\u3010].*?[\u3011]', '', last_text).strip()

        return {
            "query": query,
            "provider": "bing",
            "results": [
                {
                    "title": "Bing Search Result",
                    "url": "",
                    "snippet": cleaned,
                    "position": 1,
                }
            ],
            "total_results": 1,
        }
