"""
Calendar API Service for Team Coverage and PTO Management

This service provides calendar operations for checking team availability,
validating leave requests, and ensuring adequate team coverage.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import json


class CalendarService:
    """
    Service class for calendar and team coverage operations.
    Integrates with PTO/leave request and approval workflow.
    """

    def __init__(self):
        """Initialize the Calendar Service with mock data storage."""
        # In production, this would connect to a real database or calendar API
        self.employees = {}
        self.teams = {}
        self.leave_requests = []
        self.team_schedules = {}
        self._initialize_mock_data()

    def _initialize_mock_data(self):
        """Initialize with sample data for testing."""
        # Sample teams
        self.teams = {
            "team_001": {
                "name": "Engineering Team A",
                "members": ["emp_001", "emp_002", "emp_003", "emp_004"],
                "minimum_coverage": 2
            },
            "team_002": {
                "name": "Engineering Team B",
                "members": ["emp_005", "emp_006", "emp_007"],
                "minimum_coverage": 1
            }
        }

        # Sample employees
        self.employees = {
            "emp_001": {"name": "Alice Johnson", "team_id": "team_001", "role": "Senior Engineer"},
            "emp_002": {"name": "Bob Smith", "team_id": "team_001", "role": "Engineer"},
            "emp_003": {"name": "Carol White", "team_id": "team_001", "role": "Engineer"},
            "emp_004": {"name": "David Brown", "team_id": "team_001", "role": "Junior Engineer"},
            "emp_005": {"name": "Eve Davis", "team_id": "team_002", "role": "Senior Engineer"},
            "emp_006": {"name": "Frank Miller", "team_id": "team_002", "role": "Engineer"},
            "emp_007": {"name": "Grace Wilson", "team_id": "team_002", "role": "Engineer"}
        }

        # Sample leave requests
        self.leave_requests = [
            {
                "employee_id": "emp_002",
                "start_date": "2026-02-10",
                "end_date": "2026-02-14",
                "leave_type": "vacation",
                "status": "approved"
            },
            {
                "employee_id": "emp_003",
                "start_date": "2026-02-12",
                "end_date": "2026-02-13",
                "leave_type": "sick",
                "status": "approved"
            }
        ]

    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Main execution method called by the agent framework.
        
        Args:
            **kwargs: Operation parameters from input_schema
            
        Returns:
            Dict containing operation results
        """
        operation = kwargs.get("operation")
        
        if not operation:
            return {
                "operation": "unknown",
                "success": False,
                "message": "No operation specified"
            }

        # Route to appropriate operation handler
        operation_handlers = {
            "check_availability": self.check_availability,
            "get_team_schedule": self.get_team_schedule,
            "check_coverage": self.check_coverage,
            "get_leave_conflicts": self.get_leave_conflicts,
            "validate_leave_request": self.validate_leave_request,
            "get_employee_pto": self.get_employee_pto,
            "get_team_members": self.get_team_members
        }

        handler = operation_handlers.get(operation)
        if not handler:
            return {
                "operation": operation,
                "success": False,
                "message": f"Unknown operation: {operation}"
            }

        try:
            result = handler(**kwargs)
            return result
        except Exception as e:
            return {
                "operation": operation,
                "success": False,
                "message": f"Error executing operation: {str(e)}"
            }

    def check_availability(self, **kwargs) -> Dict[str, Any]:
        """
        Check if an employee is available during a date range.
        
        Args:
            employee_id: Employee to check
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Dict with availability status
        """
        employee_id = kwargs.get("employee_id")
        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")

        if not all([employee_id, start_date, end_date]):
            return {
                "operation": "check_availability",
                "success": False,
                "message": "Missing required parameters: employee_id, start_date, end_date"
            }

        if employee_id not in self.employees:
            return {
                "operation": "check_availability",
                "success": False,
                "message": f"Employee {employee_id} not found"
            }

        # Check for conflicting leave requests
        conflicts = self._find_date_conflicts(employee_id, start_date, end_date)
        
        is_available = len(conflicts) == 0

        return {
            "operation": "check_availability",
            "success": True,
            "data": {
                "employee_id": employee_id,
                "employee_name": self.employees[employee_id]["name"],
                "start_date": start_date,
                "end_date": end_date,
                "is_available": is_available,
                "conflicts": conflicts
            },
            "message": f"Employee is {'available' if is_available else 'not available'} for the requested dates"
        }

    def get_team_schedule(self, **kwargs) -> Dict[str, Any]:
        """
        Get the schedule for all team members during a date range.
        
        Args:
            team_id: Team to query
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Dict with team schedule information
        """
        team_id = kwargs.get("team_id")
        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")

        if not all([team_id, start_date, end_date]):
            return {
                "operation": "get_team_schedule",
                "success": False,
                "message": "Missing required parameters: team_id, start_date, end_date"
            }

        if team_id not in self.teams:
            return {
                "operation": "get_team_schedule",
                "success": False,
                "message": f"Team {team_id} not found"
            }

        team = self.teams[team_id]
        schedule = []

        for employee_id in team["members"]:
            employee = self.employees[employee_id]
            leave_during_period = [
                lr for lr in self.leave_requests
                if lr["employee_id"] == employee_id and
                self._dates_overlap(lr["start_date"], lr["end_date"], start_date, end_date)
            ]

            schedule.append({
                "employee_id": employee_id,
                "employee_name": employee["name"],
                "role": employee["role"],
                "leave_requests": leave_during_period,
                "is_available": len(leave_during_period) == 0
            })

        return {
            "operation": "get_team_schedule",
            "success": True,
            "data": {
                "team_id": team_id,
                "team_name": team["name"],
                "start_date": start_date,
                "end_date": end_date,
                "schedule": schedule,
                "total_members": len(team["members"]),
                "available_members": sum(1 for s in schedule if s["is_available"])
            },
            "message": f"Retrieved schedule for {team['name']}"
        }

    def check_coverage(self, **kwargs) -> Dict[str, Any]:
        """
        Check if team has adequate coverage during a date range.
        
        Args:
            team_id: Team to check
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            minimum_coverage: Minimum required team members (optional)
            
        Returns:
            Dict with coverage status
        """
        team_id = kwargs.get("team_id")
        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")
        minimum_coverage = kwargs.get("minimum_coverage")

        if not all([team_id, start_date, end_date]):
            return {
                "operation": "check_coverage",
                "success": False,
                "message": "Missing required parameters: team_id, start_date, end_date"
            }

        if team_id not in self.teams:
            return {
                "operation": "check_coverage",
                "success": False,
                "message": f"Team {team_id} not found"
            }

        team = self.teams[team_id]
        if minimum_coverage is None:
            minimum_coverage = team.get("minimum_coverage", 1)

        # Get team schedule
        schedule_result = self.get_team_schedule(team_id=team_id, start_date=start_date, end_date=end_date)
        available_count = schedule_result["data"]["available_members"]

        # Determine coverage status
        if available_count >= minimum_coverage + 1:
            coverage_status = "adequate"
        elif available_count >= minimum_coverage:
            coverage_status = "adequate"
        elif available_count >= minimum_coverage - 1:
            coverage_status = "insufficient"
        else:
            coverage_status = "critical"

        return {
            "operation": "check_coverage",
            "success": True,
            "coverage_status": coverage_status,
            "data": {
                "team_id": team_id,
                "team_name": team["name"],
                "start_date": start_date,
                "end_date": end_date,
                "total_members": len(team["members"]),
                "available_members": available_count,
                "minimum_required": minimum_coverage,
                "coverage_met": available_count >= minimum_coverage
            },
            "message": f"Coverage is {coverage_status} ({available_count}/{minimum_coverage} minimum)"
        }

    def get_leave_conflicts(self, **kwargs) -> Dict[str, Any]:
        """
        Find conflicting leave requests for a proposed leave period.
        
        Args:
            employee_id: Employee requesting leave
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Dict with conflict information
        """
        employee_id = kwargs.get("employee_id")
        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")

        if not all([employee_id, start_date, end_date]):
            return {
                "operation": "get_leave_conflicts",
                "success": False,
                "message": "Missing required parameters: employee_id, start_date, end_date"
            }

        if employee_id not in self.employees:
            return {
                "operation": "get_leave_conflicts",
                "success": False,
                "message": f"Employee {employee_id} not found"
            }

        employee = self.employees[employee_id]
        team_id = employee["team_id"]

        # Find conflicts for the employee
        employee_conflicts = self._find_date_conflicts(employee_id, start_date, end_date)

        # Find team member conflicts
        team = self.teams[team_id]
        team_conflicts = []
        
        for member_id in team["members"]:
            if member_id != employee_id:
                member_leave = self._find_date_conflicts(member_id, start_date, end_date)
                if member_leave:
                    team_conflicts.extend([
                        {**conflict, "employee_name": self.employees[member_id]["name"]}
                        for conflict in member_leave
                    ])

        return {
            "operation": "get_leave_conflicts",
            "success": True,
            "conflicts": employee_conflicts + team_conflicts,
            "data": {
                "employee_id": employee_id,
                "employee_name": employee["name"],
                "team_id": team_id,
                "start_date": start_date,
                "end_date": end_date,
                "employee_conflicts": employee_conflicts,
                "team_conflicts": team_conflicts,
                "total_conflicts": len(employee_conflicts) + len(team_conflicts)
            },
            "message": f"Found {len(employee_conflicts) + len(team_conflicts)} conflicts"
        }

    def validate_leave_request(self, **kwargs) -> Dict[str, Any]:
        """
        Validate a leave request against team coverage requirements.
        
        Args:
            employee_id: Employee requesting leave
            team_id: Team ID (optional, will be inferred from employee)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            leave_type: Type of leave
            minimum_coverage: Minimum required coverage (optional)
            
        Returns:
            Dict with validation result and recommendation
        """
        employee_id = kwargs.get("employee_id")
        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")
        leave_type = kwargs.get("leave_type", "vacation")

        if not all([employee_id, start_date, end_date]):
            return {
                "operation": "validate_leave_request",
                "success": False,
                "message": "Missing required parameters: employee_id, start_date, end_date"
            }

        if employee_id not in self.employees:
            return {
                "operation": "validate_leave_request",
                "success": False,
                "message": f"Employee {employee_id} not found"
            }

        employee = self.employees[employee_id]
        team_id = kwargs.get("team_id", employee["team_id"])

        # Check employee availability
        availability = self.check_availability(employee_id=employee_id, start_date=start_date, end_date=end_date)
        
        # Check team coverage (simulating the request being approved)
        coverage = self.check_coverage(
            team_id=team_id,
            start_date=start_date,
            end_date=end_date,
            minimum_coverage=kwargs.get("minimum_coverage")
        )

        # Get conflicts
        conflicts = self.get_leave_conflicts(employee_id=employee_id, start_date=start_date, end_date=end_date)

        # Determine if request should be approved
        can_approve = (
            availability["data"]["is_available"] and
            coverage["coverage_status"] != "critical"
        )

        # Generate recommendation
        if can_approve:
            if coverage["coverage_status"] == "adequate":
                recommendation = "APPROVE"
                reason = "Employee is available and team coverage is adequate"
            else:
                recommendation = "APPROVE_WITH_CAUTION"
                reason = "Employee is available but team coverage will be minimal"
        else:
            if not availability["data"]["is_available"]:
                recommendation = "DENY"
                reason = "Employee has conflicting leave already scheduled"
            else:
                recommendation = "DENY"
                reason = "Approving would result in critical team coverage shortage"

        return {
            "operation": "validate_leave_request",
            "success": True,
            "coverage_status": coverage["coverage_status"],
            "data": {
                "employee_id": employee_id,
                "employee_name": employee["name"],
                "team_id": team_id,
                "start_date": start_date,
                "end_date": end_date,
                "leave_type": leave_type,
                "can_approve": can_approve,
                "recommendation": recommendation,
                "reason": reason,
                "availability_check": availability["data"],
                "coverage_check": coverage["data"],
                "conflicts_found": conflicts["data"]["total_conflicts"]
            },
            "message": f"Recommendation: {recommendation} - {reason}"
        }

    def get_employee_pto(self, **kwargs) -> Dict[str, Any]:
        """
        Get PTO information for an employee.
        
        Args:
            employee_id: Employee to query
            
        Returns:
            Dict with PTO balance and history
        """
        employee_id = kwargs.get("employee_id")

        if not employee_id:
            return {
                "operation": "get_employee_pto",
                "success": False,
                "message": "Missing required parameter: employee_id"
            }

        if employee_id not in self.employees:
            return {
                "operation": "get_employee_pto",
                "success": False,
                "message": f"Employee {employee_id} not found"
            }

        employee = self.employees[employee_id]
        
        # Get all leave requests for this employee
        employee_leaves = [
            lr for lr in self.leave_requests
            if lr["employee_id"] == employee_id
        ]

        # Calculate days used (simplified)
        days_used = sum(
            self._calculate_business_days(lr["start_date"], lr["end_date"])
            for lr in employee_leaves
            if lr.get("status") == "approved"
        )

        # Mock PTO balance (in production, fetch from HR system)
        pto_balance = {
            "total_annual": 20,
            "used": days_used,
            "remaining": 20 - days_used,
            "pending": 0
        }

        return {
            "operation": "get_employee_pto",
            "success": True,
            "data": {
                "employee_id": employee_id,
                "employee_name": employee["name"],
                "pto_balance": pto_balance,
                "leave_history": employee_leaves
            },
            "message": f"PTO balance: {pto_balance['remaining']} days remaining"
        }

    def get_team_members(self, **kwargs) -> Dict[str, Any]:
        """
        Get list of team members.
        
        Args:
            team_id: Team to query
            
        Returns:
            Dict with team member information
        """
        team_id = kwargs.get("team_id")

        if not team_id:
            return {
                "operation": "get_team_members",
                "success": False,
                "message": "Missing required parameter: team_id"
            }

        if team_id not in self.teams:
            return {
                "operation": "get_team_members",
                "success": False,
                "message": f"Team {team_id} not found"
            }

        team = self.teams[team_id]
        members = [
            {
                "employee_id": emp_id,
                **self.employees[emp_id]
            }
            for emp_id in team["members"]
        ]

        return {
            "operation": "get_team_members",
            "success": True,
            "data": {
                "team_id": team_id,
                "team_name": team["name"],
                "members": members,
                "total_members": len(members)
            },
            "message": f"Retrieved {len(members)} team members"
        }

    # Helper methods

    def _find_date_conflicts(self, employee_id: str, start_date: str, end_date: str) -> List[Dict]:
        """Find leave requests that conflict with the given date range."""
        conflicts = []
        for leave_request in self.leave_requests:
            if leave_request["employee_id"] == employee_id:
                if self._dates_overlap(
                    leave_request["start_date"],
                    leave_request["end_date"],
                    start_date,
                    end_date
                ):
                    conflicts.append(leave_request)
        return conflicts

    def _dates_overlap(self, start1: str, end1: str, start2: str, end2: str) -> bool:
        """Check if two date ranges overlap."""
        start1_dt = datetime.strptime(start1, "%Y-%m-%d")
        end1_dt = datetime.strptime(end1, "%Y-%m-%d")
        start2_dt = datetime.strptime(start2, "%Y-%m-%d")
        end2_dt = datetime.strptime(end2, "%Y-%m-%d")
        
        return start1_dt <= end2_dt and end1_dt >= start2_dt

    def _calculate_business_days(self, start_date: str, end_date: str) -> int:
        """Calculate number of business days between two dates."""
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        
        days = 0
        current = start
        while current <= end:
            if current.weekday() < 5:  # Monday = 0, Sunday = 6
                days += 1
            current += timedelta(days=1)
        
        return days


# For testing
if __name__ == "__main__":
    service = CalendarService()
    
    # Test validate_leave_request
    result = service.execute(
        operation="validate_leave_request",
        employee_id="emp_001",
        start_date="2026-02-10",
        end_date="2026-02-14",
        leave_type="vacation"
    )
    
    print(json.dumps(result, indent=2))
