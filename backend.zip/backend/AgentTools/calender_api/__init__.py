"""
Calendar API Tool Package

A comprehensive calendar and team coverage management tool for PTO/leave 
request and approval workflows.
"""

from .service import CalendarService

__version__ = "1.0"
__author__ = "EchoAI"

__all__ = ["CalendarService"]
