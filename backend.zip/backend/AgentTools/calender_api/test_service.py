"""
Unit tests for Calendar API Service
"""

import unittest
import sys
from datetime import datetime, timedelta
from service import CalendarService


class TestCalendarService(unittest.TestCase):
    """Test cases for Calendar API operations"""

    def setUp(self):
        """Set up test fixtures"""
        self.service = CalendarService()

    def test_check_availability_available(self):
        """Test checking availability for an available employee"""
        result = self.service.execute(
            operation="check_availability",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-14"
        )

        self.assertTrue(result["success"])
        self.assertTrue(result["data"]["is_available"])
        self.assertEqual(len(result["data"]["conflicts"]), 0)

    def test_check_availability_unavailable(self):
        """Test checking availability for unavailable employee"""
        result = self.service.execute(
            operation="check_availability",
            employee_id="emp_002",
            start_date="2026-02-10",
            end_date="2026-02-14"
        )

        self.assertTrue(result["success"])
        self.assertFalse(result["data"]["is_available"])
        self.assertGreater(len(result["data"]["conflicts"]), 0)

    def test_check_availability_missing_params(self):
        """Test check_availability with missing parameters"""
        result = self.service.execute(
            operation="check_availability",
            employee_id="emp_001"
        )

        self.assertFalse(result["success"])
        self.assertIn("Missing required parameters", result["message"])

    def test_check_availability_invalid_employee(self):
        """Test check_availability with invalid employee ID"""
        result = self.service.execute(
            operation="check_availability",
            employee_id="emp_999",
            start_date="2026-03-10",
            end_date="2026-03-14"
        )

        self.assertFalse(result["success"])
        self.assertIn("not found", result["message"])

    def test_get_team_schedule(self):
        """Test getting team schedule"""
        result = self.service.execute(
            operation="get_team_schedule",
            team_id="team_001",
            start_date="2026-02-10",
            end_date="2026-02-14"
        )

        self.assertTrue(result["success"])
        self.assertEqual(result["data"]["team_id"], "team_001")
        self.assertIn("schedule", result["data"])
        self.assertGreater(len(result["data"]["schedule"]), 0)

    def test_check_coverage_adequate(self):
        """Test coverage check with adequate coverage"""
        result = self.service.execute(
            operation="check_coverage",
            team_id="team_001",
            start_date="2026-03-10",
            end_date="2026-03-14",
            minimum_coverage=2
        )

        self.assertTrue(result["success"])
        self.assertIn(result["coverage_status"], ["adequate", "insufficient", "critical"])

    def test_check_coverage_with_leave(self):
        """Test coverage check during period with existing leave"""
        result = self.service.execute(
            operation="check_coverage",
            team_id="team_001",
            start_date="2026-02-10",
            end_date="2026-02-14",
            minimum_coverage=2
        )

        self.assertTrue(result["success"])
        self.assertIn("coverage_status", result)

    def test_get_leave_conflicts(self):
        """Test finding leave conflicts"""
        result = self.service.execute(
            operation="get_leave_conflicts",
            employee_id="emp_001",
            start_date="2026-02-10",
            end_date="2026-02-14"
        )

        self.assertTrue(result["success"])
        self.assertIn("conflicts", result)
        self.assertIsInstance(result["conflicts"], list)

    def test_validate_leave_request_approve(self):
        """Test leave validation that should approve"""
        result = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-14",
            leave_type="vacation"
        )

        self.assertTrue(result["success"])
        self.assertIn("recommendation", result["data"])
        self.assertIn(result["data"]["recommendation"], ["APPROVE", "APPROVE_WITH_CAUTION", "DENY"])

    def test_validate_leave_request_deny_conflict(self):
        """Test leave validation that should deny due to conflict"""
        result = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_002",
            start_date="2026-02-10",
            end_date="2026-02-14",
            leave_type="vacation"
        )

        self.assertTrue(result["success"])
        self.assertEqual(result["data"]["recommendation"], "DENY")
        self.assertIn("conflicting", result["data"]["reason"].lower())

    def test_get_employee_pto(self):
        """Test getting employee PTO information"""
        result = self.service.execute(
            operation="get_employee_pto",
            employee_id="emp_002"
        )

        self.assertTrue(result["success"])
        self.assertIn("pto_balance", result["data"])
        self.assertIn("total_annual", result["data"]["pto_balance"])
        self.assertIn("remaining", result["data"]["pto_balance"])
        self.assertIn("leave_history", result["data"])

    def test_get_team_members(self):
        """Test getting team members"""
        result = self.service.execute(
            operation="get_team_members",
            team_id="team_001"
        )

        self.assertTrue(result["success"])
        self.assertIn("members", result["data"])
        self.assertEqual(result["data"]["team_id"], "team_001")
        self.assertGreater(len(result["data"]["members"]), 0)

    def test_invalid_operation(self):
        """Test with invalid operation name"""
        result = self.service.execute(
            operation="invalid_operation"
        )

        self.assertFalse(result["success"])
        self.assertIn("Unknown operation", result["message"])

    def test_no_operation(self):
        """Test with no operation specified"""
        result = self.service.execute()

        self.assertFalse(result["success"])
        self.assertIn("No operation specified", result["message"])

    def test_dates_overlap_helper(self):
        """Test the date overlap helper function"""
        # Overlapping dates
        self.assertTrue(
            self.service._dates_overlap("2026-02-10", "2026-02-14", "2026-02-12", "2026-02-16")
        )
        
        # Non-overlapping dates
        self.assertFalse(
            self.service._dates_overlap("2026-02-10", "2026-02-14", "2026-02-20", "2026-02-25")
        )
        
        # Adjacent dates
        self.assertFalse(
            self.service._dates_overlap("2026-02-10", "2026-02-14", "2026-02-15", "2026-02-20")
        )

    def test_calculate_business_days(self):
        """Test business days calculation"""
        # Week with no weekend (Mon-Fri)
        days = self.service._calculate_business_days("2026-02-02", "2026-02-06")
        self.assertEqual(days, 5)
        
        # Single day
        days = self.service._calculate_business_days("2026-02-02", "2026-02-02")
        self.assertEqual(days, 1)
        
        # Week including weekend
        days = self.service._calculate_business_days("2026-02-06", "2026-02-09")
        self.assertEqual(days, 2)  # Friday and Monday only

    def test_workflow_integration(self):
        """Test complete workflow: validate -> check coverage -> conflicts"""
        # Step 1: Validate leave request
        validation = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-14",
            leave_type="vacation"
        )
        
        self.assertTrue(validation["success"])
        
        # Step 2: Check coverage
        coverage = self.service.execute(
            operation="check_coverage",
            team_id=validation["data"]["team_id"],
            start_date="2026-03-10",
            end_date="2026-03-14"
        )
        
        self.assertTrue(coverage["success"])
        
        # Step 3: Check conflicts
        conflicts = self.service.execute(
            operation="get_leave_conflicts",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-14"
        )
        
        self.assertTrue(conflicts["success"])

    def test_multiple_team_members_on_leave(self):
        """Test coverage when multiple team members are on leave"""
        # Both emp_002 and emp_003 have leave during Feb 10-14
        result = self.service.execute(
            operation="check_coverage",
            team_id="team_001",
            start_date="2026-02-10",
            end_date="2026-02-14",
            minimum_coverage=2
        )

        self.assertTrue(result["success"])
        # Should show reduced coverage
        self.assertLess(
            result["data"]["available_members"],
            result["data"]["total_members"]
        )


class TestCalendarServiceEdgeCases(unittest.TestCase):
    """Test edge cases and error conditions"""

    def setUp(self):
        """Set up test fixtures"""
        self.service = CalendarService()

    def test_same_day_leave(self):
        """Test leave request for same day (start = end)"""
        result = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-10",
            leave_type="sick"
        )

        self.assertTrue(result["success"])

    def test_past_date_validation(self):
        """Test validation with past dates (should still process)"""
        result = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_001",
            start_date="2026-01-10",
            end_date="2026-01-14",
            leave_type="vacation"
        )

        self.assertTrue(result["success"])

    def test_long_leave_request(self):
        """Test validation for extended leave (multiple weeks)"""
        result = self.service.execute(
            operation="validate_leave_request",
            employee_id="emp_001",
            start_date="2026-03-10",
            end_date="2026-03-28",
            leave_type="parental"
        )

        self.assertTrue(result["success"])

    def test_all_team_members_available(self):
        """Test coverage when all team members are available"""
        result = self.service.execute(
            operation="check_coverage",
            team_id="team_001",
            start_date="2026-03-10",
            end_date="2026-03-14",
            minimum_coverage=1
        )

        self.assertTrue(result["success"])
        self.assertEqual(result["coverage_status"], "adequate")


def run_tests():
    """Run all tests and display results"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test cases
    suite.addTests(loader.loadTestsFromTestCase(TestCalendarService))
    suite.addTests(loader.loadTestsFromTestCase(TestCalendarServiceEdgeCases))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
