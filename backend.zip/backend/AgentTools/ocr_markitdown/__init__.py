"""MarkItDown-based OCR tool package for Echo."""

from .service import (
    DocumentConversionError,
    DocumentSecurityError,
    MarkItDownService,
    OCRService,
    get_service,
)

__version__ = "1.0"
__author__ = "EchoAI"

__all__ = [
    "OCRService",
    "MarkItDownService",
    "DocumentConversionError",
    "DocumentSecurityError",
    "get_service",
]
