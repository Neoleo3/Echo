"""
OCR service for the Echo tool runtime, built on the platform conversion layer.

WHAT: Turns an image, PDF or Office document into text for the ``tool_ocr`` /
      ``tool_ocr_markitdown`` tools and for ``DocumentAnalysisService``.
WHY:  Two implementations of "read a document" existed. ``apps/markitdown`` is
      the platform one -- credential cascade, vision-capability check, PDFium
      OCR fallback, offline converter session, extension and size guards -- and
      this module had its own, weaker copy. Rather than maintain the copy, this
      is now an adapter over the platform package, which is also what Plan_1 §1
      requires: "every MarkItDown-related module lives in apps/markitdown and
      nothing outside it imports markitdown".

What that changes, in the three places the old wiring was wrong:

* **Credentials.** The vision model was built from ``AZURE_OPENAI_API_KEY`` /
  ``AZURE_OPENAI_ENDPOINT`` read straight out of the environment. This
  deployment keeps those in Key Vault and leaves the variables unset, so the
  client came back ``None`` and image OCR was skipped with a log line no user
  ever saw. ``apps/markitdown.resolve_vision_binding`` resolves the caller's
  own credential, then the user's default LLM, then the platform default, and
  reports in ``ocr_skipped_reason`` when it could not.

* **Plugins.** ``enable_plugins`` was on, and the module warned when
  ``markitdown-ocr`` was absent. That plugin requires PyMuPDF (AGPL-3.0) and is
  deliberately not installed; the three capabilities it adds are reimplemented
  in ``apps/markitdown/ocr_fallback.py`` on PDFium. Plugins are off here, and
  embedded-image and scanned-page OCR now actually run.

* **Path resolution.** A path that did not exist was searched for by filename
  across every upload root (``rglob``), so one session could read another
  session's upload. Containment is now checked and nothing is searched.
"""

import base64
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger("echo_ai.tools.document_ocr")

# Kept for callers that read it; the ceiling itself is enforced by
# ``apps.markitdown.guards.check_size``.
MAX_FILE_SIZE_MB = int(os.getenv("DOC_OCR_MAX_FILE_SIZE_MB", "25"))

_BACKEND_ROOT = Path(__file__).resolve().parents[2]
_raw_allowed_dirs = os.getenv("DOC_OCR_ALLOWED_DIRS")
if _raw_allowed_dirs:
    ALLOWED_UPLOAD_DIRS = [Path(p.strip()).resolve() for p in _raw_allowed_dirs.split(",") if p.strip()]
else:
    _default_uploads = _BACKEND_ROOT / "uploads"
    ALLOWED_UPLOAD_DIRS = [_default_uploads.resolve()]

_app_uploads = os.getenv("APP_UPLOADS_DIR")
if _app_uploads:
    ALLOWED_UPLOAD_DIRS.append(Path(_app_uploads).resolve())
else:
    ALLOWED_UPLOAD_DIRS.append((_BACKEND_ROOT / "apps" / "appmgr" / "uploads").resolve())


class DocumentConversionError(Exception):
    """Raised when a document cannot be converted to text."""


class DocumentSecurityError(Exception):
    """Raised when an input fails a security or policy check."""


class MarkItDownService:
    """
    Adapter over ``apps.markitdown`` -- the platform's conversion layer.

    Keeps the ``convert_from_path`` / ``convert_from_bytes`` /
    ``convert_from_base64`` contract this package has always exposed, so
    ``OCRService`` below and ``DocumentAnalysisService`` are unchanged, while
    the work itself is done by the package that owns document conversion.
    """

    def __init__(self):
        self._last_result: Optional[Any] = None

    # ------------------------------------------------------------------
    # Conversion
    # ------------------------------------------------------------------

    def convert_from_bytes(
        self,
        file_bytes: bytes,
        filename: str,
        *,
        user_id: Optional[str] = None,
        credential_id: Optional[str] = None,
    ) -> str:
        """
        Convert an in-memory document to text.

        WHAT: Extension and size guards, then ``apps.markitdown.convert_bytes``.
        WHY:  Bytes are the only shape every caller can supply -- an upload, a
              base64 payload, or a file read off an allowed directory -- so the
              other two entry points funnel here and there is one code path to
              reason about.
        INPUT: Raw bytes and the filename they arrived under; optionally the
               caller's identity, used only to resolve the vision model.
        OUTPUT: Markdown text, stripped.
        RAISES: ``DocumentSecurityError`` for a refused extension or an
                oversized payload, ``DocumentConversionError`` otherwise, so the
                handlers in ``OCRService.execute`` still classify failures the
                same way.
        """
        from apps.markitdown import converter, guards
        from apps.markitdown.errors import (
            ConversionError,
            MarkItDownUnavailable,
            SourceTooLargeError,
            UnsupportedSourceError,
        )

        if not filename or not str(filename).strip():
            raise DocumentConversionError(
                "A filename with a supported extension is required"
            )

        if not isinstance(file_bytes, (bytes, bytearray)):
            raise DocumentConversionError(
                f"Expected bytes for '{filename}', got "
                f"{type(file_bytes).__name__}"
            )

        if not file_bytes:
            raise DocumentConversionError(
                f"File content for '{filename}' is empty"
            )

        # Normalize bytearray input to bytes before passing it downstream.
        file_bytes = bytes(file_bytes)

        safe_name = guards.safe_filename(filename)
        try:
            guards.check_extension(safe_name)
            guards.check_size(len(file_bytes), safe_name)
        except (UnsupportedSourceError, SourceTooLargeError) as exc:
            raise DocumentSecurityError(str(exc)) from exc

        # Clear metadata from a previous conversion before starting a new one.
        self._last_result = None

        try:
            result = converter.convert_bytes(
                file_bytes,
                filename=safe_name,
                user_id=user_id,
                credential_id=credential_id,
            )
        except (MarkItDownUnavailable, ConversionError) as exc:
            raise DocumentConversionError(str(exc)) from exc
        except Exception as exc:
            logger.exception("Document conversion failed for %s", safe_name)
            raise DocumentConversionError(
                f"Failed to convert '{safe_name}': {exc}"
            ) from exc

        self._last_result = result
        return (result.markdown or "").strip()

    # def convert_from_base64(
    #     self,
    #     b64_content: str,
    #     filename: str,
    #     *,
    #     user_id: Optional[str] = None,
    #     credential_id: Optional[str] = None,
    # ) -> str:
    #     """Decode a base64 payload and convert it."""
    #     try:
    #         file_bytes = base64.b64decode(b64_content)
    #     except Exception as exc:
    #         raise DocumentConversionError(
    #             f"Invalid base64 content for '{filename}': {exc}"
    #         ) from exc
    #     return self.convert_from_bytes(
    #         file_bytes, filename, user_id=user_id, credential_id=credential_id
    #     )

    def convert_from_base64(
        self,
        b64_content: str,
        filename: str,
        *,
        user_id: Optional[str] = None,
        credential_id: Optional[str] = None,
    ) -> str:
        """
        Decode a base64 or base64 data-URL payload and convert it.

        Accepts either raw base64 or a value such as: data:image/png;base64,iVBORw0K...
        """
        if not isinstance(b64_content, str) or not b64_content.strip():
            raise DocumentConversionError(
                f"Empty or invalid base64 content for '{filename}'"
            )

        encoded_content = b64_content.strip()

        # Support browser-style data URLs.
        if encoded_content.lower().startswith("data:"):
            try:
                header, encoded_content = encoded_content.split(",", 1)
            except ValueError as exc:
                raise DocumentConversionError(
                    f"Invalid data URL for '{filename}'"
                ) from exc

            if ";base64" not in header.lower():
                raise DocumentConversionError(
                    f"Data URL for '{filename}' is not base64 encoded"
                )

        # Remove whitespace and line wrapping without accepting arbitrary
        # non-base64 characters.
        encoded_content = re.sub(r"\s+", "", encoded_content)

        try:
            file_bytes = base64.b64decode(
                encoded_content,
                validate=True,
            )
        except Exception as exc:
            raise DocumentConversionError(
                f"Invalid base64 content for '{filename}': {exc}"
            ) from exc
        if not file_bytes:
            raise DocumentConversionError(
                f"Decoded content for '{filename}' is empty"
            )

        return self.convert_from_bytes(
            file_bytes,
            filename,
            user_id=user_id,
            credential_id=credential_id,
        )

    def convert_from_path(
        self,
        file_path: Union[str, Path],
        *,
        user_id: Optional[str] = None,
        credential_id: Optional[str] = None,
    ) -> str:
        """Read a file from an allowed directory and convert it."""
        path = self._validate_path(file_path)
        return self.convert_from_bytes(
            path.read_bytes(),
            path.name,
            user_id=user_id,
            credential_id=credential_id,
        )

    # ------------------------------------------------------------------
    # Reporting
    # ------------------------------------------------------------------

    def last_conversion_notes(self) -> List[str]:
        """
        Warnings the last conversion produced, written for the caller to read.

        The one that matters is ``ocr_skipped_reason``: when no vision-capable
        model resolved, the images in a document were not read, and a caller
        told nothing will treat the text it got as complete.
        """
        result = self._last_result
        if result is None:
            return []

        notes: List[str] = []
        reason = getattr(result, "ocr_skipped_reason", None)
        if reason:
            notes.append(
                "Images in this document were not read: "
                f"{reason}. Text outside images was extracted normally."
            )
        return notes

    def last_conversion_metadata(self) -> Dict[str, Any]:
        """Non-secret description of how the last conversion was produced."""
        result = self._last_result
        if result is None:
            return {}
        try:
            return dict(result.describe())
        except Exception:  # pragma: no cover - defensive
            return {}

    # ------------------------------------------------------------------
    # Path policy
    # ------------------------------------------------------------------

    # def _validate_path(self, file_path: Union[str, Path]) -> Path:
    #     """
    #     Resolve a path and confirm it sits inside an allowed upload directory.

    #     WHAT: Containment check only -- no searching.
    #     WHY:  The previous implementation fell back to ``rglob(filename)`` over
    #           every upload root when a path did not resolve, so asking for
    #           ``invoice.pdf`` returned whichever ``invoice.pdf`` it found first,
    #           including one belonging to another session. Phase 9 removed the
    #           same pattern from ``data_analyst``. A caller that knows the file
    #           knows where it is; a caller that does not must not be handed
    #           somebody else's.
    #     RAISES: ``DocumentConversionError`` when the file does not exist,
    #             ``DocumentSecurityError`` when it exists outside the allowed
    #             directories.
    #     """
    #     candidate = Path(file_path)

    #     resolved: Optional[Path] = None
    #     if candidate.exists():
    #         resolved = candidate.resolve()
    #     elif not candidate.is_absolute():
    #         for base_dir in ALLOWED_UPLOAD_DIRS:
    #             direct = (base_dir / candidate).resolve()
    #             if direct.exists():
    #                 resolved = direct
    #                 break

    #     if resolved is None or not resolved.exists():
    #         raise DocumentConversionError(f"File not found: {file_path}")

    #     if not any(resolved == base or base in resolved.parents for base in ALLOWED_UPLOAD_DIRS):
    #         raise DocumentSecurityError(
    #             f"'{file_path}' resolves outside the allowed upload directories "
    #             f"({', '.join(str(path) for path in ALLOWED_UPLOAD_DIRS)})."
    #         )
    #     return resolved

    def _validate_path(
    self,
    file_path: Union[str, Path],
    ) -> Path:
        """
        Resolve a path and confirm that it is a regular file inside an allowed
        upload directory.

        No filename searching is performed. Relative paths are checked directly
        beneath the configured upload roots.
        """
        if not file_path:
            raise DocumentConversionError(
                "A file path is required"
            )

        candidate = Path(file_path)

        resolved: Optional[Path]= None

        if candidate.exists():
            resolved = candidate.resolve()

        elif not candidate.is_absolute():
            for base_dir in ALLOWED_UPLOAD_DIRS:
                direct = (base_dir / candidate).resolve()

                if direct.exists():
                    resolved = direct
                    break

        if resolved is None or not resolved.exists():
            raise DocumentConversionError(
                f"File not found: {file_path}"
            )

        if not resolved.is_file():
            raise DocumentConversionError(
                f"Source path is not a file: {file_path}"
            )

        is_allowed = any(
            resolved == base_dir or base_dir in resolved.parents
            for base_dir in ALLOWED_UPLOAD_DIRS
        )

        if not is_allowed:
            raise DocumentSecurityError(
                f"'{file_path}' resolves outside the allowed upload directories "
                f"({', '.join(str(path) for path in ALLOWED_UPLOAD_DIRS)})."
            )

        return resolved



class OCRService:
    """Echo-compatible OCR service backed by MarkItDown conversion."""

    def __init__(self):
        self.supported_formats = [
            ".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".gif",
            ".pdf", ".docx", ".pptx", ".xlsx", ".xls", ".csv", ".json",
            ".xml", ".html", ".txt", ".md", ".zip", ".epub", ".wav", ".mp3",
        ]
        self.currency_symbols = ["$", "€", "£", "¥", "₹"]
        self.date_patterns = [
            r"\d{1,2}/\d{1,2}/\d{2,4}",
            r"\d{4}-\d{2}-\d{2}",
            r"\d{1,2}-\d{1,2}-\d{2,4}",
            r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},? \d{4}",
        ]
        self._service: Optional[MarkItDownService] = None

    # def execute(self, context: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
    #     """
    #     Tool entry point.

    #     ``context`` is supplied by ``ToolExecutor`` for methods that declare it
    #     (``_context_kwargs``). Only ``user_id`` and ``credential_id`` are read,
    #     and only to resolve which vision model reads the images: without them
    #     the conversion falls back to the platform default, which is how this
    #     module used to behave for every caller.
    #     """
    #     operation = kwargs.get("operation")
    #     if not operation:
    #         return {"operation": "unknown", "success": False, "message": "No operation specified"}
    #     ctx = context or {}
    #     kwargs.setdefault("user_id", ctx.get("user_id"))
    #     kwargs.setdefault("credential_id", ctx.get("credential_id"))
    #     handlers = {
    #         "extract_text": self.extract_text,
    #         "extract_receipt_data": self.extract_receipt_data,
    #         "detect_text_regions": self.detect_text_regions,
    #         "extract_table_data": self.extract_table_data,
    #         "get_text_confidence": self.get_text_confidence,
    #         "batch_process": self.batch_process,
    #     }
    #     handler = handlers.get(operation)
    #     if handler is None:
    #         return {"operation": operation, "success": False, "message": f"Unknown operation: {operation}"}
    #     try:
    #         return handler(**kwargs)
    #     except (DocumentConversionError, DocumentSecurityError) as exc:
    #         logger.warning("OCR operation '%s' failed: %s", operation, exc)
    #         return {"operation": operation, "success": False, "message": str(exc)}
    #     except Exception as exc:
    #         logger.exception("Unexpected OCR error during '%s'", operation)
    #         return {"operation": operation, "success": False, "message": f"Error executing operation: {exc}"}


    def execute(
        self,
        context: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Tool entry point.

        Normalizes compatibility aliases accepted by the manifest before
        dispatching to the canonical OCR handlers.

        ``context`` is supplied by ``ToolExecutor``. The user and credential
        identifiers are forwarded to the MarkItDown credential resolver.
        """
        raw_operation = kwargs.get("operation")

        if not raw_operation:
            return {
                "operation": "unknown",
                "success": False,
                "message": "No operation specified",
            }

        # Normalize casing and surrounding whitespace.
        requested_operation = str(raw_operation).strip().lower()

        # Compatibility aliases accepted by the tool manifest.
        # operation_aliases = {
        #     "extract": "extract_text",
        #     "read": "extract_text",
        #     "ocr": "extract_text",
        #     "text": "extract_text",
        #     "receipt": "extract_receipt_data",
        #     "table": "extract_table_data",
        #     "regions": "detect_text_regions",
        #     "confidence": "get_text_confidence",
        #     "batch": "batch_process",
        # }

        operation_aliases = {
            "extract": "extract_text",
            "read": "extract_text",
            "ocr": "extract_text",
            }

        operation = operation_aliases.get(
            requested_operation,
            requested_operation,
        )

        # Store the canonical operation for handlers and downstream logging.
        kwargs["operation"] = operation

        # # Normalize output_format if it remains in the tool manifest.
        # output_format = kwargs.get("output_format")
        # if output_format is not None:
        #     kwargs["output_format"] = str(output_format).strip().lower()

        ctx = context or {}

        # setdefault() does not replace an existing key whose value is None.
        # Use explicit checks so context values are not accidentally ignored.
        if not kwargs.get("user_id"):
            kwargs["user_id"] = ctx.get("user_id")

        if not kwargs.get("credential_id"):
            kwargs["credential_id"] = ctx.get("credential_id")

        handlers = {
            "extract_text": self.extract_text,
            "extract_receipt_data": self.extract_receipt_data,
            "detect_text_regions": self.detect_text_regions,
            "extract_table_data": self.extract_table_data,
            "get_text_confidence": self.get_text_confidence,
            "batch_process": self.batch_process,
        }

        handler = handlers.get(operation)

        if handler is None:
            return {
                "operation": operation,
                "success": False,
                "message": (
                    f"Unknown operation: {requested_operation}. "
                    f"Supported operations: {', '.join(handlers.keys())}"
                ),
            }

        logger.info(
            "Executing OCR operation requested=%s canonical=%s",
            requested_operation,
            operation,
        )

        try:
            return handler(**kwargs)

        except (DocumentConversionError, DocumentSecurityError) as exc:
            logger.warning(
                "OCR operation '%s' failed: %s",
                operation,
                exc,
            )
            return {
                "operation": operation,
                "success": False,
                "message": str(exc),
            }

        except Exception as exc:
            logger.exception(
                "Unexpected OCR error during '%s'",
                operation,
            )
            return {
                "operation": operation,
                "success": False,
                "message": f"Error executing operation: {exc}",
            }
    
    def extract_text(self, **kwargs) -> Dict[str, Any]:
        confidence_threshold = kwargs.get("confidence_threshold", 0.6)
        extracted_text, metadata = self._convert_source_to_text(**kwargs)
        confidence_score = self._estimate_confidence(extracted_text)
        warnings = list(metadata.get("warnings", []))
        if not extracted_text.strip():
            warnings.append(
                "The document conversion completed, but no text was extracted."
            )
        if confidence_score < confidence_threshold:
            warnings.append(f"Low confidence estimate: {confidence_score:.2f} (threshold: {confidence_threshold})")
        if metadata.get("confidence_is_estimated"):
            warnings.append("MarkItDown does not expose OCR confidence directly; confidence_score is an Echo heuristic.")
        return {
            "operation": "extract_text",
            "success": True,
            "extracted_text": extracted_text,
            "confidence_score": confidence_score,
            "character_count": len(extracted_text),
            "line_count": len([line for line in extracted_text.splitlines() if line.strip()]),
            "warnings": warnings,
            "metadata": metadata,
            "message": f"Extracted {len(extracted_text)} characters from {metadata.get('source_name', 'document')}",
        }

    def extract_receipt_data(self, **kwargs) -> Dict[str, Any]:
        text_result = self.extract_text(**kwargs)
        if not text_result["success"]:
            return text_result
        receipt_data = self._parse_receipt_text(text_result["extracted_text"], kwargs.get("extract_fields") or [])
        validation = self._validate_receipt_data(receipt_data)
        warnings = list(text_result.get("warnings") or [])
        if not validation["is_valid"]:
            warnings.extend(validation["missing_fields"])
        return {
            "operation": "extract_receipt_data",
            "success": True,
            "receipt_data": receipt_data,
            "confidence_score": text_result["confidence_score"],
            "validation": validation,
            "warnings": warnings,
            "message": f"Extracted receipt from {receipt_data.get('merchant_name') or 'Unknown Merchant'}",
        }

    def detect_text_regions(self, **kwargs) -> Dict[str, Any]:
        text_result = self.extract_text(**kwargs)
        if not text_result["success"]:
            return text_result
        lines = [line.strip() for line in text_result["extracted_text"].splitlines() if line.strip()]
        text_regions = [
            {
                "text": line,
                "confidence": text_result["confidence_score"],
                "bbox": None,
                "type": self._classify_text_region(line),
                "line_number": index + 1,
            }
            for index, line in enumerate(lines)
        ]
        warnings = list(text_result.get("warnings") or [])
        warnings.append("MarkItDown does not return OCR bounding boxes; text_regions are line-based logical regions.")
        return {
            "operation": "detect_text_regions",
            "success": True,
            "text_regions": text_regions,
            "region_count": len(text_regions),
            "confidence_score": text_result["confidence_score"],
            "warnings": warnings,
            "message": f"Detected {len(text_regions)} logical text regions",
        }

    def extract_table_data(self, **kwargs) -> Dict[str, Any]:
        text_result = self.extract_text(**kwargs)
        if not text_result["success"]:
            return text_result
        line_items = self._parse_line_items(text_result["extracted_text"])
        subtotal = sum(item["amount"] for item in line_items)
        return {
            "operation": "extract_table_data",
            "success": True,
            "line_items": line_items,
            "item_count": len(line_items),
            "subtotal": round(subtotal, 2),
            "confidence_score": text_result["confidence_score"],
            "warnings": text_result.get("warnings", []),
            "message": f"Extracted {len(line_items)} line items",
        }

    def get_text_confidence(self, **kwargs) -> Dict[str, Any]:
        text_result = self.extract_text(**kwargs)
        if not text_result["success"]:
            return text_result
        confidence_data = self._analyze_confidence(text_result["extracted_text"])
        return {
            "operation": "get_text_confidence",
            "success": True,
            **confidence_data,
            "warnings": text_result.get("warnings", []),
            "message": f"Overall confidence: {confidence_data['overall_confidence']:.1%}",
        }

    # def batch_process(self, **kwargs) -> Dict[str, Any]:
    #     image_paths = kwargs.get("image_paths") or []
    #     if not image_paths:
    #         return {"operation": "batch_process", "success": False, "message": "No image_paths provided for batch processing"}
    #     results = []
    #     successful = 0
    #     failed = 0
    #     for image_path in image_paths:
    #         result = self.extract_receipt_data(image_path=image_path, **kwargs)
    #         results.append(
    #             {
    #                 "image_path": image_path,
    #                 "success": result.get("success", False),
    #                 "data": result.get("receipt_data", {}),
    #                 "confidence": result.get("confidence_score", 0),
    #                 "warnings": result.get("warnings", []),
    #                 "message": result.get("message"),
    #             }
    #         )
    #         if result.get("success"):
    #             successful += 1
    #         else:
    #             failed += 1
    #     return {
    #         "operation": "batch_process",
    #         "success": True,
    #         "results": results,
    #         "total_processed": len(image_paths),
    #         "successful": successful,
    #         "failed": failed,
    #         "message": f"Processed {len(image_paths)} files: {successful} successful, {failed} failed",
    #     }

    # def _get_service(self) -> MarkItDownService:
    #     if self._service is None:
    #         self._service = get_service()
    #     return self._service
    
    def batch_process(self, **kwargs) -> Dict[str, Any]:
        image_paths = kwargs.get("image_paths") or []

        if not image_paths:
            return {
                "operation": "batch_process",
                "success": False,
                "message": (
                    "No image_paths provided for batch processing"
                ),
            }

        raw_batch_operation = str(
            kwargs.get("batch_operation", "extract_text")
        ).strip().lower()

        batch_operation_aliases = {
            "extract": "extract_text",
            "receipt": "extract_receipt_data",
        }

        batch_operation = batch_operation_aliases.get(
            raw_batch_operation,
            raw_batch_operation,
        )

        batch_handlers = {
            "extract_text": self.extract_text,
            "extract_receipt_data": self.extract_receipt_data,
        }

        batch_handler = batch_handlers.get(batch_operation)

        if batch_handler is None:
            return {
                "operation": "batch_process",
                "success": False,
                "message": (
                    f"Unsupported batch_operation: "
                    f"{raw_batch_operation}. Supported values: "
                    "extract_text, extract_receipt_data"
                ),
            }

        # Keep common options such as confidence_threshold and credentials,
        # but remove all routing and document-source arguments.
        base_kwargs = dict(kwargs)

        for key in (
            "operation",
            "batch_operation",
            "image_paths",
            "image_path",
            "file_path",
            "file_bytes",
            "image_data",
            "file_content_base64",
            "filename",
        ):
            base_kwargs.pop(key, None)

        results: List[Dict[str, Any]] = []
        successful = 0
        failed = 0

        for image_path in image_paths:
            try:
                result = batch_handler(
                    image_path=image_path,
                    **base_kwargs,
                )

            except (DocumentConversionError, DocumentSecurityError) as exc:
                logger.warning(
                    "Batch OCR failed for '%s': %s",
                    image_path,
                    exc,
                )

                result = {
                    "operation": batch_operation,
                    "success": False,
                    "message": str(exc),
                }

            except Exception as exc:
                logger.exception(
                    "Unexpected batch OCR failure for '%s'",
                    image_path,
                )

                result = {
                    "operation": batch_operation,
                    "success": False,
                    "message": f"Unexpected OCR error: {exc}",
                }

            results.append(
                {
                    "image_path": image_path,
                    "success": result.get("success", False),
                    "extracted_text": result.get("extracted_text"),
                    "receipt_data": result.get("receipt_data"),
                    "confidence_score": result.get(
                        "confidence_score",
                        0,
                    ),
                    "warnings": result.get("warnings", []),
                    "metadata": result.get("metadata", {}),
                    "message": result.get("message"),
                }
            )

            if result.get("success"):
                successful += 1
            else:
                failed += 1

        return {
            "operation": "batch_process",
            "success": failed == 0,
            "results": results,
            "total_processed": len(image_paths),
            "successful": successful,
            "failed": failed,
            "message": (
                f"Processed {len(image_paths)} files: "
                f"{successful} successful, {failed} failed"
            ),
        }

    # def _convert_source_to_text(self, **kwargs) -> Tuple[str, Dict[str, Any]]:
    #     """
    #     Resolve whichever source shape the caller supplied and convert it.

    #     The returned metadata carries the conversion notes from
    #     ``apps.markitdown`` -- most importantly whether image OCR was skipped,
    #     which the caller must be told rather than left to infer from short text.
    #     """
    #     file_path = kwargs.get("file_path") or kwargs.get("image_path")
    #     file_bytes = kwargs.get("file_bytes")
    #     image_data = kwargs.get("file_content_base64") or kwargs.get("image_data")
    #     filename = kwargs.get("filename") or self._resolve_filename(file_path, kwargs)
    #     identity = {
    #         "user_id": kwargs.get("user_id"),
    #         "credential_id": kwargs.get("credential_id"),
    #     }
    #     service = self._get_service()

    #     if file_bytes is not None:
    #         if not filename:
    #             raise DocumentConversionError("filename or image_path is required when using file_bytes")
    #         extracted_text = service.convert_from_bytes(file_bytes, filename, **identity)
    #         source_type, source_name = "bytes", filename
    #     elif image_data:
    #         if not filename:
    #             raise DocumentConversionError("filename is required when using image_data or file_content_base64")
    #         extracted_text = service.convert_from_base64(image_data, filename, **identity)
    #         source_type, source_name = "base64", filename
    #     elif file_path:
    #         extracted_text = service.convert_from_path(file_path, **identity)
    #         source_type, source_name = "path", Path(file_path).name
    #     else:
    #         raise DocumentConversionError(
    #             "One of file_path/image_path, file_bytes, or file_content_base64/image_data must be provided"
    #         )

    #     metadata: Dict[str, Any] = {
    #         "backend": "markitdown",
    #         "source_type": source_type,
    #         "source_name": source_name,
    #         "confidence_is_estimated": True,
    #         "warnings": service.last_conversion_notes(),
    #     }
    #     metadata.update(service.last_conversion_metadata())
    #     return extracted_text, metadata


    def _get_service(self) -> MarkItDownService:
        """
        Return the conversion service owned by this OCRService instance.

        MarkItDownService stores metadata for the most recent conversion, so
        OCRService should not use the process-wide singleton for request-specific
        result reporting.
        """
        if self._service is None:
            self._service = MarkItDownService()

        return self._service


    def _convert_source_to_text(
        self,
        **kwargs,
    ) -> Tuple[str, Dict[str, Any]]:
        """
        Resolve exactly one source and convert it.

        Supported sources:
        - file_path or image_path
        - file_bytes
        - file_content_base64 or image_data
        """
        file_path = (
            kwargs.get("file_path")
            or kwargs.get("image_path")
        )

        file_bytes = kwargs.get("file_bytes")

        image_data = (
            kwargs.get("file_content_base64")
            or kwargs.get("image_data")
        )

        filename = (
            kwargs.get("filename")
            or self._resolve_filename(file_path, kwargs)
        )

        source_count = sum(
            (
                bool(file_path),
                file_bytes is not None,
                bool(image_data),
            )
        )

        if source_count == 0:
            raise DocumentConversionError(
                "One source is required: file_path/image_path, "
                "file_bytes, or file_content_base64/image_data"
            )

        if source_count > 1:
            raise DocumentConversionError(
                "Provide only one source: file_path/image_path, "
                "file_bytes, or file_content_base64/image_data"
            )

        identity = {
            "user_id": kwargs.get("user_id"),
            "credential_id": kwargs.get("credential_id"),
        }

        service = self._get_service()

        if file_bytes is not None:
            if not filename:
                raise DocumentConversionError(
                    "filename is required when using file_bytes"
                )

            extracted_text = service.convert_from_bytes(
                file_bytes,
                filename,
                **identity,
            )

            source_type = "bytes"
            source_name = filename

        elif image_data:
            if not filename:
                raise DocumentConversionError(
                    "filename is required when using image_data "
                    "or file_content_base64"
                )

            extracted_text = service.convert_from_base64(
                image_data,
                filename,
                **identity,
            )

            source_type = "base64"
            source_name = filename

        else:
            extracted_text = service.convert_from_path(
                file_path,
                **identity,
            )

            source_type = "path"
            source_name = Path(file_path).name

        metadata: Dict[str, Any] = {
            "backend": "markitdown",
            "source_type": source_type,
            "source_name": source_name,
            "confidence_is_estimated": True,
            "warnings": service.last_conversion_notes(),
        }

        metadata.update(
            service.last_conversion_metadata()
        )

        return extracted_text, metadata    

    def _resolve_filename(self, file_path: Optional[str], kwargs: Dict[str, Any]) -> Optional[str]:
        if kwargs.get("filename"):
            return kwargs["filename"]
        if file_path:
            return Path(file_path).name
        return None

    def _estimate_confidence(self, extracted_text: str) -> float:
        stripped = re.sub(r"\s+", "", extracted_text or "")
        if not stripped:
            return 0.0
        alnum_ratio = sum(char.isalnum() for char in stripped) / max(len(stripped), 1)
        line_count = max(len([line for line in (extracted_text or "").splitlines() if line.strip()]), 1)
        signal_bonus = min(len(stripped) / 1200, 0.12)
        structure_bonus = min(line_count / 100, 0.08)
        return round(min(0.65 + (alnum_ratio * 0.15) + signal_bonus + structure_bonus, 0.98), 2)

    def _parse_receipt_text(self, text: str, extract_fields: Optional[List[str]] = None) -> Dict[str, Any]:
        receipt_data = {
            "merchant_name": None,
            "merchant_address": None,
            "date": None,
            "time": None,
            "total_amount": None,
            "subtotal": None,
            "tax_amount": None,
            "payment_method": None,
            "transaction_id": None,
            "items": [],
            "raw_text": text,
        }
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        for line in lines[:5]:
            if re.search(r"[A-Za-z]{3,}", line) and not re.search(r"store|#|street|avenue|blvd|road|st\.?$", line.lower()):
                receipt_data["merchant_name"] = line.strip("#*- ")
                break
        for line in lines:
            for pattern in self.date_patterns:
                match = re.search(pattern, line)
                if match:
                    receipt_data["date"] = match.group(0)
                    break
            if receipt_data["date"]:
                break
        time_match = re.search(r"\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?", text, re.IGNORECASE)
        if time_match:
            receipt_data["time"] = time_match.group(0)
        for line in lines:
            if re.search(r"(?i)total", line):
                amount_match = re.search(r"[\$€£¥₹]?\s*(\d+[,.]?\d*\.?\d{2})(?!\d)", line)
                if amount_match:
                    receipt_data["total_amount"] = float(amount_match.group(1).replace(",", ""))
                    break
        for line in lines:
            if re.search(r"(?i)subtotal", line):
                amount_match = re.search(r"[\$€£¥₹]?\s*(\d+[,.]?\d*\.?\d{2})(?!\d)", line)
                if amount_match:
                    receipt_data["subtotal"] = float(amount_match.group(1).replace(",", ""))
                    break
        for line in lines:
            if re.search(r"(?i)tax", line):
                amount_match = re.search(r"[\$€£¥₹]?\s*(\d+[,.]?\d*\.?\d{2})(?!\d)", line)
                if amount_match:
                    receipt_data["tax_amount"] = float(amount_match.group(1).replace(",", ""))
                    break
        payment_patterns = [r"(?i)(visa|mastercard|amex|discover|debit|cash|credit)", r"\*+\d{4}"]
        for line in lines:
            if any(re.search(pattern, line) for pattern in payment_patterns):
                receipt_data["payment_method"] = line
                break
        receipt_data["items"] = self._parse_line_items(text)
        return receipt_data

    def _parse_line_items(self, text: str) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        for raw_line in text.splitlines():
            line = raw_line.strip().lstrip("-*0123456789. ")
            if not line or re.search(r"(?i)store|street|thank|total|subtotal|tax|card|cash|approved|invoice|receipt", line):
                continue
            amount_match = re.search(r"[\$€£¥₹]?\s*(\d+[,.]?\d*\.?\d{2})(?!\d)", line)
            if not amount_match:
                continue
            amount = float(amount_match.group(1).replace(",", ""))
            item_name = line[:amount_match.start()].strip(" :-")
            if len(item_name) < 3:
                continue
            quantity = 1
            qty_match = re.search(r"^(\d+)\s+", item_name)
            if qty_match:
                quantity = int(qty_match.group(1))
                item_name = item_name[qty_match.end():].strip()
            items.append(
                {
                    "description": item_name,
                    "quantity": quantity,
                    "amount": amount,
                    "unit_price": round(amount / quantity, 2) if quantity > 0 else amount,
                }
            )
        return items

    def _validate_receipt_data(self, receipt_data: Dict[str, Any]) -> Dict[str, Any]:
        required_fields = ["merchant_name", "date", "total_amount"]
        missing_fields = [f"Missing {field}" for field in required_fields if not receipt_data.get(field)]
        has_math_error = False
        if receipt_data.get("subtotal") and receipt_data.get("tax_amount") and receipt_data.get("total_amount"):
            calculated_total = receipt_data["subtotal"] + receipt_data["tax_amount"]
            if abs(calculated_total - receipt_data["total_amount"]) > 0.02:
                has_math_error = True
                missing_fields.append(f"Total mismatch: {receipt_data['total_amount']} != {calculated_total}")
        return {
            "is_valid": not missing_fields,
            "missing_fields": missing_fields,
            "has_required_fields": all(receipt_data.get(field) for field in required_fields),
            "has_math_error": has_math_error,
        }

    def _analyze_confidence(self, text: str) -> Dict[str, Any]:
        overall = self._estimate_confidence(text)
        high = round(min(overall + 0.1, 1.0), 2)
        medium = round(max(0.05, 1.0 - high - 0.05), 2)
        low = round(max(0.0, 1.0 - high - medium), 2)
        return {
            "overall_confidence": overall,
            "text_clarity": round(min(overall + 0.03, 1.0), 2),
            "image_quality": round(max(overall - 0.04, 0.0), 2),
            "character_confidence": {"high": high, "medium": medium, "low": low},
            "quality_metrics": {
                "source": "markitdown",
                "signal_length": len(re.sub(r"\s+", "", text)),
                "line_count": len([line for line in text.splitlines() if line.strip()]),
                "confidence_method": "heuristic",
            },
            "recommendations": [
                "Confidence values are heuristic because MarkItDown does not expose OCR confidence.",
                "Review extracted totals and dates before using receipt data downstream.",
            ],
        }

    def _classify_text_region(self, line: str) -> str:
        lowered = line.lower()
        if "total" in lowered:
            return "total"
        if any(token in lowered for token in ("date", "invoice", "receipt")):
            return "info"
        if re.search(r"[\$€£¥₹]?\s*\d+[,.]?\d*\.?\d{2}", line):
            return "line_item"
        if len(line) < 40 and line.upper() == line:
            return "header"
        return "text"


_service_instance: Optional[MarkItDownService] = None


def get_service() -> MarkItDownService:
    """
    Return the process-wide MarkItDownService compatibility instance.

    This remains available for package exports and legacy callers.
    """
    global _service_instance
    if _service_instance is None:
        _service_instance = MarkItDownService()
    return _service_instance

__all__ = [
    "OCRService",
    "MarkItDownService",
    "DocumentConversionError",
    "DocumentSecurityError",
    "get_service",
]
