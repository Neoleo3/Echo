"""
PPT Template Populator AgentTool package.

Populates an existing PowerPoint template (ppt_template_test.pptx) with
structured JSON data. Supports placeholder replacement for presentation
title, subtitle, and section details. Uses python-pptx (MIT license).
"""
