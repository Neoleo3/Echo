"""
PowerPoint Template Populator Tool.

WHY: Users frequently request "fill this template with my data" or
"populate the presentation template with analysis results". Without this
tool the agent can only reply with text. With it, the agent populates
an existing .pptx template and returns a file the user can download.

Uses python-pptx (MIT license) — no AGPL risk.

DESCRIPTION-GATED: The tool description explicitly states it should ONLY
be called when the user explicitly requests template population.
The agent will NOT call it for general queries.

AZURE BLOB STORAGE INTEGRATED: The generated .pptx files are uploaded to 
Azure Blob Storage and a download URL is returned to the user.
"""
import socket
import logging
import os
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
from pptx import Presentation

from echolib.branding import resolve_kpmg_logo as _resolve_kpmg_logo
from echolib.blob_storage import (
    upload_to_blob,
    get_blob_url,
)


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool definition (used by the auto-bind registry)
# ---------------------------------------------------------------------------

TOOL_DEFINITION = {
    "tool_id": "tool_ppt_generator_template",
    "name": "PowerPoint Template Populator",
    "description": (
        "ONLY use this tool when the user EXPLICITLY asks to populate a PowerPoint "
        "template with data. Do NOT use this tool for creating presentations from scratch. "
        "This tool fills ppt_template_test.pptx with JSON data for presentation title, "
        "subtitle, and section details using placeholders like {{presentation.title}}, "
        "{{section.description}}, {{section.type}}. Returns a downloadable file path."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "json_data": {
                "type": ["object", "string"],
                "description": "Preferred payload. Accepts either object data or a JSON string.",
            },
            "presentation": {
                "type": "object",
                "description": "Direct payload mode: top-level presentation metadata.",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Presentation title for {{presentation.title}} placeholder",
                    },
                    "subtitle": {
                        "type": "string",
                        "description": "Presentation subtitle for {{presentation.subtitle}} placeholder",
                    },
                },
            },
            "title": {
                "type": "string",
                "description": "Fallback title in direct payload mode.",
            },
            "subtitle": {
                "type": "string",
                "description": "Fallback subtitle in direct payload mode.",
            },
            "session_id": {
                "type": "string",
                "description": "Chat session identifier used to organize generated PowerPoints in Azure Blob Storage."
                },
            "sections": {
                "type": "array",
                "description": "Array of section objects or strings to populate section slides",
                "items": {
                    "type": ["object", "string"],
                },
            },
        },
        "anyOf": [
            {"required": ["json_data"]},
            {"required": ["presentation"]},
            {"required": ["title"]},
        ],
    },
    "capabilities": ["ppt_template_population", "template_filling"],
}


class PPTGeneratorService:
    """
    Populates an existing PowerPoint template with structured JSON data.

    WHY: Wraps python-pptx to abstract away template placeholder replacement.
    Provides a clean API that the agent LLM can call via the tool schema.
    The template file (ppt_template_test.pptx) is resolved from workspace root.
    """

    # Hardcoded template path
    TEMPLATE_PATH = Path.cwd() / "ppt_template_test.pptx"
  
    # TEMPLATE_PATH = (
    #     Path(__file__).resolve().parent
    #     / "template"
    #     / "ppt_template_test.pptx"
    # )

    # TEMPLATE_PATH = Path(
    #     "/backend/AgentTools/ppt_generator_template/template/ppt_template_test.pptx"
    # )

    def __init__(self, output_dir: Optional[str] = None) -> None:
        """
        Initialize with the directory where .pptx files will be saved.

        Args:
            output_dir: Absolute path for saving generated .pptx files.

        Raises:
            FileNotFoundError: If template file does not exist at TEMPLATE_PATH.
        """
        # uploads_root = os.getenv("APP_UPLOADS_DIR")
        # default_output_dir = (
        #     os.path.join(uploads_root, "generated", "ppt")
        #     if uploads_root
        #     else os.path.join("uploads", "generated", "ppt")
        # )
        # self.output_dir = os.path.abspath(output_dir or default_output_dir)


        uploads_root = os.getenv("APP_UPLOADS_DIR", "/app/uploads")

        self.output_dir = os.path.abspath(
            output_dir or os.path.join(uploads_root, "generated", "ppt")
        )
        os.makedirs(self.output_dir, exist_ok=True)
        logger.info(f"OUTPUT_DIR={self.output_dir}")
        logger.info(f"OUTPUT_DIR_EXISTS={os.path.exists(self.output_dir)}")
        self._logo_path = _resolve_kpmg_logo()

        logger.info("CURRENT_WORKING_DIRECTORY=%s", Path.cwd())
        logger.info(f"PPT_TEMPLATE_PATH={self.TEMPLATE_PATH}")
        logger.info(f"PPT_TEMPLATE_EXISTS={self.TEMPLATE_PATH.exists()}")

        # Verify template exists at startup
        if not self.TEMPLATE_PATH.exists():
            raise FileNotFoundError(
                f"Template file not found: {self.TEMPLATE_PATH}. "
                f"Ensure ppt_template_test.pptx exists at workspace root "
            )

        logger.info(f"PPT template loaded from: {self.TEMPLATE_PATH}")

    def generate(self, json_data: Any = None, **kwargs: Any) -> Dict[str, str]:
        """
        Populate ppt_template_test.pptx with JSON data.

        WHY: Accepts the clean dict structure that the LLM produces from the
        tool schema and populates the template with presentation title, subtitle,
        and section details.

        Args:
            json_data: Preferred wrapped payload. Can be a dict or JSON string.
                Expected structure:
                {
                    "presentation": {
                        "title": str,
                        "subtitle": str (optional)
                    },
                    "sections": [
                        {
                            "title": str,
                            "description": str,
                            "type": str
                        }
                    ]
                }
            **kwargs: Direct payload mode (presentation/title/subtitle/sections).

        Returns:
            Dict with "file_path" (str), "filename" (str), "file_id" (str).

        The payload is normalized into the internal shape:
            {"presentation": {"title": str, "subtitle": str}, "sections": list[dict]}
        """

        logger.info("========== PPT TEMPLATE TOOL INVOKED ==========")

        logger.info(
            "RAW_JSON_DATA_TYPE=%s",
            type(json_data).__name__,
        )

        logger.info(
            "RAW_JSON_DATA=%s",
            json.dumps(
                json_data,
                default=str,
                indent=2,
            ) if json_data is not None else "None",
        )

        logger.info(
            "RAW_KWARGS=%s",
            json.dumps(
                kwargs,
                default=str,
                indent=2,
            ),
        )
        normalized_data = self._normalize_payload(json_data, kwargs)

        logger.info(
            "NORMALIZED_PRESENTATION_TITLE=%s",
            normalized_data.get("presentation", {}).get("title"),
        )

        logger.info(
            "NORMALIZED_SECTION_COUNT=%s",
            len(normalized_data.get("sections", [])),
        )
        
        session_id = (
            kwargs.get("session_id")
            or kwargs.get("chat_session_id")
            or normalized_data.get("session_id")
            or str(uuid.uuid4())
            )

        # Generate unique file ID and output path
        file_id = str(uuid.uuid4())

        template_name = self.TEMPLATE_PATH.stem

        presentation_title = (
            normalized_data.get("presentation", {}).get("title", "")
            if isinstance(normalized_data.get("presentation", {}), dict)
            else ""
        )

        safe_title = "".join(
            c for c in str(presentation_title)
            if c.isalnum() or c in " -_"
        )[:60].strip()

        filename = f"{safe_title or template_name}.pptx"

        file_path = os.path.join(
            self.output_dir,
            f"{file_id}_{filename}"
        )

        abs_path = os.path.abspath(file_path)

        # Populate the template
        self._populate_template(
            template_path=str(self.TEMPLATE_PATH),
            json_data=normalized_data,
            output_path=abs_path,
        )


        blob_name = (
            f"generated/doc/"
            f"{session_id}/"
            f"{file_id}/"
            f"{filename}"
        )

        uploaded = upload_to_blob(
        local_path=abs_path,
        blob_name=blob_name,
        )

        if not uploaded:
            raise RuntimeError(
                f"Failed to upload PPT to Azure Blob Storage: {blob_name}"
                )
            
        download_url = get_blob_url(blob_name)
        logger.info(
            "DOWNLOAD_URL=%s",
            download_url,
        )
        try:
            os.remove(abs_path)
        except Exception:
            logger.warning(
                "Failed to remove local PPT: %s",
                abs_path,
            )

        logger.info(f"Template populated: {filename} → {abs_path}")
        marker = f"[GENERATED_FILE:{download_url}|{filename}]"
        # marker = f"[GENERATED_FILE:{abs_path}:{filename}]"
        logger.info(
            "MARKER_PAYLOAD=%s",
            marker
            )

        # return {
        #     "result": (
        #         f"File generated successfully: {filename}\n\n"
        #         f"{marker}\n\n"
        #         "Include the [GENERATED_FILE:...] line above EXACTLY ONCE in your "
        #         "final answer, verbatim — it becomes the download link."
        #     ),
        #     "file_path": abs_path,
        #     "filename": filename,
        #     "file_id": file_id,
        #     "blob_name": blob_name,
        #     "download_url": download_url,
        #     "session_id": session_id,
        # }

        # return {
        #     "result": (
        #         f"Template populated successfully.\n\n"
        #         f"Download URL:\n{download_url}"
        #     ),
        #     "filename": filename,
        #     "file_id": file_id,
        #     "download_url": download_url,
        #     "blob_name": blob_name,
        #     "session_id": session_id,
        # }

        return {
            "file_path": download_url,
            "filename": filename,
            "file_id": file_id,
            "download_url": download_url,
            "session_id": session_id,
            "result": (
                f"File generated successfully.\n\n"
                f"Download URL:\n{download_url}"
            ),
        }

    def _normalize_payload(self, json_data: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize flexible inputs into a single internal payload contract."""
        raw_payload = self._coerce_payload_source(json_data=json_data, kwargs=kwargs)

        if not isinstance(raw_payload, dict):
            raw_payload = {}

        presentation = raw_payload.get("presentation")
        if not isinstance(presentation, dict):
            presentation = {}

        title = self._first_non_empty(
            presentation.get("title"),
            raw_payload.get("title"),
            raw_payload.get("presentation_title"),
            "Generated Presentation",
        )
        subtitle = self._first_non_empty(
            presentation.get("subtitle"),
            raw_payload.get("subtitle"),
            raw_payload.get("presentation_subtitle"),
            "",
        )

        normalized_presentation: Dict[str, str] = {
            "title": str(title),
            "subtitle": str(subtitle),
        }

        sections = self._normalize_sections(raw_payload.get("sections"))
        return {
            "presentation": normalized_presentation,
            "sections": sections,
            "session_id": raw_payload.get("session_id"),
            }

    def _coerce_payload_source(self, json_data: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Accept wrapped, direct, or JSON-string payloads without failing hard."""
        payload: Any = json_data
        if payload is None:
            payload = kwargs

        if isinstance(payload, str):
            payload = payload.strip()
            if not payload:
                payload = {}
            else:
                try:
                    payload = json.loads(payload)
                except json.JSONDecodeError:
                    logger.warning("ppt_generator_template received non-JSON string payload")
                    payload = {"title": payload}

        if not isinstance(payload, dict):
            logger.warning(
                "ppt_generator_template received unsupported payload type: %s",
                type(payload).__name__,
            )
            return {}

        # Some callers send wrapper-level shape: {"json_data": {...}}
        embedded = payload.get("json_data")
        if isinstance(embedded, str):
            try:
                embedded = json.loads(embedded)
            except json.JSONDecodeError:
                embedded = None

        if isinstance(embedded, dict):
            merged = dict(embedded)
            for key in ("presentation", "title", "subtitle", "sections"):
                if key in payload and key not in merged:
                    merged[key] = payload[key]
            return merged

        return payload

    def _normalize_sections(self, sections: Any) -> List[Dict[str, str]]:
        """Normalize sections to list[dict] with stable keys used by placeholders."""
        if sections is None:
            return []

        if isinstance(sections, dict):
            section_items = [sections]
        elif isinstance(sections, list):
            section_items = sections
        else:
            section_items = [sections]

        normalized: List[Dict[str, str]] = []
        for idx, item in enumerate(section_items, start=1):
            if isinstance(item, str):
                text = item.strip()
                if not text:
                    continue
                normalized.append(
                    {
                        "title": f"Section {idx}",
                        "description": text,
                        "type": "",
                    }
                )
                continue

            if not isinstance(item, dict):
                continue

            title = self._first_non_empty(
                item.get("title"),
                item.get("name"),
                item.get("heading"),
                f"Section {idx}",
            )
            description = self._first_non_empty(
                item.get("description"),
                item.get("content"),
                item.get("body"),
                item.get("text"),
                "",
            )
            section_type = self._first_non_empty(
                item.get("type"),
                item.get("category"),
                item.get("kind"),
                "",
            )

            normalized.append(
                {
                    "title": str(title),
                    "description": str(description),
                    "type": str(section_type),
                }
            )

        return normalized

    @staticmethod
    def _first_non_empty(*values: Any) -> Any:
        """Return the first non-empty value (after trimming strings)."""
        for value in values:
            if value is None:
                continue
            if isinstance(value, str):
                stripped = value.strip()
                if stripped:
                    return stripped
                continue
            return value
        return ""

    def _replace_placeholder(
        self,
        slide,
        placeholder: str,
        value: str,
    ) -> None:
        """
        Replace placeholder text while retaining the existing shape formatting.

        Args:
            slide: python-pptx Slide object.
            placeholder: Placeholder string (e.g., "{{presentation.title}}").
            value: Replacement value (will be converted to string).
        """
        for shape in slide.shapes:
            if not hasattr(shape, "text"):
                continue

            try:
                if placeholder in shape.text:
                    shape.text = shape.text.replace(placeholder, str(value))
            except Exception as e:
                logger.debug(f"Could not replace {placeholder} in shape: {e}")
                continue

    def _add_logo(self, prs: Presentation, slide: Any) -> None:
        """Place the shared KPMG logo in the top-right corner of a slide."""
        if not self._logo_path:
            return
        try:
            from pptx.util import Inches

            width = Inches(1.4)
            left = prs.slide_width - width - Inches(0.4)
            slide.shapes.add_picture(
                self._logo_path, left, Inches(0.25), width=width
            )
        except Exception:
            logger.exception("KPMG logo could not be added to template slide")

    def _remove_slide(self, prs: Presentation, slide_index: int) -> None:
        """
        Remove an unused slide from the presentation.

        Args:
            prs: python-pptx Presentation object.
            slide_index: 0-based index of the slide to remove.
        """
        slide_id = prs.slides._sldIdLst[slide_index]
        prs.slides._sldIdLst.remove(slide_id)

    def _populate_template(
        self,
        template_path: str,
        json_data: Dict[str, Any],
        output_path: str,
    ) -> None:
        """
        Populate an existing PPT template with JSON data.

        Args:
            template_path: Path to the template .pptx file.
            json_data: Dictionary with presentation and sections data.
            output_path: Path where the populated .pptx will be saved.
        """
        prs = Presentation(template_path)

        presentation = json_data.get("presentation", {})
        sections = json_data.get("sections", [])

        # =====================================================================
        # TITLE SLIDE (slide 0)
        # =====================================================================
        if len(prs.slides) > 0:
            slide = prs.slides[0]

            # Brand consistency with ppt_generator: add logo on title slide.
            self._add_logo(prs, slide)

            # Replace presentation title
            self._replace_placeholder(
                slide,
                "{{presentation.title}}",
                presentation.get("title", ""),
            )

            # Replace presentation subtitle (if provided)
            if "subtitle" in presentation:
                self._replace_placeholder(
                    slide,
                    "{{presentation.subtitle}}",
                    presentation.get("subtitle", ""),
                )

        # =====================================================================
        # SECTION SLIDES (starting from slide 1)
        # =====================================================================
        template_start_slide = 1

        max_content_slide_index = len(prs.slides) - 2
        for idx, section in enumerate(sections):
            slide_index = template_start_slide + idx

            # Stop if we've run out of template slides
            if slide_index > max_content_slide_index:
                break

            slide = prs.slides[slide_index]

            # Brand consistency with ppt_generator: add logo on section slides.
            self._add_logo(prs, slide)

            # Replace section title
            self._replace_placeholder(
                slide,
                "{{section.title}}",
                section.get("title", ""),
            )

            # Replace section description
            self._replace_placeholder(
                slide,
                "{{section.description}}",
                section.get("description", ""),
            )

            # Replace section type
            self._replace_placeholder(
                slide,
                "{{section.type}}",
                section.get("type", ""),
            )

        # =====================================================================
        # REMOVE UNUSED TEMPLATE SLIDES
        # =====================================================================
        # If there are fewer sections than template slides, remove the extras
        slides_required = len(sections) + 1  # +1 for title slide

        # Preserve final Thank You slide
        last_slide_index = len(prs.slides) - 1

        for i in reversed(range(slides_required, last_slide_index)):
            self._remove_slide(prs, i)

        # Save the populated presentation
        prs.save(output_path)
        # logger.info(
        #     f"Template populated successfully: {sections.__len__()} sections, "
        #     f"{len(prs.slides)} total slides"
        # )
        if not os.path.exists(output_path):
            raise RuntimeError(
                f"PPT file missing immediately after save: {output_path}"
            )

        logger.info(
            f"PPT saved successfully: {output_path}"
        )

        logger.info(
            f"SAVE_HOST={socket.gethostname()}"
        )

        logger.info(
            f"PPT size: {os.path.getsize(output_path)} bytes"
        )
