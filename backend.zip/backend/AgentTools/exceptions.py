"""
AgentTools Custom Exceptions - Structured error handling

Provides specific exception types for different failure scenarios.
Enables proper logging and error recovery.
"""

from typing import Optional, Dict, Any


class AgentToolError(Exception):
    """Base exception for all AgentTools errors."""
    
    def __init__(
        self,
        message: str,
        error_code: str = "UNKNOWN",
        details: Optional[Dict[str, Any]] = None,
        recovery_hint: Optional[str] = None
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.recovery_hint = recovery_hint
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/API responses."""
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "recovery_hint": self.recovery_hint,
        }


# =============================================================================
# FILE READER ERRORS
# =============================================================================

class FileReaderError(AgentToolError):
    """Base exception for file reading errors."""
    pass


class FileSizeExceededError(FileReaderError):
    """File is larger than allowed limit."""
    
    def __init__(self, file_size: int, max_size: int):
        super().__init__(
            message=f"File size {file_size} bytes exceeds limit {max_size} bytes",
            error_code="FILE_SIZE_EXCEEDED",
            details={
                "file_size_bytes": file_size,
                "max_size_bytes": max_size,
                "file_size_mb": round(file_size / 1024 / 1024, 2),
                "max_size_mb": round(max_size / 1024 / 1024, 2),
            },
            recovery_hint="Reduce file size or upload in smaller chunks"
        )


class UnsupportedMimeTypeError(FileReaderError):
    """MIME type is not supported."""
    
    def __init__(self, mime_type: str, supported_types: list):
        super().__init__(
            message=f"MIME type '{mime_type}' is not supported",
            error_code="UNSUPPORTED_MIME_TYPE",
            details={
                "provided_mime_type": mime_type,
                "supported_mime_types": supported_types,
            },
            recovery_hint=f"Use one of: {', '.join(supported_types)}"
        )


class ParsingError(FileReaderError):
    """Error during file parsing."""
    
    def __init__(self, file_type: str, original_error: Exception):
        super().__init__(
            message=f"Failed to parse {file_type} file: {str(original_error)}",
            error_code="PARSING_ERROR",
            details={
                "file_type": file_type,
                "original_error": str(original_error),
                "error_type": type(original_error).__name__,
            },
            recovery_hint=f"Verify {file_type} file is not corrupted"
        )


class CSVAgentError(FileReaderError):
    """Error in CSV query agent."""
    
    def __init__(self, query: str, original_error: Exception):
        super().__init__(
            message=f"CSV analysis failed: {str(original_error)}",
            error_code="CSV_AGENT_ERROR",
            details={
                "query": query,
                "original_error": str(original_error),
            },
            recovery_hint="Check query syntax and data format"
        )


# =============================================================================
# EXCEL GENERATOR ERRORS
# =============================================================================

class ExcelGeneratorError(AgentToolError):
    """Base exception for Excel generation errors."""
    pass


class InvalidExcelDataError(ExcelGeneratorError):
    """Invalid data structure for Excel generation."""
    
    def __init__(self, issue: str, details_dict: Dict[str, Any]):
        super().__init__(
            message=f"Invalid Excel data: {issue}",
            error_code="INVALID_EXCEL_DATA",
            details=details_dict,
            recovery_hint="Verify sheets/headers/rows structure"
        )


class ExcelFormulaSyntaxError(ExcelGeneratorError):
    """Invalid Excel formula."""
    
    def __init__(self, formula: str, original_error: Exception):
        super().__init__(
            message=f"Invalid Excel formula: {formula}",
            error_code="INVALID_FORMULA",
            details={
                "formula": formula,
                "error": str(original_error),
            },
            recovery_hint="Check Excel formula syntax"
        )


class ExcelChartError(ExcelGeneratorError):
    """Error creating chart."""
    
    def __init__(self, chart_type: str, original_error: Exception):
        super().__init__(
            message=f"Failed to create {chart_type} chart: {str(original_error)}",
            error_code="CHART_CREATION_ERROR",
            details={
                "chart_type": chart_type,
                "error": str(original_error),
            },
            recovery_hint="Verify chart data and type"
        )


# =============================================================================
# PPT GENERATOR ERRORS
# =============================================================================

class PPTGeneratorError(AgentToolError):
    """Base exception for PPT generation errors."""
    pass


class NodeJsNotFoundError(PPTGeneratorError):
    """Node.js executable not found."""
    
    def __init__(self, node_path: str):
        super().__init__(
            message=f"Node.js not found at: {node_path}",
            error_code="NODE_JS_NOT_FOUND",
            details={"tried_path": node_path},
            recovery_hint="Install Node.js or set NODE_EXECUTABLE environment variable"
        )


class PptxGenJsNotFoundError(PPTGeneratorError):
    """pptxgenjs package not available."""
    
    def __init__(self):
        super().__init__(
            message="pptxgenjs package not installed",
            error_code="PPTXGENJS_NOT_FOUND",
            recovery_hint="Run: npm install pptxgenjs in node_scripts directory"
        )


class PPTSubprocessError(PPTGeneratorError):
    """Error executing PPT generation subprocess."""
    
    def __init__(self, returncode: int, stderr: str, timeout: Optional[bool] = False):
        super().__init__(
            message=f"PPT generation subprocess failed (code {returncode})",
            error_code="PPT_SUBPROCESS_ERROR",
            details={
                "return_code": returncode,
                "stderr": stderr,
                "timeout": timeout,
            },
            recovery_hint="Check node script logs and pptxgenjs configuration"
        )


class InvalidPPTDataError(PPTGeneratorError):
    """Invalid data structure for PPT generation."""
    
    def __init__(self, issue: str, details_dict: Dict[str, Any]):
        super().__init__(
            message=f"Invalid PPT data: {issue}",
            error_code="INVALID_PPT_DATA",
            details=details_dict,
            recovery_hint="Verify slide structure and content"
        )


# =============================================================================
# DOCUMENT ANALYSIS ERRORS
# =============================================================================

class DocumentAnalysisError(AgentToolError):
    """Base exception for document analysis errors."""
    pass


class InvalidOperationError(DocumentAnalysisError):
    """Invalid operation requested."""
    
    def __init__(self, operation: str, valid_operations: list):
        super().__init__(
            message=f"Invalid operation: {operation}",
            error_code="INVALID_OPERATION",
            details={
                "requested_operation": operation,
                "valid_operations": valid_operations,
            },
            recovery_hint=f"Use one of: {', '.join(valid_operations)}"
        )


class MissingAnalysisDataError(DocumentAnalysisError):
    """Required data for analysis is missing."""
    
    def __init__(self, required_field: str):
        super().__init__(
            message=f"Missing required field: {required_field}",
            error_code="MISSING_DATA",
            details={"required_field": required_field},
            recovery_hint=f"Provide {required_field} in request"
        )


class PolicyViolationError(DocumentAnalysisError):
    """Policy compliance violation detected."""
    
    def __init__(self, violation_type: str, value: float, limit: float):
        super().__init__(
            message=f"Policy violation: {violation_type} ({value} exceeds {limit})",
            error_code="POLICY_VIOLATION",
            details={
                "violation_type": violation_type,
                "value": value,
                "limit": limit,
            }
        )


# =============================================================================
# DOCX HANDLER ERRORS
# =============================================================================

class DocxError(AgentToolError):
    """Base exception for DOCX processing errors."""
    pass


class CorruptedDocxError(DocxError):
    """DOCX file is corrupted or invalid."""
    
    def __init__(self, original_error: Exception):
        super().__init__(
            message=f"DOCX file corrupted: {str(original_error)}",
            error_code="CORRUPTED_DOCX",
            details={"error": str(original_error)},
            recovery_hint="Try opening file in Word to recover"
        )


# =============================================================================
# DOCUMENT STRUCTURE ERRORS
# =============================================================================

class InvalidDocumentStructureError(AgentToolError):
    """Document structure is invalid for document generation."""
    
    def __init__(self, issue: str):
        super().__init__(
            message=f"Invalid document structure: {issue}",
            error_code="INVALID_DOCUMENT_STRUCTURE",
            details={"issue": issue},
            recovery_hint="Verify document has title and at least one section with content"
        )


# =============================================================================
# DOXYGEN / DOCX PIPELINE ERRORS
# =============================================================================


class DoxygenPipelineError(DocxError):
    """Base for Doxygen + doxypypy + Pandoc DOCX pipeline failures."""

    pass


class DoxygenNotFoundError(DoxygenPipelineError):
    def __init__(self, executable: str):
        super().__init__(
            message=f"Doxygen executable not found or not runnable: {executable}",
            error_code="DOXYGEN_NOT_FOUND",
            details={"executable": executable},
            recovery_hint="Install Doxygen and set DOXYGEN_EXECUTABLE, or add it to PATH",
        )


class PandocNotFoundError(DoxygenPipelineError):
    def __init__(self, executable: str):
        super().__init__(
            message=f"Pandoc executable not found or not runnable: {executable}",
            error_code="PANDOC_NOT_FOUND",
            details={"executable": executable},
            recovery_hint="Install Pandoc and set PANDOC_EXECUTABLE, or add it to PATH",
        )


class DoxypypyNotFoundError(DoxygenPipelineError):
    def __init__(self, tried: str):
        super().__init__(
            message="doxypypy is not available (required for Python→Doxygen filtering)",
            error_code="DOXPYPY_NOT_FOUND",
            details={"hint": tried},
            recovery_hint="pip install doxypypy and ensure `doxypypy` is on PATH, or set DOXPYPY_EXECUTABLE",
        )


class DoxypypyFilterError(DoxygenPipelineError):
    def __init__(self, stderr: str, returncode: int):
        super().__init__(
            message="doxypypy failed while filtering Python report source",
            error_code="DOXPYPY_FILTER_ERROR",
            details={"returncode": returncode, "stderr": (stderr or "")[:4000]},
            recovery_hint="Check generated source encoding and Doxygen special characters in section text",
        )


class DoxygenGenerationError(DoxygenPipelineError):
    def __init__(self, stderr: str, returncode: int):
        super().__init__(
            message="Doxygen RTF generation failed",
            error_code="DOXYGEN_GENERATION_ERROR",
            details={"returncode": returncode, "stderr": (stderr or "")[:4000]},
            recovery_hint="Verify DOXYGEN_EXECUTABLE and inspect Doxygen stderr output",
        )


class RTFToDocxConversionError(DoxygenPipelineError):
    def __init__(self, stderr: str, returncode: int):
        super().__init__(
            message="Pandoc failed to convert RTF to DOCX",
            error_code="RTF_TO_DOCX_ERROR",
            details={"returncode": returncode, "stderr": (stderr or "")[:4000]},
            recovery_hint="Verify pandoc supports rtf→docx and RTF input is valid",
        )


# =============================================================================
# GENERIC ERRORS
# =============================================================================

class ValidationError(AgentToolError):
    """Data validation failed."""
    
    def __init__(self, field: str, issue: str):
        super().__init__(
            message=f"Validation failed for {field}: {issue}",
            error_code="VALIDATION_ERROR",
            details={"field": field, "issue": issue}
        )
