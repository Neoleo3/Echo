"""
Code Review Service
Provides AI-powered code review using LLM for quality, security, and best practices analysis
"""
import logging
from typing import Dict, Any, Optional
logger = logging.getLogger(__name__)

# try:
#     from langchain_core.messages import SystemMessage, HumanMessage
#     import langchain_openai
#     LANGCHAIN_AVAILABLE = True
# except ImportError as e:
#     LANGCHAIN_AVAILABLE = False
#     logger.error(f"LangChain dependency missing: {e}") = None
#     SystemMessage = None
#     HumanMessage = None

try:
    from langchain_core.messages import SystemMessage, HumanMessage
    import langchain_openai

    LANGCHAIN_AVAILABLE = True

except ImportError as e:
    LANGCHAIN_AVAILABLE = False

    SystemMessage = None
    HumanMessage = None

    logger.error(f"LangChain dependency missing: {e}")

from echolib.llm_resolver import resolve_and_build_llm_sync


# SUPPORTED_LANGUAGES = {
#     "python",
#     "javascript",
#     "typescript",
#     "java",
#     "go",
#     "rust",
#     "c++",
#     "c#"
# }

class CodeReviewService:
    """Service for AI-powered code review"""

    def __init__(self, user_id: Optional[str] = None):
        self.user_id = user_id
        self.llm = None

        if not LANGCHAIN_AVAILABLE:
            logger.warning("langchain_openai not installed. Code review will not work. Install with: pip install langchain-openai")
            return
        
    def _get_llm(self):
        if self.llm is None:
            logger.info("Initializing Code Reviewer LLM")

            try:
                    self.llm = resolve_and_build_llm_sync(
                        user_id=self.user_id,
                        component="code_reviewer",
                        temperature=0.2,
                        allow_platform_fallback=True,
                        framework="langchain",
                    )

                    logger.info("Code Reviewer LLM initialized successfully")

            except Exception as e:
                    logger.exception("Failed to initialize LLM")
                    raise RuntimeError(
                        f"Code Reviewer LLM initialization failed: {str(e)}"
                    )

        return self.llm
            

            # logger.info("Code Reviewer LLM initialized")
        # return self.llm

    def review_code(self, code: str, language: str = "python", focus_areas: Optional[str] = None) -> str:
        """
        Perform comprehensive code review

        Args:
            code: Code snippet to review
            language: Programming language (python, javascript, java, etc.)
            focus_areas: Specific areas to focus on (optional)

        Returns:
            Detailed code review with categorized feedback
        """
        if not LANGCHAIN_AVAILABLE:
            raise RuntimeError("Required LangChain dependencies are unavailable.")
        llm = self._get_llm()
        logger.info(f"review_code received code type: {type(code)}")
        logger.info(f"review_code received value: {code}")

        # if not code or not code.strip():
        #     raise ValueError("Code to review cannot be empty")
        # Handle cases where the whole request dict is passed as code

        # if isinstance(code, dict):
        #     logger.warning(
        #         "Received dict instead of string for code parameter. Extracting code field."
        #     )

        #     language = code.get("language", language)
        #     focus_areas = code.get("focus_areas", focus_areas)
        #     code = code.get("code", "")

        # if not isinstance(code, str):
        #     raise ValueError(
        #         f"Expected code to be a string but got {type(code).__name__}"
        #     )

        # if not code.strip():
        #     raise ValueError("Code to review cannot be empty")


        # language = (language or "code").strip().lower()

        logger.info(f"Received code parameter type: {type(code)}")

        # Handle tool executors that pass the entire payload as the first argument
        if isinstance(code, dict):
            logger.warning(
                "Received request payload as code argument. Extracting fields."
            )

            payload = code

            code = payload.get("code", "")
            language = payload.get("language", language)
            focus_areas = payload.get("focus_areas", focus_areas)

        if not isinstance(code, str):
            raise ValueError(
                f"Expected code to be string but got {type(code).__name__}"
            )

        if not code.strip():
            raise ValueError("Code to review cannot be empty")

        language = str(language or "code").strip().lower()

        try:
            # Build focus areas string if provided
            focus_section = ""
            if focus_areas:
                focus_section = f"\n\nPay special attention to: {focus_areas}"

            task_description = f"""
Review the following {language.upper()} code thoroughly and provide a comprehensive analysis.

CODE TO REVIEW:
```{language}
{code}
```
{focus_section}

Provide your review in the following structured format:

## 🎯 OVERVIEW
- Provide a brief 2-3 sentence summary of what the code does
- Overall code quality rating (1-10)

## 🔴 CRITICAL ISSUES (Must Fix)
- List any critical bugs, security vulnerabilities, or crashes
- Explain the impact and how to reproduce
- Provide specific fixes with code examples

## 🟡 WARNINGS (Should Fix)
- Logic errors or edge cases not handled
- Performance bottlenecks or inefficiencies
- Missing error handling or validation
- Anti-patterns or code smells

## 🟢 SUGGESTIONS (Nice to Have)
- Code readability improvements
- Better naming conventions
- Refactoring opportunities
- Design pattern recommendations

## 🛡️ SECURITY REVIEW
- SQL injection, XSS, or other injection vulnerabilities
- Insecure data handling (passwords, tokens, PII)
- Authentication/authorization issues
- Dependency vulnerabilities

## ⚡ PERFORMANCE ANALYSIS
- Time complexity issues (O(n²) where O(n) possible)
- Memory leaks or excessive memory usage
- Database query optimization opportunities
- Caching opportunities

## 📚 BEST PRACTICES
- Adherence to language-specific conventions (PEP 8, ESLint, etc.)
- Code organization and structure
- Documentation and comments quality
- Test coverage recommendations

## ✅ WHAT'S DONE WELL
- Highlight positive aspects of the code
- Good practices worth keeping
- Effective patterns used

## 🔧 REFACTORED CODE (if significant improvements needed)
- Provide an improved version of the code
- Explain key changes made

## 📊 SUMMARY SCORE
- Bugs & Correctness: X/10
- Security: X/10
- Performance: X/10
- Readability: X/10
- Maintainability: X/10
- Overall: X/10

Be thorough, constructive, and educational. Provide specific examples and actionable advice.
"""

            system_prompt = SystemMessage(
                content="""You are a distinguished Senior Software Architect and Code Review Expert with over 20 years of experience across multiple domains:

- Software Engineering Best Practices & Design Patterns
- Security Engineering & Vulnerability Assessment (OWASP Top 10, CVE analysis)
- Performance Optimization & Scalability
- Code Quality & Technical Debt Management
- Multiple Programming Languages & Frameworks

Your code reviews are:
✓ Thorough and systematic - you catch subtle bugs others miss
✓ Educational - you explain the "why" behind each suggestion
✓ Constructive - you balance criticism with positive reinforcement
✓ Actionable - you provide specific fixes with code examples
✓ Prioritized - you clearly distinguish critical vs. nice-to-have improvements

You have reviewed thousands of production codebases and mentored hundreds of developers. Your feedback has prevented countless production incidents and improved code quality across organizations.

Analyze code with the mindset of: "What could go wrong in production? How can this be better?"
"""
            )
            human_prompt = HumanMessage(content=task_description)

            logger.info(f"Performing code review for {language} code ({len(code)} characters)")
            # llm = self._get_llm()
            response = llm.invoke([system_prompt, human_prompt])

            logger.info("Code review completed successfully")
            return response.content

        except Exception as e:
            logger.error(f"Failed to perform code review: {str(e)}")
            raise

    def quick_review(self, code: str, language: str = "python") -> str:
        """
        Perform a quick, focused code review (faster, less detailed)

        Args:
            code: Code snippet to review
            language: Programming language

        Returns:
            Concise code review with key issues only
        """
        if not LANGCHAIN_AVAILABLE:
            raise RuntimeError("Required LangChain dependencies are unavailable.")
        llm = self._get_llm()

        # if not code or not code.strip():
        #     raise ValueError("Code to review cannot be empty")

        # if isinstance(code, dict):
        #     logger.warning(
        #         "Received dict instead of string for code parameter. Extracting code field."
        #     )

        #     language = code.get("language", language)
        #     code = code.get("code", "")

        # if not isinstance(code, str):
        #     raise ValueError(
        #         f"Expected code to be a string but got {type(code).__name__}"
        #     )

        # if not code.strip():
        #     raise ValueError("Code to review cannot be empty")

        # language = (language or "code").strip().lower()

        logger.info(f"Received code parameter type: {type(code)}")

        if isinstance(code, dict):
            logger.warning(
                "Received request payload as code argument. Extracting fields."
            )

            payload = code

            code = payload.get("code", "")
            language = payload.get("language", language)

        if not isinstance(code, str):
            raise ValueError(
                f"Expected code to be string but got {type(code).__name__}"
            )

        if not code.strip():
            raise ValueError("Code to review cannot be empty")

        language = str(language or "code").strip().lower()

        try:
            task_description = f"""
Perform a QUICK code review of this {language.upper()} code. Focus only on:
1. Critical bugs that will cause crashes or incorrect behavior
2. Security vulnerabilities (injection, auth issues, data leaks)
3. Major performance problems

CODE:
```{language}
{code}
```

Provide a concise review with:
- 🔴 Critical Issues (must fix)
- 🟡 Important Warnings (should fix)
- Overall assessment (1-2 sentences)

Be brief and direct. Only mention the most important issues.
"""

            system_prompt = SystemMessage(
                content="You are a senior code reviewer. Provide quick, focused feedback on critical issues only. Be concise and actionable."
            )
            human_prompt = HumanMessage(content=task_description)

            logger.info(f"Performing quick code review for {language} code")
            # llm = self._get_llm()
            response = llm.invoke([system_prompt, human_prompt])

            return response.content

        except Exception as e:
            logger.error(f"Failed to perform quick code review: {str(e)}")
            raise
