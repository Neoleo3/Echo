"""
ConvoBI Database Query tool package.

Generic wrapper between agent tools and the ConvoBI NLP-to-SQL engine.
Any database loaded into ConvoBI can be queried through this adapter.
"""

from .service import ConvoBIService

__version__ = "1.0"
__author__ = "EchoAI"

__all__ = ["ConvoBIService"]
