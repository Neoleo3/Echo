"""
ConvoBI Database Query Service
==============================
Invoke-only middleware between agent tools (CrewAI, workflows, Echo Agent)
and the ConvoBI LangGraph NLP-to-SQL agent.

The input contract mirrors ``POST /convobi/invoke``:
    - message
    - session_id (optional)
    - connection_id (optional) — DB connection ID from saved_db_connections.json
    - file_id (optional)

Output returns a minimal, agent-safe payload derived from
``invoke_convobi_agent()`` to avoid large context bloat.
"""

from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


def _get_langgraph_invoker():
    """
    Return the ``invoke_convobi_agent`` function from the LangGraph-based
    Convobi module, or None if not available.
    """
    try:
        from apps.convobi.main import invoke_convobi_agent
        return invoke_convobi_agent
    except Exception as exc:
        logger.debug("LangGraph invoke_convobi_agent not available: %s", exc)
        return None


class ConvoBIService:
    """
    Invoke-only adapter for the ConvoBI NLP-to-SQL engine.

    This tool accepts invoke-style inputs and returns a minimal subset
    of ConvoBI agent response fields.
    """

    def __init__(self):
        self._langgraph_invoke: Optional[Any] = None

    def _langgraph_invoker(self):
        if self._langgraph_invoke is None:
            self._langgraph_invoke = _get_langgraph_invoker()
        return self._langgraph_invoke

    def execute(self, input_data=None, **kwargs) -> Dict[str, Any]:
        """
        Main execution method invoked by the agent framework (ToolExecutor).

        Invoke-style input contract (matches POST /convobi/invoke):
          - message: str (required)
          - session_id: Optional[str]
          - connection_id: Optional[str] — DB connection ID from saved_db_connections.json
          - file_id: Optional[str]

        Accepts both positional dict and keyword arguments to remain
        compatible with every ToolExecutor calling convention.
        """
        if isinstance(input_data, dict):
            params = {**input_data, **kwargs}
        else:
            params = kwargs

        message = (params.get("message") or "").strip()
        connection_id = (params.get("connection_id") or "").strip() or None
        file_id = (params.get("file_id") or "").strip() or None
        session_id = (params.get("session_id") or "").strip() or None

        if not message:
            return {
                "success": False,
                "error": "Missing required parameter: message",
            }

        if connection_id and file_id:
            return {
                "success": False,
                "error": "Provide either connection_id or file_id, not both.",
            }

        invoker = self._langgraph_invoker()
        if invoker is None:
            return {
                "success": False,
                "error": "ConvoBI invoke agent is not available.",
            }

        try:
            cs = self._resolve_connection_string(connection_id=connection_id, file_id=file_id)
            if not cs:
                return {
                    "success": False,
                    "error": "No database connection string available",
                }

            result = invoker(
                question=message,
                connection_string=cs,
                session_id=session_id,
            )

            if isinstance(result, dict):
                return self._to_agent_safe_payload(result, session_id)

            return {
                "success": False,
                "error": "Invalid response from ConvoBI invoker",
            }
        except Exception as exc:
            logger.exception("ConvoBIService.invoke failed")
            return {
                "success": False,
                "error": f"ConvoBI invoke failed: {exc}",
                "session_id": session_id or "",
            }

    def _to_agent_safe_payload(self, result: Dict[str, Any], session_id: Optional[str]) -> Dict[str, Any]:
        """Return minimal fields useful to agents without large payload bloat."""
        return {
            "success": bool(result.get("success")),
            "response": result.get("response") or "",
            "summary": result.get("summary"),
            "sql": result.get("sql"),
            "row_count": result.get("row_count"),
            "columns": result.get("columns"),
            "execution_time_ms": result.get("execution_time_ms"),
            "confidence": result.get("confidence"),
            "session_id": result.get("session_id") or session_id or "",
            "error": result.get("error"),
        }

    def _resolve_connection_string(
        self,
        connection_id: Optional[str] = None,
        file_id: Optional[str] = None,
    ) -> Optional[str]:
        """Resolve connection_id or file_id to a connection string for the LangGraph agent."""
        try:
            from apps.convobi.main import _resolve_connection_string as convobi_resolve_connection_string
            cs = convobi_resolve_connection_string(connection_id=connection_id, file_id=file_id)
            if cs:
                return cs
        except Exception:
            pass
        return None
