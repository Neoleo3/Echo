"""
Unit tests for ConvoBI invoke-only tool service.
"""

import sys
import unittest
from unittest.mock import patch

from service import ConvoBIService


class TestConvoBIInvokeOnly(unittest.TestCase):
    """Validate invoke-only input contract and lean response mapping."""

    def setUp(self):
        self.service = ConvoBIService()

    def test_missing_message(self):
        result = self.service.execute({"connection_id": "conn-1"})
        self.assertFalse(result["success"])
        self.assertIn("message", result["error"].lower())

    def test_connection_and_file_mutually_exclusive(self):
        result = self.service.execute(
            {
                "message": "hello",
                "connection_id": "conn-1",
                "file_id": "file-1",
            }
        )
        self.assertFalse(result["success"])
        self.assertIn("either connection_id or file_id", result["error"].lower())

    def test_invoker_unavailable(self):
        with patch.object(ConvoBIService, "_langgraph_invoker", return_value=None):
            result = self.service.execute({"message": "test", "connection_id": "conn-1"})
        self.assertFalse(result["success"])
        self.assertIn("not available", result["error"].lower())

    def test_missing_connection_string(self):
        with patch.object(ConvoBIService, "_langgraph_invoker", return_value=lambda **_: {"success": True}), \
             patch.object(ConvoBIService, "_resolve_connection_string", return_value=None):
            result = self.service.execute({"message": "test", "connection_id": "conn-1"})

        self.assertFalse(result["success"])
        self.assertIn("connection string", result["error"].lower())

    def test_full_response_is_slimmed_for_agent_context(self):
        full_payload = {
            "success": True,
            "response": "There are 42 incidents.",
            "sql": "SELECT COUNT(*) AS count FROM incidents",
            "explanation": "Counted all incident records.",
            "data": [{"count": 42}],
            "row_count": 1,
            "columns": ["count"],
            "execution_time_ms": 123.4,
            "confidence": 0.92,
            "optimizations": ["Used aggregate pushdown"],
            "warnings": [],
            "error": None,
            "summary": "42 incidents total.",
            "visualization_html": "<div>chart</div>",
            "session_id": "s-1",
            "tables_used": {"incidents": {}},
            "agent_steps": [{"event": "tool_call"}],
        }

        with patch.object(ConvoBIService, "_resolve_connection_string", return_value="sqlite:///tmp.db"):
            with patch.object(ConvoBIService, "_langgraph_invoker") as mock_invoker:
                mock_invoker.return_value = lambda **kwargs: full_payload
                result = self.service.execute(
                    {
                        "message": "How many incidents?",
                        "session_id": "s-1",
                        "connection_id": "conn-1",
                    }
                )

        self.assertTrue(result["success"])
        self.assertEqual(result["response"], full_payload["response"])
        self.assertEqual(result["sql"], full_payload["sql"])
        self.assertEqual(result["summary"], full_payload["summary"])
        self.assertEqual(result["row_count"], full_payload["row_count"])
        self.assertEqual(result["columns"], full_payload["columns"])
        self.assertEqual(result["session_id"], full_payload["session_id"])
        self.assertNotIn("data", result)
        self.assertNotIn("agent_steps", result)
        self.assertNotIn("tables_used", result)
        self.assertNotIn("visualization_html", result)

    def test_invoker_is_called_with_invoke_arguments(self):
        captured = {}

        def fake_invoker(**kwargs):
            captured.update(kwargs)
            return {"success": True, "response": "ok"}

        with patch.object(ConvoBIService, "_resolve_connection_string", return_value="sqlite:///tmp.db"):
            with patch.object(ConvoBIService, "_langgraph_invoker", return_value=fake_invoker):
                _ = self.service.execute(
                    {
                        "message": "show me top priorities",
                        "session_id": "abc",
                        "file_id": "file-xyz",
                    }
                )

        self.assertEqual(captured.get("question"), "show me top priorities")
        self.assertEqual(captured.get("session_id"), "abc")
        self.assertEqual(captured.get("connection_string"), "sqlite:///tmp.db")


class TestServiceInitialization(unittest.TestCase):
    """Test service instantiation."""

    def test_service_creates(self):
        service = ConvoBIService()
        self.assertIsNotNone(service)


def run_tests():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTests(loader.loadTestsFromTestCase(TestConvoBIInvokeOnly))
    suite.addTests(loader.loadTestsFromTestCase(TestServiceInitialization))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("=" * 70)

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
