"""
Performance Review Code Execution Tool Package
For generating insights from annual performance review data
"""

from .service import CodeExecutionService, calculate
from .analysis_templates import PerformanceAnalyzer

__version__ = "1.0.0"
__all__ = ["CodeExecutionService", "calculate", "PerformanceAnalyzer"]
