"""
Test Suite for Performance Review Code Execution Tool
Run with: python test_tool.py
"""

import unittest
import json
from service import CodeExecutionService
from analysis_templates import PerformanceAnalyzer


class TestCodeExecutionService(unittest.TestCase):
    """Test cases for CodeExecutionService"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.service = CodeExecutionService()
        self.sample_data = {
            "employee_id": "TEST001",
            "review_period": "2025-Q4",
            "self_assessment": {
                "overall_rating": 4.5,
                "strengths": ["Technical skills", "Communication"],
                "weaknesses": ["Time management"],
                "achievements": ["Project completion"],
                "skills": {
                    "technical": 4.5,
                    "communication": 4.0
                }
            },
            "peer_feedback": [
                {
                    "peer_id": "PEER001",
                    "rating": 4.0,
                    "strengths": ["Technical skills"],
                    "areas_for_improvement": ["Time management"]
                }
            ],
            "manager_review": {
                "overall_rating": 4.0,
                "strengths": ["Technical skills"],
                "areas_for_improvement": ["Time management"],
                "skills": {
                    "technical": 4.0,
                    "communication": 3.5
                }
            },
            "goals": [
                {
                    "title": "Complete certification",
                    "status": "completed",
                    "completion_percentage": 100
                }
            ]
        }
    
    def test_basic_execution(self):
        """Test basic code execution"""
        code = """
insights = {
    "test": "success",
    "value": 42
}
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertEqual(result['insights']['test'], 'success')
        self.assertEqual(result['insights']['value'], 42)
    
    def test_access_to_review_data(self):
        """Test that code can access review_data"""
        code = """
insights = {
    "employee_id": review_data['employee_id'],
    "self_rating": review_data['self_assessment']['overall_rating']
}
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertEqual(result['insights']['employee_id'], 'TEST001')
        self.assertEqual(result['insights']['self_rating'], 4.5)
    
    def test_numpy_availability(self):
        """Test that numpy is available"""
        code = """
import numpy as np
insights = {
    "numpy_available": True,
    "mean": float(np.mean([1, 2, 3, 4, 5]))
}
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertTrue(result['insights']['numpy_available'])
        self.assertEqual(result['insights']['mean'], 3.0)
    
    def test_error_handling(self):
        """Test error handling for invalid code"""
        code = """
insights = undefined_variable
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'error')
        self.assertIn('NameError', result['error'])
    
    def test_print_output_capture(self):
        """Test that print statements are captured"""
        code = """
print("Hello from code execution")
insights = {"status": "printed"}
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertIn('Hello from code execution', result['output'])
    
    def test_json_output_format(self):
        """Test JSON output format"""
        code = """
insights = {"format": "json"}
"""
        result = self.service.execute_analysis(code, self.sample_data, output_format="json")
        
        self.assertIsInstance(result['insights'], dict)
    
    def test_markdown_output_format(self):
        """Test Markdown output format"""
        code = """
insights = {"title": "Test", "value": "data"}
"""
        result = self.service.execute_analysis(code, self.sample_data, output_format="markdown")
        
        self.assertIsInstance(result['insights'], str)
        self.assertIn('# Performance Review Insights', result['insights'])


class TestPerformanceAnalyzer(unittest.TestCase):
    """Test cases for PerformanceAnalyzer templates"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.sample_data = {
            "employee_id": "TEST001",
            "review_period": "2025-Q4",
            "self_assessment": {
                "overall_rating": 4.5,
                "strengths": ["Technical skills", "Communication"],
                "weaknesses": ["Time management"],
                "achievements": ["Project completion", "Team leadership"],
                "skills": {
                    "technical": 4.5,
                    "communication": 4.0,
                    "leadership": 3.5
                }
            },
            "peer_feedback": [
                {
                    "peer_id": "PEER001",
                    "rating": 4.0,
                    "strengths": ["Technical skills"],
                    "areas_for_improvement": ["Time management"]
                },
                {
                    "peer_id": "PEER002",
                    "rating": 4.5,
                    "strengths": ["Communication"],
                    "areas_for_improvement": ["Delegation"]
                }
            ],
            "manager_review": {
                "overall_rating": 4.0,
                "strengths": ["Technical skills", "Reliability"],
                "areas_for_improvement": ["Time management", "Leadership"],
                "skills": {
                    "technical": 4.0,
                    "communication": 3.5,
                    "leadership": 3.0
                }
            },
            "goals": [
                {
                    "title": "Complete certification",
                    "status": "completed",
                    "completion_percentage": 100
                },
                {
                    "title": "Lead project",
                    "status": "in_progress",
                    "completion_percentage": 60
                }
            ]
        }
    
    def test_compare_perspectives(self):
        """Test perspective comparison analysis"""
        result = PerformanceAnalyzer.compare_perspectives(self.sample_data)
        
        self.assertIn('self_vs_manager', result)
        self.assertIn('self_vs_peers', result)
        self.assertIn('manager_vs_peers', result)
        
        # Check that ratings are calculated
        self.assertEqual(result['self_vs_manager']['self_rating'], 4.5)
        self.assertEqual(result['self_vs_manager']['manager_rating'], 4.0)
    
    def test_sentiment_analysis(self):
        """Test sentiment analysis"""
        result = PerformanceAnalyzer.sentiment_analysis(self.sample_data)
        
        self.assertIn('self_assessment_tone', result)
        self.assertIn('peer_feedback_tone', result)
        self.assertIn('manager_review_tone', result)
        self.assertIn('overall_sentiment', result)
        
        # Check that tones are valid values
        valid_tones = ['positive', 'negative', 'neutral', 'mixed']
        self.assertIn(result['overall_sentiment'], valid_tones)
    
    def test_gap_analysis(self):
        """Test gap analysis"""
        result = PerformanceAnalyzer.gap_analysis(self.sample_data)
        
        self.assertIn('perception_gaps', result)
        self.assertIn('skill_gaps', result)
        self.assertIn('recommendations', result)
        
        # Check perception gaps structure
        if result['perception_gaps']:
            gap = result['perception_gaps'][0]
            self.assertIn('skill', gap)
            self.assertIn('self_rating', gap)
            self.assertIn('manager_rating', gap)
    
    def test_identify_strengths_weaknesses(self):
        """Test strengths and weaknesses identification"""
        result = PerformanceAnalyzer.identify_strengths_weaknesses(self.sample_data)
        
        self.assertIn('top_strengths', result)
        self.assertIn('areas_for_improvement', result)
        self.assertIn('consistent_themes', result)
        
        # Check that "Technical skills" appears as a strength (mentioned multiple times)
        strengths_list = [s['strength'] for s in result['top_strengths']]
        self.assertIn('Technical skills', strengths_list)
    
    def test_goal_alignment_analysis(self):
        """Test goal alignment analysis"""
        result = PerformanceAnalyzer.goal_alignment_analysis(self.sample_data)
        
        self.assertIn('goal_completion_rate', result)
        self.assertIn('completed_goals', result)
        self.assertIn('in_progress_goals', result)
        self.assertIn('alignment_with_review', result)
        
        # Check completion rate calculation
        self.assertEqual(result['goal_completion_rate'], 50.0)  # 1 of 2 completed
        self.assertEqual(len(result['completed_goals']), 1)
        self.assertEqual(len(result['in_progress_goals']), 1)
    
    def test_generate_summary(self):
        """Test summary generation"""
        result = PerformanceAnalyzer.generate_summary(self.sample_data)
        
        self.assertIn('employee_id', result)
        self.assertIn('overall_performance', result)
        self.assertIn('key_achievements', result)
        self.assertIn('priority_development_areas', result)
        
        # Check employee ID
        self.assertEqual(result['employee_id'], 'TEST001')
        
        # Check that overall performance is determined
        self.assertIn(result['overall_performance'], 
                     ['Exceptional', 'Exceeds Expectations', 'Meets Expectations', 'Needs Improvement'])
    
    def test_comprehensive_analysis(self):
        """Test comprehensive analysis"""
        result = PerformanceAnalyzer.comprehensive_analysis(self.sample_data)
        
        # Check that all analysis types are included
        self.assertIn('comparison_analysis', result)
        self.assertIn('sentiment_analysis', result)
        self.assertIn('gap_analysis', result)
        self.assertIn('strengths_weaknesses', result)
        self.assertIn('goal_alignment', result)
        self.assertIn('summary', result)
    
    def test_empty_peer_feedback(self):
        """Test handling of empty peer feedback"""
        data = self.sample_data.copy()
        data['peer_feedback'] = []
        
        result = PerformanceAnalyzer.compare_perspectives(data)
        
        # Should handle gracefully without errors
        self.assertIsInstance(result, dict)
    
    def test_missing_fields(self):
        """Test handling of missing optional fields"""
        minimal_data = {
            "employee_id": "TEST001",
            "self_assessment": {"overall_rating": 4.0},
            "manager_review": {"overall_rating": 4.0},
            "peer_feedback": [],
            "goals": []
        }
        
        # Should not raise errors
        try:
            result = PerformanceAnalyzer.comprehensive_analysis(minimal_data)
            self.assertIsInstance(result, dict)
        except Exception as e:
            self.fail(f"Comprehensive analysis failed with minimal data: {e}")


class TestIntegration(unittest.TestCase):
    """Integration tests"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.service = CodeExecutionService()
        self.sample_data = {
            "employee_id": "INT001",
            "self_assessment": {
                "overall_rating": 4.0,
                "skills": {"technical": 4.0}
            },
            "peer_feedback": [{"rating": 4.0}],
            "manager_review": {
                "overall_rating": 3.5,
                "skills": {"technical": 3.5}
            },
            "goals": [{"status": "completed"}]
        }
    
    def test_comprehensive_via_service(self):
        """Test running comprehensive analysis through service"""
        code = """
from analysis_templates import PerformanceAnalyzer
insights = PerformanceAnalyzer.comprehensive_analysis(review_data)
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertIn('summary', result['insights'])
        self.assertIn('comparison_analysis', result['insights'])
    
    def test_custom_analysis_with_templates(self):
        """Test combining custom code with templates"""
        code = """
from analysis_templates import PerformanceAnalyzer

# Run gap analysis
gap = PerformanceAnalyzer.gap_analysis(review_data)

# Add custom metric
custom_score = (review_data['self_assessment']['overall_rating'] + 
                review_data['manager_review']['overall_rating']) / 2

insights = {
    "gap_analysis": gap,
    "average_rating": round(custom_score, 2)
}
"""
        result = self.service.execute_analysis(code, self.sample_data)
        
        self.assertEqual(result['execution_status'], 'success')
        self.assertIn('gap_analysis', result['insights'])
        self.assertIn('average_rating', result['insights'])


def run_tests():
    """Run all tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestCodeExecutionService))
    suite.addTests(loader.loadTestsFromTestCase(TestPerformanceAnalyzer))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
