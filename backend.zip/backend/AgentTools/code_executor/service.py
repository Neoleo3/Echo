"""
Code execution tool -- runs Python an agent wrote, in the sandbox.

WHAT: Executes model-authored Python against caller-supplied data and returns
      what it produced.
WHY:  This module claimed to be sandboxed and was not. It called
      ``exec(code, {"__builtins__": __builtins__, ...})`` inside the API
      process. The ``allowed_modules`` dictionary it injected restricted
      nothing -- full builtins carry ``__import__``, ``open``, ``eval`` and
      ``compile``, so the code could reach anything the service account could,
      including ``os.environ``, which on this deployment holds the database
      URL, the JWT secret, the storage connection string and the Key Vault
      credential. The ``code`` argument is written by a language model, so the
      contents were governed by whatever text reached the prompt.

      Execution now goes through ``apps.sandbox``: a separate interpreter, an
      allow-listed environment, a temporary working directory, a wall-clock
      timeout and POSIX resource limits.

The public contract is unchanged -- ``execute_analysis`` still returns
``insights`` / ``execution_status`` / ``output`` / ``error``, and the ``json``,
``markdown``, ``html`` and ``text`` output formats still work -- so the tool
manifest, ``DocumentAnalysisService`` and any agent already holding this tool
are unaffected.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Imported inside the sandbox child, not here: the code an agent writes usually
# expects these names, and stating them keeps the generated code honest about
# what is available.
PREAMBLE = (
    "import json, math, statistics, collections\n"
    "from datetime import datetime, date, timedelta\n"
    "try:\n"
    "    import numpy as np\n"
    "    import pandas as pd\n"
    "except ImportError:\n"
    "    np = pd = None\n"
)

AVAILABLE_MODULES = ("json", "math", "statistics", "collections", "datetime", "numpy", "pandas")


class CodeExecutionService:
    """Executes Python supplied by an agent and formats what it returns."""

    def __init__(self, timeout_seconds: Optional[int] = None):
        self.timeout_seconds = timeout_seconds
        self.available_modules = AVAILABLE_MODULES

    def execute_analysis(
        self,
        code: str,
        review_data: Optional[Dict[str, Any]] = None,
        analysis_type: str = "comprehensive",
        output_format: str = "json",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Run ``code`` with ``review_data`` bound, and return its insights.

        INPUT: Python source; a data dictionary bound as ``review_data``; the
               analysis label bound as ``analysis_type``; the output format.
        OUTPUT: ``{insights, execution_status, output, error}``. A failure is
                reported, never raised, so the agent receives the traceback and
                can correct its own code on the next turn -- which is the whole
                value of a code tool.
        """
        if not code or not code.strip():
            return {
                "insights": {},
                "execution_status": "error",
                "output": "",
                "error": "No code provided.",
            }

        from apps.sandbox import run_python

        result = run_python(
            f"{PREAMBLE}\n{code}",
            variables={
                "review_data": review_data or {},
                "analysis_type": analysis_type,
            },
            timeout=self.timeout_seconds,
            label="agent_code_executor",
        )

        if not result.success:
            logger.info(
                "Agent code execution failed (%s)",
                "timeout" if result.timed_out else "error",
            )
            return {
                "insights": {},
                "execution_status": "error",
                "output": result.stdout,
                "error": result.error or "Execution failed.",
            }

        insights = self._insights_from(result)
        return {
            "insights": self._format_insights(insights, output_format),
            "execution_status": "success",
            "output": result.stdout,
            "error": None,
        }

    # ------------------------------------------------------------------
    # Result shaping
    # ------------------------------------------------------------------

    def _insights_from(self, result: Any) -> Any:
        """
        Pick the value the code meant as its answer.

        ``insights`` first, then ``result``, matching the two names this tool
        has always documented; stdout is the fallback so code that only prints
        still returns something.
        """
        variables = result.variables or {}
        if "insights" in variables:
            return variables["insights"]
        if "result" in variables:
            return variables["result"]
        if result.output not in (None, ""):
            return result.output
        return {}

    def _format_insights(self, insights: Any, output_format: str) -> Any:
        """Format insights according to the requested output format."""
        if output_format == "markdown":
            return self._to_markdown(insights)
        if output_format == "html":
            return self._to_html(insights)
        if output_format == "text":
            return str(insights)
        return insights

    def _to_markdown(self, insights: Any) -> str:
        """Render insights as markdown."""
        if not isinstance(insights, dict):
            return str(insights)

        lines = ["# Insights", ""]
        for key, value in insights.items():
            lines.append(f"## {str(key).replace('_', ' ').title()}")
            lines.append("")
            if isinstance(value, dict):
                lines.extend(f"- **{k}**: {v}" for k, v in value.items())
            elif isinstance(value, list):
                lines.extend(f"- {item}" for item in value)
            else:
                lines.append(str(value))
            lines.append("")
        return "\n".join(lines)

    def _to_html(self, insights: Any) -> str:
        """Render insights as HTML."""
        from html import escape

        if not isinstance(insights, dict):
            return f"<p>{escape(str(insights))}</p>"

        parts = ["<div class='insights'>", "<h1>Insights</h1>"]
        for key, value in insights.items():
            parts.append(f"<h2>{escape(str(key).replace('_', ' ').title())}</h2>")
            if isinstance(value, dict):
                parts.append("<ul>")
                parts.extend(
                    f"<li><strong>{escape(str(k))}:</strong> {escape(str(v))}</li>"
                    for k, v in value.items()
                )
                parts.append("</ul>")
            elif isinstance(value, list):
                parts.append("<ul>")
                parts.extend(f"<li>{escape(str(item))}</li>" for item in value)
                parts.append("</ul>")
            else:
                parts.append(f"<p>{escape(str(value))}</p>")
        parts.append("</div>")
        return "\n".join(parts)


def calculate(
    code: str,
    review_data: Optional[Dict[str, Any]] = None,
    analysis_type: str = "comprehensive",
    output_format: str = "json",
) -> Dict[str, Any]:
    """Convenience wrapper kept for existing callers."""
    return CodeExecutionService().execute_analysis(
        code, review_data, analysis_type, output_format
    )


__all__ = ["AVAILABLE_MODULES", "CodeExecutionService", "PREAMBLE", "calculate"]
