"""
Analysis Templates for Performance Review Insights
Pre-built analysis functions for common performance review scenarios
"""

from typing import Dict, Any, List
import statistics


class PerformanceAnalyzer:
    """Pre-built analysis templates for performance reviews"""
    
    @staticmethod
    def comprehensive_analysis(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform comprehensive analysis of all review components
        """
        insights = {
            "comparison_analysis": PerformanceAnalyzer.compare_perspectives(review_data),
            "sentiment_analysis": PerformanceAnalyzer.sentiment_analysis(review_data),
            "gap_analysis": PerformanceAnalyzer.gap_analysis(review_data),
            "strengths_weaknesses": PerformanceAnalyzer.identify_strengths_weaknesses(review_data),
            "goal_alignment": PerformanceAnalyzer.goal_alignment_analysis(review_data),
            "summary": PerformanceAnalyzer.generate_summary(review_data)
        }
        return insights
    
    @staticmethod
    def compare_perspectives(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compare self-assessment, peer feedback, and manager review
        """
        comparison = {
            "self_vs_manager": {},
            "self_vs_peers": {},
            "manager_vs_peers": {},
            "consensus_areas": [],
            "divergent_areas": []
        }
        
        # Extract ratings if available
        self_rating = review_data.get('self_assessment', {}).get('overall_rating', 0)
        manager_rating = review_data.get('manager_review', {}).get('overall_rating', 0)
        
        peer_ratings = []
        for peer in review_data.get('peer_feedback', []):
            if 'rating' in peer:
                peer_ratings.append(peer['rating'])
        
        avg_peer_rating = statistics.mean(peer_ratings) if peer_ratings else 0
        
        # Calculate differences
        if self_rating and manager_rating:
            comparison['self_vs_manager'] = {
                "difference": round(self_rating - manager_rating, 2),
                "self_rating": self_rating,
                "manager_rating": manager_rating,
                "alignment": "high" if abs(self_rating - manager_rating) < 0.5 else "moderate" if abs(self_rating - manager_rating) < 1.0 else "low"
            }
        
        if self_rating and avg_peer_rating:
            comparison['self_vs_peers'] = {
                "difference": round(self_rating - avg_peer_rating, 2),
                "self_rating": self_rating,
                "avg_peer_rating": round(avg_peer_rating, 2),
                "alignment": "high" if abs(self_rating - avg_peer_rating) < 0.5 else "moderate" if abs(self_rating - avg_peer_rating) < 1.0 else "low"
            }
        
        if manager_rating and avg_peer_rating:
            comparison['manager_vs_peers'] = {
                "difference": round(manager_rating - avg_peer_rating, 2),
                "manager_rating": manager_rating,
                "avg_peer_rating": round(avg_peer_rating, 2),
                "alignment": "high" if abs(manager_rating - avg_peer_rating) < 0.5 else "moderate" if abs(manager_rating - avg_peer_rating) < 1.0 else "low"
            }
        
        return comparison
    
    @staticmethod
    def sentiment_analysis(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze sentiment across different review sources
        """
        sentiment = {
            "self_assessment_tone": "neutral",
            "peer_feedback_tone": "neutral",
            "manager_review_tone": "neutral",
            "overall_sentiment": "neutral"
        }
        
        # Simple keyword-based sentiment analysis
        positive_keywords = ['excellent', 'outstanding', 'exceptional', 'strong', 'great', 'impressive', 'exceeded']
        negative_keywords = ['needs improvement', 'below', 'weak', 'lacking', 'insufficient', 'poor']
        
        # Analyze self-assessment
        self_text = str(review_data.get('self_assessment', {})).lower()
        self_positive = sum(1 for kw in positive_keywords if kw in self_text)
        self_negative = sum(1 for kw in negative_keywords if kw in self_text)
        sentiment['self_assessment_tone'] = "positive" if self_positive > self_negative else "negative" if self_negative > self_positive else "neutral"
        
        # Analyze manager review
        manager_text = str(review_data.get('manager_review', {})).lower()
        manager_positive = sum(1 for kw in positive_keywords if kw in manager_text)
        manager_negative = sum(1 for kw in negative_keywords if kw in manager_text)
        sentiment['manager_review_tone'] = "positive" if manager_positive > manager_negative else "negative" if manager_negative > manager_positive else "neutral"
        
        # Analyze peer feedback
        peer_positive = 0
        peer_negative = 0
        for peer in review_data.get('peer_feedback', []):
            peer_text = str(peer).lower()
            peer_positive += sum(1 for kw in positive_keywords if kw in peer_text)
            peer_negative += sum(1 for kw in negative_keywords if kw in peer_text)
        
        sentiment['peer_feedback_tone'] = "positive" if peer_positive > peer_negative else "negative" if peer_negative > peer_positive else "neutral"
        
        # Overall sentiment
        positive_count = sum(1 for tone in [sentiment['self_assessment_tone'], sentiment['peer_feedback_tone'], sentiment['manager_review_tone']] if tone == "positive")
        negative_count = sum(1 for tone in [sentiment['self_assessment_tone'], sentiment['peer_feedback_tone'], sentiment['manager_review_tone']] if tone == "negative")
        
        sentiment['overall_sentiment'] = "positive" if positive_count > negative_count else "negative" if negative_count > positive_count else "mixed"
        
        return sentiment
    
    @staticmethod
    def gap_analysis(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Identify gaps between self-perception and others' perception
        """
        gaps = {
            "perception_gaps": [],
            "skill_gaps": [],
            "expectation_gaps": [],
            "recommendations": []
        }
        
        self_skills = review_data.get('self_assessment', {}).get('skills', {})
        manager_skills = review_data.get('manager_review', {}).get('skills', {})
        
        # Compare skill assessments
        for skill, self_rating in self_skills.items():
            manager_rating = manager_skills.get(skill, 0)
            if abs(self_rating - manager_rating) > 1.0:
                gap_type = "overestimation" if self_rating > manager_rating else "underestimation"
                gaps['perception_gaps'].append({
                    "skill": skill,
                    "self_rating": self_rating,
                    "manager_rating": manager_rating,
                    "gap": round(self_rating - manager_rating, 2),
                    "type": gap_type
                })
        
        # Identify skill gaps from manager feedback
        for skill, rating in manager_skills.items():
            if rating < 3.0:  # Assuming 5-point scale
                gaps['skill_gaps'].append({
                    "skill": skill,
                    "current_rating": rating,
                    "target_rating": 4.0,
                    "gap": round(4.0 - rating, 2)
                })
        
        # Generate recommendations
        if gaps['perception_gaps']:
            gaps['recommendations'].append("Schedule calibration session with manager to align on skill assessments")
        if gaps['skill_gaps']:
            gaps['recommendations'].append("Create development plan for identified skill gaps")
        
        return gaps
    
    @staticmethod
    def identify_strengths_weaknesses(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Identify key strengths and areas for improvement
        """
        analysis = {
            "top_strengths": [],
            "areas_for_improvement": [],
            "consistent_themes": [],
            "action_items": []
        }
        
        # Collect all mentioned strengths and weaknesses
        all_strengths = []
        all_weaknesses = []
        
        # From self-assessment
        all_strengths.extend(review_data.get('self_assessment', {}).get('strengths', []))
        all_weaknesses.extend(review_data.get('self_assessment', {}).get('weaknesses', []))
        
        # From manager review
        all_strengths.extend(review_data.get('manager_review', {}).get('strengths', []))
        all_weaknesses.extend(review_data.get('manager_review', {}).get('areas_for_improvement', []))
        
        # From peer feedback
        for peer in review_data.get('peer_feedback', []):
            all_strengths.extend(peer.get('strengths', []))
            all_weaknesses.extend(peer.get('areas_for_improvement', []))
        
        # Identify most frequently mentioned items
        from collections import Counter
        strength_counts = Counter(all_strengths)
        weakness_counts = Counter(all_weaknesses)
        
        analysis['top_strengths'] = [{"strength": s, "mentions": c} for s, c in strength_counts.most_common(5)]
        analysis['areas_for_improvement'] = [{"area": a, "mentions": c} for a, c in weakness_counts.most_common(5)]
        
        # Identify consistent themes (mentioned by multiple sources)
        analysis['consistent_themes'] = [s for s, c in strength_counts.items() if c >= 2]
        
        # Generate action items
        for area, count in weakness_counts.most_common(3):
            analysis['action_items'].append(f"Develop improvement plan for: {area}")
        
        return analysis
    
    @staticmethod
    def goal_alignment_analysis(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze goal achievement and alignment with performance
        """
        goal_analysis = {
            "goal_completion_rate": 0.0,
            "completed_goals": [],
            "in_progress_goals": [],
            "not_started_goals": [],
            "alignment_with_review": "unknown",
            "recommendations": []
        }
        
        goals = review_data.get('goals', [])
        
        if not goals:
            return goal_analysis
        
        completed = 0
        in_progress = 0
        not_started = 0
        
        for goal in goals:
            status = goal.get('status', 'unknown').lower()
            
            if status in ['completed', 'achieved', 'done']:
                completed += 1
                goal_analysis['completed_goals'].append(goal.get('title', 'Unnamed goal'))
            elif status in ['in_progress', 'ongoing', 'active']:
                in_progress += 1
                goal_analysis['in_progress_goals'].append(goal.get('title', 'Unnamed goal'))
            else:
                not_started += 1
                goal_analysis['not_started_goals'].append(goal.get('title', 'Unnamed goal'))
        
        total_goals = len(goals)
        goal_analysis['goal_completion_rate'] = round((completed / total_goals * 100), 2) if total_goals > 0 else 0.0
        
        # Check alignment with overall performance
        manager_rating = review_data.get('manager_review', {}).get('overall_rating', 0)
        
        if manager_rating >= 4.0 and goal_analysis['goal_completion_rate'] >= 80:
            goal_analysis['alignment_with_review'] = "high"
        elif manager_rating >= 3.0 and goal_analysis['goal_completion_rate'] >= 60:
            goal_analysis['alignment_with_review'] = "moderate"
        else:
            goal_analysis['alignment_with_review'] = "low"
        
        # Generate recommendations
        if goal_analysis['goal_completion_rate'] < 70:
            goal_analysis['recommendations'].append("Focus on completing in-progress goals")
        if goal_analysis['not_started_goals']:
            goal_analysis['recommendations'].append("Prioritize or reassess not-started goals")
        
        return goal_analysis
    
    @staticmethod
    def generate_summary(review_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate executive summary of the performance review
        """
        summary = {
            "employee_id": review_data.get('employee_id', 'Unknown'),
            "review_period": review_data.get('review_period', 'Not specified'),
            "overall_performance": "Not rated",
            "key_achievements": [],
            "priority_development_areas": [],
            "next_steps": []
        }
        
        # Determine overall performance
        manager_rating = review_data.get('manager_review', {}).get('overall_rating', 0)
        
        if manager_rating >= 4.5:
            summary['overall_performance'] = "Exceptional"
        elif manager_rating >= 4.0:
            summary['overall_performance'] = "Exceeds Expectations"
        elif manager_rating >= 3.0:
            summary['overall_performance'] = "Meets Expectations"
        elif manager_rating > 0:
            summary['overall_performance'] = "Needs Improvement"
        
        # Extract key achievements
        achievements = review_data.get('self_assessment', {}).get('achievements', [])
        summary['key_achievements'] = achievements[:3] if achievements else []
        
        # Priority development areas
        weaknesses = review_data.get('manager_review', {}).get('areas_for_improvement', [])
        summary['priority_development_areas'] = weaknesses[:3] if weaknesses else []
        
        # Next steps
        summary['next_steps'] = [
            "Review and discuss performance insights with manager",
            "Create development plan for priority areas",
            "Set goals for next review period"
        ]
        
        return summary
