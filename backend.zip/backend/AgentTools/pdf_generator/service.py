# """
# PDF (.pdf) report generator tool - KPMG-branded.

# Mirrors docx_generator: accepts title + sections (heading/body/table) and produces
# a downloadable, KPMG-branded PDF via fpdf2. Emits a [GENERATED_FILE:...] marker so the
# existing download pipeline (skill_executor / workflow generated_file_links) turns it into
# a "Click here to download" link.
# """

# from __future__ import annotations

# import logging
# import os
# import re
# import uuid
# from io import BytesIO
# from typing import Any, Dict, List

# from echolib.branding import KPMG_BLUE_RGB as _KPMG_BLUE_RGB
# from echolib.branding import resolve_kpmg_logo as _resolve_kpmg_logo

# logger = logging.getLogger(__name__)


# TOOL_DEFINITION = {
#     "tool_id": "tool_pdf_generator",
#     "name": "PDF Document Generator",
#     "description": (
#         "Creates a KPMG-branded PDF (.pdf) document. RULES: 1) Call file_reader FIRST for "
#         "every uploaded PDF before calling this tool. 2) Call this tool EXACTLY ONCE with "
#         "ALL sections - never split into multiple calls. 3) Every section needs a "
#         "descriptive heading. 4) Use tables for comparative data. Returns a downloadable "
#         "file path."
#     ),
#     "input_schema": {
#         "type": "object",
#         "properties": {
#             "title": {"type": "string", "description": "Document title (shown in the document)"},
#             "sections": {
#                 "type": "array",
#                 "description": "Ordered sections",
#                 "items": {
#                     "type": "object",
#                     "properties": {
#                         "heading": {"type": "string", "description": "Section heading"},
#                         "body": {"type": "string", "description": "Narrative paragraphs"},
#                         "table": {
#                             "type": "object",
#                             "properties": {
#                                 "headers": {"type": "array", "items": {"type": "string"}},
#                                 "rows": {"type": "array", "items": {"type": "array"}},
#                             },
#                         },
#                     },
#                     "required": [],
#                 },
#             },
#         },
#         "required": ["title", "sections"],
#     },
#     "capabilities": ["pdf_generation", "pdf_export"],
# }


# def _safe_pdf_filename(title: str) -> str:
#     raw = (title or "").strip() or "Report"
#     slug = "".join(c if c.isalnum() or c in " -_" else " " for c in raw)
#     slug = re.sub(r"\s+", " ", slug).strip(" ._")[:100] or "Report"
#     if not slug.lower().endswith(".pdf"):
#         slug = f"{slug}.pdf"
#     return slug


# class _BrandedPDF:
#     """Builds a KPMG-branded fpdf2 document. Branding failures never raise."""

#     def __init__(self, title: str):
#         from fpdf import FPDF

#         class _Doc(FPDF):
#             def __init__(self, logo: str | None, doc_title: str):
#                 super().__init__()
#                 self._logo = logo
#                 self._title = doc_title

#             def header(self):
#                 if self._logo:
#                     try:
#                         self.image(self._logo, x=self.w - 42, y=8, w=32)
#                     except Exception:
#                         logger.exception("KPMG header logo could not be added to PDF")
#                 self.set_draw_color(*_KPMG_BLUE_RGB)
#                 self.set_line_width(0.6)
#                 self.line(10, 26, self.w - 10, 26)
#                 self.set_y(30)

#             def footer(self):
#                 self.set_y(-15)
#                 self.set_font("Helvetica", "I", 8)
#                 self.set_text_color(128, 128, 128)
#                 self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

#         logo = None
#         try:
#             logo = _resolve_kpmg_logo()
#         except Exception:
#             logger.exception("resolve_kpmg_logo failed; continuing without logo")

#         self.pdf = _Doc(logo, title)
#         self.pdf.alias_nb_pages()
#         self.pdf.set_auto_page_break(auto=True, margin=20)
#         self.pdf.add_page()

#     def title_block(self, title: str) -> None:
#         p = self.pdf
#         p.set_font("Helvetica", "B", 18)
#         p.set_text_color(*_KPMG_BLUE_RGB)
#         p.multi_cell(0, 10, (title or "Report").strip() or "Report")
#         p.set_draw_color(200, 200, 200)
#         p.line(10, p.get_y() + 2, p.w - 10, p.get_y() + 2)
#         p.ln(6)
#         p.set_text_color(0, 0, 0)

#     # def heading(self, text: str) -> None:
#     #     p = self.pdf
#     #     p.set_font("Helvetica", "B", 13)
#     #     p.set_text_color(*_KPMG_BLUE_RGB)
#     #     p.multi_cell(0, 8, (text or "Section").strip() or "Section")
#     #     p.set_text_color(0, 0, 0)
#     #     p.ln(1)

#     def heading(self, text: str) -> None:
#         p = self.pdf

#         p.set_font("Helvetica", "B", 13)
#         p.set_text_color(*_KPMG_BLUE_RGB)

#         p.set_x(p.l_margin)


#         p.multi_cell(
#             p.w - p.l_margin - p.r_margin,
#             8,
#             (text or "Section").strip() or "Section"
#         )

#         p.set_text_color(0, 0, 0)

#         # Reset cursor position
#         p.set_x(p.l_margin)

#         p.ln(1)
#     # def paragraph(self, text: str) -> None:
#     #     p = self.pdf
#     #     p.set_font("Helvetica", "", 11)
#     #     for line in (text or "").split("\n"):
#     #         p.multi_cell(0, 6, line)
#     #     p.ln(2)

#     def paragraph(self, text: str) -> None:
#         p = self.pdf
#         p.set_font("Helvetica", "", 11)

#         available_width = p.w - p.l_margin - p.r_margin

#         for line in (text or "").splitlines():
#             # Reset X position before each line
#             p.set_x(p.l_margin)

#             # Handle empty lines safely
#             if not line.strip():
#                 p.ln(4)
#                 continue

#             logger.debug(
#                 "PDF paragraph render. x=%s, y=%s, available_width=%s, line_preview=%r",
#                 p.get_x(),
#                 p.get_y(),
#                 available_width,
#                 line[:100],  #Log first 100 characters of the line for debugging
#             )

#             p.multi_cell(
#                 available_width,
#                 6,
#                 line,
#             )

#         p.ln(2)

#     def table(self, headers: List[str], rows: List[List[Any]]) -> None:
#         p = self.pdf
#         cols = max(len(headers or []), max((len(r) for r in (rows or [])), default=0))
#         if cols == 0:
#             return

#         avail = p.w - 20
#         col_w = avail / cols

#         p.set_font("Helvetica", "B", 10)
#         p.set_fill_color(*_KPMG_BLUE_RGB)
#         p.set_text_color(255, 255, 255)
#         for j in range(cols):
#             txt = str(headers[j]) if headers and j < len(headers) else ""
#             p.cell(col_w, 8, txt[:40], border=1, align="C", fill=True)
#         p.ln(8)

#         p.set_font("Helvetica", "", 9)
#         p.set_text_color(0, 0, 0)
#         for row in rows or []:
#             for j in range(cols):
#                 val = str(row[j]) if isinstance(row, (list, tuple)) and j < len(row) else ""
#                 p.cell(col_w, 7, val[:40], border=1)
#             p.ln(7)
#         p.ln(3)

#     def output_bytes(self) -> bytes:
#         buf = BytesIO()
#         raw = self.pdf.output(dest="S")
#         if isinstance(raw, str):
#             raw = raw.encode("latin-1")
#         buf.write(raw)
#         return buf.getvalue()


# class PDFGeneratorService:
#     """Create KPMG-branded .pdf files from structured sections/tables."""

#     def __init__(self, output_dir: str | None = None) -> None:
#         self.output_dir = output_dir or os.path.join("uploads", "generated", "pdf")
#         os.makedirs(self.output_dir, exist_ok=True)

#     def generate(self, input_data: Dict[str, Any]) -> Dict[str, str]:
#         title = input_data.get("title", "Report")
#         sections = input_data.get("sections") or []
#         logger.info(
#         "PDF INPUT DATA=%r",
#         input_data
#          )

#         doc = _BrandedPDF(title=title)
#         doc.title_block(title)
#         for sec in sections:
#             if not isinstance(sec, dict):
#                 continue
#             heading = (sec.get("heading") or sec.get("title") or "Section").strip()
#             logger.info(
#             "Processing section. Heading=%r",
#             heading
#             )
#             doc.heading(heading)
#             # body = sec.get("body") or sec.get("text") or sec.get("content") or ""
#             # if isinstance(body, str) and body.strip():
#             #     doc.paragraph(body)
#             body = sec.get("body") or sec.get("text") or sec.get("content") or ""

#         if isinstance(body, str) and body.strip():
#             logger.info(
#                 "Rendering section body. Section='%s', Length=%d, Preview=%r",
#                 heading,
#                 len(body),
#                 body[:500]
#             )

#             logger.info(
#                 "Section='%s' Body=%r",
#                 heading,
#                 body
#             )

#             try:
#                 doc.paragraph(body)
#             except Exception as exc:
#                 logger.exception(
#                     "Failed rendering body for section '%s'. Error=%s",
#                     heading,
#                     str(exc)
#                 )
#             tbl = sec.get("table")
#             if isinstance(tbl, dict) and (tbl.get("headers") or tbl.get("rows")):
#                 doc.table(list(tbl.get("headers") or []), [list(r) for r in (tbl.get("rows") or [])])

#         file_id = str(uuid.uuid4())
#         display_name = _safe_pdf_filename(title)
#         disk_name = f"{file_id}.pdf"
#         file_path = os.path.abspath(os.path.join(self.output_dir, disk_name))
#         os.makedirs(self.output_dir, exist_ok=True)
#         with open(file_path, "wb") as fh:
#             fh.write(doc.output_bytes())

#         logger.info("PDF generated: %s (display=%s)", disk_name, display_name)

#         marker = f"[GENERATED_FILE:{file_path}:{display_name}]"
#         return {
#             "result": (
#                 f"PDF document '{title}' generated successfully.\n\n"
#                 f"{marker}\n\n"
#                 "Include the [GENERATED_FILE:...] line above EXACTLY ONCE in your final "
#                 "answer, verbatim - it becomes the download link. Do NOT rewrite it as a "
#                 "markdown link and do NOT call pdf_generator again."
#             ),
#             "file_path": file_path,
#             "filename": display_name,
#             "file_id": file_id,
#         }



"""
PDF (.pdf) report generator tool - KPMG-branded.

Mirrors docx_generator: accepts title + sections (heading/body/table) and produces
a downloadable, KPMG-branded PDF via fpdf2. Emits a [GENERATED_FILE:...] marker so the
existing download pipeline (skill_executor / workflow generated_file_links) turns it into
a "Click here to download" link.
"""

from __future__ import annotations

import logging
import os
import re
import json
import uuid
from io import BytesIO
from typing import Any, Dict, List
from echolib.blob_storage import (
    upload_to_blob,
    get_blob_url,
)

from echolib.branding import KPMG_BLUE_RGB as _KPMG_BLUE_RGB
from echolib.branding import resolve_kpmg_logo as _resolve_kpmg_logo

logger = logging.getLogger(__name__)

_NOT_DISCLOSED = "Not disclosed in provided documents"
_PLACEHOLDER_CELL = re.compile(
    r"^placeholder(\s+for\s+[\w\s,.'-]+)?$",
    re.IGNORECASE,
)


def _sanitize_docx_text(val: Any) -> str:
    """Replace LLM placeholder tokens with grounded wording."""
    if val is None:
        return _NOT_DISCLOSED
    s = str(val).strip()
    if not s:
        return _NOT_DISCLOSED
    low = s.lower()
    if low == "placeholder" or _PLACEHOLDER_CELL.match(s):
        return _NOT_DISCLOSED
    if "placeholder" in low:
        return _NOT_DISCLOSED
    return s

def normalize_pdf_sections(
    sections: List[Dict[str, Any]],
    *,
    include_charts: bool = False,
) -> List[Dict[str, Any]]:
    """
    Accept LLM quirks: ``title`` instead of ``heading``; ``text`` instead of ``body``;
    ``charts`` as list of strings (no image) or misaligned labels/values.

    When ``include_charts`` is False (default), section ``charts`` are cleared and
    auto-charts from tables/body are not synthesized. Set True when the caller
    wants chart images (e.g. after matching user intent or model flag).
    """
    out: List[Dict[str, Any]] = []  
    for raw in sections or []:
        if not isinstance(raw, dict):
            continue
        sec = dict(raw)
        head = (
            sec.get("heading")
            or sec.get("title")
            or ""
        ).strip()

        sec["heading"] = head or "Section"
        sec.pop("title", None)

        # Narrative: many LLMs use "text" instead of "body"
        b = sec.get("body")
        tx = sec.get("text")
        ct = sec.get("content")
        if isinstance(b, str) and b.strip():
            merged = b
        elif isinstance(tx, str) and tx.strip():
            merged = tx
        elif isinstance(ct, str) and ct.strip():
            merged = ct
        elif isinstance(b, str):
            merged = b
        else:
            merged = ""
        sec.pop("text", None)

        if isinstance(merged, str):
            # LLMs sometimes emit literal "\n" escape sequences instead of
            # real newlines — convert them so pipe-table detection works.
            merged = merged.replace("\\n", "\n")
            lines = []
            for line in merged.split("\n"):
                t = line.strip()
                lines.append(_sanitize_docx_text(t) if t else "")
            sec["body"] = "\n".join(lines)
        else:
            sec["body"] = ""

        sec.pop("charts", None)

        if isinstance(sec.get("table"), dict):
            tb = dict(sec["table"])
            hdrs = [_sanitize_docx_text(x) for x in (tb.get("headers") or [])]
            rows = []
            for row in tb.get("rows") or []:
                if isinstance(row, (list, tuple)):
                    rows.append([_sanitize_docx_text(c) for c in row])
                else:
                    rows.append([_sanitize_docx_text(row)])
            tb["headers"] = hdrs
            tb["rows"] = rows
            sec["table"] = tb

        out.append(sec)
        
    return out

TOOL_DEFINITION = {
    "tool_id": "tool_pdf_generator",
    "name": "PDF Document Generator",
    "description": (
        "Creates a KPMG-branded PDF (.pdf) document. RULES: 1) Call file_reader FIRST for "
        "every uploaded PDF before calling this tool. 2) Call this tool EXACTLY ONCE with "
        "ALL sections - never split into multiple calls. 3) Every section needs a "
        "descriptive heading. 4) Use tables for comparative data. Returns a downloadable "
        "file path."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Document title (shown in the document)"},
            "sections": {
                "type": "array",
                "description": "Ordered sections",
                "items": {
                    "type": "object",
                    "properties": {
                        "heading": {"type": "string", "description": "Section heading"},
                        "body": {"type": "string", "description": "Narrative paragraphs"},
                        "table": {
                            "type": "object",
                            "properties": {
                                "headers": {"type": "array", "items": {"type": "string"}},
                                "rows": {"type": "array", "items": {"type": "array"}},
                            },
                        },
                    },
                    "required": [],
                },
            },
        },
        "required": ["title", "sections"],
    },
    "capabilities": ["pdf_generation", "pdf_export"],
}


def _safe_pdf_filename(title: str) -> str:
    raw = (title or "").strip() or "Report"

    # Remove an existing PDF extension first
    raw = re.sub(
        r"\s*\.?\s*pdf$",
        "",
        raw,
        flags=re.IGNORECASE,
    ).strip()

    slug = "".join(
        c if c.isalnum() or c in " -_"
        else " "
        for c in raw
    )

    slug = re.sub(r"\s+", " ", slug).strip(" ._")[:100]

    if not slug:
        slug = "Report"

    return f"{slug}.pdf"

class _BrandedPDF:
    """Builds a KPMG-branded fpdf2 document. Branding failures never raise."""

    def __init__(self, title: str):
        from fpdf import FPDF

        class _Doc(FPDF):
            def __init__(self, logo: str | None, doc_title: str):
                super().__init__()
                self._logo = logo
                self._title = doc_title

            def header(self):
                if self._logo:
                    try:
                        self.image(self._logo, x=self.w - 42, y=8, w=32)
                    except Exception:
                        logger.exception("KPMG header logo could not be added to PDF")
                self.set_draw_color(*_KPMG_BLUE_RGB)
                self.set_line_width(0.6)
                self.line(10, 26, self.w - 10, 26)
                self.set_y(30)

            def footer(self):
                self.set_y(-15)
                self.set_font("Helvetica", "I", 8)
                self.set_text_color(128, 128, 128)
                self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

        logo = None
        try:
            logo = _resolve_kpmg_logo()
        except Exception:
            logger.exception("resolve_kpmg_logo failed; continuing without logo")

        self.pdf = _Doc(logo, title)
        self.pdf.alias_nb_pages()
        self.pdf.set_auto_page_break(auto=True, margin=20)
        self.pdf.add_page()

    def title_block(self, title: str) -> None:
        p = self.pdf
        p.set_font("Helvetica", "B", 18)
        p.set_text_color(*_KPMG_BLUE_RGB)
        p.multi_cell(0, 10, (title or "Report").strip() or "Report")
        p.set_draw_color(200, 200, 200)
        p.line(10, p.get_y() + 2, p.w - 10, p.get_y() + 2)
        p.ln(6)
        p.set_text_color(0, 0, 0)

    # def heading(self, text: str) -> None:
    #     p = self.pdf
    #     p.set_font("Helvetica", "B", 13)
    #     p.set_text_color(*_KPMG_BLUE_RGB)
    #     p.multi_cell(0, 8, (text or "Section").strip() or "Section")
    #     p.set_text_color(0, 0, 0)
    #     p.ln(1)

    def heading(self, text: str) -> None:
        p = self.pdf

        p.set_font("Helvetica", "B", 13)
        p.set_text_color(*_KPMG_BLUE_RGB)

        p.set_x(p.l_margin)


        p.multi_cell(
            p.w - p.l_margin - p.r_margin,
            8,
            (text or "Section").strip() or "Section"
        )

        p.set_text_color(0, 0, 0)

        # Reset cursor position
        p.set_x(p.l_margin)

        p.ln(1)
    # def paragraph(self, text: str) -> None:
    #     p = self.pdf
    #     p.set_font("Helvetica", "", 11)
    #     for line in (text or "").split("\n"):
    #         p.multi_cell(0, 6, line)
    #     p.ln(2)

    def paragraph(self, text: str) -> None:
        p = self.pdf
        p.set_font("Helvetica", "", 11)

        available_width = p.w - p.l_margin - p.r_margin

        text = str(text or "").replace("\\n", "\n")

        for line in text.splitlines():
            # Reset X position before each line
            p.set_x(p.l_margin)

            # Handle empty lines safely
            if not line.strip():
                p.ln(4)
                continue

            logger.debug(
                "PDF paragraph render. x=%s, y=%s, available_width=%s, line_preview=%r",
                p.get_x(),
                p.get_y(),
                available_width,
                line[:100],  #Log first 100 characters of the line for debugging
            )

            p.multi_cell(
                available_width,
                6,
                line,
            )

        p.ln(2)

    def table(self, headers: List[str], rows: List[List[Any]]) -> None:
        p = self.pdf
        cols = max(len(headers or []), max((len(r) for r in (rows or [])), default=0))
        if cols == 0:
            return

        avail = p.w - 20
        col_w = avail / cols

        p.set_font("Helvetica", "B", 10)
        p.set_fill_color(*_KPMG_BLUE_RGB)
        p.set_text_color(255, 255, 255)
        for j in range(cols):
            txt = str(headers[j]) if headers and j < len(headers) else ""
            p.cell(col_w, 8, txt[:40], border=1, align="C", fill=True)
        p.ln(8)

        p.set_font("Helvetica", "", 9)
        p.set_text_color(0, 0, 0)
        for row in rows or []:
            for j in range(cols):
                val = str(row[j]) if isinstance(row, (list, tuple)) and j < len(row) else ""
                p.cell(col_w, 7, val[:40], border=1)
            p.ln(7)
        p.ln(3)

    def output_bytes(self) -> bytes:
        buf = BytesIO()
        raw = self.pdf.output(dest="S")
        if isinstance(raw, str):
            raw = raw.encode("latin-1")
        buf.write(raw)
        return buf.getvalue()


class PDFGeneratorService:
    """Create KPMG-branded .pdf files from structured sections/tables."""

    def __init__(self, output_dir: str | None = None) -> None:
        self.output_dir = output_dir or os.path.join("uploads", "generated", "pdf")
        os.makedirs(self.output_dir, exist_ok=True)

    def generate(self, input_data: Dict[str, Any]) -> Dict[str, str]:
        title = input_data.get("title", "Report")
        sections = input_data.get("sections") or []

        logger.info("========== PDF TOOL INVOKED ==========")

        logger.info(
            "RAW_DATA_TYPE=%s",
            type(input_data).__name__
        )

        logger.info(
            "RAW_DATA=%s",
            json.dumps(
                input_data,
                default=str,
                indent=2,
            )
        )

        logger.info(
            "TITLE=%s",
            title,
        )

        logger.info(
            "SECTIONS_TYPE=%s",
            type(sections).__name__,
        )

        logger.info(
            "SECTION_COUNT=%s",
            len(sections),
        )

        session_id = (
            input_data.get("session_id")
            or input_data.get("chat_session_id")
            or str(uuid.uuid4())
        )

        sections = normalize_pdf_sections(
            [dict(s) for s in sections if isinstance(s, dict)]
        )

        logger.info(
            "Normalized PDF sections=%s",
            sections,
        )

        # head = (
        #     sec.get("heading")
        #     or sec.get("title")
        #     or ""
        # ).strip()

        # sec["heading"] = head or "Section"

        doc = _BrandedPDF(title=title)
        doc.title_block(title)
        for sec in sections:
            if not isinstance(sec, dict):
                continue

            heading = str(
                sec.get("heading") or "Section"
            ).strip()
            doc.heading(heading)
            # body = sec.get("body") or sec.get("text") or sec.get("content") or ""
            # if isinstance(body, str) and body.strip():
            #     doc.paragraph(body)
            body = sec.get("body") or ""
            if isinstance(body, str) and body.strip():
                logger.info(
                    "Rendering section body. Section='%s', Length=%d, Preview=%r",
                    heading,
                    len(body),
                    body[:500]
                )
            try:
                doc.paragraph(body)
            except Exception as exc:
                logger.exception(
                    "Failed rendering body for section '%s'. Error=%s",
                    heading,
                    str(exc)
                )
            tbl = sec.get("table")
            if isinstance(tbl, dict) and (tbl.get("headers") or tbl.get("rows")):
                doc.table(list(tbl.get("headers") or []), [list(r) for r in (tbl.get("rows") or [])])

        file_id = str(uuid.uuid4())
        filename = _safe_pdf_filename(title)

        file_path = os.path.abspath(
            os.path.join(self.output_dir, filename)
        )
        os.makedirs(self.output_dir, exist_ok=True)
        with open(file_path, "wb") as fh:
            fh.write(doc.output_bytes())

        logger.info("PDF generated: %s", filename)

        blob_name = (
            f"generated/doc/"
            f"{session_id}/"
            f"{file_id}/"
            f"{filename}"
        )

        uploaded = upload_to_blob(
            local_path=file_path,
            blob_name=blob_name,
        )
        logger.info("PDF upload result=%s", uploaded)

        if not uploaded:
            raise RuntimeError(
                f"Failed to upload PDF to blob storage: {blob_name}"
            )

        download_url = get_blob_url(blob_name)

        logger.info("PDF DOWNLOAD_URL=%s", download_url)

        try:
            os.remove(file_path)
        except Exception:
            logger.warning(
                "Failed to remove local PDF file: %s",
                file_path,
            )

       
        return {
            "file_path": download_url,
            "filename": filename,
            "file_id": file_id,
            "download_url": download_url,
            "session_id": session_id,
            "result": (
                f"File generated successfully.\n\n"
                f"Download URL:\n{download_url}"
            ),
        }