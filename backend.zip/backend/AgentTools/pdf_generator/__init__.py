"""PDF (.pdf) report generator for agent downloads (KPMG-branded)."""

from .service import PDFGeneratorService, TOOL_DEFINITION

__all__ = ["PDFGeneratorService", "TOOL_DEFINITION"]
