"""
SQL Tool — Agent-facing SQL query executor.

Accepts a db_id (connection_id from DatabaseConnectorService) and a SQL query,
executes it against the saved connection, and returns formatted results.

The db_id comes from the app's connector setup — same ID returned by
GET /connectors/db/list.
"""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


class SQLToolService:
    """
    Executes SQL queries against a saved database connection.
    """

    def execute(self, data: Dict[str, Any]) -> str:
        """
        Execute a SQL query against a saved database connection.

        Args:
            data: dict with:
                db_id   (str) — connection_id from the DB connector list
                query   (str) — SQL query to execute
                limit   (int, optional) — max rows to return (default 100)

        Returns:
            Plain text summary of query results for the LLM.
        """
        db_id = (data.get("db_id") or "").strip()
        query = (data.get("query") or "").strip()
        limit = int(data.get("limit") or 100)

        if not db_id:
            return "Error: db_id is required. Provide the database connection ID."

        if not query:
            return "Error: query is required. Provide a SQL query to execute."

        try:
            from apps.connector.db_connector import DatabaseConnectorService

            svc = DatabaseConnectorService()

            # Check connection exists
            conn_info = svc._connections.get(db_id)
            if not conn_info:
                # Reload from DB in case it was added after startup
                svc._load_persisted()
                conn_info = svc._connections.get(db_id)

            if not conn_info:
                available = list(svc._connections.keys())
                return (
                    f"Error: Database connection '{db_id}' not found. "
                    f"Available connection IDs: {available}"
                )

            db_name = conn_info.get("name", db_id)
            db_type = conn_info.get("db_type", "unknown")

            logger.info(
                "SQL Tool executing query on db_id=%s (%s / %s): %s",
                db_id, db_name, db_type, query[:200],
            )

            result = svc.execute_query(
                connection_id=db_id,
                query=query,
                limit=limit,
            )

            # Format result for LLM
            if result.get("type") == "select":
                columns = result.get("columns", [])
                rows = result.get("rows", [])
                row_count = result.get("row_count", 0)

                if not rows:
                    return f"Query executed successfully. No rows returned.\nQuery: {query}"

                # Build a readable table
                lines = [
                    f"Query Results from '{db_name}' ({row_count} rows):",
                    f"Columns: {', '.join(columns)}",
                    "",
                ]
                for i, row in enumerate(rows[:50]):  # cap display at 50
                    values = " | ".join(str(row.get(c, "")) for c in columns)
                    lines.append(f"  Row {i+1}: {values}")

                if row_count > 50:
                    lines.append(f"  ... ({row_count - 50} more rows not shown)")

                return "\n".join(lines)

            else:
                # DML result
                rows_affected = result.get("rows_affected", 0)
                return (
                    f"Query executed successfully on '{db_name}'. "
                    f"Rows affected: {rows_affected}."
                )

        except ValueError as exc:
            return f"Query execution error: {exc}"
        except Exception as exc:
            logger.exception("SQL Tool unexpected error: %s", exc)
            return f"Unexpected error executing query: {exc}"
