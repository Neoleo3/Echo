"""
AgentTools Logging Configuration

Centralized logging setup with:
- Structured logging formats
- Different log levels for different modules
- File and console output
- Configurable via environment variables
"""

import logging
import logging.handlers
import os

try:
    from pythonjsonlogger import jsonlogger
except ImportError:
    jsonlogger = None


def setup_logging():
    """
    Configure logging for AgentTools.
    
    Environment variables:
    - AGENTTOOLS_LOG_LEVEL: Log level (DEBUG, INFO, WARNING, ERROR)
    - AGENTTOOLS_LOG_FILE: Path to log file (optional)
    - AGENTTOOLS_LOG_FORMAT: Format (json|text)
    """
    from .config import get_config
    
    config = get_config()
    log_level = config.logging.log_level
    log_dir = os.path.join(config.paths.output_base, "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    # Root logger
    root_logger = logging.getLogger("agenttools")
    root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # File handler
    log_file = os.path.join(log_dir, "agenttools.log")
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5
    )
    file_handler.setLevel(log_level)
    
    # Formatters
    if config.logging.include_timestamps:
        text_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    else:
        text_format = "%(name)s - %(levelname)s - %(message)s"
    
    text_formatter = logging.Formatter(text_format)
    json_formatter = jsonlogger.JsonFormatter() if jsonlogger else logging.Formatter(text_format)
    
    # Attach handlers
    console_handler.setFormatter(text_formatter)
    file_handler.setFormatter(json_formatter)
    
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    
    # Configure specific modules
    logging.getLogger("pptx").setLevel(logging.WARNING)  # Suppress pptx debug logs
    logging.getLogger("openpyxl").setLevel(logging.WARNING)
    logging.getLogger("langchain").setLevel(logging.WARNING)
    
    root_logger.info(
        "AgentTools logging initialized (level=%s, file=%s)",
        log_level, log_file
    )
    
    return root_logger


# Initialize on import
setup_logging()
