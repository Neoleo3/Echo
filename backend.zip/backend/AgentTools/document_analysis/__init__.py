"""
Document Analysis Tool Package

Analyzes receipt and expense documents for policy compliance, fraud detection,
and data validation in automated expense report processing.
"""

from .service import DocumentAnalysisService

__version__ = "1.0"
__author__ = "EchoAI"

__all__ = ["DocumentAnalysisService"]
