"""Document analysis with optional OCR-backed receipt extraction."""

import base64
import ast
import re
import logging
import os
from datetime import datetime, timedelta
from difflib import SequenceMatcher
from typing import Dict, List, Any, Optional, Tuple
import json
import hashlib

logger = logging.getLogger(__name__)

DOCX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
DEFAULT_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif", ".gif"}
DEFAULT_DOCUMENT_EXTENSIONS = {".pdf", ".docx"}
DEFAULT_DOCUMENT_MIME_TYPES = {"application/pdf", DOCX_MIME_TYPE}


class DocumentAnalysisService:
    """
    Service class for analyzing receipts and expense documents.
    Checks policy compliance, detects duplicates and fraud, validates data.
    """

    def __init__(self):
        """Initialize the Document Analysis Service with config."""
        try:
            from ..config import get_config
            from ..ocr_markitdown.service import OCRService
            self.config = get_config()
            self.doc_config = self.config.document_analysis
            self.ocr_service = OCRService()
        except ImportError as exc:
            self.config = None
            self.doc_config = None
            self.ocr_service = None
            logger.warning(
                "Document Analysis init: dependency import failed (%s: %s). "
                "OCR-based extraction will be unavailable.",
                type(exc).__name__, exc,
            )
        
        # Default policy rules (configurable via environment)
        self.default_policy = {
            "max_meal_amount": self.doc_config.default_max_meal if self.doc_config else 75.00,
            "max_single_expense": self.doc_config.default_max_single_expense if self.doc_config else 1000.00,
            "max_daily_expenses": self.doc_config.default_max_daily if self.doc_config else 250.00,
            "requires_receipt_over": 25.00,
            "allowed_categories": [
                "Meals", "Transportation", "Lodging", "Office Supplies",
                "Travel", "Entertainment", "Training", "Technology", "Other"
            ],
            "blacklisted_merchants": ["Casino", "Liquor Store", "Gun Shop", "Adult Entertainment"],
            "max_expense_age_days": 90,
            "per_diem_rates": {
                "meals": 50.00,
                "lodging": 150.00
            }
        }
        
        # Expense categories with keywords
        self.category_keywords = {
            "Meals": ["restaurant", "cafe", "coffee", "food", "dining", "lunch", "dinner", "breakfast", "starbucks", "burger", "pizza", "mcdonald"],
            "Transportation": ["uber", "lyft", "taxi", "gas", "fuel", "parking", "airline", "flight", "rental car", "train", "subway"],
            "Lodging": ["hotel", "motel", "airbnb", "inn", "resort", "accommodation", "hyatt", "marriott"],
            "Office Supplies": ["staples", "office depot", "paper", "supplies", "printer", "toner"],
            "Travel": ["airline", "booking", "expedia", "kayak", "travelocity"],
            "Entertainment": ["cinema", "theater", "concert", "event", "tickets", "entertainment", "sports"],
            "Training": ["conference", "seminar", "workshop", "training", "course", "education", "udemy"],
            "Technology": ["apple", "microsoft", "amazon", "best buy", "electronics", "computer", "software"],
            "Other": []
        }
        
        # Duplicate detection method (configurable)
        self.duplicate_method = self.doc_config.duplicate_detection_method if self.doc_config else "fuzzy"
        self.fuzzy_threshold = self.doc_config.fuzzy_match_threshold if self.doc_config else 0.85
        self.ocr_timeout_seconds = self.doc_config.ocr_timeout_seconds if self.doc_config else 30
        self.ocr_max_file_size = self.doc_config.ocr_max_file_size if self.doc_config else 15 * 1024 * 1024
        self.ocr_confidence_warning_threshold = (
            self.doc_config.ocr_confidence_warning_threshold if self.doc_config else 0.6
        )
        self.supported_image_mime_types = set(
            (self.doc_config.ocr_supported_image_mime_types if self.doc_config else [])
            or [
                "image/png",
                "image/jpeg",
                "image/jpg",
                "image/webp",
                "image/bmp",
                "image/tiff",
                "image/gif",
            ]
        )
        self.supported_image_extensions = set(
            (self.doc_config.ocr_supported_image_extensions if self.doc_config else [])
            or list(DEFAULT_IMAGE_EXTENSIONS)
        )
        self.supported_document_mime_types = set(
            (self.doc_config.ocr_supported_document_mime_types if self.doc_config else [])
            or list(DEFAULT_DOCUMENT_MIME_TYPES)
        )
        self.supported_document_extensions = set(
            (self.doc_config.ocr_supported_document_extensions if self.doc_config else [])
            or list(DEFAULT_DOCUMENT_EXTENSIONS)
        )
        
        logger.info("Document Analysis Service initialized (duplicate_method=%s)", self.duplicate_method)

    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Main execution method called by the agent framework.
        Routes to appropriate operation handler with proper error handling.
        """
        from ..exceptions import InvalidOperationError, DocumentAnalysisError
        
        # Strip None values from kwargs — LLMs often pass explicit nulls for
        # optional fields.  Downstream handlers use .get(key, default) which
        # only applies the default when the key is ABSENT, not when it's None.
        kwargs = {k: v for k, v in kwargs.items() if v is not None}

        logger.info(
            "DOCUMENT_ANALYSIS_INPUT=%s",
            json.dumps(kwargs, default=str)
        )

        if kwargs.get("threshold_strictness") == "medium":
            kwargs["threshold_strictness"] = "moderate"

        if kwargs.get("analysis_depth") == "full":
            kwargs["analysis_depth"] = "comprehensive"

        if kwargs.get("operation") == "analyze":
            kwargs["operation"] = "analyze_receipt"

        operation = kwargs.get("operation")
        
        if not operation:
            raise DocumentAnalysisError(
                message="No operation specified", 
                error_code="MISSING_OPERATION"
            )

        # Route to appropriate operation handler
        operation_handlers = {
            "analyze": self.analyze_receipt,
            "analyze_receipt": self.analyze_receipt,
            "check_policy_compliance": self.check_policy_compliance,
            "detect_duplicates": self.detect_duplicates,
            "categorize_expense": self.categorize_expense,
            "validate_amounts": self.validate_amounts,
            "verify_merchant": self.verify_merchant,
            "detect_fraud_indicators": self.detect_fraud_indicators,
            "generate_analysis_report": self.generate_analysis_report
        }

        handler = operation_handlers.get(operation)
        if not handler:
            raise InvalidOperationError(
                operation=operation,
                valid_operations=list(operation_handlers.keys())
            )

        try:
            result = handler(**kwargs)
            logger.info("Operation completed successfully: %s", operation)
            return result
        except Exception as e:
            logger.error("Operation failed: %s - %s", operation, str(e), exc_info=True)
            return {
                "operation": operation,
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__
            }

    def analyze_receipt(self, **kwargs) -> Dict[str, Any]:
        """
        Comprehensive receipt analysis including all checks.
        
        Args:
            receipt_data: Structured receipt data from OCR
            expense_data: Employee's expense claim
            policy_rules: Policy rules to check
            existing_receipts: For duplicate detection
            analysis_depth: Level of analysis
            
        Returns:
            Dict with complete analysis results
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        expense_data = kwargs.get("expense_data", {})
        analysis_depth = kwargs.get("analysis_depth", "standard")
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "analyze_receipt",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        results = {
            "operation": "analyze_receipt",
            "success": True,
            "receipt_info": {
                "merchant": receipt_data.get("merchant_name"),
                "date": receipt_data.get("date"),
                "total": receipt_data.get("total_amount")
            }
        }
        
        # Run all analyses
        all_violations = []
        all_warnings = list(ocr_context.get("warnings", []))
        
        # 1. Policy compliance
        compliance = self.check_policy_compliance(**kwargs)
        if not compliance["success"]:
            return compliance
        
        results["compliance_status"] = compliance["compliance_status"]
        all_violations.extend(compliance.get("violations", []))
        
        # 2. Categorization
        category = self.categorize_expense(**kwargs)
        results["category"] = category.get("category")
        results["category_confidence"] = category.get("confidence", 0)
        
        # 3. Fraud detection
        fraud = self.detect_fraud_indicators(**kwargs)
        results["fraud_score"] = fraud.get("fraud_score", 0)
        results["fraud_indicators"] = fraud.get("fraud_indicators", [])
        
        # 4. Duplicate detection
        if kwargs.get("existing_receipts"):
            duplicates = self.detect_duplicates(**kwargs)
            if duplicates.get("is_duplicate"):
                results["duplicate_match"] = duplicates.get("match")
                all_violations.append({
                    "type": "duplicate_submission",
                    "severity": "high",
                    "description": "Potential duplicate receipt detected"
                })
        
        # 5. Amount validation
        validation = self.validate_amounts(**kwargs)
        if not validation.get("amounts_valid"):
            all_warnings.extend(validation.get("issues", []))
        
        # 6. Merchant verification
        if kwargs.get("merchant_database"):
            merchant_check = self.verify_merchant(**kwargs)
            if not merchant_check.get("is_verified"):
                all_warnings.append(merchant_check.get("message"))
        
        # Determine overall status
        if results["fraud_score"] > 0.7:
            results["compliance_status"] = "flagged"
        elif len([v for v in all_violations if v.get("severity") == "high"]) > 0:
            results["compliance_status"] = "non_compliant"
        elif len(all_violations) > 0:
            results["compliance_status"] = "requires_review"
        
        results["violations"] = all_violations
        results["warnings"] = all_warnings
        results["total_violations"] = len(all_violations)
        results["total_warnings"] = len(all_warnings)
        
        # Generate recommendations
        if kwargs.get("include_recommendations", True):
            results["recommendations"] = self._generate_recommendations(results)
        
        # Summary
        results["analysis_summary"] = {
            "compliant": results["compliance_status"] == "compliant",
            "requires_approval": results["compliance_status"] in ["requires_review", "non_compliant"],
            "reject": results["compliance_status"] == "flagged" or results["fraud_score"] > 0.8,
            "confidence_level": "high" if results["fraud_score"] < 0.3 else "medium" if results["fraud_score"] < 0.6 else "low"
        }
        
        results["message"] = self._create_summary_message(results)
        
        return self._attach_ocr_context(results, ocr_context)

    def check_policy_compliance(self, **kwargs) -> Dict[str, Any]:
        """
        Check receipt against company expense policies.
        
        Args:
            receipt_data: Receipt data to check
            expense_data: Expense claim data
            policy_rules: Policy rules (uses defaults if not provided)
            threshold_strictness: How strict to be
            
        Returns:
            Dict with compliance status and violations
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        expense_data = kwargs.get("expense_data", {})
        policy = kwargs.get("policy_rules", self.default_policy)
        strictness = kwargs.get("threshold_strictness", "moderate")
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "check_policy_compliance",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        violations = []
        
        # Check total amount limits
        total = receipt_data.get("total_amount", 0)
        category = self.categorize_expense(receipt_data=receipt_data).get("category", "Other")
        
        # Check meal amount limit
        if category == "Meals" and total > policy.get("max_meal_amount", 75):
            violations.append({
                "type": "exceeds_meal_limit",
                "severity": "medium",
                "description": f"Meal expense ${total:.2f} exceeds limit ${policy['max_meal_amount']:.2f}",
                "policy_limit": policy["max_meal_amount"],
                "actual_amount": total
            })
        
        # Check single expense limit
        if total > policy.get("max_single_expense", 1000):
            violations.append({
                "type": "exceeds_single_expense_limit",
                "severity": "high",
                "description": f"Expense ${total:.2f} exceeds single expense limit ${policy['max_single_expense']:.2f}",
                "policy_limit": policy["max_single_expense"],
                "actual_amount": total
            })
        
        # Check receipt requirement
        if total > policy.get("requires_receipt_over", 25) and not receipt_data.get("raw_text"):
            violations.append({
                "type": "missing_receipt",
                "severity": "high",
                "description": f"Receipt required for expenses over ${policy['requires_receipt_over']:.2f}",
                "policy_limit": policy["requires_receipt_over"],
                "actual_amount": total
            })
        
        # Check merchant blacklist
        merchant = receipt_data.get("merchant_name", "").upper()
        blacklisted = policy.get("blacklisted_merchants", [])
        for blocked in blacklisted:
            if blocked.upper() in merchant:
                violations.append({
                    "type": "blacklisted_merchant",
                    "severity": "high",
                    "description": f"Merchant '{receipt_data.get('merchant_name')}' is not allowed",
                    "merchant": receipt_data.get("merchant_name")
                })
        
        # Check expense age
        if receipt_data.get("date"):
            try:
                receipt_date = self._parse_date(receipt_data["date"])
                age_days = (datetime.now() - receipt_date).days
                max_age = policy.get("max_expense_age_days", 90)
                
                if age_days > max_age:
                    violations.append({
                        "type": "expense_too_old",
                        "severity": "medium",
                        "description": f"Expense is {age_days} days old, exceeds {max_age} day limit",
                        "expense_age_days": age_days,
                        "policy_limit": max_age
                    })
            except:
                violations.append({
                    "type": "invalid_date",
                    "severity": "low",
                    "description": "Could not parse receipt date"
                })
        
        # Check category validity
        if category not in policy.get("allowed_categories", []):
            violations.append({
                "type": "invalid_category",
                "severity": "low",
                "description": f"Category '{category}' is not in allowed categories",
                "category": category
            })
        
        # Check claimed amount vs receipt amount
        if expense_data.get("claimed_amount"):
            claimed = expense_data["claimed_amount"]
            if abs(claimed - total) > 0.01:
                violations.append({
                    "type": "amount_mismatch",
                    "severity": "high",
                    "description": f"Claimed amount ${claimed:.2f} does not match receipt total ${total:.2f}",
                    "claimed_amount": claimed,
                    "receipt_amount": total,
                    "difference": abs(claimed - total)
                })
        
        # Determine compliance status
        high_severity = [v for v in violations if v["severity"] == "high"]
        
        if len(high_severity) > 0:
            compliance_status = "non_compliant"
        elif len(violations) > 0:
            compliance_status = "requires_review"
        else:
            compliance_status = "compliant"
        
        return self._attach_ocr_context({
            "operation": "check_policy_compliance",
            "success": True,
            "compliance_status": compliance_status,
            "violations": violations,
            "violation_count": len(violations),
            "high_severity_count": len(high_severity),
            "message": f"Found {len(violations)} policy violations ({len(high_severity)} high severity)"
        }, ocr_context)

    def detect_duplicates(self, **kwargs) -> Dict[str, Any]:
        """
        Detect if receipt is a duplicate of previously submitted receipt.
        
        Args:
            receipt_data: Current receipt
            existing_receipts: Previously submitted receipts
            
        Returns:
            Dict with duplicate detection results
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        existing_receipts = kwargs.get("existing_receipts", [])
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "detect_duplicates",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        if not existing_receipts:
            return self._attach_ocr_context({
                "operation": "detect_duplicates",
                "success": True,
                "is_duplicate": False,
                "message": "No existing receipts to compare against"
            }, ocr_context)
        
        # Create fingerprint of current receipt
        current_fingerprint = self._create_receipt_fingerprint(receipt_data)
        
        # Check against existing receipts
        best_match = None
        highest_similarity = 0.0
        
        for idx, existing in enumerate(existing_receipts):
            existing_fingerprint = self._create_receipt_fingerprint(existing)
            similarity = self._calculate_similarity(current_fingerprint, existing_fingerprint)
            
            if similarity > highest_similarity:
                highest_similarity = similarity
                best_match = {
                    "receipt_index": idx,
                    "receipt_data": existing,
                    "similarity_score": similarity
                }
        
        # Threshold for duplicate detection
        is_duplicate = highest_similarity > 0.85
        
        return self._attach_ocr_context({
            "operation": "detect_duplicates",
            "success": True,
            "is_duplicate": is_duplicate,
            "match": best_match if is_duplicate else None,
            "highest_similarity": highest_similarity,
            "threshold": 0.85,
            "message": f"{'Duplicate detected' if is_duplicate else 'No duplicates found'} (similarity: {highest_similarity:.2%})"
        }, ocr_context)

    def categorize_expense(self, **kwargs) -> Dict[str, Any]:
        """
        Automatically categorize expense based on merchant and items.
        
        Args:
            receipt_data: Receipt data to categorize
            
        Returns:
            Dict with category and confidence
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "categorize_expense",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        merchant = receipt_data.get("merchant_name", "").lower()
        items = receipt_data.get("items", [])
        
        # Score each category
        category_scores = {}
        
        for category, keywords in self.category_keywords.items():
            score = 0
            
            # Check merchant name
            for keyword in keywords:
                if keyword.lower() in merchant:
                    score += 10
            
            # Check item descriptions
            for item in items:
                item_desc = item.get("description", "").lower()
                for keyword in keywords:
                    if keyword.lower() in item_desc:
                        score += 2
            
            category_scores[category] = score
        
        # Get best category
        if max(category_scores.values()) > 0:
            best_category = max(category_scores, key=category_scores.get)
            confidence = min(category_scores[best_category] / 20.0, 1.0)  # Normalize to 0-1
        else:
            best_category = "Other"
            confidence = 0.3
        
        return self._attach_ocr_context({
            "operation": "categorize_expense",
            "success": True,
            "category": best_category,
            "confidence": confidence,
            "category_scores": category_scores,
            "message": f"Categorized as '{best_category}' with {confidence:.0%} confidence"
        }, ocr_context)

    def validate_amounts(self, **kwargs) -> Dict[str, Any]:
        """
        Validate that amounts on receipt are mathematically correct.
        
        Args:
            receipt_data: Receipt data to validate
            
        Returns:
            Dict with validation results
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "validate_amounts",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        issues = []
        
        subtotal = receipt_data.get("subtotal")
        tax = receipt_data.get("tax_amount")
        total = receipt_data.get("total_amount")
        items = receipt_data.get("items", [])
        
        # Validate item total matches subtotal
        if items and subtotal:
            calculated_subtotal = sum(item.get("amount", 0) for item in items)
            if abs(calculated_subtotal - subtotal) > 0.02:  # 2 cent tolerance
                issues.append({
                    "type": "subtotal_mismatch",
                    "description": f"Item total ${calculated_subtotal:.2f} doesn't match subtotal ${subtotal:.2f}",
                    "expected": subtotal,
                    "actual": calculated_subtotal,
                    "difference": abs(calculated_subtotal - subtotal)
                })
        
        # Validate subtotal + tax = total
        if subtotal and tax and total:
            calculated_total = subtotal + tax
            if abs(calculated_total - total) > 0.02:
                issues.append({
                    "type": "total_mismatch",
                    "description": f"Subtotal + Tax ${calculated_total:.2f} doesn't match total ${total:.2f}",
                    "expected": total,
                    "calculated": calculated_total,
                    "difference": abs(calculated_total - total)
                })
        
        # Check for negative amounts
        if total and total < 0:
            issues.append({
                "type": "negative_amount",
                "description": "Receipt total is negative (possible refund?)",
                "amount": total
            })
        
        # Check for unreasonably high amounts
        if total and total > 10000:
            issues.append({
                "type": "unusually_high_amount",
                "description": f"Amount ${total:.2f} is unusually high",
                "amount": total
            })
        
        return self._attach_ocr_context({
            "operation": "validate_amounts",
            "success": True,
            "amounts_valid": len(issues) == 0,
            "issues": issues,
            "issue_count": len(issues),
            "message": f"{'Amounts are valid' if len(issues) == 0 else f'Found {len(issues)} amount issues'}"
        }, ocr_context)

    def verify_merchant(self, **kwargs) -> Dict[str, Any]:
        """
        Verify merchant against known merchant database.
        
        Args:
            receipt_data: Receipt data
            merchant_database: Known merchants
            
        Returns:
            Dict with verification results
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        merchant_db = kwargs.get("merchant_database", [])
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "verify_merchant",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        merchant_name = receipt_data.get("merchant_name", "").lower()
        
        if not merchant_db:
            return self._attach_ocr_context({
                "operation": "verify_merchant",
                "success": True,
                "is_verified": False,
                "verification_status": "no_database",
                "message": "No merchant database provided for verification"
            }, ocr_context)
        
        # Check against known merchants
        is_verified = False
        matched_merchant = None
        
        for known_merchant in merchant_db:
            known_name = known_merchant.get("name", "").lower()
            if known_name in merchant_name or merchant_name in known_name:
                is_verified = True
                matched_merchant = known_merchant
                break
        
        return self._attach_ocr_context({
            "operation": "verify_merchant",
            "success": True,
            "is_verified": is_verified,
            "matched_merchant": matched_merchant,
            "verification_status": "verified" if is_verified else "unverified",
            "message": f"Merchant {'verified' if is_verified else 'not found in database'}"
        }, ocr_context)

    def detect_fraud_indicators(self, **kwargs) -> Dict[str, Any]:
        """
        Detect potential fraud indicators in receipt.
        
        Args:
            receipt_data: Receipt data to analyze
            expense_data: Expense claim data
            
        Returns:
            Dict with fraud score and indicators
        """
        receipt_data, ocr_context = self._get_receipt_data(kwargs)
        expense_data = kwargs.get("expense_data", {})
        
        if not receipt_data:
            return self._attach_ocr_context({
                "operation": "detect_fraud_indicators",
                "success": False,
                "message": "No receipt_data provided"
            }, ocr_context)
        
        fraud_indicators = []
        fraud_score = 0.0
        
        total = receipt_data.get("total_amount", 0)
        
        # Check for suspiciously round numbers
        if total and str(total).endswith('.00') and total >= 100:
            fraud_indicators.append("Suspiciously round amount")
            fraud_score += 0.15
        
        # Check for altered amounts
        claimed = expense_data.get("claimed_amount")
        if claimed and total and claimed > total * 1.1:  # Claimed more than 10% higher
            fraud_indicators.append("Claimed amount significantly exceeds receipt total")
            fraud_score += 0.35
        
        # Check for missing critical fields
        missing_fields = []
        if not receipt_data.get("merchant_name"):
            missing_fields.append("merchant_name")
        if not receipt_data.get("date"):
            missing_fields.append("date")
        if not receipt_data.get("total_amount"):
            missing_fields.append("total_amount")
        
        if len(missing_fields) >= 2:
            fraud_indicators.append(f"Missing critical fields: {', '.join(missing_fields)}")
            fraud_score += 0.25
        
        # Check for weekend/off-hours expenses (for certain categories)
        if receipt_data.get("date"):
            try:
                receipt_date = self._parse_date(receipt_data["date"])
                if receipt_date.weekday() >= 5:  # Weekend
                    category = self.categorize_expense(receipt_data=receipt_data).get("category")
                    if category == "Office Supplies":
                        fraud_indicators.append("Office supply purchase on weekend")
                        fraud_score += 0.1
            except:
                pass
        
        # Check for duplicate-like text patterns
        raw_text = receipt_data.get("raw_text", "")
        if raw_text:
            # Check for copy-paste artifacts
            if "copied from" in raw_text.lower() or "screenshot" in raw_text.lower():
                fraud_indicators.append("Possible screenshot or copied receipt")
                fraud_score += 0.3
        
        # Check for unrealistic itemization
        items = receipt_data.get("items", [])
        if len(items) > 20:
            fraud_indicators.append("Unusually high number of line items")
            fraud_score += 0.1
        
        # Cap fraud score at 1.0
        fraud_score = min(fraud_score, 1.0)
        
        # Determine risk level
        if fraud_score < 0.3:
            risk_level = "low"
        elif fraud_score < 0.6:
            risk_level = "medium"
        else:
            risk_level = "high"
        
        return self._attach_ocr_context({
            "operation": "detect_fraud_indicators",
            "success": True,
            "fraud_score": fraud_score,
            "risk_level": risk_level,
            "fraud_indicators": fraud_indicators,
            "indicator_count": len(fraud_indicators),
            "message": f"Fraud risk: {risk_level} ({fraud_score:.1%} score, {len(fraud_indicators)} indicators)"
        }, ocr_context)

    def generate_analysis_report(self, **kwargs) -> Dict[str, Any]:
        """
        Generate comprehensive analysis report for receipt.
        
        Args:
            receipt_data: Receipt data
            expense_data: Expense claim
            All other parameters for complete analysis
            
        Returns:
            Dict with complete formatted report
        """
        # Run comprehensive analysis
        analysis = self.analyze_receipt(**kwargs)
        
        if not analysis["success"]:
            return analysis
        
        # Format report
        report = {
            "report_generated": datetime.now().isoformat(),
            "receipt_summary": analysis.get("receipt_info"),
            "compliance": {
                "status": analysis.get("compliance_status"),
                "violations": analysis.get("violations", []),
                "warnings": analysis.get("warnings", [])
            },
            "categorization": {
                "category": analysis.get("category"),
                "confidence": analysis.get("category_confidence")
            },
            "fraud_assessment": {
                "score": analysis.get("fraud_score"),
                "indicators": analysis.get("fraud_indicators", [])
            },
            "recommendations": analysis.get("recommendations", []),
            "decision_recommendation": {
                "action": "approve" if analysis["analysis_summary"]["compliant"] else 
                         "reject" if analysis["analysis_summary"]["reject"] else "review",
                "confidence": analysis["analysis_summary"]["confidence_level"],
                "reasoning": self._create_decision_reasoning(analysis)
            }
        }
        
        return {
            "operation": "generate_analysis_report",
            "success": True,
            "report": report,
            "ocr_metadata": analysis.get("ocr_metadata"),
            "warnings": analysis.get("warnings", []),
            "message": f"Generated comprehensive analysis report - Action: {report['decision_recommendation']['action']}"
        }

    # Helper methods

    def _get_receipt_data(self, kwargs: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        if kwargs.get("_receipt_data_cache"):
            return kwargs["_receipt_data_cache"], kwargs.get("_ocr_context_cache", {"ocr_used": False, "warnings": []})

        receipt_data = kwargs.get("receipt_data") or {}
        if receipt_data:
            return receipt_data, {"ocr_used": False, "warnings": []}

        if not self._has_ocr_source(kwargs):
            return {}, {"ocr_used": False, "warnings": []}

        source = self._resolve_ocr_source(kwargs)
        payload = self._extract_receipt_payload(source, kwargs)
        normalized, ocr_context = self._normalize_ocr_payload(payload, source)
        kwargs["_receipt_data_cache"] = normalized
        kwargs["_ocr_context_cache"] = ocr_context
        return normalized, ocr_context

    def _attach_ocr_context(self, result: Dict[str, Any], ocr_context: Dict[str, Any]) -> Dict[str, Any]:
        if not ocr_context.get("ocr_used"):
            return result

        out = dict(result)
        warnings = list(out.get("warnings", []))
        for warning in ocr_context.get("warnings", []):
            if warning not in warnings:
                warnings.append(warning)
        if warnings:
            out["warnings"] = warnings
        out["ocr_metadata"] = {
            "ocr_used": True,
            "confidence_score": ocr_context.get("confidence_score"),
            "source_file": ocr_context.get("source_file"),
            "mime_type": ocr_context.get("mime_type"),
        }
        return out

    def _has_ocr_source(self, kwargs: Dict[str, Any]) -> bool:
        return any(kwargs.get(field) for field in ("file_name", "content_base64", "file_bytes"))

    def _resolve_ocr_source(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        from ..exceptions import DocumentAnalysisError

        file_name = os.path.basename(kwargs.get("file_name") or "uploaded-image")
        mime_type = (kwargs.get("mime_type") or "").strip().lower()
        file_bytes = kwargs.get("file_bytes")
        content_base64 = kwargs.get("content_base64")

        if isinstance(file_bytes, str):
            try:
                file_bytes = base64.b64decode(file_bytes, validate=False)
            except Exception as exc:
                raise DocumentAnalysisError(
                    message=f"Invalid file_bytes payload: {exc}",
                    error_code="INVALID_FILE_BYTES",
                    recovery_hint="Provide raw bytes or a base64-encoded string",
                )

        if not file_bytes and content_base64:
            try:
                file_bytes = base64.b64decode(content_base64, validate=False)
            except Exception as exc:
                raise DocumentAnalysisError(
                    message=f"Invalid content_base64 payload: {exc}",
                    error_code="INVALID_BASE64",
                    recovery_hint="Provide valid base64 file content",
                )

        if not file_bytes and file_name:
            file_bytes = self._resolve_bytes_from_uploads(file_name)

        if not file_bytes:
            raise DocumentAnalysisError(
                message=(
                    f"No file content found for '{file_name}'. Pass content_base64/file_bytes, "
                    "or upload the document in the app chat first."
                ),
                error_code="EMPTY_OCR_PAYLOAD",
                details={"file_name": file_name},
                recovery_hint="Upload the document file first or pass base64 content",
            )

        if len(file_bytes) > self.ocr_max_file_size:
            raise DocumentAnalysisError(
                message=(
                    f"Document file size {len(file_bytes)} bytes exceeds OCR limit "
                    f"{self.ocr_max_file_size} bytes"
                ),
                error_code="OCR_FILE_TOO_LARGE",
                details={
                    "file_name": file_name,
                    "file_size_bytes": len(file_bytes),
                    "max_size_bytes": self.ocr_max_file_size,
                },
                recovery_hint="Reduce image size or upload a smaller file",
            )

        mime_type = self._normalize_document_mime_type(file_name, mime_type)

        if not self._is_supported_document_upload(file_name, mime_type):
            raise DocumentAnalysisError(
                message="Document analysis extraction supports only image, PDF, and DOCX uploads",
                error_code="OCR_UNSUPPORTED_DOCUMENT",
                details={
                    "file_name": file_name,
                    "mime_type": mime_type,
                    "supported_mime_types": sorted(self.supported_image_mime_types | self.supported_document_mime_types),
                    "supported_extensions": sorted(self.supported_image_extensions | self.supported_document_extensions),
                },
                recovery_hint="Upload a supported image, PDF, or DOCX file, or provide receipt_data directly",
            )

        if not mime_type:
            mime_type = self._infer_mime_type(file_name)

        return {
            "file_name": file_name,
            "mime_type": mime_type,
            "file_bytes": file_bytes,
        }

    def _resolve_bytes_from_uploads(self, file_name: str) -> Optional[bytes]:
        safe_name = os.path.basename(file_name or "")
        if not safe_name:
            return None

        safe_norm = safe_name.strip().lower()
        backend_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        roots = []
        env_dir = os.getenv("APP_UPLOADS_DIR")
        if env_dir:
            roots.append(os.path.abspath(env_dir))
        roots.append(os.path.join(backend_root, "apps", "appmgr", "uploads"))

        seen = set()
        for base in roots:
            if not base or base in seen or not os.path.isdir(base):
                continue
            seen.add(base)
            for dirpath, _, filenames in os.walk(base):
                for candidate in filenames:
                    if candidate.strip().lower().endswith(safe_norm):
                        path = os.path.join(dirpath, candidate)
                        try:
                            with open(path, "rb") as handle:
                                return handle.read()
                        except OSError:
                            continue
        return None

    def _normalize_document_mime_type(self, file_name: str, mime_type: str) -> str:
        ext = os.path.splitext(file_name or "")[1].lower()
        mime = (mime_type or "").lower().split(";", 1)[0].strip()

        if (
            ext in self.supported_image_extensions
            or ext in DEFAULT_IMAGE_EXTENSIONS
            or ext in self.supported_document_extensions
            or ext in DEFAULT_DOCUMENT_EXTENSIONS
        ):
            inferred = self._infer_mime_type(file_name)
            if inferred != "application/octet-stream":
                return inferred
        return mime

    def _is_supported_document_upload(self, file_name: str, mime_type: str) -> bool:
        ext = os.path.splitext(file_name or "")[1].lower()
        mime = (mime_type or "").lower().split(";", 1)[0].strip()
        if (
            ext in self.supported_image_extensions
            or ext in DEFAULT_IMAGE_EXTENSIONS
            or ext in self.supported_document_extensions
            or ext in DEFAULT_DOCUMENT_EXTENSIONS
        ):
            return True
        if mime:
            if mime in self.supported_document_mime_types:
                return True
            return mime in self.supported_image_mime_types or mime.startswith("image/")
        return False

    def _is_docx_upload(self, file_name: str, mime_type: str) -> bool:
        ext = os.path.splitext(file_name or "")[1].lower()
        mime = (mime_type or "").lower().split(";", 1)[0].strip()
        return ext == ".docx" or mime == DOCX_MIME_TYPE

    def _infer_mime_type(self, file_name: str) -> str:
        ext = os.path.splitext(file_name or "")[1].lower()
        mapping = {
            ".pdf": "application/pdf",
            ".docx": DOCX_MIME_TYPE,
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".bmp": "image/bmp",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
            ".gif": "image/gif",
        }
        return mapping.get(ext, "application/octet-stream")

    def _extract_receipt_payload(self, source: Dict[str, Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        from ..exceptions import DocumentAnalysisError

        extraction_result = self._extract_document_text(source, kwargs)
        if not extraction_result.get("success"):
            raise DocumentAnalysisError(
                message=extraction_result.get("message") or "Document extraction failed",
                error_code="OCR_EXTRACTION_FAILED",
                details={"extraction_result": extraction_result},
                recovery_hint="Verify the uploaded image or PDF is readable and supported",
            )

        extracted_text = (extraction_result.get("extracted_text") or "").strip()
        if not extracted_text:
            raise DocumentAnalysisError(
                message="Document extraction returned no readable text",
                error_code="OCR_EMPTY_TEXT",
                details={"file_name": source.get("file_name"), "mime_type": source.get("mime_type")},
                recovery_hint="Upload a clearer scan or provide receipt_data directly",
            )

        structured = self._structure_receipt_text(extracted_text, kwargs)
        raw_payload = structured if isinstance(structured, dict) else {}
        payload = {
            "receipt_data": raw_payload if raw_payload else {},
            "raw_text": extracted_text,
            "extracted_text": extracted_text,
            "confidence_score": extraction_result.get("confidence_score"),
            "warnings": list(extraction_result.get("warnings") or []),
            "metadata": extraction_result.get("metadata") or {},
        }
        if isinstance(structured, str) and structured.strip():
            payload["warnings"].append("Receipt structuring model returned plain text instead of JSON")
            payload["raw_text"] = structured.strip()
        return payload

    def _extract_document_text(self, source: Dict[str, Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        from ..exceptions import DocumentAnalysisError

        if self._is_docx_upload(source.get("file_name", ""), source.get("mime_type", "")):
            return self._extract_docx_text(source)

        if not self.ocr_service:
            raise DocumentAnalysisError(
                message="OCR service is not available for document analysis",
                error_code="OCR_SERVICE_UNAVAILABLE",
                recovery_hint="Ensure MarkItDown OCR dependencies are installed for AgentTools.ocr_markitdown.service",
            )

        extraction_kwargs = {
            "file_bytes": source["file_bytes"],
            "image_path": source.get("file_name"),
            "language": kwargs.get("language", "eng"),
            "preprocessing": kwargs.get("preprocessing", True),
            "confidence_threshold": kwargs.get(
                "confidence_threshold",
                self.ocr_confidence_warning_threshold,
            ),
        }
        try:
            return self.ocr_service.extract_text(**extraction_kwargs)
        except ModuleNotFoundError as exc:
            raise DocumentAnalysisError(
                message=f"Document extraction dependency is missing: {exc}",
                error_code="OCR_DEPENDENCY_MISSING",
                recovery_hint="Install the MarkItDown OCR dependencies required by AgentTools.ocr_markitdown.service",
            )

    def _extract_docx_text(self, source: Dict[str, Any]) -> Dict[str, Any]:
        from ..exceptions import DocumentAnalysisError

        try:
            from ..file_reader.parsers.docx_parser import DocxParser
        except ModuleNotFoundError as exc:
            raise DocumentAnalysisError(
                message=f"DOCX extraction dependency is missing: {exc}",
                error_code="DOCX_DEPENDENCY_MISSING",
                recovery_hint="Install the DOCX parsing dependencies required by AgentTools.file_reader",
            )

        try:
            parsed = DocxParser().parse(source["file_bytes"])
        except Exception as exc:
            raise DocumentAnalysisError(
                message=f"DOCX extraction failed: {exc}",
                error_code="DOCX_EXTRACTION_FAILED",
                details={"file_name": source.get("file_name")},
                recovery_hint="Verify the uploaded DOCX file is valid and readable",
            )

        extracted_text = str(parsed.get("content") or "").strip()
        metadata = parsed.get("metadata") if isinstance(parsed.get("metadata"), dict) else {}
        statistics = parsed.get("statistics") if isinstance(parsed.get("statistics"), dict) else {}

        return {
            "operation": "extract_text",
            "success": True,
            "extracted_text": extracted_text,
            "confidence_score": 1.0 if extracted_text else 0.0,
            "character_count": len(extracted_text),
            "line_count": extracted_text.count("\n") + 1 if extracted_text else 0,
            "metadata": {
                "parser": "docx",
                "docx_metadata": metadata,
                "statistics": statistics,
            },
            "warnings": [],
            "message": f"Extracted {len(extracted_text):,} characters from DOCX",
        }

    def _structure_receipt_text(self, extracted_text: str, kwargs: Dict[str, Any]) -> Any:
        from ..exceptions import DocumentAnalysisError
        from echolib.llm_resolver import resolve_and_build_llm_sync

        user_question = str(kwargs.get("user_question") or kwargs.get("ocr_prompt") or "").strip()
        user_text = self.doc_config.ocr_json_instruction
        if user_question:
            user_text = (
                f"{user_text}\n\n"
                f"Additional user intent to consider while extracting: {user_question}"
            )

        prompt = (
            f"{self.doc_config.ocr_system_prompt}\n\n"
            f"{user_text}\n\n"
            "Receipt text to structure:\n"
            "---\n"
            f"{extracted_text}\n"
            "---"
        )

        try:
            llm = resolve_and_build_llm_sync(
                temperature=self.doc_config.ocr_temperature,
                max_tokens=self.doc_config.ocr_llm_max_tokens,
            )
        except Exception as exc:
            raise DocumentAnalysisError(
                message=f"Shared LLM is not available for receipt structuring: {exc}",
                error_code="OCR_LLM_UNAVAILABLE",
                recovery_hint="Verify the default LLM configuration used by the application",
            )

        try:
            response = llm.invoke(prompt)
        except Exception as exc:
            raise DocumentAnalysisError(
                message=f"Receipt structuring failed: {exc}",
                error_code="OCR_LLM_REQUEST_FAILED",
                recovery_hint="Retry with a clearer document or verify the shared LLM deployment",
            )

        content = getattr(response, "content", response)
        return self._extract_structured_content(content)

    def _normalize_ocr_payload(self, payload: Dict[str, Any], source: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        from ..exceptions import DocumentAnalysisError

        if not isinstance(payload, dict):
            raise DocumentAnalysisError(
                message="OCR API returned an invalid payload",
                error_code="OCR_INVALID_PAYLOAD",
                details={"payload_type": type(payload).__name__},
                recovery_hint="Return a JSON object with receipt fields or a receipt_data object",
            )

        if payload.get("success") is False:
            raise DocumentAnalysisError(
                message=payload.get("message") or payload.get("error") or "OCR extraction failed",
                error_code="OCR_EXTRACTION_FAILED",
                details={"ocr_payload": payload},
            )

        payload = self._unwrap_chat_completion_payload(payload)

        raw_receipt = payload.get("receipt_data") if isinstance(payload.get("receipt_data"), dict) else payload
        line_items = raw_receipt.get("items") or raw_receipt.get("line_items") or []
        normalized = {
            "merchant_name": raw_receipt.get("merchant_name") or raw_receipt.get("merchant") or raw_receipt.get("vendor_name"),
            "date": raw_receipt.get("date") or raw_receipt.get("transaction_date"),
            "total_amount": raw_receipt.get("total_amount") or raw_receipt.get("total") or raw_receipt.get("amount"),
            "subtotal": raw_receipt.get("subtotal") or raw_receipt.get("subtotal_amount"),
            "tax_amount": raw_receipt.get("tax_amount") or raw_receipt.get("tax"),
            "items": line_items,
            "currency": raw_receipt.get("currency"),
            "raw_text": raw_receipt.get("raw_text") or raw_receipt.get("extracted_text") or raw_receipt.get("text") or payload.get("extracted_text") or payload.get("raw_text"),
        }

        warnings = list(payload.get("warnings") or [])
        confidence_score = (
            payload.get("confidence_score")
            or raw_receipt.get("confidence_score")
            or payload.get("overall_confidence")
        )
        missing_fields = [
            field_name for field_name in ("merchant_name", "date", "total_amount", "raw_text")
            if not normalized.get(field_name)
        ]
        if missing_fields:
            warnings.append(
                f"OCR returned partial receipt data; missing fields: {', '.join(missing_fields)}"
            )
        if confidence_score is not None:
            try:
                confidence_value = float(confidence_score)
            except (TypeError, ValueError):
                confidence_value = None
            if confidence_value is not None and confidence_value < self.ocr_confidence_warning_threshold:
                warnings.append(
                    f"OCR confidence is low ({confidence_value:.0%}); review extracted fields before approval"
                )
            confidence_score = confidence_value

        return normalized, {
            "ocr_used": True,
            "warnings": warnings,
            "confidence_score": confidence_score,
            "source_file": source.get("file_name"),
            "mime_type": source.get("mime_type"),
        }

    def _unwrap_chat_completion_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        choices = payload.get("choices")
        if not isinstance(choices, list) or not choices:
            return payload

        first_choice = choices[0] if isinstance(choices[0], dict) else {}
        message = first_choice.get("message") if isinstance(first_choice.get("message"), dict) else {}
        content = message.get("content")
        parsed = self._extract_structured_content(content)
        if isinstance(parsed, dict):
            if "raw_text" not in parsed and isinstance(content, str):
                parsed["raw_text"] = content
            if "confidence_score" not in parsed:
                parsed["confidence_score"] = payload.get("confidence_score")
            return parsed
        return {
            "raw_text": parsed if isinstance(parsed, str) else str(content or ""),
            "confidence_score": payload.get("confidence_score"),
        }

    def _extract_structured_content(self, content: Any) -> Any:
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text" and isinstance(item.get("text"), str):
                        text_parts.append(item["text"])
                    elif isinstance(item.get("content"), str):
                        text_parts.append(item["content"])
                elif isinstance(item, str):
                    text_parts.append(item)
            content = "\n".join(part for part in text_parts if part).strip()

        if not isinstance(content, str):
            return content

        text = content.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text).strip()

        try:
            return json.loads(text)
        except Exception:
            pass

        json_match = re.search(r"\{.*\}", text, re.DOTALL)
        if json_match:
            candidate = json_match.group(0)
            try:
                return json.loads(candidate)
            except Exception:
                try:
                    return ast.literal_eval(candidate)
                except Exception:
                    pass

        try:
            return ast.literal_eval(text)
        except Exception:
            return text

    def _create_receipt_fingerprint(self, receipt: Dict[str, Any]) -> str:
        """Create a unique fingerprint for duplicate detection."""
        # Combine key fields
        fingerprint_data = f"{receipt.get('merchant_name', '')}" \
                          f"{receipt.get('date', '')}" \
                          f"{receipt.get('total_amount', 0):.2f}"
        
        return hashlib.md5(fingerprint_data.encode()).hexdigest()

    def _calculate_similarity(self, fp1: str, fp2: str) -> float:
        """Calculate similarity between two fingerprints."""
        # Simple exact match for demo (in production, use fuzzy matching)
        return 1.0 if fp1 == fp2 else 0.0

    def _parse_date(self, date_str: str) -> datetime:
        """Parse date string to datetime object."""
        # Try common formats
        formats = ["%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y", "%d/%m/%Y"]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt)
            except:
                continue
        
        raise ValueError(f"Could not parse date: {date_str}")

    def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on analysis results."""
        recommendations = []
        
        # Based on violations
        violations = analysis.get("violations", [])
        for violation in violations:
            if violation["type"] == "exceeds_meal_limit":
                recommendations.append("Consider splitting meal expenses if shared with clients")
            elif violation["type"] == "amount_mismatch":
                recommendations.append("Verify claimed amount matches receipt total")
            elif violation["type"] == "expense_too_old":
                recommendations.append("Submit expenses within policy timeframe")
            elif violation["type"] == "blacklisted_merchant":
                recommendations.append("This merchant type is not allowed per policy")
        
        # Based on fraud score
        fraud_score = analysis.get("fraud_score", 0)
        if fraud_score > 0.7:
            recommendations.append("Manual review required due to fraud indicators")
        elif fraud_score > 0.4:
            recommendations.append("Additional documentation may be requested")
        
        # Based on compliance
        if analysis.get("compliance_status") == "non_compliant":
            recommendations.append("Expense does not meet policy requirements - approval unlikely")
        elif analysis.get("compliance_status") == "requires_review":
            recommendations.append("Manager approval required for policy exceptions")
        
        return recommendations

    def _create_summary_message(self, analysis: Dict[str, Any]) -> str:
        """Create human-readable summary message."""
        status = analysis.get("compliance_status")
        violations = len(analysis.get("violations", []))
        fraud_score = analysis.get("fraud_score", 0)
        
        if status == "compliant":
            return f"Receipt is compliant with all policies"
        elif status == "flagged":
            return f"Receipt flagged for review - high fraud risk ({fraud_score:.0%})"
        elif status == "non_compliant":
            return f"Receipt has {violations} policy violations - approval required"
        else:
            return f"Receipt requires review - {violations} issues found"

    def _create_decision_reasoning(self, analysis: Dict[str, Any]) -> str:
        """Create reasoning for decision recommendation."""
        reasons = []
        
        if analysis["analysis_summary"]["compliant"]:
            reasons.append("All policy requirements met")
        
        violations = analysis.get("violations", [])
        if violations:
            high_sev = [v for v in violations if v.get("severity") == "high"]
            if high_sev:
                reasons.append(f"{len(high_sev)} high-severity violations")
        
        fraud_score = analysis.get("fraud_score", 0)
        if fraud_score > 0.6:
            reasons.append(f"High fraud risk ({fraud_score:.0%})")
        
        return "; ".join(reasons) if reasons else "Standard processing"


# For testing
if __name__ == "__main__":
    service = DocumentAnalysisService()
    
    # Test with sample receipt data
    sample_receipt = {
        "merchant_name": "Starbucks Coffee",
        "date": "03/15/2024",
        "total_amount": 45.50,
        "subtotal": 42.06,
        "tax_amount": 3.44,
        "items": [
            {"description": "Grande Latte", "amount": 4.95, "quantity": 1},
            {"description": "Croissant", "amount": 3.45, "quantity": 1}
        ]
    }
    
    result = service.execute(
        operation="analyze_receipt",
        receipt_data=sample_receipt,
        expense_data={"claimed_amount": 45.50}
    )
    
    print(json.dumps(result, indent=2))
