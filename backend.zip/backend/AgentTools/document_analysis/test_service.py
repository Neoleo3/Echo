"""
Unit tests for Document Analysis Service
"""

import unittest
import sys
import os
from unittest.mock import patch, MagicMock
sys.path.insert(0, os.path.dirname(__file__))
from service import DocumentAnalysisService


class TestDocumentAnalysisService(unittest.TestCase):
    """Test cases for Document Analysis operations"""

    def setUp(self):
        """Set up test fixtures"""
        self.service = DocumentAnalysisService()
        self.sample_receipt = {
            "merchant_name": "Walmart",
            "date": "03/15/2024",
            "total_amount": 50.00,
            "subtotal": 46.30,
            "tax_amount": 3.70,
            "items": [
                {"description": "Milk", "amount": 3.99, "quantity": 1},
                {"description": "Bread", "amount": 2.49, "quantity": 1}
            ],
            "raw_text": "Sample receipt text"
        }

    def test_check_policy_compliance_compliant(self):
        """Test policy check for compliant receipt"""
        result = self.service.execute(
            operation="check_policy_compliance",
            receipt_data=self.sample_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertIn(result["compliance_status"], ["compliant", "requires_review", "non_compliant"])

    def test_check_policy_compliance_exceeds_limit(self):
        """Test policy check when amount exceeds limit"""
        expensive_receipt = self.sample_receipt.copy()
        expensive_receipt["total_amount"] = 2000.00
        
        result = self.service.execute(
            operation="check_policy_compliance",
            receipt_data=expensive_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertGreater(result["violation_count"], 0)

    def test_detect_duplicates_no_duplicates(self):
        """Test duplicate detection with no matches"""
        result = self.service.execute(
            operation="detect_duplicates",
            receipt_data=self.sample_receipt,
            existing_receipts=[]
        )
        
        self.assertTrue(result["success"])
        self.assertFalse(result["is_duplicate"])

    def test_detect_duplicates_with_match(self):
        """Test duplicate detection with matching receipt"""
        result = self.service.execute(
            operation="detect_duplicates",
            receipt_data=self.sample_receipt,
            existing_receipts=[self.sample_receipt]
        )
        
        self.assertTrue(result["success"])
        self.assertTrue(result["is_duplicate"])

    def test_categorize_expense_meals(self):
        """Test expense categorization for meals"""
        meal_receipt = self.sample_receipt.copy()
        meal_receipt["merchant_name"] = "Starbucks Coffee"
        
        result = self.service.execute(
            operation="categorize_expense",
            receipt_data=meal_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertEqual(result["category"], "Meals")
        self.assertGreater(result["confidence"], 0.5)

    def test_categorize_expense_transportation(self):
        """Test categorization for transportation"""
        transport_receipt = {
            "merchant_name": "Uber Technologies",
            "total_amount": 25.00
        }
        
        result = self.service.execute(
            operation="categorize_expense",
            receipt_data=transport_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertEqual(result["category"], "Transportation")

    def test_validate_amounts_valid(self):
        """Test amount validation with valid amounts"""
        result = self.service.execute(
            operation="validate_amounts",
            receipt_data=self.sample_receipt
        )
        
        self.assertTrue(result["success"])

    def test_validate_amounts_mismatch(self):
        """Test amount validation with mismatched total"""
        invalid_receipt = self.sample_receipt.copy()
        invalid_receipt["total_amount"] = 100.00  # Doesn't match subtotal + tax
        
        result = self.service.execute(
            operation="validate_amounts",
            receipt_data=invalid_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertGreater(result["issue_count"], 0)

    def test_verify_merchant_verified(self):
        """Test merchant verification with known merchant"""
        merchant_db = [
            {"name": "Walmart", "category": "Retail"},
            {"name": "Starbucks", "category": "Restaurant"}
        ]
        
        result = self.service.execute(
            operation="verify_merchant",
            receipt_data=self.sample_receipt,
            merchant_database=merchant_db
        )
        
        self.assertTrue(result["success"])
        self.assertTrue(result["is_verified"])

    def test_verify_merchant_unverified(self):
        """Test merchant verification with unknown merchant"""
        merchant_db = [{"name": "Other Store", "category": "Retail"}]
        
        result = self.service.execute(
            operation="verify_merchant",
            receipt_data=self.sample_receipt,
            merchant_database=merchant_db
        )
        
        self.assertTrue(result["success"])
        self.assertFalse(result["is_verified"])

    def test_detect_fraud_indicators_clean(self):
        """Test fraud detection on clean receipt"""
        result = self.service.execute(
            operation="detect_fraud_indicators",
            receipt_data=self.sample_receipt
        )
        
        self.assertTrue(result["success"])
        self.assertLess(result["fraud_score"], 0.5)

    def test_detect_fraud_indicators_suspicious(self):
        """Test fraud detection with suspicious indicators"""
        suspicious_receipt = self.sample_receipt.copy()
        suspicious_receipt["total_amount"] = 100.00  # Round number
        
        result = self.service.execute(
            operation="detect_fraud_indicators",
            receipt_data=suspicious_receipt,
            expense_data={"claimed_amount": 150.00}  # Much higher than receipt
        )
        
        self.assertTrue(result["success"])
        self.assertGreater(len(result["fraud_indicators"]), 0)

    def test_analyze_receipt_comprehensive(self):
        """Test comprehensive receipt analysis"""
        result = self.service.execute(
            operation="analyze_receipt",
            receipt_data=self.sample_receipt,
            expense_data={"claimed_amount": 50.00}
        )
        
        self.assertTrue(result["success"])
        self.assertIn("compliance_status", result)
        self.assertIn("category", result)
        self.assertIn("fraud_score", result)

    def test_generate_analysis_report(self):
        """Test analysis report generation"""
        result = self.service.execute(
            operation="generate_analysis_report",
            receipt_data=self.sample_receipt,
            expense_data={"claimed_amount": 50.00}
        )
        
        self.assertTrue(result["success"])
        self.assertIn("report", result)
        self.assertIn("decision_recommendation", result["report"])

    def test_invalid_operation(self):
        """Test with invalid operation"""
        result = self.service.execute(
            operation="invalid_operation"
        )
        
        self.assertFalse(result["success"])

    def test_missing_receipt_data(self):
        """Test operations without receipt data"""
        result = self.service.execute(
            operation="analyze_receipt"
        )
        
        self.assertFalse(result["success"])


class TestPolicyChecks(unittest.TestCase):
    """Test policy compliance checks"""

    def setUp(self):
        self.service = DocumentAnalysisService()

    def test_meal_limit_exceeded(self):
        """Test meal expense exceeding limit"""
        receipt = {
            "merchant_name": "Expensive Restaurant",
            "total_amount": 100.00,
            "date": "03/15/2024"
        }
        
        result = self.service.execute(
            operation="check_policy_compliance",
            receipt_data=receipt
        )
        
        violations = [v for v in result["violations"] if v["type"] == "exceeds_meal_limit"]
        self.assertGreater(len(violations), 0)

    def test_blacklisted_merchant(self):
        """Test blacklisted merchant detection"""
        receipt = {
            "merchant_name": "Casino Hotel",
            "total_amount": 50.00,
            "date": "03/15/2024"
        }
        
        result = self.service.execute(
            operation="check_policy_compliance",
            receipt_data=receipt
        )
        
        violations = [v for v in result["violations"] if v["type"] == "blacklisted_merchant"]
        self.assertGreater(len(violations), 0)


class TestOCRAndUploadFlow(unittest.TestCase):
    """Test OCR extraction and file upload routing."""

    def setUp(self):
        self.service = DocumentAnalysisService()
        self.sample_receipt = {
            "merchant_name": "Walmart",
            "date": "03/15/2024",
            "total_amount": 50.00,
            "subtotal": 46.30,
            "tax_amount": 3.70,
            "items": [
                {"description": "Milk", "amount": 3.99, "quantity": 1},
            ],
            "raw_text": "Walmart receipt text",
        }

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_analyze_receipt_runs_ocr_for_uploaded_image(self, mock_ocr):
        """Analyze receipt should auto-run OCR when only an image upload is provided."""
        mock_ocr.return_value = {
            "success": True,
            "receipt_data": {
                "merchant_name": "Starbucks Coffee",
                "date": "03/15/2024",
                "total_amount": 12.5,
                "subtotal": 11.5,
                "tax_amount": 1.0,
                "items": [{"description": "Coffee", "amount": 12.5, "quantity": 1}],
                "raw_text": "Starbucks Coffee 03/15/2024 total 12.50",
            },
            "confidence_score": 0.92,
        }
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.png",
            mime_type="image/png",
            content_base64="ZmFrZS1pbWFnZS1ieXRlcw==",
            expense_data={"claimed_amount": 12.5},
        )
        self.assertTrue(result["success"])
        self.assertEqual(result["receipt_info"]["merchant"], "Starbucks Coffee")
        self.assertTrue(result["ocr_metadata"]["ocr_used"])
        mock_ocr.assert_called_once()

    def test_analyze_receipt_rejects_unsupported_upload_for_extraction(self):
        """Extraction path should reject unsupported uploads outside image/PDF/DOCX."""
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.txt",
            mime_type="text/plain",
            content_base64="c29tZS10ZXh0",
        )
        self.assertFalse(result["success"])
        self.assertEqual(result["error_type"], "DocumentAnalysisError")
        self.assertIn("docx", result["error"].lower())

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_existing_receipt_data_skips_ocr(self, mock_ocr):
        """Existing structured receipt_data should bypass OCR entirely."""
        result = self.service.execute(
            operation="analyze_receipt",
            receipt_data=self.sample_receipt,
            file_name="receipt.png",
            mime_type="image/png",
        )
        self.assertTrue(result["success"])
        mock_ocr.assert_not_called()

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_low_confidence_ocr_adds_warning(self, mock_ocr):
        """Low OCR confidence should surface as a warning, not a hard failure."""
        mock_ocr.return_value = {
            "success": True,
            "receipt_data": {
                "merchant_name": "Walmart",
                "date": "03/15/2024",
                "total_amount": 50.0,
                "subtotal": 46.3,
                "tax_amount": 3.7,
                "items": [{"description": "Milk", "amount": 3.99, "quantity": 1}],
                "raw_text": "Walmart receipt text",
            },
            "confidence_score": 0.4,
        }
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.jpg",
            mime_type="image/jpeg",
            content_base64="ZmFrZS1pbWFnZS1ieXRlcw==",
        )
        self.assertTrue(result["success"])
        self.assertTrue(any("confidence is low" in w.lower() for w in result["warnings"]))

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_analyze_receipt_accepts_pdf_upload(self, mock_extract):
        """PDF uploads should route through internal extraction."""
        mock_extract.return_value = {
            "success": True,
            "receipt_data": {
                "merchant_name": "Hotel Example",
                "date": "03/15/2024",
                "total_amount": 250.0,
                "subtotal": 230.0,
                "tax_amount": 20.0,
                "items": [],
                "raw_text": "Hotel Example total 250.00",
            },
            "confidence_score": 0.88,
        }
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.pdf",
            mime_type="application/pdf",
            content_base64="JVBERi0xLjQK",
            expense_data={"claimed_amount": 250.0},
        )
        self.assertTrue(result["success"])
        self.assertEqual(result["receipt_info"]["merchant"], "Hotel Example")
        self.assertTrue(result["ocr_metadata"]["ocr_used"])
        mock_extract.assert_called_once()

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_analyze_receipt_accepts_docx_upload(self, mock_extract):
        """DOCX uploads should route through internal extraction."""
        mock_extract.return_value = {
            "success": True,
            "receipt_data": {
                "merchant_name": "Cafe Example",
                "date": "03/15/2024",
                "total_amount": 18.5,
                "subtotal": 17.0,
                "tax_amount": 1.5,
                "items": [],
                "raw_text": "Cafe Example total 18.50",
            },
            "confidence_score": 1.0,
        }
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.docx",
            mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            content_base64="ZmFrZS1kb2N4LWJ5dGVz",
            expense_data={"claimed_amount": 18.5},
        )
        self.assertTrue(result["success"])
        self.assertEqual(result["receipt_info"]["merchant"], "Cafe Example")
        self.assertTrue(result["ocr_metadata"]["ocr_used"])
        mock_extract.assert_called_once()

    @patch.object(DocumentAnalysisService, "_extract_receipt_payload")
    def test_analyze_receipt_accepts_docx_upload_with_generic_mime(self, mock_extract):
        """DOCX uploads should still be accepted when clients send a generic MIME type."""
        mock_extract.return_value = {
            "success": True,
            "receipt_data": {
                "merchant_name": "Cafe Example",
                "date": "03/15/2024",
                "total_amount": 18.5,
                "subtotal": 17.0,
                "tax_amount": 1.5,
                "items": [],
                "raw_text": "Cafe Example total 18.50",
            },
            "confidence_score": 1.0,
        }
        result = self.service.execute(
            operation="analyze_receipt",
            file_name="receipt.docx",
            mime_type="application/octet-stream",
            content_base64="ZmFrZS1kb2N4LWJ5dGVz",
        )
        self.assertTrue(result["success"])
        self.assertEqual(result["receipt_info"]["merchant"], "Cafe Example")
        mock_extract.assert_called_once()


def run_tests():
    """Run all tests"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    suite.addTests(loader.loadTestsFromTestCase(TestDocumentAnalysisService))
    suite.addTests(loader.loadTestsFromTestCase(TestPolicyChecks))
    suite.addTests(loader.loadTestsFromTestCase(TestOCRAndUploadFlow))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
