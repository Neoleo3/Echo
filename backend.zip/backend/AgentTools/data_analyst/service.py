"""
Data Analyst Tool — Queries tabular data (Excel/CSV) and generates charts.

WHY: Uploaded Excel/CSV files converted to text chunks lose computational
accuracy. This tool runs pandas queries on the actual DataFrames, enabling
accurate statistics, comparisons, and computation. It also generates charts
via matplotlib/seaborn and saves them as PNG files for the download system.

DESCRIPTION-GATED: Only fires when the user explicitly asks about data in an
uploaded tabular file or requests a chart/graph/visualization.
"""

import logging
import os
import re
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool definition (used by the auto-bind registry)
# ---------------------------------------------------------------------------

TOOL_DEFINITION = {
    "tool_id": "data_analyst",
    "name": "Data Analyst — Excel/CSV Query, Chart & Transform",
    "description": (
        "Use this tool when the user asks questions about uploaded Excel or CSV data, "
        "requests data analysis, computations, statistics, or asks for charts, graphs, "
        "or visualizations from tabular data. This tool runs pandas queries on the "
        "actual uploaded data (not text summaries) and can generate matplotlib charts. "
        "It can also transform data (normalize, standardize, apply formulas) and export "
        "the result as a downloadable Excel file when export_to_excel is set to true. "
        "Do NOT use this tool for non-tabular files (PDFs, Word docs). "
        "Do NOT use this tool unless the user's question is about data in an "
        "uploaded Excel/CSV file or they explicitly ask for a chart/graph/transformation."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language question about the data or transformation instruction",
            },
            "generate_chart": {
                "type": "boolean",
                "description": (
                    "Whether to generate a chart/visualization. Set true when user "
                    "asks for graph, chart, plot, visualization, or visual representation."
                ),
                "default": False,
            },
            "chart_type": {
                "type": "string",
                "enum": ["bar", "line", "pie", "scatter", "heatmap", "histogram", "box"],
                "description": (
                    "Type of chart to generate. Only used if generate_chart is true. "
                    "If unsure, omit and the agent will choose."
                ),
            },
            "export_to_excel": {
                "type": "boolean",
                "description": (
                    "Set true ONLY when the user asks for a transformed/modified Excel "
                    "file back (e.g., normalize columns, standardize data, apply formulas "
                    "and return the result as a downloadable Excel). When true, the tool "
                    "applies transformations directly to the DataFrame and saves the "
                    "result as a downloadable .xlsx file."
                ),
                "default": False,
            },
        },
        "required": ["query"],
    },
    "capabilities": ["data_analysis", "excel_query", "csv_query", "chart_generation", "visualization", "data_transformation", "excel_export"],
}


class DataAnalystService:
    """
    Queries uploaded Excel/CSV files using pandas and generates matplotlib charts.

    WHY: The langchain-experimental pandas agent executes Python code directly on
    DataFrames, enabling accurate computation unlike text-chunk RAG retrieval.
    Charts are saved to disk and registered with the download system.
    """

    def __init__(self, output_dir: str = None) -> None:
        """
        Initialize with the directory where chart images will be saved.

        Args:
            output_dir: Absolute path for saving generated chart PNG files.
        """
        self.output_dir = output_dir or os.path.join("uploads", "generated", "charts")
        os.makedirs(self.output_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Entry point for ToolExecutor (generic registry path)
    # ------------------------------------------------------------------

    def analyze(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Entry point called by ToolExecutor via the generic registry path.

        Args:
            input_data: Dict with keys: query, generate_chart, chart_type,
                export_to_excel.
            context: Execution context from the caller. Two keys are read:
                ``tabular_files`` -- the spreadsheets this session uploaded --
                and ``user_id`` / ``app_id`` for credential resolution.

        Returns:
            Dict with answer (including GENERATED_FILE marker if chart created),
            plus optional chart_path / chart_filename / chart_file_id.

        Two things changed in Phase 9, both correctness rather than features:

        **Files come from the caller when the caller knows them.** Directory
        discovery scans shared upload roots, so it can surface a spreadsheet
        another session uploaded — it only ever behaved correctly because the
        one caller that had session state (the CrewAI application executor)
        bypassed this method entirely and injected files into a tool closure.
        With that executor gone, the session's files arrive on the context and
        discovery is the fallback for callers that genuinely have none, such as
        a workflow node chaining a previously generated sheet.

        **The LLM is resolved for the calling user.** ``resolve_and_build_llm_sync()``
        with no arguments skips the user's own credential and runs on platform
        secrets — the same defect as Finding 16.
        """
        from echolib.llm_resolver import resolve_and_build_llm_sync

        ctx = context or {}

        llm = resolve_and_build_llm_sync(
            user_id=ctx.get("user_id"),
            app_id=ctx.get("app_id"),
            component="data_analyst_tool",
            # Pandas code generation, not prose. The deleted CrewAI wrapper used
            # 0.0 here while this path silently used the 0.7 default, so the same
            # tool was more likely to invent a column name inside a workflow than
            # inside an application.
            temperature=0.0,
        )

        file_paths = self._resolve_file_paths(ctx.get("tabular_files"))

        logger.info(
                    "DATA_ANALYST_QUERY = %s",
                    input_data.get("query")
                    )

        result = self.query(
            llm=llm,
            file_paths=file_paths,
            user_query=input_data.get("query", ""),
            generate_chart=input_data.get("generate_chart", False),
            chart_type=input_data.get("chart_type"),
            export_to_excel=input_data.get("export_to_excel", False),
        )

    

        # Embed GENERATED_FILE marker into the answer for the download system
        response: Dict[str, Any] = {"answer": result["answer"]}
        if result.get("chart_path"):
            response["answer"] += (
                f"\n\n[GENERATED_FILE:{result['chart_path']}"
                f":{result['chart_filename']}]\n\n"
                f"DUPLICATE WARNING: Include the [GENERATED_FILE:...] tag ONLY ONCE in your "
                f"final answer. The system registers files automatically from tool output. "
                f"If you include it more than once, the user will see duplicate entries "
                f"in their file list."
            )
            response["chart_path"] = result["chart_path"]
            response["chart_filename"] = result["chart_filename"]
            response["chart_file_id"] = result["chart_file_id"]

        if result.get("excel_path"):
            # Do NOT emit GENERATED_FILE marker here — the excel_generator
            # tool handles download link registration via its source_file mode.
            response["excel_path"] = result["excel_path"]
            response["excel_filename"] = result["excel_filename"]
            response["excel_file_id"] = result["excel_file_id"]

        return response

    def _resolve_file_paths(
        self, provided: Optional[List[Dict[str, Any]]]
    ) -> List[Dict[str, str]]:
        """
        Prefer the caller's file list; fall back to directory discovery.

        A caller that knows which files belong to this session is authoritative:
        discovery cannot distinguish one session's upload from another's, and
        widening the set is both a wrong answer and a data-visibility problem.
        Discovery remains for callers with no session — a workflow node reading a
        sheet an earlier step generated.
        """
        entries: List[Dict[str, str]] = []
        for item in provided or []:
            if not isinstance(item, dict):
                continue
            path = item.get("file_path") or item.get("path")
            if not path:
                continue
            entries.append(
                {
                    "file_path": str(path),
                    "filename": str(item.get("filename") or os.path.basename(str(path))),
                }
            )

        if entries:
            logger.info("data_analyst using %d caller-supplied file(s)", len(entries))
            return entries

        return self._discover_tabular_files()

    def _discover_tabular_files(self) -> List[Dict[str, str]]:
        """
        Scan upload and generated directories for Excel/CSV files.

        Includes files from:
        - APP_UPLOADS_DIR (env var)
        - apps/appmgr/uploads/ (original user uploads)
        - uploads/generated/excel/ (intermediate outputs from prior workflow steps)

        Returns:
            List of {"file_path": str, "filename": str} dicts, sorted by
            modification time (most recent last).
        """
        roots: List[str] = []
        env_dir = os.getenv("APP_UPLOADS_DIR")
        if env_dir:
            roots.append(os.path.abspath(env_dir))
        _backend_root = os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )
        roots.append(os.path.join(_backend_root, "apps", "appmgr", "uploads"))
        # Include generated Excel directory so workflow steps can chain:
        # Step N's data_analyst saves here, Step N+1 discovers it.
        roots.append(os.path.abspath(os.path.join("uploads", "generated", "excel")))

        files: List[Dict[str, str]] = []
        seen: set = set()
        for base in roots:
            if not base or base in seen or not os.path.isdir(base):
                continue
            seen.add(base)
            try:
                for dirpath, _, filenames in os.walk(base):
                    for fn in filenames:
                        ext = os.path.splitext(fn)[1].lower()
                        if ext in (".xlsx", ".csv", ".xls"):
                            fpath = os.path.join(dirpath, fn)
                            files.append({"file_path": fpath, "filename": fn})
            except OSError:
                pass

        # Sort by mtime so the most recent file (latest step output) loads last.
        files.sort(
            key=lambda f: os.path.getmtime(f["file_path"])
            if os.path.isfile(f["file_path"]) else 0
        )

        logger.debug("Auto-discovered %d tabular files from uploads + generated", len(files))
        logger.info("=== DISCOVERED FILES ===")

        for f in files:
            logger.info(
                "File: %s",
                f["file_path"]
            )
        return files

    # ------------------------------------------------------------------
    # Robust file readers
    # ------------------------------------------------------------------

    @staticmethod
    def _read_csv_robust(fpath: str):
        """Read a CSV file with automatic delimiter and encoding detection."""
        import pandas as pd

        # Try UTF-8 with auto-delimiter detection first
        try:
            return pd.read_csv(fpath, sep=None, engine="python", encoding="utf-8")
        except UnicodeDecodeError:
            pass

        # Fall back to latin-1 (covers Western European encodings)
        return pd.read_csv(fpath, sep=None, engine="python", encoding="latin-1")

    @staticmethod
    def _read_excel_robust(fpath: str, fname: str):
        """Read an Excel file, loading all sheets into a single DataFrame
        with a '_sheet' column for identification. Falls back to first sheet
        if concatenation fails."""
        import pandas as pd

        sheets = pd.read_excel(fpath, sheet_name=None)

        for sheet_name, sheet_df in sheets.items():

            logger.info(
                "Workbook=%s Sheet=%s Rows=%d Cols=%d",
                fname,
                sheet_name,
                len(sheet_df),
                len(sheet_df.columns),
            )

        if not sheets:
            raise ValueError(f"No sheets found in {fname}")

        # Single sheet — return directly
        if len(sheets) == 1:
            df = next(iter(sheets.values()))

            logger.info(
                "%s -> sheet rows=%d cols=%d",
                fname,
                len(df),
                len(df.columns),
            )

            return df

        # Multiple sheets — concatenate with a _sheet identifier column
        try:
            parts = []
            for sheet_name, df in sheets.items():
                df = df.copy()
                df["_sheet"] = sheet_name
                parts.append(df)
            return pd.concat(parts, ignore_index=True)
        except Exception:
            # If concat fails (incompatible schemas), return first sheet only
            logger.warning(
                "Could not concatenate sheets for '%s', using first sheet only",
                fname,
            )
            # return next(iter(sheets.values()))
            for sheet_name, sheet_df in sheets.items():

                logger.info(
                    "Sheet '%s' rows=%d cols=%d",
                    sheet_name,
                    len(sheet_df),
                    len(sheet_df.columns),
                )

                if not sheet_df.empty:
                    logger.info(
                        "Using sheet '%s' for %s",
                        sheet_name,
                        fname,
                    )
                    return sheet_df

            return next(iter(sheets.values()))

    def query(
        self,
        llm: Any,
        file_paths: List[Dict[str, str]],
        user_query: str,
        generate_chart: bool = False,
        chart_type: Optional[str] = None,
        export_to_excel: bool = False,
    ) -> Dict[str, Any]:
        """
        Query tabular data using natural language and optionally generate a chart.
        When export_to_excel is True, applies transformations to the DataFrame
        in-place and saves the result as a downloadable .xlsx file.

        Args:
            llm: LangChain-compatible LLM instance (AzureChatOpenAI or similar).
            file_paths: List of {"file_path": str, "filename": str} dicts.
            user_query: Natural language question about the data.
            generate_chart: Whether to also generate a visualization PNG.
            chart_type: Optional chart type hint: "bar", "line", "pie", etc.
            export_to_excel: Whether to save the transformed DataFrame as .xlsx.

        Returns:
            Dict with:
                "answer": str — natural language answer
                "chart_path": Optional[str] — absolute path to generated PNG
                "chart_filename": Optional[str] — filename of chart PNG
                "chart_file_id": Optional[str] — UUID for download system
                "excel_path": Optional[str] — absolute path to generated xlsx
                "excel_filename": Optional[str] — filename of xlsx
                "excel_file_id": Optional[str] — UUID for download system
        """
        import pandas as pd
        import threading
        from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent

        # --- Auto-detect transformation intent ---
        _TRANSFORM_KEYWORDS = [
            "normalize", "standardize", "z-score", "zscore", "scale",
            "transform", "formula", "calculate score", "min-max",
            "minmax", "scoring", "apply rule", "compute score",
        ]
        if not export_to_excel and any(
            kw in user_query.lower() for kw in _TRANSFORM_KEYWORDS
        ):
            export_to_excel = True
            logger.info(
                "Auto-enabled export_to_excel based on transformation keywords in query"
            )

        if not file_paths:
            return {
                "answer": "No tabular files are available in this session.",
                "chart_path": None,
                "chart_filename": None,
                "chart_file_id": None,
            }

        # Load all tabular files into DataFrames
        dataframes: Dict[str, Any] = {}
        for file_info in file_paths:
            fpath = file_info.get("file_path", "")
            fname = file_info.get("filename", os.path.basename(fpath))
            if not os.path.isfile(fpath):
                logger.warning("Tabular file not found on disk: %s", fpath)
                continue
            try:
                ext = os.path.splitext(fname)[1].lower()
                if ext == ".csv":
                    df = self._read_csv_robust(fpath)
                else:
                    df = self._read_excel_robust(fpath, fname)
                if isinstance(df, dict):
                    # Multi-sheet result: add each as separate entry
                    for sheet_label, sheet_df in df.items():
                        dataframes[sheet_label] = sheet_df
                else:
                    dataframes[fname] = df
                logger.debug("Loaded DataFrame '%s': %d rows, %d cols", fname, len(df) if not isinstance(df, dict) else sum(len(v) for v in df.values()), len(df.columns) if not isinstance(df, dict) else 0)
            except Exception:
                logger.exception("Failed to load tabular file: %s", fpath)


        logger.info("=== DISCOVERED DATAFRAMES ===")

        for name, df in dataframes.items():
            try:
                logger.info(
                    "DataFrame '%s' -> rows=%d cols=%d",
                    name,
                    len(df),
                    len(df.columns),
                )
                logger.info("Columns: %s", df.columns.tolist())
            except Exception:
                logger.exception("Failed logging dataframe info")

        if not dataframes:
            return {
                "answer": "Could not load any tabular files for analysis.",
                "chart_path": None,
                "chart_filename": None,
                "chart_file_id": None,
                "excel_path": None,
                "excel_filename": None,
                "excel_file_id": None,
            }

        if len(dataframes) == 1:
            df_for_agent = list(dataframes.values())[0]
        else:
            df_for_agent = list(dataframes.values())[-1]


        logger.info(
            "AVAILABLE DATAFRAMES = %s",
            list(dataframes.keys())
        )

        logger.info(
            "SELECTED DATAFRAME SHAPE = %s",
            df_for_agent.shape
        )

        logger.info(
            "SELECTED DATAFRAME HEAD:\n%s",
            df_for_agent.head(5).to_string()
        )

        # Track original columns to detect if transformation added new ones
        original_columns = (
            set(df_for_agent.columns.tolist())
            if not isinstance(df_for_agent, list)
            else set()
        )

        # --- Structure analysis for transformation guidance ---
        structure_analysis = None
        if export_to_excel:
            structure_analysis = self._analyze_dataframe_structure(
                df_for_agent, user_query
            )
            prefix = self._build_transform_prefix(dataframes, structure_analysis)
        else:
            prefix = self._build_agent_prefix(dataframes, generate_chart, chart_type)

        # Resolve agent_type: force function-calling to avoid ReAct text-parsing
        # issues with smaller models (gpt-4o-mini writes natural language in Action
        # field instead of tool name, causing infinite loops).
        try:
            from langchain.agents import AgentType
            _agent_type = AgentType.OPENAI_FUNCTIONS
        except (ImportError, AttributeError):
            _agent_type = "openai-tools"

        if not isinstance(df_for_agent, list):
            logger.info(
                "AGENT DATAFRAME SHAPE = %s",
                df_for_agent.shape,
            )

            logger.info(
                "AGENT COLUMNS = %s",
                df_for_agent.columns.tolist(),
            )

            logger.info(
                "AGENT SAMPLE =\n%s",
                df_for_agent.head(5).to_string(),
            )

        agent = create_pandas_dataframe_agent(
            llm,
            df_for_agent,
            agent_type=_agent_type,
            verbose=True,
            allow_dangerous_code=True,
            include_df_in_prompt=True,
            prefix=prefix,
            max_iterations=15,
        )
        # Safety net: set handle_parsing_errors in case any version still uses
        # text-based parsing as fallback.
        try:
            agent.handle_parsing_errors = True
        except Exception:
            pass
        chart_path: Optional[str] = None
        chart_filename: Optional[str] = None
        chart_file_id: Optional[str] = None

        if generate_chart:
            chart_file_id = str(uuid.uuid4())
            chart_filename = f"chart_{chart_file_id}.png"
            chart_path = os.path.join(self.output_dir, chart_filename)
            enhanced_query = (
                f"{user_query}\n\n"
                f"IMPORTANT: Save the chart as a PNG file to this exact path: {chart_path}\n"
                f"Use: import matplotlib.pyplot as plt; "
                f"plt.savefig('{chart_path}', dpi=150, bbox_inches='tight'); plt.close()\n"
                f"Do NOT call plt.show()."
            )
        elif export_to_excel:
            enhanced_query = self._build_enhanced_transform_query(
                user_query, structure_analysis
            )
        else:
            enhanced_query = user_query

        # Execute agent with timeout to prevent runaway loops consuming tokens
        _AGENT_TIMEOUT_SECONDS = 90

        def _invoke_agent():
            return agent.invoke({"input": enhanced_query})

        try:
            # Use a thread to enforce timeout
            _result_container = [None]
            _error_container = [None]

            def _run_agent():
                try:
                    _result_container[0] = _invoke_agent()
                except Exception as e:
                    _error_container[0] = e

            worker = threading.Thread(target=_run_agent, daemon=True)
            worker.start()
            worker.join(timeout=_AGENT_TIMEOUT_SECONDS)

            if worker.is_alive():
                logger.error(
                    "Pandas agent timed out after %ds for query: %s",
                    _AGENT_TIMEOUT_SECONDS,
                    user_query,
                )
                answer = (
                    "Data analysis timed out. The transformation may be too complex "
                    "for a single pass. Please try simplifying the request."
                )
            elif _error_container[0]:
                raise _error_container[0]
            else:
                result = _result_container[0]
                answer = result.get("output", str(result))
        except Exception as exc:
            logger.exception("Pandas agent execution failed for query: %s", user_query)
            answer = f"Data analysis encountered an error: {exc}"
            chart_path = None
            chart_filename = None
            chart_file_id = None

        # Verify chart was actually saved; retry once if LLM forgot savefig
        if chart_path and not os.path.isfile(chart_path):
            logger.warning("Chart not saved on first attempt, retrying")
            retry_query = (
                f"Generate ONLY a matplotlib chart for: {user_query}\n"
                f"You MUST save it:\n"
                f"import matplotlib.pyplot as plt\n"
                f"plt.savefig('{chart_path}', dpi=150, bbox_inches='tight')\n"
                f"plt.close()"
            )
            try:
                agent.invoke({"input": retry_query})
            except Exception:
                logger.exception("Chart retry failed")

        # Final verification — drop chart metadata if file still absent
        if chart_path and not os.path.isfile(chart_path):
            logger.warning("Chart generation failed after retry: %s", user_query)
            chart_path = None
            chart_filename = None
            chart_file_id = None

        # --- Export transformed DataFrame to Excel ---
        excel_path: Optional[str] = None
        excel_filename: Optional[str] = None
        excel_file_id: Optional[str] = None

        if export_to_excel:
            excel_path, excel_filename, excel_file_id = self._export_dataframe_to_excel(
                df_for_agent, original_columns, user_query, agent,
                structure_analysis=structure_analysis,
            )
            if excel_path:
                answer += (
                    f"\n\nThe transformed data has been saved to an Excel file."
                    f"\n\nEXCEL_OUTPUT_PATH: {excel_path}"
                    f"\nTo provide a download link, call the excel_generator tool with "
                    f'source_file="{excel_path}" and an appropriate title.'
                )

        return {
            "answer": answer,
            "chart_path": chart_path,
            "chart_filename": chart_filename,
            "chart_file_id": chart_file_id,
            "excel_path": excel_path,
            "excel_filename": excel_filename,
            "excel_file_id": excel_file_id,
        }

    def _build_agent_prefix(
        self,
        dataframes: Dict[str, Any],
        generate_chart: bool,
        chart_type: Optional[str],
    ) -> str:
        """
        Build the system prefix for the pandas dataframe agent.

        WHY: Providing a detailed prefix improves agent accuracy and ensures
        it follows chart-generation instructions reliably.

        Args:
            dataframes: Dict of {filename: DataFrame} for context.
            generate_chart: Whether chart generation is requested.
            chart_type: Optional chart type hint.

        Returns:
            System prefix string injected into the agent's prompt.
        """
        file_summaries = []
        for fname, df in dataframes.items():
            cols = ", ".join(str(c) for c in df.columns.tolist()[:20])
            file_summaries.append(f"  - {fname}: {len(df)} rows, columns: [{cols}]")
        files_section = "\n".join(file_summaries)

        prefix = (
            "You are a senior data analyst working with pandas DataFrames.\n"
            "The data is ALREADY LOADED into a variable called `df`. "
            "Do NOT try to read files from disk. Do NOT use pd.read_excel() or pd.read_csv(). "
            "The DataFrame `df` is ready to use directly.\n\n"
            "Available data:\n"
            f"{files_section}\n\n"
            "RULES:\n"
            "- The data is already in `df`. Use it directly — never read from disk.\n"
            "- NEVER call pd.read_excel(), pd.read_csv(), or open() to load files.\n"
            "- Run Python code to answer questions accurately\n"
            "- For numerical questions: compute exact values, do not approximate\n"
            "- For comparisons: show both values being compared\n"
            "- Final answer must be in plain language, no Python code\n"
            "- If data is insufficient to answer, say so clearly\n"
        )

        if generate_chart:
            chart_hint = f"Use chart type: {chart_type}" if chart_type else "Choose the most appropriate chart type"
            prefix += (
                "\nCHART GENERATION:\n"
                "- You MUST generate a chart/visualization for this query\n"
                "- Use matplotlib and seaborn for professional-looking charts\n"
                f"- {chart_hint}\n"
                "- Use a clean style: import seaborn as sns; sns.set_style('whitegrid')\n"
                "- Add clear title, axis labels, and legend where appropriate\n"
                "- For large datasets, show top 10-20 items max in the chart\n"
                "- ALWAYS call plt.savefig() with the exact path provided\n"
                "- ALWAYS call plt.close() after saving\n"
                "- NEVER call plt.show()\n"
            )

        return prefix

    def _analyze_dataframe_structure(
        self,
        df: Any,
        user_query: str,
    ) -> Dict[str, Any]:
        """
        Analyze the DataFrame structure and user query to determine the
        correct transformation approach.

        Returns a dict with:
            value_columns: List of numeric columns containing data to transform.
            metadata_columns: List of text/identifier columns.
            control_columns: List of columns that control transformation logic
                (e.g., Direction, Category, Type).
            suggested_axis: "row" or "column" — the axis along which to compute
                aggregates (min/max/mean) for normalization.
            detected_formulas: Dict of extracted formula info from the user query.
            column_naming_hint: Suggested naming pattern for output columns.
        """
        import numpy as np
        import pandas as pd

        analysis: Dict[str, Any] = {
            "value_columns": [],
            "metadata_columns": [],
            "control_columns": [],
            "suggested_axis": "column",  # default: standard column-wise
            "detected_formulas": {},
            "column_naming_hint": "suffix",
        }

        if isinstance(df, list):
            # Multiple DataFrames — analyze the first one
            if not df:
                return analysis
            df = df[0]

        if not isinstance(df, pd.DataFrame) or df.empty:
            return analysis

        all_columns = df.columns.tolist()
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        non_numeric_cols = [c for c in all_columns if c not in numeric_cols]

        # --- Detect control columns ---
        # Columns with a small number of unique categorical values that appear
        # to dictate transformation behavior (Direction, Type, Category, etc.)
        _CONTROL_PATTERNS = re.compile(
            r"(?i)(direction|type|category|method|rule|approach|criteria|preference|"
            r"attracti|scoring.?method|normali[sz]ation.?type)",
        )
        for col in non_numeric_cols:
            col_lower = col.lower().strip()
            if _CONTROL_PATTERNS.search(col):
                analysis["control_columns"].append(col)
            elif df[col].nunique() <= 5 and any(
                kw in str(df[col].dropna().unique()).lower()
                for kw in ("higher", "lower", "positive", "negative", "max", "min")
            ):
                # Content-based detection: values suggest directional control
                analysis["control_columns"].append(col)

        # --- Detect metadata vs value columns ---
        # Metadata: non-numeric cols not identified as control
        _METADATA_PATTERNS = re.compile(
            r"(?i)(s\.?\s*no|serial|index|id|name|factor|sub.?factor|"
            r"data.?point|description|label|unit|measure|metric|indicator)",
        )
        for col in non_numeric_cols:
            if col not in analysis["control_columns"]:
                analysis["metadata_columns"].append(col)

        # Value columns: numeric columns that aren't row indices
        _INDEX_PATTERNS = re.compile(r"(?i)(s\.?\s*no|serial|index|row.?num|id$|_id$)")
        for col in numeric_cols:
            if _INDEX_PATTERNS.search(col):
                analysis["metadata_columns"].append(col)
            else:
                analysis["value_columns"].append(col)

        # --- Determine axis ---
        # Key heuristic: if a control column exists with per-row directional
        # values AND the user's query implies per-row scoring, suggest row-wise.
        _ROW_WISE_QUERY_PATTERNS = re.compile(
            r"(?i)(per\s*row|row[\s-]*wise|across\s*(the\s*)?(columns|cities|entities|locations|regions|items)"
            r"|for\s*each\s*row|each\s*row|horizontal|across\s*all\s*(the\s*)?\w+\s*columns"
            r"|min.*max.*across|across.*min.*max)",
        )
        _COL_WISE_QUERY_PATTERNS = re.compile(
            r"(?i)(per\s*column|column[\s-]*wise|across\s*(the\s*)?rows"
            r"|for\s*each\s*column|vertical|down\s*the\s*column)",
        )

        has_control_col = len(analysis["control_columns"]) > 0
        query_suggests_row = bool(_ROW_WISE_QUERY_PATTERNS.search(user_query))
        query_suggests_col = bool(_COL_WISE_QUERY_PATTERNS.search(user_query))

        if query_suggests_row and not query_suggests_col:
            analysis["suggested_axis"] = "row"
        elif query_suggests_col and not query_suggests_row:
            analysis["suggested_axis"] = "column"
        elif has_control_col:
            # Control column with directional values strongly suggests row-wise:
            # each row has its own direction, so normalization is across value
            # columns within each row.
            control_col = analysis["control_columns"][0]
            control_values = df[control_col].dropna().unique()
            has_directional = any(
                any(kw in str(v).lower() for kw in ("higher", "lower", "more", "less", "positive", "negative"))
                for v in control_values
            )
            if has_directional:
                analysis["suggested_axis"] = "row"
        else:
            # No control column and no explicit user hint — check data shape.
            # If value columns look like entity/location names (many columns,
            # relatively few rows with data), suggest row-wise.
            # Otherwise default to column-wise.
            if len(analysis["value_columns"]) >= 3:
                # Heuristic: if the non-null row count is small relative to
                # the number of value columns, it's likely a metrics matrix
                valid_rows = df[analysis["value_columns"]].dropna(how="all").shape[0]
                if valid_rows > 0 and len(analysis["value_columns"]) >= 3:
                    # Check if user's query mentions the column names or
                    # normalization keywords without specifying axis
                    pass  # keep default column-wise unless overridden above

        # --- Extract formula patterns from user query ---
        formulas = {}

        # Detect explicit scoring/normalization formulas
        _HIGHER_FORMULA = re.compile(
            r"(?i)(?:if|when|where).*higher.*(?:score|formula|normalized?)\s*[:=]\s*"
            r"\(?\s*(?:value|v|x)\s*[-–]\s*min\s*\)?\s*\*?\s*(\d+)?\s*/?\s*\(?\s*max\s*[-–]\s*min\s*\)?",
        )
        _LOWER_FORMULA = re.compile(
            r"(?i)(?:if|when|where).*lower.*(?:score|formula|normalized?)\s*[:=]\s*"
            r"\(?\s*(?:value|v|x)\s*[-–]\s*max\s*\)?\s*\*?\s*(\d+)?\s*/?\s*\(?\s*min\s*[-–]\s*max\s*\)?",
        )
        _EQUAL_FORMULA = re.compile(
            r"(?i)(?:if|when|where).*(?:max\s*=\s*min|min\s*=\s*max|equal).*(?:score|set)\s*(?:=|to)\s*(\d+)",
        )
        _FLOOR_PATTERN = re.compile(
            r"(?i)(?:if|when).*(?:score|value).*(?:<|less\s*than)\s*(\d+).*(?:set|floor|cap|clamp).*(?:to|=)\s*(\d+)",
        )
        _CAP_PATTERN = re.compile(
            r"(?i)(?:cap|ceiling|max|upper).*(?:score|value).*(?:at|to|=)\s*(\d+)",
        )
        _SCALE_FACTOR = re.compile(
            r"(?i)\*\s*(\d+)\s*/|(\d+)\s*/\s*\(", 
        )

        higher_match = _HIGHER_FORMULA.search(user_query)
        lower_match = _LOWER_FORMULA.search(user_query)
        equal_match = _EQUAL_FORMULA.search(user_query)
        floor_match = _FLOOR_PATTERN.search(user_query)
        cap_match = _CAP_PATTERN.search(user_query)
        scale_match = _SCALE_FACTOR.search(user_query)

        if higher_match or lower_match:
            formulas["type"] = "direction_based_normalization"
            formulas["scale_factor"] = 5  # default
            if scale_match:
                factor = scale_match.group(1) or scale_match.group(2)
                if factor:
                    formulas["scale_factor"] = int(factor)
        if equal_match:
            formulas["equal_value"] = int(equal_match.group(1))
        if floor_match:
            formulas["floor"] = int(floor_match.group(2))
        if cap_match:
            formulas["cap"] = int(cap_match.group(1))

        # Detect general normalization keywords
        if not formulas:
            _NORM_TYPE = re.compile(r"(?i)(min[\s-]*max|z[\s-]*score|standard|logarithm|log\s*transform|percentile)")
            norm_match = _NORM_TYPE.search(user_query)
            if norm_match:
                formulas["type"] = norm_match.group(1).lower().replace(" ", "_").replace("-", "_")

        analysis["detected_formulas"] = formulas

        # --- Column naming hint ---
        # Check if user specified a naming pattern
        _NAMING_PATTERN = re.compile(
            r"(?i)(?:named?|called?|label(?:led|ed)?)\s*[\"']?(\w+)\s*\(?\s*Normalized?\s*\)?",
        )
        naming_match = _NAMING_PATTERN.search(user_query)
        if naming_match or "normalized)" in user_query.lower() or "(normalized" in user_query.lower():
            analysis["column_naming_hint"] = "parenthetical"  # e.g., "City (Normalized)"
        else:
            analysis["column_naming_hint"] = "suffix"  # e.g., "city_normalized"

        return analysis

    def _build_transform_prefix(
        self,
        dataframes: Dict[str, Any],
        structure_analysis: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Build a transformation-focused prefix for the pandas agent.

        Used when export_to_excel=True. Instructs the agent to modify the
        DataFrame in-place. Uses structure analysis to provide the correct
        transformation pattern (row-wise vs column-wise).
        """
        file_summaries = []
        for fname, df in dataframes.items():
            cols = ", ".join(str(c) for c in df.columns.tolist()[:30])
            dtypes = ", ".join(f"{c}({df[c].dtype})" for c in df.columns.tolist()[:15])
            file_summaries.append(
                f"  - {fname}: {len(df)} rows, columns: [{cols}]\n    dtypes: [{dtypes}]"
            )
        files_section = "\n".join(file_summaries)

        prefix = (
            "You are a senior data engineer performing data transformations.\n"
            "The data is ALREADY LOADED into a variable called `df`. "
            "Do NOT try to read files from disk. Do NOT use pd.read_excel() or pd.read_csv(). "
            "The DataFrame `df` is ready to use directly.\n\n"
            "Available data:\n"
            f"{files_section}\n\n"
            "YOUR TASK: Apply the user's requested transformation to the DataFrame.\n\n"
            "CRITICAL RULES:\n"
            "- NEVER call pd.read_excel(), pd.read_csv(), or open() to load files.\n"
            "- Modify the DataFrame `df` DIRECTLY (in-place). Do NOT create copies or new DataFrames.\n"
            "- KEEP all original columns — never drop or overwrite them.\n"
            "- ADD new columns for transformation results.\n"
            "- Handle NaN values: use skipna=True for aggregations, leave NaN as NaN in output.\n"
            "- After transformation, print the first 3 rows of the new columns to confirm correctness.\n"
            "- Your final text answer should describe what was done (which columns, which method).\n\n"
        )

        # --- Add structure-aware guidance ---
        if structure_analysis:
            axis = structure_analysis.get("suggested_axis", "column")
            value_cols = structure_analysis.get("value_columns", [])
            control_cols = structure_analysis.get("control_columns", [])
            metadata_cols = structure_analysis.get("metadata_columns", [])
            naming_hint = structure_analysis.get("column_naming_hint", "suffix")

            if value_cols:
                prefix += (
                    "DATA STRUCTURE ANALYSIS:\n"
                    f"- Value columns (numeric data to transform): {value_cols}\n"
                    f"- Metadata columns (identifiers, NOT to transform): {metadata_cols}\n"
                    f"- Control columns (dictate transformation rules per row): {control_cols}\n"
                    f"- Suggested transformation axis: {axis.upper()}-WISE\n"
                )
                if naming_hint == "parenthetical":
                    prefix += "- Output column naming: '<OriginalColumn> (Normalized)' format\n"
                prefix += "\n"

            if axis == "row":
                prefix += self._row_wise_transform_guidance(value_cols, control_cols)
            else:
                prefix += self._column_wise_transform_guidance(value_cols)
        else:
            # Fallback: no structure analysis available — provide both patterns
            prefix += self._generic_transform_guidance()

        return prefix

    @staticmethod
    def _row_wise_transform_guidance(
        value_columns: List[str],
        control_columns: List[str],
    ) -> str:
        """Generate guidance for row-wise transformations."""
        cols_str = str(value_columns[:10])
        control_str = control_columns[0] if control_columns else "Direction"

        return (
            "ROW-WISE TRANSFORMATION INSTRUCTIONS:\n"
            "The transformation must be computed ACROSS value columns within each row,\n"
            "NOT down a column across rows.\n\n"
            "HOW TO COMPUTE:\n"
            "1. Identify the value columns (numeric data columns for transformation).\n"
            f"   value_cols = {cols_str}\n"
            "2. For EACH ROW that requires transformation:\n"
            "   - Compute min and max ACROSS the value columns IN THAT ROW:\n"
            "     row_min = row[value_cols].min()  # min across columns, not down a column!\n"
            "     row_max = row[value_cols].max()  # max across columns, not down a column!\n"
            "   - Apply the formula using that row's min/max.\n"
            "3. Store the result as new columns alongside the original data.\n\n"
            "CORRECT PATTERN (row-wise with control column):\n"
            "```python\n"
            "import numpy as np\n"
            f"value_cols = {cols_str}  # adjust to actual value column names\n"
            f"control_col = '{control_str}'\n\n"
            "# Identify rows that have a control value (non-empty Direction/Type)\n"
            "has_control = df[control_col].notna() & (df[control_col].str.strip() != '')\n\n"
            "# For each value column, compute normalized score\n"
            "for col in value_cols:\n"
            "    new_col = col + ' (Normalized)'  # or col + '_normalized'\n"
            "    df[new_col] = np.nan\n\n"
            "# Process only rows that have a control value\n"
            "for idx in df[has_control].index:\n"
            "    row_values = df.loc[idx, value_cols].astype(float)\n"
            "    row_min = row_values.min()\n"
            "    row_max = row_values.max()\n"
            "    direction = str(df.loc[idx, control_col]).lower()\n\n"
            "    for col in value_cols:\n"
            "        val = float(df.loc[idx, col])\n"
            "        new_col = col + ' (Normalized)'\n"
            "        if row_max == row_min:\n"
            "            score = 3  # or whatever the user specifies for equal values\n"
            "        elif 'higher' in direction or 'more' in direction:\n"
            "            score = (val - row_min) * 5 / (row_max - row_min)\n"
            "        elif 'lower' in direction or 'less' in direction:\n"
            "            score = (val - row_max) * 5 / (row_min - row_max)\n"
            "        else:\n"
            "            score = np.nan\n"
            "        # Apply floor and cap as specified by user\n"
            "        if score is not np.nan and score < 1:\n"
            "            score = 1\n"
            "        if score is not np.nan and score > 5:\n"
            "            score = 5\n"
            "        df.loc[idx, new_col] = score\n"
            "```\n\n"
            "COMMON MISTAKES TO AVOID:\n"
            "- Do NOT use df[col].min() / df[col].max() — that computes min/max DOWN the column across all rows.\n"
            "- Do NOT normalize column-by-column. Normalize ROW-BY-ROW across the value columns.\n"
            "- The min and max must be computed from the SAME ROW's values across value columns.\n"
            "- Rows without a control value (section headers, blank rows) should have empty/NaN normalized columns.\n\n"
        )

    @staticmethod
    def _column_wise_transform_guidance(value_columns: List[str]) -> str:
        """Generate guidance for column-wise transformations."""
        return (
            "COLUMN-WISE TRANSFORMATION INSTRUCTIONS:\n"
            "The transformation must be computed DOWN each column across all rows.\n\n"
            "PATTERNS:\n"
            "- Min-Max normalization (0-1 scale):\n"
            "  `df['col_normalized'] = (df['col'] - df['col'].min()) / (df['col'].max() - df['col'].min())`\n"
            "- Z-score standardization:\n"
            "  `df['col_zscore'] = (df['col'] - df['col'].mean()) / df['col'].std()`\n"
            "- Log transform:\n"
            "  `df['col_log'] = np.log1p(df['col'])`\n"
            "- Custom formula:\n"
            "  `df['new_col'] = df['colA'] / df['colB']`\n\n"
            "EDGE CASES:\n"
            "- If std==0 for z-score, set result to 0.\n"
            "- If max==min for normalization, set result to a neutral value (0 or user-specified).\n"
            "- Apply only to numeric columns unless user specifies otherwise.\n\n"
        )

    @staticmethod
    def _generic_transform_guidance() -> str:
        """Fallback guidance when no structure analysis is available."""
        return (
            "TRANSFORMATION PATTERNS:\n\n"
            "DETERMINE THE CORRECT AXIS FIRST:\n"
            "- If the data has a control/direction column that dictates the formula per row,\n"
            "  and value columns represent different entities (cities, products, regions),\n"
            "  then normalize ROW-WISE: compute min/max across value columns within each row.\n"
            "- If the data has samples/observations as rows and features as columns,\n"
            "  then normalize COLUMN-WISE: compute min/max down each column across rows.\n\n"
            "ROW-WISE (entities as columns, metrics as rows):\n"
            "```python\n"
            "value_cols = [list of numeric entity columns]\n"
            "for idx in df.index:\n"
            "    row_min = df.loc[idx, value_cols].min()\n"
            "    row_max = df.loc[idx, value_cols].max()\n"
            "    for col in value_cols:\n"
            "        df.loc[idx, col + '_normalized'] = (df.loc[idx, col] - row_min) / (row_max - row_min)\n"
            "```\n\n"
            "COLUMN-WISE (samples as rows, features as columns):\n"
            "```python\n"
            "df['col_normalized'] = (df['col'] - df['col'].min()) / (df['col'].max() - df['col'].min())\n"
            "```\n\n"
            "IMPORTANT: Read the user's request carefully to determine which axis is correct.\n"
            "If the user mentions 'for each row', 'across columns', or a direction/control column,\n"
            "use ROW-WISE. If they mention 'for each column', 'across rows', or standard\n"
            "feature scaling, use COLUMN-WISE.\n\n"
        )

    def _build_enhanced_transform_query(
        self,
        user_query: str,
        structure_analysis: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Build an enhanced query for transformation that includes structured
        context about the data and explicit instructions based on the analysis.

        Instead of generic "add new columns" instructions, this provides the
        LLM with specific information about WHAT to transform and HOW.
        """
        parts = [user_query, ""]

        if not structure_analysis:
            # Fallback: generic instructions
            parts.append(
                "IMPORTANT TRANSFORMATION RULES:\n"
                "- Apply the requested transformation DIRECTLY to `df` (in-place).\n"
                "- Add NEW columns for results. Keep all original columns.\n"
                "- Handle NaN/missing values gracefully.\n"
                "- After transformation, print df.columns.tolist() to confirm.\n"
                "- Describe what transformations were applied in your final answer.\n"
            )
            return "\n".join(parts)

        axis = structure_analysis.get("suggested_axis", "column")
        value_cols = structure_analysis.get("value_columns", [])
        control_cols = structure_analysis.get("control_columns", [])
        formulas = structure_analysis.get("detected_formulas", {})
        naming_hint = structure_analysis.get("column_naming_hint", "suffix")

        parts.append("EXECUTION CONTEXT (derived from data structure analysis):")

        # Inform the LLM which columns are values vs metadata vs control
        if value_cols:
            parts.append(f"- VALUE COLUMNS to transform: {value_cols}")
        if control_cols:
            parts.append(f"- CONTROL COLUMN (dictates formula per row): '{control_cols[0]}'")

        # Explicit axis instruction
        if axis == "row":
            parts.append(
                "- AXIS: ROW-WISE — compute min/max ACROSS value columns within each row, "
                "NOT down a column across rows."
            )
            parts.append(
                "- For each row: row_min = min(values across value columns in that row), "
                "row_max = max(values across value columns in that row)."
            )
        else:
            parts.append(
                "- AXIS: COLUMN-WISE — compute statistics DOWN each column across all rows."
            )

        # Formula-specific instructions
        if formulas:
            scale = formulas.get("scale_factor", 5)
            equal_val = formulas.get("equal_value", 3)
            floor_val = formulas.get("floor", 1)
            cap_val = formulas.get("cap", 5)

            if formulas.get("type") == "direction_based_normalization":
                parts.append(
                    f"\n- FORMULA (Higher/more attractive): score = (value - row_min) * {scale} / (row_max - row_min)"
                )
                parts.append(
                    f"- FORMULA (Lower/more attractive): score = (value - row_max) * {scale} / (row_min - row_max)"
                )
                parts.append(f"- If row_max == row_min: score = {equal_val}")
                parts.append(f"- Floor: if score < {floor_val}, set to {floor_val}")
                parts.append(f"- Cap: if score > {cap_val}, set to {cap_val}")

        # Column naming
        if naming_hint == "parenthetical":
            parts.append(
                "- OUTPUT COLUMN NAMES: Use '<OriginalColumnName> (Normalized)' format."
            )
        else:
            parts.append(
                "- OUTPUT COLUMN NAMES: Use '<original_column>_normalized' suffix format."
            )

        # Standard rules
        parts.append(
            "\nIMPORTANT RULES:\n"
            "- Modify `df` DIRECTLY in-place. Do NOT create new DataFrames.\n"
            "- Keep ALL original columns intact.\n"
            "- Rows without a control value (headers, sub-headers, blank) → leave normalized columns as NaN.\n"
            "- After transformation, print the first 5 rows of the new columns to confirm.\n"
            "- Your final answer should describe what was done.\n"
        )

        return "\n".join(parts)

    def _build_retry_query(
        self,
        user_query: str,
        structure_analysis: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Build a retry query when the first transformation attempt failed to
        add new columns. Uses structure analysis for targeted instructions.
        """
        if not structure_analysis:
            return (
                f"You MUST apply the transformation from this request: {user_query}\n\n"
                "Add the result as NEW columns to `df` directly.\n"
                "Do NOT create a new DataFrame. Modify `df` in-place.\n"
                "Print df.columns.tolist() after to confirm new columns exist."
            )

        axis = structure_analysis.get("suggested_axis", "column")
        value_cols = structure_analysis.get("value_columns", [])
        control_cols = structure_analysis.get("control_columns", [])
        formulas = structure_analysis.get("detected_formulas", {})

        parts = [
            f"RETRY: Your previous attempt did NOT add any new columns to `df`.",
            f"You MUST apply the transformation from: {user_query}\n",
        ]

        if axis == "row" and value_cols:
            control_col = control_cols[0] if control_cols else "Direction"
            cols_repr = repr(value_cols[:10])
            parts.append(
                f"SPECIFIC INSTRUCTIONS:\n"
                f"1. value_cols = {cols_repr}\n"
                f"2. For each row where df['{control_col}'] is not empty:\n"
                f"   - row_min = df.loc[idx, value_cols].astype(float).min()\n"
                f"   - row_max = df.loc[idx, value_cols].astype(float).max()\n"
                f"   - Apply the normalization formula from the user's request\n"
                f"3. Store results in NEW columns (e.g., df[col + ' (Normalized)'] = score)\n"
                f"4. Rows without a control value → leave as NaN\n"
            )
        elif value_cols:
            parts.append(
                f"SPECIFIC INSTRUCTIONS:\n"
                f"1. For each column in {value_cols[:10]}:\n"
                f"   - Compute column-level statistics (min, max, mean, std)\n"
                f"   - Apply the normalization formula from the user's request\n"
                f"   - Store in a new column: df['<col>_normalized'] = ...\n"
            )

        if formulas.get("type") == "direction_based_normalization":
            scale = formulas.get("scale_factor", 5)
            parts.append(
                f"\nFORMULA REMINDER:\n"
                f"- Higher: (value - row_min) * {scale} / (row_max - row_min)\n"
                f"- Lower: (value - row_max) * {scale} / (row_min - row_max)\n"
                f"- If max == min: score = {formulas.get('equal_value', 3)}\n"
                f"- Clip to [{formulas.get('floor', 1)}, {formulas.get('cap', 5)}]\n"
            )

        parts.append(
            "\nModify `df` in-place. Print df.columns.tolist() to confirm."
        )
        return "\n".join(parts)

    def _export_dataframe_to_excel(
        self,
        df_for_agent: Any,
        original_columns: set,
        user_query: str,
        agent: Any,
        structure_analysis: Optional[Dict[str, Any]] = None,
    ) -> tuple:
        """
        Save the transformed DataFrame to an Excel file.

        After the pandas agent has modified df_for_agent in-place, this method
        saves it to disk and returns the file metadata for the GENERATED_FILE
        marker system.

        Args:
            df_for_agent: The DataFrame (or list of DataFrames) that was passed
                to the pandas agent and potentially modified in-place.
            original_columns: Set of column names before transformation.
            user_query: Original user query (for retry context).
            agent: The pandas agent instance (for retry if needed).
            structure_analysis: Optional structure analysis dict for smarter retry.

        Returns:
            Tuple of (excel_path, excel_filename, excel_file_id) or (None, None, None).
        """
        import pandas as pd

        try:
            # Determine the DataFrame to export
            if isinstance(df_for_agent, list):
                # Multiple DataFrames — concatenate for export
                export_df = pd.concat(df_for_agent, ignore_index=True)
            else:
                export_df = df_for_agent

            # Check if transformation actually added new columns
            current_columns = set(export_df.columns.tolist())
            new_columns = current_columns - original_columns

            if not new_columns and original_columns:
                # Agent didn't modify in-place — retry with structure-aware instruction
                logger.warning(
                    "No new columns detected after transformation, retrying with explicit instruction"
                )
                retry_query = self._build_retry_query(
                    user_query, structure_analysis
                )
                try:
                    agent.invoke({"input": retry_query})
                except Exception:
                    logger.exception("Transform retry failed")

                # Re-check after retry
                if isinstance(df_for_agent, list):
                    export_df = pd.concat(df_for_agent, ignore_index=True)
                else:
                    export_df = df_for_agent
                current_columns = set(export_df.columns.tolist())
                new_columns = current_columns - original_columns

            if not new_columns and original_columns:
                logger.warning(
                    "Transformation did not produce new columns after retry. "
                    "Exporting DataFrame as-is."
                )

            # Save to Excel
            excel_output_dir = os.path.join("uploads", "generated", "excel")
            os.makedirs(excel_output_dir, exist_ok=True)

            excel_file_id = str(uuid.uuid4())
            excel_filename = f"transformed_data_{excel_file_id[:8]}.xlsx"
            excel_path = os.path.abspath(
                os.path.join(excel_output_dir, excel_filename)
            )

            # Write with openpyxl engine and basic formatting
            with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
                export_df.to_excel(writer, index=False, sheet_name="Transformed Data")

                # Apply basic header formatting
                ws = writer.sheets["Transformed Data"]
                from openpyxl.styles import Font, PatternFill, Alignment

                header_font = Font(bold=True, color="FFFFFF", size=11)
                header_fill = PatternFill(
                    start_color="1F4E79", end_color="1F4E79", fill_type="solid"
                )
                # Highlight new (transformed) columns with a different fill
                new_col_fill = PatternFill(
                    start_color="2E8B57", end_color="2E8B57", fill_type="solid"
                )

                col_list = export_df.columns.tolist()
                for col_idx, col_name in enumerate(col_list, start=1):
                    cell = ws.cell(row=1, column=col_idx)
                    cell.font = header_font
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    if col_name in new_columns:
                        cell.fill = new_col_fill
                    else:
                        cell.fill = header_fill

                # Auto-fit column widths
                for col_idx, col_name in enumerate(col_list, start=1):
                    max_len = len(str(col_name))
                    for row in ws.iter_rows(
                        min_row=2, max_row=min(len(export_df) + 1, 50),
                        min_col=col_idx, max_col=col_idx
                    ):
                        for cell in row:
                            if cell.value is not None:
                                max_len = max(max_len, len(str(cell.value)))
                    from openpyxl.utils import get_column_letter
                    ws.column_dimensions[get_column_letter(col_idx)].width = min(
                        max(max_len + 3, 10), 50
                    )

                # Freeze header row
                ws.freeze_panes = ws["A2"]

            logger.info(
                "Transformed Excel exported: %s (%d rows, %d cols, %d new cols)",
                excel_filename,
                len(export_df),
                len(export_df.columns),
                len(new_columns),
            )
            return excel_path, excel_filename, excel_file_id

        except Exception:
            logger.exception("Failed to export transformed DataFrame to Excel")
            return None, None, None
