"""
Data Analyst AgentTool package.

Provides Excel/CSV query and chart generation capabilities via pandas
and matplotlib/seaborn. Registered as a CrewAI tool and auto-bound
to all agents that support tabular data queries.
"""
