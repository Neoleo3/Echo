"""
Calculator core package.
"""
