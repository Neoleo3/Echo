"""
EchoAI Knowledge Search — Agent Tool Implementation

This tool is auto-discovered by the ToolRegistry and can be used by any agent
or workflow.  It performs retrieval against a specified knowledge base using
the same search pipeline as the /knowledge/{kb_id}/search API endpoint.

Required input:
    - query (str): Natural language search query
    - kb_id (str): UUID of the knowledge base to search

Optional input:
    - top_k (int): Number of results (default: KB setting or 5)
    - search_type (str): "similarity" or "hybrid" (default: KB setting)
"""

import asyncio
import logging
from typing import Any, Dict

from echolib.llm_factory import LLMFactory
from echolib.database import get_db_session
from echolib.repositories.knowledge_repo import KnowledgeBaseRepository
from apps.knowledge import retriever

logger = logging.getLogger(__name__)


class KnowledgeSearchTool:
    """
    Agent tool for searching knowledge bases.

    Instantiated by the ToolExecutor when an agent invokes the
    ``tool_knowledge_search`` tool.
    """

    def __init__(self):
        self._llm_factory = None
        self._kb_repo = KnowledgeBaseRepository()

    @property
    def llm_factory(self) -> LLMFactory:
        if self._llm_factory is None:
            self._llm_factory = LLMFactory()
        return self._llm_factory

    def search(self, **kwargs) -> Dict[str, Any]:
        """
        Execute a knowledge base search.

        Called by ToolExecutor with the tool's input schema fields.

        Args (via kwargs):
            query: Search query string.
            kb_id: Knowledge base UUID.
            top_k: Optional max results.
            search_type: Optional "similarity" or "hybrid".

        Returns:
            Dict with query, results, total_results, search_type.
        """
        query = kwargs.get("query", "")
        kb_id = kwargs.get("kb_id", "")
        top_k = kwargs.get("top_k")
        search_type = kwargs.get("search_type")

        if not query or not kb_id:
            return {
                "query": query,
                "results": [],
                "total_results": 0,
                "search_type": search_type or "similarity",
                "error": "Both 'query' and 'kb_id' are required",
            }

        try:
            return self._run_search(query, kb_id, top_k, search_type)
        except Exception as e:
            logger.error("Knowledge search tool error: %s", e, exc_info=True)
            return {
                "query": query,
                "results": [],
                "total_results": 0,
                "search_type": search_type or "similarity",
                "error": str(e),
            }

    def _run_search(
        self,
        query: str,
        kb_id: str,
        top_k: int = None,
        search_type: str = None,
    ) -> Dict[str, Any]:
        """Sync wrapper that loads KB config and runs retriever.

        Handles both sync and async calling contexts:
        - If an event loop is already running (e.g. called from async LangGraph agent),
          runs the async DB call in a separate thread to avoid RuntimeError.
        - If no event loop is running, uses asyncio.run() directly.
        """
        import concurrent.futures

        # Load KB config from DB (async) — safe for both contexts
        try:
            asyncio.get_running_loop()
            # We're inside an async context — cannot use asyncio.run()
            # Run the async DB call in a new thread with its own event loop
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                kb_config = pool.submit(
                    asyncio.run, self._load_kb_config(kb_id)
                ).result()
        except RuntimeError:
            # No running event loop — safe to use asyncio.run()
            kb_config = asyncio.run(self._load_kb_config(kb_id))
        if not kb_config:
            return {
                "query": query,
                "results": [],
                "total_results": 0,
                "search_type": search_type or "similarity",
                "error": f"Knowledge base {kb_id} not found",
            }

        effective_top_k = top_k or kb_config.get("top_k", 5)
        effective_search_type = search_type or kb_config.get("search_type", "similarity")
        embedding_model = kb_config.get("embedding_model")
        vector_weight = kb_config.get("vector_weight", 0.5)
        keyword_weight = kb_config.get("keyword_weight", 0.5)
        processing_type = kb_config.get("processing_type", "vector")

        # Only fetch embeddings when the processing type needs them.
        # Graph-only KBs don't use vector search.
        embeddings = None
        if processing_type in ("vector", "hybrid"):
            if embedding_model:
                wrapper = self.llm_factory.get_model(embedding_model)
            else:
                wrapper = self.llm_factory.get_default_model()
            embeddings = wrapper._embeddings_client

        # Run search
        results = retriever.search(
            kb_id=kb_id,
            query=query,
            embeddings=embeddings,
            search_type=effective_search_type,
            top_k=effective_top_k,
            vector_weight=vector_weight,
            keyword_weight=keyword_weight,
            processing_type=processing_type,
        )

        # Add KB name to results
        kb_name = kb_config.get("name", "")
        for r in results:
            r["knowledge_base_name"] = kb_name

        return {
            "query": query,
            "results": results,
            "total_results": len(results),
            "search_type": effective_search_type,
            "top_k": effective_top_k,
        }

    async def _load_kb_config(self, kb_id: str) -> dict:
        """Load KB configuration from DB (no user scoping for tool context)."""
        from sqlalchemy import select
        from echolib.models.knowledge import KnowledgeBase
        from echolib.repositories.base import safe_uuid

        kb_uuid = safe_uuid(kb_id)
        if kb_uuid is None:
            return {}

        async with get_db_session() as db:
            result = await db.execute(
                select(KnowledgeBase).where(
                    KnowledgeBase.id == kb_uuid,
                    KnowledgeBase.is_deleted == False,
                )
            )
            kb = result.scalar_one_or_none()
            if not kb:
                return {}
            return {
                "name": kb.name,
                "top_k": kb.top_k,
                "search_type": kb.search_type,
                "embedding_model": kb.embedding_model,
                "vector_weight": kb.vector_weight,
                "keyword_weight": kb.keyword_weight,
                "processing_type": kb.processing_type,
            }
