"""EchoAI Knowledge Search Agent Tool"""
