from typing import Iterable, Optional
import logging

from echolib.llm_resolver import resolve_and_build_llm_sync

logger = logging.getLogger(__name__)


def summarize_documents(docs: Iterable, max_chars: int = 8000, user_id: Optional[str] = None) -> str:
    """Summarize a collection of documents using an LLM.

    WHAT: Merges document content, truncates to max_chars, and sends to an LLM
          for summarization.
    WHY:  Provides a concise summary of potentially large document collections
          for downstream consumption.
    INPUT:
        docs      -- Iterable of document objects (with .page_content) or strings.
        max_chars -- Maximum characters to send to the LLM (default 8000).
        user_id   -- Optional user ID for credential resolution.
    OUTPUT: A string containing the LLM-generated summary.
    """
    parts = []
    for doc in docs:
        content = getattr(doc, "page_content", None)
        if content is None:
            content = str(doc)
        parts.append(content)

    merged = "\n\n".join(parts)
    if len(merged) > max_chars:
        merged = merged[:max_chars]

    llm = resolve_and_build_llm_sync(
        user_id=user_id,
        component="summarizer",
        temperature=0.1,
        allow_platform_fallback=True,
        framework="langchain",
    )

    prompt = "Summarize the following content clearly and concisely:\n" + merged
    return llm.invoke(prompt).content
