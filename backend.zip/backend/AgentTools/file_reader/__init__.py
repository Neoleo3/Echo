"""
File reader core package.
"""
