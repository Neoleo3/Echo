import io
import logging
from typing import Optional

import pandas as pd

from echolib.llm_resolver import resolve_and_build_llm_sync

logger = logging.getLogger(__name__)


class CSVSummarizer:
    """Summarize CSV/Excel datasets using an LLM."""

    def summarize(self, raw_bytes: bytes, file_name: str, stream: bool = False, user_id: Optional[str] = None):
        """Generate a natural-language summary of a tabular dataset.

        WHAT: Reads a CSV or Excel file, computes basic statistics, and asks an
              LLM to explain the dataset.
        WHY:  Gives users a quick understanding of uploaded data without manual
              inspection.
        INPUT:
            raw_bytes -- Raw file content as bytes.
            file_name -- Original filename (used to detect CSV vs Excel).
            stream    -- Whether to enable streaming on the LLM.
            user_id   -- Optional user ID for credential resolution.
        OUTPUT: A string containing the LLM-generated dataset explanation.
        """
        if file_name.lower().endswith(".csv"):
            df = pd.read_csv(io.BytesIO(raw_bytes))
        else:
            df = pd.read_excel(io.BytesIO(raw_bytes))

        stats = {
            "rows": len(df),
            "columns": list(df.columns),
            "dtypes": df.dtypes.astype(str).to_dict(),
            "missing": df.isnull().sum().to_dict(),
            "numeric_summary": df.describe().to_dict(),
        }

        llm = resolve_and_build_llm_sync(
            user_id=user_id,
            component="csv_summarizer",
            temperature=0,
            allow_platform_fallback=True,
            framework="langchain",
            streaming=stream,
        )

        prompt = f"Explain this dataset clearly:\n{stats}"
        return llm.invoke(prompt).content
