import io
import logging
from typing import Optional

import pandas as pd
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent

from echolib.llm_resolver import resolve_and_build_llm_sync

from .stream_handler import TokenCollector

logger = logging.getLogger(__name__)


class CSVQueryAgent:
    """Agent for querying CSV/Excel data using natural language."""

    def __init__(self, stream: bool = False, user_id: Optional[str] = None):
        self.collector = TokenCollector() if stream else None

        callback_kwargs = {}
        if stream and self.collector:
            callback_kwargs["streaming"] = True
            callback_kwargs["callbacks"] = [self.collector]

        self.llm = resolve_and_build_llm_sync(
            user_id=user_id,
            component="csv_agent",
            temperature=0,
            allow_platform_fallback=True,
            framework="langchain",
            **callback_kwargs,
        )

    def create_agent(self, raw_bytes: bytes, file_name: str):
        """Create a pandas dataframe agent from raw file bytes.

        WHAT: Parses a CSV or Excel file into a DataFrame and creates a
              LangChain pandas agent for natural-language querying.
        WHY:  Allows users to ask questions about tabular data without
              writing code.
        INPUT:
            raw_bytes -- Raw file content as bytes.
            file_name -- Original filename (used to detect CSV vs Excel).
        OUTPUT: A LangChain agent capable of answering questions about the data.
        """
        if file_name.lower().endswith(".csv"):
            df = pd.read_csv(io.BytesIO(raw_bytes))
        else:
            df = pd.read_excel(io.BytesIO(raw_bytes))

        return create_pandas_dataframe_agent(
            self.llm,
            df,
            verbose=True,
            allow_dangerous_code=True,
            include_df_in_prompt=True,
            prefix="""
You are a data analyst working with a pandas dataframe called df.
Run Python code to answer questions.

IMPORTANT:
- No Python code in final answer
- Plain language only
- No technical jargon
""",
        )
