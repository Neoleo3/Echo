from typing import Any, Dict, Literal, Optional

from pydantic import BaseModel, Field


class FileReaderInput(BaseModel):
    file_name: str
    # Optional: inferred from the file extension when missing/unknown so a caller
    # that forgets the mime (or sends a parameterized one) does not fail.
    mime_type: str = ""
    content_base64: Optional[str] = None

    mode: Literal["extract", "query", "summarize"] = "extract"
    query: Optional[str] = None
    stream: bool = False

    chunk_size: int = Field(default=1000, ge=0, le=5000)
    chunk_overlap: int = Field(default=200, ge=0, le=1000)


class FileReaderResult(BaseModel):
    file_name: str
    file_type: str
    metadata: Dict[str, Any]
    result: Any
