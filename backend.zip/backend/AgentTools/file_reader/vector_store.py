import os

from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings

from echolib.secrets_provider import secrets
import logging
logger = logging.getLogger(__name__)

ROOT = "vector_db_storage"


def _build_empty_store(emb: OpenAIEmbeddings) -> FAISS:
    """Create an empty FAISS store without seeding fake documents."""
    import faiss

    probe_vector = emb.embed_query("faiss_dimension_probe")
    if not probe_vector:
        raise ValueError("Embedding backend returned an empty vector for index initialization")

    index = faiss.IndexFlatL2(len(probe_vector))
    return FAISS(
        embedding_function=emb,
        index=index,
        docstore=InMemoryDocstore(),
        index_to_docstore_id={},
    )


def load_or_create(doc_id: str):
    path = os.path.join(ROOT, doc_id)
    os.makedirs(path, exist_ok=True)


    api_key = (
        secrets.get_secret("FALLBACK_AZURE_OPENAI_API_KEY")
        or secrets.get_secret("AZURE_OPENAI_API_KEY", "")
    )

    endpoint = (
        secrets.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
        or secrets.get_secret(
            "AZURE_OPENAI_ENDPOINT",
            "https://aiabotgpt.openai.azure.com/"
        )
    )

    deployment_embeddings = (
        secrets.get_secret(
            "FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
        )
        or "embedding_text"
    )

    if not api_key:
        raise ValueError(
        "FALLBACK_AZURE_OPENAI_API_KEY / AZURE_OPENAI_API_KEY "
        "is not configured"
        )
    
    if not endpoint:
        raise ValueError(
            "FALLBACK_AZURE_OPENAI_ENDPOINT / AZURE_OPENAI_ENDPOINT "
            "is not configured"
        )

    logger.info(
        "FALLBACK_AZURE_OPENAI_ENDPOINT=%s",
        secrets.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
    )
    
    logger.info(
            "AZURE_OPENAI_ENDPOINT=%s",
            secrets.get_secret("AZURE_OPENAI_ENDPOINT", "")
        )
    
    logger.info(
        "Resolved endpoint=%s",
        endpoint
    )

    logger.info(
            "Resolved deployment_embeddings=%s",
            deployment_embeddings
        )

    logger.info(
        "FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT=%s",
        secrets.get_secret(
            "FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
        )
    )

    logger.info(
        "Resolved deployment_embeddings=%s",
        deployment_embeddings
    )

    logger.info(
        "API key present=%s",
        bool(api_key)
    )

    
    # emb = AzureOpenAIEmbeddings(
    #     azure_endpoint=endpoint,
    #     api_key=api_key,
    #     azure_deployment=deployment_embeddings,
    #     api_version="2025-01-01-preview"
    # )

    emb = AzureOpenAIEmbeddings(
    azure_endpoint=endpoint,
    api_key=api_key,
    azure_deployment=deployment_embeddings,
    model="embedding_text",
    api_version="2024-02-01",
)


    logger.info(
        "Embeddings class=%s",
        type(emb).__name__
    )

    logger.info(
        "embedding.model=%s",
        getattr(emb, "model", None)
    )

    logger.info(
        "embedding.deployment=%s",
        getattr(emb, "deployment", None)
    )

    logger.info(
        "embedding.azure_endpoint=%s",
        getattr(emb, "azure_endpoint", None)
    )

    logger.info(
        "embedding.openai_api_base=%s",
        getattr(emb, "openai_api_base", None)
    )

    logger.info(
        "embedding.openai_api_version=%s",
        getattr(emb, "openai_api_version", None)
    )

    if os.path.exists(os.path.join(path, "index.faiss")):
        return FAISS.load_local(
            path,
            emb,
            allow_dangerous_deserialization=True
        )

    return _build_empty_store(emb)


def save(store, doc_id: str):
    store.save_local(os.path.join(ROOT, doc_id))
