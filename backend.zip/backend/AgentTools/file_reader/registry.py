"""
Parser registry for the File Reader tool.

Resolution is robust on purpose: a missing, parameterized, or wrong ``mime_type``
is the most common cause of intermittent "Unsupported mime_type" failures (which
in turn starve downstream document generators of content, so the downloadable
link never appears). We therefore:

  * register every available parser (not just pdf/json/xml),
  * normalize the mime (strip ``; charset=...`` and lowercase),
  * fall back to the file extension when the mime is missing/unknown,
  * import optional parsers defensively so one missing dependency cannot break
    the whole tool.
"""

import logging
import os
from typing import Dict, Optional

from .parsers.base import BaseParser

logger = logging.getLogger(__name__)

PARSER_REGISTRY: Dict[str, BaseParser] = {}

# Extension -> canonical mime. Used to infer/repair a missing or wrong mime_type.
EXT_TO_MIME: Dict[str, str] = {
    ".pdf": "application/pdf",
    ".json": "application/json",
    ".xml": "application/xml",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt": "application/vnd.ms-powerpoint",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".log": "text/plain",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}


def _register(mimes, factory) -> None:
    """Instantiate ``factory`` and map it to each mime; skip on any import/init error."""
    try:
        inst = factory()
    except Exception as e:  # missing optional dependency, etc.
        logger.warning("file_reader: parser unavailable for %s (%s)", mimes, e)
        return
    for m in mimes:
        PARSER_REGISTRY[m] = inst


def _safe_import_and_register() -> None:
    # Core parsers (core deps — should always be present)
    try:
        from .parsers.pdf_parser import PdfParser
        _register(["application/pdf"], PdfParser)
    except Exception as e:
        logger.warning("file_reader: PdfParser import failed (%s)", e)
    try:
        from .parsers.json_parser import JsonParser
        _register(["application/json", "text/json"], JsonParser)
    except Exception as e:
        logger.warning("file_reader: JsonParser import failed (%s)", e)
    try:
        from .parsers.xml_parser import XmlParser
        _register(["application/xml", "text/xml"], XmlParser)
    except Exception as e:
        logger.warning("file_reader: XmlParser import failed (%s)", e)
    try:
        from .parsers.docx_parser import DocxParser
        _register(
            [
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/msword",
            ],
            DocxParser,
        )
    except Exception as e:
        logger.warning("file_reader: DocxParser import failed (%s)", e)
    try:
        from .parsers.txt_parser import TxtParser
        _register(["text/plain", "text/markdown"], TxtParser)
    except Exception as e:
        logger.warning("file_reader: TxtParser import failed (%s)", e)
    # Optional parsers (extra deps — guard each)
    try:
        from .parsers.pptx_parser import PptxParser
        _register(
            [
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "application/vnd.ms-powerpoint",
            ],
            PptxParser,
        )
    except Exception as e:
        logger.warning("file_reader: PptxParser unavailable (%s)", e)
    try:
        from .parsers.xlsx_parser import XlsxParser
        _register(
            [
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel",
            ],
            XlsxParser,
        )
    except Exception as e:
        logger.warning("file_reader: XlsxParser unavailable (%s)", e)
    try:
        from .parsers.csv_text_parser import CsvTextParser
        _register(["text/csv"], CsvTextParser)
    except Exception as e:
        logger.warning("file_reader: CsvTextParser unavailable (%s)", e)
    try:
        from .parsers.image_parser import ImageParser
        _register(["image/png", "image/jpeg", "image/jpg", "image/webp"], ImageParser)
    except Exception as e:
        logger.warning("file_reader: ImageParser unavailable (%s)", e)


_safe_import_and_register()


def normalize_mime(mime: Optional[str]) -> str:
    """Lowercase the mime and strip parameters like ``; charset=binary``."""
    if not mime:
        return ""
    return mime.split(";", 1)[0].strip().lower()


def mime_from_filename(file_name: str) -> str:
    """Best-effort mime from the file extension ('' if unknown)."""
    ext = os.path.splitext(file_name or "")[1].lower()
    return EXT_TO_MIME.get(ext, "")


def resolve_parser(file_name: str = "", mime_type: str = "") -> Optional[BaseParser]:
    """Resolve a parser by mime first, then by file extension. Robust to a
    missing / parameterized / incorrect ``mime_type`` so callers don't fail
    intermittently when the mime is slightly off."""
    parser = PARSER_REGISTRY.get(normalize_mime(mime_type))
    if parser is not None:
        return parser
    mapped = mime_from_filename(file_name)
    if mapped:
        return PARSER_REGISTRY.get(mapped)
    return None
