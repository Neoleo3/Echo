from typing import Dict

from .base import BaseParser


class CsvTextParser(BaseParser):
    """Decode CSV bytes as text for extract / chunk / RAG (not the SQL CSV agent)."""

    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        try:
            text = raw_bytes.decode("utf-8")
        except UnicodeDecodeError:
            text = raw_bytes.decode("latin-1", errors="replace")
        return {"content": text.strip()}

