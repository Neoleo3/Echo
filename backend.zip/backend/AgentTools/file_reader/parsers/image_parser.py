"""
Image parser for file_reader.

Extracts text from raster images (JPEG, PNG, BMP, TIFF, WEBP) using
pytesseract + Pillow.  Applies pre-processing (greyscale, contrast, upscale)
to maximise OCR accuracy.

Install: pip install pytesseract Pillow
Also install Tesseract binary: https://github.com/tesseract-ocr/tesseract
"""

from __future__ import annotations

import io
import logging
from typing import Dict

from .base import BaseParser

logger = logging.getLogger(__name__)


class ImageParser(BaseParser):
    """Parse image bytes to OCR text."""

    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        try:
            from PIL import Image, ImageOps, ImageEnhance
            import pytesseract
        except ImportError as exc:
            raise ImportError(
                "pytesseract and Pillow are required for image OCR.  "
                "Install: pip install pytesseract Pillow"
            ) from exc

        img = Image.open(io.BytesIO(raw_bytes))

        # Pre-process for better accuracy
        img = img.convert("L")           # greyscale
        w, h = img.size
        if w < 1200 or h < 1200:
            scale = max(1200 / w, 1200 / h)
            img = img.resize((int(w * scale), int(h * scale)))
        img = ImageOps.autocontrast(img)
        img = ImageEnhance.Sharpness(img).enhance(1.4)

        text = pytesseract.image_to_string(img).strip()
        return {"content": text}
