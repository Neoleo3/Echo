"""
Plain-text parser — .txt, .md, .log, .html, etc.
"""
from __future__ import annotations

import re
from typing import Dict

from .base import BaseParser


class TxtParser(BaseParser):
    """Decode plain-text or HTML bytes to a string."""

    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        # Try UTF-8 first, then Latin-1 as fallback
        for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
            try:
                text = raw_bytes.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            text = raw_bytes.decode("utf-8", errors="replace")

        # Strip HTML tags if the content looks like HTML
        if re.search(r"<[a-z]+[^>]*>", text, re.IGNORECASE):
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s{2,}", " ", text)

        return {"content": text.strip()}
