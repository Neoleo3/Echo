"""
Document parser implementations.
"""
