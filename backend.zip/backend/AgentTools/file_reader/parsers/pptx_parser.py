"""
PPTX / PPT parser for file_reader.

Extracts all text from every slide, including:
  - Shape text frames
  - Table cell text
  - Notes (speaker notes)
  - SmartArt / group shape text

For legacy .ppt files, a LibreOffice-based conversion is attempted first,
then falls back to python-pptx directly on the bytes.

Install: pip install python-pptx
"""

from __future__ import annotations

import io
import logging
import subprocess
import tempfile
import os
from typing import Dict, List

from .base import BaseParser

logger = logging.getLogger(__name__)


def _text_from_shape(shape: object) -> List[str]:
    """Recursively collect all text from a shape (handles groups)."""
    from pptx.enum.shapes import MSO_SHAPE_TYPE  # type: ignore

    parts: List[str] = []
    try:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            for child in shape.shapes:
                parts.extend(_text_from_shape(child))
            return parts
    except Exception:
        pass

    # Table
    try:
        if shape.has_table:
            for row in shape.table.rows:
                cell_texts = [c.text.strip() for c in row.cells if c.text.strip()]
                if cell_texts:
                    parts.append("\t".join(cell_texts))
            return parts
    except Exception:
        pass

    # Text frame
    try:
        if shape.has_text_frame:
            t = shape.text_frame.text.strip()
            if t:
                parts.append(t)
    except Exception:
        pass

    return parts


class PptxParser(BaseParser):
    """Parse .pptx (and .ppt via LibreOffice conversion) to plain text."""

    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        try:
            from pptx import Presentation
        except ImportError as exc:
            raise ImportError(
                "python-pptx is required.  Install: pip install python-pptx"
            ) from exc

        try:
            prs = Presentation(io.BytesIO(raw_bytes))
        except Exception:
            # May be a legacy .ppt — attempt LibreOffice conversion
            raw_bytes = self._convert_ppt_to_pptx(raw_bytes)
            prs = Presentation(io.BytesIO(raw_bytes))

        slide_texts: List[str] = []
        for slide_num, slide in enumerate(prs.slides, start=1):
            parts: List[str] = [f"--- Slide {slide_num} ---"]

            for shape in slide.shapes:
                parts.extend(_text_from_shape(shape))

            # Speaker notes
            try:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    parts.append(f"[Notes] {notes}")
            except Exception:
                pass

            if len(parts) > 1:  # More than just the header
                slide_texts.append("\n".join(parts))

        content = "\n\n".join(slide_texts).strip()
        return {"content": content}

    @staticmethod
    def _convert_ppt_to_pptx(raw_bytes: bytes) -> bytes:
        """
        Convert legacy .ppt bytes to .pptx via LibreOffice headless.
        Returns .pptx bytes or raises if LibreOffice is unavailable.
        """
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "input.ppt")
            with open(src, "wb") as fh:
                fh.write(raw_bytes)
            try:
                subprocess.run(
                    ["libreoffice", "--headless", "--convert-to", "pptx",
                     "--outdir", tmp, src],
                    check=True,
                    capture_output=True,
                    timeout=60,
                )
            except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
                raise ValueError(
                    "Could not convert .ppt to .pptx. LibreOffice is required for "
                    "legacy .ppt files. Error: " + str(exc)
                ) from exc

            out = os.path.join(tmp, "input.pptx")
            with open(out, "rb") as fh:
                return fh.read()
