"""
DOCX (Microsoft Word) Parser

Extracts text, tables, metadata, and structure from .docx files.
Uses python-docx library (BSD license).
"""

from typing import Dict, List, Any
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

from .base import BaseParser


class DocxParser(BaseParser):
    """Parse .docx files and extract structured content."""
    
    def parse(self, raw_bytes: bytes) -> Dict[str, Any]:
        """
        Parse DOCX file and extract text, tables, and metadata.
        
        Args:
            raw_bytes: Binary content of .docx file
            
        Returns:
            Dict with:
                - content: Full text content (all paragraphs)
                - tables: List of table data (list of lists)
                - paragraphs: List of individual paragraphs
                - metadata: Document metadata (author, title, etc.)
                - statistics: Word count, paragraph count, etc.
        """
        from io import BytesIO
        from ...exceptions import CorruptedDocxError
        
        try:
            # Load document from bytes
            doc = Document(BytesIO(raw_bytes))
        except Exception as e:
            raise CorruptedDocxError(e)
        
        # Extract content
        paragraphs = self._extract_paragraphs(doc)
        tables = self._extract_tables(doc)
        metadata = self._extract_metadata(doc)
        
        # Combine paragraphs and tables into full content
        content_parts = []
        content_parts.extend(paragraphs)
        
        for table_idx, table_rows in enumerate(tables):
            content_parts.append(f"\n[TABLE {table_idx + 1}]\n")
            for row in table_rows:
                content_parts.append(" | ".join(str(cell) for cell in row))
        
        full_content = "\n".join(content_parts).strip()
        
        return {
            "content": full_content,
            "paragraphs": paragraphs,
            "tables": tables,
            "metadata": metadata,
            "statistics": {
                "paragraph_count": len(paragraphs),
                "table_count": len(tables),
                "word_count": len(full_content.split()),
                "character_count": len(full_content),
            }
        }
    
    def _extract_paragraphs(self, doc: Document) -> List[str]:
        """Extract all paragraphs from document."""
        paragraphs = []
        
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:  # Only include non-empty paragraphs
                paragraphs.append(text)
        
        return paragraphs
    
    def _extract_tables(self, doc: Document) -> List[List[List[str]]]:
        """Extract all tables with their data."""
        tables = []
        
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [
                    cell.text.strip() for cell in row.cells
                ]
                table_data.append(row_data)
            
            if table_data:
                tables.append(table_data)
        
        return tables
    
    def _extract_metadata(self, doc: Document) -> Dict[str, Any]:
        """Extract document metadata."""
        core_props = doc.core_properties
        
        metadata = {
            "title": core_props.title or "",
            "author": core_props.author or "",
            "subject": core_props.subject or "",
            "keywords": core_props.keywords or "",
            "comments": core_props.comments or "",
            "category": core_props.category or "",
        }
        
        # Add timestamps if available
        if core_props.created:
            metadata["created"] = core_props.created.isoformat()
        if core_props.modified:
            metadata["modified"] = core_props.modified.isoformat()
        
        return metadata
