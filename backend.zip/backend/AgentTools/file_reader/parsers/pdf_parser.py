from typing import Dict
from io import BytesIO

from pypdf import PdfReader

from .base import BaseParser


class PdfParser(BaseParser):
    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        # pypdf expects a seekable stream, not raw bytes.
        reader = PdfReader(BytesIO(raw_bytes))
        pages = []
        for page in reader.pages:
            text = page.extract_text() or ""
            pages.append(text)
        content = "\n\n".join(pages).strip()
        return {"content": content}
