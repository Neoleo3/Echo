from io import BytesIO
from typing import Dict

from .base import BaseParser


class XlsxParser(BaseParser):
    """
    Flatten workbook cell values to plain text for extract / query / summarize.

    Uses read-only iteration for large files. data_only=True reads computed values.
    """

    def parse(self, raw_bytes: bytes) -> Dict[str, str]:
        from openpyxl import load_workbook

        bio = BytesIO(raw_bytes)
        wb = load_workbook(bio, read_only=True, data_only=True)
        parts: list[str] = []
        try:
            for sheet in wb.worksheets:
                parts.append(f"=== Sheet: {sheet.title} ===")
                for row in sheet.iter_rows(values_only=True):
                    cells = ["" if c is None else str(c).strip() for c in row]
                    if any(cells):
                        parts.append("\t".join(cells))
        finally:
            wb.close()
        content = "\n".join(parts).strip()
        return {"content": content}
