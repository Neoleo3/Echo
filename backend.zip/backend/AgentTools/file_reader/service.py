import base64
import binascii
import hashlib
import os
from typing import Optional

from .models import FileReaderInput
from .stream_utils import stream_text
from .registry import PARSER_REGISTRY, resolve_parser, normalize_mime, mime_from_filename
from .vector_store import load_or_create, save
from .embeddings import split_into_chunks
from .summarizer import summarize_documents
from .csv_capability.csv_agent import CSVQueryAgent
from .csv_capability.csv_summarizer import CSVSummarizer

MAX_SIZE = 50 * 1024 * 1024


def is_tabular(name: str, mime: str) -> bool:
    return name.lower().endswith((".csv", ".xls", ".xlsx"))


def doc_id(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


class FileReaderService:
    def _coerce_input(self, data: FileReaderInput | dict) -> FileReaderInput:
        if isinstance(data, FileReaderInput):
            normalized = data.model_copy()
        elif isinstance(data, dict):
            payload = dict(data)
            if not payload.get("chunk_size"):
                payload["chunk_size"] = 1000
            if payload.get("chunk_overlap") is None:
                payload["chunk_overlap"] = 200
            normalized = FileReaderInput.model_validate(payload)
        else:
            raise TypeError(f"Unsupported File Reader payload type: {type(data)!r}")

        if not normalized.chunk_size:
            normalized.chunk_size = 1000
        if normalized.chunk_overlap is None:
            normalized.chunk_overlap = 200
        if normalized.chunk_overlap >= normalized.chunk_size:
            normalized.chunk_overlap = min(200, max(0, normalized.chunk_size - 1))
        return normalized

    def _resolve_bytes_from_uploads(self, file_name: str) -> Optional[bytes]:
        safe_name = os.path.basename(file_name or "")
        if not safe_name:
            return None

        safe_norm = safe_name.strip().lower()
        backend_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        roots = []
        env_dir = os.getenv("APP_UPLOADS_DIR")
        if env_dir:
            roots.append(os.path.abspath(env_dir))
        roots.append(os.path.join(backend_root, "apps", "appmgr", "uploads"))

        seen = set()
        for base in roots:
            if not base or base in seen or not os.path.isdir(base):
                continue
            seen.add(base)
            for dirpath, _, filenames in os.walk(base):
                for candidate in filenames:
                    if candidate.strip().lower().endswith(safe_norm):
                        path = os.path.join(dirpath, candidate)
                        try:
                            with open(path, "rb") as handle:
                                return handle.read()
                        except OSError:
                            continue
        return None

    def _decode_base64_content(self, value: str, file_name: str) -> bytes:
        if not isinstance(value, str):
            raise ValueError(
                f"content_base64 for '{file_name}' must be a Base64 string, "
                f"got {type(value).__name__}"
            )

        encoded = value.strip()

        # Support browser FileReader output such as:
        # data:application/pdf;base64,JVBERi0xLjQK...
        if encoded.lower().startswith("data:"):
            header, separator, encoded = encoded.partition(",")

            if not separator or ";base64" not in header.lower():
                raise ValueError(
                    f"Invalid data URL supplied for '{file_name}'. "
                    "Expected a data URL containing ';base64,'."
                )

        # Remove spaces, line breaks, tabs, and other whitespace.
        encoded = "".join(encoded.split())

        if not encoded:
            raise ValueError(
                f"Empty content_base64 supplied for '{file_name}'."
            )

        # Remove existing padding temporarily so that the actual
        # number of Base64 data characters can be checked.
        encoded_without_padding = encoded.rstrip("=")
        remainder = len(encoded_without_padding) % 4

        # A valid Base64 value can never have exactly one remaining
        # character in its final group.
        if remainder == 1:
            raise ValueError(
                f"Invalid or truncated Base64 content for '{file_name}'. "
                f"The payload contains {len(encoded_without_padding)} "
                "Base64 data characters, which leaves a remainder of 1 "
                "when divided by 4. Re-encode the original file and check "
                "that the request is not being truncated."
            )

        # Restore correct padding if the sender omitted it.
        encoded = encoded_without_padding
        encoded += "=" * (-len(encoded) % 4)

        try:
            return base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError(
                f"Invalid Base64 content for '{file_name}': {exc}"
            ) from exc

    # def _resolve_raw_bytes(self, data: FileReaderInput) -> bytes:
    #     if data.content_base64:
    #         raw = base64.b64decode(data.content_base64)
    #     else:
    #         raw = self._resolve_bytes_from_uploads(data.file_name) or b""

    #     if not raw:
    #         raise ValueError(
    #             f"No file content found for '{data.file_name}'. Pass content_base64 or upload the file first."
    #         )

    #     if len(raw) > MAX_SIZE:
    #         raise ValueError("File > 50MB")
    #     return raw

    def _resolve_raw_bytes(self, data: FileReaderInput) -> bytes:
        if data.content_base64:
            raw = self._decode_base64_content(
                value=data.content_base64,
                file_name=data.file_name,
            )
        else:
            raw = self._resolve_bytes_from_uploads(data.file_name) or b""

        if not raw:
            raise ValueError(
                f"No file content found for '{data.file_name}'. "
                "Pass content_base64 or upload the file first."
            )

        if len(raw) > MAX_SIZE:
            raise ValueError(
                f"File '{data.file_name}' exceeds the 50 MB limit."
            )

        return raw

    def process(self, data: FileReaderInput | dict, user_id: Optional[str] = None):
        data = self._coerce_input(data)
        raw = self._resolve_raw_bytes(data)

        # CSV PATH
        if is_tabular(data.file_name, data.mime_type):
            # if data.mode == "query":
            #     agent = CSVQueryAgent(stream=data.stream, user_id=user_id)
            #     exec_agent = agent.create_agent(raw, data.file_name)
            #     exec_agent.invoke({"input": data.query})
            #     text = agent.collector.text() if data.stream else exec_agent.invoke({"input": data.query})["output"]
            #     return stream_text(text) if data.stream else text

            if data.mode == "query":
                agent = CSVQueryAgent(
                    stream=data.stream,
                    user_id=user_id,
                )

                exec_agent = agent.create_agent(
                    raw,
                    data.file_name,
                )

                result = exec_agent.invoke({
                    "input": data.query,
                })

                if data.stream:
                    text = agent.collector.text()
                    return stream_text(text)

                return result["output"]

            if data.mode == "summarize":
                result = CSVSummarizer().summarize(raw, data.file_name, stream=data.stream, user_id=user_id)
                return stream_text(result) if data.stream else result

        # DOCUMENT PATH — resolve by mime, then fall back to the file extension
        # so a missing/parameterized/incorrect mime_type does not fail the call.
        parser = resolve_parser(data.file_name, data.mime_type)
        if not parser:
            raise ValueError(
                f"Unsupported file type for '{data.file_name}' "
                f"(mime_type={data.mime_type!r}). Supported: pdf, docx, pptx, "
                f"xlsx, csv, json, xml, txt/md, png/jpg."
            )
        parsed = parser.parse(raw)
        content = parsed["content"]

        store = load_or_create(doc_id(raw))
        chunks = split_into_chunks(content, data.chunk_size, data.chunk_overlap)
        if data.mode == "extract":
            return content
        store.add_documents(chunks)
        save(store, doc_id(raw))

        if data.mode == "query":
            docs = store.as_retriever().get_relevant_documents(data.query)
            answer = summarize_documents(docs, user_id=user_id)
            return stream_text(answer) if data.stream else answer

        if data.mode == "summarize":
            answer = summarize_documents(chunks, user_id=user_id)
            return stream_text(answer) if data.stream else answer

        return content
