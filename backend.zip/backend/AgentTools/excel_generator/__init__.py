"""
Excel Generator AgentTool package.

Creates formatted Excel workbooks (.xlsx) from structured data provided
by the agent LLM. Uses openpyxl (MIT license).
"""

from .service import ExcelGeneratorService

__all__ = ["ExcelGeneratorService"]
