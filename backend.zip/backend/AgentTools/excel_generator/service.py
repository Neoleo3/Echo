"""
Excel Spreadsheet Generator (ExcelGeneratorService).

Creates formatted .xlsx workbooks from structured data provided by the
agent LLM.  Uses openpyxl (MIT license, already in requirements).

DESCRIPTION-GATED: Only fires when the user explicitly asks for an Excel
file, spreadsheet, workbook, or .xlsx report.
"""

from __future__ import annotations

import ast
import json
import logging
import os
import re
import uuid
from datetime import date, datetime
from typing import Any, Dict, List, Optional
from echolib.blob_storage import (
    upload_to_blob,
    get_blob_url,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Safety limits
# ---------------------------------------------------------------------------
MAX_SHEETS = 5
MAX_ROWS_PER_SHEET = 200


# ---------------------------------------------------------------------------
# Value coercion
# ---------------------------------------------------------------------------

def _coerce(val: Any) -> Any:
    """Convert string representations to native Python types so openpyxl
    writes correct cell types (numbers, booleans, dates)."""
    if val is None:
        return ""
    if isinstance(val, (int, float, bool, datetime, date)):
        return val
    s = str(val).strip()
    if not s:
        return ""
    # Boolean
    if s.lower() in ("true", "yes"):
        return True
    if s.lower() in ("false", "no"):
        return False
    # Percentage like "12.5%"
    if s.endswith("%"):
        try:
            return float(s[:-1]) / 100.0
        except ValueError:
            pass
    # Number (strip common currency symbols and commas)
    cleaned = re.sub(r"[,$€£¥₹]", "", s).replace(",", "")
    if cleaned and cleaned.lstrip("-").replace(".", "", 1).isdigit():
        try:
            return int(cleaned) if "." not in cleaned else float(cleaned)
        except ValueError:
            pass
    # ISO date "2024-01-15"
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        pass
    return s


# ---------------------------------------------------------------------------
# Input helpers
# ---------------------------------------------------------------------------

def _safe_filename(name: Any, default: str = "Report", limit: int = 50) -> str:
    """Sanitise a user-supplied title into a safe filename stem."""
    safe = re.sub(r"[^\w\s\-]", " ", str(name or default)).strip()
    safe = re.sub(r"\s+", " ", safe).strip()
    safe = safe.rstrip(" .")
    return safe[:limit] or default


def _safe_sheet_title(name: Any, fallback: str = "Sheet") -> str:
    """Sanitise a sheet tab name — strip chars disallowed by openpyxl and
    truncate to the 31-character Excel limit."""
    title = str(name or fallback).strip()
    title = re.sub(r"[\\/*?:\[\]]", " ", title)
    title = re.sub(r"\s+", " ", title).strip()
    return (title or fallback)[:31]


def _normalize_headers(headers: Any) -> List[str]:
    """Ensure headers is a list of non-empty strings."""
    if not isinstance(headers, list):
        return []
    return [str(h).strip() for h in headers if str(h).strip()]


def _normalize_sheet(sd: Dict[str, Any]) -> Dict[str, Any]:
    """Normalise a single sheet dict to canonical form with validated
    ``name``, ``headers``, ``rows``, and ``freeze_panes`` keys."""
    sd = dict(sd)

    sd.setdefault("name", "Sheet")
    sd.setdefault("headers", [])
    sd.setdefault("rows", [])

    headers = _normalize_headers(sd.get("headers"))
    rows = sd.get("rows")

    if isinstance(rows, list) and rows:
        first_row = rows[0]
        if isinstance(first_row, (list, tuple)):
            rows = [list(row) for row in rows if isinstance(row, (list, tuple))]
        elif isinstance(first_row, dict):
            # Infer headers from dict keys if not provided
            if not headers:
                headers = [str(k) for k in first_row.keys()]
            rows = [
                [row.get(h, "") for h in headers]
                for row in rows if isinstance(row, dict)
            ]
        else:
            rows = []
    elif not isinstance(rows, list):
        rows = []

    sd["headers"] = headers
    sd["rows"] = rows
    sd.setdefault("freeze_panes", True)
    return sd


def _sheets_from_string(value: str) -> List[Dict[str, Any]]:
    """Parse a JSON (or Python-repr) string into a list of sheet dicts.
    Handles the case where the LLM sends sheets as a serialised string."""
    cleaned = value.strip()
    if not cleaned:
        return []

    # Try standard JSON first
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # Pydantic str() coercion can produce Python repr with single quotes
        try:
            data = ast.literal_eval(cleaned)
            if isinstance(data, (list, dict)):
                if isinstance(data, dict):
                    return [dict(data)]
                return [dict(item) for item in data if isinstance(item, dict)]
        except (ValueError, SyntaxError):
            pass
        raise ValueError(
            "sheets must be a valid JSON array of sheet objects"
        )

    if isinstance(data, dict):
        return [dict(data)]
    if isinstance(data, list):
        return [dict(item) for item in data if isinstance(item, dict)]
    raise ValueError("sheets JSON must be a sheet object or an array of sheet objects")


# ---------------------------------------------------------------------------
# ExcelGeneratorService
# ---------------------------------------------------------------------------

class ExcelGeneratorService:
    """Creates formatted Excel workbooks from structured data.

    Wraps openpyxl to provide a clean API callable from the agent LLM
    via the tool schema.  Applies professional formatting (bold headers,
    colour fills, auto-fit columns, frozen header row) so the output is
    presentation-ready.
    """

    def __init__(self, output_dir: str = None) -> None:
        self.output_dir = output_dir or os.path.join("uploads", "generated", "excel")
        os.makedirs(self.output_dir, exist_ok=True)


    def _normalize_payload(self, payload):

        if not isinstance(payload, dict):
            return {
                "title": "Report",
                "sheets": [],
                "session_id": None,
            }

        if isinstance(payload.get("data"), dict):
            payload = payload["data"]

        if isinstance(payload.get("json_data"), dict):
            payload = payload["json_data"]

        sheets = payload.get("sheets", [])

        if isinstance(sheets, dict):
            sheets = [sheets]

        if not isinstance(sheets, list):
            sheets = []

        return {
            "title": payload.get("title", "Report"),
            "sheets": sheets,
            "session_id": payload.get("session_id"),
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        data: Any = None,
        **kwargs: Any,
    ) -> Dict[str, str]:
        """Create a formatted .xlsx workbook.

        Supports two calling conventions so it works from both the CrewAI
        wrapper (keyword args) and ToolExecutor (single dict):
          1.  service.generate({"title": ..., "sheets": ...})
          2.  service.generate(title=..., sheets=...)

        Returns dict with ``download_url``, ``filename``, ``file_id``, ``result``.
        """
        from openpyxl import Workbook

        # ---- Normalise input ------------------------------------------
        if data is None:
            data = kwargs
        elif not isinstance(data, dict):
            data = {"title": data, **kwargs}

        logger.info("========== EXCEL TOOL INVOKED ==========")
        logger.info("RAW_DATA_TYPE=%s", type(data).__name__)
        logger.info(
            "RAW_DATA=%s",
            json.dumps(data, default=str, indent=2)
        )
        logger.info(
            "RAW_KWARGS=%s",
            json.dumps(kwargs, default=str, indent=2)
        )

        # title = data.get("title", "Report")
        # sheets = data.get("sheets", [])

        normalized = self._normalize_payload(data)

        logger.info(
            "NORMALIZED_PAYLOAD=%s",
            json.dumps(normalized, default=str, indent=2)
        )

        title = normalized["title"]
        sheets = normalized["sheets"]

        logger.info("TITLE=%s", title)
        logger.info("SHEETS_TYPE=%s", type(sheets).__name__)
        logger.info(
            "RAW_SHEETS=%s",
            json.dumps(sheets, default=str, indent=2)
        )

        session_id = (
            data.get("session_id")
            or data.get("chat_session_id")
            or str(uuid.uuid4())
            )

        # Handle sheets passed as a JSON string
        if isinstance(sheets, str):
            sheets = _sheets_from_string(sheets)
        if not isinstance(sheets, list):
            sheets = []

        logger.info(
            "NORMALIZED_SHEETS=%s",
            json.dumps(sheets, default=str, indent=2)
        )

        # ---- Validate -------------------------------------------------
        if not sheets:
            raise ValueError(
                "At least one sheet is required. Provide a 'sheets' list "
                "with name, headers, and rows for each sheet."
            )
        if len(sheets) > MAX_SHEETS:
            raise ValueError(
                f"Too many sheets ({len(sheets)}). "
                f"Maximum allowed is {MAX_SHEETS}."
            )

        total_rows = 0

        for sheet in sheets:
            if isinstance(sheet, dict):
                rows = sheet.get("rows", [])
                if isinstance(rows, list):
                    total_rows += len(rows)

        logger.info("TOTAL_ROWS_RECEIVED=%s", total_rows)

        if total_rows == 0:
            raise ValueError(
                "TOTAL_ROWS_RECEIVED=0"
            )

        # ---- Build workbook -------------------------------------------
        wb = Workbook()
        default_sheet = wb.active
        default_sheet_used = False
        used_names: set[str] = set()

        for raw_sheet in sheets:
            if not isinstance(raw_sheet, dict):
                logger.warning(
                    "Skipping invalid sheet payload: expected dict, got %s",
                    type(raw_sheet).__name__,
                )
                continue

            sd = _normalize_sheet(raw_sheet)
            logger.info(
                "SHEET_NAME=%s HEADERS=%d ROWS=%d",
                sd.get("name"),
                len(sd.get("headers", [])),
                len(sd.get("rows", []))
            )

            logger.info(
                "HEADERS_CONTENT=%s",
                sd.get("headers")
            )

            logger.info(
                "FIRST_ROW=%s",
                sd["rows"][0] if sd["rows"] else None
            )

            if not sd["headers"] and sd["rows"]:
                max_cols = max(
                    (len(r) for r in sd["rows"] if isinstance(r, list)),
                    default=0
                )

                sd["headers"] = [
                    f"Column {i+1}"
                    for i in range(max_cols)
                ]

            # Validate row count
            if len(sd["rows"]) > MAX_ROWS_PER_SHEET:
                raise ValueError(
                    f"Sheet '{sd.get('name', 'Sheet')}' has {len(sd['rows'])} rows. "
                    f"Maximum allowed is {MAX_ROWS_PER_SHEET}."
                )

            # Deduplicate sheet names
            target_title = self._next_unique_sheet_name(
                used_names,
                _safe_sheet_title(sd.get("name") or "Sheet"),
            )
            used_names.add(target_title)

            if not default_sheet_used:
                ws = default_sheet
                ws.title = target_title
                default_sheet_used = True
            else:
                ws = wb.create_sheet(title=target_title)

            self._write_headers(ws, sd["headers"])
            self._write_rows(ws, sd["rows"])
            self._autofit(ws, sd["headers"], sd["rows"])
            logger.info(
                "AFTER_WRITE SHEET=%s MAX_ROW=%s MAX_COL=%s",
                ws.title,
                ws.max_row,
                ws.max_column
            )

            # Freeze header row
            if sd.get("freeze_panes") and sd["headers"]:
                ws.freeze_panes = ws["A2"]

        # Fallback if no valid sheets were written
        if not default_sheet_used:
            default_sheet["A1"] = title or "Report"

        # ---- Save to disk --------------------------------------------
        file_id = str(uuid.uuid4())
        # filename = f"{_safe_filename(title)}.xlsx"
        # base_filename = _safe_filename(title).removesuffix("xlsx")
        # filename = f"{base_filename}.xlsx"

        base_filename = _safe_filename(title)

        base_filename = re.sub(
            r"\s*\.?\s*xlsx$",
            "",
            base_filename,
            flags=re.IGNORECASE,
        ).strip()

        filename = f"{base_filename}.xlsx"

        temp_filename = f"{file_id}_{filename}"

        path = os.path.join(
            self.output_dir,
            temp_filename
        )
        abs_path = os.path.abspath(path)

        for ws in wb.worksheets:
            logger.info(
                "WORKSHEET=%s MAX_ROW=%s MAX_COL=%s",
                ws.title,
                ws.max_row,
                ws.max_column
            )

        wb.save(abs_path)

        logger.info("Excel generated: %s (%d sheets)", filename, len(sheets))

        # blob_name = (
        #     f"generated/excel/"
        #     f"{session_id}/"
        #     f"{file_id}_{filename}"
        #     )

        blob_name = (
            f"generated/excel/"
            f"{session_id}/"
            f"{file_id}/"
            f"{filename}"
        )
                
 
        if not os.path.exists(abs_path):
            raise RuntimeError(
                f"Excel file not created: {abs_path}"
            )

        # logger.info(
        #     "Excel file exists. size=%s",
        #     os.path.getsize(abs_path),
        # )

        logger.info(
            "EXCEL_FILE_PATH=%s",
            abs_path
        )

        logger.info(
            "EXCEL_FILE_SIZE=%s",
            os.path.getsize(abs_path)
        )

        logger.info(
            "Uploading Excel. local_path=%s blob_name=%s",
            abs_path,
            blob_name,
        )

        logger.info("FILENAME=%r", filename)
        logger.info("BLOB_NAME=%r", blob_name)

        uploaded = upload_to_blob(
            local_path=abs_path,
            blob_name=blob_name,
        )
        logger.info(
            "Upload result=%s",
            uploaded,
        )

        if not uploaded:
            raise RuntimeError(
                f"Failed to upload Excel to Azure Blob Storage: {blob_name}"
            )

        download_url = get_blob_url(blob_name)

        logger.info(
            "DOWNLOAD_URL=%s",
            download_url,
        )

        try:
            os.remove(abs_path)
        except Exception:
            logger.warning(
                "Failed to remove local Excel file: %s",
                abs_path,
            )

        logger.info(
            "Excel response=%s",
            {
                "file_path": download_url,
                "filename": filename,
                "file_id": file_id,
            },
        )

        # return {
        #     "file_path": download_url,
        #     "filename": filename,
        #     "file_id": file_id,
        #     "blob_name": blob_name,
        #     "download_url": download_url,
        #     "session_id": session_id,
        #     "result": (
        #         f"Excel spreadsheet generated successfully.\n\n"
        #         f"Download URL:\n{download_url}"
        #         ),
        #     }

        return {
            "file_path": download_url,
            "filename": filename,
            "file_id": file_id,
            "download_url": download_url,
            "session_id": session_id,
            "result": (
                f"File generated successfully.\n\n"
                f"Download URL:\n{download_url}"
            ),
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _next_unique_sheet_name(
        used: set[str], base: str,
    ) -> str:
        """Return *base* if unused, otherwise append a numeric suffix."""
        candidate = base
        suffix = 2
        while candidate in used:
            suffix_str = f" {suffix}"
            candidate = f"{base[:31 - len(suffix_str)]}{suffix_str}"
            suffix += 1
        return candidate

    def _write_headers(self, ws: Any, headers: List[str]) -> None:
        """Write the header row with bold white text on a dark navy fill."""
        from openpyxl.styles import Font, PatternFill, Alignment

        hdr_font = Font(bold=True, color="FFFFFF", size=11)
        hdr_fill = PatternFill(
            start_color="00338D", end_color="00338D", fill_type="solid",  # KPMG blue
        )
        hdr_align = Alignment(horizontal="center", vertical="center")

        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=str(header))
            cell.font = hdr_font
            cell.fill = hdr_fill
            cell.alignment = hdr_align

    def _write_rows(self, ws: Any, rows: List[List[Any]]) -> None:
        """Write data rows with value coercion and alternating fills."""
        from openpyxl.styles import PatternFill, Alignment

        alt_fill = PatternFill(
            start_color="DEE6F2", end_color="DEE6F2", fill_type="solid",  # KPMG-blue tint
        )
        data_align = Alignment(vertical="center")
        pct_fmt = "0.00%"
        date_fmt = "YYYY-MM-DD"

        logger.info(
        "WRITING_ROWS=%s",
        len(rows)
        )

        for ri, row in enumerate(rows, start=2):
            logger.info(
                "ROW_%s=%s",
                ri,
                row)
            
            for ci, val in enumerate(row, start=1):
                coerced = _coerce(val)
                cell = ws.cell(row=ri, column=ci, value=coerced)
                cell.alignment = data_align
                if ri % 2 == 0:
                    cell.fill = alt_fill
                # Apply number formats for coerced types
                if isinstance(coerced, float) and isinstance(val, str) and str(val).strip().endswith("%"):
                    cell.number_format = pct_fmt
                if isinstance(coerced, (date, datetime)):
                    cell.number_format = date_fmt

    def _autofit(self, ws: Any, headers: List[str], rows: List[List[Any]]) -> None:
        """Set column widths based on maximum content length."""
        from openpyxl.utils import get_column_letter

        for ci, h in enumerate(headers, start=1):
            max_len = len(str(h))
            for row in rows:
                if ci - 1 < len(row):
                    max_len = max(max_len, len(str(row[ci - 1] or "")))
            ws.column_dimensions[get_column_letter(ci)].width = min(
                max(max_len + 4, 10), 50,
            )
