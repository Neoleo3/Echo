"""policy engine v2

Revision ID: 088
Revises: 087
"""

from alembic import op
import sqlalchemy as sa

revision = "088"
down_revision = "087"


def upgrade():

    op.add_column(
        "agent_trust_policies",
        sa.Column(
            "policy_prompt",
            sa.Text(),
            nullable=True,
        ),
    )

    op.add_column(
        "agent_trust_policies",
        sa.Column(
            "judge_prompt",
            sa.Text(),
            nullable=True,
        ),
    )

    op.add_column(
        "agent_trust_policies",
        sa.Column(
            "is_system_policy",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )


def downgrade():

    op.drop_column(
        "agent_trust_policies",
        "is_system_policy",
    )

    op.drop_column(
        "agent_trust_policies",
        "judge_prompt",
    )

    op.drop_column(
        "agent_trust_policies",
        "policy_prompt",
    )