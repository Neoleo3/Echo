"""add_updated_at_to_policy_recommendations"""

from alembic import op
import sqlalchemy as sa

revision = "091"
down_revision = "090"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column(
        "agent_trust_policy_recommendations",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),
    )

def downgrade():
    op.drop_column(
        "agent_trust_policy_recommendations",
        "updated_at",
    )