"""add owner_user_id to governance profile

Revision ID: 081
Revises: 080
Create Date: 2026-09-16

"""

from alembic import op
import sqlalchemy as sa


# Replace these values
revision = "081"
down_revision = "080"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 1. Add nullable column first
    op.add_column(
        "agent_governance_profiles",
        sa.Column(
            "owner_user_id",
            sa.String(length=36),
            nullable=True,
        ),
    )

    # 2. Create index
    op.create_index(
        "ix_agent_governance_profiles_owner_user_id",
        "agent_governance_profiles",
        ["owner_user_id"],
        unique=False,
    )

    # 3. Backfill existing records from agents table
    op.execute(
        """
        UPDATE agent_governance_profiles gp
        SET owner_user_id = CAST(a.user_id AS VARCHAR)
        FROM agents a
        WHERE gp.agent_id = a.hexaid
        """
    )

    # 4. Make column mandatory
    op.alter_column(
        "agent_governance_profiles",
        "owner_user_id",
        nullable=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_agent_governance_profiles_owner_user_id",
        table_name="agent_governance_profiles",
    )

    op.drop_column(
        "agent_governance_profiles",
        "owner_user_id",
    )