"""Add triggers for sharing agents and workflows with all users

Revision ID: 043
Revises: 042
Create Date: 2026-05-20

Creates PostgreSQL triggers that automatically distribute agents and
workflows owned by the system user (DEFAULT_USER_ID) to all other users.

Mechanism:
  - INSERT/UPDATE on agents/workflows by system user -> copy to all users
  - INSERT on users -> copy all shared agents/workflows to new user
  - Soft-delete by system user -> cascade soft-delete to all copies

Copies are tracked via a '_shared_from' field injected into the
definition JSONB. User-created items (without '_shared_from') are
never overwritten or affected.

Includes helper functions for easy insertion of shared items:
  fn_insert_shared_agent(JSONB)    -> UUID
  fn_insert_shared_workflow(JSONB) -> UUID

Usage after migration:
  -- Insert from JSON file (supports {"agent": {...}} wrapper or bare def)
  SELECT fn_insert_shared_agent(
    '{"name":"My Agent","role":"Helper",...}'::jsonb
  );

  SELECT fn_insert_shared_workflow(
    '{"name":"My Workflow","status":"draft",...}'::jsonb
  );

  -- Remove a shared item (soft-delete cascades to all copies)
  UPDATE agents SET is_deleted = true
  WHERE agent_id = '<uuid>' AND user_id = '00000000-0000-0000-0000-000000000001';
"""

from typing import Sequence, Union
from alembic import op


revision: str = "043"
down_revision: Union[str, None] = "042"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SYSTEM_USER_ID = "00000000-0000-0000-0000-000000000001"


def upgrade() -> None:
    # ------------------------------------------------------------------
    # 1. Agent sharing trigger function
    # ------------------------------------------------------------------
    op.execute(f"""
    CREATE OR REPLACE FUNCTION fn_share_agent_to_all_users()
    RETURNS TRIGGER AS $$
    DECLARE
        v_system_uid  UUID := '{SYSTEM_USER_ID}'::uuid;
        v_target       RECORD;
        v_copy_uuid    UUID;
        v_copy_hexaid  VARCHAR(32);
        v_copy_def     JSONB;
    BEGIN
        -- Only act on rows owned by the system user
        IF NEW.user_id != v_system_uid THEN
            RETURN NEW;
        END IF;

        -- CASCADE SOFT-DELETE to all copies
        IF NEW.is_deleted = true THEN
            UPDATE agents
            SET is_deleted  = true,
                updated_at  = CURRENT_TIMESTAMP
            WHERE definition->>'_shared_from' = NEW.agent_id::text
              AND is_deleted = false;
            RETURN NEW;
        END IF;

        -- DISTRIBUTE to every active user
        FOR v_target IN
            SELECT user_id
            FROM users
            WHERE user_id != v_system_uid
              AND is_active = true
        LOOP
            -- Deterministic UUID: same (original, user) always yields same ID
            v_copy_uuid   := md5(NEW.agent_id::text || v_target.user_id::text)::uuid;
            v_copy_hexaid := REPLACE(v_copy_uuid::text, '-', '');

            -- Build definition with tracking metadata
            v_copy_def := NEW.definition
                          || jsonb_build_object(
                                 '_shared_from', NEW.agent_id::text,
                                 'agent_id',     v_copy_uuid::text);

            -- Skip users who already have a NON-shared agent with same name
            -- (the unique_agent_name_per_user constraint covers all rows
            --  including soft-deleted, so we check without is_deleted filter)
            IF EXISTS (
                SELECT 1 FROM agents
                WHERE user_id = v_target.user_id
                  AND name    = NEW.name
                  AND (   definition->>'_shared_from' IS NULL
                       OR definition->>'_shared_from' != NEW.agent_id::text)
            ) THEN
                CONTINUE;
            END IF;

            -- Upsert: insert new copy or update existing shared copy
            BEGIN
                INSERT INTO agents
                    (hexaid, agent_id, user_id, name, definition,
                     source_workflow_id, is_deleted, created_at, updated_at)
                VALUES
                    (v_copy_hexaid, v_copy_uuid, v_target.user_id, NEW.name,
                     v_copy_def, NEW.source_workflow_id, false,
                     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (hexaid) DO UPDATE SET
                    name               = EXCLUDED.name,
                    definition         = EXCLUDED.definition,
                    source_workflow_id = EXCLUDED.source_workflow_id,
                    is_deleted         = false,
                    updated_at         = CURRENT_TIMESTAMP;
            EXCEPTION
                WHEN unique_violation THEN
                    -- Name conflict with user-created agent; skip
                    NULL;
            END;
        END LOOP;

        RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    """)

    op.execute("""
    CREATE TRIGGER trg_share_agent_to_all_users
    AFTER INSERT OR UPDATE ON agents
    FOR EACH ROW
    EXECUTE FUNCTION fn_share_agent_to_all_users();
    """)

    # ------------------------------------------------------------------
    # 2. Workflow sharing trigger function
    # ------------------------------------------------------------------
    op.execute(f"""
    CREATE OR REPLACE FUNCTION fn_share_workflow_to_all_users()
    RETURNS TRIGGER AS $$
    DECLARE
        v_system_uid  UUID := '{SYSTEM_USER_ID}'::uuid;
        v_target       RECORD;
        v_copy_uuid    UUID;
        v_copy_hexaid  VARCHAR(32);
        v_copy_def     JSONB;
    BEGIN
        IF NEW.user_id != v_system_uid THEN
            RETURN NEW;
        END IF;

        -- CASCADE SOFT-DELETE
        IF NEW.is_deleted = true THEN
            UPDATE workflows
            SET is_deleted  = true,
                updated_at  = CURRENT_TIMESTAMP
            WHERE definition->>'_shared_from' = NEW.workflow_id::text
              AND is_deleted = false;
            RETURN NEW;
        END IF;

        FOR v_target IN
            SELECT user_id
            FROM users
            WHERE user_id != v_system_uid
              AND is_active = true
        LOOP
            v_copy_uuid   := md5(NEW.workflow_id::text || v_target.user_id::text)::uuid;
            v_copy_hexaid := REPLACE(v_copy_uuid::text, '-', '');

            v_copy_def := NEW.definition
                          || jsonb_build_object(
                                 '_shared_from',  NEW.workflow_id::text,
                                 'workflow_id',   v_copy_uuid::text);

            -- Skip users who have a NON-shared workflow with same name
            IF EXISTS (
                SELECT 1 FROM workflows
                WHERE user_id = v_target.user_id
                  AND name    = NEW.name
                  AND (   definition->>'_shared_from' IS NULL
                       OR definition->>'_shared_from' != NEW.workflow_id::text)
            ) THEN
                CONTINUE;
            END IF;

            BEGIN
                INSERT INTO workflows
                    (hexaid, workflow_id, user_id, name, status,
                     definition, is_deleted, created_at, updated_at)
                VALUES
                    (v_copy_hexaid, v_copy_uuid, v_target.user_id, NEW.name,
                     NEW.status, v_copy_def, false,
                     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (hexaid) DO UPDATE SET
                    name       = EXCLUDED.name,
                    status     = EXCLUDED.status,
                    definition = EXCLUDED.definition,
                    is_deleted = false,
                    updated_at = CURRENT_TIMESTAMP;
            EXCEPTION
                WHEN unique_violation THEN
                    NULL;
            END;
        END LOOP;

        RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    """)

    op.execute("""
    CREATE TRIGGER trg_share_workflow_to_all_users
    AFTER INSERT OR UPDATE ON workflows
    FOR EACH ROW
    EXECUTE FUNCTION fn_share_workflow_to_all_users();
    """)

    # ------------------------------------------------------------------
    # 3. New-user trigger: copy all shared items to freshly signed-up user
    # ------------------------------------------------------------------
    op.execute(f"""
    CREATE OR REPLACE FUNCTION fn_copy_shared_items_to_new_user()
    RETURNS TRIGGER AS $$
    DECLARE
        v_system_uid  UUID := '{SYSTEM_USER_ID}'::uuid;
        v_agent        RECORD;
        v_workflow     RECORD;
        v_copy_uuid    UUID;
        v_copy_hexaid  VARCHAR(32);
        v_copy_def     JSONB;
    BEGIN
        IF NEW.user_id = v_system_uid THEN
            RETURN NEW;
        END IF;

        -- Copy all active shared agents
        FOR v_agent IN
            SELECT agent_id, name, definition, source_workflow_id
            FROM agents
            WHERE user_id   = v_system_uid
              AND is_deleted = false
        LOOP
            v_copy_uuid   := md5(v_agent.agent_id::text || NEW.user_id::text)::uuid;
            v_copy_hexaid := REPLACE(v_copy_uuid::text, '-', '');

            v_copy_def := v_agent.definition
                          || jsonb_build_object(
                                 '_shared_from', v_agent.agent_id::text,
                                 'agent_id',     v_copy_uuid::text);

            BEGIN
                INSERT INTO agents
                    (hexaid, agent_id, user_id, name, definition,
                     source_workflow_id, is_deleted, created_at, updated_at)
                VALUES
                    (v_copy_hexaid, v_copy_uuid, NEW.user_id, v_agent.name,
                     v_copy_def, v_agent.source_workflow_id, false,
                     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (hexaid) DO NOTHING;
            EXCEPTION
                WHEN unique_violation THEN
                    NULL;
            END;
        END LOOP;

        -- Copy all active shared workflows
        FOR v_workflow IN
            SELECT workflow_id, name, status, definition
            FROM workflows
            WHERE user_id   = v_system_uid
              AND is_deleted = false
        LOOP
            v_copy_uuid   := md5(v_workflow.workflow_id::text || NEW.user_id::text)::uuid;
            v_copy_hexaid := REPLACE(v_copy_uuid::text, '-', '');

            v_copy_def := v_workflow.definition
                          || jsonb_build_object(
                                 '_shared_from',  v_workflow.workflow_id::text,
                                 'workflow_id',   v_copy_uuid::text);

            BEGIN
                INSERT INTO workflows
                    (hexaid, workflow_id, user_id, name, status,
                     definition, is_deleted, created_at, updated_at)
                VALUES
                    (v_copy_hexaid, v_copy_uuid, NEW.user_id, v_workflow.name,
                     v_workflow.status, v_copy_def, false,
                     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (hexaid) DO NOTHING;
            EXCEPTION
                WHEN unique_violation THEN
                    NULL;
            END;
        END LOOP;

        RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    """)

    op.execute("""
    CREATE TRIGGER trg_copy_shared_items_to_new_user
    AFTER INSERT ON users
    FOR EACH ROW
    EXECUTE FUNCTION fn_copy_shared_items_to_new_user();
    """)

    # ------------------------------------------------------------------
    # 4. Helper: insert a shared agent from JSON
    #    Accepts {"agent": {...}} wrapper OR bare agent definition.
    # ------------------------------------------------------------------
    op.execute(f"""
    CREATE OR REPLACE FUNCTION fn_insert_shared_agent(p_json JSONB)
    RETURNS UUID AS $$
    DECLARE
        v_system_uid UUID := '{SYSTEM_USER_ID}'::uuid;
        v_def        JSONB;
        v_agent_id   UUID;
        v_hexaid     VARCHAR(32);
        v_name       TEXT;
    BEGIN
        -- Unwrap {{"agent": {{...}}}} envelope if present
        IF p_json ? 'agent' THEN
            v_def := p_json->'agent';
        ELSE
            v_def := p_json;
        END IF;

        v_name := v_def->>'name';
        IF v_name IS NULL OR v_name = '' THEN
            RAISE EXCEPTION 'Agent JSON must include a "name" field';
        END IF;

        -- Use provided agent_id or generate one
        IF v_def->>'agent_id' IS NOT NULL THEN
            v_agent_id := (v_def->>'agent_id')::uuid;
        ELSE
            v_agent_id := gen_random_uuid();
            v_def := v_def || jsonb_build_object('agent_id', v_agent_id::text);
        END IF;

        v_hexaid := REPLACE(v_agent_id::text, '-', '');

        -- Insert under system user; the trigger distributes to all users
        INSERT INTO agents
            (hexaid, agent_id, user_id, name, definition,
             is_deleted, created_at, updated_at)
        VALUES
            (v_hexaid, v_agent_id, v_system_uid, v_name, v_def,
             false, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT (hexaid) DO UPDATE SET
            name       = EXCLUDED.name,
            definition = EXCLUDED.definition,
            is_deleted = false,
            updated_at = CURRENT_TIMESTAMP;

        RETURN v_agent_id;
    END;
    $$ LANGUAGE plpgsql;
    """)

    # ------------------------------------------------------------------
    # 5. Helper: insert a shared workflow from JSON
    # ------------------------------------------------------------------
    op.execute(f"""
    CREATE OR REPLACE FUNCTION fn_insert_shared_workflow(p_json JSONB)
    RETURNS UUID AS $$
    DECLARE
        v_system_uid  UUID := '{SYSTEM_USER_ID}'::uuid;
        v_def         JSONB;
        v_workflow_id UUID;
        v_hexaid      VARCHAR(32);
        v_name        TEXT;
        v_status      TEXT;
    BEGIN
        v_def := p_json;

        v_name := v_def->>'name';
        IF v_name IS NULL OR v_name = '' THEN
            RAISE EXCEPTION 'Workflow JSON must include a "name" field';
        END IF;

        v_status := COALESCE(v_def->>'status', 'draft');

        IF v_def->>'workflow_id' IS NOT NULL THEN
            v_workflow_id := (v_def->>'workflow_id')::uuid;
        ELSE
            v_workflow_id := gen_random_uuid();
            v_def := v_def || jsonb_build_object('workflow_id', v_workflow_id::text);
        END IF;

        v_hexaid := REPLACE(v_workflow_id::text, '-', '');

        INSERT INTO workflows
            (hexaid, workflow_id, user_id, name, status,
             definition, is_deleted, created_at, updated_at)
        VALUES
            (v_hexaid, v_workflow_id, v_system_uid, v_name, v_status,
             v_def, false, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT (hexaid) DO UPDATE SET
            name       = EXCLUDED.name,
            status     = EXCLUDED.status,
            definition = EXCLUDED.definition,
            is_deleted = false,
            updated_at = CURRENT_TIMESTAMP;

        RETURN v_workflow_id;
    END;
    $$ LANGUAGE plpgsql;
    """)

    # ------------------------------------------------------------------
    # 6. SEED: Insert shared agents (trigger distributes to all users)
    # ------------------------------------------------------------------

    # InvoiceInsight Pro
    op.execute("""
    SELECT fn_insert_shared_agent('{
      "icon": "courtCaseFile",
      "name": "InvoiceInsight Pro",
      "role": "Invoice Processing Specialist",
      "model": "gpt-4",
      "tools": [
        "tool_file_reader",
        "tool_web_search",
        "tool_document_analysis",
        "tool_ocr"
      ],
      "prompt": "You are InvoiceInsight Pro, an expert in invoice processing. Your task is to answer user questions regarding invoice creation, approval processes, and payment tracking. Utilize your knowledge to provide clear, concise, and actionable advice. If necessary, you can use the tool_web_search to find additional information or the tool_file_reader to analyze any uploaded invoice documents. Ensure that your responses are tailored to the user''s specific inquiries and provide examples where applicable.",
      "agent_id": "7a93f0ce-5781-4b23-a00b-458053f19ea5",
      "metadata": {
        "created_at": "2026-03-06T08:36:04.135Z",
        "updated_at": "2026-03-06T08:36:04.135Z"
      },
      "settings": {
        "top_p": 0.9,
        "max_token": 1500,
        "temperature": 0.5,
        "max_iteration": 5
      },
      "variables": [],
      "description": "This agent assists users in understanding and managing invoice processing, providing answers to questions related to invoice creation, approval workflows, and payment tracking.",
      "permissions": {
        "allowed_agents": [],
        "can_call_agents": true
      }
    }'::jsonb);
    """)

    # Add more shared agents here:
    # op.execute("""SELECT fn_insert_shared_agent('{...}'::jsonb);""")

    # Add shared workflows here:
    # op.execute("""SELECT fn_insert_shared_workflow('{...}'::jsonb);""")


def downgrade() -> None:
    # Remove all shared copies first (items with _shared_from tracking)
    op.execute(
        "DELETE FROM agents WHERE definition->>'_shared_from' IS NOT NULL"
    )
    op.execute(
        "DELETE FROM workflows WHERE definition->>'_shared_from' IS NOT NULL"
    )
    # Remove system user's originals seeded by this migration
    op.execute(
        "DELETE FROM agents WHERE user_id = '00000000-0000-0000-0000-000000000001' "
        "AND agent_id = '7a93f0ce-5781-4b23-a00b-458053f19ea5'"
    )

    # Drop triggers
    op.execute("DROP TRIGGER IF EXISTS trg_share_agent_to_all_users ON agents")
    op.execute("DROP TRIGGER IF EXISTS trg_share_workflow_to_all_users ON workflows")
    op.execute("DROP TRIGGER IF EXISTS trg_copy_shared_items_to_new_user ON users")

    # Drop functions
    op.execute("DROP FUNCTION IF EXISTS fn_share_agent_to_all_users()")
    op.execute("DROP FUNCTION IF EXISTS fn_share_workflow_to_all_users()")
    op.execute("DROP FUNCTION IF EXISTS fn_copy_shared_items_to_new_user()")
    op.execute("DROP FUNCTION IF EXISTS fn_insert_shared_agent(JSONB)")
    op.execute("DROP FUNCTION IF EXISTS fn_insert_shared_workflow(JSONB)")
