"""create_agent_trust_initialization

Revision ID: 083
Revises: 082
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "083"
down_revision = "082"
branch_labels = None
depends_on = None


def upgrade():

    op.create_table(
        "agent_trust_initialization",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "owner_user_id",
            sa.String(length=36),
            nullable=False,
        ),

        sa.Column(
            "initialization_version",
            sa.Integer(),
            nullable=False,
            server_default="1",
        ),

        sa.Column(
            "initialized_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),

        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("owner_user_id"),
    )

    op.create_index(
        "ix_agent_trust_initialization_owner_user_id",
        "agent_trust_initialization",
        ["owner_user_id"],
        unique=True,
    )


def downgrade():

    op.drop_index(
        "ix_agent_trust_initialization_owner_user_id",
        table_name="agent_trust_initialization",
    )

    op.drop_table(
        "agent_trust_initialization",
    )