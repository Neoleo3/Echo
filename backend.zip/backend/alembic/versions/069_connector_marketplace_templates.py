"""add marketplace templates

Revision ID: 069
Revises: 068
Create Date: 2026-08-25
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.dialects.postgresql import JSONB


# revision identifiers, used by Alembic.
revision = "069"
down_revision = "068"
branch_labels = None
depends_on = None


def upgrade() -> None:

    op.create_table(
        "connector_marketplace_templates",

        sa.Column(
            "id",
            UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),

        sa.Column(
            "template_id",
            sa.String(length=255),
            nullable=False,
        ),

        sa.Column(
            "name",
            sa.String(length=255),
            nullable=False,
        ),

        sa.Column(
            "description",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "icon",
            sa.String(length=500),
            nullable=True,
        ),

        sa.Column(
            "connector_type",
            sa.String(length=50),
            nullable=False,
        ),

        sa.Column(
            "status",
            sa.String(length=50),
            nullable=False,
            server_default="draft",
        ),

        sa.Column(
            "template_json",
            JSONB,
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),

        sa.Column(
            "deleted_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),

        #
        # inherited from BaseModel
        #
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),
    )

    op.create_index(
        "idx_marketplace_template_id",
        "connector_marketplace_templates",
        ["template_id"],
        unique=True,
    )

    op.create_index(
        "idx_marketplace_status",
        "connector_marketplace_templates",
        ["status"],
        unique=False,
    )

    op.create_index(
        "idx_marketplace_deleted_at",
        "connector_marketplace_templates",
        ["deleted_at"],
        unique=False,
    )


def downgrade() -> None:

    op.drop_index(
        "idx_marketplace_deleted_at",
        table_name="connector_marketplace_templates",
    )

    op.drop_index(
        "idx_marketplace_status",
        table_name="connector_marketplace_templates",
    )

    op.drop_index(
        "idx_marketplace_template_id",
        table_name="connector_marketplace_templates",
    )

    op.drop_table(
        "connector_marketplace_templates"
    )