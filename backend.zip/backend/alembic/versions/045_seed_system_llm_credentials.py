"""Seed system-level LLM credentials visible to all users

Revision ID: 045
Revises: 044
Create Date: 2026-06-01

Inserts two UserLlmCredential rows owned by the system user so that
every user sees pre-configured Azure and Ollama LLMs in their dropdown
without needing to add credentials manually.  The ``is_system`` flag in
config_metadata lets the API and frontend mark these as read-only.

Credentials:
  - Azure/gpt-4o-mini  (00000000-0000-0000-0000-000000000100)
  - Ollama/gpt-oss:20b (00000000-0000-0000-0000-000000000200)
"""

import json
from typing import Sequence, Union

from alembic import op
from sqlalchemy import text


revision: str = "045"
down_revision: Union[str, None] = "044"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

SYSTEM_USER_ID = "00000000-0000-0000-0000-000000000001"

AZURE_CREDENTIAL_ID = "00000000-0000-0000-0000-000000000100"
OLLAMA_CREDENTIAL_ID = "00000000-0000-0000-0000-000000000200"

_AZURE_METADATA = {
    "model_id": "azure/gpt-4o-mini",
    "model_name": "gpt-4o-mini",
    "base_url": "https://aiabotgpt.openai.azure.com/",
    "api_version": "2025-01-01-preview",
    "deployment_name": "gpt-4o-mini",
    "description": "Azure provided LLM.",
    "icon": "default",
    "api_key_ref": f"user-cred-{AZURE_CREDENTIAL_ID}",
    "is_system": True,
}

_OLLAMA_METADATA = {
    "model_id": "ollama/gpt-oss:20b",
    "model_name": "gpt-oss:20b",
    "base_url": "http://10.188.100.130:8002/v1",
    "description": "ollama provided LLM.",
    "icon": "default",
    "api_key_ref": f"user-cred-{OLLAMA_CREDENTIAL_ID}",
    "is_system": True,
}


def upgrade() -> None:
    conn = op.get_bind()

    # Azure/gpt-4o-mini
    conn.execute(
        text("""
            INSERT INTO user_llm_credentials
                (credential_id, user_id, credential_name, provider,
                 is_default, metadata, is_deleted,
                 encrypted_api_key, api_key_storage)
            VALUES
                (CAST(:cred_id AS uuid), CAST(:user_id AS uuid), :name, :provider,
                 FALSE, CAST(:meta AS jsonb), FALSE,
                 :api_key, :storage)
            ON CONFLICT (credential_id) DO NOTHING
        """),
        {
            "cred_id": AZURE_CREDENTIAL_ID,
            "user_id": SYSTEM_USER_ID,
            "name": "Azure/gpt-4o-mini",
            "provider": "azure",
            "meta": json.dumps(_AZURE_METADATA),
            "api_key": "ETIqdDg2Gi7Ms38QWxqt7E5bhJiv8JWWZcbv8YAhsUpcWZ6I2ljpJQQJ99BBACHYHv6XJ3w3AAABACOGpgoE",
            "storage": "db",
        },
    )

    # Ollama/gpt-oss:20b  (no API key required)
    conn.execute(
        text("""
            INSERT INTO user_llm_credentials
                (credential_id, user_id, credential_name, provider,
                 is_default, metadata, is_deleted,
                 encrypted_api_key, api_key_storage)
            VALUES
                (CAST(:cred_id AS uuid), CAST(:user_id AS uuid), :name, :provider,
                 FALSE, CAST(:meta AS jsonb), FALSE,
                 NULL, NULL)
            ON CONFLICT (credential_id) DO NOTHING
        """),
        {
            "cred_id": OLLAMA_CREDENTIAL_ID,
            "user_id": SYSTEM_USER_ID,
            "name": "Ollama/gpt-oss:20b",
            "provider": "ollama",
            "meta": json.dumps(_OLLAMA_METADATA),
        },
    )


def downgrade() -> None:
    conn = op.get_bind()
    conn.execute(
        text("""
            DELETE FROM user_llm_credentials
            WHERE credential_id IN (CAST(:azure AS uuid), CAST(:ollama AS uuid))
        """),
        {
            "azure": AZURE_CREDENTIAL_ID,
            "ollama": OLLAMA_CREDENTIAL_ID,
        },
    )
