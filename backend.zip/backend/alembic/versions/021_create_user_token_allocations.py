"""create user_token_allocations table

Revision ID: 021
Revises: 020
Create Date: 2026-06-15

Stores per-user LLM token budgets with organizational metadata.
Analytics endpoints read this table to show token usage vs. allocated limits.
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "021"
down_revision = "020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "user_token_allocations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("email", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=50), nullable=False),
        sa.Column("designation", sa.String(length=255), nullable=True),
        sa.Column("department", sa.String(length=255), nullable=True),
        sa.Column("tag", sa.String(length=255), nullable=True),
        sa.Column("model", sa.String(length=255), nullable=True),
        sa.Column("token_limit", sa.Integer(), nullable=False, server_default="0"),
        sa.Column(
            "token_duration",
            sa.String(length=50),
            nullable=False,
            server_default="daily",
        ),
        sa.Column(
            "is_active",
            sa.Boolean(),
            server_default=sa.text("true"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.user_id"],
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("user_id", name="uq_user_token_alloc_user_id"),
    )

    op.create_index(
        "idx_user_token_alloc_user",
        "user_token_allocations",
        ["user_id"],
        unique=True,
    )
    op.create_index(
        "idx_user_token_alloc_active",
        "user_token_allocations",
        ["is_active"],
    )


def downgrade() -> None:
    op.drop_index("idx_user_token_alloc_active", table_name="user_token_allocations")
    op.drop_index("idx_user_token_alloc_user", table_name="user_token_allocations")
    op.drop_table("user_token_allocations")
