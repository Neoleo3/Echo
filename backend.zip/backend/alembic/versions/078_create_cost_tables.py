"""create cost governance tables

Revision ID: 078
Revises: 077
Create Date: 2026-09-10

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "078"
down_revision = "077"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "agent_trust_cost_records",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("agent_id", sa.String(length=32), nullable=True),
        sa.Column("source_event_id", sa.String(length=64), nullable=True),
        sa.Column("department", sa.String(length=100), nullable=True),
        sa.Column("model", sa.String(length=255), nullable=True),
        sa.Column("provider", sa.String(length=100), nullable=True),
        sa.Column("input_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("output_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("total_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("cost_usd", sa.Float(), nullable=False, server_default="0"),
        sa.Column("billing_source", sa.String(length=50), nullable=True),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("source_event_id", name="uq_at_cost_records_source_event_id"),
    )
    op.create_index("ix_at_cost_records_agent", "agent_trust_cost_records", ["agent_id"])
    op.create_index("ix_at_cost_records_source_event", "agent_trust_cost_records", ["source_event_id"])

    op.create_table(
        "agent_trust_budgets",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("scope", sa.String(length=20), nullable=False),
        sa.Column("scope_id", sa.String(length=255), nullable=True),
        sa.Column("limit_usd", sa.Float(), nullable=False),
        sa.Column("period", sa.String(length=20), nullable=False, server_default="monthly"),
        sa.Column("alert_threshold_pct", sa.Float(), nullable=False, server_default="80"),
        sa.Column("hard_stop", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade():
    op.drop_table("agent_trust_budgets")
    op.drop_table("agent_trust_cost_records")
