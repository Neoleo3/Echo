"""create user_llm_credentials table

Revision ID: 019
Revises: 018
Create Date: 2026-03-16
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import JSONB


revision = "019"
down_revision = "018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "user_llm_credentials",
        sa.Column(
            "credential_id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("credential_name", sa.String(length=255), nullable=False),
        sa.Column("provider", sa.String(length=50), nullable=False),
        sa.Column("is_default", sa.Boolean(), server_default="false", nullable=False),
        sa.Column(
            "metadata",
            JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column("is_deleted", sa.Boolean(), server_default="false", nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("credential_id"),
        sa.UniqueConstraint("user_id", "credential_name", name="uq_user_credential_name"),
    )

    # Partial index: only active (non-deleted) credentials per user
    op.create_index(
        "idx_user_creds_user",
        "user_llm_credentials",
        ["user_id"],
        unique=False,
        postgresql_where=sa.text("is_deleted = FALSE"),
    )

    # Partial index: active credentials filtered by provider
    op.create_index(
        "idx_user_creds_provider",
        "user_llm_credentials",
        ["user_id", "provider"],
        unique=False,
        postgresql_where=sa.text("is_deleted = FALSE"),
    )

    # Partial unique index: at most one active default credential per user
    op.create_index(
        "idx_user_creds_one_default",
        "user_llm_credentials",
        ["user_id"],
        unique=True,
        postgresql_where=sa.text("is_default = TRUE AND is_deleted = FALSE"),
    )


def downgrade() -> None:
    op.drop_index("idx_user_creds_one_default", table_name="user_llm_credentials")
    op.drop_index("idx_user_creds_provider", table_name="user_llm_credentials")
    op.drop_index("idx_user_creds_user", table_name="user_llm_credentials")
    op.drop_table("user_llm_credentials")
