"""Create refresh_tokens table

Revision ID: 008
Revises: 007
Create Date: 2026-02-26

Adds the refresh_tokens table for JWT token-rotation authentication.
Each token stores a SHA-256 hash (never the raw token) and supports
single-use rotation with explicit revocation.

Target Database: PostgreSQL 16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '008'
down_revision: Union[str, None] = '007'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'refresh_tokens',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('user_id', sa.UUID(), nullable=False),
        sa.Column('token_hash', sa.String(length=128), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('is_revoked', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True),
                  server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True),
                  server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.user_id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )

    # Indexes
    op.create_index(
        'ix_refresh_tokens_user_id',
        'refresh_tokens', ['user_id'],
    )
    op.create_index(
        'ix_refresh_tokens_token_hash',
        'refresh_tokens', ['token_hash'],
        unique=True,
    )
    op.create_index(
        'idx_refresh_tokens_user_active',
        'refresh_tokens', ['user_id', 'is_revoked'],
        postgresql_where=sa.text('is_revoked = false'),
    )


def downgrade() -> None:
    op.drop_index('idx_refresh_tokens_user_active', table_name='refresh_tokens')
    op.drop_index('ix_refresh_tokens_token_hash', table_name='refresh_tokens')
    op.drop_index('ix_refresh_tokens_user_id', table_name='refresh_tokens')
    op.drop_table('refresh_tokens')
