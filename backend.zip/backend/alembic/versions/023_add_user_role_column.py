"""Add role column to users table for RBAC

Revision ID: 023
Revises: 022
Create Date: 2026-04-15

Adds a 'role' column to the users table with a CHECK constraint
restricting values to 'super_admin', 'admin', 'user'.
All existing users default to 'user'.
Pre-seeds role assignments for predefined super_admin and admin emails.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "023"
down_revision: Union[str, None] = "022"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Pre-defined role assignments (lowercase emails)
_SUPER_ADMIN_EMAILS = (
    "shreyanf@kpmg.com",
    "nehabehl@kpmg.com",
    "shashanksingh12@kpmg.com",
    "advaitlote@kpmg.com",
)

_ADMIN_EMAILS = (
    "ashnamuthappa@kpmg.com",
    "satyajitga@kpmg.com",
    "vanshikamahajan@kpmg.com",
    "sanjeevanip1@kpmg.com",
)


def upgrade() -> None:
    # 1. Add role column with server default so existing rows get 'user'
    op.add_column(
        "users",
        sa.Column(
            "role",
            sa.String(20),
            nullable=False,
            server_default="user",
        ),
    )

    # 2. Add CHECK constraint to restrict valid values
    op.create_check_constraint(
        "ck_users_role",
        "users",
        "role IN ('super_admin', 'admin', 'user')",
    )

    # 3. Seed roles for predefined super_admin emails
    for email in _SUPER_ADMIN_EMAILS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'super_admin' WHERE lower(email) = :email"
            ).bindparams(email=email.lower())
        )

    # 4. Seed roles for predefined admin emails
    for email in _ADMIN_EMAILS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'admin' WHERE lower(email) = :email"
            ).bindparams(email=email.lower())
        )


def downgrade() -> None:
    op.drop_constraint("ck_users_role", "users", type_="check")
    op.drop_column("users", "role")
