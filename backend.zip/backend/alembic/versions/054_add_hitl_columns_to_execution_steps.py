"""add HITL columns and updated_at to execution_steps

Adds the columns that the ExecutionStep ORM model (echolib/models/execution.py)
declares but that were never created by any migration:
  - hitl_required
  - hitl_decision
  - hitl_decision_timestamp
  - hitl_attempts
  - updated_at (inherited from BaseModel)

Without these, every query on execution_steps raised
``UndefinedColumnError: column execution_steps.hitl_required does not exist``.

Revision ID: 054
Revises: 053
Create Date: 2026-07-03
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "054"
down_revision: Union[str, None] = "053"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


TABLE = "execution_steps"


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns(TABLE)}
    indexes = {idx["name"] for idx in inspector.get_indexes(TABLE)}

    if "hitl_required" not in columns:
        op.add_column(
            TABLE,
            sa.Column(
                "hitl_required",
                sa.Boolean(),
                server_default=sa.text("false"),
                nullable=False,
            ),
        )

    if "hitl_decision" not in columns:
        op.add_column(
            TABLE,
            sa.Column("hitl_decision", postgresql.JSONB(), nullable=True),
        )

    if "hitl_decision_timestamp" not in columns:
        op.add_column(
            TABLE,
            sa.Column(
                "hitl_decision_timestamp",
                sa.DateTime(timezone=True),
                nullable=True,
            ),
        )

    if "hitl_attempts" not in columns:
        op.add_column(
            TABLE,
            sa.Column(
                "hitl_attempts",
                sa.Integer(),
                server_default=sa.text("0"),
                nullable=False,
            ),
        )

    if "updated_at" not in columns:
        op.add_column(
            TABLE,
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                server_default=sa.func.current_timestamp(),
                nullable=False,
            ),
        )

    # Indexes declared on the ORM model's __table_args__.
    if "idx_exec_step_hitl_required" not in indexes:
        op.create_index(
            "idx_exec_step_hitl_required",
            TABLE,
            ["run_id", "hitl_required"],
            unique=False,
            postgresql_where=sa.text("hitl_required = true"),
        )

    if "idx_exec_step_hitl_decision" not in indexes:
        op.create_index(
            "idx_exec_step_hitl_decision",
            TABLE,
            ["step_id", "hitl_decision_timestamp"],
            unique=False,
        )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns(TABLE)}
    indexes = {idx["name"] for idx in inspector.get_indexes(TABLE)}

    if "idx_exec_step_hitl_decision" in indexes:
        op.drop_index("idx_exec_step_hitl_decision", table_name=TABLE)

    if "idx_exec_step_hitl_required" in indexes:
        op.drop_index("idx_exec_step_hitl_required", table_name=TABLE)

    for col in (
        "updated_at",
        "hitl_attempts",
        "hitl_decision_timestamp",
        "hitl_decision",
        "hitl_required",
    ):
        if col in columns:
            op.drop_column(TABLE, col)
