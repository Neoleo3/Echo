"""create agentic_applications table

Revision ID: 026
Revises: 024
Create Date: 2026-04-30
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import JSONB


revision: str = "026"
down_revision: Union[str, None] = "024"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "agentic_applications",
        sa.Column(
            "agentic_app_id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "name",
            sa.String(length=255),
            nullable=False,
        ),
        sa.Column(
            "description",
            sa.Text(),
            nullable=True,
        ),
        sa.Column(
            "status",
            sa.String(length=20),
            server_default="draft",
            nullable=False,
        ),
        sa.Column(
            "canvas_config",
            JSONB(),
            nullable=True,
            comment="Flat array of canvas component objects: [{id, type, x, y, w, h, props}]",
        ),
        sa.Column(
            "is_deleted",
            sa.Boolean(),
            server_default="false",
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.user_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("agentic_app_id"),
    )

    op.create_index(
        "idx_agentic_apps_user",
        "agentic_applications",
        ["user_id"],
        unique=False,
        postgresql_where=sa.text("is_deleted = FALSE"),
    )

    op.create_index(
        "idx_agentic_apps_status",
        "agentic_applications",
        ["user_id", "status"],
        unique=False,
        postgresql_where=sa.text("is_deleted = FALSE"),
    )


def downgrade() -> None:
    op.drop_index("idx_agentic_apps_status", table_name="agentic_applications")
    op.drop_index("idx_agentic_apps_user", table_name="agentic_applications")
    op.drop_table("agentic_applications")
