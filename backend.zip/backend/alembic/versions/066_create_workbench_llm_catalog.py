"""create workbench_llm_catalog table

Revision ID: 066
Revises: 065
Create Date: 2026-08-11
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "066"
down_revision = "065"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "workbench_llm_catalog",
        sa.Column("workbench_llm_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("canonical_model_id", sa.String(length=255), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("provider_type", sa.String(length=100), nullable=False),
        sa.Column("model_name", sa.String(length=255), nullable=False),
        sa.Column("base_url", sa.String(length=1024), nullable=True),
        sa.Column("credential_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default="true", nullable=False),
        sa.Column("metadata", postgresql.JSONB(astext_type=sa.Text()), server_default="{}", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("CURRENT_TIMESTAMP"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("CURRENT_TIMESTAMP"), nullable=False),
        sa.ForeignKeyConstraint(["credential_id"], ["user_llm_credentials.credential_id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["created_by"], ["users.user_id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("workbench_llm_id"),
        sa.UniqueConstraint("canonical_model_id"),
    )

    op.create_index(
        "ix_workbench_llm_catalog_canonical_model_id",
        "workbench_llm_catalog",
        ["canonical_model_id"],
        unique=True,
    )
    op.create_index(
        "ix_workbench_llm_catalog_provider_type",
        "workbench_llm_catalog",
        ["provider_type"],
        unique=False,
    )
    op.create_index(
        "ix_workbench_llm_catalog_credential_id",
        "workbench_llm_catalog",
        ["credential_id"],
        unique=False,
    )
    op.create_index(
        "ix_workbench_llm_catalog_created_by",
        "workbench_llm_catalog",
        ["created_by"],
        unique=False,
    )
    op.create_index(
        "ix_workbench_llm_catalog_is_active",
        "workbench_llm_catalog",
        ["is_active"],
        unique=False,
    )
    op.create_index(
        "idx_workbench_llm_provider_active",
        "workbench_llm_catalog",
        ["provider_type", "is_active"],
        unique=False,
    )


def downgrade():
    op.drop_index("idx_workbench_llm_provider_active", table_name="workbench_llm_catalog")
    op.drop_index("ix_workbench_llm_catalog_is_active", table_name="workbench_llm_catalog")
    op.drop_index("ix_workbench_llm_catalog_created_by", table_name="workbench_llm_catalog")
    op.drop_index("ix_workbench_llm_catalog_credential_id", table_name="workbench_llm_catalog")
    op.drop_index("ix_workbench_llm_catalog_provider_type", table_name="workbench_llm_catalog")
    op.drop_index("ix_workbench_llm_catalog_canonical_model_id", table_name="workbench_llm_catalog")
    op.drop_table("workbench_llm_catalog")
