"""agentic A2UI + orchestration_metadata; app_personas.description

Revision ID: 029
Revises: 028
Create Date: 2026-04-30

- agentic_applications.a2ui_config JSONB
- agentic_applications.orchestration_metadata JSONB (LLM snapshot)
- app_personas.description TEXT (nullable) + seed blurbs for catalog personas
"""
from typing import Sequence, Union

from alembic import op


revision: str = "029"
down_revision: Union[str, None] = "028"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE agentic_applications "
        "ADD COLUMN IF NOT EXISTS a2ui_config JSONB"
    )
    op.execute(
        "ALTER TABLE agentic_applications "
        "ADD COLUMN IF NOT EXISTS orchestration_metadata JSONB"
    )
    op.execute(
        "COMMENT ON COLUMN agentic_applications.orchestration_metadata IS "
        "'LLM orchestration: app_type, reasoning, selected_agents, "
        "selected_workflows, selected_skills, selected_persona'"
    )
    op.execute(
        "ALTER TABLE app_personas ADD COLUMN IF NOT EXISTS description TEXT"
    )
    op.execute(
        "UPDATE app_personas "
        "SET description = 'Friendly, patient tone for end-user help and troubleshooting.' "
        "WHERE name = 'Support Agent' AND description IS NULL"
    )
    op.execute(
        "UPDATE app_personas "
        "SET description = 'Professional HR tone; policies, benefits, and employee matters.' "
        "WHERE name = 'HR Assistant' AND description IS NULL"
    )
    op.execute(
        "UPDATE app_personas "
        "SET description = 'Persuasive, concise tone for prospects and customer conversations.' "
        "WHERE name = 'Sales Assistant' AND description IS NULL"
    )
    op.execute(
        "UPDATE app_personas "
        "SET description = 'Formal, precise language suitable for compliance and legal context.' "
        "WHERE name = 'Legal Advisor' AND description IS NULL"
    )
    op.execute(
        "UPDATE app_personas "
        "SET description = 'Clear, detailed explanations for engineers and technical users.' "
        "WHERE name = 'Technical Expert' AND description IS NULL"
    )


def downgrade() -> None:
    op.execute("ALTER TABLE app_personas DROP COLUMN IF EXISTS description")
    op.execute(
        "ALTER TABLE agentic_applications DROP COLUMN IF EXISTS orchestration_metadata"
    )
    op.execute(
        "ALTER TABLE agentic_applications DROP COLUMN IF EXISTS a2ui_config"
    )
