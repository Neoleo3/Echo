"""Fix ExecutionRunRepository.save_run() method signature - Accept status parameter

Revision ID: 056
Revises: 055
Create Date: 2026-07-04

ISSUE:
- executor.py calls save_run(status=status) with status parameter
- execution_repo.py save_run() method doesn't accept status parameter
- Result: TypeError when workflow execution starts with new workflow
- Prevents ExecutionRun record from being created in database
- Cascades to FK violation errors on execution_steps

ROOT CAUSE:
Method signature mismatch between caller and implementation:
- Caller (executor.py:387): await save_run(..., status=status)
- Method (execution_repo.py:432): async def save_run(db, run_id, workflow_id=None, user_id=None)

FIX:
Update execution_repo.py:
1. Add optional status parameter with default="running" to method signature
2. Update implementation to use parameter instead of hardcoding status="running"

BACKWARD COMPATIBLE:
✅ Default parameter value ensures existing behavior unchanged
✅ Old callers (no status param) continue to work
✅ New callers (with status param) now work correctly
✅ No database schema changes required
✅ No migration-level logic needed (code-only fix)

This migration serves as a version checkpoint documenting the code fix.
The actual fix is in echolib/repositories/execution_repo.py (not in database).
"""

from typing import Union
from alembic import op


revision: str = "056"
down_revision: Union[str, None] = "055"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """
    No database changes required.
    
    This migration documents the application code fix:
    - ExecutionRunRepository.save_run() now accepts optional status parameter
    - Allows executor.py to pass status value when creating execution runs
    - Prevents TypeError that was blocking new workflow execution
    
    Code changes:
    - File: backend/echolib/repositories/execution_repo.py
    - Lines 432-437: Add status: str = "running" to method signature
    - Line 448: Use status parameter instead of hardcoded "running"
    """
    pass


def downgrade() -> None:
    """No database changes to reverse."""
    pass
