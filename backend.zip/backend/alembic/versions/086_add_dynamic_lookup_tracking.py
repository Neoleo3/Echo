"""add_dynamic_lookup_tracking

Revision ID: 086
Revises: 085
Create Date: 2026-09-25

Adds support for dynamic designations/business units with creator tracking.

Changes:
- Add is_predefined and created_by columns to app_designations and app_business_units
- Add case-insensitive unique index on lower(name) for both tables
- Add created_by column (self-referential FK) to users table
- Backfill existing rows as is_predefined=true
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "086"
down_revision = "085"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ─────────────────────────────────────────────────────────────────
    # 1. Add created_by column to users table (self-referential FK)
    # ─────────────────────────────────────────────────────────────────
    op.add_column(
        "users",
        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
    )
    # Add self-referential FK constraint
    op.create_foreign_key(
        "fk_users_created_by",
        "users",
        "users",
        ["created_by"],
        ["user_id"],
        ondelete="SET NULL",
    )

    # ─────────────────────────────────────────────────────────────────
    # 2. Add columns to app_designations
    # ─────────────────────────────────────────────────────────────────
    op.add_column(
        "app_designations",
        sa.Column(
            "is_predefined",
            sa.Boolean(),
            nullable=False,
            server_default="true",
        ),
    )
    op.add_column(
        "app_designations",
        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
    )
    # Add FK to users table
    op.create_foreign_key(
        "fk_app_designations_created_by",
        "app_designations",
        "users",
        ["created_by"],
        ["user_id"],
        ondelete="SET NULL",
    )
    # Add case-insensitive unique index on lower(name)
    op.create_index(
        "idx_app_designations_name_ci",
        "app_designations",
        [sa.text("lower(name)")],
        unique=True,
    )

    # ─────────────────────────────────────────────────────────────────
    # 3. Add columns to app_business_units
    # ─────────────────────────────────────────────────────────────────
    op.add_column(
        "app_business_units",
        sa.Column(
            "is_predefined",
            sa.Boolean(),
            nullable=False,
            server_default="true",
        ),
    )
    op.add_column(
        "app_business_units",
        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
    )
    # Add FK to users table
    op.create_foreign_key(
        "fk_app_business_units_created_by",
        "app_business_units",
        "users",
        ["created_by"],
        ["user_id"],
        ondelete="SET NULL",
    )
    # Add case-insensitive unique index on lower(name)
    op.create_index(
        "idx_app_business_units_name_ci",
        "app_business_units",
        [sa.text("lower(name)")],
        unique=True,
    )


def downgrade() -> None:
    # ─────────────────────────────────────────────────────────────────
    # Remove changes in reverse order
    # ─────────────────────────────────────────────────────────────────

    # Drop indexes and columns from app_business_units
    op.drop_index("idx_app_business_units_name_ci", table_name="app_business_units")
    op.drop_constraint(
        "fk_app_business_units_created_by",
        "app_business_units",
        type_="foreignkey",
    )
    op.drop_column("app_business_units", "created_by")
    op.drop_column("app_business_units", "is_predefined")

    # Drop indexes and columns from app_designations
    op.drop_index("idx_app_designations_name_ci", table_name="app_designations")
    op.drop_constraint(
        "fk_app_designations_created_by",
        "app_designations",
        type_="foreignkey",
    )
    op.drop_column("app_designations", "created_by")
    op.drop_column("app_designations", "is_predefined")

    # Drop FK and column from users
    op.drop_constraint("fk_users_created_by", "users", type_="foreignkey")
    op.drop_column("users", "created_by")
