"""Add updated_at column to execution_runs

Revision ID: 057
Revises: 056
Create Date: 2026-07-04

The execution_runs table was created without the updated_at column even though
ExecutionRun inherits BaseModel. Workflow completion updates already write this
column, so schema drift causes execution finalization to fail.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "057"
down_revision: Union[str, None] = "056"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("execution_runs")}

    if "updated_at" in columns:
        return

    op.add_column(
        "execution_runs",
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=True,
        ),
    )
    op.execute("UPDATE execution_runs SET updated_at = created_at WHERE updated_at IS NULL")
    op.alter_column("execution_runs", "updated_at", nullable=False)


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("execution_runs")}

    if "updated_at" in columns:
        op.drop_column("execution_runs", "updated_at")