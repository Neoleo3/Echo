"""Create agent context attachment tables

Revision ID: 063
Revises: 062
Create Date: 2026-08-07

Phase 6 gives an agent persistent context: files and URLs attached while it is
configured, plus links to existing knowledge bases. Three new tables back that,
and **everything lives in Postgres** — the original upload, the converted
markdown, and the embedding of every passage.

Nothing is written to local disk. The platform runs on cloud containers with
more than one replica and no shared filesystem, so a file written to disk by
one replica is invisible to the next and is gone after a restart.
``agentic_uploaded_files.content`` (migration ``028``) already stores upload
bytes as ``LargeBinary``; these tables follow that established pattern.

``agent_files``
    One uploaded file or attached URL per row: identity, the original bytes,
    the converted markdown, and conversion state.
    ``agents.definition.files[]`` mirrors only the stable identity of each
    attachment, so a background ingest never rewrites an agent definition or
    inflates ``config_version``.

``agent_file_chunks``
    The vector store. One row per retrievable passage, holding the passage text
    and its embedding as normalized little-endian float32 bytes. There is no
    ``pgvector`` extension in this deployment, and none is required: similarity
    is computed in the application over one agent's own passages, which is
    bounded by construction. ``pgvector`` is the upgrade path if a per-agent
    corpus ever outgrows that.

``agent_knowledge_base_links``
    An agent's read-only link to an existing knowledge base.

All three cascade from ``agents.agent_id``, which is ``NOT NULL UNIQUE``, so
the foreign keys are real rather than advisory. ``knowledge_base_id`` on
``agent_files`` is a provenance column with no FK: retrieval for uploaded
sources never touches the knowledge pipeline.

Purely additive. No existing table, column, constraint or index is altered.
The four existing file surfaces (``uploaded_files``, ``agentic_uploaded_files``,
``application_documents``, ``knowledge_documents``) are untouched.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql


revision: str = "063"
down_revision: Union[str, None] = "062"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "agent_files",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("agent_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        # Identity
        sa.Column("source_type", sa.String(16), nullable=False, server_default="file"),
        sa.Column("name", sa.String(512), nullable=False),
        sa.Column("url", sa.Text(), nullable=True),
        sa.Column("format", sa.String(32), nullable=True),
        sa.Column("mime_type", sa.String(128), nullable=True),
        sa.Column("size_bytes", sa.Integer(), nullable=True),
        sa.Column("content_hash", sa.String(64), nullable=True),
        # Content. Postgres TOASTs both out of line and compresses them, so a
        # 25 MB upload does not bloat the heap the metadata queries read.
        sa.Column("content_bytes", sa.LargeBinary(), nullable=True),
        sa.Column("content_md", sa.Text(), nullable=True),
        # Provenance only -- no FK, see the module docstring
        sa.Column("knowledge_base_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=True),
        # Exposure and lifecycle
        sa.Column(
            "ingest_mode", sa.String(16), nullable=False, server_default="retrieval"
        ),
        sa.Column("status", sa.String(16), nullable=False, server_default="pending"),
        sa.Column("converted_by", sa.String(48), nullable=True),
        sa.Column("ocr_skipped_reason", sa.String(64), nullable=True),
        sa.Column("embedding_model", sa.String(128), nullable=True),
        sa.Column("char_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("chunk_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.ForeignKeyConstraint(
            ["agent_id"], ["agents.agent_id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ["user_id"], ["users.user_id"], ondelete="CASCADE"
        ),
        # Re-uploading identical bytes to the same agent is a no-op rather than
        # a second conversion and a second set of embeddings.
        sa.UniqueConstraint("agent_id", "content_hash", name="uq_agent_file_content"),
    )

    op.create_index("ix_agent_files_agent_id", "agent_files", ["agent_id"])
    op.create_index("ix_agent_files_user_id", "agent_files", ["user_id"])
    # The readiness gate asks "is anything still pending or failed" without
    # loading rows, so status is indexed.
    op.create_index("idx_agent_files_status", "agent_files", ["status"])

    op.create_table(
        "agent_file_chunks",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("agent_file_id", postgresql.UUID(as_uuid=True), nullable=False),
        # Denormalized from agent_files so one agent's passages are read in a
        # single indexed query rather than joined through every attachment.
        sa.Column("agent_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("chunk_index", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("content", sa.Text(), nullable=False),
        # Normalized little-endian float32. Dimensions are recorded because a
        # mismatch means the embedding model changed, and a similarity computed
        # across two embedding spaces is a number with no meaning.
        sa.Column("embedding", sa.LargeBinary(), nullable=True),
        sa.Column("dimensions", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("embedding_model", sa.String(128), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.ForeignKeyConstraint(
            ["agent_file_id"], ["agent_files.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ["agent_id"], ["agents.agent_id"], ondelete="CASCADE"
        ),
    )

    op.create_index(
        "ix_agent_file_chunks_agent_file_id", "agent_file_chunks", ["agent_file_id"]
    )
    op.create_index("ix_agent_file_chunks_agent_id", "agent_file_chunks", ["agent_id"])
    # The retrieval query filters on both together.
    op.create_index(
        "idx_agent_file_chunks_agent", "agent_file_chunks", ["agent_id", "agent_file_id"]
    )

    op.create_table(
        "agent_knowledge_base_links",
        sa.Column("agent_id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "knowledge_base_id", postgresql.UUID(as_uuid=True), primary_key=True
        ),
        sa.Column("alias", sa.String(255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.ForeignKeyConstraint(
            ["agent_id"], ["agents.agent_id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ["knowledge_base_id"], ["knowledge_bases.id"], ondelete="CASCADE"
        ),
    )


def downgrade() -> None:
    op.drop_table("agent_knowledge_base_links")

    op.drop_index("idx_agent_file_chunks_agent", table_name="agent_file_chunks")
    op.drop_index("ix_agent_file_chunks_agent_id", table_name="agent_file_chunks")
    op.drop_index("ix_agent_file_chunks_agent_file_id", table_name="agent_file_chunks")
    op.drop_table("agent_file_chunks")

    op.drop_index("idx_agent_files_status", table_name="agent_files")
    op.drop_index("ix_agent_files_user_id", table_name="agent_files")
    op.drop_index("ix_agent_files_agent_id", table_name="agent_files")
    op.drop_table("agent_files")
