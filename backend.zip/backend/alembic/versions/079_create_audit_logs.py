"""create hash-chained audit log table

Revision ID: 079
Revises: 078
Create Date: 2026-09-10

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "079"
down_revision = "078"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "agent_trust_audit_logs",
        sa.Column("id", sa.Integer(), nullable=False, autoincrement=True),
        # agent_id is intentionally NOT a foreign key -- the trail must
        # survive the agent's own deletion.
        sa.Column("agent_id", sa.String(length=32), nullable=True),
        sa.Column("event_type", sa.String(length=80), nullable=False),
        sa.Column("actor", sa.String(length=200), nullable=True),
        sa.Column("action", sa.String(length=200), nullable=False),
        sa.Column("resource", sa.String(length=300), nullable=True),
        sa.Column("outcome", sa.String(length=32), nullable=False, server_default="success"),
        sa.Column("severity", sa.String(length=32), nullable=False, server_default="info"),
        sa.Column("details", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("correlation_id", sa.String(length=64), nullable=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("prev_hash", sa.String(length=64), nullable=False),
        sa.Column("entry_hash", sa.String(length=64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_at_audit_logs_agent_time", "agent_trust_audit_logs", ["agent_id", "timestamp"])


def downgrade():
    op.drop_table("agent_trust_audit_logs")
