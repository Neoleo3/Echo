"""remove status and risk_level from agent governance profile

Revision ID: 085_remove_deprecated_fields
Revises: 084
Create Date: 2026-09-25

"""

from alembic import op
import sqlalchemy as sa


# revision identifiers
revision = "085"
down_revision = "084"
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column(
        "agent_governance_profiles",
        "status",
    )

    op.drop_column(
        "agent_governance_profiles",
        "risk_level",
    )


def downgrade():
    op.add_column(
        "agent_governance_profiles",
        sa.Column(
            "status",
            sa.String(length=20),
            nullable=False,
            server_default="unreviewed",
        ),
    )

    op.add_column(
        "agent_governance_profiles",
        sa.Column(
            "risk_level",
            sa.String(length=20),
            nullable=False,
            server_default="unassessed",
        ),
    )