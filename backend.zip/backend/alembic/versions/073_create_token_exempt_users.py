"""create token exempt users table

Revision ID: 073
Revises: 072
Create Date: 2026-09-03

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers
revision = "073"
down_revision = "072"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "token_exempt_users",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "email",
            sa.String(length=320),
            nullable=False,
        ),

        sa.Column(
            "created_by",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.ForeignKeyConstraint(
            ["created_by"],
            ["users.user_id"],
        ),

        sa.PrimaryKeyConstraint("id"),

        sa.UniqueConstraint(
            "email",
            name="uq_token_exempt_users_email",
        ),
    )

    op.create_index(
        "idx_token_exempt_users_email",
        "token_exempt_users",
        ["email"],
        unique=False,
    )


def downgrade():
    op.drop_index(
        "idx_token_exempt_users_email",
        table_name="token_exempt_users",
    )

    op.drop_table("token_exempt_users")