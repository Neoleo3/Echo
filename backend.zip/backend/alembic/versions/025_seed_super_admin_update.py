"""Seed ravineshmishra and ashishbajwan as super_admin

Revision ID: 024
Revises: 023
Create Date: 2026-04-29
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "024"
down_revision: Union[str, None] = "023"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_EMAILS = (
    "ravineshmishra@kpmg.com",
    "ashishbajwan@kpmg.com"
)


def upgrade() -> None:
    for email in _EMAILS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'super_admin' WHERE lower(email) = :email"
            ).bindparams(email=email)
        )


def downgrade() -> None:
    for email in _EMAILS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'user' WHERE lower(email) = :email"
            ).bindparams(email=email)
        )