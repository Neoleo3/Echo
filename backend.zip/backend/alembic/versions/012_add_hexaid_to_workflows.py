"""Add hexaid column to workflows table

Revision ID: 012
Revises: 011
Create Date: 2026-03-02

Adds hexaid as primary key to workflows table.
- hexaid: 32-char hex string (UUID.hex), same value as workflow_id without hyphens
- workflow_id: Unique business identifier (UUID)
- workflow_id and hexaid are 2 different columns; hexaid is the DB PK

Target Database: PostgreSQL 16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '012'
down_revision: Union[str, None] = '011'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add hexaid column (nullable first for existing rows)
    op.add_column(
        'workflows',
        sa.Column('hexaid', sa.String(32), nullable=True)
    )

    # Populate hexaid from workflow_id for existing rows (32-char hex = UUID without hyphens)
    op.execute("""
        UPDATE workflows
        SET hexaid = REPLACE(workflow_id::text, '-', '')
        WHERE hexaid IS NULL
    """)

    # Make hexaid NOT NULL
    op.alter_column(
        'workflows',
        'hexaid',
        existing_type=sa.String(32),
        nullable=False
    )

    # Drop dependent FKs that reference workflows_pkey before we can drop it
    op.drop_constraint('workflow_versions_workflow_id_fkey', 'workflow_versions', type_='foreignkey')
    op.drop_constraint('executions_workflow_id_fkey', 'executions', type_='foreignkey')

    # Drop old PK on workflow_id
    op.drop_constraint('workflows_pkey', 'workflows', type_='primary')

    # Add new PK on hexaid
    op.create_primary_key('workflows_pkey', 'workflows', ['hexaid'])

    # Add unique constraint on workflow_id (required for FK references from workflow_versions, executions)
    op.create_unique_constraint('uq_workflows_workflow_id', 'workflows', ['workflow_id'])

    # Re-add FKs pointing to the new unique constraint on workflow_id
    op.create_foreign_key(
        'workflow_versions_workflow_id_fkey', 'workflow_versions', 'workflows',
        ['workflow_id'], ['workflow_id'], ondelete='CASCADE'
    )
    op.create_foreign_key(
        'executions_workflow_id_fkey', 'executions', 'workflows',
        ['workflow_id'], ['workflow_id'], ondelete='CASCADE'
    )


def downgrade() -> None:
    # Drop re-added FKs
    op.drop_constraint('executions_workflow_id_fkey', 'executions', type_='foreignkey')
    op.drop_constraint('workflow_versions_workflow_id_fkey', 'workflow_versions', type_='foreignkey')

    # Drop unique constraint on workflow_id
    op.drop_constraint('uq_workflows_workflow_id', 'workflows', type_='unique')

    # Drop PK on hexaid
    op.drop_constraint('workflows_pkey', 'workflows', type_='primary')

    # Restore PK on workflow_id
    op.create_primary_key('workflows_pkey', 'workflows', ['workflow_id'])

    # Re-add original FKs pointing to the restored PK
    op.create_foreign_key(
        'workflow_versions_workflow_id_fkey', 'workflow_versions', 'workflows',
        ['workflow_id'], ['workflow_id'], ondelete='CASCADE'
    )
    op.create_foreign_key(
        'executions_workflow_id_fkey', 'executions', 'workflows',
        ['workflow_id'], ['workflow_id'], ondelete='CASCADE'
    )

    # Remove hexaid column
    op.drop_column('workflows', 'hexaid')
