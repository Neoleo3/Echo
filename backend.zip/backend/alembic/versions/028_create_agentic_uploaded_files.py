"""create agentic_uploaded_files table

Revision ID: 028
Revises: 027
Create Date: 2026-04-30
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "028"
down_revision: Union[str, None] = "027"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "agentic_uploaded_files",
        sa.Column(
            "file_id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "agentic_app_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("original_filename", sa.String(length=512), nullable=False),
        sa.Column("stored_filename", sa.String(length=512), nullable=False),
        sa.Column("mime_type", sa.String(length=100), nullable=True),
        sa.Column("size_bytes", sa.BigInteger(), nullable=True),
        sa.Column("content", sa.LargeBinary(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["agentic_app_id"],
            ["agentic_applications.agentic_app_id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.user_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("file_id"),
    )

    op.create_index(
        "idx_agentic_uploaded_files_app",
        "agentic_uploaded_files",
        ["agentic_app_id"],
        unique=False,
    )
    op.create_index(
        "idx_agentic_uploaded_files_user",
        "agentic_uploaded_files",
        ["user_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("idx_agentic_uploaded_files_user", table_name="agentic_uploaded_files")
    op.drop_index("idx_agentic_uploaded_files_app", table_name="agentic_uploaded_files")
    op.drop_table("agentic_uploaded_files")
