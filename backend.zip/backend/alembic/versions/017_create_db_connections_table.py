"""create db_connections table for connector module

Revision ID: 017
Revises: 016
Create Date: 2026-03-11
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB


revision = '017'
down_revision = '016'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'db_connections',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('name', sa.String(255), nullable=False, server_default='Unnamed'),
        sa.Column('db_type', sa.String(50), nullable=False, server_default='unknown'),
        sa.Column('connection_string', sa.Text(), nullable=False),
        sa.Column('dialect', sa.String(100), nullable=True),
        sa.Column('tables_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('views_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('schemas', JSONB(), nullable=True, server_default=sa.text("'[]'::jsonb")),
        sa.Column('ssh_tunnel_enabled', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('ssh_host', sa.String(255), nullable=True),
        sa.Column('ssh_config', JSONB(), nullable=True),
        sa.Column('file_content_hash', sa.String(64), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.current_timestamp(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.current_timestamp(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table('db_connections')
