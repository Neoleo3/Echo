"""add canvas_spec JSONB column to applications

Revision ID: 033
Revises: 032
Create Date: 2026-04-30

Adds a dedicated top-level canvas_spec JSONB column as a
fallback / secondary store for canvas specs.
"""

from typing import Sequence, Union

from alembic import op


revision: str = "033"
down_revision: Union[str, None] = "032"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        ALTER TABLE applications
            ADD COLUMN IF NOT EXISTS canvas_spec JSONB;
    """)


def downgrade() -> None:
    op.execute("""
        ALTER TABLE applications
            DROP COLUMN IF EXISTS canvas_spec;
    """)
