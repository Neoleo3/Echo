"""add ocr_method column to knowledge_bases

Revision ID: 038
Revises: 037
Create Date: 2026-04-30

Adds a nullable ocr_method VARCHAR(50) column to knowledge_bases.
Valid values: azure_vision, docling, or NULL (system default).
"""

from typing import Sequence, Union

from alembic import op


revision: str = "038"
down_revision: Union[str, None] = "037"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        ALTER TABLE knowledge_bases
            ADD COLUMN IF NOT EXISTS ocr_method VARCHAR(50);
    """)


def downgrade() -> None:
    op.execute("""
        ALTER TABLE knowledge_bases
            DROP COLUMN IF EXISTS ocr_method;
    """)
