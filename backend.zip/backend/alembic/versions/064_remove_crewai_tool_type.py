"""Retire the 'crewai' tool type

Revision ID: 064
Revises: 063
Create Date: 2026-08-08

Phase 9 removes CrewAI platform-wide. ``tool_type = 'crewai'`` was the last
place the framework's name survived in stored data.

It was never a distinct execution path. ``ToolExecutor.invoke`` dispatched
``ToolType.CREWAI`` to ``_execute_local`` — the same branch ``local`` took — so
the two labels described one behaviour. Rewriting the rows therefore changes how
a tool is *named*, not how it runs, and no tool's ``execution_config`` is
touched.

Two rows ship in the repository's tool catalogue with this type
(``tool_excel_generator``, ``tool_ppt_generator_template``); the filesystem
copies are rewritten in code, because ``ToolRegistry.register`` writes
filesystem-primary and DB-secondary and a DB-only change would be undone the
next time the cache reloaded. Any user-created rows are covered by the UPDATE
below.

Order matters: the data is rewritten **before** the constraint is replaced.
Dropping the old constraint first would leave a window in which a concurrent
insert could write a value the new constraint rejects; rewriting first means the
new constraint is valid the moment it is added.

``custom`` stays in the allowed set. It is unrelated to CrewAI, is declared on
the ORM model, and nothing in this phase touches it.

Reversible. ``downgrade`` restores the constraint but deliberately does **not**
restore the rows: the code that gave ``crewai`` a meaning no longer exists, so
returning the label would produce tools that read as CrewAI-native and execute
locally — the ambiguity this migration removes.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "064"
down_revision: Union[str, None] = "063"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_CONSTRAINT = "valid_tool_type"
_TABLE = "tools"


def upgrade() -> None:
    connection = op.get_bind()

    # 1. Rewrite the rows. Reported so the operator sees the blast radius.
    result = connection.execute(
        sa.text(
            "UPDATE tools SET tool_type = 'local' WHERE tool_type = 'crewai'"
        )
    )
    print(f"[064] tools rewritten from 'crewai' to 'local': {result.rowcount}")

    # 2. The definition JSONB carries its own copy of the type, read by
    #    ``ToolRegistry._hydrate_tool_from_row`` when it rebuilds a ToolDef from
    #    the database. Leaving it would resurrect the old label on the next
    #    cache miss, and ``ToolType('crewai')`` no longer exists — the hydration
    #    would raise rather than degrade.
    result = connection.execute(
        sa.text(
            "UPDATE tools "
            "SET definition = jsonb_set(definition, '{tool_type}', '\"local\"'::jsonb) "
            "WHERE definition ? 'tool_type' "
            "AND definition->>'tool_type' = 'crewai'"
        )
    )
    print(f"[064] tool definitions rewritten from 'crewai' to 'local': {result.rowcount}")

    # 3. Replace the constraint. Dropped with IF EXISTS because it is declared on
    #    the ORM model rather than created by an earlier migration, so a database
    #    built from an older baseline may not carry it under this name.
    op.execute(sa.text(f"ALTER TABLE {_TABLE} DROP CONSTRAINT IF EXISTS {_CONSTRAINT}"))
    op.create_check_constraint(
        _CONSTRAINT,
        _TABLE,
        "tool_type IN ('local', 'mcp', 'api', 'custom')",
    )


def downgrade() -> None:
    op.execute(sa.text(f"ALTER TABLE {_TABLE} DROP CONSTRAINT IF EXISTS {_CONSTRAINT}"))
    op.create_check_constraint(
        _CONSTRAINT,
        _TABLE,
        "tool_type IN ('local', 'mcp', 'api', 'crewai', 'custom')",
    )
