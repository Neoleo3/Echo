"""policy recommendations and security assignments

Revision ID: 084
Revises: 083
Create Date: 2026-09-25
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "084"
down_revision = "083"
branch_labels = None
depends_on = None


def upgrade():

    op.create_table(
        "agent_trust_policy_recommendations",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "agent_id",
            sa.String(length=32),
            nullable=False,
        ),

        sa.Column(
            "recommended_policy_ids",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
        ),

        sa.Column(
            "recommendation_reasoning",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
        ),

        sa.Column(
            "accepted",
            sa.Boolean(),
            nullable=False,
        ),

        sa.Column(
            "created_by",
            sa.String(length=128),
            nullable=False,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),

        sa.Column(
            "accepted_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),

        sa.PrimaryKeyConstraint("id"),
    )

    op.create_index(
        "ix_policy_recommendations_agent_id",
        "agent_trust_policy_recommendations",
        ["agent_id"],
    )

    op.create_index(
        "ix_policy_recommendations_accepted",
        "agent_trust_policy_recommendations",
        ["accepted"],
    )

    op.create_table(
        "agent_trust_security_assignments",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "agent_id",
            sa.String(length=32),
            nullable=False,
        ),

        sa.Column(
            "attack_id",
            sa.String(length=100),
            nullable=False,
        ),

        sa.Column(
            "assigned_by",
            sa.String(length=128),
            nullable=False,
        ),

        sa.Column(
            "assigned_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),

        sa.PrimaryKeyConstraint("id"),

        sa.UniqueConstraint(
            "agent_id",
            "attack_id",
            name="uq_security_assignment",
        ),
    )

    op.create_index(
        "ix_security_assignment_agent",
        "agent_trust_security_assignments",
        ["agent_id"],
    )


def downgrade():

    op.drop_table(
        "agent_trust_security_assignments"
    )

    op.drop_table(
        "agent_trust_policy_recommendations"
    )