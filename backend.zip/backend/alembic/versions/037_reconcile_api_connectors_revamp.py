"""ensure api_connectors revamp columns exist on drifted databases

Revision ID: 037
Revises: 036
Create Date: 2026-04-30

Idempotent reconciliation ensuring the 032 columns exist, are backfilled,
and have proper NOT NULL/default contracts and indexes.
"""

from typing import Sequence, Union

from alembic import op


revision: str = "037"
down_revision: Union[str, None] = "036"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        ALTER TABLE api_connectors
            ADD COLUMN IF NOT EXISTS name VARCHAR(255),
            ADD COLUMN IF NOT EXISTS description TEXT,
            ADD COLUMN IF NOT EXISTS auth_type VARCHAR(50) DEFAULT 'none',
            ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'untested',
            ADD COLUMN IF NOT EXISTS enabled BOOLEAN DEFAULT true,
            ADD COLUMN IF NOT EXISTS last_tested_at TIMESTAMPTZ;
    """)

    op.execute("""
        UPDATE api_connectors
        SET
            name = COALESCE(
                NULLIF(name, ''),
                NULLIF(config_json->>'name', ''),
                NULLIF(config_json->'creation_payload'->>'name', ''),
                connector_id
            ),
            description = COALESCE(
                description,
                NULLIF(config_json->>'description', ''),
                NULLIF(config_json->'creation_payload'->>'description', '')
            ),
            auth_type = COALESCE(
                NULLIF(auth_type, ''),
                NULLIF(config_json->>'auth_type', ''),
                NULLIF(config_json->'creation_payload'->'auth_config'->>'type', ''),
                NULLIF(config_json->'creation_payload'->'auth'->>'type', ''),
                'none'
            ),
            status = COALESCE(NULLIF(status, ''), NULLIF(config_json->>'status', ''), 'untested'),
            enabled = COALESCE(enabled, (config_json->>'enabled')::boolean, true)
        WHERE
            name IS NULL OR BTRIM(name) = '' OR
            description IS NULL OR
            auth_type IS NULL OR BTRIM(auth_type) = '' OR
            status IS NULL OR BTRIM(status) = '' OR
            enabled IS NULL;
    """)

    op.execute("ALTER TABLE api_connectors ALTER COLUMN auth_type SET DEFAULT 'none';")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN auth_type SET NOT NULL;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN status SET DEFAULT 'untested';")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN status SET NOT NULL;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN enabled SET DEFAULT true;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN enabled SET NOT NULL;")

    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_status ON api_connectors (status);")
    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_auth_type ON api_connectors (auth_type);")
    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_enabled ON api_connectors (enabled);")


def downgrade() -> None:
    pass
