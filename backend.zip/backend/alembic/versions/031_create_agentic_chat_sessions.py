"""Create agentic_chat_sessions table

Revision ID: 031
Revises: 030
Create Date: 2026-04-30

Persists multi-turn chat conversations for chat_interface components
running inside agentic applications.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "031"
down_revision: Union[str, None] = "030"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "agentic_chat_sessions",
        sa.Column("session_id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "agentic_app_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey(
                "agentic_applications.agentic_app_id", ondelete="CASCADE"
            ),
            nullable=False,
        ),
        sa.Column("component_id", sa.String(255), nullable=False),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.user_id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "messages",
            postgresql.JSONB,
            server_default="[]",
            nullable=False,
            comment='Array of {role: "user"|"assistant", content: "..."}',
        ),
        sa.Column("title", sa.Text, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
    )

    op.create_index(
        "idx_agentic_chat_app_comp_user",
        "agentic_chat_sessions",
        ["agentic_app_id", "component_id", "user_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "idx_agentic_chat_app_comp_user",
        table_name="agentic_chat_sessions",
    )
    op.drop_table("agentic_chat_sessions")
