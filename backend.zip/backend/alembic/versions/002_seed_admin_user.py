"""Seed admin user for EchoAI

Revision ID: 002
Revises: 001
Create Date: 2026-02-03

Creates the default system admin user for:
- Migrated data ownership (existing agents/workflows from JSON files)
- System-level operations
- Default user for development/testing

Admin User Details:
- user_id: Configured via ECHO_DEFAULT_USER_ID env var
           (default: 00000000-0000-0000-0000-000000000001)
- email: admin@echoai.local
- display_name: System Admin
- metadata: {"role": "admin", "migrated": true}

Conflict handling:
- ON CONFLICT (email) DO UPDATE SET user_id = EXCLUDED.user_id
  This ensures the configured UUID wins when the email already
  exists with a different UUID (e.g. production DB bootstrapped
  before this migration was env-var-aware).
"""
import os
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '002'
down_revision: Union[str, None] = '001'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Read from the same env var that echolib.repositories.base uses at runtime.
_DEFAULT_USER_ID = os.getenv(
    "ECHO_DEFAULT_USER_ID",
    "00000000-0000-0000-0000-000000000001",
)
_DEFAULT_USER_EMAIL = os.getenv(
    "ECHO_DEFAULT_USER_EMAIL",
    "admin@echoai.local",
)
_DEFAULT_USER_DISPLAY_NAME = os.getenv(
    "ECHO_DEFAULT_USER_DISPLAY_NAME",
    "System Admin",
)


def upgrade() -> None:
    # Insert default admin user with the configured UUID.
    # ON CONFLICT (email) DO UPDATE ensures that if the email row
    # already exists (possibly with a different UUID), the user_id
    # is aligned to match the configured ECHO_DEFAULT_USER_ID.
    op.execute(
        sa.text("""
            INSERT INTO users (user_id, email, display_name, metadata, is_active)
            VALUES (
                :user_id,
                :email,
                :display_name,
                '{"role": "admin", "migrated": true, "system_user": true}'::jsonb,
                TRUE
            )
            ON CONFLICT (email) DO UPDATE
                SET user_id      = EXCLUDED.user_id,
                    display_name = EXCLUDED.display_name,
                    is_active    = TRUE;
        """).bindparams(
            user_id=_DEFAULT_USER_ID,
            email=_DEFAULT_USER_EMAIL,
            display_name=_DEFAULT_USER_DISPLAY_NAME,
        )
    )


def downgrade() -> None:
    # Remove the admin user by the configured UUID.
    # Note: This will CASCADE delete any agents/workflows owned by admin.
    # In production, you would want to reassign ownership first.
    op.execute(
        sa.text("""
            DELETE FROM users
            WHERE user_id = :user_id;
        """).bindparams(user_id=_DEFAULT_USER_ID)
    )
