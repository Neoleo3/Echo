"""Migrate synthetic connector tools to agent connector attachments

Revision ID: 062
Revises: 061
Create Date: 2026-08-05

Connectors were converted into synthetic tools and attached to agents through
``definition.tools``. That path is removed: a connector is now attached to the
agent as an entry in ``definition.connectors`` and reached through the
connector middleware.

This migration moves the data to match:

  1. GIN index on ``agents.definition -> 'connectors'`` so "which agents use
     connector X" is answerable (readiness gate).
  2. Every ``definition.tools`` entry that resolves to a connector-synced tool
     row is removed from ``tools`` and written to ``connectors``.
  3. The same rewrite is applied to agents embedded by value in
     ``workflows.definition['agents']`` — the executor still reads the embedded
     copy, so skipping it would leave workflow agents holding phantom tool ids.
  4. Entries that look like connector tools but cannot be resolved are left in
     ``tools`` untouched and recorded under
     ``definition.metadata.connector_migration.needs_review``. Never silently
     stripped.
  5. Synthetic tool rows are soft-deleted, not dropped, so the change is
     reversible.

Additive and reversible. No column is added, dropped, or retyped.
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from alembic import op
from sqlalchemy import text


revision: str = "062"
down_revision: Union[str, None] = "061"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

logger = logging.getLogger("alembic.runtime.migration")

CONNECTOR_SYNC_SOURCE = "connector_sync"
INDEX_NAME = "ix_agents_definition_connectors"

# tool ids minted by the removed ToolRegistry._connector_tool_id()
LEGACY_TOOL_ID_PATTERN = re.compile(r"^tool_(api|mcp)_")


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

def _load_connector_tool_map(conn) -> Dict[str, Dict[str, Any]]:
    """
    Map every synthetic connector tool id to the connector it stood in for.

    Joins on ``definition->>'tool_id'`` rather than parsing the tool id: the
    id was built from a lossy slug of the connector name, so it cannot be
    reversed reliably.
    """
    rows = conn.execute(
        text(
            """
            SELECT definition
            FROM tools
            WHERE definition -> 'execution_config' ->> 'source' = :source
            """
        ),
        {"source": CONNECTOR_SYNC_SOURCE},
    ).fetchall()

    mapping: Dict[str, Dict[str, Any]] = {}
    for (definition,) in rows:
        if isinstance(definition, str):
            definition = json.loads(definition)
        if not isinstance(definition, dict):
            continue

        tool_id = definition.get("tool_id")
        execution_config = definition.get("execution_config") or {}
        connector_id = execution_config.get("connector_id")
        if not tool_id or not connector_id:
            continue

        mapping[tool_id] = {
            "connector_id": connector_id,
            "kind": (execution_config.get("connector_source") or "api").lower(),
            "alias": definition.get("name") or connector_id,
        }

    return mapping


# ---------------------------------------------------------------------------
# Definition rewriting
# ---------------------------------------------------------------------------

def _connector_entry(tool_id: str, connector: Dict[str, Any]) -> Dict[str, Any]:
    """Build a canonical ``definition.connectors`` entry."""
    return {
        "connector_id": connector["connector_id"],
        "kind": connector["kind"],
        "alias": connector["alias"],
        "allowed_operations": [],
        "migrated_from_tool_id": tool_id,
    }


def _rewrite_definition(
    definition: Dict[str, Any],
    tool_map: Dict[str, Dict[str, Any]],
) -> Tuple[Dict[str, Any], bool, int, int]:
    """
    Move connector-backed tool references into ``connectors``.

    Returns the new definition, whether anything changed, how many entries were
    migrated, and how many were flagged for review. The input is never mutated.
    """
    tools = definition.get("tools")
    if not isinstance(tools, list) or not tools:
        return definition, False, 0, 0

    existing = definition.get("connectors")
    connectors: List[Any] = list(existing) if isinstance(existing, list) else []
    already_migrated = {
        entry.get("migrated_from_tool_id")
        for entry in connectors
        if isinstance(entry, dict)
    }

    kept_tools: List[Any] = []
    migrated: List[Dict[str, Any]] = []
    needs_review: List[str] = []

    for entry in tools:
        if not isinstance(entry, str):
            kept_tools.append(entry)
            continue

        connector = tool_map.get(entry)
        if connector is not None:
            if entry not in already_migrated:
                migrated.append(_connector_entry(entry, connector))
            continue

        if LEGACY_TOOL_ID_PATTERN.match(entry):
            # Looks like a connector tool but no row resolves it. Keep the
            # reference and surface it rather than dropping it.
            needs_review.append(entry)

        kept_tools.append(entry)

    if not migrated and not needs_review:
        return definition, False, 0, 0

    updated = dict(definition)
    updated["tools"] = kept_tools
    if migrated:
        updated["connectors"] = connectors + migrated

    if needs_review:
        metadata = dict(updated.get("metadata") or {})
        migration_note = dict(metadata.get("connector_migration") or {})
        recorded = list(migration_note.get("needs_review") or [])
        migration_note["needs_review"] = recorded + [
            tool_id for tool_id in needs_review if tool_id not in recorded
        ]
        migration_note["revision"] = revision
        migration_note["reason"] = (
            "Tool id matches the removed connector-tool naming scheme but no "
            "connector-synced tool row resolves it. Left attached; review "
            "manually and attach the connector to the agent instead."
        )
        metadata["connector_migration"] = migration_note
        updated["metadata"] = metadata

    return updated, True, len(migrated), len(needs_review)


def _restore_definition(definition: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
    """Reverse ``_rewrite_definition`` using ``migrated_from_tool_id``."""
    connectors = definition.get("connectors")
    if not isinstance(connectors, list) or not connectors:
        return definition, False

    restored_tool_ids: List[str] = []
    remaining: List[Any] = []
    for entry in connectors:
        tool_id = entry.get("migrated_from_tool_id") if isinstance(entry, dict) else None
        if tool_id:
            restored_tool_ids.append(tool_id)
        else:
            remaining.append(entry)

    if not restored_tool_ids:
        return definition, False

    tools = definition.get("tools")
    tools = list(tools) if isinstance(tools, list) else []

    updated = dict(definition)
    updated["connectors"] = remaining
    updated["tools"] = tools + [t for t in restored_tool_ids if t not in tools]

    metadata = updated.get("metadata")
    if isinstance(metadata, dict) and "connector_migration" in metadata:
        metadata = dict(metadata)
        metadata.pop("connector_migration", None)
        updated["metadata"] = metadata

    return updated, True


# ---------------------------------------------------------------------------
# Table passes
# ---------------------------------------------------------------------------

def _as_dict(value: Any) -> Optional[Dict[str, Any]]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return None
    return value if isinstance(value, dict) else None


def _process_agents(conn, tool_map: Dict[str, Dict[str, Any]], reverse: bool) -> None:
    rows = conn.execute(text("SELECT hexaid, definition FROM agents")).fetchall()

    changed = migrated_total = review_total = 0
    for hexaid, raw_definition in rows:
        definition = _as_dict(raw_definition)
        if definition is None:
            continue

        if reverse:
            updated, did_change = _restore_definition(definition)
            migrated = review = 0
        else:
            updated, did_change, migrated, review = _rewrite_definition(definition, tool_map)

        if not did_change:
            continue

        conn.execute(
            text("UPDATE agents SET definition = CAST(:definition AS JSONB) WHERE hexaid = :hexaid"),
            {"definition": json.dumps(updated), "hexaid": hexaid},
        )
        changed += 1
        migrated_total += migrated
        review_total += review

    logger.info(
        "agents: %d row(s) rewritten, %d connector attachment(s), %d flagged for review",
        changed, migrated_total, review_total,
    )


def _process_workflows(conn, tool_map: Dict[str, Dict[str, Any]], reverse: bool) -> None:
    """Apply the same rewrite to agents embedded by value in a workflow."""
    rows = conn.execute(text("SELECT hexaid, definition FROM workflows")).fetchall()

    changed = migrated_total = review_total = 0
    for hexaid, raw_definition in rows:
        definition = _as_dict(raw_definition)
        if definition is None:
            continue

        embedded = definition.get("agents")
        if not isinstance(embedded, list) or not embedded:
            continue

        new_agents: List[Any] = []
        workflow_changed = False
        for agent in embedded:
            if not isinstance(agent, dict):
                new_agents.append(agent)
                continue

            if reverse:
                updated, did_change = _restore_definition(agent)
                migrated = review = 0
            else:
                updated, did_change, migrated, review = _rewrite_definition(agent, tool_map)

            new_agents.append(updated)
            if did_change:
                workflow_changed = True
                migrated_total += migrated
                review_total += review

        if not workflow_changed:
            continue

        updated_definition = dict(definition)
        updated_definition["agents"] = new_agents
        conn.execute(
            text("UPDATE workflows SET definition = CAST(:definition AS JSONB) WHERE hexaid = :hexaid"),
            {"definition": json.dumps(updated_definition), "hexaid": hexaid},
        )
        changed += 1

    logger.info(
        "workflows: %d row(s) rewritten, %d connector attachment(s), %d flagged for review",
        changed, migrated_total, review_total,
    )


# ---------------------------------------------------------------------------
# Migration entry points
# ---------------------------------------------------------------------------

def upgrade() -> None:
    conn = op.get_bind()

    op.execute(
        f"""
        CREATE INDEX IF NOT EXISTS {INDEX_NAME}
        ON agents USING GIN ((definition -> 'connectors') jsonb_path_ops)
        """
    )

    tool_map = _load_connector_tool_map(conn)
    logger.info("Found %d synthetic connector tool(s)", len(tool_map))

    _process_agents(conn, tool_map, reverse=False)
    _process_workflows(conn, tool_map, reverse=False)

    result = conn.execute(
        text(
            """
            UPDATE tools
            SET is_deleted = TRUE,
                status = 'disabled'
            WHERE definition -> 'execution_config' ->> 'source' = :source
              AND is_deleted = FALSE
            """
        ),
        {"source": CONNECTOR_SYNC_SOURCE},
    )
    logger.info("Soft-deleted %d synthetic connector tool row(s)", result.rowcount or 0)


def downgrade() -> None:
    conn = op.get_bind()

    conn.execute(
        text(
            """
            UPDATE tools
            SET is_deleted = FALSE,
                status = 'active'
            WHERE definition -> 'execution_config' ->> 'source' = :source
            """
        ),
        {"source": CONNECTOR_SYNC_SOURCE},
    )

    _process_agents(conn, {}, reverse=True)
    _process_workflows(conn, {}, reverse=True)

    op.execute(f"DROP INDEX IF EXISTS {INDEX_NAME}")
