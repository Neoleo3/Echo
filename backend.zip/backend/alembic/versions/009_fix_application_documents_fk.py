"""Fix application_documents chat_session_id: NOT NULL + ON DELETE CASCADE

Revision ID: 009
Revises: 008
Create Date: 2026-02-27

Addresses the P0 document-upload invisibility bug:

1. Deletes any orphaned rows where chat_session_id IS NULL (cleanup).
2. Alters chat_session_id to NOT NULL so no future document can be
   created without a valid session reference.
3. Drops the existing FK (auto-named by PostgreSQL as
   ``application_documents_chat_session_id_fkey``) and re-creates it
   with ON DELETE CASCADE, so deleting a session automatically removes
   its documents instead of leaving dangling references.

Target Database: PostgreSQL 16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '009'
down_revision: Union[str, None] = '008'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Step 1: Remove orphaned documents that have no session binding.
    # These are the exact rows that triggered the invisibility bug.
    op.execute(
        "DELETE FROM application_documents WHERE chat_session_id IS NULL"
    )

    # Step 2: Make chat_session_id NOT NULL to prevent future orphans.
    op.alter_column(
        'application_documents',
        'chat_session_id',
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=False,
    )

    # Step 3: Drop the existing FK (no ON DELETE CASCADE).
    op.drop_constraint(
        'application_documents_chat_session_id_fkey',
        'application_documents',
        type_='foreignkey',
    )

    # Step 4: Re-create the FK with ON DELETE CASCADE.
    op.create_foreign_key(
        'application_documents_chat_session_id_fkey',
        'application_documents',
        'application_chat_sessions',
        ['chat_session_id'],
        ['chat_session_id'],
        ondelete='CASCADE',
    )


def downgrade() -> None:
    # Reverse Step 4 & 3: drop cascading FK, restore original FK.
    op.drop_constraint(
        'application_documents_chat_session_id_fkey',
        'application_documents',
        type_='foreignkey',
    )
    op.create_foreign_key(
        'application_documents_chat_session_id_fkey',
        'application_documents',
        'application_chat_sessions',
        ['chat_session_id'],
        ['chat_session_id'],
    )

    # Reverse Step 2: allow NULLs again.
    op.alter_column(
        'application_documents',
        'chat_session_id',
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=True,
    )
