"""create user designation and business unit link tables

Revision ID: 039
Revises: 038
Create Date: 2026-05-01

Creates user_designation_links and user_business_unit_links association tables
for attribute-based access control. Also adds bootstrap_mode setting support.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID as PG_UUID


revision: str = "039"
down_revision: Union[str, None] = "038"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- user_designation_links ---
    op.create_table(
        "user_designation_links",
        sa.Column("user_id", PG_UUID(as_uuid=True), sa.ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True),
        sa.Column("designation_id", PG_UUID(as_uuid=True), sa.ForeignKey("app_designations.designation_id", ondelete="CASCADE"), primary_key=True),
    )

    # --- user_business_unit_links ---
    op.create_table(
        "user_business_unit_links",
        sa.Column("user_id", PG_UUID(as_uuid=True), sa.ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True),
        sa.Column("business_unit_id", PG_UUID(as_uuid=True), sa.ForeignKey("app_business_units.business_unit_id", ondelete="CASCADE"), primary_key=True),
    )

    # Backfill from user_token_allocations where designation/department strings
    # match existing lookup catalog names.
    op.execute(sa.text("""
        INSERT INTO user_designation_links (user_id, designation_id)
        SELECT DISTINCT u.user_id, d.designation_id
        FROM user_token_allocations uta
        JOIN users u ON u.email = uta.email
        JOIN app_designations d ON lower(d.name) = lower(uta.designation)
        WHERE uta.designation IS NOT NULL AND uta.designation != ''
        ON CONFLICT DO NOTHING
    """))

    op.execute(sa.text("""
        INSERT INTO user_business_unit_links (user_id, business_unit_id)
        SELECT DISTINCT u.user_id, bu.business_unit_id
        FROM user_token_allocations uta
        JOIN users u ON u.email = uta.email
        JOIN app_business_units bu ON lower(bu.name) = lower(uta.department)
        WHERE uta.department IS NOT NULL AND uta.department != ''
        ON CONFLICT DO NOTHING
    """))


def downgrade() -> None:
    op.drop_table("user_business_unit_links")
    op.drop_table("user_designation_links")
