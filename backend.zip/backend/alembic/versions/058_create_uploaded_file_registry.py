"""Create uploaded_files registry table

Revision ID: 058
Revises: 057
"""

from alembic import op
import sqlalchemy as sa

revision = "058"
down_revision = "057"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "uploaded_files",

        sa.Column(
            "file_id",
            sa.String(64),
            primary_key=True,
        ),

        sa.Column(
            "db_path",
            sa.Text(),
            nullable=False,
        ),

        sa.Column(
            "blob_name",
            sa.Text(),
            nullable=False,
        ),

        sa.Column(
            "original_path",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "format",
            sa.String(20),
            nullable=True,
        ),

        sa.Column(
            "sheets_json",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "stored_locally",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("true"),
        ),

        sa.Column(
            "file_size",
            sa.BigInteger(),
            nullable=True,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )

    op.create_index(
        "ix_uploaded_files_created_at",
        "uploaded_files",
        ["created_at"],
    )


def downgrade():
    op.drop_index(
        "ix_uploaded_files_created_at",
        table_name="uploaded_files",
    )

    op.drop_table("uploaded_files")