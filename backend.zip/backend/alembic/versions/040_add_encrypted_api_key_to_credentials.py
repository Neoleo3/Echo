"""add encrypted_api_key and api_key_storage to user_llm_credentials

Revision ID: 040
Revises: 039
Create Date: 2026-05-13

Adds a DB-side fallback for storing LLM API keys when Azure Key Vault
is unavailable.  Two new nullable columns:

    encrypted_api_key  TEXT   — stores the raw API key (plaintext)
    api_key_storage    VARCHAR(10) — "kv" or "db"; NULL for legacy rows
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "040"
down_revision: Union[str, None] = "039"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "user_llm_credentials",
        sa.Column("encrypted_api_key", sa.Text(), nullable=True),
    )
    op.add_column(
        "user_llm_credentials",
        sa.Column("api_key_storage", sa.String(10), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("user_llm_credentials", "api_key_storage")
    op.drop_column("user_llm_credentials", "encrypted_api_key")
