"""add channels table

Revision ID: 050
Revises: 049
Create Date: 2026-06-13

Adds a ``channels`` table for notification channel management.
Supported channel types: ``email``, ``teams``, ``slack``, ``webhook``.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers
revision: str = "050"
down_revision: Union[str, None] = "049"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Idempotent guard: skip if the table already exists (e.g. created out of band
    # or by a prior partial run).
    bind = op.get_bind()
    if sa.inspect(bind).has_table("channels"):
        return

    op.create_table(
        "channels",
        sa.Column("id", sa.Integer(), primary_key=True, index=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("channel_type", sa.String(50), nullable=False),  # email | teams | slack | webhook
        sa.Column("config", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("channels")