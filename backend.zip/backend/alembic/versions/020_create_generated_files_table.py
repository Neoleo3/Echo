"""create generated_files table for agent-produced downloads

Revision ID: 020
Revises: 019
Create Date: 2026-03-29

WHY: Agent tools (ppt_generator, excel_generator, data_analyst charts) write
files to disk and embed [GENERATED_FILE:path:name] markers in their output.
The skill_executor scans these markers and registers each file here so the
download endpoint can serve them via a URL-safe download_key. A TTL cleanup
task uses expires_at + is_deleted to purge stale files from disk and DB.
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "020"
down_revision = "019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "generated_files",
        sa.Column(
            "generated_file_id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "chat_session_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "application_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("original_filename", sa.String(length=512), nullable=False),
        sa.Column("file_path", sa.Text(), nullable=False),
        sa.Column("mime_type", sa.String(length=120), nullable=True),
        sa.Column("size_bytes", sa.BigInteger(), nullable=True),
        sa.Column("download_key", sa.String(length=64), nullable=False),
        sa.Column(
            "expires_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "is_deleted",
            sa.Boolean(),
            server_default=sa.text("false"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("generated_file_id"),
        sa.ForeignKeyConstraint(
            ["chat_session_id"],
            ["application_chat_sessions.chat_session_id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["application_id"],
            ["applications.application_id"],
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("download_key", name="uq_generated_files_download_key"),
    )

    op.create_index(
        "idx_generated_files_session",
        "generated_files",
        ["chat_session_id", "created_at"],
    )
    op.create_index(
        "idx_generated_files_download_key",
        "generated_files",
        ["download_key"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("idx_generated_files_download_key", table_name="generated_files")
    op.drop_index("idx_generated_files_session", table_name="generated_files")
    op.drop_table("generated_files")
