"""create telemetry_events and user_token_usage_periods tables

Revision ID: 022
Revises: 021
Create Date: 2026-06-15

Adds DB persistence for telemetry events and rolling per-user
token usage periods (budget tracking that survives restarts).
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "022"
down_revision = "021"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # -- telemetry_events --------------------------------------------------
    op.create_table(
        "telemetry_events",
        sa.Column("event_id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("event_type", sa.String(50), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.func.current_timestamp()),
        sa.Column("user_id", sa.String(255), nullable=False, server_default="anonymous"),
        sa.Column("session_id", sa.String(255), nullable=True),
        sa.Column("agent_id", sa.String(255), nullable=True),
        sa.Column("workflow_id", sa.String(255), nullable=True),
        sa.Column("model", sa.String(255), nullable=True),
        sa.Column("provider", sa.String(255), nullable=True),
        sa.Column("tool_name", sa.String(255), nullable=True),
        sa.Column("tool_type", sa.String(255), nullable=True),
        sa.Column("method", sa.String(100), nullable=True),
        sa.Column("feature", sa.String(255), nullable=True),
        sa.Column("duration_ms", sa.Float, nullable=True),
        sa.Column("input_tokens", sa.Integer, nullable=True),
        sa.Column("output_tokens", sa.Integer, nullable=True),
        sa.Column("total_tokens", sa.Integer, nullable=True),
        sa.Column("status", sa.String(50), nullable=False, server_default="success"),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("metadata_json", postgresql.JSONB, nullable=True),
        sa.Column("request_content", sa.Text, nullable=True),
        sa.Column("response_content", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True),
                  server_default=sa.func.current_timestamp(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True),
                  server_default=sa.func.current_timestamp(), nullable=False),
    )
    op.create_index("idx_te_event_type_ts", "telemetry_events",
                    ["event_type", "timestamp"])
    op.create_index("idx_te_user_ts", "telemetry_events",
                    ["user_id", "timestamp"])
    op.create_index("idx_te_user_event", "telemetry_events",
                    ["user_id", "event_type"])
    op.create_index("idx_te_session", "telemetry_events", ["session_id"])
    op.create_index("idx_te_agent", "telemetry_events", ["agent_id"])

    # -- user_token_usage_periods ------------------------------------------
    op.create_table(
        "user_token_usage_periods",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.user_id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("period_start", sa.DateTime(timezone=True), nullable=False),
        sa.Column("period_end", sa.DateTime(timezone=True), nullable=False),
        sa.Column("period_type", sa.String(20), nullable=False),
        sa.Column("total_input_tokens", sa.BigInteger, nullable=False,
                  server_default="0"),
        sa.Column("total_output_tokens", sa.BigInteger, nullable=False,
                  server_default="0"),
        sa.Column("total_tokens", sa.BigInteger, nullable=False,
                  server_default="0"),
        sa.Column("total_calls", sa.Integer, nullable=False,
                  server_default="0"),
        sa.Column("total_tool_calls", sa.Integer, nullable=False,
                  server_default="0"),
        sa.Column("total_errors", sa.Integer, nullable=False,
                  server_default="0"),
        sa.Column("is_current", sa.Boolean, nullable=False,
                  server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True),
                  server_default=sa.func.current_timestamp(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True),
                  server_default=sa.func.current_timestamp(), nullable=False),
        sa.UniqueConstraint("user_id", "period_start", "period_type",
                            name="uq_user_period"),
    )
    op.create_index("idx_utup_user", "user_token_usage_periods", ["user_id"])
    op.create_index("idx_utup_current", "user_token_usage_periods",
                    ["is_current"])


def downgrade() -> None:
    op.drop_table("user_token_usage_periods")
    op.drop_table("telemetry_events")
