"""Truncate all application tables (delete all rows)

Revision ID: 010
Revises: 009
Create Date: 2026-02-27

WARNING:
This migration is destructive. It removes all data from all tables in the
public schema except `alembic_version`.
"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "010"
down_revision: Union[str, None] = "009"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        """
        DO $$
        DECLARE
            table_list text;
        BEGIN
            SELECT string_agg(format('%I.%I', schemaname, tablename), ', ')
            INTO table_list
            FROM pg_tables
            WHERE schemaname = 'public'
              AND tablename <> 'alembic_version';

            IF table_list IS NOT NULL THEN
                EXECUTE 'TRUNCATE TABLE ' || table_list || ' RESTART IDENTITY CASCADE';
            END IF;
        END
        $$;
        """
    )


def downgrade() -> None:
    # Data deletion cannot be reversed.
    pass

