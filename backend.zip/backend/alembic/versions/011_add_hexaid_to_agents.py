"""Add hexaid column to agents table

Revision ID: 011
Revises: 010
Create Date: 2026-03-02

Adds hexaid as primary key to agents table.
- hexaid: 32-char hex string (UUID.hex), same value as agent_id without hyphens
- agent_id: Unique business identifier (UUID)
- agent_id and hexaid are 2 different columns; hexaid is the DB PK

Target Database: PostgreSQL 16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '011'
down_revision: Union[str, None] = '009'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add hexaid column (nullable first for existing rows)
    op.add_column(
        'agents',
        sa.Column('hexaid', sa.String(32), nullable=True)
    )

    # Populate hexaid from agent_id for existing rows (32-char hex = UUID without hyphens)
    op.execute("""
        UPDATE agents
        SET hexaid = REPLACE(agent_id::text, '-', '')
        WHERE hexaid IS NULL
    """)

    # Make hexaid NOT NULL
    op.alter_column(
        'agents',
        'hexaid',
        existing_type=sa.String(32),
        nullable=False
    )

    # Drop old PK on agent_id
    op.drop_constraint('agents_pkey', 'agents', type_='primary')

    # Add new PK on hexaid
    op.create_primary_key('agents_pkey', 'agents', ['hexaid'])

    # Add unique constraint on agent_id (required for upsert on_conflict)
    op.create_unique_constraint('uq_agents_agent_id', 'agents', ['agent_id'])


def downgrade() -> None:
    # Drop unique constraint on agent_id
    op.drop_constraint('uq_agents_agent_id', 'agents', type_='unique')

    # Drop PK on hexaid
    op.drop_constraint('agents_pkey', 'agents', type_='primary')

    # Restore PK on agent_id
    op.create_primary_key('agents_pkey', 'agents', ['agent_id'])

    # Remove hexaid column
    op.drop_column('agents', 'hexaid')
