"""scope credential_name uniqueness to active rows

Revision ID: 087
Revises: 086
Create Date: 2026-09-28

``uq_user_credential_name`` was a plain unique constraint on
(user_id, credential_name), so a soft-deleted credential (is_deleted=TRUE)
still blocked re-registering a model under the same name. Replace it with
a partial unique index that only applies to active rows, matching the
pattern already used by ``idx_user_creds_one_default``.
"""

from alembic import op
import sqlalchemy as sa

revision = "087"
down_revision = "086"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_constraint(
        "uq_user_credential_name", "user_llm_credentials", type_="unique"
    )
    op.create_index(
        "uq_user_credential_name",
        "user_llm_credentials",
        ["user_id", "credential_name"],
        unique=True,
        postgresql_where=sa.text("is_deleted = FALSE"),
    )


def downgrade() -> None:
    op.drop_index("uq_user_credential_name", table_name="user_llm_credentials")
    op.create_unique_constraint(
        "uq_user_credential_name",
        "user_llm_credentials",
        ["user_id", "credential_name"],
    )
