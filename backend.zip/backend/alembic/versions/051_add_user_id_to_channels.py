"""add user_id to channels for tenant isolation

Revision ID: 051
Revises: 050
Create Date: 2026-06-13

Adds user_id column to channels for multi-user isolation.
Backfills existing rows and enforces constraints.
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


# revision identifiers
revision: str = "051"
down_revision: Union[str, None] = "050"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ✅ same as 020
DEFAULT_USER_ID = '00000000-0000-0000-0000-000000000001'


def upgrade() -> None:
    # Idempotent guards: each step is skipped if it was already applied, so the
    # migration is safe to run even if channels was partially modified out of band.
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("channels")}
    indexes = {idx["name"] for idx in inspector.get_indexes("channels")}
    fks = {fk["name"] for fk in inspector.get_foreign_keys("channels")}
    uniques = {uc["name"] for uc in inspector.get_unique_constraints("channels")}

    if "user_id" not in columns:
        # ✅ 1. Add column (nullable first)
        op.add_column(
            "channels",
            sa.Column("user_id", sa.UUID(), nullable=True)
        )

        # ✅ 2. Backfill existing rows
        op.execute(
            sa.text(
                f"UPDATE channels SET user_id = '{DEFAULT_USER_ID}' WHERE user_id IS NULL"
            )
        )

        # ✅ 3. Make NOT NULL
        op.alter_column("channels", "user_id", nullable=False)

    # ✅ 4. Add foreign key
    if "fk_channels_user_id" not in fks:
        op.create_foreign_key(
            "fk_channels_user_id",
            "channels",
            "users",
            ["user_id"],
            ["user_id"],
            ondelete="CASCADE",
        )

    # ✅ 5. Add index
    if "idx_channels_user_id" not in indexes:
        op.create_index(
            "idx_channels_user_id",
            "channels",
            ["user_id"],
            unique=False,
        )

    # ✅ 6. Unique constraint (user_id + name)
    if "uq_channels_user_id_name" not in uniques:
        op.create_unique_constraint(
            "uq_channels_user_id_name",
            "channels",
            ["user_id", "name"],
        )


def downgrade() -> None:
    op.drop_constraint("uq_channels_user_id_name", "channels", type_="unique")
    op.drop_index("idx_channels_user_id", table_name="channels")
    op.drop_constraint("fk_channels_user_id", "channels", type_="foreignkey")
    op.drop_column("channels", "user_id")
