"""
Create ppt_templates table for storing PowerPoint templates and metadata.

Revision ID: 049
Revises: 048
Create Date: 2024-01-15 10:00:00.000000
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = "049"
down_revision = "048"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create ppt_templates table with schema extraction."""
    # Idempotent guard: this migration may not have run in environments that
    # were previously pinned to an earlier revision. Skip if already present.
    bind = op.get_bind()
    if sa.inspect(bind).has_table("ppt_templates"):
        return

    op.create_table(
        "ppt_templates",
        sa.Column(
            "template_id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.String(1000), nullable=True),
        sa.Column("file_path", sa.String(512), nullable=False, unique=True),
        sa.Column("file_size_bytes", sa.Integer, nullable=False),
        sa.Column(
            "schema",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default="{}",
        ),
        sa.Column(
            "tags",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default=sa.text("'[]'::jsonb"),
        ),
        sa.Column("status", sa.String(20), nullable=False, server_default="active"),
        sa.Column("is_public", sa.Boolean, nullable=False, server_default="false"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            onupdate=sa.func.now(),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("is_deleted", sa.Boolean, nullable=False, server_default="false"),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("template_id"),
        sa.UniqueConstraint("file_path", name="uq_ppt_templates_file_path"),
        sa.CheckConstraint(
            "status IN ('active', 'archived', 'draft')",
            name="valid_template_status",
        ),
    )

    # Create indexes
    op.create_index(
        "idx_templates_user_active",
        "ppt_templates",
        ["user_id"],
        postgresql_where=sa.text("is_deleted = false"),
    )
    op.create_index(
        "idx_templates_tags",
        "ppt_templates",
        ["tags"],
        postgresql_using="gin",
    )
    op.create_index(
        "idx_templates_status",
        "ppt_templates",
        ["status"],
    )


def downgrade() -> None:
    """Drop ppt_templates table."""
    op.drop_index("idx_templates_status", table_name="ppt_templates")
    op.drop_index("idx_templates_tags", table_name="ppt_templates")
    op.drop_index("idx_templates_user_active", table_name="ppt_templates")
    op.drop_table("ppt_templates")
