"""add telemetry credential attribution columns

Revision ID: 067
Revises: 066
Create Date: 2026-08-21

"""

from alembic import op
import sqlalchemy as sa


# revision identifiers
revision = "067"
down_revision = "066"
branch_labels = None
depends_on = None


def upgrade():

    op.add_column(
        "telemetry_events",
        sa.Column(
            "credential_id",
            sa.String(length=255),
            nullable=True,
        ),
    )

    op.add_column(
        "telemetry_events",
        sa.Column(
            "credential_name",
            sa.String(length=255),
            nullable=True,
        ),
    )

    op.add_column(
        "telemetry_events",
        sa.Column(
            "billing_source",
            sa.String(length=50),
            nullable=True,
        ),
    )

    op.create_index(
        "idx_te_credential",
        "telemetry_events",
        ["credential_id"],
        unique=False,
    )

    op.create_index(
        "idx_te_credential_name",
        "telemetry_events",
        ["credential_name"],
        unique=False,
    )

    op.create_index(
        "idx_te_billing_source",
        "telemetry_events",
        ["billing_source"],
        unique=False,
    )


def downgrade():

    op.drop_index(
        "idx_te_billing_source",
        table_name="telemetry_events",
    )

    op.drop_index(
        "idx_te_credential_name",
        table_name="telemetry_events",
    )

    op.drop_index(
        "idx_te_credential",
        table_name="telemetry_events",
    )

    op.drop_column(
        "telemetry_events",
        "billing_source",
    )

    op.drop_column(
        "telemetry_events",
        "credential_name",
    )

    op.drop_column(
        "telemetry_events",
        "credential_id",
    )