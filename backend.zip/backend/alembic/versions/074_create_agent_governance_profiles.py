"""create agent governance profiles table

Revision ID: 074
Revises: 073
Create Date: 2026-09-10

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers
revision = "074"
down_revision = "073"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "agent_governance_profiles",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "agent_id",
            sa.String(length=32),
            nullable=False,
        ),

        sa.Column(
            "status",
            sa.String(length=20),
            nullable=False,
            server_default="unreviewed",
        ),

        sa.Column(
            "environment",
            sa.String(length=20),
            nullable=True,
        ),

        sa.Column(
            "risk_level",
            sa.String(length=20),
            nullable=False,
            server_default="unassessed",
        ),

        sa.Column(
            "trust_score",
            sa.Float(),
            nullable=True,
        ),

        sa.Column(
            "tags",
            postgresql.JSONB(),
            nullable=False,
            server_default="[]",
        ),

        sa.Column(
            "needs_policy_review",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),

        sa.Column(
            "identity_stale",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),

        sa.Column(
            "testing_stale",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),

        sa.Column(
            "last_definition_hash",
            sa.String(length=64),
            nullable=True,
        ),

        sa.Column(
            "last_evaluated_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.ForeignKeyConstraint(
            ["agent_id"],
            ["agents.hexaid"],
            ondelete="CASCADE",
        ),

        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("agent_id", name="uq_agent_governance_profiles_agent_id"),
    )

    op.create_index(
        "ix_agent_governance_profiles_agent_id",
        "agent_governance_profiles",
        ["agent_id"],
    )


def downgrade():
    op.drop_index(
        "ix_agent_governance_profiles_agent_id",
        table_name="agent_governance_profiles",
    )
    op.drop_table("agent_governance_profiles")
