"""Seed application lookup values for Azure Postgres environments.

Revision ID: 024
Revises: 023
Create Date: 2026-04-23

Ensures the five application lookup tables contain the default values used by
the frontend dropdown APIs. The migration is idempotent and inserts only
missing rows.
"""

from typing import Sequence, Union

from alembic import op


revision: str = "024"
down_revision: Union[str, None] = "023"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _insert_missing_rows(table_name: str, id_column: str, values: list[str]) -> None:
    escaped_values = [value.replace("'", "''") for value in values]
    values_sql = ",\n        ".join(
        f"(gen_random_uuid(), '{escaped_value}')"
        for escaped_value in escaped_values
    )
    op.execute(
        f"""
        INSERT INTO {table_name} ({id_column}, name) VALUES
        {values_sql}
        ON CONFLICT (name) DO NOTHING;
        """
    )


def upgrade() -> None:
    _insert_missing_rows(
        "app_personas",
        "persona_id",
        [
            "Support Agent",
            "HR Assistant",
            "Sales Assistant",
            "Legal Advisor",
            "Technical Expert",
        ],
    )
    _insert_missing_rows(
        "app_guardrail_categories",
        "guardrail_category_id",
        ["Compliance", "PII", "Safety"],
    )
    _insert_missing_rows(
        "app_designations",
        "designation_id",
        [
            "Executive",
            "Manager",
            "Individual Contributor",
            "Intern",
        ],
    )
    _insert_missing_rows(
        "app_business_units",
        "business_unit_id",
        [
            "Operations",
            "Human Resources",
            "Sales",
            "Engineering",
            "Legal",
            "Finance",
        ],
    )
    _insert_missing_rows(
        "app_tags",
        "tag_id",
        ["Internal", "External", "Priority", "Experimental"],
    )


def downgrade() -> None:
    op.execute(
        "DELETE FROM app_tags WHERE name IN ('Internal', 'External', 'Priority', 'Experimental');"
    )
    op.execute(
        "DELETE FROM app_business_units WHERE name IN ('Operations', 'Human Resources', 'Sales', 'Engineering', 'Legal', 'Finance');"
    )
    op.execute(
        "DELETE FROM app_designations WHERE name IN ('Executive', 'Manager', 'Individual Contributor', 'Intern');"
    )
    op.execute(
        "DELETE FROM app_guardrail_categories WHERE name IN ('Compliance', 'PII', 'Safety');"
    )
    op.execute(
        "DELETE FROM app_personas WHERE name IN ('Support Agent', 'HR Assistant', 'Sales Assistant', 'Legal Advisor', 'Technical Expert');"
    )