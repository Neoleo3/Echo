"""make generated_files.chat_session_id and application_id nullable

Revision ID: 046
Revises: 045
Create Date: 2026-06-28

WHY: Files produced by a standalone workflow run have no owning chat session or
application. Previously these two FKs were NOT NULL, so workflow-generated files
could not be registered and never produced a download link. Making them nullable
lets workflow runs register files standalone (owners stay set for app/chat runs).
"""

from typing import Union

from alembic import op
from sqlalchemy.dialects import postgresql


revision: str = "046"
down_revision: Union[str, None] = "045"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column(
        "generated_files",
        "chat_session_id",
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=True,
    )
    op.alter_column(
        "generated_files",
        "application_id",
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=True,
    )


def downgrade() -> None:
    # Reverting requires no NULLs to exist in these columns.
    op.alter_column(
        "generated_files",
        "application_id",
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=False,
    )
    op.alter_column(
        "generated_files",
        "chat_session_id",
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=False,
    )
