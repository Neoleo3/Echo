"""add approval columns, audit log, and notifications tables

Revision ID: 041
Revises: 040
Create Date: 2026-05-14

Adds approval workflow columns to applications and agentic_applications,
creates the approval_audit_log table for tracking approval history,
and creates the notifications table for user notifications.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID as PG_UUID


revision: str = "041"
down_revision: Union[str, None] = "040"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ------------------------------------------------------------------
    # A) Add approval columns to applications
    # ------------------------------------------------------------------
    op.add_column(
        "applications",
        sa.Column(
            "approval_status",
            sa.String(20),
            server_default="pending",
            nullable=False,
        ),
    )
    op.add_column(
        "applications",
        sa.Column(
            "approved_by",
            PG_UUID(as_uuid=True),
            sa.ForeignKey("users.user_id", ondelete="SET NULL"),
            nullable=True,
        ),
    )
    op.add_column(
        "applications",
        sa.Column("rejection_reason", sa.Text(), nullable=True),
    )

    # Backfill: all pre-existing applications are grandfathered as approved
    op.execute(
        "UPDATE applications SET approval_status = 'approved' "
        "WHERE approval_status = 'pending'"
    )

    # ------------------------------------------------------------------
    # B) Add approval columns to agentic_applications
    # ------------------------------------------------------------------
    op.add_column(
        "agentic_applications",
        sa.Column(
            "approval_status",
            sa.String(20),
            server_default="pending",
            nullable=False,
        ),
    )
    op.add_column(
        "agentic_applications",
        sa.Column(
            "approved_by",
            PG_UUID(as_uuid=True),
            sa.ForeignKey("users.user_id", ondelete="SET NULL"),
            nullable=True,
        ),
    )
    op.add_column(
        "agentic_applications",
        sa.Column("rejection_reason", sa.Text(), nullable=True),
    )

    # Backfill: all pre-existing agentic applications are grandfathered as approved
    op.execute(
        "UPDATE agentic_applications SET approval_status = 'approved' "
        "WHERE approval_status = 'pending'"
    )

    # ------------------------------------------------------------------
    # C) Create approval_audit_log table
    # ------------------------------------------------------------------
    op.create_table(
        "approval_audit_log",
        sa.Column(
            "audit_id",
            PG_UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "application_id",
            PG_UUID(as_uuid=True),
            sa.ForeignKey("applications.application_id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column(
            "agentic_app_id",
            PG_UUID(as_uuid=True),
            sa.ForeignKey(
                "agentic_applications.agentic_app_id", ondelete="CASCADE"
            ),
            nullable=True,
        ),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column(
            "performed_by",
            PG_UUID(as_uuid=True),
            sa.ForeignKey("users.user_id", ondelete="SET NULL"),
            nullable=False,
        ),
        sa.Column("comment", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        # Exactly one of application_id or agentic_app_id must be set
        sa.CheckConstraint(
            "(application_id IS NOT NULL AND agentic_app_id IS NULL) OR "
            "(application_id IS NULL AND agentic_app_id IS NOT NULL)",
            name="ck_audit_one_app_type",
        ),
    )
    op.create_index(
        "ix_audit_app_created",
        "approval_audit_log",
        ["application_id", "created_at"],
    )
    op.create_index(
        "ix_audit_agentic_created",
        "approval_audit_log",
        ["agentic_app_id", "created_at"],
    )

    # ------------------------------------------------------------------
    # D) Create notifications table
    # ------------------------------------------------------------------
    op.create_table(
        "notifications",
        sa.Column(
            "notification_id",
            PG_UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_id",
            PG_UUID(as_uuid=True),
            sa.ForeignKey("users.user_id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("type", sa.String(50), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("message", sa.Text(), nullable=True),
        sa.Column("reference_id", PG_UUID(as_uuid=True), nullable=True),
        sa.Column("reference_type", sa.String(20), nullable=True),
        sa.Column(
            "is_read",
            sa.Boolean(),
            server_default="false",
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
    )
    op.create_index(
        "ix_notifications_user_unread",
        "notifications",
        ["user_id", "is_read", "created_at"],
    )


def downgrade() -> None:
    op.drop_table("notifications")
    op.drop_table("approval_audit_log")

    op.drop_column("agentic_applications", "rejection_reason")
    op.drop_column("agentic_applications", "approved_by")
    op.drop_column("agentic_applications", "approval_status")

    op.drop_column("applications", "rejection_reason")
    op.drop_column("applications", "approved_by")
    op.drop_column("applications", "approval_status")
