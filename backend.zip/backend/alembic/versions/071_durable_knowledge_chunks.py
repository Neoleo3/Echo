"""Make knowledge-base retrieval durable

Revision ID: 071
Revises: 070
Create Date: 2026-09-01

Knowledge-base retrieval was the last surface on this platform still backed by
local disk. A base's passages lived only in a FAISS index under
``{KNOWLEDGE_STORAGE_DIR}/{kb_id}/faiss_index/`` and its original file only
under ``{KNOWLEDGE_STORAGE_DIR}/{kb_id}/files/``. The platform runs on cloud
containers with more than one replica and no shared filesystem, so neither
survives a restart, a redeploy, or a request routed to a different replica.

The ``knowledge_bases`` and ``knowledge_documents`` rows *did* survive, which
produced the worst possible shape of the failure. An application with a
knowledge base attached as a data source went on listing it, the Application
Context Ledger asked the filesystem whether it was searchable, got ``no vector
index``, and reported the base ``UNAVAILABLE``. Both consumers then dropped it:
``_retrieve_knowledge_context`` skipped retrieval and ``build_contribution``
bound no ``kb__`` tool. The chat named the knowledge base and answered as
though it were empty — and reprocessing could not recover it, because the
original file the reprocess reads was gone too.

This migration moves both halves into Postgres, matching the decision already
taken for agent attachments in migration 063 and for application-chat uploads
in migration 065:

* ``knowledge_documents.content_bytes`` — the original upload, so a document
  can be converted again on any replica without asking the user for it a
  second time.
* ``knowledge_document_chunks`` — the passages and their embeddings. This table
  *is* the vector store; there is no ``pgvector`` extension in this deployment,
  so vectors are stored normalized as little-endian float32 bytes and ranked in
  the application over one base's own passages.

Both changes are additive. No column is dropped or retyped, every existing row
stays valid, and the code keeps reading the on-disk FAISS index whenever one is
present — so a base whose index is still warm behaves exactly as it did before.
Bases whose index is gone are rebuilt from the ``docling_markdown`` that was
always in Postgres, without a re-upload.
"""

from typing import Sequence, Union

from alembic import op

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "071"
down_revision: Union[str, None] = "070"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # The original upload. Nullable: rows written before this migration have no
    # stored copy, and the pipeline reports that honestly rather than assuming
    # a file it cannot produce.
    op.add_column(
        "knowledge_documents",
        sa.Column("content_bytes", sa.LargeBinary(), nullable=True),
    )

    op.create_table(
        "knowledge_document_chunks",
        sa.Column(
            "chunk_id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),
        sa.Column("knowledge_base_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("chunk_index", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("source_name", sa.String(length=512), nullable=False, server_default=""),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("heading", sa.String(length=1024), nullable=True),
        sa.Column("embedding", sa.LargeBinary(), nullable=True),
        sa.Column("dimensions", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("embedding_model", sa.String(length=128), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),
        sa.ForeignKeyConstraint(
            ["knowledge_base_id"],
            ["knowledge_bases.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["knowledge_documents.id"],
            ondelete="CASCADE",
        ),
    )

    # Retrieval reads one base's passages in a single indexed query rather than
    # scanning every base in the deployment.
    op.create_index(
        "idx_kb_doc_chunks_base",
        "knowledge_document_chunks",
        ["knowledge_base_id", "document_id"],
    )
    op.create_index(
        "ix_knowledge_document_chunks_knowledge_base_id",
        "knowledge_document_chunks",
        ["knowledge_base_id"],
    )
    op.create_index(
        "ix_knowledge_document_chunks_document_id",
        "knowledge_document_chunks",
        ["document_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_knowledge_document_chunks_document_id",
        table_name="knowledge_document_chunks",
    )
    op.drop_index(
        "ix_knowledge_document_chunks_knowledge_base_id",
        table_name="knowledge_document_chunks",
    )
    op.drop_index(
        "idx_kb_doc_chunks_base",
        table_name="knowledge_document_chunks",
    )
    op.drop_table("knowledge_document_chunks")
    op.drop_column("knowledge_documents", "content_bytes")
