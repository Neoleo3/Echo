from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "080"
down_revision = "079"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "agent_governance_profiles",
        sa.Column(
            "trust_state",
            sa.String(length=50),
            nullable=False,
            server_default="UNREVIEWED",
        ),
    )

    op.add_column(
        "agent_governance_profiles",
        sa.Column(
            "trust_dimensions",
            postgresql.JSONB(),
            nullable=False,
            server_default="{}",
        ),
    )


def downgrade():
    op.drop_column(
        "agent_governance_profiles",
        "trust_dimensions",
    )

    op.drop_column(
        "agent_governance_profiles",
        "trust_state",
    )