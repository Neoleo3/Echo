"""extend application_skill_links skill_type to allow api

Revision ID: 035
Revises: 034
Create Date: 2026-04-30

No-op audit migration. The skill_type column is VARCHAR(10) with no CHECK
constraint, so 'api' is already valid. This records the audit in the chain.
"""

from typing import Sequence, Union

from alembic import op


revision: str = "035"
down_revision: Union[str, None] = "034"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
