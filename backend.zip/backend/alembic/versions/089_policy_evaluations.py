"""policy evaluations

Revision ID: 089
Revises: 088
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "089"
down_revision = "088"


def upgrade():

    op.create_table(
        "agent_trust_policy_evaluations",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "policy_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "agent_id",
            sa.String(length=32),
            nullable=False,
        ),

        sa.Column(
            "passed",
            sa.Boolean(),
            nullable=False,
        ),

        sa.Column(
            "score",
            sa.Float(),
            nullable=False,
        ),

        sa.Column(
            "agent_response",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "judge_response",
            postgresql.JSONB(),
            nullable=False,
            server_default="{}",
        ),

        sa.Column(
            "evaluated_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),

        sa.ForeignKeyConstraint(
            ["policy_id"],
            ["agent_trust_policies.id"],
            ondelete="CASCADE",
        ),

        sa.PrimaryKeyConstraint("id"),
    )


def downgrade():

    op.drop_table(
        "agent_trust_policy_evaluations"
    )