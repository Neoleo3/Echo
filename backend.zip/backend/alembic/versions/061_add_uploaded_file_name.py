from alembic import op
import sqlalchemy as sa

revision = "061"
down_revision = "060"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "db_connections",
        sa.Column(
            "uploaded_file_name",
            sa.Text(),
            nullable=True,
        ),
    )


def downgrade():
    op.drop_column(
        "db_connections",
        "uploaded_file_name",
    )