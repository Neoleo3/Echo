"""
add updated_at column to channels

Revision ID: 052
Revises: 051
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "052"
down_revision: Union[str, None] = "051"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Idempotent guard: skip if the column already exists.
    bind = op.get_bind()
    columns = {col["name"] for col in sa.inspect(bind).get_columns("channels")}
    if "updated_at" in columns:
        return

    op.add_column(
        "channels",
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now()  # ✅ CRITICAL
        )
    )


def downgrade() -> None:
    op.drop_column("channels", "updated_at")