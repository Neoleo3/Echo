"""create identity snapshots and trust score history tables

Revision ID: 076
Revises: 075
Create Date: 2026-09-10

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "076"
down_revision = "075"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "agent_trust_identity_snapshots",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("agent_id", sa.String(length=32), nullable=False),
        sa.Column("declared", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("observed", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("drift_flags", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("hygiene_score", sa.Float(), nullable=True),
        sa.Column("evaluated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.ForeignKeyConstraint(["agent_id"], ["agents.hexaid"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_at_identity_snapshots_agent", "agent_trust_identity_snapshots", ["agent_id"])

    op.create_table(
        "agent_trust_score_history",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("agent_id", sa.String(length=32), nullable=False),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("previous_score", sa.Float(), nullable=True),
        sa.Column("band", sa.String(length=20), nullable=False),
        sa.Column("factors", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("is_provisional", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("reason", sa.Text(), nullable=True),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.current_timestamp()),
        sa.ForeignKeyConstraint(["agent_id"], ["agents.hexaid"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_at_score_history_agent", "agent_trust_score_history", ["agent_id"])


def downgrade():
    op.drop_table("agent_trust_score_history")
    op.drop_table("agent_trust_identity_snapshots")
