"""backfill existing rows approval_status to approved

Revision ID: 042
Revises: 041
Create Date: 2026-05-14

Migration 041 added approval_status with server_default='pending',
which backfilled all pre-existing rows as 'pending'. This migration
corrects that by setting all existing applications and agentic
applications to 'approved' so they are grandfathered in.
"""

from typing import Sequence, Union
from alembic import op


revision: str = "042"
down_revision: Union[str, None] = "041"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Grandfather all pre-existing applications as approved
    op.execute(
        "UPDATE applications SET approval_status = 'approved' "
        "WHERE approval_status = 'pending'"
    )
    op.execute(
        "UPDATE agentic_applications SET approval_status = 'approved' "
        "WHERE approval_status = 'pending'"
    )


def downgrade() -> None:
    # Revert grandfathered rows back to pending
    op.execute(
        "UPDATE applications SET approval_status = 'pending' "
        "WHERE approval_status = 'approved' AND approved_by IS NULL"
    )
    op.execute(
        "UPDATE agentic_applications SET approval_status = 'pending' "
        "WHERE approval_status = 'approved' AND approved_by IS NULL"
    )
