"""add updated_at to agentic_uploaded_files

Revision ID: 048
Revises: 047
Create Date: 2026-07-02
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "048"
down_revision: Union[str, None] = "047"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("agentic_uploaded_files")}

    if "updated_at" not in columns:
        op.add_column(
            "agentic_uploaded_files",
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                server_default=sa.func.current_timestamp(),
                nullable=False,
            ),
        )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("agentic_uploaded_files")}

    if "updated_at" in columns:
        op.drop_column("agentic_uploaded_files", "updated_at")
