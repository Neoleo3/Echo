"""add icon field to workflow definition JSONB for existing rows

Revision ID: 016
Revises: 015
Create Date: 2026-03-05
"""
from alembic import op


# revision identifiers, used by Alembic.
revision = '016'
down_revision = '015'
branch_labels = None
depends_on = None


def upgrade() -> None:
    """
    Backfill existing workflow rows: set definition->'icon' = 'workflow'
    for any row where the JSONB definition does not already contain an icon key.
    """
    op.execute(
        """
        UPDATE workflows
        SET definition = jsonb_set(definition, '{icon}', '"workflow"', true)
        WHERE definition IS NOT NULL
          AND NOT definition ? 'icon'
        """
    )


def downgrade() -> None:
    """
    Remove the icon key from all workflow definitions.
    """
    op.execute(
        """
        UPDATE workflows
        SET definition = definition - 'icon'
        WHERE definition IS NOT NULL
          AND definition ? 'icon'
        """
    )
