"""Keep the converted markdown of an application-chat upload

Revision ID: 068
Revises: 067
Create Date: 2026-08-26

An uploaded document is converted to markdown by ``apps/markitdown`` and then
split and embedded into ``application_document_chunks``. Only the passages were
ever stored. The markdown itself — the whole document, in order — was held in
memory for the length of one request and discarded.

Two consequences, both reported as bugs:

* **A document that converted perfectly was recorded as failed.** Conversion
  needs no model; embedding needs a resolvable credential. When embedding could
  not run, ``process_document`` returned ``chunk_count=0``, the upload route
  read that as failure, and the extracted text went out of scope. The user was
  told the file could not be processed when in fact it had been read correctly.

* **There was no whole-document read.** Similarity search is the wrong
  retrieval for "summarize this document" — the agent needs the text in order,
  not the three passages nearest a query it had to invent. ``agent_files`` has
  carried ``content_md`` since migration 063 and ``knowledge_documents`` has
  carried ``docling_markdown`` for longer; this is the one document surface
  that had no equivalent.

This migration gives ``application_documents`` the same four columns
``agent_files`` already has, so the three document surfaces finally agree.

Every column is nullable and additive. No column is dropped or retyped, and no
existing row changes: documents uploaded before this migration simply have no
stored markdown, which the code treats exactly as it treats a document that
predates durable storage — reported honestly rather than assumed present.
"""

from typing import Sequence, Union

from alembic import op

import sqlalchemy as sa

revision: str = "070"
down_revision: Union[str, None] = "069"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # The converted document, in reading order. Nullable because every row that
    # already exists has none, and because a document may legitimately fail to
    # convert — in which case ``processing_status`` carries the reason.
    op.add_column(
        "application_documents",
        sa.Column("content_md", sa.Text(), nullable=True),
    )

    # Characters of extracted text. Stored rather than derived so a paging read
    # can report "N more characters" without loading the whole column.
    op.add_column(
        "application_documents",
        sa.Column("char_count", sa.Integer(), nullable=False, server_default="0"),
    )

    # Which backend produced the text, and — when the OCR pass did not run —
    # why not. Without these, "the scan came back empty" and "no vision model
    # was configured" are indistinguishable to everyone including the user.
    op.add_column(
        "application_documents",
        sa.Column("converted_by", sa.String(length=64), nullable=True),
    )
    op.add_column(
        "application_documents",
        sa.Column("ocr_skipped_reason", sa.String(length=128), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("application_documents", "ocr_skipped_reason")
    op.drop_column("application_documents", "converted_by")
    op.drop_column("application_documents", "char_count")
    op.drop_column("application_documents", "content_md")