"""Make hitl_checkpoints writable

Revision ID: 072
Revises: 071
Create Date: 2026-09-01

``hitl_checkpoints`` has never accepted a single row. Two independent faults,
both dating to migration 001, and every write to the table hit one or the other:

1. **The ORM declares a column the table does not have.** ``HITLCheckpoint``
   extends ``BaseModel`` (``echolib/models/base.py``), which declares
   ``updated_at`` NOT NULL. Migration 001 created the table with ``created_at``
   only. Every ORM *read* as well as every write therefore failed with
   ``UndefinedColumnError: column hitl_checkpoints.updated_at does not exist``
   -- which is exactly what the HITL logs show on approve and on reject.

   This is the same defect migration 054 fixed for ``execution_steps``, with
   the same one-line cause recorded there: "updated_at (inherited from
   BaseModel)". ``hitl_checkpoints`` was simply never given the same treatment.

2. **The foreign key points at a table nothing writes.** ``run_id`` referenced
   ``executions.run_id``, but rows in ``executions`` are only ever created by
   ``ExecutionRepository.create_execution``, which no runtime path calls. The
   workflow runtime records runs through ``save_run`` into ``execution_runs`` --
   a different table, whose ``run_id`` is a ``String`` and so cannot be
   referenced from this ``UUID`` column at all. So even with ``updated_at``
   present, every insert would fail on the constraint instead.

   The constraint is dropped rather than repointed. ``hitl_checkpoints`` is the
   review-UI record and is written best-effort, after the fact, by a runtime
   whose own notion of a run lives in ``execution_runs``; a foreign key that can
   never be satisfied is not integrity, it is an outage.

``resolved_by -> users.user_id`` is deliberately left in place. That column
holds a real user id and is nullable, and nothing writes a non-user value to it.

Both changes are additive or subtractive-of-a-blocker: no column is dropped, no
column is retyped, and no existing row changes. Inspector-guarded throughout, so
re-running is safe on a database that already has either change.
"""

from typing import Sequence, Union

from alembic import op

import sqlalchemy as sa

revision: str = "072"
down_revision: Union[str, None] = "071"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


TABLE = "hitl_checkpoints"


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    if TABLE not in inspector.get_table_names():
        # Nothing to repair on a database that never created the table.
        return

    columns = {col["name"] for col in inspector.get_columns(TABLE)}

    if "updated_at" not in columns:
        # Nullable=False with a server default, matching migration 054: existing
        # rows -- if any survive -- take the default rather than blocking.
        op.add_column(
            TABLE,
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                server_default=sa.func.current_timestamp(),
                nullable=False,
            ),
        )

    # Drop the run_id foreign key by whatever name the database gave it.
    # Migration 001 declared it inline and unnamed, so Postgres generated
    # ``hitl_checkpoints_run_id_fkey``; the lookup avoids depending on that.
    for fk in inspector.get_foreign_keys(TABLE):
        if fk.get("referred_table") == "executions" and fk.get("constrained_columns") == ["run_id"]:
            name = fk.get("name")
            if name:
                op.drop_constraint(name, TABLE, type_="foreignkey")


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    if TABLE not in inspector.get_table_names():
        return

    columns = {col["name"] for col in inspector.get_columns(TABLE)}

    existing = {
        fk.get("name")
        for fk in inspector.get_foreign_keys(TABLE)
        if fk.get("referred_table") == "executions"
    }
    if "hitl_checkpoints_run_id_fkey" not in existing:
        op.create_foreign_key(
            "hitl_checkpoints_run_id_fkey",
            TABLE,
            "executions",
            ["run_id"],
            ["run_id"],
            ondelete="CASCADE",
        )

    if "updated_at" in columns:
        op.drop_column(TABLE, "updated_at")
