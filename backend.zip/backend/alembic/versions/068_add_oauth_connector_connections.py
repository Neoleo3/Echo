from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "068"
down_revision = "067"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "oauth_connector_connections",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),

        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "connector_id",
            sa.String(length=255),
            nullable=False,
        ),

        sa.Column(
            "provider",
            sa.String(length=100),
            nullable=False,
        ),

        sa.Column(
            "provider_user_id",
            sa.String(length=255),
            nullable=True,
        ),

        sa.Column(
            "provider_email",
            sa.String(length=320),
            nullable=True,
        ),

        sa.Column(
            "access_token",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "refresh_token",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "granted_scopes",
            postgresql.JSONB(astext_type=sa.Text()),
            nullable=False,
            server_default="[]",
        ),

        sa.Column(
            "expires_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),

        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.user_id"],
            ondelete="CASCADE",
        ),
    )

    op.create_unique_constraint(
        "uq_oauth_conn_user_connector",
        "oauth_connector_connections",
        ["user_id", "connector_id"],
    )

    op.create_index(
        "idx_oauth_conn_user_id",
        "oauth_connector_connections",
        ["user_id"],
    )

    op.create_index(
        "idx_oauth_conn_connector_id",
        "oauth_connector_connections",
        ["connector_id"],
    )


def downgrade():
    op.drop_index(
        "idx_oauth_conn_connector_id",
        table_name="oauth_connector_connections",
    )

    op.drop_index(
        "idx_oauth_conn_user_id",
        table_name="oauth_connector_connections",
    )

    op.drop_constraint(
        "uq_oauth_conn_user_connector",
        "oauth_connector_connections",
        type_="unique",
    )

    op.drop_table("oauth_connector_connections")