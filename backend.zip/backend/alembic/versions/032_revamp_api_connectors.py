"""Revamp api_connectors: add normalized columns for name, auth_type, status, enabled, last_tested_at.

Revision ID: 032
Revises: 031
Create Date: 2026-04-30

Adds operational columns to api_connectors so we can filter/sort
without having to crack open the JSONB config_json blob.
Existing rows are backfilled from config_json.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "032"
down_revision: Union[str, None] = "031"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        ALTER TABLE api_connectors
            ADD COLUMN IF NOT EXISTS name VARCHAR(255),
            ADD COLUMN IF NOT EXISTS description TEXT,
            ADD COLUMN IF NOT EXISTS auth_type VARCHAR(50) DEFAULT 'none',
            ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'untested',
            ADD COLUMN IF NOT EXISTS enabled BOOLEAN DEFAULT true,
            ADD COLUMN IF NOT EXISTS last_tested_at TIMESTAMPTZ;
    """)

    # Backfill from config_json
    op.execute(sa.text("""
        UPDATE api_connectors
        SET
            name = COALESCE(config_json->>'name', config_json->'creation_payload'->>'name', connector_id),
            description = COALESCE(config_json->>'description', config_json->'creation_payload'->>'description'),
            auth_type = COALESCE(
                config_json->>'auth_type',
                config_json->'creation_payload'->'auth_config'->>'type',
                config_json->'creation_payload'->'auth'->>'type',
                'none'
            ),
            status = COALESCE(config_json->>'status', 'untested'),
            enabled = COALESCE((config_json->>'enabled')::boolean, true)
    """))

    # Set NOT NULL constraints
    op.execute("ALTER TABLE api_connectors ALTER COLUMN auth_type SET DEFAULT 'none';")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN auth_type SET NOT NULL;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN status SET DEFAULT 'untested';")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN status SET NOT NULL;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN enabled SET DEFAULT true;")
    op.execute("ALTER TABLE api_connectors ALTER COLUMN enabled SET NOT NULL;")

    # Indexes for common filters
    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_status ON api_connectors (status);")
    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_auth_type ON api_connectors (auth_type);")
    op.execute("CREATE INDEX IF NOT EXISTS idx_api_connectors_enabled ON api_connectors (enabled);")


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_api_connectors_enabled")
    op.execute("DROP INDEX IF EXISTS idx_api_connectors_auth_type")
    op.execute("DROP INDEX IF EXISTS idx_api_connectors_status")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS last_tested_at")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS enabled")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS status")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS auth_type")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS description")
    op.execute("ALTER TABLE api_connectors DROP COLUMN IF EXISTS name")
