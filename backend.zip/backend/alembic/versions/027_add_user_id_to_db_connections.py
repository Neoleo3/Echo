"""add user_id to db_connections for tenant isolation

Revision ID: 027
Revises: 026
Create Date: 2026-04-30

Adds user_id column to db_connections for multi-user isolation.
Existing rows are backfilled with DEFAULT_USER_ID before making the column non-nullable.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "027"
down_revision: Union[str, None] = "026"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

DEFAULT_USER_ID = "00000000-0000-0000-0000-000000000001"


def upgrade() -> None:
    # Idempotent: skip if column already exists
    op.execute(
        "ALTER TABLE db_connections ADD COLUMN IF NOT EXISTS user_id UUID"
    )

    op.execute(
        sa.text(
            f"UPDATE db_connections SET user_id = '{DEFAULT_USER_ID}' WHERE user_id IS NULL"
        )
    )

    op.execute("ALTER TABLE db_connections ALTER COLUMN user_id SET NOT NULL")

    # FK and indexes — use IF NOT EXISTS patterns for safety
    op.execute("""
        DO $$ BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_constraint WHERE conname = 'fk_db_connections_user_id'
            ) THEN
                ALTER TABLE db_connections
                    ADD CONSTRAINT fk_db_connections_user_id
                    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE;
            END IF;
        END $$;
    """)

    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_db_connections_user_id ON db_connections (user_id)"
    )

    op.execute("""
        DO $$ BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_constraint WHERE conname = 'uq_db_connections_user_id_name'
            ) THEN
                ALTER TABLE db_connections
                    ADD CONSTRAINT uq_db_connections_user_id_name UNIQUE (user_id, name);
            END IF;
        END $$;
    """)


def downgrade() -> None:
    op.execute("ALTER TABLE db_connections DROP CONSTRAINT IF EXISTS uq_db_connections_user_id_name")
    op.execute("DROP INDEX IF EXISTS idx_db_connections_user_id")
    op.execute("ALTER TABLE db_connections DROP CONSTRAINT IF EXISTS fk_db_connections_user_id")
    op.execute("ALTER TABLE db_connections DROP COLUMN IF EXISTS user_id")
