"""remove to_email from channels config

Revision ID: 053
Revises: 052
"""

from typing import Union

from alembic import op
import sqlalchemy as sa


revision: str = "053"
down_revision: Union[str, None] = "052"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Remove legacy recipient storage from channel configuration.
    op.execute(
        sa.text(
            """
            UPDATE channels
            SET config = (config::jsonb - 'to_email')::json
            WHERE (config::jsonb ? 'to_email')
            """
        )
    )


def downgrade() -> None:
    # Irreversible: removed values cannot be reconstructed.
    pass
