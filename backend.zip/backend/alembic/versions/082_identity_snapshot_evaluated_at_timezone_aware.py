"""make_identity_snapshot_evaluated_at_timezone_aware

Revision ID: 082
Revises: 081
Create Date: 2026-09-21

"""

from alembic import op
import sqlalchemy as sa


# revision identifiers
revision = "082"
down_revision = "081"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE agent_trust_identity_snapshots
        ALTER COLUMN evaluated_at
        TYPE TIMESTAMPTZ
        USING evaluated_at AT TIME ZONE 'UTC'
        """
    )


def downgrade() -> None:
    op.execute(
        """
        ALTER TABLE agent_trust_identity_snapshots
        ALTER COLUMN evaluated_at
        TYPE TIMESTAMP
        USING evaluated_at AT TIME ZONE 'UTC'
        """
    )