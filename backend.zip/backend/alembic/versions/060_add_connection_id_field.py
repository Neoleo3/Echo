from alembic import op
import sqlalchemy as sa

revision = "060"
down_revision = "059"

def upgrade():
    op.add_column(
        "uploaded_files",
        sa.Column(
            "connection_id",
            sa.String(64),
            nullable=True,
        ),
    )

def downgrade():
    op.drop_column(
        "uploaded_files",
        "connection_id",
    )