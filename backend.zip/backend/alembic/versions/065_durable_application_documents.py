"""Make application-chat documents durable

Revision ID: 065
Revises: 064
Create Date: 2026-08-10

Session document retrieval was backed by two things on local disk: the uploaded
file under ``APP_UPLOADS_DIR``, and a FAISS index under
``APP_UPLOADS_DIR/rag_indexes/{session_id}/``. The platform runs on cloud
containers with more than one replica and no shared filesystem, so neither
survives a restart, a redeploy, or a request routed to a different replica.

The ``application_documents`` row *did* survive. The result was the worst
possible shape of the failure: the conversation still listed the document, the
readiness ledger still reported it as ready, and every retrieval against it
returned nothing — so the agent answered as though the document had never been
uploaded, and the user had to upload it again.

This migration moves both halves into Postgres, matching the decision already
taken for agent attachments in migration 063:

* ``application_documents.content_bytes`` — the original upload, so a document
  can be converted again without asking the user for it a second time, and so
  the local file can be rehydrated on any replica for the tools that still
  consume a path.
* ``application_document_chunks`` — the passages and their embeddings. This
  table *is* the vector store; there is no ``pgvector`` extension in this
  deployment, so vectors are stored normalized as little-endian float32 bytes
  and ranked in the application over one session's own passages.

Both changes are additive. No column is dropped or retyped, every existing row
stays valid, and the code keeps reading the on-disk FAISS index for any session
that already has one — so sessions created before this migration continue to
answer until they are re-uploaded.
"""

from typing import Sequence, Union

from alembic import op

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "065"
down_revision: Union[str, None] = "064"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None



def upgrade() -> None:
    # The original upload. Nullable: rows written before this migration have
    # no stored copy, and an application-level document may legitimately be
    # kept by reference alone.
    op.add_column(
        "application_documents",
        sa.Column("content_bytes", sa.LargeBinary(), nullable=True),
    )

    op.create_table(
        "application_document_chunks",
        sa.Column(
            "chunk_id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            nullable=False,
        ),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("application_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("chat_session_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("chunk_index", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("source_name", sa.String(length=512), nullable=False, server_default=""),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("embedding", sa.LargeBinary(), nullable=True),
        sa.Column("dimensions", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("embedding_model", sa.String(length=128), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.current_timestamp(),
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["application_documents.document_id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["application_id"],
            ["applications.application_id"],
            ondelete="CASCADE",
        ),
    )

    # Retrieval reads one session's passages in a single indexed query rather
    # than joining through every document in the application.
    op.create_index(
        "idx_app_doc_chunks_session",
        "application_document_chunks",
        ["chat_session_id", "document_id"],
    )
    op.create_index(
        "ix_application_document_chunks_document_id",
        "application_document_chunks",
        ["document_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_application_document_chunks_document_id",
        table_name="application_document_chunks",
    )
    op.drop_index(
        "idx_app_doc_chunks_session",
        table_name="application_document_chunks",
    )
    op.drop_table("application_document_chunks")
    op.drop_column("application_documents", "content_bytes")
