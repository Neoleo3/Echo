"""drop duplicate unique index on generated_files.download_key

Revision ID: 034
Revises: 033
Create Date: 2026-04-30

Some earlier migrations created both a unique constraint and a unique index
on generated_files.download_key. Only one is needed.
"""

from typing import Sequence, Union

from alembic import op


revision: str = "034"
down_revision: Union[str, None] = "033"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_generated_files_download_key")


def downgrade() -> None:
    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_generated_files_download_key "
        "ON generated_files (download_key)"
    )
