"""ensure users.role exists on drifted databases

Revision ID: 036
Revises: 035
Create Date: 2026-04-30

Idempotent reconciliation ensuring users.role exists, is NOT NULL,
has a default, and admin/super_admin emails are seeded correctly.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "036"
down_revision: Union[str, None] = "035"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_SUPER_ADMINS = ("shreyanf", "nehabehl", "shashank", "advait")
_ADMINS = ("ashnamuthappa", "satyajitga", "vanshika")


def upgrade() -> None:
    # Column should already exist from CurrCloud 023, but ensure it
    op.execute(
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(20) DEFAULT 'user';"
    )

    op.execute("""
        UPDATE users
        SET role = COALESCE(NULLIF(metadata->>'role', ''), 'user')
        WHERE role IS NULL OR BTRIM(role) = '';
    """)
    op.execute("ALTER TABLE users ALTER COLUMN role SET DEFAULT 'user';")
    op.execute("ALTER TABLE users ALTER COLUMN role SET NOT NULL;")

    for prefix in _SUPER_ADMINS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'super_admin' "
                "WHERE LOWER(email) LIKE :pattern"
            ).bindparams(pattern=f"{prefix}%")
        )

    for prefix in _ADMINS:
        op.execute(
            sa.text(
                "UPDATE users SET role = 'admin' "
                "WHERE LOWER(email) LIKE :pattern"
            ).bindparams(pattern=f"{prefix}%")
        )


def downgrade() -> None:
    pass
