"""add api and mcp connector tables

Revision ID: 018
Revises: 017
Create Date: 2026-03-12
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import JSONB


revision = "018"
down_revision = "017"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "api_connectors",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("connector_id", sa.String(length=255), nullable=False),
        sa.Column("config_json", JSONB(), server_default=sa.text("'{}'::jsonb"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "connector_id", name="uq_api_connectors_user_connector"),
    )
    op.create_index("idx_api_connectors_user_id", "api_connectors", ["user_id"], unique=False)
    op.create_index(
        "idx_api_connectors_config_json_gin",
        "api_connectors",
        ["config_json"],
        unique=False,
        postgresql_using="gin",
    )

    op.create_table(
        "mcp_connectors",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("connector_id", sa.String(length=255), nullable=False),
        sa.Column("connected", sa.Boolean(), server_default="false", nullable=False),
        sa.Column("config_json", JSONB(), server_default=sa.text("'{}'::jsonb"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.current_timestamp(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["user_id"], ["users.user_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "connector_id", name="uq_mcp_connectors_user_connector"),
    )
    op.create_index("idx_mcp_connectors_user_id", "mcp_connectors", ["user_id"], unique=False)
    op.create_index(
        "idx_mcp_connectors_config_json_gin",
        "mcp_connectors",
        ["config_json"],
        unique=False,
        postgresql_using="gin",
    )


def downgrade() -> None:
    op.drop_index("idx_mcp_connectors_config_json_gin", table_name="mcp_connectors")
    op.drop_index("idx_mcp_connectors_user_id", table_name="mcp_connectors")
    op.drop_table("mcp_connectors")

    op.drop_index("idx_api_connectors_config_json_gin", table_name="api_connectors")
    op.drop_index("idx_api_connectors_user_id", table_name="api_connectors")
    op.drop_table("api_connectors")
