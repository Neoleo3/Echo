"""add graph_model column to knowledge_bases

Revision ID: 015
Revises: 014
Create Date: 2026-03-05
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '015'
down_revision = '014'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        'knowledge_bases',
        sa.Column('graph_model', sa.String(255), nullable=True),
    )


def downgrade() -> None:
    op.drop_column('knowledge_bases', 'graph_model')
