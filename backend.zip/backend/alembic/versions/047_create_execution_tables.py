"""Create execution_runs and execution_steps tables for workflow persistence

Revision ID: 047
Revises: 046
Create Date: 2026-06-28

WHY: Workflow execution tracking (run_id, step_id, status, timestamps) is
currently stored in-memory with a 60-second TTL. When clients poll after 60s,
they get 404 errors. Adding these two tables enables:
1. Database fallback for the transparency module (ExecutionRunRepository)
2. Late-joining clients to query execution history
3. Audit trail for workflow runs and individual steps
4. Foundation for execution monitoring and analytics

Schema:
- execution_runs: Tracks each workflow run (started, in-progress, completed)
- execution_steps: Tracks each step within a run (agent execution, tool calls, etc)
"""

from typing import Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "047"
down_revision: Union[str, None] = "046"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create execution_runs table
    op.create_table(
        "execution_runs",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", sa.String(length=255), nullable=False, unique=True),
        sa.Column("workflow_id", sa.String(length=255), nullable=True),
        sa.Column("user_id", sa.String(length=255), nullable=True),
        sa.Column("status", sa.String(length=50), nullable=False, default="running"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata", postgresql.JSONB(), nullable=True, default=dict()),
        sa.PrimaryKeyConstraint("id"),
        sa.Index("idx_execution_runs_run_id", "run_id"),
        sa.Index("idx_execution_runs_workflow_id", "workflow_id"),
        sa.Index("idx_execution_runs_user_id", "user_id"),
        sa.Index("idx_execution_runs_status", "status"),
    )

    # Create execution_steps table
    op.create_table(
        "execution_steps",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", sa.String(length=255), nullable=False),
        sa.Column("step_id", sa.String(length=255), nullable=False),
        sa.Column("agent_name", sa.String(length=255), nullable=False),
        sa.Column("step_type", sa.String(length=50), nullable=False),
        sa.Column("input_summary", sa.Text(), nullable=True),
        sa.Column("output_summary", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("metadata", postgresql.JSONB(), nullable=True, default=dict()),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["run_id"], ["execution_runs.run_id"], ondelete="CASCADE"),
        sa.Index("idx_execution_steps_run_id", "run_id"),
        sa.Index("idx_execution_steps_step_id", "step_id"),
        sa.Index("idx_execution_steps_agent_name", "agent_name"),
        sa.Index("idx_execution_steps_step_type", "step_type"),
    )


def downgrade() -> None:
    op.drop_table("execution_steps")
    op.drop_table("execution_runs")
