"""Re-seed lookup tables after truncation

Revision ID: 013
Revises: 012
Create Date: 2026-03-03

Migration 010 truncated all tables. This re-inserts the default seed data
for the five lookup tables: personas, guardrail_categories, designations,
business_units, and tags.
"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "013"
down_revision: Union[str, None] = "012"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Personas
    op.execute("""
        INSERT INTO app_personas (persona_id, name) VALUES
        (gen_random_uuid(), 'Support Agent'),
        (gen_random_uuid(), 'HR Assistant'),
        (gen_random_uuid(), 'Sales Assistant'),
        (gen_random_uuid(), 'Legal Advisor'),
        (gen_random_uuid(), 'Technical Expert')
        ON CONFLICT DO NOTHING;
    """)

    # Guardrail Categories
    op.execute("""
        INSERT INTO app_guardrail_categories (guardrail_category_id, name) VALUES
        (gen_random_uuid(), 'Compliance'),
        (gen_random_uuid(), 'PII'),
        (gen_random_uuid(), 'Safety')
        ON CONFLICT DO NOTHING;
    """)

    # Designations
    op.execute("""
        INSERT INTO app_designations (designation_id, name) VALUES
        (gen_random_uuid(), 'Executive'),
        (gen_random_uuid(), 'Manager'),
        (gen_random_uuid(), 'Individual Contributor'),
        (gen_random_uuid(), 'Intern')
        ON CONFLICT DO NOTHING;
    """)

    # Business Units
    op.execute("""
        INSERT INTO app_business_units (business_unit_id, name) VALUES
        (gen_random_uuid(), 'Operations'),
        (gen_random_uuid(), 'Human Resources'),
        (gen_random_uuid(), 'Sales'),
        (gen_random_uuid(), 'Engineering'),
        (gen_random_uuid(), 'Legal'),
        (gen_random_uuid(), 'Finance')
        ON CONFLICT DO NOTHING;
    """)

    # Tags
    op.execute("""
        INSERT INTO app_tags (tag_id, name) VALUES
        (gen_random_uuid(), 'Internal'),
        (gen_random_uuid(), 'External'),
        (gen_random_uuid(), 'Priority'),
        (gen_random_uuid(), 'Experimental')
        ON CONFLICT DO NOTHING;
    """)


def downgrade() -> None:
    op.execute("DELETE FROM app_tags WHERE name IN ('Internal', 'External', 'Priority', 'Experimental');")
    op.execute("DELETE FROM app_business_units WHERE name IN ('Operations', 'Human Resources', 'Sales', 'Engineering', 'Legal', 'Finance');")
    op.execute("DELETE FROM app_designations WHERE name IN ('Executive', 'Manager', 'Individual Contributor', 'Intern');")
    op.execute("DELETE FROM app_guardrail_categories WHERE name IN ('Compliance', 'PII', 'Safety');")
    op.execute("DELETE FROM app_personas WHERE name IN ('Support Agent', 'HR Assistant', 'Sales Assistant', 'Legal Advisor', 'Technical Expert');")
