"""add is_default_embedding to credentials

Revision ID: 090
Revises: 089
Create Date: 2026-09-29

Chat and embedding models shared one ``is_default`` flag, so a knowledge base
that fell back to "the user's default credential" could be handed a chat
deployment, and there was no way to prefer a specific embedding credential
independently of whichever model happened to be the chat default. This adds a
second, independent default flag with its own partial unique index, mirroring
``idx_user_creds_one_default`` exactly.
"""

from alembic import op
import sqlalchemy as sa

revision = "090"
down_revision = "089"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "user_llm_credentials",
        sa.Column(
            "is_default_embedding",
            sa.Boolean(),
            server_default="false",
            nullable=False,
        ),
    )
    op.create_index(
        "idx_user_creds_one_default_embedding",
        "user_llm_credentials",
        ["user_id"],
        unique=True,
        postgresql_where=sa.text("is_default_embedding = TRUE AND is_deleted = FALSE"),
    )


def downgrade() -> None:
    op.drop_index("idx_user_creds_one_default_embedding", table_name="user_llm_credentials")
    op.drop_column("user_llm_credentials", "is_default_embedding")
