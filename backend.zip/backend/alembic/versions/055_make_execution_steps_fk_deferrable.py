"""Make execution_steps FK constraint deferrable - FIX for ForeignKeyViolationError

Revision ID: 055
Revises: 054
Create Date: 2026-07-04

ISSUE:
- Migration 047 created execution_steps with strict FK constraint
- Checked at INSERT time (fails immediately on orphaned row)
- Transparency module saves steps before ExecutionRun record created
- Result: IntegrityError repeats for every step during workflow execution

FIX:
- Make FK DEFERRABLE INITIALLY DEFERRED
- Validates at transaction COMMIT instead of INSERT
- Allows flexible insert order within transaction
- Maintains referential integrity at same point in time

BACKWARD COMPATIBLE:
✅ No schema visible changes to application code
✅ No runtime changes needed
✅ Existing workflows continue to work
✅ Constraint still enforced (at transaction end instead of immediately)

ROOT CAUSE:
The transparency module (apps/workflow/runtime/transparency.py:276) calls _save_step_sync()
which immediately INSERTs into execution_steps table before ExecutionRun record exists.
With a strict FK constraint, this fails. By making the constraint DEFERRABLE, inserts
can succeed in any order within a transaction - validation happens at COMMIT time when
both tables are populated.
"""

from typing import Union
from alembic import op


revision: str = "055"
down_revision: Union[str, None] = "054"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """
    Drop non-deferrable FK constraint and recreate as DEFERRABLE INITIALLY DEFERRED.
    
    This allows the transparency module and executor to save steps/runs in any order
    within a transaction. Constraint validation occurs at COMMIT time instead of INSERT.
    
    PostgreSQL auto-generates constraint name: execution_steps_run_id_fkey
    """
    # Drop existing strict (non-deferrable) FK constraint
    op.execute(
        "ALTER TABLE execution_steps DROP CONSTRAINT execution_steps_run_id_fkey"
    )
    
    # Recreate as DEFERRABLE INITIALLY DEFERRED
    # This allows inserts in any order; validates at COMMIT not INSERT
    op.execute(
        """
        ALTER TABLE execution_steps 
        ADD CONSTRAINT execution_steps_run_id_fkey 
        FOREIGN KEY (run_id) 
        REFERENCES execution_runs(run_id) 
        ON DELETE CASCADE 
        DEFERRABLE INITIALLY DEFERRED
        """
    )


def downgrade() -> None:
    """
    Revert to original strict (non-deferrable) FK constraint.
    
    Note: In practice, downgrade is risky if there are orphaned steps.
    This migration should be kept permanently - do not downgrade.
    """
    # Drop the deferrable FK constraint
    op.execute(
        "ALTER TABLE execution_steps DROP CONSTRAINT execution_steps_run_id_fkey"
    )
    
    # Recreate original strict constraint (validates at INSERT)
    op.execute(
        """
        ALTER TABLE execution_steps 
        ADD CONSTRAINT execution_steps_run_id_fkey 
        FOREIGN KEY (run_id) 
        REFERENCES execution_runs(run_id) 
        ON DELETE CASCADE
        """
    )
