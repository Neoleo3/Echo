"""Add actions JSONB column to agentic_applications

Revision ID: 059
Revises: 058
Create Date: 2026-07-14

- agentic_applications.actions JSONB (nullable)
"""
from typing import Sequence, Union

from alembic import op


revision: str = "059"
down_revision: Union[str, None] = "058"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE agentic_applications "
        "ADD COLUMN IF NOT EXISTS actions JSONB"
    )
    op.execute(
        "COMMENT ON COLUMN agentic_applications.actions IS "
        "'Executable workflow/agent actions: action_id, workflow_id/agent_id, "
        "input_mapping[], output_mapping[]. Defines runtime contract for UI execution.'"
    )


def downgrade() -> None:
    op.execute(
        "ALTER TABLE agentic_applications DROP COLUMN IF EXISTS actions"
    )
