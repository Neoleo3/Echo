"""
Alembic Environment Configuration for EchoAI

Async SQLAlchemy configuration for PostgreSQL migrations.
"""
import asyncio
import ssl
from logging.config import fileConfig

from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Import models metadata for autogenerate support
# This will be populated when models are created
try:
    from echolib.models import Base
    target_metadata = Base.metadata
except ImportError:
    # Models not yet created, use None
    target_metadata = None

# Import database URL from config if available
try:
    from echolib.config import settings
    config.set_main_option("sqlalchemy.url", settings.database_url)
except ImportError:
    # Config not yet created, use default from alembic.ini
    pass


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    """Execute migrations with the given connection."""
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


def _get_connect_args() -> dict:
    """Return SSL connect args respecting DATABASE_SSL setting."""
    import os
    ssl_setting = os.getenv("DATABASE_SSL", "auto").lower().strip()
    if ssl_setting == "disable":
        return {}
    if ssl_setting == "require":
        return {"ssl": ssl.create_default_context()}
    # auto: detect from URL
    url = (config.get_main_option("sqlalchemy.url") or "").lower()
    if "ssl=require" in url or "sslmode=require" in url:
        return {"ssl": ssl.create_default_context()}
    for local in ("localhost", "127.0.0.1", "::1"):
        if local in url:
            return {}
    return {"ssl": ssl.create_default_context()}


async def run_async_migrations() -> None:
    """Run migrations in 'online' mode using async engine.

    In this scenario we need to create an Engine
    and associate a connection with the context.
    """
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        connect_args=_get_connect_args(),
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
