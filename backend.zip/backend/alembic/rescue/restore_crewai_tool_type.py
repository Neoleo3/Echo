"""
Rescue script -- restore the 'crewai' tool type removed by migration ``064``.

WHAT: Puts the ``tools`` table back into its pre-``064`` shape: the permissive
      ``valid_tool_type`` CHECK constraint, and optionally the row labels that
      ``064`` rewrote from ``crewai`` to ``local``.
WHY:  There is no separate staging environment. If applying ``064`` destabilises
      a deployment mid-demo, this restores the previous database state in one
      command without touching the Alembic chain.

THIS IS DELIBERATELY NOT AN ALEMBIC REVISION.
A forward revision carrying this restore would be picked up by
``alembic upgrade head`` and silently undo ``064`` on every deploy. A
branch-labelled revision would create a second head and break
``alembic upgrade head`` outright. Living outside ``alembic/versions/`` means
this file can never enter the upgrade path and can be run any number of times.

PRECONDITION FOR ``--rows``
    Restoring the row labels is only correct when the application code is also
    rolled back to its pre-Phase-9 state. Under current code ``ToolType`` has no
    ``CREWAI`` member, so ``ToolRegistry._hydrate_tool_from_row`` raises on
    ``ToolDef(**row.definition)``, swallows the error and returns ``None``; with
    ``LEGACY_FILE_READ_ENABLED=false`` there is no filesystem fallback, so a
    database-only tool would silently disappear. Restoring the *constraint* is
    safe under both code versions -- it only widens what may be stored.

ORDER MATTERS, AND IS THE INVERSE OF ``064``
    ``064`` narrows the allowed set, so it rewrites data first and swaps the
    constraint second. This script widens it, so it must swap the constraint
    first and rewrite data second -- writing ``crewai`` while the restrictive
    constraint is still in place would be rejected.

WHICH ROWS ARE RESTORED
    ``064`` records nothing about the rows it rewrote, so an exact reversal is
    not derivable from the database. The default target list is the tool
    catalogue shipped in ``AgentTools/*/tool_manifest.json`` that declares
    ``"tool_type": "crewai"``. Override it with ``--tool-id`` when a deployment
    carries user-created tools that also need restoring. Running with no action
    flag prints the current state of every target, so the list can be checked
    before anything is written.

Every action is idempotent and re-runnable. Everything happens inside one
transaction, so a failure leaves nothing half-applied.
"""
from __future__ import annotations

import argparse
import asyncio
import os
import ssl
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# Run directly (``python alembic/rescue/restore_crewai_tool_type.py``), so the
# backend root is not on sys.path yet. alembic/rescue/<file> -> backend/
_BACKEND_ROOT = Path(__file__).resolve().parents[2]
if str(_BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(_BACKEND_ROOT))

from sqlalchemy import bindparam, text  # noqa: E402
from sqlalchemy.ext.asyncio import create_async_engine  # noqa: E402

TABLE = "tools"
CONSTRAINT = "valid_tool_type"

# Pre-064 allowed set, from alembic/versions/001_initial_schema.py:179.
PERMISSIVE_TYPES = ("local", "mcp", "api", "crewai", "custom")

# Tools shipping as tool_type "crewai" in AgentTools/*/tool_manifest.json.
DEFAULT_TOOL_IDS: Sequence[str] = (
    "tool_docx_generator",
    "tool_excel_generator",
    "tool_pdf_generator",
    "tool_ppt_generator",
    "tool_ppt_generator_template",
)


# ----------------------------------------------------------------------
# Connection
# ----------------------------------------------------------------------


def resolve_database_url(explicit: Optional[str] = None) -> str:
    """
    Resolve the database URL, mirroring how ``alembic/env.py`` finds it.

    Order: explicit argument, ``DATABASE_URL``, ``echolib.config.settings``,
    then ``alembic.ini``. The echolib import is guarded the same way ``env.py``
    guards it, so a missing application dependency cannot block the rescue.
    """
    if explicit:
        return _as_asyncpg(explicit)

    env_url = os.getenv("DATABASE_URL")
    if env_url:
        return _as_asyncpg(env_url)

    try:
        from echolib.config import settings

        if getattr(settings, "database_url", None):
            return _as_asyncpg(settings.database_url)
    except Exception as exc:  # pragma: no cover - operator diagnostic
        print(f"[rescue] echolib.config unavailable ({exc}); falling back to alembic.ini")

    ini_path = _BACKEND_ROOT / "alembic.ini"
    if ini_path.exists():
        import configparser

        parser = configparser.ConfigParser()
        parser.read(ini_path, encoding="utf-8")
        ini_url = parser.get("alembic", "sqlalchemy.url", fallback="")
        if ini_url:
            return _as_asyncpg(ini_url)

    raise SystemExit(
        "[rescue] Could not resolve a database URL. "
        "Pass --database-url, or set DATABASE_URL."
    )


def _as_asyncpg(url: str) -> str:
    """Normalize any accepted PostgreSQL URL form onto the asyncpg driver."""
    url = url.strip()
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://") :]
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://") :]
    return url


def connect_args(url: str) -> Dict[str, Any]:
    """SSL connect args honouring DATABASE_SSL, copied from ``alembic/env.py``."""
    ssl_setting = os.getenv("DATABASE_SSL", "auto").lower().strip()
    if ssl_setting == "disable":
        return {}
    if ssl_setting == "require":
        return {"ssl": ssl.create_default_context()}

    lowered = (url or "").lower()
    if "ssl=require" in lowered or "sslmode=require" in lowered:
        return {"ssl": ssl.create_default_context()}
    for local in ("localhost", "127.0.0.1", "::1"):
        if local in lowered:
            return {}
    return {"ssl": ssl.create_default_context()}


# ----------------------------------------------------------------------
# Inspection
# ----------------------------------------------------------------------


async def current_constraint(conn: Any) -> Optional[str]:
    """Return the current CHECK definition for ``valid_tool_type``, if present."""
    result = await conn.execute(
        text(
            "SELECT pg_get_constraintdef(c.oid) "
            "FROM pg_constraint c "
            "WHERE c.conname = :name AND c.conrelid = to_regclass(:table)"
        ),
        {"name": CONSTRAINT, "table": TABLE},
    )
    row = result.first()
    return row[0] if row else None


async def target_rows(conn: Any, tool_ids: Sequence[str]) -> List[Any]:
    """Report the stored type of every target tool, from both places it is held."""
    stmt = text(
        "SELECT definition->>'tool_id' AS tool_id, "
        "       tool_type            AS column_type, "
        "       definition->>'tool_type' AS definition_type, "
        "       is_deleted "
        "FROM tools "
        "WHERE definition->>'tool_id' IN :ids "
        "ORDER BY 1"
    ).bindparams(bindparam("ids", expanding=True))
    result = await conn.execute(stmt, {"ids": list(tool_ids)})
    return list(result.fetchall())


async def print_status(conn: Any, tool_ids: Sequence[str]) -> None:
    """Print the current constraint and target-row state. Writes nothing."""
    definition = await current_constraint(conn)
    print(f"[rescue] constraint {CONSTRAINT}: {definition or '<absent>'}")
    if definition and "crewai" in definition:
        print("[rescue] constraint state: PERMISSIVE (pre-064) — 'crewai' is allowed")
    elif definition:
        print("[rescue] constraint state: RESTRICTIVE (064 applied) — 'crewai' is rejected")

    rows = await target_rows(conn, tool_ids)
    if not rows:
        print(f"[rescue] none of the {len(tool_ids)} target tool(s) are present in the database")
        return

    print(f"[rescue] target tools ({len(rows)} found):")
    for row in rows:
        deleted = " [soft-deleted]" if row.is_deleted else ""
        print(
            f"           {row.tool_id}: column={row.column_type} "
            f"definition={row.definition_type}{deleted}"
        )


# ----------------------------------------------------------------------
# Restore
# ----------------------------------------------------------------------


async def restore_constraint(conn: Any) -> None:
    """
    Replace ``valid_tool_type`` with the pre-064 permissive set.

    Dropped with IF EXISTS for the same reason ``064`` does it: the constraint is
    declared on the ORM model rather than created by a migration, so a database
    built from an older baseline may not carry it under this name. The restored
    set is strictly wider than any set currently in force, so it cannot reject a
    row that already exists.
    """
    await conn.execute(text(f"ALTER TABLE {TABLE} DROP CONSTRAINT IF EXISTS {CONSTRAINT}"))
    allowed = ", ".join(f"'{value}'" for value in PERMISSIVE_TYPES)
    await conn.execute(
        text(
            f"ALTER TABLE {TABLE} ADD CONSTRAINT {CONSTRAINT} "
            f"CHECK (tool_type IN ({allowed}))"
        )
    )
    print(f"[rescue] constraint {CONSTRAINT} restored to ({allowed})")


async def restore_rows(conn: Any, tool_ids: Sequence[str]) -> None:
    """
    Relabel the target tools from ``local`` back to ``crewai``.

    Both places the type is stored are rewritten. ``tools.tool_type`` is what the
    CHECK constraint and type filters read; ``definition->>'tool_type'`` is what
    ``ToolRegistry._hydrate_tool_from_row`` reads when it rebuilds a ToolDef from
    the database, and leaving it behind would resurrect the wrong label on the
    next cache miss.

    Only rows currently labelled ``local`` are touched, so a tool that was never
    CrewAI-backed cannot be mislabelled by a repeat run.
    """
    column_stmt = text(
        "UPDATE tools SET tool_type = 'crewai' "
        "WHERE definition->>'tool_id' IN :ids AND tool_type = 'local'"
    ).bindparams(bindparam("ids", expanding=True))
    result = await conn.execute(column_stmt, {"ids": list(tool_ids)})
    print(f"[rescue] tools.tool_type restored to 'crewai': {result.rowcount}")

    definition_stmt = text(
        "UPDATE tools "
        "SET definition = jsonb_set(definition, '{tool_type}', '\"crewai\"'::jsonb) "
        "WHERE definition->>'tool_id' IN :ids "
        "AND definition ? 'tool_type' "
        "AND definition->>'tool_type' = 'local'"
    ).bindparams(bindparam("ids", expanding=True))
    result = await conn.execute(definition_stmt, {"ids": list(tool_ids)})
    print(f"[rescue] tool definitions restored to 'crewai': {result.rowcount}")


async def run(args: argparse.Namespace) -> int:
    """Resolve the connection, apply the requested actions, report the outcome."""
    url = resolve_database_url(args.database_url)
    printable = url.split("@")[-1] if "@" in url else url
    print(f"[rescue] target database: ...@{printable}")

    engine = create_async_engine(url, connect_args=connect_args(url), pool_pre_ping=False)
    tool_ids = list(args.tool_id) if args.tool_id else list(DEFAULT_TOOL_IDS)

    do_constraint = args.all or args.constraint
    do_rows = args.all or args.rows

    try:
        async with engine.begin() as conn:
            print("[rescue] --- before ---")
            await print_status(conn, tool_ids)

            if not (do_constraint or do_rows):
                print(
                    "\n[rescue] No action requested; nothing was changed.\n"
                    "[rescue] Use --constraint, --rows, or --all. See --help."
                )
                return 0

            # A widening constraint must land before any 'crewai' write, or the
            # UPDATE is rejected by the restrictive constraint still in force.
            if do_rows and not do_constraint:
                definition = await current_constraint(conn)
                if definition and "crewai" not in definition:
                    print(
                        "\n[rescue] ABORTED: the restrictive constraint is still in place, "
                        "so writing 'crewai' would be rejected.\n"
                        "[rescue] Run with --all (or --constraint first)."
                    )
                    return 2

            print("[rescue] --- applying ---")
            if do_constraint:
                await restore_constraint(conn)
            if do_rows:
                await restore_rows(conn, tool_ids)

            print("[rescue] --- after ---")
            await print_status(conn, tool_ids)

            if args.dry_run:
                # Raising out of engine.begin() rolls the transaction back.
                raise _DryRun()
    except _DryRun:
        print("\n[rescue] DRY RUN — transaction rolled back, nothing was written.")
        return 0
    finally:
        await engine.dispose()

    print("\n[rescue] Done. Committed.")
    if do_rows:
        print(
            "[rescue] REMINDER: row labels are only meaningful with pre-Phase-9 "
            "application code deployed. Current code cannot load a 'crewai' tool."
        )
    return 0


class _DryRun(Exception):
    """Internal signal used to roll back a dry run."""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="restore_crewai_tool_type",
        description=(
            "Restore the pre-064 'crewai' tool type. "
            "With no action flag it reports current state and changes nothing."
        ),
    )
    parser.add_argument(
        "--constraint",
        action="store_true",
        help="Restore the permissive valid_tool_type CHECK constraint. Safe under any code version.",
    )
    parser.add_argument(
        "--rows",
        action="store_true",
        help="Relabel the target tools back to 'crewai'. Requires pre-Phase-9 code.",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Both --constraint and --rows, in the correct order.",
    )
    parser.add_argument(
        "--tool-id",
        action="append",
        metavar="TOOL_ID",
        help="Override the default target list. Repeatable.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Execute inside a transaction and roll it back. Reports what would change.",
    )
    parser.add_argument(
        "--database-url",
        default=None,
        help="Override the resolved database URL.",
    )
    return parser


def main() -> int:
    return asyncio.run(run(build_parser().parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
