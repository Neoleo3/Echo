#!/bin/bash
set -e

echo "Running Alembic migrations..."
python -m alembic upgrade 091

echo "Starting application..."
exec "$@"
