"""
LLM Routes - FastAPI endpoints that expose LLM functionality.

Uses LLMService which delegates to LLMFactory.

Also includes Per-User LLM Credential CRUD endpoints.  API keys are stored
in Azure Key Vault (secret name: ``user-cred-{credential_id}``); only
non-secret metadata is persisted in PostgreSQL.
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

# Import LLMService (which wraps LLMFactory)
from echolib.services import LLMService
from echolib.LLM_Details.Exceptions.custom_exceptions import (
    ModelNotFoundError,
    MissingAPIKeyError,
    LLMExecutionError,
    ValidationError,
    EmbeddingError
)

# Credential CRUD dependencies
from echolib.credential_crypto import encrypt_api_key
from echolib.credential_resolver import is_embedding_credential, read_credential_api_key
from echolib.database import get_db_session
from echolib.model_capabilities import (
    FAMILY_AUTO,
    MODEL_FAMILY_PATTERN,
    REASONING_EFFORT_PATTERN,
    normalize_model_family,
    normalize_reasoning_effort,
)
from echolib.models.user_llm_credential import UserLlmCredential
from echolib.secrets_provider import secrets
from echolib.security import get_current_user, require_user, require_admin_or_above, resolve_user_id
from echolib.types import UserContext

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Path to the canonical provider catalog JSON
_LLM_PROVIDER_JSON = (
    Path(__file__).resolve().parent.parent.parent
    / "echolib" / "LLM_Details" / "Providers" / "llm_provider.json"
)

# Initialize APIRouter
router = APIRouter(
    prefix="/LLMs",
    tags=["LLMs"]
)

# Global LLMService instance (will be initialized with tool_service)
llm_service = LLMService(None)

# ==================== REQUEST/RESPONSE MODELS ====================

class InvokeRequest(BaseModel):
    model_id: str
    prompt: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class ChatRequest(BaseModel):
    model_id: str
    messages: List[Dict[str, str]]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class StreamRequest(BaseModel):
    model_id: str
    prompt: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class JsonModeRequest(BaseModel):
    model_id: str
    prompt: str
    schema: Optional[Dict] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class FunctionCallRequest(BaseModel):
    model_id: str
    tools: List[Dict]
    prompt: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class EmbedRequest(BaseModel):
    model_id: str
    text: Union[str, List[str]]


# Provider slugs the platform can actually construct a client for. Kept in
# lockstep with ``echolib.llm_client_builder_v2._SUPPORTED_PROVIDERS`` — a
# provider accepted here but unknown there is a registration that only fails
# at the first invocation, long after the user could act on it.
_PROVIDER_PATTERN = "^(azure|openai|anthropic|ollama|gemini|workbench)$"

# Bounds on the optional tuning fields. Generous on purpose: they exist to
# reject typos and negative values, not to second-guess a model the platform
# has never heard of.
_MIN_CONTEXT_WINDOW = 128
_MAX_CONTEXT_WINDOW = 20_000_000
_MIN_OUTPUT_TOKENS = 1
_MAX_OUTPUT_TOKENS = 1_000_000

# Output budget for a "Test connection" call. Deliberately small — the test
# proves the endpoint, the key and the deployment name, not the model's
# writing. A reasoning model has this raised to the floor in
# ``model_capabilities``, because there the budget also pays for thinking and
# 100 tokens would come back empty and look like a failure.
_TEST_MAX_TOKENS = 100


class CustomModelRequest(BaseModel):
    model_id: Optional[str] = Field(None, description="Unique identifier (auto-generated from provider/model_name if omitted)")
    name: str = Field(..., min_length=1, max_length=255, description="Display name")
    provider: str = Field(..., pattern=_PROVIDER_PATTERN, description="Provider slug (azure, openai, anthropic, ollama, gemini)")
    base_url: str = Field(..., description="API endpoint URL")
    api_key_env: Optional[str] = Field(None, description="Environment variable name for API key")
    api_key: Optional[str] = Field(None, description="API key (stored in Key Vault, never returned).")
    model_name: str = Field(..., min_length=1, description="Model identifier at provider")
    description: Optional[str] = Field("", description="Free-text description shown on the model card")
    icon: Optional[str] = Field(None, description="Icon slug shown on the model card")
    is_default: Optional[bool] = False
    is_embedding: Optional[bool] = Field(
        None,
        description="Explicitly mark this as an embedding model, overriding name-based detection.",
    )
    is_default_embedding: Optional[bool] = Field(
        None,
        description="Promote this model to the caller's default embedding model. Independent of is_default.",
    )
    api_version: Optional[str] = Field(None, description="API version (Azure)")
    deployment_name: Optional[str] = Field(None, description="Azure deployment name")
    # --- Optional capability / tuning metadata -----------------------------
    # All three are optional and default to None, which means "do not state
    # one" — the resolver then behaves exactly as it did before these fields
    # existed. They are only ever read when the user supplied a value.
    context_window: Optional[int] = Field(
        None,
        ge=_MIN_CONTEXT_WINDOW,
        le=_MAX_CONTEXT_WINDOW,
        description="Maximum input context in tokens. Published to LangChain as profile.max_input_tokens.",
    )
    max_output_tokens: Optional[int] = Field(
        None,
        ge=_MIN_OUTPUT_TOKENS,
        le=_MAX_OUTPUT_TOKENS,
        description="Default ceiling on generated tokens when the caller states none.",
    )
    temperature: Optional[float] = Field(
        None,
        ge=0.0,
        le=2.0,
        description="Default sampling temperature when the caller states none.",
    )
    model_family: Optional[str] = Field(
        None,
        pattern=MODEL_FAMILY_PATTERN,
        description=(
            "Which request schema this model follows: 'gpt4' (GPT-4 family and "
            "earlier, full sampling), 'gpt5' (GPT-5 family and o-series — no "
            "temperature or top_p), or 'auto' to detect from the model and "
            "deployment names. Omitted means auto."
        ),
    )
    reasoning_effort: Optional[str] = Field(
        None,
        pattern=REASONING_EFFORT_PATTERN,
        description=(
            "How hard a reasoning model thinks. Sent only to GPT-5-family and "
            "o-series models. 'none' is required on gpt-5.6 and later when the "
            "model is given tools over Chat Completions."
        ),
    )
    enabled: Optional[bool] = Field(
        None,
        description="Whether this model is offered in selection lists. Defaults to enabled.",
    )
    daily_limit: Optional[int] = Field(
    None,
    ge=1,
    description="Daily token budget",
    )

    monthly_limit: Optional[int] = Field(
        None,
        ge=1,
        description="Monthly token budget",
    )


class CustomModelUpdateRequest(BaseModel):
    """Request body for updating an existing custom model.

    Every field is optional: the frontend sends only what the user changed.
    ``None`` therefore means "leave alone", never "clear".
    """
    name: Optional[str] = Field(None, min_length=1, max_length=255, description="Display name")
    provider: Optional[str] = Field(None, pattern=_PROVIDER_PATTERN, description="Provider slug (azure, openai, anthropic, ollama, gemini)")
    base_url: Optional[str] = Field(None, description="API endpoint URL")
    api_key_env: Optional[str] = Field(None, description="Environment variable name for API key")
    api_key: Optional[str] = Field(None, description="API key (stored in Key Vault, never returned).")
    model_name: Optional[str] = Field(None, description="Model identifier at provider")
    description: Optional[str] = None
    icon: Optional[str] = None
    api_version: Optional[str] = Field(None, description="API version (Azure)")
    deployment_name: Optional[str] = Field(None, description="Azure deployment name")
    context_window: Optional[int] = Field(None, ge=_MIN_CONTEXT_WINDOW, le=_MAX_CONTEXT_WINDOW)
    max_output_tokens: Optional[int] = Field(None, ge=_MIN_OUTPUT_TOKENS, le=_MAX_OUTPUT_TOKENS)
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    model_family: Optional[str] = Field(None, pattern=MODEL_FAMILY_PATTERN)
    reasoning_effort: Optional[str] = Field(None, pattern=REASONING_EFFORT_PATTERN)
    enabled: Optional[bool] = None
    is_default: Optional[bool] = Field(
        None,
        description="Promote this model to the caller's default. Demotes the previous default in the same transaction.",
    )
    is_embedding: Optional[bool] = Field(
        None,
        description="Explicitly mark this as an embedding model, overriding name-based detection.",
    )
    is_default_embedding: Optional[bool] = Field(
        None,
        description="Promote this model to the caller's default embedding model. Independent of is_default.",
    )
    daily_limit: Optional[int] = Field(None, ge=1)

    monthly_limit: Optional[int] = Field(None, ge=1)


# ==================== CREDENTIAL PYDANTIC SCHEMAS ====================

class CredentialCreateRequest(BaseModel):
    """Request body for creating a new credential."""
    credential_name: str = Field(..., min_length=1, max_length=255, description="Human-readable label.")
    provider: str = Field(
        ...,
        min_length=1,
        max_length=50,
        pattern=_PROVIDER_PATTERN,
        description="Provider slug.",
    )
    api_key: Optional[str] = Field(None, description="API key (stored in Key Vault, never returned).")
    base_url: Optional[str] = Field(None, max_length=1024, description="Provider base URL.")
    api_version: Optional[str] = Field(None, max_length=50, description="API version (Azure).")
    deployment_name: Optional[str] = Field(None, max_length=255, description="Azure deployment name.")
    is_default: Optional[bool] = Field(None, description="Set as global default. Auto-set if first credential.")
    is_embedding: Optional[bool] = Field(
        None,
        description="Explicitly mark this as an embedding model, overriding name-based detection.",
    )
    is_default_embedding: Optional[bool] = Field(
        None,
        description="Set as default embedding credential. Independent of is_default.",
    )
    # Workbench-only; ignored by every other provider's builder branch.
    workbench_provider: Optional[str] = Field(None, max_length=50, description="Workbench child provider (openai).")
    charge_code: Optional[str] = Field(None, max_length=50, description="KPMG Workbench x-kpmg-charge-code header.")
    region_override: Optional[str] = Field(None, max_length=100, description="KPMG Workbench x-kpmg-region-override header.")
    azureml_model_deployment: Optional[str] = Field(None, max_length=255, description="KPMG Workbench azureml-model-deployment header.")


class CredentialUpdateRequest(BaseModel):
    """Request body for updating an existing credential."""
    credential_name: Optional[str] = Field(None, min_length=1, max_length=255)
    provider: Optional[str] = Field(
        None,
        min_length=1,
        max_length=50,
        pattern=_PROVIDER_PATTERN,
    )
    api_key: Optional[str] = Field(None, description="New API key (re-stored in Key Vault).")
    base_url: Optional[str] = Field(None, max_length=1024)
    api_version: Optional[str] = Field(None, max_length=50)
    deployment_name: Optional[str] = Field(None, max_length=255)
    workbench_provider: Optional[str] = Field(None, max_length=50)
    charge_code: Optional[str] = Field(None, max_length=50)
    region_override: Optional[str] = Field(None, max_length=100)
    azureml_model_deployment: Optional[str] = Field(None, max_length=255)
    is_embedding: Optional[bool] = Field(
        None,
        description="Explicitly mark this as an embedding model, overriding name-based detection.",
    )
    # No is_default_embedding here, matching is_default's absence on this
    # request: promotion for this resource happens only through the dedicated
    # PATCH set-default / set-default-embedding endpoints.


class CredentialResponse(BaseModel):
    """Single credential returned to the caller (api_key masked)."""
    credential_id: str
    credential_name: str
    provider: str
    is_default: bool
    is_default_embedding: bool
    api_key_set: bool = Field(description="True when an API key is stored (value is never returned).")
    base_url: Optional[str] = None
    api_version: Optional[str] = None
    deployment_name: Optional[str] = None
    workbench_provider: Optional[str] = None
    charge_code: Optional[str] = None
    region_override: Optional[str] = None
    azureml_model_deployment: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class CredentialTestRequest(BaseModel):
    """Optional overrides when testing a credential."""
    prompt: str = Field(
        "Say hello in one sentence.",
        max_length=500,
        description="Short prompt for the test invocation.",
    )


class CredentialTestResponse(BaseModel):
    """Result of a credential test call."""
    success: bool
    model_response: Optional[str] = None
    error: Optional[str] = None


class AvailableCredentialEntry(BaseModel):
    """A credential entry augmented with known models for dropdown display."""
    credential_id: str
    credential_name: str
    provider: str
    is_default: bool
    known_models: List[str] = []


class ProviderCatalogEntry(BaseModel):
    """Single provider from the catalog."""
    id: str
    name: str
    requires_fields: List[str]
    known_models: List[str] = []
    allow_custom_model: Optional[bool] = None


# ==================== METADATA HELPERS ====================


def _clean_text(value: Any) -> str:
    """
    Coerce a stored metadata value to a plain string.

    Rows written before this revision can hold ``[""]`` for ``description``:
    the model declared ``description: Optional[str] = "",`` with a trailing
    comma, which makes the default a one-tuple, and JSONB stores a tuple as a
    JSON array. Reading those rows must not leak a list into the API response.
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        return _clean_text(value[0]) if value else ""
    return str(value)


def _coerce_positive_int(value: Any) -> Optional[int]:
    """Return *value* as a positive int, or None when it is absent or unusable.

    Metadata is user-supplied JSONB, so a string, a float or a blank is all
    reachable. An unreadable value must degrade to "not stated" rather than
    raise — a bad tuning number is never a reason to fail a model resolution.
    """
    if value is None or value == "":
        return None
    try:
        parsed = int(float(value))
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _coerce_temperature(value: Any) -> Optional[float]:
    """Return *value* as a temperature in [0, 2], or None when unusable."""
    if value is None or value == "":
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if 0.0 <= parsed <= 2.0 else None


def _credential_has_api_key(row) -> bool:
    """
    Whether an API key is stored for this credential, without fetching it.

    Reads the row's own record of where the key went rather than calling Key
    Vault. That is deliberate on a list endpoint: a per-row vault round trip
    would be N network calls, and it would answer ``False`` for every
    credential whenever the vault is unreachable — which is exactly when the DB
    fallback holds the key and the answer is really ``True``.

    Never returns the key, only whether one exists.
    """
    if getattr(row, "encrypted_api_key", None):
        return True

    storage = getattr(row, "api_key_storage", None)
    if storage == "kv":
        return True

    # Rows predating the storage column: a key reference was written into
    # metadata whenever one was stored.
    meta = getattr(row, "config_metadata", None) or {}
    return bool(meta.get("api_key_ref"))


def _reject_impossible_output_ceiling(
    requested: int,
    *,
    provider: Optional[str],
    model: Optional[str],
    deployment_name: Optional[str],
) -> None:
    """
    Refuse an output ceiling larger than the model can actually produce.

    WHAT: Compares the requested value against the capability table and raises
          400 when it cannot be honoured.
    WHY:  The field accepts up to a million and the resolver forwards whatever
          it is given, so registering 30,000 against a GPT-4o deployment was
          accepted here and answered with an opaque provider 400 at the first
          real call -- long after the person who typed it could connect the two.
          Saying it at registration, with the model's real limit named, is the
          difference between a fixable message and a mystery.

    Silent when the model is unrecognised: the registrar may know a self-hosted
    endpoint this table never could, and rejecting on a guess would block a
    legitimate registration.
    """
    from echolib.model_capabilities import max_output_for

    cap = max_output_for(
        provider, model=model, deployment_name=deployment_name, declared=None
    )
    if cap is None or requested <= cap:
        return

    named = (deployment_name or model or "this model").strip()
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=(
            f"Max Output Tokens of {requested:,} is more than '{named}' can "
            f"produce. Its limit is {cap:,} tokens per response. Enter "
            f"{cap:,} or less, or choose a model with a larger output limit."
        ),
    )


def _tuning_metadata(meta: Dict[str, Any]) -> Dict[str, Any]:
    """
    Read the optional tuning fields out of a credential's ``config_metadata``.

    Returns the keys the frontend renders, every one of them nullable.
    A credential registered before these fields existed yields all ``None``
    and ``enabled=True``, which is exactly its pre-existing behaviour.

    ``model_family`` is reported as the raw stored choice, defaulting to
    ``auto``. The *resolved* family is deliberately not computed here: the
    detection lives in ``model_capabilities`` and is applied at build time
    against the model and deployment names, and publishing a second answer from
    a second place is how the two would drift apart.
    """
    return {
        "context_window": _coerce_positive_int(meta.get("context_window")),
        "max_output_tokens": _coerce_positive_int(meta.get("max_output_tokens")),
        "temperature": _coerce_temperature(meta.get("temperature")),
        "model_family": _clean_text(meta.get("model_family")) or FAMILY_AUTO,
        "reasoning_effort": normalize_reasoning_effort(meta.get("reasoning_effort")),
        # Absent means enabled. Only an explicit false disables.
        "enabled": meta.get("enabled") is not False,
    }


# ==================== ENDPOINTS ====================

@router.get("/")
def root():
    """Root endpoint - API information."""
    return {
        "name": "LLM Factory API",
        "version": "2.0.0",
        "status": "running",
        "core_methods": ["invoke", "chat", "stream", "json_mode", "function_call", "embed"],
        "architecture": "routes \u2192 LLMService \u2192 LLMFactory"
    }


@router.get("/health")
def health_check():
    """Health check endpoint."""
    try:
        return {
            "status": "healthy",
            "service": "llm-factory",
            "factory_initialized": llm_service
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }


# ==================== MODEL MANAGEMENT ====================

@router.get("/models/list")
async def get_models(
    user: UserContext = Depends(get_current_user),
):
    """
    Get list of user-scoped models from the database.

    Also includes system-level credentials (owned by the platform system
    user) so every user sees pre-configured LLMs without manual setup.

    Also includes the provider catalog from ``llm_provider.json`` so the
    frontend can render credential creation forms.
    """
    try:
        user_id = resolve_user_id(user)
        user_uuid = UUID(user_id)

        # System user UUID — credentials owned by this user are platform-
        # wide and visible (read-only) to every authenticated user.
        # One definition, shared with the resolver and the knowledge picker;
        # this used to be a second copy of the literal.
        from echolib.credential_resolver import SYSTEM_USER_ID

        _SYSTEM_USER_UUID = UUID(SYSTEM_USER_ID)

        models: List[Dict[str, Any]] = []
        async with get_db_session() as db:
            from sqlalchemy import or_, case

            stmt = (
                select(UserLlmCredential)
                .where(
                    or_(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.user_id == _SYSTEM_USER_UUID,
                    ),
                    UserLlmCredential.is_deleted.is_(False),
                )
                .order_by(
                    # System credentials first, then user's own
                    case(
                        (UserLlmCredential.user_id == _SYSTEM_USER_UUID, 0),
                        else_=1,
                    ),
                    UserLlmCredential.created_at.asc(),
                )
            )
            result = await db.execute(stmt)
            rows = result.scalars().all()

            # for row in rows:
            #     meta = row.config_metadata or {}
            #     is_system = row.user_id == _SYSTEM_USER_UUID
            #     models.append({
            #         "id": meta.get("model_id", ""),
            #         "name": row.credential_name,
            #         "provider": row.provider,
            #         "is_default": row.is_default,
            #         "credential_id": str(row.credential_id),
            #         "description": _clean_text(meta.get("description")),
            #         "icon": _clean_text(meta.get("icon")) or "default",
            #         "is_system": is_system,
            #         # Include all editable metadata so the edit modal can prefill
            #         "base_url": meta.get("base_url", ""),
            #         "model_name": meta.get("model_name", ""),
            #         "api_version": meta.get("api_version", ""),
            #         "deployment_name": meta.get("deployment_name", ""),
            #         # Whether a key is stored, never the key itself. Without
            #         # this the edit form cannot tell "no key" apart from "key
            #         # withheld", so a blank field reads as lost data.
            #         "api_key_set": _credential_has_api_key(row),
            #         # Optional tuning metadata — null when never stated.
            #         **_tuning_metadata(meta),
            #     })

            for row in rows:
                meta = row.config_metadata or {}
                is_system = row.user_id == _SYSTEM_USER_UUID
                canonical_model_id = meta.get("model_id", "") or str(row.credential_id)
                models.append({
                    # "id": meta.get("model_id", ""),
                    "id": canonical_model_id,
                    "model_id": canonical_model_id,
                    "canonical_model_id": canonical_model_id,
                    "catalog_type": "credential",
                    "name": row.credential_name,
                    "provider": row.provider,
                    "is_default": row.is_default,
                    "is_default_embedding": row.is_default_embedding,
                    "is_embedding": is_embedding_credential(meta, row.credential_name),
                    "credential_id": str(row.credential_id),
                    "description": _clean_text(meta.get("description")),
                    "icon": _clean_text(meta.get("icon")) or "default",
                    "is_system": is_system,
                    # Include all editable metadata so the edit modal can prefill
                    "base_url": meta.get("base_url", ""),
                    "model_name": meta.get("model_name", ""),
                    "api_version": meta.get("api_version", ""),
                    "deployment_name": meta.get("deployment_name", ""),
                    # Whether a key is stored, never the key itself. Without
                    # this the edit form cannot tell "no key" apart from "key
                    # withheld", so a blank field reads as lost data.
                    "api_key_set": _credential_has_api_key(row),
                    # Optional tuning metadata — null when never stated.
                    **_tuning_metadata(meta),
                })

        response: Dict[str, Any] = {"models": models}

        # Include provider-grouped catalog from llm_provider.json
        providers = llm_service.get_provider_catalog()
        if providers:
            response["providers"] = providers

        return response
    except Exception as e:
        logger.error(f"Error getting models: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to load models",
        )


@router.get("/providers/catalog")
def get_provider_catalog():
    """
    Return the provider template catalog from llm_provider.json.

    Used by the frontend Settings page to render credential creation forms
    with the correct required fields per provider.
    """
    try:
        return {"providers": llm_service.get_provider_catalog()}
    except Exception as e:
        logger.error(f"Error getting provider catalog: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to load provider catalog"
        )


@router.get("/models")
def get_model_info(model_id: str):
    """Get information about a specific model."""
    try:
        model = llm_service.get_model(model_id)
        return {
            "id": model.get_model_id(),
            "provider": model.get_provider(),
            "config": model.get_config()
        }
    except ModelNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/add-custom-model")
async def add_custom_model(
    request: CustomModelRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    try:
        # Auto-generate model_id from provider/model_name when not provided
        effective_model_id = (request.model_id or "").strip()
        if not effective_model_id:
            effective_model_id = f"{request.provider}/{request.model_name}"

        # Default icon if not provided
        icon_value = _clean_text(request.icon) or "default"

        # Generate credential_id upfront so we can derive the KV secret name
        credential_id_val = uuid4()
        credential_id_str = str(credential_id_val)
        kv_secret_name = f"user-cred-{credential_id_str}"

        raw_api_key = request.api_key or ""

        # Persist to DB + Key Vault (DB is the sole source of truth)
        user_id = resolve_user_id(user)
        user_uuid = UUID(user_id)

        # Store API key in Key Vault -- prefer KV, fall back to DB column
        # when KV is unavailable so the operation is not blocked.
        api_key_stored_in_kv = False
        api_key_in_db = False
        if raw_api_key:
            try:
                _store_api_key(credential_id_str, raw_api_key)
                api_key_stored_in_kv = True
            except Exception as kv_err:
                logger.warning(
                    "Key Vault unavailable for custom model %s — "
                    "storing API key in DB column as fallback. KV error: %s",
                    effective_model_id, kv_err,
                )
                api_key_in_db = True

        # Build metadata JSONB -- NEVER include the raw API key
        metadata: Dict[str, Any] = {
            "base_url": request.base_url,
            "model_id": effective_model_id,
            "model_name": request.model_name,
            "icon": icon_value,
            "description": _clean_text(request.description),
            "api_key_ref": kv_secret_name,
        }
        if request.api_version:
            metadata["api_version"] = request.api_version
        if request.deployment_name:
            metadata["deployment_name"] = request.deployment_name

        # Optional tuning fields. Written only when the user stated one, so a
        # model registered without them carries no key at all and resolves
        # exactly as it did before these fields existed.
        if request.context_window is not None:
            metadata["context_window"] = request.context_window
        if request.max_output_tokens is not None:
            _reject_impossible_output_ceiling(
                request.max_output_tokens,
                provider=request.provider,
                model=request.model_name,
                deployment_name=request.deployment_name,
            )
            metadata["max_output_tokens"] = request.max_output_tokens
        if request.temperature is not None:
            metadata["temperature"] = request.temperature
        # ``auto`` is the absence of a choice, so it is not stored. That keeps a
        # model registered through this endpoint indistinguishable from one
        # registered before the field existed, and both resolve by detection.
        if normalize_model_family(request.model_family) is not None:
            metadata["model_family"] = request.model_family
        if request.reasoning_effort is not None:
            metadata["reasoning_effort"] = request.reasoning_effort
        if request.enabled is not None:
            metadata["enabled"] = bool(request.enabled)
        if request.is_embedding is not None:
            metadata["is_embedding"] = bool(request.is_embedding)
        budget = {}

        if request.daily_limit is not None:
            budget["daily_limit"] = request.daily_limit

        if request.monthly_limit is not None:
            budget["monthly_limit"] = request.monthly_limit

        if budget:
            metadata["budget"] = budget

        try:
            async with get_db_session() as db:
                # Reject a duplicate model_id up front. Two rows sharing one
                # model_id make Tier 1b resolution ambiguous, and the caller
                # can act on a 409 where they cannot act on a later failure.
                duplicate = await db.execute(
                    select(UserLlmCredential.credential_id).where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.config_metadata["model_id"].astext == effective_model_id,
                        UserLlmCredential.is_deleted.is_(False),
                    ).limit(1)
                )
                if duplicate.first() is not None:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"A model with the identifier '{effective_model_id}' is already "
                            "registered. Choose a different model name, or edit the existing entry."
                        ),
                    )

                # Determine auto-default. The first model a user registers
                # becomes their default; after that it must be asked for.
                count_result = await db.execute(
                    select(UserLlmCredential.credential_id).where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_deleted.is_(False),
                    )
                )
                is_first = count_result.first() is None
                should_be_default = is_first or bool(request.is_default)

                # The embedding default is independent of the chat default: no
                # auto-promotion on "first model", and only an embedding-capable
                # credential may hold it.
                should_be_default_embedding = bool(request.is_default_embedding)
                if should_be_default_embedding and not is_embedding_credential(
                    metadata, request.name
                ):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=(
                            "Only an embedding-capable model can be set as the "
                            "default embedding model. Mark 'is_embedding' first."
                        ),
                    )

                # Clear existing default if needed
                if should_be_default and not is_first:
                    await db.execute(
                        update(UserLlmCredential)
                        .where(
                            UserLlmCredential.user_id == user_uuid,
                            UserLlmCredential.is_default.is_(True),
                            UserLlmCredential.is_deleted.is_(False),
                        )
                        .values(is_default=False)
                    )

                if should_be_default_embedding:
                    await db.execute(
                        update(UserLlmCredential)
                        .where(
                            UserLlmCredential.user_id == user_uuid,
                            UserLlmCredential.is_default_embedding.is_(True),
                            UserLlmCredential.is_deleted.is_(False),
                        )
                        .values(is_default_embedding=False)
                    )

                row = UserLlmCredential(
                    credential_id=credential_id_val,
                    user_id=user_uuid,
                    credential_name=request.name,
                    provider=request.provider,
                    is_default=should_be_default,
                    is_default_embedding=should_be_default_embedding,
                    config_metadata=metadata,
                    # Encrypted, never raw. The column is read back by
                    # ``read_credential_api_key``, which decrypts it.
                    encrypted_api_key=encrypt_api_key(raw_api_key) if api_key_in_db else None,
                    api_key_storage="db" if api_key_in_db else ("kv" if api_key_stored_in_kv else None),
                )
                db.add(row)
                # Session auto-commits on context-manager exit

            logger.info(
                "Persisted custom model %s to DB (credential_id=%s, user=%s, storage=%s)",
                effective_model_id, credential_id_str, user_id,
                "db" if api_key_in_db else "kv",
            )
        except HTTPException:
            # A deliberate rejection (duplicate model_id). Still clean up the
            # KV secret written moments ago, or it is orphaned forever.
            if api_key_stored_in_kv:
                _delete_api_key(credential_id_str)
            raise
        except IntegrityError as dup_err:
            # ``uq_user_credential_name`` — a display name already in use, or
            # ``idx_user_creds_one_default`` losing a race. Both are the
            # caller's to resolve, so neither is a 500.
            if api_key_stored_in_kv:
                _delete_api_key(credential_id_str)
            logger.info(
                "Rejected duplicate custom model for user %s: %s", user_id, dup_err,
            )
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"A model named '{request.name}' already exists. "
                    "Choose a different name."
                ),
            )
        except Exception as db_err:
            # DB insert failed -- clean up orphaned KV secret
            if api_key_stored_in_kv:
                _delete_api_key(credential_id_str)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to persist custom model: {db_err}",
            )

        return {
            "success": True,
            "message": f"Model '{request.name}' registered successfully",
            "model_id": effective_model_id,
            # Returned so the caller can immediately test the connection or
            # promote the model without re-listing every credential.
            "credential_id": credential_id_str,
            "is_default": should_be_default,
            "is_default_embedding": should_be_default_embedding,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding custom model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.delete("/models")
async def remove_custom_model(
    model_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Remove a custom model (DB is the sole source of truth)."""
    try:
        user_id = resolve_user_id(user)
        user_uuid = UUID(user_id)
        credential_id_to_delete_from_kv: str | None = None

        async with get_db_session() as db:
            # Find the credential row by metadata->>'model_id'
            stmt = (
                select(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.config_metadata["model_id"].astext == model_id,
                    UserLlmCredential.is_deleted.is_(False),
                )
                .limit(1)
            )
            row_result = await db.execute(stmt)
            row = row_result.scalar_one_or_none()

            if row is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Custom model '{model_id}' not found",
                )

            was_default = row.is_default
            was_default_embedding = row.is_default_embedding
            credential_id_to_delete_from_kv = str(row.credential_id)

            # Hard-delete the row
            await db.delete(row)

            # Auto-promote next oldest credential if this was default
            if was_default:
                next_stmt = (
                    select(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .order_by(UserLlmCredential.created_at.asc())
                    .limit(1)
                )
                next_result = await db.execute(next_stmt)
                next_default = next_result.scalar_one_or_none()
                if next_default is not None:
                    next_default.is_default = True
                    logger.info(
                        "Auto-promoted credential %s as new default for user %s",
                        next_default.credential_id, user_id,
                    )

            # Same promotion, scoped to embedding-capable credentials only, so
            # deleting the embedding default never lands on a chat model.
            if was_default_embedding:
                candidates_stmt = (
                    select(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .order_by(UserLlmCredential.created_at.asc())
                )
                candidates_result = await db.execute(candidates_stmt)
                next_embedding_default = next(
                    (
                        c for c in candidates_result.scalars().all()
                        if is_embedding_credential(c.config_metadata, c.credential_name or "")
                    ),
                    None,
                )
                if next_embedding_default is not None:
                    next_embedding_default.is_default_embedding = True
                    logger.info(
                        "Auto-promoted credential %s as new default embedding model for user %s",
                        next_embedding_default.credential_id, user_id,
                    )

            # Session auto-commits on exit

        logger.info(
            "Deleted custom model %s from DB (credential_id=%s, user=%s)",
            model_id, credential_id_to_delete_from_kv, user_id,
        )

        # Delete KV secret OUTSIDE the DB session to avoid blocking the transaction
        if credential_id_to_delete_from_kv:
            try:
                _delete_api_key(credential_id_to_delete_from_kv)
            except Exception as kv_err:
                logger.warning(
                    "KV cleanup failed for custom model %s: %s",
                    model_id, kv_err,
                )

        return {
            "success": True,
            "message": f"Model '{model_id}' removed successfully",
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )


# ==================== UPDATE CUSTOM MODEL ====================

@router.put("/update-model/{model_id:path}")
async def update_custom_model(
    model_id: str,
    request: CustomModelUpdateRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Update an existing custom model.

    Updates the ``user_llm_credentials`` DB row directly (DB is the sole
    source of truth).
    """
    try:
        user_id = resolve_user_id(user)
        user_uuid = UUID(user_id)

        async with get_db_session() as db:
            stmt = (
                select(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.config_metadata["model_id"].astext == model_id,
                    UserLlmCredential.is_deleted.is_(False),
                )
                .limit(1)
            )
            row_result = await db.execute(stmt)
            row = row_result.scalar_one_or_none()

            if row is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Custom model '{model_id}' not found",
                )

            # Update scalar columns
            if request.name is not None:
                row.credential_name = request.name
            if request.provider is not None:
                row.provider = request.provider

            # Update metadata fields — skip empty strings to prevent
            # edit-form clobbering when the frontend omits unchanged fields.
            metadata = dict(row.config_metadata or {})
            if request.base_url is not None and request.base_url != "":
                metadata["base_url"] = request.base_url
            if request.model_name is not None and request.model_name != "":
                metadata["model_name"] = request.model_name
            if request.description is not None:
                metadata["description"] = request.description
            if request.icon is not None and request.icon != "":
                metadata["icon"] = request.icon
            if request.api_version is not None and request.api_version != "":
                metadata["api_version"] = request.api_version
            if request.deployment_name is not None and request.deployment_name != "":
                metadata["deployment_name"] = request.deployment_name
            budget = metadata.get("budget", {})

            if request.daily_limit is not None:
                budget["daily_limit"] = request.daily_limit

            if request.monthly_limit is not None:
                budget["monthly_limit"] = request.monthly_limit

            if budget:
                metadata["budget"] = budget

            # Optional tuning fields. These need a three-way distinction the
            # empty-string guard above cannot express: not sent (leave alone),
            # sent with a value (store), sent as null (clear). ``model_fields_set``
            # is what separates "omitted" from "explicitly null", so a user can
            # remove a context window they no longer want stated.
            sent = request.model_fields_set
            if "max_output_tokens" in sent and request.max_output_tokens is not None:
                # Validated against the model this edit leaves the row on, not
                # the one it arrived with: a request that changes both the model
                # and the ceiling has to be judged on the pair.
                _reject_impossible_output_ceiling(
                    request.max_output_tokens,
                    provider=request.provider or row.provider,
                    model=request.model_name or metadata.get("model_name"),
                    deployment_name=(
                        request.deployment_name or metadata.get("deployment_name")
                    ),
                )

            for key, value in (
                ("context_window", request.context_window),
                ("max_output_tokens", request.max_output_tokens),
                ("temperature", request.temperature),
                ("reasoning_effort", request.reasoning_effort),
            ):
                if key not in sent:
                    continue
                if value is None:
                    metadata.pop(key, None)
                else:
                    metadata[key] = value

            # ``model_family`` has a third meaning the loop above cannot carry:
            # ``auto`` is a real user choice that must *remove* a previously
            # stored override and return the model to detection.
            if "model_family" in sent:
                if normalize_model_family(request.model_family) is None:
                    metadata.pop("model_family", None)
                else:
                    metadata["model_family"] = request.model_family

            if "enabled" in sent:
                if request.enabled is None:
                    metadata.pop("enabled", None)
                else:
                    metadata["enabled"] = bool(request.enabled)

            if "is_embedding" in sent:
                if request.is_embedding is None:
                    metadata.pop("is_embedding", None)
                else:
                    metadata["is_embedding"] = bool(request.is_embedding)

            # Handle API key update -- store in KV, fall back to DB column
            if request.api_key:
                cred_id_str = str(row.credential_id)
                try:
                    _store_api_key(cred_id_str, request.api_key)
                    metadata["api_key_ref"] = f"user-cred-{cred_id_str}"
                    row.encrypted_api_key = None
                    row.api_key_storage = "kv"
                except Exception as kv_err:
                    logger.warning(
                        "Key Vault unavailable for model %s — "
                        "storing API key in DB column as fallback. KV error: %s",
                        model_id, kv_err,
                    )
                    metadata["api_key_ref"] = f"user-cred-{cred_id_str}"
                    row.encrypted_api_key = encrypt_api_key(request.api_key)
                    row.api_key_storage = "db"

            # Remove legacy raw key field if present
            metadata.pop("api_key_env", None)

            row.config_metadata = metadata

            # Promotion to default. Demote-then-promote runs inside this same
            # transaction so the partial unique index ``idx_user_creds_one_default``
            # never sees two active defaults. Demotion on its own is refused:
            # clearing the flag here would leave the user with no default at
            # all, and ``_try_user_credential`` has nothing to fall back to.
            if request.is_default is True and not row.is_default:
                await db.execute(
                    update(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_default.is_(True),
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .values(is_default=False)
                )
                row.is_default = True
                is_default_after = True
            else:
                is_default_after = row.is_default

            # Independent of the block above: this is a different flag with
            # its own partial unique index, so promoting or leaving it alone
            # never touches the chat default and vice versa.
            if request.is_default_embedding is True and not row.is_default_embedding:
                if not is_embedding_credential(metadata, row.credential_name or ""):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=(
                            "Only an embedding-capable model can be set as the "
                            "default embedding model. Mark 'is_embedding' first."
                        ),
                    )
                await db.execute(
                    update(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_default_embedding.is_(True),
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .values(is_default_embedding=False)
                )
                row.is_default_embedding = True
                is_default_embedding_after = True
            else:
                is_default_embedding_after = row.is_default_embedding
            # Session auto-commits on exit

        logger.info("Updated custom model %s in DB for user %s", model_id, user_id)

        return {
            "success": True,
            "message": f"Model '{model_id}' updated successfully",
            "model_id": model_id,
            "is_default": is_default_after,
            "is_default_embedding": is_default_embedding_after,
        }

    except HTTPException:
        raise
    except IntegrityError as dup_err:
        # ``uq_user_credential_name`` on a renamed model, or a race on the
        # default index. Both are the caller's to resolve.
        logger.info("Rejected conflicting update to model %s: %s", model_id, dup_err)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "That change conflicts with an existing model — most likely the "
                "display name is already in use. Choose a different name."
            ),
        )
    except Exception as e:
        logger.error(f"Error updating custom model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )


# ==================== METHOD 1: INVOKE ====================

@router.post("/invoke")
def invoke(request: InvokeRequest):
    """
    Simple text generation - single turn.

    Example:
        POST /api/llms/invoke
        {
            "model_id": "claude-opus-4",
            "prompt": "What is Python?",
            "temperature": 0.7
        }
    """
    try:
        model = llm_service.get_model(
            request.model_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )

        response = model.invoke(request.prompt)

        return {
            "response": response,
            "model": request.model_id,
            "method": "invoke"
        }

    except ModelNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except MissingAPIKeyError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="API key not configured"
        )
    except LLMExecutionError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== METHOD 2: CHAT ====================

@router.post("/chat")
def chat(request: ChatRequest):
    """
    Conversation with history - multi-turn.

    Example:
        POST /api/llms/chat
        {
            "model_id": "claude-opus-4",
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi!"},
                {"role": "user", "content": "How are you?"}
            ]
        }
    """
    try:
        model = llm_service.get_model(
            request.model_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )

        response = model.chat(request.messages)

        return {
            "response": response,
            "model": request.model_id,
            "method": "chat"
        }

    except (ModelNotFoundError, MissingAPIKeyError, LLMExecutionError) as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== METHOD 3: STREAM ====================

@router.post("/stream")
def stream(request: StreamRequest):
    """
    Streaming text generation - real-time chunks.

    Returns Server-Sent Events (SSE).
    """
    try:
        model = llm_service.get_model(
            request.model_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )

        def generate():
            try:
                for chunk in model.stream(request.prompt):
                    yield f"data: {json.dumps({'chunk': chunk, 'done': False})}\n\n"

                # Final message
                yield f"data: {json.dumps({'chunk': '', 'done': True})}\n\n"

            except Exception as e:
                yield f"data: {json.dumps({'error': str(e), 'done': True})}\n\n"

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
            }
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== METHOD 4: JSON MODE ====================

@router.post("/json-mode")
def json_mode(request: JsonModeRequest):
    """
    Structured JSON output - guaranteed valid JSON.

    Example:
        POST /api/llms/json-mode
        {
            "model_id": "claude-opus-4",
            "prompt": "Extract person info: John is 25 years old",
            "schema": {"name": "string", "age": "integer"}
        }
    """
    try:
        model = llm_service.get_model(
            request.model_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )

        response = model.json_mode(request.prompt, schema=request.schema)

        return {
            "result": response,
            "model": request.model_id,
            "method": "json_mode"
        }

    except (ModelNotFoundError, MissingAPIKeyError, LLMExecutionError) as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== METHOD 5: FUNCTION CALL ====================

@router.post("/function-call")
def function_call(request: FunctionCallRequest):
    """
    Native function/tool calling.

    Example:
        POST /api/llms/function-call
        {
            "model_id": "claude-opus-4",
            "tools": [
                {
                    "name": "search_database",
                    "description": "Search company database",
                    "parameters": {
                        "query": {"type": "string"}
                    }
                }
            ],
            "prompt": "Find sales data for Q4"
        }
    """
    try:
        model = llm_service.get_model(
            request.model_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )

        response = model.function_call(request.tools, request.prompt)

        return {
            "result": response,
            "model": request.model_id,
            "method": "function_call"
        }

    except (ModelNotFoundError, MissingAPIKeyError, LLMExecutionError) as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== METHOD 6: EMBED ====================

@router.post("/embed")
def embed(request: EmbedRequest):
    """
    Generate text embeddings - vector representations.

    Example:
        POST /api/llms/embed
        {
            "model_id": "claude-opus-4",
            "text": "Hello world"
        }

        Or for multiple texts:
        {
            "model_id": "claude-opus-4",
            "text": ["Hello", "World"]
        }
    """
    try:
        model = llm_service.get_model(request.model_id)

        embeddings = model.embed(request.text)

        return {
            "embeddings": embeddings,
            "model": request.model_id,
            "method": "embed",
            "dimensions": len(embeddings) if isinstance(request.text, str) else len(embeddings[0])
        }

    except EmbeddingError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
    except (ModelNotFoundError, MissingAPIKeyError) as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==================== UTILITY ENDPOINTS ====================

@router.post("/refresh-config")
def refresh_config():
    """Reload configuration from file."""
    try:
        llm_service.refresh_configuration()
        return {"message": "Configuration refreshed successfully"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/providers")
def get_providers():
    """Get list of available providers."""
    try:
        providers = llm_service.get_providers()
        return {"providers": providers}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ======================================================================
# CREDENTIAL CRUD — Per-User LLM Credential Management
# ======================================================================
# Endpoints below manage user-level LLM credentials.  API keys are stored
# in Azure Key Vault (secret name: ``user-cred-{credential_id}``); only
# non-secret metadata is persisted in PostgreSQL.
# ======================================================================


# ======================================================================
# Credential Helpers
# ======================================================================

def _cred_row_to_response(row: UserLlmCredential, api_key_set: bool) -> CredentialResponse:
    """Convert a DB row to a masked response."""
    metadata = row.config_metadata or {}
    return CredentialResponse(
        credential_id=str(row.credential_id),
        credential_name=row.credential_name,
        provider=row.provider,
        is_default=row.is_default,
        is_default_embedding=row.is_default_embedding,
        api_key_set=api_key_set,
        base_url=metadata.get("base_url"),
        api_version=metadata.get("api_version"),
        deployment_name=metadata.get("deployment_name"),
        workbench_provider=metadata.get("workbench_provider"),
        charge_code=metadata.get("charge_code"),
        region_override=metadata.get("region_override"),
        azureml_model_deployment=metadata.get("azureml_model_deployment"),
        created_at=row.created_at.isoformat() if row.created_at else None,
        updated_at=row.updated_at.isoformat() if row.updated_at else None,
    )


def _has_api_key_in_kv(credential_id: str) -> bool:
    """Deprecated shim: prefer ``_credential_has_api_key(row)``.

    This asked Key Vault directly, which answered ``False`` for a credential
    whose key lives in the DB fallback column and for every credential
    whenever the vault could not be authenticated to — reporting "no API key"
    during a platform outage. Callers that hold the row should use
    ``_credential_has_api_key``, which reads the row's own record of where the
    key was stored and makes no network call.

    Retained because it is reachable without a row in hand. Kept permissive:
    an unreachable vault must not be reported as an absent key.
    """
    if not secrets.is_keyvault_enabled:
        return True

    kv_key = f"user-cred-{credential_id}"
    try:
        return secrets.get_secret(kv_key) is not None
    except Exception:
        # Vault unreachable. Absence of proof is not proof of absence.
        logger.debug(
            "Could not confirm Key Vault state for credential %s; "
            "assuming a key is present.", credential_id,
        )
        return True


def _store_api_key(credential_id: str, api_key: str) -> None:
    """Persist the API key in Key Vault.

    Raises on any failure so callers can gate DB persistence on KV success.
    """
    kv_key = f"user-cred-{credential_id}"
    payload = json.dumps({"api_key": api_key})

    client = secrets._get_write_client()
    if client is None:
        raise RuntimeError(
            f"Key Vault write client unavailable; credential {credential_id} "
            "api_key cannot be persisted. Check AZURE_KEY_VAULT_ENABLED and "
            "identity configuration."
        )

    try:
        client.set_secret(kv_key, payload)
        logger.info("Stored api_key in KV for credential %s (key=%s)", credential_id, kv_key)
    except Exception as e:
        logger.error("Failed to store api_key in KV for credential %s: %s", credential_id, e)
        raise


def _delete_api_key(credential_id: str) -> None:
    """Delete the API key from Key Vault."""
    kv_key = f"user-cred-{credential_id}"

    client = secrets._get_write_client()
    if client is None:
        return

    try:
        client.begin_delete_secret(kv_key)
        logger.info("Deleted api_key from KV for credential %s (key=%s)", credential_id, kv_key)
    except Exception as e:
        logger.warning("Failed to delete api_key from KV for credential %s: %s", credential_id, e)


def _load_provider_catalog() -> List[Dict[str, Any]]:
    """Read the llm_provider.json file and return the providers list."""
    try:
        with open(_LLM_PROVIDER_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("providers", [])
    except FileNotFoundError:
        logger.error("llm_provider.json not found at %s", _LLM_PROVIDER_JSON)
        return []
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON in llm_provider.json: %s", e)
        return []


def _known_models_for_provider(provider: str) -> List[str]:
    """Return known_models from llm_provider.json for a given provider slug."""
    catalog = _load_provider_catalog()
    for entry in catalog:
        if entry.get("id") == provider:
            return entry.get("known_models", [])
    return []


async def _get_user_credential(
    db: AsyncSession,
    credential_id: str,
    user_id: str,
) -> UserLlmCredential:
    """Fetch a credential by ID, verifying ownership. Raises 404 on miss."""
    try:
        cred_uuid = UUID(credential_id)
        user_uuid = UUID(user_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid credential_id or user_id format.")

    stmt = select(UserLlmCredential).where(
        UserLlmCredential.credential_id == cred_uuid,
        UserLlmCredential.user_id == user_uuid,
        UserLlmCredential.is_deleted.is_(False),
    )
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="Credential not found.")
    return row


# ======================================================================
# POST /LLMs/credentials — Create new credential
# ======================================================================

@router.post("/credentials", status_code=201, response_model=CredentialResponse)
async def create_credential(
    payload: CredentialCreateRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Create a new LLM credential.

    Stores non-secret metadata in PostgreSQL and the API key in Key Vault.
    If this is the user's first credential, it is automatically set as
    the global default.
    """
    user_id = resolve_user_id(user)
    user_uuid = UUID(user_id)

    # Pre-generate credential_id so we can store KV before DB insert
    credential_id_val = uuid4()
    credential_id_str = str(credential_id_val)

    # Validate name uniqueness before any side effects
    async with get_db_session() as db:
        existing = await db.execute(
            select(UserLlmCredential).where(
                UserLlmCredential.user_id == user_uuid,
                UserLlmCredential.credential_name == payload.credential_name,
                UserLlmCredential.is_deleted.is_(False),
            )
        )
        if existing.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=409,
                detail=f"Credential name '{payload.credential_name}' already exists.",
            )

    # Step 1: Store API key in Key Vault FIRST (before DB row exists)
    api_key_stored_in_kv = False
    api_key_in_db = False
    if payload.api_key:
        try:
            _store_api_key(credential_id_str, payload.api_key)
            api_key_stored_in_kv = True
        except Exception as kv_err:
            logger.warning(
                "Key Vault unavailable for credential %s — "
                "storing API key in DB column as fallback. KV error: %s",
                credential_id_str, kv_err,
            )
            api_key_in_db = True

    # Step 2: Create DB row. If this fails, clean up the KV secret.
    try:
        async with get_db_session() as db:
            # Determine if this should auto-become default
            count_result = await db.execute(
                select(UserLlmCredential.credential_id).where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.is_deleted.is_(False),
                )
            )
            is_first = count_result.first() is None
            should_be_default = is_first or (payload.is_default is True)

            # If setting as default, clear existing default
            if should_be_default and not is_first:
                await db.execute(
                    update(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_default.is_(True),
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .values(is_default=False)
                )

            # Build metadata JSONB
            metadata: Dict[str, str] = {}
            if payload.base_url:
                metadata["base_url"] = payload.base_url
            if payload.api_version:
                metadata["api_version"] = payload.api_version
            if payload.deployment_name:
                metadata["deployment_name"] = payload.deployment_name
            if payload.workbench_provider:
                metadata["workbench_provider"] = payload.workbench_provider
            if payload.charge_code:
                metadata["charge_code"] = payload.charge_code
            if payload.region_override:
                metadata["region_override"] = payload.region_override
            if payload.azureml_model_deployment:
                metadata["azureml_model_deployment"] = payload.azureml_model_deployment
            if payload.is_embedding is not None:
                metadata["is_embedding"] = bool(payload.is_embedding)

            # The embedding default is independent of the chat default: no
            # auto-promotion on "first credential", and only an
            # embedding-capable credential may hold it.
            should_be_default_embedding = bool(payload.is_default_embedding)
            if should_be_default_embedding and not is_embedding_credential(
                metadata, payload.credential_name
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        "Only an embedding-capable model can be set as the "
                        "default embedding model. Set 'is_embedding' first."
                    ),
                )
            if should_be_default_embedding:
                await db.execute(
                    update(UserLlmCredential)
                    .where(
                        UserLlmCredential.user_id == user_uuid,
                        UserLlmCredential.is_default_embedding.is_(True),
                        UserLlmCredential.is_deleted.is_(False),
                    )
                    .values(is_default_embedding=False)
                )

            row = UserLlmCredential(
                credential_id=credential_id_val,
                user_id=user_uuid,
                credential_name=payload.credential_name,
                provider=payload.provider,
                is_default=should_be_default,
                is_default_embedding=should_be_default_embedding,
                config_metadata=metadata,
                encrypted_api_key=encrypt_api_key(payload.api_key) if api_key_in_db else None,
                api_key_storage="db" if api_key_in_db else ("kv" if api_key_stored_in_kv else None),
            )
            db.add(row)
            # Session auto-commits on context-manager exit
    except Exception:
        # DB insert failed -- clean up the orphaned KV secret
        if api_key_stored_in_kv:
            _delete_api_key(credential_id_str)
        raise

    # Re-fetch the committed row for the response
    async with get_db_session() as db:
        stmt = select(UserLlmCredential).where(
            UserLlmCredential.credential_id == credential_id_val
        )
        result = await db.execute(stmt)
        saved_row = result.scalar_one()

    logger.info(
        "Created credential %s for user %s (provider=%s, default=%s)",
        credential_id_str,
        user_id,
        payload.provider,
        should_be_default,
    )

    return _cred_row_to_response(saved_row, api_key_set=api_key_stored_in_kv or api_key_in_db)


# ======================================================================
# GET /LLMs/credentials — List user's credentials
# ======================================================================

@router.get("/credentials", response_model=List[CredentialResponse])
async def list_credentials(
    user: UserContext = Depends(require_admin_or_above),
):
    """List all active credentials for the authenticated user (api_key masked)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        stmt = (
            select(UserLlmCredential)
            .where(
                UserLlmCredential.user_id == UUID(user_id),
                UserLlmCredential.is_deleted.is_(False),
            )
            .order_by(UserLlmCredential.created_at.asc())
        )
        result = await db.execute(stmt)
        rows = result.scalars().all()

    return [
        _cred_row_to_response(row, api_key_set=_credential_has_api_key(row))
        for row in rows
    ]


# ======================================================================
# GET /LLMs/credentials/llm/available — Credentials + known models
# ======================================================================

@router.get("/credentials/llm/available", response_model=List[AvailableCredentialEntry])
async def list_available_credentials(
    user: UserContext = Depends(require_user),
):
    """
    Return the user's credentials merged with known_models from
    llm_provider.json, suitable for populating model-selection dropdowns.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        stmt = (
            select(UserLlmCredential)
            .where(
                UserLlmCredential.user_id == UUID(user_id),
                UserLlmCredential.is_deleted.is_(False),
            )
            .order_by(UserLlmCredential.created_at.asc())
        )
        result = await db.execute(stmt)
        rows = result.scalars().all()

    entries: List[AvailableCredentialEntry] = []
    for row in rows:
        entries.append(
            AvailableCredentialEntry(
                credential_id=str(row.credential_id),
                credential_name=row.credential_name,
                provider=row.provider,
                is_default=row.is_default,
                known_models=_known_models_for_provider(row.provider),
            )
        )

    return entries


# ======================================================================
# GET /LLMs/credentials/providers/catalog — Provider templates
# ======================================================================

@router.get("/credentials/providers/catalog", response_model=List[ProviderCatalogEntry])
async def get_credential_provider_catalog():
    """
    Return the provider template catalog from llm_provider.json.

    Used by the frontend to render credential creation forms with the
    correct required fields per provider.
    """
    catalog = _load_provider_catalog()
    return [
        ProviderCatalogEntry(
            id=entry.get("id", ""),
            name=entry.get("name", ""),
            requires_fields=entry.get("requires_fields", []),
            known_models=entry.get("known_models", []),
            allow_custom_model=entry.get("allow_custom_model"),
        )
        for entry in catalog
    ]


# ======================================================================
# GET /LLMs/credentials/{credential_id} — Get single credential
# ======================================================================

@router.get("/credentials/{credential_id}", response_model=CredentialResponse)
async def get_credential(
    credential_id: str,
    user: UserContext = Depends(require_user),
):
    """Get a single credential by ID (api_key masked)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        row = await _get_user_credential(db, credential_id, user_id)

    return _cred_row_to_response(row, api_key_set=_credential_has_api_key(row))


# ======================================================================
# PUT /LLMs/credentials/{credential_id} — Update credential
# ======================================================================

@router.put("/credentials/{credential_id}", response_model=CredentialResponse)
async def update_credential(
    credential_id: str,
    payload: CredentialUpdateRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Update an existing credential.

    If a new api_key is provided it is re-stored in Key Vault.
    """
    user_id = resolve_user_id(user)

    # Step 1: Store new API key in KV FIRST (if provided).
    # The KV key name is deterministic (user-cred-{credential_id}), so this
    # is an in-place overwrite.  If the subsequent DB update fails, the KV
    # value is still valid for the existing DB row -- no orphan created.
    api_key_in_db = False
    if payload.api_key:
        try:
            _store_api_key(credential_id, payload.api_key)
        except Exception as kv_err:
            logger.warning(
                "Key Vault unavailable for credential %s — "
                "storing API key in DB column as fallback. KV error: %s",
                credential_id, kv_err,
            )
            api_key_in_db = True

    # Step 2: Update DB row
    async with get_db_session() as db:
        row = await _get_user_credential(db, credential_id, user_id)

        # Update scalar fields
        if payload.credential_name is not None:
            row.credential_name = payload.credential_name
        if payload.provider is not None:
            row.provider = payload.provider

        # Update metadata fields
        metadata = dict(row.config_metadata or {})
        if payload.base_url is not None:
            metadata["base_url"] = payload.base_url
        if payload.api_version is not None:
            metadata["api_version"] = payload.api_version
        if payload.deployment_name is not None:
            metadata["deployment_name"] = payload.deployment_name
        if payload.workbench_provider is not None:
            metadata["workbench_provider"] = payload.workbench_provider
        if payload.charge_code is not None:
            metadata["charge_code"] = payload.charge_code
        if payload.region_override is not None:
            metadata["region_override"] = payload.region_override
        if payload.azureml_model_deployment is not None:
            metadata["azureml_model_deployment"] = payload.azureml_model_deployment
        if payload.is_embedding is not None:
            metadata["is_embedding"] = bool(payload.is_embedding)
        row.config_metadata = metadata

        # DB fallback for API key
        if payload.api_key:
            if api_key_in_db:
                row.encrypted_api_key = encrypt_api_key(payload.api_key)
                row.api_key_storage = "db"
            else:
                row.encrypted_api_key = None
                row.api_key_storage = "kv"

    # Re-fetch for response
    async with get_db_session() as db:
        stmt = select(UserLlmCredential).where(
            UserLlmCredential.credential_id == UUID(credential_id),
            UserLlmCredential.user_id == UUID(user_id),
            UserLlmCredential.is_deleted.is_(False),
        )
        result = await db.execute(stmt)
        updated_row = result.scalar_one()

    logger.info("Updated credential %s for user %s", credential_id, user_id)
    return _cred_row_to_response(updated_row, api_key_set=_credential_has_api_key(updated_row))


# ======================================================================
# DELETE /LLMs/credentials/{credential_id} — Soft-delete credential
# ======================================================================

@router.delete("/credentials/{credential_id}", status_code=204)
async def delete_credential(
    credential_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Soft-delete a credential.

    Marks ``is_deleted=True`` in the DB and deletes the Key Vault secret.
    If the deleted credential was the global default, the next oldest
    active credential is promoted to default.
    """
    user_id = resolve_user_id(user)
    user_uuid = UUID(user_id)

    async with get_db_session() as db:
        row = await _get_user_credential(db, credential_id, user_id)
        was_default = row.is_default
        was_default_embedding = row.is_default_embedding

        row.is_deleted = True
        row.is_default = False
        row.is_default_embedding = False

        # Auto-promote next oldest if this was default
        if was_default:
            stmt = (
                select(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.is_deleted.is_(False),
                    UserLlmCredential.credential_id != UUID(credential_id),
                )
                .order_by(UserLlmCredential.created_at.asc())
                .limit(1)
            )
            result = await db.execute(stmt)
            next_default = result.scalar_one_or_none()
            if next_default is not None:
                next_default.is_default = True
                logger.info(
                    "Auto-promoted credential %s as new default for user %s",
                    next_default.credential_id,
                    user_id,
                )

        # Same promotion, scoped to embedding-capable credentials only, so
        # deleting the embedding default never lands on a chat model.
        if was_default_embedding:
            candidates_stmt = (
                select(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.is_deleted.is_(False),
                    UserLlmCredential.credential_id != UUID(credential_id),
                )
                .order_by(UserLlmCredential.created_at.asc())
            )
            candidates_result = await db.execute(candidates_stmt)
            next_embedding_default = next(
                (
                    c for c in candidates_result.scalars().all()
                    if is_embedding_credential(c.config_metadata, c.credential_name or "")
                ),
                None,
            )
            if next_embedding_default is not None:
                next_embedding_default.is_default_embedding = True
                logger.info(
                    "Auto-promoted credential %s as new default embedding model for user %s",
                    next_embedding_default.credential_id,
                    user_id,
                )

    # Delete KV secret
    _delete_api_key(credential_id)
    logger.info("Soft-deleted credential %s for user %s", credential_id, user_id)


# ======================================================================
# POST /LLMs/credentials/{credential_id}/test — Test credential
# ======================================================================

@router.post("/credentials/{credential_id}/test", response_model=CredentialTestResponse)
async def test_credential(
    credential_id: str,
    body: CredentialTestRequest = CredentialTestRequest(),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Test a stored credential by making a single LLM invocation.

    Builds a client from the stored config through ``build_langchain_llm`` --
    the same constructor the runtime uses -- and invokes it with a short
    prompt. Building it any other way is how this endpoint came to disagree
    with the runtime about GPT-5 parameters and about where the key lives.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        row = await _get_user_credential(db, credential_id, user_id)

    metadata = row.config_metadata or {}
    provider = row.provider

    # Read the key through the same reader the runtime resolver uses, so a
    # credential that works in an agent run cannot be reported as broken here.
    # This endpoint previously looked only in Key Vault, which meant every
    # credential written to the DB fallback -- that is, every credential
    # registered while Key Vault was unreachable -- failed its own test.
    api_key = ""
    if provider != "ollama":
        secret = await read_credential_api_key(row)
        api_key = secret.api_key

        if not api_key:
            # Name the actual cause. Reporting a platform identity failure as
            # a missing API key sends the operator to fix the wrong thing.
            if secret.kv_error:
                return CredentialTestResponse(
                    success=False,
                    error=(
                        "The platform could not read this credential's API key "
                        f"({secret.kv_error}), and no usable stored copy was found. "
                        "This is a platform configuration issue rather than a "
                        "problem with the key itself — contact your administrator."
                    ),
                )
            return CredentialTestResponse(
                success=False,
                error=(
                    "No API key is stored for this model. Edit the model and "
                    "enter the key to continue."
                ),
            )

    try:
    #     from echolib.llm_client_builder_v2 import build_langchain_llm

        # ``deployment_name`` is authoritative for Azure and empty for every
        # other provider, so it can only be a first choice, never the only
        # one — reading it alone made this endpoint fail for openai,
        # anthropic, gemini and ollama, which never carry a deployment.
        test_model_name = (
            metadata.get("deployment_name")
            or metadata.get("model_name")
            or metadata.get("model_id")
            or ""
        )

        if provider == "workbench":
            # The legacy LLMClientBuilder below has no workbench branch.
            from echolib.llm_client_builder_v2 import build_langchain_llm

            llm_client = build_langchain_llm(
                provider="workbench",
                api_key=api_key,
                base_url=metadata.get("base_url", ""),
                model=test_model_name,
                temperature=0.0,
                max_tokens=5000,
                api_version=metadata.get("api_version") or "2024-12-01-preview",
                deployment_name=metadata.get("deployment_name", ""),
                workbench_provider=metadata.get("workbench_provider", "openai"),
                charge_code=metadata.get("charge_code", "0000"),
                region_override=metadata.get("region_override", ""),
                azureml_model_deployment=metadata.get("azureml_model_deployment", ""),
            )
        else:
            from echolib.llm_client_builder_v2 import build_langchain_llm

        # Built through the same constructor the runtime uses. This endpoint
        # used to build through ``LLMClientBuilder``, a second construction of
        # the same credential that hard-coded a temperature, the retired
        # ``max_tokens`` name and ``api_version="2024-02-01"`` — so a GPT-5
        # credential that an agent could run on failed its own test and the
        # user was told their API key was bad. The same divergence was already
        # fixed once for key reading, above.
        build_kwargs: Dict[str, Any] = {
            "provider": provider,
            "api_key": api_key,
            "base_url": metadata.get("base_url", "") or "",
            "model": test_model_name,
            # A test call states no temperature: whatever this model's default
            # is, is what the user is testing. Withheld models never reach the
            # gate at all, and classic ones behave as the provider intends.
            "temperature": None,
            # "max_tokens": _TEST_MAX_TOKENS,
            "max_tokens": 5000,
            "deployment_name": metadata.get("deployment_name", "") or "",
            "model_family": metadata.get("model_family"),
            "reasoning_effort": metadata.get("reasoning_effort"),
        }
        if metadata.get("api_version"):
            build_kwargs["api_version"] = metadata["api_version"]

        llm_client = build_langchain_llm(**build_kwargs)

        # Wrap the synchronous LLM call with a 30-second timeout.
        # asyncio.to_thread offloads the blocking call; wait_for
        # enforces the deadline.
        _LLM_TEST_TIMEOUT_SECONDS = 120
        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(llm_client.invoke, body.prompt),
                timeout=_LLM_TEST_TIMEOUT_SECONDS,
            )
            logger.info("Test response received: %s", response)
        except asyncio.TimeoutError:
            return CredentialTestResponse(
                success=False,
                error=f"LLM call timed out after {_LLM_TEST_TIMEOUT_SECONDS} seconds. "
                      "The provider may be unreachable or overloaded.",
            )

        content = response.content if hasattr(response, "content") else str(response)

        return CredentialTestResponse(success=True, model_response=content)

    except ConnectionError as e:
        logger.warning(
            "Credential test connection error for %s (user %s): %s",
            credential_id, user_id, e,
        )
        return CredentialTestResponse(
            success=False,
            error=f"Connection failed: unable to reach the LLM provider. "
                  f"Please verify the base URL and network connectivity.",
        )
    except PermissionError as e:
        logger.warning(
            "Credential test auth error for %s (user %s): %s",
            credential_id, user_id, e,
        )
        return CredentialTestResponse(
            success=False,
            error="Authentication failed: the API key was rejected by the provider.",
        )
    except Exception as e:
        error_msg = str(e).lower()
        # Detect auth failures that come as generic exceptions
        if any(kw in error_msg for kw in ("401", "unauthorized", "invalid api key", "authentication")):
            return CredentialTestResponse(
                success=False,
                error="Authentication failed: the API key was rejected by the provider.",
            )
        if any(kw in error_msg for kw in ("timeout", "timed out", "deadline")):
            return CredentialTestResponse(
                success=False,
                error="LLM call timed out. The provider may be unreachable or overloaded.",
            )
        if any(kw in error_msg for kw in ("connection", "connect", "unreachable", "dns")):
            return CredentialTestResponse(
                success=False,
                error="Connection failed: unable to reach the LLM provider. "
                      "Please verify the base URL and network connectivity.",
            )
        logger.warning(
            "Credential test failed for %s (user %s): %s",
            credential_id, user_id, e,
        )
        return CredentialTestResponse(success=False, error=str(e))


# ======================================================================
# PATCH /LLMs/credentials/{credential_id}/set-default — Toggle default
# ======================================================================

@router.patch("/credentials/{credential_id}/set-default", response_model=CredentialResponse)
async def set_default_credential(
    credential_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Set a credential as the user's global default.

    Clears the existing default (if any) and promotes the specified
    credential.
    """
    user_id = resolve_user_id(user)
    user_uuid = UUID(user_id)

    try:
        async with get_db_session() as db:
            # Verify credential exists, belongs to user, and is not deleted
            row = await _get_user_credential(db, credential_id, user_id)

            # Both UPDATEs run in a single DB transaction (auto-committed
            # when the context manager exits).  The partial unique index
            # ``idx_user_creds_one_default`` guarantees at most one active
            # default per user.
            await db.execute(
                update(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.is_default.is_(True),
                    UserLlmCredential.is_deleted.is_(False),
                )
                .values(is_default=False)
            )

            row.is_default = True

    except IntegrityError:
        # Concurrent requests may race on the partial unique index.
        # Return 409 so the client can retry.
        raise HTTPException(
            status_code=409,
            detail="Another request is updating the default credential. Please try again.",
        )

    # Re-fetch for response
    async with get_db_session() as db:
        stmt = select(UserLlmCredential).where(
            UserLlmCredential.credential_id == UUID(credential_id),
            UserLlmCredential.user_id == user_uuid,
            UserLlmCredential.is_deleted.is_(False),
        )
        result = await db.execute(stmt)
        updated_row = result.scalar_one()

    logger.info("Set credential %s as default for user %s", credential_id, user_id)
    return _cred_row_to_response(updated_row, api_key_set=_credential_has_api_key(updated_row))


# ======================================================================
# PATCH /LLMs/credentials/{credential_id}/set-default-embedding
# ======================================================================

@router.patch(
    "/credentials/{credential_id}/set-default-embedding",
    response_model=CredentialResponse,
)
async def set_default_embedding_credential(
    credential_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Set a credential as the user's default embedding model.

    Mirrors ``set_default_credential`` exactly, but for the independent
    ``is_default_embedding`` flag: it never touches ``is_default``, and the
    chat default never touches this one either.
    """
    user_id = resolve_user_id(user)
    user_uuid = UUID(user_id)

    try:
        async with get_db_session() as db:
            row = await _get_user_credential(db, credential_id, user_id)

            if not is_embedding_credential(row.config_metadata, row.credential_name or ""):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        "Only an embedding-capable model can be set as the "
                        "default embedding model. Mark 'is_embedding' on it first."
                    ),
                )

            # Both UPDATEs run in a single DB transaction (auto-committed
            # when the context manager exits). The partial unique index
            # ``idx_user_creds_one_default_embedding`` guarantees at most one
            # active embedding default per user.
            await db.execute(
                update(UserLlmCredential)
                .where(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.is_default_embedding.is_(True),
                    UserLlmCredential.is_deleted.is_(False),
                )
                .values(is_default_embedding=False)
            )

            row.is_default_embedding = True

    except HTTPException:
        raise
    except IntegrityError:
        # Concurrent requests may race on the partial unique index.
        raise HTTPException(
            status_code=409,
            detail="Another request is updating the default embedding model. Please try again.",
        )

    # Re-fetch for response
    async with get_db_session() as db:
        stmt = select(UserLlmCredential).where(
            UserLlmCredential.credential_id == UUID(credential_id),
            UserLlmCredential.user_id == user_uuid,
            UserLlmCredential.is_deleted.is_(False),
        )
        result = await db.execute(stmt)
        updated_row = result.scalar_one()

    logger.info(
        "Set credential %s as default embedding model for user %s", credential_id, user_id
    )
    return _cred_row_to_response(updated_row, api_key_set=_credential_has_api_key(updated_row))


# ======================================================================
# Startup Rehydration — Restore custom models from DB into ConfigLoader
# ======================================================================

async def rehydrate_custom_models_from_db() -> None:
    """
    Legacy rehydration function -- now a no-op.

    All LLM credential resolution uses the DB (user_llm_credentials table)
    directly via llm_resolver.py.  The process-global _custom_models dict
    has been removed to prevent cross-user model leakage.
    """
    logger.info("Custom model rehydration skipped (DB is now the sole source of truth)")
