"""
Workbench LLM Routes

Separate CRUD and test surface for workbench catalog entries.
This module intentionally does not alter existing marketplace routes.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select

from echolib.database import get_db_session
from echolib.models.user_llm_credential import UserLlmCredential
from echolib.models.workbench_llm_catalog import WorkbenchLlmCatalog
from echolib.security import require_admin_or_above, require_user, resolve_user_id
from echolib.types import UserContext


router = APIRouter(prefix="/LLMs/workbench", tags=["LLMs Workbench"])


class WorkbenchModelCreateRequest(BaseModel):
    canonical_model_id: str = Field(..., min_length=3, max_length=255)
    name: str = Field(..., min_length=1, max_length=255)
    provider_type: str = Field(..., min_length=1, max_length=100)
    model_name: str = Field(..., min_length=1, max_length=255)
    base_url: Optional[str] = Field(None, max_length=1024)
    credential_id: Optional[str] = None
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WorkbenchModelUpdateRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    provider_type: Optional[str] = Field(None, min_length=1, max_length=100)
    model_name: Optional[str] = Field(None, min_length=1, max_length=255)
    base_url: Optional[str] = Field(None, max_length=1024)
    credential_id: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None


class WorkbenchModelResponse(BaseModel):
    id: str
    canonical_model_id: str
    name: str
    provider_type: str
    model_name: str
    base_url: Optional[str] = None
    credential_id: Optional[str] = None
    description: Optional[str] = None
    is_active: bool
    metadata: Dict[str, Any] = Field(default_factory=dict)
    catalog_type: str = "workbench"


class WorkbenchModelTestResponse(BaseModel):
    success: bool
    message: str


class WorkbenchInvokeRequest(BaseModel):
    payload: Dict[str, Any] = Field(default_factory=dict)


def _to_response(row: WorkbenchLlmCatalog) -> WorkbenchModelResponse:
    return WorkbenchModelResponse(
        id=str(row.workbench_llm_id),
        canonical_model_id=row.canonical_model_id,
        name=row.name,
        provider_type=row.provider_type,
        model_name=row.model_name,
        base_url=row.base_url,
        credential_id=str(row.credential_id) if row.credential_id else None,
        description=row.description,
        is_active=row.is_active,
        metadata=row.config_metadata or {},
    )


@router.get("", response_model=List[WorkbenchModelResponse])
async def list_workbench_models(
    include_inactive: bool = False,
    user: UserContext = Depends(require_user),
):
    """List workbench catalog entries."""
    _ = user
    async with get_db_session() as db:
        stmt = select(WorkbenchLlmCatalog).order_by(WorkbenchLlmCatalog.created_at.desc())
        if not include_inactive:
            stmt = stmt.where(WorkbenchLlmCatalog.is_active.is_(True))
        rows = (await db.execute(stmt)).scalars().all()

    return [_to_response(row) for row in rows]


@router.post("", response_model=WorkbenchModelResponse, status_code=201)
async def create_workbench_model(
    body: WorkbenchModelCreateRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """Create a new workbench catalog entry."""
    user_id = resolve_user_id(user)

    credential_uuid: Optional[UUID] = None
    if body.credential_id:
        try:
            credential_uuid = UUID(body.credential_id)
        except ValueError as e:
            raise HTTPException(status_code=422, detail="Invalid credential_id UUID") from e

    async with get_db_session() as db:
        existing = await db.execute(
            select(WorkbenchLlmCatalog).where(
                WorkbenchLlmCatalog.canonical_model_id == body.canonical_model_id
            )
        )
        if existing.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=409,
                detail=f"canonical_model_id '{body.canonical_model_id}' already exists",
            )

        if credential_uuid is not None:
            cred = await db.execute(
                select(UserLlmCredential).where(
                    UserLlmCredential.credential_id == credential_uuid,
                    UserLlmCredential.is_deleted.is_(False),
                )
            )
            if cred.scalar_one_or_none() is None:
                raise HTTPException(status_code=404, detail="Credential not found")

        row = WorkbenchLlmCatalog(
            canonical_model_id=body.canonical_model_id,
            name=body.name,
            provider_type=body.provider_type,
            model_name=body.model_name,
            base_url=body.base_url,
            credential_id=credential_uuid,
            created_by=UUID(user_id),
            description=body.description,
            is_active=True,
            config_metadata=body.metadata,
        )
        db.add(row)

    return _to_response(row)


@router.put("/{workbench_llm_id}", response_model=WorkbenchModelResponse)
async def update_workbench_model(
    workbench_llm_id: str,
    body: WorkbenchModelUpdateRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update an existing workbench catalog entry."""
    _ = user

    try:
        entry_uuid = UUID(workbench_llm_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail="Invalid workbench_llm_id UUID") from e

    credential_uuid: Optional[UUID] = None
    if body.credential_id is not None:
        try:
            credential_uuid = UUID(body.credential_id)
        except ValueError as e:
            raise HTTPException(status_code=422, detail="Invalid credential_id UUID") from e

    async with get_db_session() as db:
        row = (
            await db.execute(
                select(WorkbenchLlmCatalog).where(
                    WorkbenchLlmCatalog.workbench_llm_id == entry_uuid
                )
            )
        ).scalar_one_or_none()

        if row is None:
            raise HTTPException(status_code=404, detail="Workbench model not found")

        if credential_uuid is not None:
            cred = await db.execute(
                select(UserLlmCredential).where(
                    UserLlmCredential.credential_id == credential_uuid,
                    UserLlmCredential.is_deleted.is_(False),
                )
            )
            if cred.scalar_one_or_none() is None:
                raise HTTPException(status_code=404, detail="Credential not found")
            row.credential_id = credential_uuid

        if body.name is not None:
            row.name = body.name
        if body.provider_type is not None:
            row.provider_type = body.provider_type
        if body.model_name is not None:
            row.model_name = body.model_name
        if body.base_url is not None:
            row.base_url = body.base_url
        if body.description is not None:
            row.description = body.description
        if body.is_active is not None:
            row.is_active = body.is_active
        if body.metadata is not None:
            row.config_metadata = body.metadata

    return _to_response(row)


@router.delete("/{workbench_llm_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_workbench_model(
    workbench_llm_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Delete a workbench catalog entry."""
    _ = user

    try:
        entry_uuid = UUID(workbench_llm_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail="Invalid workbench_llm_id UUID") from e

    async with get_db_session() as db:
        row = (
            await db.execute(
                select(WorkbenchLlmCatalog).where(
                    WorkbenchLlmCatalog.workbench_llm_id == entry_uuid
                )
            )
        ).scalar_one_or_none()

        if row is None:
            raise HTTPException(status_code=404, detail="Workbench model not found")

        await db.delete(row)


@router.post("/{workbench_llm_id}/test", response_model=WorkbenchModelTestResponse)
async def test_workbench_model(
    workbench_llm_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Validate entry + credential linkage before invoke adapter wiring is added."""
    _ = user

    try:
        entry_uuid = UUID(workbench_llm_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail="Invalid workbench_llm_id UUID") from e

    async with get_db_session() as db:
        row = (
            await db.execute(
                select(WorkbenchLlmCatalog).where(
                    WorkbenchLlmCatalog.workbench_llm_id == entry_uuid
                )
            )
        ).scalar_one_or_none()

        if row is None:
            raise HTTPException(status_code=404, detail="Workbench model not found")

        if row.credential_id is not None:
            cred = await db.execute(
                select(UserLlmCredential).where(
                    UserLlmCredential.credential_id == row.credential_id,
                    UserLlmCredential.is_deleted.is_(False),
                )
            )
            if cred.scalar_one_or_none() is None:
                raise HTTPException(status_code=409, detail="Linked credential is missing or deleted")

    return WorkbenchModelTestResponse(
        success=True,
        message="Workbench model entry is valid. Adapter invocation wiring is pending implementation.",
    )


@router.post("/{workbench_llm_id}/invoke")
async def invoke_workbench_model(
    workbench_llm_id: str,
    body: WorkbenchInvokeRequest,
    user: UserContext = Depends(require_user),
):
    """Placeholder invoke route for upcoming adapter-based implementation."""
    _ = body
    _ = user
    raise HTTPException(
        status_code=501,
        detail=f"Workbench invoke is not wired yet for model {workbench_llm_id}.",
    )


@router.post("/{workbench_llm_id}/chat")
async def chat_workbench_model(
    workbench_llm_id: str,
    body: WorkbenchInvokeRequest,
    user: UserContext = Depends(require_user),
):
    """Placeholder chat route for upcoming adapter-based implementation."""
    _ = body
    _ = user
    raise HTTPException(
        status_code=501,
        detail=f"Workbench chat is not wired yet for model {workbench_llm_id}.",
    )


@router.post("/{workbench_llm_id}/count-tokens")
async def count_tokens_workbench_model(
    workbench_llm_id: str,
    body: WorkbenchInvokeRequest,
    user: UserContext = Depends(require_user),
):
    """Placeholder count-tokens route for upcoming adapter-based implementation."""
    _ = body
    _ = user
    raise HTTPException(
        status_code=501,
        detail=f"Workbench count-tokens is not wired yet for model {workbench_llm_id}.",
    )
