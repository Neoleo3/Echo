"""
The uniform connector invocation surface.

WHAT: One entry point -- ``invoke_connector(connector, operation, params)`` --
      dispatching to the API client, the MCP client, or the database service.
WHY:  Before phase 5 a connector was reachable only by masquerading as a tool,
      so invocation lived in ``apps/tool/executor.py`` behind a ``ToolDef`` and
      databases were unreachable entirely. One surface means one place where
      operations are checked, credentials resolve, and results are normalized.

Credentials are never passed in and never returned. Each kind resolves its own,
server-side, per invocation, through the path it already used:
API and MCP via their services (Key Vault), databases via
``db_connections.connection_string``. Phase 5 changes none of that.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Optional

from apps.tool.async_bridge import run_async
from echolib import connector_permissions as permissions

from . import guards
from .refs import KIND_API, KIND_DATABASE, KIND_MCP, ResolvedConnector

logger = logging.getLogger(__name__)

DEFAULT_INVOKE_TIMEOUT_SECONDS = 60

# Operation names, shared with the tool layer and the allow-list check.
OP_API_INVOKE = "invoke"
OP_MCP_CALL_TOOL = "call_tool"
OP_MCP_READ_RESOURCE = "read_resource"
OP_DB_LIST_TABLES = "list_tables"
OP_DB_GET_SCHEMA = "get_schema"
OP_DB_QUERY = "query"


@dataclass(frozen=True)
class InvocationResult:
    """Normalized outcome of one connector call."""

    success: bool
    data: Any = None
    error: Optional[str] = None
    error_type: Optional[str] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def ok(cls, data: Any, **metadata: Any) -> "InvocationResult":
        return cls(success=True, data=data, metadata=metadata)

    @classmethod
    def fail(cls, error: str, error_type: str = "execution_error", **metadata: Any) -> "InvocationResult":
        return cls(success=False, error=error, error_type=error_type, metadata=metadata)


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def _invoke_api(
    connector: ResolvedConnector,
    params: Mapping[str, Any],
    *,
    user_id: str,
) -> InvocationResult:
    """
    Call an API connector.

    The endpoint, method and auth come from the stored record; the model
    supplies only query parameters and a body. It cannot redirect the call.
    """
    from echolib.connectors.api_service import APIConnectorService

    query_params = params.get("query_params")
    body = params.get("body")

    normalized_params = (
        {str(k): str(v) for k, v in query_params.items()} if isinstance(query_params, dict) else None
    )

    result = run_async(
        APIConnectorService().invoke(
            connector.connector_id,
            user_id=user_id,
            query_params=normalized_params,
            body=body if isinstance(body, dict) else None,
        ),
        timeout=DEFAULT_INVOKE_TIMEOUT_SECONDS,
    )

    payload = result.model_dump() if hasattr(result, "model_dump") else result
    if not isinstance(payload, dict):
        return InvocationResult.ok(payload)

    if payload.get("success", True):
        return InvocationResult.ok(
            payload.get("data", payload.get("response", payload)),
            status_code=payload.get("status_code"),
        )

    return InvocationResult.fail(
        str(payload.get("error") or "API call failed"),
        str(payload.get("error_type") or "execution_error"),
        status_code=payload.get("status_code"),
    )


# ---------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------

def _invoke_mcp(
    connector: ResolvedConnector,
    operation: str,
    params: Mapping[str, Any],
    *,
    user_id: str,
) -> InvocationResult:
    """Call a tool on, or read a resource from, an MCP server."""
    from echolib.mcp.service import MCPConnectorService

    if operation == OP_MCP_READ_RESOURCE:
        uri = str(params.get("resource_uri") or params.get("uri") or "").strip()
        if not uri:
            return InvocationResult.fail("resource_uri is required", "validation_error")
        payload: Dict[str, Any] = {"operation": "resources/read", "resource_uri": uri}
    else:
        tool_name = str(params.get("tool_name") or "").strip()
        if not tool_name:
            return InvocationResult.fail("tool_name is required", "validation_error")

        # The tool's own arguments are exposed as top-level fields, because the
        # args model is generated from the MCP tool's advertised input schema.
        # An explicit ``arguments`` mapping is honoured when a caller supplies
        # one directly.
        arguments = params.get("arguments")
        if not isinstance(arguments, dict):
            arguments = {
                key: value
                for key, value in params.items()
                if key not in ("tool_name", "operation", "arguments")
            }

        payload = {"tool_name": tool_name, "arguments": arguments}

    result = run_async(
        MCPConnectorService().invoke_async(
            connector.connector_id,
            payload=payload,
            context={"source": "agent_connector_middleware"},
            user_id=user_id,
        ),
        timeout=DEFAULT_INVOKE_TIMEOUT_SECONDS,
    )

    if not isinstance(result, dict):
        return InvocationResult.ok(result)
    if result.get("success"):
        return InvocationResult.ok(result.get("output", result))
    return InvocationResult.fail(str(result.get("error") or "MCP call failed"))


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db_service() -> Any:
    from apps.connector.db_connector import DatabaseConnectorService

    return DatabaseConnectorService()


def db_list_tables(connection_id: str, schema: Optional[str] = None) -> Dict[str, Any]:
    """Read-only table and view listing. Also used to build the descriptor."""
    return _db_service().get_tables(connection_id, schema_name=schema)


def db_full_schema(connection_id: str, schema: Optional[str] = None) -> Dict[str, Any]:
    """Full introspection: columns, keys, indexes, row-count estimates."""
    return _db_service().get_full_schema(connection_id, schema_name=schema)


def _invoke_database(
    connector: ResolvedConnector,
    operation: str,
    params: Mapping[str, Any],
) -> InvocationResult:
    """
    Run one of the three database operations under the read-only guard.

    Ownership was established when the connector resolved; the service is
    re-consulted here only for execution.
    """
    connection_id = connector.connector_id
    # ``schema_name`` is what the tool args model exposes; ``schema`` is
    # accepted too so a direct caller reads naturally.
    raw_schema = params.get("schema_name") or params.get("schema")
    schema = str(raw_schema) if raw_schema else None

    if operation == OP_DB_LIST_TABLES:
        return InvocationResult.ok(db_list_tables(connection_id, schema))

    if operation == OP_DB_GET_SCHEMA:
        full = db_full_schema(connection_id, schema)
        table = str(params.get("table") or "").strip()
        if table:
            matches = [
                entry for entry in full.get("tables", [])
                if str(entry.get("table_name", "")).lower() == table.lower()
            ]
            if not matches:
                return InvocationResult.fail(
                    f"Table '{table}' was not found on this connector.", "not_found"
                )
            return InvocationResult.ok({"tables": matches, "schema": full.get("schema")})
        return InvocationResult.ok(full)

    if operation == OP_DB_QUERY:
        sql = str(params.get("sql") or params.get("query") or "")
        # Writes are explicit opt-in: they require read_write or above, or the
        # ``write`` grant named directly. An attachment that never stated a
        # level is read_only, so migration 062's attachments cannot write.
        allow_write = permissions.allows_database_write(connector.permitted_operations())
        try:
            statement, classification = guards.check_query(sql, allow_write=allow_write)
        except guards.SQLGuardError as exc:
            return InvocationResult.fail(str(exc), "query_rejected")

        limit = guards.resolve_row_limit(params.get("limit"))
        db_type = str((connector.record or {}).get("db_type") or "")
        if classification == guards.OPERATION_READ:
            statement = guards.apply_row_limit(statement, db_type=db_type, limit=limit)

        result = _db_service().execute_query(
            connection_id,
            statement,
            limit=limit,
            timeout=guards.DEFAULT_STATEMENT_TIMEOUT_SECONDS,
        )
        return InvocationResult.ok(result, executed_sql=statement, classification=classification)

    return InvocationResult.fail(f"Unsupported database operation '{operation}'.", "validation_error")


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_KIND_OPERATIONS = {
    KIND_API: {OP_API_INVOKE},
    KIND_MCP: {OP_MCP_CALL_TOOL, OP_MCP_READ_RESOURCE},
    KIND_DATABASE: {OP_DB_LIST_TABLES, OP_DB_GET_SCHEMA, OP_DB_QUERY},
}


def _authorize(
    connector: ResolvedConnector,
    operation: str,
    params: Mapping[str, Any],
) -> Optional[str]:
    """
    Check one call against the attachment's permission set.

    WHAT: Returns ``None`` when the call is authorized, otherwise the refusal
          to hand back to the model.
    WHY:  This is the authorization boundary. Withholding a tool at build time
          keeps it out of the model's reach, but that is a UX control -- the
          decision has to be re-made at the moment of the call, because this is
          the last point before a request leaves for an external system.
          Prompt instructions are never part of it.

    For MCP the *tool name* is what is checked, not just the operation: an
    attachment permits named tools, and ``call_tool`` alone says nothing about
    which one. For databases, reads are inherent to any attachment and only the
    write class is gated. For an API connector the single stored endpoint is
    the operation.
    """
    permitted = connector.permitted_operations()

    if connector.kind == KIND_API:
        if operation in permitted:
            return None
        return f"Operation '{operation}' is not permitted for connector '{connector.alias}'."

    if connector.kind == KIND_MCP:
        if operation == OP_MCP_READ_RESOURCE:
            if permissions.MCP_RESOURCE_OPERATION in permitted:
                return None
            return (
                f"Reading resources from '{connector.alias}' is not enabled for this agent."
            )

        tool_name = str(params.get("tool_name") or "").strip()
        if not tool_name:
            return "tool_name is required."
        if tool_name in permitted:
            return None
        return (
            f"The tool '{tool_name}' is not enabled for connector '{connector.alias}'. "
            "Ask the user to raise its access level or enable that tool, and do not "
            "claim to have used it."
        )

    if connector.kind == KIND_DATABASE:
        if operation != OP_DB_QUERY:
            return None if permissions.database_operation_permitted(operation, permitted) else (
                f"Operation '{operation}' is not permitted for connector '{connector.alias}'."
            )
        # A query's own class is decided by the SQL guard, which classifies the
        # statement; the write grant is checked there against the same set.
        return None

    return f"Connector kind '{connector.kind}' cannot be invoked."


def invoke_connector(
    connector: ResolvedConnector,
    operation: str,
    params: Optional[Mapping[str, Any]] = None,
    *,
    user_id: Optional[str] = None,
) -> InvocationResult:
    """
    Invoke one operation on one attached connector.

    WHAT: Validates the operation against the connector kind and the
          attachment's allow-list, then dispatches to the owning service.
    WHY:  This is the single enforcement point for spec section 6.1 gating at
          call time, and the only place an agent's request becomes a real
          external call.
    INPUT: A ``ResolvedConnector``, an operation name, its parameters, and the
           acting user.
    OUTPUT: ``InvocationResult`` -- failures are values, not exceptions, so the
            model receives an actionable message instead of the node crashing.
    """
    params = params or {}
    operation = str(operation or "").strip().lower()

    if not connector.resolved:
        return InvocationResult.fail(
            f"Connector '{connector.alias}' is unavailable: {connector.error}", "unavailable"
        )

    permitted = _KIND_OPERATIONS.get(connector.kind, set())
    if operation not in permitted:
        return InvocationResult.fail(
            f"Operation '{operation}' is not supported by a {connector.kind} connector.",
            "validation_error",
        )

    denial = _authorize(connector, operation, params)
    if denial is not None:
        logger.warning(
            "Refused %s on connector '%s' (level=%s): %s",
            operation, connector.connector_id, connector.access_level, denial,
        )
        return InvocationResult.fail(denial, "not_permitted")

    try:
        if connector.kind == KIND_API:
            return _invoke_api(connector, params, user_id=str(user_id or ""))
        if connector.kind == KIND_MCP:
            return _invoke_mcp(connector, operation, params, user_id=str(user_id or ""))
        return _invoke_database(connector, operation, params)
    except Exception as exc:
        logger.error(
            "Connector '%s' operation '%s' failed: %s",
            connector.connector_id, operation, exc, exc_info=True,
        )
        return InvocationResult.fail(str(exc))


__all__ = [
    "InvocationResult",
    "OP_API_INVOKE",
    "OP_DB_GET_SCHEMA",
    "OP_DB_LIST_TABLES",
    "OP_DB_QUERY",
    "OP_MCP_CALL_TOOL",
    "OP_MCP_READ_RESOURCE",
    "db_full_schema",
    "db_list_tables",
    "invoke_connector",
]
