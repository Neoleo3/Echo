"""
Connector Middleware -- how an agent reaches its attached connectors.

WHAT: One ``AgentMiddleware`` that carries the tools for an agent's attached
      API, MCP and database connectors, plus the descriptor block describing
      them.
WHY:  Phase 5a deleted connector-to-tool synthesis: connectors were minted as
      synthetic entries in the global tool registry, which polluted it with
      per-user tools, made attachment implicit, and left databases unreachable
      by any agent. Attachment now lives on the agent
      (``definition.connectors``) and this is the only path from there to a
      real call.

Two responsibilities, matching the plan:

1. **Context exposure at build time** -- ``descriptors`` renders what each
   connector is and which tool calls it, under a shared token budget.
2. **Runtime invocation** -- ``tools`` registers callables that dispatch
   through ``invoker`` to each connector kind's existing service.

Gating: Connector Settings is off by default per agent (spec section 6.1). The
contract's ``attached_connectors`` returns nothing while it is off, so an agent
whose toggle is off gets no descriptors and no tools regardless of what its
definition contains.

Secrets: descriptors carry auth *type* only, tool arguments never carry
credentials, and every credential resolves server-side per invocation through
the path that kind already used. Key Vault behaviour is unchanged.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Sequence

from langchain.agents.middleware import AgentMiddleware

from echolib.agent_contract import ORIGIN_APPLICATION

from .descriptors import describe_connectors
from .refs import ResolvedConnector, resolve_agent_connectors
from .tools import build_connector_tools, new_budget_state

logger = logging.getLogger(__name__)


class ConnectorMiddleware(AgentMiddleware):
    """
    Registers connector tools with the agent and reports their descriptor.

    Tools are resolved once per build. ``AgentFactory.build`` runs per
    invocation, so "once per build" is also "once per turn" -- new attachments
    take effect on the next message with no cache to invalidate.
    """

    def __init__(
        self,
        connectors: Sequence[ResolvedConnector],
        tools: Sequence[Any],
        *,
        budget_state: Optional[Dict[str, Any]] = None,
        context_block: str = "",
    ) -> None:
        self.connectors = list(connectors)
        self.tools = list(tools)
        self.budget_state = budget_state if budget_state is not None else new_budget_state()
        self.context_block = context_block

    @property
    def name(self) -> str:
        return "ConnectorMiddleware"

    def describe(self) -> Dict[str, Any]:
        """
        Summarize this build's connector surface for logs and step metadata.

        Identifiers and counts only -- never a credential, never a descriptor
        body, so it is safe to persist alongside an execution record.
        """
        return {
            "attached": len(self.connectors),
            "resolved": sum(1 for c in self.connectors if c.resolved),
            "own_resolved": sum(
                1 for c in self.connectors
                if c.resolved and c.origin != ORIGIN_APPLICATION
            ),
            "application_resolved": sum(
                1 for c in self.connectors
                if c.resolved and c.origin == ORIGIN_APPLICATION
            ),
            "tools": len(self.tools),
            "connectors": [
                {
                    "connector_id": c.connector_id,
                    "kind": c.kind,
                    "alias": c.alias,
                    "origin": c.origin or "agent",
                    "resolved": c.resolved,
                    "error": c.error,
                }
                for c in self.connectors
            ],
        }


def build_connector_middleware(
    agent_config: Optional[Dict[str, Any]],
    *,
    user_id: Optional[str] = None,
    owner_user_id: Optional[str] = None,
    budget_state: Optional[Dict[str, Any]] = None,
    on_tool_start: Optional[Callable[..., Optional[str]]] = None,
    on_tool_end: Optional[Callable[..., None]] = None,
    token_budget: Optional[int] = None,
) -> Optional[ConnectorMiddleware]:
    """
    Build the connector middleware for one agent, or ``None`` when it has none.

    WHAT: Resolves attachments, renders descriptors, builds tools.
    WHY:  ``AgentFactory`` needs one call that either yields a middleware or
          nothing, so the factory never grows connector-specific branching.
    INPUT: An agent definition, the acting user, the owner whose ownership
           authorises the agent's own attachments, the shared connector budget,
           observability hooks, and this build's share of the descriptor token
           allowance. ``token_budget`` is passed by the factory so connector
           and attached-document descriptors compete for one prompt allowance
           rather than each claiming their own; ``None`` keeps the standalone
           default. ``owner_user_id`` defaults to the caller, which is correct
           wherever the agent is being run by its author.
    OUTPUT: ``ConnectorMiddleware`` or ``None``. Returns ``None`` when the
            agent has no attachments or Connector Settings is off; returns a
            middleware with zero tools when attachments exist but none
            resolved, because the descriptor still has to tell the model those
            sources are unavailable rather than leaving it to guess.
    """
    connectors = resolve_agent_connectors(
        agent_config, user_id, owner_user_id=owner_user_id
    )
    if not connectors:
        return None

    budget = budget_state if budget_state is not None else new_budget_state()
    tools = build_connector_tools(
        connectors,
        user_id=user_id,
        budget_state=budget,
        on_tool_start=on_tool_start,
        on_tool_end=on_tool_end,
    )
    context_block = describe_connectors(connectors, token_budget=token_budget)

    # Split by origin: "2 connectors, 1 resolved" cannot say whether the agent
    # lost its own connector or the application's, which is the first question
    # asked every time this surface looks empty.
    own = [c for c in connectors if c.origin != ORIGIN_APPLICATION]
    lent = [c for c in connectors if c.origin == ORIGIN_APPLICATION]
    logger.info(
        "Connector middleware: own %d/%d resolved, application %d/%d resolved, "
        "%d tools, %d descriptor chars",
        sum(1 for c in own if c.resolved), len(own),
        sum(1 for c in lent if c.resolved), len(lent),
        len(tools),
        len(context_block),
    )

    return ConnectorMiddleware(
        connectors,
        tools,
        budget_state=budget,
        context_block=context_block,
    )


__all__ = [
    "ConnectorMiddleware",
    "ResolvedConnector",
    "build_connector_middleware",
    "build_connector_tools",
    "describe_connectors",
    "resolve_agent_connectors",
]
