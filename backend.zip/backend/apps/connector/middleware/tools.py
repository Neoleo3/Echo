"""
Connector-backed tools handed to the agent.

WHAT: Builds the ``StructuredTool`` objects that make an attached connector
      callable -- one per API connector, one per permitted MCP tool, three per
      database.
WHY:  A descriptor tells the model what exists; these are what make the call
      real rather than hallucinated.

Why connector calls do not share the ``execution_policy`` tool budget:
that policy caps an agent at three tool calls per run and blocks a second call
to the same tool, which suits one-shot enrichment tools. A database
conversation is inherently multi-step -- list tables, read the schema, then
query, then query again with a correction -- so reusing that budget would make
the database path unusable on arrival. Connector calls get their own allowance
with duplicate-input suppression instead of once-per-tool suppression.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from echolib.connector_permissions import allows_database_write

from .descriptors import allowed_mcp_tools
from .invoker import (
    OP_API_INVOKE,
    OP_DB_GET_SCHEMA,
    OP_DB_LIST_TABLES,
    OP_DB_QUERY,
    OP_MCP_CALL_TOOL,
    OP_MCP_READ_RESOURCE,
    InvocationResult,
    invoke_connector,
)
from .naming import tool_name
from .operations import MCP_RESOURCE_OPERATION
from .refs import KIND_API, KIND_DATABASE, KIND_MCP, ResolvedConnector

logger = logging.getLogger(__name__)

DEFAULT_MAX_CONNECTOR_CALLS = 12
MAX_RESULT_CHARS = 6000


def resolve_connector_call_limit() -> int:
    """Per-run ceiling on connector calls, environment-overridable."""
    try:
        configured = int(
            os.getenv("AGENT_MAX_CONNECTOR_CALLS", str(DEFAULT_MAX_CONNECTOR_CALLS))
        )
    except ValueError:
        return DEFAULT_MAX_CONNECTOR_CALLS
    return max(1, configured)


def new_budget_state(max_calls: Optional[int] = None) -> Dict[str, Any]:
    """Create the shared per-run connector budget."""
    return {
        "calls": 0,
        "max_calls": int(max_calls or resolve_connector_call_limit()),
        "signatures": set(),
        "by_connector": {},
        "failures": 0,
    }


def _signature(name: str, kwargs: Mapping[str, Any]) -> str:
    try:
        return f"{name}:{json.dumps(kwargs, sort_keys=True, default=str)}"
    except (TypeError, ValueError):
        return f"{name}:{kwargs}"


def _reserve(state: Dict[str, Any], connector_id: str, name: str, kwargs: Mapping[str, Any]) -> Optional[str]:
    """
    Take one unit of connector budget, or explain why the call is refused.

    Duplicate suppression is by exact input signature: repeating a call with
    the same arguments cannot produce a different answer within one run, and it
    is the shape a stuck agent loops in.
    """
    if state["calls"] >= state["max_calls"]:
        return (
            f"Connector call budget exhausted for this run ({state['max_calls']} calls). "
            "Answer with what you already retrieved and state what could not be checked."
        )

    signature = _signature(name, kwargs)
    if signature in state["signatures"]:
        return (
            "This exact call was already made in this run and returned the same result. "
            "Use the earlier result, or call with different arguments."
        )

    state["calls"] += 1
    state["signatures"].add(signature)
    state["by_connector"][connector_id] = state["by_connector"].get(connector_id, 0) + 1
    return None


def format_result(result: InvocationResult) -> str:
    """
    Render an invocation outcome as the text the model reads.

    JSON rather than the flattened ``key: value`` shape used for classic tools:
    connector payloads are rows and schemas, and structure is what makes them
    usable. Oversized payloads are truncated with an explicit marker so the
    model knows it is not seeing everything.
    """
    if not result.success:
        return (
            f"Connector error ({result.error_type or 'execution_error'}): {result.error}. "
            "Do not fabricate the data you were trying to retrieve."
        )

    data = result.data
    if isinstance(data, str):
        rendered = data
    else:
        try:
            rendered = json.dumps(data, default=str, ensure_ascii=False)
        except (TypeError, ValueError):
            rendered = str(data)

    if len(rendered) > MAX_RESULT_CHARS:
        rendered = (
            rendered[:MAX_RESULT_CHARS]
            + f"\n… result truncated at {MAX_RESULT_CHARS} characters. "
            "Narrow the request (fewer columns, a filter, or a smaller limit) if you need the rest."
        )
    return rendered


def _make_callable(
    *,
    connector: ResolvedConnector,
    operation: str,
    name: str,
    user_id: Optional[str],
    budget_state: Dict[str, Any],
    on_tool_start: Optional[Callable[..., Optional[str]]],
    on_tool_end: Optional[Callable[..., None]],
    static_params: Optional[Dict[str, Any]] = None,
) -> Callable[..., str]:
    """Build the synchronous function a StructuredTool invokes."""

    def _start(kwargs: Dict[str, Any]) -> Optional[str]:
        if on_tool_start is None:
            return None
        try:
            return on_tool_start(name, f"{connector.name} · {operation}", kwargs)
        except Exception:
            logger.debug("on_tool_start hook failed for '%s'", name, exc_info=True)
            return None

    def _end(step_id: Optional[str], payload: Any) -> None:
        if on_tool_end is None or step_id is None:
            return
        try:
            on_tool_end(step_id, payload)
        except Exception:
            logger.debug("on_tool_end hook failed for '%s'", name, exc_info=True)

    def _call(**kwargs: Any) -> str:
        params: Dict[str, Any] = dict(static_params or {})
        params.update({k: v for k, v in kwargs.items() if v is not None})

        step_id = _start(dict(kwargs))

        refusal = _reserve(budget_state, connector.connector_id, name, kwargs)
        if refusal:
            _end(step_id, refusal)
            return refusal

        # The principal the connector resolved under, not the caller. The API
        # and MCP services scope invocation by user exactly as their lookups
        # do, so calling under the caller would fail every connector an agent
        # author attached the moment anyone else ran the agent -- the tool
        # would be visible and unusable. Falls back to the caller for a
        # connector resolved before the principal was carried.
        result = invoke_connector(
            connector,
            operation,
            params,
            user_id=connector.principal_user_id or user_id,
        )
        if not result.success:
            budget_state["failures"] = budget_state.get("failures", 0) + 1

        text = format_result(result)
        _end(step_id, text)
        logger.info(
            "Connector tool '%s' -> %s (%s)",
            name, "ok" if result.success else "error", connector.kind,
        )
        return text

    _call.__name__ = name
    return _call


# ---------------------------------------------------------------------------
# Argument schemas
# ---------------------------------------------------------------------------

def _model(name: str, **fields: Any) -> Any:
    """Build a pydantic args model from ``field=(type, Field(...))`` pairs."""
    from pydantic import create_model

    return create_model(name, **fields)


def _api_args_schema(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        query_params=(
            Optional[Dict[str, Any]],
            Field(None, description="Query string parameters to send with the request."),
        ),
        body=(
            Optional[Dict[str, Any]],
            Field(None, description="Request body fields. Ignored for GET endpoints."),
        ),
    )


def _mcp_args_schema(name: str, input_schema: Optional[Mapping[str, Any]]) -> Any:
    """Derive the args model from the MCP tool's advertised JSON schema."""
    from apps.tool.langchain_tools import args_schema_from_input

    properties = (input_schema or {}).get("properties") if isinstance(input_schema, Mapping) else None
    if not properties:
        # A tool that advertises no inputs must not be given a synthetic one.
        return _model(f"{name}_Args")
    return args_schema_from_input(name, dict(input_schema or {}))


def _resource_args_schema(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        resource_uri=(str, Field(..., description="URI of the resource to read.")),
    )


def _db_query_args_schema(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        sql=(str, Field(..., description="A single SQL statement. SELECT only unless this connector allows writes.")),
        limit=(Optional[int], Field(None, description="Maximum rows to return. Capped server-side.")),
    )


def _db_schema_args_schema(name: str) -> Any:
    from pydantic import Field

    # ``schema_name`` rather than ``schema``: a pydantic field called ``schema``
    # shadows an attribute on BaseModel.
    return _model(
        f"{name}_Args",
        table=(Optional[str], Field(None, description="Restrict to one table. Omit for the whole schema.")),
        schema_name=(Optional[str], Field(None, description="Database schema name, when the database uses them.")),
    )


def _db_list_args_schema(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        schema_name=(Optional[str], Field(None, description="Database schema name, when the database uses them.")),
    )


# ---------------------------------------------------------------------------
# Tool construction
# ---------------------------------------------------------------------------

def _structured_tool(name: str, description: str, func: Callable[..., str], args_schema: Any) -> Any:
    from langchain_core.tools import StructuredTool

    return StructuredTool.from_function(
        func=func,
        name=name,
        description=description,
        args_schema=args_schema,
    )


def _api_tools(connector: ResolvedConnector, **context: Any) -> List[Any]:
    record = connector.record or {}
    name = tool_name(KIND_API, connector.alias)
    method = str(record.get("method", "GET")).upper()
    endpoint = str(record.get("endpoint_url", ""))
    purpose = str(record.get("description") or "").strip()

    description = (
        f"Call the '{connector.name}' API connector ({method} {endpoint}). "
        f"{purpose} Credentials are applied server-side."
    ).strip()

    return [
        _structured_tool(
            name,
            description,
            _make_callable(connector=connector, operation=OP_API_INVOKE, name=name, **context),
            _api_args_schema(name),
        )
    ]


def _mcp_tools(connector: ResolvedConnector, **context: Any) -> List[Any]:
    tools: List[Any] = []

    for entry in allowed_mcp_tools(connector):
        remote_name = str(entry.get("name") or "").strip()
        name = tool_name(KIND_MCP, connector.alias, remote_name)
        description = (
            f"{str(entry.get('description') or '').strip()} "
            f"(MCP tool '{remote_name}' on '{connector.name}')"
        ).strip()

        tools.append(
            _structured_tool(
                name,
                description,
                _make_callable(
                    connector=connector,
                    operation=OP_MCP_CALL_TOOL,
                    name=name,
                    static_params={"tool_name": remote_name},
                    **context,
                ),
                _mcp_args_schema(name, entry.get("input_schema")),
            )
        )

    # Resource reads are a read operation and appear in the permission set
    # under a pseudo-operation name, so they follow the same rule as tools.
    resources = ((connector.record or {}).get("discovery") or {}).get("resources") or []
    if resources and MCP_RESOURCE_OPERATION in connector.permitted_operations():
        name = tool_name(KIND_MCP, connector.alias, "read_resource")
        tools.append(
            _structured_tool(
                name,
                f"Read a resource exposed by the MCP server '{connector.name}' by URI.",
                _make_callable(
                    connector=connector, operation=OP_MCP_READ_RESOURCE, name=name, **context
                ),
                _resource_args_schema(name),
            )
        )

    return tools


def _database_tools(connector: ResolvedConnector, **context: Any) -> List[Any]:
    alias = connector.alias
    label = connector.name
    writable = allows_database_write(connector.permitted_operations())

    list_name = tool_name(KIND_DATABASE, alias, "list_tables")
    schema_name = tool_name(KIND_DATABASE, alias, "get_schema")
    query_name = tool_name(KIND_DATABASE, alias, "query")

    access = "Reads and writes are permitted." if writable else "Read-only: only SELECT is accepted."

    return [
        _structured_tool(
            list_name,
            f"List the tables and views in the '{label}' database.",
            _make_callable(connector=connector, operation=OP_DB_LIST_TABLES, name=list_name, **context),
            _db_list_args_schema(list_name),
        ),
        _structured_tool(
            schema_name,
            f"Get columns, keys and row estimates for tables in the '{label}' database. "
            "Read the schema before writing a query.",
            _make_callable(connector=connector, operation=OP_DB_GET_SCHEMA, name=schema_name, **context),
            _db_schema_args_schema(schema_name),
        ),
        _structured_tool(
            query_name,
            f"Run one SQL statement against the '{label}' database and return the rows. {access} "
            "Use exact table and column names taken from the schema tool.",
            _make_callable(connector=connector, operation=OP_DB_QUERY, name=query_name, **context),
            _db_query_args_schema(query_name),
        ),
    ]


_BUILDERS = {
    KIND_API: _api_tools,
    KIND_MCP: _mcp_tools,
    KIND_DATABASE: _database_tools,
}


def _unique_tool_name(base: str, taken: set, *, limit: int = 20) -> Optional[str]:
    """
    A tool name no other tool on this build is using.

    ``base`` when free, otherwise ``base_2``, ``base_3``, ... ``None`` when the
    suffixed forms are exhausted, which the caller reports rather than hides.
    """
    if base not in taken:
        return base
    for index in range(2, limit + 2):
        candidate = f"{base}_{index}"
        if candidate not in taken:
            return candidate
    return None


def build_connector_tools(
    connectors: Sequence[ResolvedConnector],
    *,
    user_id: Optional[str] = None,
    budget_state: Optional[Dict[str, Any]] = None,
    on_tool_start: Optional[Callable[..., Optional[str]]] = None,
    on_tool_end: Optional[Callable[..., None]] = None,
) -> List[Any]:
    """
    Build every callable tool for an agent's attached connectors.

    WHAT: Maps resolved connectors to ``StructuredTool`` objects.
    WHY:  ``create_agent`` collects ``middleware.tools`` at compile time, so
          this is what puts connectors in front of the model.
    INPUT: Resolved connectors, the acting user, the shared connector budget
           and the observability hooks used by workflow transparency.
    OUTPUT: A flat list of tools. Unresolved connectors contribute none --
            they are described as unavailable instead, so the model is told
            rather than left to guess why a call is impossible.
    """
    budget = budget_state if budget_state is not None else new_budget_state()
    context = {
        "user_id": user_id,
        "budget_state": budget,
        "on_tool_start": on_tool_start,
        "on_tool_end": on_tool_end,
    }

    tools: List[Any] = []
    seen: set = set()

    for connector in connectors:
        if not connector.resolved:
            continue
        builder = _BUILDERS.get(connector.kind)
        if builder is None:
            logger.warning("No tool builder for connector kind '%s'", connector.kind)
            continue

        try:
            built = builder(connector, **context)
        except Exception:
            logger.error(
                "Failed to build tools for connector '%s'", connector.connector_id, exc_info=True
            )
            continue

        for tool in built:
            # Two connectors aliased identically mint the same tool name and the
            # model could not tell them apart. An agent inside an application
            # carries its own connectors and the application's, so this is
            # routine rather than exotic -- and dropping the loser removed a
            # capability the user explicitly attached. Rename instead.
            if tool.name in seen:
                renamed = _unique_tool_name(tool.name, seen)
                if renamed is None:
                    logger.warning(
                        "Connector tool '%s' could not be given a distinct name; "
                        "it is described but not callable this build.", tool.name
                    )
                    continue
                logger.info(
                    "Connector tool name '%s' collided; bound as '%s'",
                    tool.name, renamed,
                )
                try:
                    tool.name = renamed
                except Exception:  # noqa: BLE001 -- immutable tool implementation
                    logger.warning(
                        "Connector tool '%s' could not be renamed; skipped",
                        tool.name, exc_info=True,
                    )
                    continue
            seen.add(tool.name)
            tools.append(tool)

    logger.info("Built %d connector tools from %d attachments", len(tools), len(connectors))
    return tools


__all__ = [
    "build_connector_tools",
    "format_result",
    "new_budget_state",
    "resolve_connector_call_limit",
]
