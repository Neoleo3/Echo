"""
TTL cache with last-known-good fallback, used by connector descriptors.

WHAT: A tiny process-local cache keyed by connector, holding the expensive
      parts of a descriptor -- an MCP server's tool manifest and a database's
      schema summary.
WHY:  ``AgentFactory.build`` runs per invocation, so an uncached descriptor
      would re-probe the MCP server and re-introspect the database on every
      message. ``DatabaseConnectorService.get_full_schema`` additionally runs
      ``SELECT COUNT(*)`` per table, which is far too expensive per turn.

Stale-but-serving is deliberate: when a refresh fails, the previous value is
returned with ``stale=True`` rather than degrading the agent to no context at
all. A connector that has never resolved has no entry and stays unresolved --
the readiness gate (phase 7) is what turns that into a hard failure.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_TTL_SECONDS = 900


@dataclass(frozen=True)
class CacheEntry:
    """A cached value with the wall-clock time it was produced."""

    value: Any
    stored_at: float

    def age_seconds(self) -> float:
        return max(0.0, time.time() - self.stored_at)


class TTLCache:
    """Thread-safe TTL cache. Small by construction: one entry per connector."""

    def __init__(self, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> None:
        self._ttl = max(1, int(ttl_seconds))
        self._entries: Dict[str, CacheEntry] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[CacheEntry]:
        """Return the entry for ``key`` whether or not it is fresh."""
        with self._lock:
            return self._entries.get(key)

    def put(self, key: str, value: Any) -> None:
        with self._lock:
            self._entries[key] = CacheEntry(value=value, stored_at=time.time())

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._entries.pop(key, None)

    def invalidate_prefix(self, prefix: str) -> int:
        """
        Drop every entry whose key starts with ``prefix``. Returns how many.

        For callers that key on more than they can reconstruct at invalidation
        time. The ledger is keyed by application, session *and* caller, but a
        document upload knows only the first two — without this it would have to
        guess the third and would silently fail to invalidate anything.
        """
        with self._lock:
            doomed = [key for key in self._entries if key.startswith(prefix)]
            for key in doomed:
                self._entries.pop(key, None)
            return len(doomed)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()

    def get_or_load(
        self,
        key: str,
        loader: Callable[[], Any],
        *,
        ttl_seconds: Optional[int] = None,
    ) -> Tuple[Optional[Any], bool]:
        """
        Return ``(value, stale)`` for ``key``, loading it when expired.

        WHAT: Serves a fresh entry directly; otherwise calls ``loader`` and
              stores the result.
        WHY:  Descriptor resolution must never raise into the agent build --
              a connector that cannot be described is reported as unresolved,
              not as a crashed agent.
        OUTPUT: ``(None, False)`` when there is nothing to serve and the load
              failed; ``(value, True)`` when a stale value is being served
              because the refresh failed.
        """
        ttl = max(1, int(ttl_seconds or self._ttl))
        entry = self.get(key)
        if entry is not None and entry.age_seconds() < ttl:
            return entry.value, False

        try:
            value = loader()
        except Exception:
            if entry is None:
                logger.warning("Connector cache load failed for '%s'", key, exc_info=True)
                return None, False
            logger.warning(
                "Connector cache refresh failed for '%s'; serving value aged %.0fs",
                key,
                entry.age_seconds(),
                exc_info=True,
            )
            return entry.value, True

        self.put(key, value)
        return value, False


# One cache per expensive descriptor source. Kept module-level because the
# cost being avoided is per-process, not per-request.
MANIFEST_CACHE = TTLCache()
SCHEMA_CACHE = TTLCache()


__all__ = ["CacheEntry", "MANIFEST_CACHE", "SCHEMA_CACHE", "TTLCache", "DEFAULT_TTL_SECONDS"]
