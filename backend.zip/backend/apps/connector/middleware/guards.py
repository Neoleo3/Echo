"""
Guards applied before a connector call leaves the agent.

WHAT: SQL statement classification for database connectors, plus the row and
      timeout caps applied to every query an agent runs.
WHY:  ``DatabaseConnectorService.execute_query`` executes and commits whatever
      it is given -- a model-authored ``DELETE`` would be applied to live data.
      Exposing a database to an agent without this guard is the single largest
      new risk in phase 5, so read-only is the default and writes are opt-in
      per attachment.

Layering, deliberately: this is a filter, not a security boundary. The boundary
is the database credential itself. Statement classification catches the common
case (a model writing DML when asked to read); a least-privilege database role
is what makes it impossible.

``sqlparse`` is used when present but is not a dependency -- environment
changes belong to phase 0. The fallback tokenizer is intentionally strict: it
rejects anything it cannot confidently classify.
"""
from __future__ import annotations

import logging
import re
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

OPERATION_READ = "read"
OPERATION_WRITE = "write"

DEFAULT_ROW_LIMIT = 100
MAX_ROW_LIMIT = 1000
DEFAULT_STATEMENT_TIMEOUT_SECONDS = 30

READ_STATEMENTS = frozenset({"SELECT", "WITH", "SHOW", "DESCRIBE", "DESC", "EXPLAIN"})
WRITE_STATEMENTS = frozenset({"INSERT", "UPDATE", "DELETE", "MERGE", "UPSERT", "REPLACE"})

# Write keywords scanned for anywhere in the statement, so a CTE that fronts an
# INSERT is classified as a write. REPLACE is deliberately absent: it is a
# string function in most dialects and would misclassify ordinary SELECTs.
WRITE_KEYWORDS_IN_BODY = frozenset({"INSERT", "UPDATE", "DELETE", "MERGE", "UPSERT"})

# Never reachable from an agent, under any attachment setting, wherever they
# appear. Schema and permission changes are not a data-access operation, and an
# agent that can issue one can undo every other control here. Keywords that are
# only dangerous as a statement head (SET, CALL, EXEC, COPY, LOAD) are handled
# by the head allow-list instead -- listing them here would reject a column
# legitimately named ``set`` or ``call``.
FORBIDDEN_KEYWORDS = frozenset({
    "DROP", "TRUNCATE", "ALTER", "CREATE", "GRANT", "REVOKE", "ATTACH", "DETACH",
    "VACUUM", "REINDEX", "INSTALL", "SHUTDOWN",
})

# Dialect escapes into the filesystem or the shell.
FORBIDDEN_TOKENS = (
    "pg_read_file", "pg_ls_dir", "lo_import", "lo_export", "xp_cmdshell",
    "sp_configure", "dbms_scheduler", "utl_file", "read_csv_auto", "into outfile",
    "into dumpfile", "load_file",
)

_COMMENT_BLOCK = re.compile(r"/\*.*?\*/", re.DOTALL)
_COMMENT_LINE = re.compile(r"(--|#)[^\n]*")
_WORD = re.compile(r"[A-Za-z_][A-Za-z_0-9$]*")
_LIMIT_CLAUSE = re.compile(r"\blimit\s+\d+", re.IGNORECASE)
_TOP_CLAUSE = re.compile(r"\bselect\s+top\s+\d+", re.IGNORECASE)
_ROWNUM_CLAUSE = re.compile(r"\browq?num\b|\bfetch\s+first\b", re.IGNORECASE)


class SQLGuardError(ValueError):
    """A query was rejected before it reached the database."""


def strip_comments(sql: str) -> str:
    """Remove block and line comments so keywords cannot hide inside them."""
    without_blocks = _COMMENT_BLOCK.sub(" ", sql or "")
    return _COMMENT_LINE.sub(" ", without_blocks)


def split_statements(sql: str) -> List[str]:
    """
    Split a SQL string into statements.

    Uses ``sqlparse`` when available; otherwise splits on semicolons outside
    string literals. Stacked statements are the classic way a read-only filter
    is bypassed, so this only has to be good enough to detect that more than
    one statement is present.
    """
    cleaned = strip_comments(sql).strip()
    if not cleaned:
        return []

    try:
        import sqlparse  # type: ignore

        return [s.strip() for s in sqlparse.split(cleaned) if s.strip()]
    except ImportError:
        pass

    statements: List[str] = []
    buffer: List[str] = []
    quote: Optional[str] = None

    for char in cleaned:
        if quote:
            buffer.append(char)
            if char == quote:
                quote = None
            continue
        if char in ("'", '"', "`"):
            quote = char
            buffer.append(char)
            continue
        if char == ";":
            statement = "".join(buffer).strip()
            if statement:
                statements.append(statement)
            buffer = []
            continue
        buffer.append(char)

    tail = "".join(buffer).strip()
    if tail:
        statements.append(tail)
    return statements


def _keywords(sql: str) -> List[str]:
    """Upper-cased word tokens, with string literals removed."""
    literal_free = re.sub(r"'[^']*'", " ", sql)
    literal_free = re.sub(r'"[^"]*"', " ", literal_free)
    return [match.group(0).upper() for match in _WORD.finditer(literal_free)]


def classify_statement(sql: str) -> str:
    """
    Return ``read``, ``write``, or raise for anything else.

    Classification is by the strongest keyword present rather than by the head,
    so a CTE fronting an ``INSERT`` is a write. Anything whose head is not a
    recognised read or write statement is rejected outright -- that is what
    keeps ``SET``, ``CALL``, ``COPY`` and every other statement type away from
    the database without denylisting words that are valid column names.
    """
    words = _keywords(sql)
    if not words:
        raise SQLGuardError("Empty SQL statement.")

    lowered = sql.lower()
    for token in FORBIDDEN_TOKENS:
        if token in lowered:
            raise SQLGuardError(f"SQL contains a forbidden construct: '{token}'.")

    forbidden = FORBIDDEN_KEYWORDS.intersection(words)
    if forbidden:
        raise SQLGuardError(
            "Schema and permission statements are never permitted from an agent "
            f"(found: {', '.join(sorted(forbidden))})."
        )

    head = words[0]
    if head not in READ_STATEMENTS and head not in WRITE_STATEMENTS:
        raise SQLGuardError(f"Unsupported SQL statement type: '{head}'.")

    if head in WRITE_STATEMENTS or WRITE_KEYWORDS_IN_BODY.intersection(words):
        return OPERATION_WRITE

    return OPERATION_READ


def check_query(sql: str, *, allow_write: bool = False) -> Tuple[str, str]:
    """
    Validate a model-authored query.

    WHAT: Rejects stacked statements, schema/permission statements and, unless
          the attachment opts in, anything that writes.
    WHY:  The database is exposed to an LLM; the query text is untrusted input.
    INPUT: The SQL and whether this attachment permits writes.
    OUTPUT: ``(statement, classification)`` where classification is read/write.
    RAISES: ``SQLGuardError`` with a message written for the model to act on.
    """
    statements = split_statements(sql)
    if not statements:
        raise SQLGuardError("No SQL statement was provided.")
    if len(statements) > 1:
        raise SQLGuardError(
            "Only one SQL statement may be executed per call. "
            "Send a single statement without a trailing semicolon."
        )

    statement = statements[0]
    classification = classify_statement(statement)

    if classification == OPERATION_WRITE and not allow_write:
        raise SQLGuardError(
            "This database connector is read-only. Only SELECT queries are "
            "permitted. Ask the user to enable write access for this connector "
            "if the task genuinely requires it."
        )

    return statement, classification


def resolve_row_limit(requested: object, *, default: int = DEFAULT_ROW_LIMIT) -> int:
    """Clamp a model-supplied row limit into the permitted range."""
    try:
        value = int(requested)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default
    return max(1, min(value, MAX_ROW_LIMIT))


def apply_row_limit(sql: str, *, db_type: str, limit: int) -> str:
    """
    Append a row limit to a read query that does not already bound itself.

    Row capping also happens at fetch time in ``execute_query``; adding the
    clause means the database stops producing rows rather than producing them
    all and discarding the tail. Dialects without ``LIMIT`` (SQL Server, Oracle)
    are left alone -- rewriting their syntax reliably is not worth the risk of
    corrupting a valid query, and the fetch cap still applies.
    """
    statement = sql.strip().rstrip(";").strip()
    dialect = (db_type or "").lower()

    if dialect in ("mssql", "sqlserver", "oracle"):
        return statement
    if _LIMIT_CLAUSE.search(statement) or _TOP_CLAUSE.search(statement) or _ROWNUM_CLAUSE.search(statement):
        return statement
    if not statement.lower().startswith(("select", "with")):
        return statement

    return f"{statement} LIMIT {limit}"


__all__ = [
    "DEFAULT_ROW_LIMIT",
    "DEFAULT_STATEMENT_TIMEOUT_SECONDS",
    "MAX_ROW_LIMIT",
    "OPERATION_READ",
    "OPERATION_WRITE",
    "SQLGuardError",
    "apply_row_limit",
    "check_query",
    "classify_statement",
    "resolve_row_limit",
    "split_statements",
    "strip_comments",
]
