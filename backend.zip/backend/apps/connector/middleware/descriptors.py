"""
Connector descriptors -- what the model is told about each attached connector.

WHAT: Renders one typed block per attached connector: what it is, what it can
      do, and the name of the tool that does it.
WHY:  Descriptor injection is what lets a model select the right operation.
      Without it the model has tool names and no idea which connector answers
      which question, and it invents API calls and column names instead.

Two rules govern everything here:

1. **No secret material.** Auth is described by *type* only. The records these
   are built from are already masked by their services; nothing re-reads a
   credential.
2. **A shared budget.** Descriptors compete for one token allowance across all
   connectors, not one each, because context exhaustion is a property of the
   prompt, not of a connector. What does not fit is reported as an explicit
   omission, never dropped silently -- a model that is told "12 more tables
   exist, call db__sales__list_tables" behaves correctly; one that is shown a
   truncated list believes it has seen everything.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from echolib.connector_permissions import allows_database_write

from . import invoker
from .cache import MANIFEST_CACHE, SCHEMA_CACHE
from .naming import tool_name
from .refs import KIND_API, KIND_DATABASE, KIND_MCP, ResolvedConnector

logger = logging.getLogger(__name__)

# Rough conversion; exact tokenization varies per model and is not worth a
# tokenizer dependency for a budget whose purpose is to bound growth.
CHARS_PER_TOKEN = 4
DEFAULT_TOKEN_BUDGET = 1500
MIN_CHARS_PER_CONNECTOR = 240

MAX_TABLES_LISTED = 25
MAX_COLUMNS_LISTED = 15
MAX_MCP_TOOLS_LISTED = 25
MAX_MCP_RESOURCES_LISTED = 10
MAX_FIELDS_LISTED = 12

HEADER = (
    "Connected data sources. Each one below is attached to you and reachable "
    "through the named tool. Use them to obtain real data; never answer from "
    "the description alone, and never invent an operation that is not listed."
)


def resolve_token_budget() -> int:
    """Read the descriptor token allowance, environment-overridable."""
    try:
        configured = int(os.getenv("CONNECTOR_DESCRIPTOR_TOKEN_BUDGET", str(DEFAULT_TOKEN_BUDGET)))
    except ValueError:
        return DEFAULT_TOKEN_BUDGET
    return max(200, configured)


def _truncate(text: str, max_chars: int, *, marker: str = "\n… description truncated") -> str:
    if len(text) <= max_chars:
        return text
    keep = max(0, max_chars - len(marker))
    return text[:keep].rstrip() + marker


def _clean(value: Any, limit: int = 200) -> str:
    text = str(value or "").strip().replace("\n", " ")
    return text[:limit]


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def _describe_api(connector: ResolvedConnector) -> List[str]:
    record: Mapping[str, Any] = connector.record or {}
    lines = [
        f"- Tool: `{tool_name(KIND_API, connector.alias)}`",
        f"- Call: {str(record.get('method', 'GET')).upper()} {_clean(record.get('endpoint_url'), 300)}",
    ]

    description = _clean(record.get("description"), 300)
    if description:
        lines.insert(0, f"- Purpose: {description}")

    query_params = record.get("query_params")
    if isinstance(query_params, dict) and query_params:
        names = list(query_params.keys())[:MAX_FIELDS_LISTED]
        lines.append(f"- Query parameters: {', '.join(str(n) for n in names)}")

    body = record.get("default_body")
    if isinstance(body, dict) and body:
        names = list(body.keys())[:MAX_FIELDS_LISTED]
        lines.append(f"- Body fields: {', '.join(str(n) for n in names)}")

    auth_type = _clean(record.get("auth_type"), 40) or "none"
    lines.append(f"- Auth: {auth_type} (applied server-side; you never supply credentials)")

    status = _clean(record.get("status"), 40)
    if status and status != "tested":
        lines.append(f"- Status: {status}")

    return lines


# ---------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------

def _mcp_manifest(connector: ResolvedConnector) -> Dict[str, Any]:
    """
    Read the server's advertised manifest.

    Served from the connector record, which the MCP service refreshes on
    create, update and ``refresh_discovery``. Cached per connector so repeated
    builds inside one conversation do not re-read it.
    """

    def _load() -> Dict[str, Any]:
        discovery = (connector.record or {}).get("discovery") or {}
        return {
            "tools": [t for t in discovery.get("tools", []) if isinstance(t, dict)],
            "resources": [r for r in discovery.get("resources", []) if isinstance(r, dict)],
        }

    manifest, stale = MANIFEST_CACHE.get_or_load(f"mcp:{connector.connector_id}", _load)
    if stale:
        logger.info("Serving stale MCP manifest for '%s'", connector.connector_id)
    return manifest or {"tools": [], "resources": []}


def mcp_tool_selection(
    connector: ResolvedConnector,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Split a server's tools into those this attachment exposes and those it withholds.

    The split comes from ``permitted_operations()`` -- the same set the invoker
    authorizes against -- so a tool can never be offered to the model and then
    refused at the call, or withheld here and reachable there.
    """
    tools = [t for t in _mcp_manifest(connector).get("tools", []) if isinstance(t, dict)]
    permitted = set(connector.permitted_operations())

    exposed = [t for t in tools if str(t.get("name") or "").strip() in permitted]
    withheld = [
        t for t in tools
        if str(t.get("name") or "").strip() and str(t.get("name")).strip() not in permitted
    ]
    return exposed, withheld


def allowed_mcp_tools(connector: ResolvedConnector) -> List[Dict[str, Any]]:
    """Discovered MCP tools this attachment exposes, in manifest order."""
    return mcp_tool_selection(connector)[0]


def _describe_mcp(connector: ResolvedConnector) -> List[str]:
    record: Mapping[str, Any] = connector.record or {}
    manifest = _mcp_manifest(connector)
    tools, withheld = mcp_tool_selection(connector)
    resources = manifest.get("resources", [])

    lines: List[str] = []
    description = _clean(record.get("description"), 300)
    if description:
        lines.append(f"- Purpose: {description}")

    transport = _clean(record.get("transport_type"), 40)
    if transport:
        lines.append(f"- Transport: {transport}")

    if tools:
        lines.append(f"- Tools ({len(tools)}):")
        for tool in tools[:MAX_MCP_TOOLS_LISTED]:
            name = _clean(tool.get("name"), 80)
            summary = _clean(tool.get("description"), 160)
            call_name = tool_name(KIND_MCP, connector.alias, name)
            lines.append(f"  - `{call_name}`{' — ' + summary if summary else ''}")
        if len(tools) > MAX_MCP_TOOLS_LISTED:
            lines.append(f"  - … {len(tools) - MAX_MCP_TOOLS_LISTED} more tools not shown.")
    elif withheld:
        lines.append("- Tools: none enabled for you on this server.")
    else:
        lines.append("- Tools: none advertised by this server.")

    if withheld:
        names = ", ".join(_clean(t.get("name"), 60) for t in withheld[:MAX_MCP_TOOLS_LISTED])
        lines.append(
            f"- Not enabled ({len(withheld)}): {names}. This agent's access level for this "
            "connector does not include them. Do not claim to have used them; say the user "
            "needs to raise the access level or enable the tool."
        )

    if resources:
        listed = [_clean(r.get("uri"), 120) for r in resources[:MAX_MCP_RESOURCES_LISTED]]
        lines.append(
            f"- Resources ({len(resources)}): {', '.join(u for u in listed if u)}"
            f" — read with `{tool_name(KIND_MCP, connector.alias, 'read_resource')}`"
        )
        if len(resources) > MAX_MCP_RESOURCES_LISTED:
            lines.append(f"  - … {len(resources) - MAX_MCP_RESOURCES_LISTED} more resources not shown.")

    return lines


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db_schema(connector: ResolvedConnector) -> Optional[Dict[str, Any]]:
    """
    Read the database's schema summary, cached.

    ``get_full_schema`` runs ``SELECT COUNT(*)`` per table, so it is far too
    expensive to run per agent build; the cache is what makes a database
    connector usable on a conversational turn.
    """
    schema, stale = SCHEMA_CACHE.get_or_load(
        f"db:{connector.connector_id}",
        lambda: invoker.db_full_schema(connector.connector_id),
    )
    if stale:
        logger.info("Serving stale database schema for '%s'", connector.connector_id)
    return schema


def _format_table(table: Mapping[str, Any]) -> str:
    name = _clean(table.get("table_name"), 80)
    columns = table.get("columns") or []
    rendered: List[str] = []
    for column in columns[:MAX_COLUMNS_LISTED]:
        if not isinstance(column, dict):
            continue
        col_name = _clean(column.get("name"), 60)
        col_type = _clean(column.get("type"), 30)
        rendered.append(f"{col_name} {col_type}".strip())
    if len(columns) > MAX_COLUMNS_LISTED:
        rendered.append(f"… +{len(columns) - MAX_COLUMNS_LISTED} columns")

    row_count = table.get("row_count")
    suffix = f" [~{row_count} rows]" if isinstance(row_count, int) else ""
    return f"  - {name}({', '.join(rendered)}){suffix}"


def _describe_database(connector: ResolvedConnector) -> List[str]:
    record: Mapping[str, Any] = connector.record or {}
    alias = connector.alias
    writable = allows_database_write(connector.permitted_operations())

    lines = [
        f"- Type: {_clean(record.get('db_type'), 40) or 'unknown'}",
        f"- Tools: `{tool_name(KIND_DATABASE, alias, 'list_tables')}`, "
        f"`{tool_name(KIND_DATABASE, alias, 'get_schema')}`, "
        f"`{tool_name(KIND_DATABASE, alias, 'query')}`",
        "- Access: read-only; only SELECT queries are accepted"
        if not writable
        else "- Access: read and write enabled for this connector",
    ]

    schema = _db_schema(connector)
    if not schema:
        lines.append(
            "- Schema: not available right now; call the list_tables tool before querying."
        )
        return lines

    tables = [t for t in schema.get("tables", []) if isinstance(t, dict)]
    if not tables:
        lines.append("- Schema: no tables found.")
        return lines

    lines.append(f"- Tables ({len(tables)}):")
    lines.extend(_format_table(table) for table in tables[:MAX_TABLES_LISTED])
    if len(tables) > MAX_TABLES_LISTED:
        lines.append(
            f"  - … {len(tables) - MAX_TABLES_LISTED} more tables not shown; "
            f"call `{tool_name(KIND_DATABASE, alias, 'list_tables')}` for the full list."
        )

    views = schema.get("views") or []
    if views:
        lines.append(f"- Views: {len(views)}")

    return lines


# ---------------------------------------------------------------------------
# Assembly
# ---------------------------------------------------------------------------

_RENDERERS = {
    KIND_API: _describe_api,
    KIND_MCP: _describe_mcp,
    KIND_DATABASE: _describe_database,
}

_KIND_LABELS = {
    KIND_API: "API connector",
    KIND_MCP: "MCP server",
    KIND_DATABASE: "database connector",
}


def describe_connector(connector: ResolvedConnector) -> str:
    """Render one connector's descriptor block. Never raises."""
    label = _KIND_LABELS.get(connector.kind, "connector")
    heading = f"### {connector.name} ({label})"

    if not connector.resolved:
        return f"{heading}\n- Unavailable: {connector.error}. Do not claim to have used it."

    try:
        lines = _RENDERERS[connector.kind](connector)
    except Exception:
        logger.warning(
            "Descriptor rendering failed for '%s'", connector.connector_id, exc_info=True
        )
        return f"{heading}\n- Description unavailable; call its tools to discover what it offers."

    return "\n".join([heading, *lines])


def describe_connectors(
    connectors: Sequence[ResolvedConnector],
    *,
    token_budget: Optional[int] = None,
) -> str:
    """
    Render the connector context block for an agent's system prompt.

    WHAT: One block per connector, bounded by a shared token budget.
    WHY:  Spec section 4.3 and the plan's context-window risk: descriptors are
          the largest new contribution to prompt size, and a wide database or
          a large MCP manifest would otherwise crowd out the instructions.
    INPUT: Resolved connectors and an optional budget override.
    OUTPUT: A markdown block, or an empty string when nothing is attached.

    Budget is shared, not per connector: each gets an equal slice of what
    remains, so a small API descriptor leaves more room for a wide schema.
    """
    if not connectors:
        return ""

    budget_chars = (token_budget or resolve_token_budget()) * CHARS_PER_TOKEN
    blocks: List[str] = []
    omitted = 0
    remaining = budget_chars

    for index, connector in enumerate(connectors):
        left = len(connectors) - index
        share = max(MIN_CHARS_PER_CONNECTOR, remaining // left) if left else remaining
        if remaining < MIN_CHARS_PER_CONNECTOR:
            omitted = left
            break

        block = _truncate(describe_connector(connector), min(share, remaining))
        blocks.append(block)
        remaining -= len(block)

    if omitted:
        blocks.append(
            f"### {omitted} further connector(s) not described here\n"
            "- They are still attached and their tools are still callable; ask the "
            "user which one to use if the choice is unclear."
        )

    logger.info(
        "Connector descriptors: %d rendered, %d omitted, %d chars of %d budget",
        len(blocks) - (1 if omitted else 0), omitted, budget_chars - remaining, budget_chars,
    )
    return "\n\n".join([HEADER, *blocks])


__all__ = [
    "CHARS_PER_TOKEN",
    "DEFAULT_TOKEN_BUDGET",
    "allowed_mcp_tools",
    "mcp_tool_selection",
    "describe_connector",
    "describe_connectors",
    "resolve_token_budget",
]
