"""
Resolve an agent's connector attachments into live, sanitized records.

WHAT: Turns ``definition.connectors[]`` entries into ``ResolvedConnector``
      objects carrying the connector's current record, scoped to the owning
      user.
WHY:  Descriptor rendering and runtime invocation both need the same
      resolution, done once per build, with the same ownership check. Doing it
      in two places is how a connector ends up described but not callable.

Every lookup is user-scoped at the service layer, so an attachment pointing at
another user's connector resolves to ``None`` and is reported as unresolved
rather than silently executing.

No secret material is carried: the API and MCP services mask their records, and
the database service returns a masked connection string.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple

from apps.tool.async_bridge import run_async
from echolib.agent_contract import CONNECTOR_KIND_ALIASES, attached_connectors
from echolib.connector_permissions import (
    DEFAULT_ACCESS_LEVEL,
    effective_operations,
    normalize_access_level,
)

logger = logging.getLogger(__name__)

KIND_API = "api"
KIND_MCP = "mcp"
KIND_DATABASE = "database"

RESOLUTION_TIMEOUT_SECONDS = 30


@dataclass(frozen=True)
class ResolvedConnector:
    """One attached connector, resolved against its owning service."""

    connector_id: str
    kind: str
    alias: str
    allowed_operations: Tuple[str, ...] = ()
    record: Mapping[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    access_level: str = DEFAULT_ACCESS_LEVEL
    # The user whose ownership authorised this attachment, carried from
    # resolution to invocation. ``APIConnectorService.invoke`` and
    # ``MCPConnectorService.invoke_async`` scope by user exactly as their
    # lookups do, so a connector resolved under its owner and then *called*
    # under the caller would be found at build time and fail at run time --
    # a tool the model can see and cannot use. Both halves read this.
    principal_user_id: str = ""
    # ``"application"`` when this attachment was lent by an application for this
    # turn, empty when it is the agent's own. Carried so a build can report what
    # each half contributed instead of one undifferentiated count.
    origin: str = ""

    @property
    def resolved(self) -> bool:
        return self.error is None and bool(self.record)

    @property
    def name(self) -> str:
        """Display name from the record, falling back to the attachment alias."""
        for key in ("name", "connector_name"):
            value = self.record.get(key) if isinstance(self.record, Mapping) else None
            if isinstance(value, str) and value.strip():
                return value.strip()
        return self.alias

    def discovered_tools(self) -> List[Mapping[str, Any]]:
        """The MCP tools this server currently advertises. Empty for other kinds."""
        if self.kind != KIND_MCP:
            return []
        discovery = (self.record or {}).get("discovery") or {}
        return [t for t in (discovery.get("tools") or []) if isinstance(t, Mapping)]

    def has_resources(self) -> bool:
        """True when the MCP server advertises readable resources."""
        if self.kind != KIND_MCP:
            return False
        discovery = (self.record or {}).get("discovery") or {}
        return bool(discovery.get("resources"))

    def permitted_operations(self) -> List[str]:
        """
        The operations this attachment may actually perform.

        Computed once from the access level and the connector's *current*
        capabilities, or taken verbatim from ``allowed_operations`` when the
        user named tools explicitly. Every consumer -- descriptors, tool
        construction and the invoker -- reads this rather than re-deriving its
        own answer, so a permission decision is made in one place.
        """
        return effective_operations(
            self.kind,
            access_level=self.access_level,
            allowed_operations=self.allowed_operations,
            tools=self.discovered_tools(),
            has_resources=self.has_resources(),
        )

    def allows(self, operation: str) -> bool:
        """True when ``operation`` is inside this attachment's permission set."""
        wanted = str(operation or "").strip()
        permitted = self.permitted_operations()
        if wanted in permitted:
            return True
        return wanted.lower() in {op.lower() for op in permitted}


def _api_service() -> Any:
    from echolib.connectors.api_service import APIConnectorService

    return APIConnectorService()


def _mcp_service() -> Any:
    from echolib.mcp.service import MCPConnectorService

    return MCPConnectorService()


def _db_service() -> Any:
    """
    Return the database connector service.

    Constructed per call rather than cached: ``__init__`` loads the connection
    table, which is how a connection created after process start becomes
    visible. This mirrors every other caller in the codebase.
    """
    from apps.connector.db_connector import DatabaseConnectorService

    return DatabaseConnectorService()


def _fetch_api_record(connector_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    return run_async(
        _api_service().get(connector_id, user_id=user_id),
        timeout=RESOLUTION_TIMEOUT_SECONDS,
    )


def _fetch_mcp_record(connector_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    return run_async(
        _mcp_service().get_async(connector_id, user_id=user_id),
        timeout=RESOLUTION_TIMEOUT_SECONDS,
    )


def _fetch_db_record(connector_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    return _db_service().get_connection(connector_id, user_id=user_id)


_FETCHERS = {
    KIND_API: _fetch_api_record,
    KIND_MCP: _fetch_mcp_record,
    KIND_DATABASE: _fetch_db_record,
}


def _infer_kind(connector_id: str, user_id: str) -> Tuple[str, Optional[Dict[str, Any]]]:
    """
    Determine a connector's kind by probing each service in turn.

    Only used when the attachment does not record one -- entries written before
    the contract normalized ``kind``. Ordered cheapest-lookup-last so the
    database service (which reloads its table on construction) is tried once.
    """
    for kind in (KIND_API, KIND_MCP, KIND_DATABASE):
        try:
            record = _FETCHERS[kind](connector_id, user_id)
        except Exception:
            logger.debug("Kind probe failed for '%s' as %s", connector_id, kind, exc_info=True)
            continue
        if record:
            return kind, record
    return "", None


def resolve_connector(entry: Mapping[str, Any], user_id: str) -> ResolvedConnector:
    """
    Resolve one attachment entry against its owning service.

    WHAT: Fetches the live connector record for the attachment.
    WHY:  A descriptor built from the attachment alone would describe a
          connector that may have been deleted, disabled, or never belonged to
          this user.
    INPUT: A normalized ``definition.connectors[]`` entry and the **principal**
           whose ownership authorises it -- the agent's owner for the agent's
           own attachments, the application's owner for one it lent. This is
           not necessarily whoever is chatting; see ``resolve_agent_connectors``.
    OUTPUT: A ``ResolvedConnector``; failures are carried in ``error``, never
            raised, so one bad attachment cannot fail an agent build. The
            principal is carried on the result so invocation uses the same
            identity the lookup did.
    """
    connector_id = str(entry.get("connector_id") or "").strip()
    alias = str(entry.get("alias") or connector_id).strip() or connector_id
    kind = CONNECTOR_KIND_ALIASES.get(str(entry.get("kind") or "").lower(), "")
    allowed = tuple(
        str(op).strip() for op in (entry.get("allowed_operations") or []) if str(op).strip()
    )
    level = normalize_access_level(entry.get("access_level"))

    if not connector_id:
        return ResolvedConnector(
            "", kind, alias, allowed, {}, "attachment has no connector_id", level
        )

    if not user_id:
        return ResolvedConnector(
            connector_id, kind, alias, allowed, {},
            "no user context available for connector resolution", level,
        )

    try:
        if kind in _FETCHERS:
            record = _FETCHERS[kind](connector_id, user_id)
        else:
            kind, record = _infer_kind(connector_id, user_id)
    except Exception as exc:
        logger.warning("Connector '%s' could not be resolved: %s", connector_id, exc, exc_info=True)
        return ResolvedConnector(connector_id, kind, alias, allowed, {}, str(exc), level)

    if not record:
        return ResolvedConnector(
            connector_id, kind, alias, allowed, {},
            "connector not found for this user", level,
        )

    origin = str(entry.get("origin") or "").lower()

    if kind == KIND_API and not record.get("enabled", True):
        return ResolvedConnector(
            connector_id, kind, alias, allowed, record, "connector is disabled", level,
            str(user_id), origin,
        )

    return ResolvedConnector(
        connector_id, kind, alias, allowed, record, None, level, str(user_id), origin
    )


def _on_event_loop() -> bool:
    """True when the calling thread is running an asyncio event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True


def resolve_agent_connectors(
    agent_config: Optional[Mapping[str, Any]],
    user_id: Optional[str],
    *,
    owner_user_id: Optional[str] = None,
) -> List[ResolvedConnector]:
    """
    Resolve every connector attached to an agent.

    Returns an empty list when Connector Settings is off for the agent -- the
    gate lives in the contract (``attached_connectors``) so no caller can skip
    it.

    ``user_id`` is the caller; ``owner_user_id`` is the principal whose
    ownership authorises the attachment. Each connector service scopes its
    lookup by user, so resolving under the caller made every connector an agent
    author attached invisible to anyone else running that agent -- reported as
    "connector not found for this user" and bound as no tool at all. An
    attachment the *application* lent carries its own ``owner_user_id`` and
    resolves under the application's owner. Omitting ``owner_user_id`` falls
    back to the caller, which is correct wherever the two are the same.

    Must not be called from a thread that is running an event loop: API and MCP
    records are read through async services, and awaiting them from the loop
    thread would block the very loop the coroutine needs. Rather than hang for
    the resolution timeout, that case fails immediately with a message naming
    the fix, so a mis-wired call site is a log line and a visible descriptor
    rather than a stalled request.
    """
    entries = attached_connectors(dict(agent_config or {}))
    if not entries:
        return []

    if _on_event_loop():
        logger.error(
            "Connector resolution was called on the event loop thread. Build the "
            "agent inside asyncio.to_thread() -- the agent build is synchronous and "
            "blocks the loop for the whole model round trip regardless."
        )
        return [
            ResolvedConnector(
                str(entry.get("connector_id") or ""),
                str(entry.get("kind") or ""),
                str(entry.get("alias") or entry.get("connector_id") or ""),
                tuple(entry.get("allowed_operations") or ()),
                {},
                "connector resolution is unavailable on this execution path",
                normalize_access_level(entry.get("access_level")),
            )
            for entry in entries
        ]

    from echolib.agent_contract import ORIGIN_APPLICATION

    def _principal(entry: Mapping[str, Any]) -> str:
        """The user whose ownership authorises this one attachment."""
        if str(entry.get("origin") or "").lower() == ORIGIN_APPLICATION:
            # Lent by an application: its owner authorised it. A contribution
            # serialized before the owner travelled with it falls back to the
            # caller, which is what it did before.
            return str(entry.get("owner_user_id") or user_id or "")
        return str(owner_user_id or user_id or "")

    resolved = [resolve_connector(entry, _principal(entry)) for entry in entries]

    unresolved = [c for c in resolved if not c.resolved]
    if unresolved:
        logger.warning(
            "%d of %d attached connectors did not resolve: %s",
            len(unresolved),
            len(resolved),
            ", ".join(f"{c.alias}({c.error})" for c in unresolved),
        )
    return resolved


__all__ = [
    "KIND_API",
    "KIND_DATABASE",
    "KIND_MCP",
    "ResolvedConnector",
    "resolve_agent_connectors",
    "resolve_connector",
]
