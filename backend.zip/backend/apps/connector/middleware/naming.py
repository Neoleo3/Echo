"""
Tool naming for connector-backed tools.

WHAT: Derives the stable, model-visible tool name for each connector operation.
WHY:  The descriptor tells the model what a connector is; the tool name is how
      it calls it. Both are generated here so a descriptor can never reference
      a tool name the tool layer did not register.

Names are derived from the attachment alias, not the connector's display name,
so renaming a connector does not change the tool the model was told about
mid-conversation.
"""
from __future__ import annotations

import re

MAX_SLUG_LENGTH = 24
MAX_TOOL_NAME_LENGTH = 64

_UNSAFE = re.compile(r"[^0-9A-Za-z]+")


def slugify(value: str, *, max_length: int = MAX_SLUG_LENGTH) -> str:
    """Reduce arbitrary text to a lower-case identifier fragment."""
    cleaned = _UNSAFE.sub("_", str(value or "")).strip("_").lower()
    cleaned = re.sub(r"_+", "_", cleaned)
    return cleaned[:max_length].strip("_") or "connector"


def tool_name(kind: str, alias: str, operation: str = "") -> str:
    """
    Build the tool name for one connector operation.

    ``api__crm``, ``mcp__files__read_file``, ``db__sales__query``.
    """
    prefix = {"api": "api", "mcp": "mcp", "database": "db"}.get(kind, "conn")
    parts = [prefix, slugify(alias)]
    if operation:
        parts.append(slugify(operation, max_length=32))
    return "__".join(parts)[:MAX_TOOL_NAME_LENGTH]


__all__ = ["MAX_TOOL_NAME_LENGTH", "slugify", "tool_name"]
