"""
Attach-time permission validation.

WHAT: The checks that need a connector's live capabilities -- validating that
      an MCP allow-list names tools the server actually advertises, and
      validating an access level -- plus the app-facing re-export of the shared
      permission vocabulary.
WHY:  The vocabulary itself (levels, classification, expansion, per-kind
      operations) lives in ``echolib.connector_permissions`` because the
      persistence boundary in ``echolib.agent_contract`` has to enforce it and
      must not import from ``apps.*``. What belongs here is only the part that
      needs discovery data.

The layering, deliberately:

    echolib.connector_permissions   the vocabulary. Pure. Enforced on every
                                    write by the agent contract.
    this module                     attach-time validation against a live
                                    connector, where a wrong value can still be
                                    reported to the caller as a 422.
    refs.ResolvedConnector          expansion into one permission set per
                                    attachment.
    invoker                         authorization at the moment of the call.

Nothing else makes a permission decision.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from echolib.connector_permissions import (
    ACCESS_DESTRUCTIVE,
    ACCESS_LEVELS,
    ACCESS_READ,
    ACCESS_WRITE,
    API_OPERATIONS,
    DATABASE_OPERATIONS,
    DEFAULT_ACCESS_LEVEL,
    LEVEL_FULL_ACCESS,
    LEVEL_READ_ONLY,
    LEVEL_READ_WRITE,
    MCP_RESOURCE_OPERATION,
    InvalidAccessLevelError,
    InvalidOperationsError,
    classify_mcp_tool,
    clean_operations,
    describe_mcp_operations,
    effective_operations,
    expand_access_level,
    normalize_access_level,
    validate_access_level,
)
from echolib.connector_permissions import KIND_API, KIND_DATABASE, KIND_MCP

logger = logging.getLogger(__name__)


def split_mcp_tools(
    tools: Sequence[Mapping[str, Any]]
) -> Tuple[List[Mapping[str, Any]], List[Mapping[str, Any]]]:
    """Partition discovered tools into (read-shaped, everything that changes data)."""
    read: List[Mapping[str, Any]] = []
    changing: List[Mapping[str, Any]] = []
    for tool in tools or []:
        (read if classify_mcp_tool(tool) == ACCESS_READ else changing).append(tool)
    return read, changing


def selected_mcp_tools(
    tools: Sequence[Mapping[str, Any]],
    *,
    access_level: Any = DEFAULT_ACCESS_LEVEL,
    allowed_operations: Optional[Sequence[str]] = None,
) -> Tuple[List[Mapping[str, Any]], List[Mapping[str, Any]]]:
    """
    Split a server's tools into exposed and withheld for one attachment.

    Kept as a standalone helper so a caller holding a raw tool list -- the
    connector picker, for instance -- can preview what a level would produce
    without constructing a ``ResolvedConnector``.
    """
    permitted = set(
        effective_operations(
            KIND_MCP,
            access_level=access_level,
            allowed_operations=allowed_operations,
            tools=tools,
        )
    )
    named = [t for t in (tools or []) if str(t.get("name") or "").strip()]
    exposed = [t for t in named if str(t.get("name")).strip() in permitted]
    withheld = [t for t in named if str(t.get("name")).strip() not in permitted]
    return exposed, withheld


def validate_allowed_operations(
    kind: str,
    values: Optional[Sequence[str]],
    *,
    mcp_tool_names: Optional[Sequence[str]] = None,
) -> List[str]:
    """
    Validate an attachment's explicit ``allowed_operations``.

    WHAT: Returns the cleaned list, or raises with the legal values named.
    WHY:  The field is polymorphic by kind. Without validation a wrong value is
          only discovered when an agent runs and a call is refused, and the
          contract would have stored a grant nothing can interpret.
    INPUT: The connector kind, the requested values, and -- for MCP -- the tool
           names the server currently advertises.
    RAISES: ``InvalidOperationsError`` naming the legal values.
    """
    cleaned = [str(v).strip() for v in (values or []) if str(v).strip()]
    if not cleaned:
        return []

    deduped = list(dict.fromkeys(cleaned))

    if kind in (KIND_API, KIND_DATABASE):
        return clean_operations(kind, deduped, strict=True)[0]

    if kind == KIND_MCP:
        if mcp_tool_names is None:
            # Discovery unavailable: accept, so a temporarily unreachable server
            # cannot block configuration. The invoker still authorizes each call
            # against the manifest it loads at build time.
            logger.info("MCP tool names unavailable; accepting allowed_operations unvalidated")
            return deduped

        known = {str(n).strip().lower() for n in mcp_tool_names if str(n).strip()}
        known.add(MCP_RESOURCE_OPERATION)
        invalid = [v for v in deduped if v.lower() not in known]
        if invalid:
            raise InvalidOperationsError(
                f"Unknown MCP tool(s) {invalid} for this connector. allowed_operations must name "
                f"tools the server advertises. Available: {sorted(known)}."
            )
        return deduped

    raise InvalidOperationsError(f"Unknown connector kind '{kind}'.")


def preview_access_levels(
    kind: str,
    tools: Optional[Sequence[Mapping[str, Any]]] = None,
    *,
    has_resources: bool = False,
) -> Dict[str, List[str]]:
    """
    What each access level would permit for this connector, right now.

    Lets the attach API show a user the consequence of a level before they
    choose it, instead of describing it in prose that can drift from the code.
    """
    return {
        level: expand_access_level(kind, level, tools=tools, has_resources=has_resources)
        for level in ACCESS_LEVELS
    }


__all__ = [
    "ACCESS_DESTRUCTIVE",
    "ACCESS_LEVELS",
    "ACCESS_READ",
    "ACCESS_WRITE",
    "API_OPERATIONS",
    "DATABASE_OPERATIONS",
    "DEFAULT_ACCESS_LEVEL",
    "InvalidAccessLevelError",
    "InvalidOperationsError",
    "LEVEL_FULL_ACCESS",
    "LEVEL_READ_ONLY",
    "LEVEL_READ_WRITE",
    "MCP_RESOURCE_OPERATION",
    "classify_mcp_tool",
    "describe_mcp_operations",
    "effective_operations",
    "expand_access_level",
    "normalize_access_level",
    "preview_access_levels",
    "selected_mcp_tools",
    "split_mcp_tools",
    "validate_access_level",
    "validate_allowed_operations",
]
