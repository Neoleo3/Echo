"""
Marketplace DI registrations.
"""

from echolib.di import container

from echolib.marketplace.service import MarketplaceService


container.register_factory(
    "marketplace.service",
    lambda: MarketplaceService(),
)