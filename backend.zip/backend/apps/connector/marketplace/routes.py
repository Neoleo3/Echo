from fastapi import APIRouter, HTTPException

from echolib.marketplace.models import (
    MarketplaceTemplateCreateRequest,
    MarketplaceTemplateUpdateRequest,
    MarketplaceProvisionRequest,
)

from echolib.marketplace.service import (
    MarketplaceService,
)
from fastapi import APIRouter, Depends
from echolib.security import get_current_user, resolve_user_id, require_user
from echolib.types import UserContext
router = APIRouter(
    prefix="/marketplace",
    tags=["Marketplace"],
)

service = MarketplaceService()
@router.post(
    "/templates",
)
async def create_template(
    request: MarketplaceTemplateCreateRequest,
):
    try:
        return await service.create_template(
            request,
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

@router.get(
    "/templates",
)
async def list_templates(
    connector_type: str | None = None,
):
    return await service.list_templates(
        connector_type=connector_type,
    )

@router.get(
    "/templates/{template_id}",
)
async def get_template(
    template_id: str,
):
    template = await service.get_template(
        template_id,
    )

    if not template:

        raise HTTPException(
            status_code=404,
            detail="Template not found",
        )

    return template

@router.put(
    "/templates/{template_id}",
)
async def update_template(
    template_id: str,
    request: MarketplaceTemplateUpdateRequest,
):
    try:

        return await service.update_template(
            template_id,
            request,
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        )

@router.delete(
    "/templates/{template_id}",
)
async def delete_template(
    template_id: str,
):
    try:

        return await service.delete_template(
            template_id,
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        )

@router.post(
    "/templates/{template_id}/use",
)
async def use_template(
    template_id: str,
    request: MarketplaceProvisionRequest,
    user: UserContext = Depends(require_user),
):
    try:

        return await service.provision_connector(
            template_id=template_id,
            inputs=request.inputs,
            user_id=resolve_user_id(user)
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

