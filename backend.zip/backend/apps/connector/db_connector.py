"""
Universal Database Connector Service
=====================================
Supports connecting to any SQL database — both **public** (direct) and
**private** (SSH tunnel through a bastion/jump host).

Supported databases:
  PostgreSQL · MySQL · MariaDB · Microsoft SQL Server · Oracle
  SQLite · Google BigQuery · Snowflake · ClickHouse · Amazon Redshift

Frontend form fields (matches UI):
  Database Type  ·  Host  ·  Port  ·  Database Name
  Username  ·  Password  ·  [Server IP shown for firewall rules]
"""

import json
import logging
import os
import re
import socket
import uuid
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus, urlparse, parse_qs, unquote

import httpx
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Engine
from sqlalchemy.engine.url import make_url
import pyodbc

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Persistence – PostgreSQL
# ---------------------------------------------------------------------------
from echolib.config import settings as _echo_settings

_pg_sync_engine: Optional[Engine] = None


def _get_pg_sync_url() -> str:
    """Convert the async DATABASE_URL to a synchronous psycopg2 URL.

    Also normalises the ``ssl`` query parameter to ``sslmode`` because
    psycopg2 does not recognise ``ssl`` as a valid libpq connection
    option (asyncpg accepts it, but psycopg2/libpq expects ``sslmode``).
    """
    url = _echo_settings.database_url
    if "+asyncpg" in url:
        url = url.replace("+asyncpg", "+psycopg2")
    elif url.startswith("postgresql://"):
        url = url.replace("postgresql://", "postgresql+psycopg2://", 1)

    # Normalise ?ssl=<value> → ?sslmode=<value> for psycopg2/libpq compat
    parsed = urlparse(url)
    if parsed.query:
        from urllib.parse import parse_qs, urlencode
        params = parse_qs(parsed.query, keep_blank_values=True)
        if "ssl" in params and "sslmode" not in params:
            params["sslmode"] = params.pop("ssl")
            new_query = urlencode(params, doseq=True)
            url = parsed._replace(query=new_query).geturl()

    return url


def _get_pg_engine() -> Engine:
    """Get or create a synchronous PostgreSQL engine for DB-connection persistence."""
    global _pg_sync_engine
    if _pg_sync_engine is not None:
        return _pg_sync_engine

    _pg_sync_engine = create_engine(
        _get_pg_sync_url(), pool_pre_ping=True, pool_size=2, max_overflow=3
    )
    return _pg_sync_engine

# When creating a connection with this name, use this fixed connection_id (for ITSM DB default)
ITSM_CONNECTION_NAME = "MSSQL-ITSM"
ITSM_DEFAULT_CONNECTION_ID = "9eb2583a"

# When creating a connection with this name, use this fixed connection_id (for CRM DB default)
CRM_CONNECTION_NAME = "CRM-DB"
CRM_DEFAULT_CONNECTION_ID = "3cf29b94"

# ---------------------------------------------------------------------------
# Supported database types  (drives the "Database Type" dropdown)
# ---------------------------------------------------------------------------
DB_TYPES: Dict[str, Dict[str, Any]] = {
    "postgresql": {
        "label": "PostgreSQL",
        "default_port": 5432,
        "driver": "postgresql+psycopg2",
        "drivers_available": [
            "postgresql+psycopg2",
            "postgresql+asyncpg",
            "postgresql+pg8000",
        ],
        "placeholder_host": "db.example.com",
    },
    "mysql": {
        "label": "MySQL",
        "default_port": 3306,
        "driver": "mysql+pymysql",
        "drivers_available": ["mysql+pymysql", "mysql+mysqlconnector"],
        "placeholder_host": "db.example.com",
    },
    "mariadb": {
        "label": "MariaDB",
        "default_port": 3306,
        "driver": "mariadb+pymysql",
        "drivers_available": ["mariadb+pymysql"],
        "placeholder_host": "db.example.com",
    },
    "mssql": {
        "label": "Microsoft SQL Server",
        "default_port": 1433,
        "driver": "mssql+pymssql",
        "drivers_available": ["mssql+pymssql", "mssql+pyodbc"],
        "placeholder_host": "sqlserver.example.com",
    },
    "oracle": {
        "label": "Oracle",
        "default_port": 1521,
        "driver": "oracle+oracledb",
        "drivers_available": ["oracle+oracledb", "oracle+cx_oracle"],
        "placeholder_host": "oracle.example.com",
    },
    "sqlite": {
        "label": "SQLite",
        "default_port": None,
        "driver": "sqlite",
        "drivers_available": ["sqlite"],
        "placeholder_host": "(upload DB file)",
        "supports_file_upload": True,
    },
    "bigquery": {
        "label": "Google BigQuery",
        "default_port": None,
        "driver": "bigquery",
        "drivers_available": ["bigquery"],
        "placeholder_host": "project-id",
    },
    "snowflake": {
        "label": "Snowflake",
        "default_port": 443,
        "driver": "snowflake",
        "drivers_available": ["snowflake"],
        "placeholder_host": "account.snowflakecomputing.com",
    },
    "clickhouse": {
        "label": "ClickHouse",
        "default_port": 9000,
        "driver": "clickhouse+native",
        "drivers_available": ["clickhouse+native", "clickhouse+http"],
        "placeholder_host": "localhost",
    },
    "redshift": {
        "label": "Amazon Redshift",
        "default_port": 5439,
        "driver": "redshift+psycopg2",
        "drivers_available": ["redshift+psycopg2"],
        "placeholder_host": "cluster.region.redshift.amazonaws.com",
    },
    "hive": {
        "label": "Apache Hive",
        "default_port": 10000,
        "driver": "hive",
        "drivers_available": ["hive"],
        "placeholder_host": "localhost",
    },
    "duckdb": {
        "label": "DuckDB",
        "default_port": None,
        "driver": "duckdb",
        "drivers_available": ["duckdb"],
        "placeholder_host": "(upload DB file)",
        "supports_file_upload": True,
    },
}

# ---------------------------------------------------------------------------
# Pydantic request / config models
# ---------------------------------------------------------------------------


class SSHTunnelConfig(BaseModel):
    """SSH tunnel configuration for accessing private / firewalled databases."""

    ssh_host: str = Field(..., description="SSH bastion / jump host address")
    ssh_port: int = Field(22, description="SSH port")
    ssh_username: str = Field(..., description="SSH username")
    ssh_password: Optional[str] = Field(
        None, description="SSH password (if not using key)"
    )
    ssh_private_key: Optional[str] = Field(
        None, description="SSH private key content (PEM format)"
    )
    ssh_private_key_passphrase: Optional[str] = Field(
        None, description="Passphrase for the private key"
    )


class DBConnectionConfig(BaseModel):
    """
    Database connection configuration — matches the frontend form exactly.

    **Mode 1 – Structured parameters (preferred, matches UI form):**
        db_type, host, port, database_name, username, password

    **Mode 2 – Raw connection string:**
        connection_string  (full SQLAlchemy DSN)

    For **private databases** behind firewalls add ``ssh_tunnel``.
    """

    model_config = ConfigDict(populate_by_name=True)

    # ---- Mode 1: form fields (matches UI) ----
    db_type: Optional[str] = Field(
        None,
        description=(
            "Database type key from the dropdown: "
            "postgresql, mysql, mariadb, mssql, oracle, sqlite, "
            "bigquery, snowflake, clickhouse, redshift, hive, duckdb"
        ),
    )
    host: Optional[str] = Field(None, description="Database host / IP address")
    port: Optional[int] = Field(
        None, description="Database port (auto-filled per db_type if omitted)"
    )
    database_name: Optional[str] = Field(
        None,
        alias="databaseName",
        description="Database name (or file path for SQLite, project-id for BigQuery)",
    )
    username: Optional[str] = Field(None, description="Database username")
    password: Optional[str] = Field(None, description="Database password")

    # ---- Snowflake-specific ----
    account_url: Optional[str] = Field(
        None,
        description=(
            "Snowflake account URL, e.g. 'your-account.snowflakecomputing.com'. "
            "Used instead of host/port for Snowflake connections."
        ),
    )

    # ---- SQL Server ODBC-specific ----
    odbc_connection_string: Optional[str] = Field(
        None,
        alias="odbcConnectionString",
        description=(
            "Raw ODBC connection string for SQL Server, e.g. "
            "'Driver={ODBC Driver 17 for SQL Server};Server=server;Database=database;UID=user;PWD=password;'"
        ),
    )

    # ---- File-based databases (SQLite, DuckDB) ----
    database_file_path: Optional[str] = Field(
        None,
        description=(
            "Server path to DB file (set automatically when using uploaded_db_file_id). "
            "Or provide a path manually for server-side files. "
            "For DuckDB: file path or :memory:"
        ),
    )
    uploaded_db_file_id: Optional[str] = Field(
        None,
        description=(
            "ID returned from POST /connectors/db/upload. Use this to connect via uploaded DB file "
            "instead of database_file_path. Supported for db_type: sqlite, duckdb."
        ),
    )

    # ---- Mode 2: raw DSN ----
    connection_string: Optional[str] = Field(
        None,
        description=(
            "Full SQLAlchemy connection string, e.g. "
            "postgresql://user:pass@host:5432/mydb. "
            "When provided, the form fields above are ignored."
        ),
    )

    # ---- Advanced ----
    driver: Optional[str] = Field(
        None,
        description=(
            "Database driver. Can be a SQLAlchemy dialect (e.g. 'mssql+pyodbc') "
            "OR an ODBC driver name (e.g. 'ODBC Driver 18 for SQL Server'). "
            "ODBC names are automatically placed into the query string. "
            "Auto-selected if omitted."
        ),
    )
    extra_params: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Additional query-string parameters, e.g. "
            "{'charset': 'utf8mb4', 'driver': 'ODBC Driver 18 for SQL Server'}"
        ),
    )
    connect_args: Optional[Dict[str, Any]] = Field(
        None,
        description="Dict passed to create_engine(connect_args=...). Useful for SSL certificates etc.",
    )
    pool_size: int = Field(5, description="Connection pool size")
    pool_timeout: int = Field(30, description="Pool timeout in seconds")

    # ---- SSH tunnel for private databases ----
    ssh_tunnel: Optional[SSHTunnelConfig] = Field(
        None,
        description="SSH tunnel config for private databases behind firewalls",
    )

    # ---- Display / save ----
    name: Optional[str] = Field(
        None,
        alias="integrationName",
        description="Display name for the saved connection (also accepts 'integrationName')",
    )
    # ---- Original uploaded file metadata ----
    uploaded_file_name: Optional[str] = Field(
        None,
        description="Original uploaded database filename (SQLite/DuckDB uploads)",
    )

    # ---- Internal: file content hash for deduplication (SQLite/DuckDB uploads) ----
    file_content_hash: Optional[str] = Field(
        None,
        description="SHA256 hash of uploaded file content; used to avoid duplicate connections for same file",
    )


class DBQueryRequest(BaseModel):
    """Execute a query on a saved connection."""

    query: str = Field(..., description="SQL query to execute")
    limit: int = Field(100, description="Max rows to return")
    timeout: int = Field(30, description="Query timeout in seconds")


# ---------------------------------------------------------------------------
# SSH Tunnel helper
# ---------------------------------------------------------------------------


class _SSHTunnelWrapper:
    """Manages an SSH tunnel lifecycle."""

    def __init__(
        self, config: SSHTunnelConfig, remote_host: str, remote_port: int
    ):
        self.config = config
        self.remote_host = remote_host
        self.remote_port = remote_port
        self._tunnel = None

    def start(self) -> Tuple[str, int]:
        """Start the tunnel. Returns (local_host, local_port)."""
        try:
            from sshtunnel import SSHTunnelForwarder
        except ImportError:
            raise ImportError(
                "The 'sshtunnel' package is required for SSH tunneling. "
                "Install it with:  pip install sshtunnel"
            )

        kwargs: Dict[str, Any] = {
            "ssh_address_or_host": (self.config.ssh_host, self.config.ssh_port),
            "ssh_username": self.config.ssh_username,
            "remote_bind_address": (self.remote_host, self.remote_port),
        }

        if self.config.ssh_private_key:
            import io
            import paramiko

            pkey = paramiko.RSAKey.from_private_key(
                io.StringIO(self.config.ssh_private_key),
                password=self.config.ssh_private_key_passphrase,
            )
            kwargs["ssh_pkey"] = pkey
        elif self.config.ssh_password:
            kwargs["ssh_password"] = self.config.ssh_password
        else:
            raise ValueError(
                "SSH tunnel requires either ssh_password or ssh_private_key"
            )

        self._tunnel = SSHTunnelForwarder(**kwargs)
        self._tunnel.start()
        local_host = "127.0.0.1"
        local_port = self._tunnel.local_bind_port
        logger.info(
            "SSH tunnel established: %s:%s -> %s:%s",
            local_host,
            local_port,
            self.remote_host,
            self.remote_port,
        )
        return local_host, local_port

    def stop(self):
        if self._tunnel:
            self._tunnel.stop()
            self._tunnel = None
            logger.info("SSH tunnel closed")


# ---------------------------------------------------------------------------
# Connection-string builder
# ---------------------------------------------------------------------------


def build_connection_string(config: DBConnectionConfig) -> str:
    """
    Build a SQLAlchemy DSN from the structured form fields.
    If ``config.connection_string`` is already provided, return it as-is.
    """
    if config.connection_string:
        return config.connection_string.strip()

    if not config.db_type:
        raise ValueError("Either 'connection_string' or 'db_type' must be provided")

    db_type = config.db_type.lower()
    if db_type not in DB_TYPES:
        raise ValueError(
            f"Unsupported db_type '{db_type}'. "
            f"Supported: {', '.join(sorted(DB_TYPES.keys()))}"
        )

    info = DB_TYPES[db_type]

    # --- SQLite (file-based) ---
    if db_type == "sqlite":
        logger.info(
            "[SQLITE_BUILD] database_file_path=%s database_name=%s",
            config.database_file_path,
            config.database_name,
        )
        path = config.database_file_path or config.database_name
        if not path:
            raise ValueError(
                "SQLite requires database_file_path"
            )

        return f"sqlite:///{path}"

    # --- DuckDB (file-based) ---
    if db_type == "duckdb":
        path = config.database_file_path or config.database_name or ":memory:"
        # Strip file:// prefix if present – DuckDB SQLAlchemy driver expects raw path
        if path.startswith("file:///"):
            path = path[len("file:///"):]
        elif path.startswith("file://"):
            path = path[len("file://"):]
        return f"duckdb:///{path}"

    # --- BigQuery ---
    if db_type == "bigquery":
        project = config.database_name or ""
        cs = f"bigquery://{project}"
        if config.extra_params:
            qs = "&".join(f"{k}={v}" for k, v in config.extra_params.items())
            cs += f"?{qs}"
        return cs

    # --- SQL Server with raw ODBC connection string ---
    if db_type == "mssql" and config.odbc_connection_string:
        odbc_cs = config.odbc_connection_string.strip()
        encoded = quote_plus(odbc_cs)
        return f"mssql+pyodbc:///?odbc_connect={encoded}"

    # --- Snowflake (uses account_url instead of host:port) ---
    if db_type == "snowflake":
        account = config.account_url or config.host or ""
        # Remove trailing .snowflakecomputing.com if present
        if account.endswith(".snowflakecomputing.com"):
            account = account[: -len(".snowflakecomputing.com")]
        user = quote_plus(config.username or "")
        pwd = quote_plus(config.password or "")
        db = config.database_name or ""
        extra = dict(config.extra_params or {})
        if user and pwd:
            cs = f"snowflake://{user}:{pwd}@{account}/{db}"
        elif user:
            cs = f"snowflake://{user}@{account}/{db}"
        else:
            cs = f"snowflake://{account}/{db}"
        if extra:
            qs = "&".join(
                f"{k}={quote_plus(str(v))}" for k, v in extra.items()
            )
            cs += f"?{qs}"
        return cs

    # --- Resolve the driver ---
    # The `driver` field can be either:
    #   (a) a SQLAlchemy dialect+driver like "mssql+pyodbc"   →  used as URL scheme
    #   (b) an ODBC driver name like "ODBC Driver 18 for SQL Server"
    #       →  use the appropriate SQLAlchemy scheme and move the ODBC name into ?driver=
    #   (c) omitted  →  use the default for this db_type
    extra = dict(config.extra_params or {})
    raw_driver = (config.driver or "").strip()

    if raw_driver and ("+" not in raw_driver and "://" not in raw_driver):
        # Looks like an ODBC / native driver name, not a SQLAlchemy dialect.
        # e.g. "ODBC Driver 18 for SQL Server", "FreeTDS", "MySQL ODBC 8.0"
        # → push it into the query-string as ?driver=... and pick the right
        #   SQLAlchemy dialect automatically.
        extra["driver"] = raw_driver
        if db_type == "mssql":
            sa_driver = "mssql+pyodbc"
        elif db_type in ("mysql", "mariadb"):
            sa_driver = info["driver"]  # mysql+pymysql, etc.
        else:
            sa_driver = info["driver"]
    elif raw_driver:
        sa_driver = raw_driver          # already a proper SQLAlchemy driver
    else:
        sa_driver = info["driver"]      # default for this db_type

    host = config.host or "localhost"
    port = config.port or info["default_port"]
    user = quote_plus(config.username or "")
    pwd = quote_plus(config.password or "")
    db = config.database_name or ""

    if user and pwd:
        cs = f"{sa_driver}://{user}:{pwd}@{host}:{port}/{db}"
    elif user:
        cs = f"{sa_driver}://{user}@{host}:{port}/{db}"
    else:
        cs = f"{sa_driver}://{host}:{port}/{db}"

    if extra:
        qs = "&".join(
            f"{k}={quote_plus(str(v))}" for k, v in extra.items()
        )
        cs += f"?{qs}"

    return cs


def _infer_db_type(connection_string: str) -> str:
    """Infer db_type from a DSN scheme."""
    scheme = urlparse(connection_string).scheme.lower().split("+")[0]
    mapping = {
        "postgresql": "postgresql",
        "postgres": "postgresql",
        "mysql": "mysql",
        "mariadb": "mariadb",
        "mssql": "mssql",
        "oracle": "oracle",
        "sqlite": "sqlite",
        "bigquery": "bigquery",
        "snowflake": "snowflake",
        "clickhouse": "clickhouse",
        "redshift": "redshift",
        "hive": "hive",
        "duckdb": "duckdb",
    }
    return mapping.get(scheme, scheme)


# ---------------------------------------------------------------------------
# Mask password
# ---------------------------------------------------------------------------


def mask_connection_string(cs: str) -> str:
    """Mask password in a DSN for safe display."""
    if not cs or "://" not in cs:
        return cs or ""
    try:
        scheme, rest = cs.split("://", 1)
        if "@" in rest:
            creds, host_part = rest.split("@", 1)
            if ":" in creds:
                user, _ = creds.split(":", 1)
                return f"{scheme}://{user}:****@{host_part}"
        return f"{scheme}://****"
    except Exception:
        return "***"


def _format_connection_error(exc: Exception, connection_string: str) -> str:
    """Return a user-friendly connection error message (optionally with ODBC hints)."""
    msg = str(exc).lower()
    cs = (connection_string or "").strip()
    scheme = urlparse(cs).scheme.lower() if cs else ""
    if "im002" in msg or "data source name not found" in msg or "no default driver specified" in msg:
        hint = (
            "ODBC Driver Manager could not find a driver or DSN. "
            "On Windows: install the correct ODBC driver (e.g. 'ODBC Driver 17/18 for SQL Server'). "
            "Alternatively use mssql+pymssql://user:pass@host/db (pip install pymssql), or mssql+pyodbc://... with driver= in the query string."
        )
        return f"Connection failed: {exc}. {hint}"
    if "mssql" in scheme or "sql server" in msg:
        if "pyodbc" in msg or "odbc" in msg:
            return (
                f"Connection failed: {exc}. "
                "For SQL Server: install 'ODBC Driver 17/18 for SQL Server' or use mssql+pymssql (pip install pymssql)."
            )
    return f"Connection failed: {exc}"


# ---------------------------------------------------------------------------
# Server public IP helper  (shown on the form so users can whitelist it)
# ---------------------------------------------------------------------------

_cached_server_ip: Optional[str] = None


def get_server_public_ip() -> str:
    """
    Return the server's public IP address.
    The frontend shows this so the user can add it to their DB firewall rules.
    """
    global _cached_server_ip
    if _cached_server_ip:
        return _cached_server_ip

    # Try multiple services for reliability
    services = [
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://icanhazip.com",
        "https://checkip.amazonaws.com",
    ]
    for url in services:
        try:
            resp = httpx.get(url, timeout=5.0)
            if resp.status_code == 200:
                ip = resp.text.strip()
                if ip:
                    _cached_server_ip = ip
                    return ip
        except Exception:
            continue

    # Fallback: local hostname resolution
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        _cached_server_ip = ip
        return ip
    except Exception:
        return "unknown"


# ---------------------------------------------------------------------------
# Natural language → SQL (for /db/invoke with question)
# ---------------------------------------------------------------------------

# Env: DB_INVOKE_LLM_URL = base URL for LLM API (e.g. http://localhost:8000), used as {url}/LLMs/chat
# Env: DB_INVOKE_LLM_MODEL = optional model_id; if not set, first model from /LLMs/models is used


def _build_schema_summary_for_nl(schema_result: Dict[str, Any]) -> str:
    """Build a compact schema summary string for the LLM prompt from get_full_schema output."""
    lines: List[str] = []
    for table in schema_result.get("tables", [])[:30]:
        tname = table.get("table_name", "?")
        cols = table.get("columns", [])
        col_strs = [f"{c.get('name', '?')} ({str(c.get('type', '')).split('(')[0]})" for c in cols[:25]]
        lines.append(f"Table: {tname}\n  Columns: {', '.join(col_strs)}")
    for view in schema_result.get("views", [])[:10]:
        vname = view.get("view_name", "?")
        cols = view.get("columns", [])
        col_strs = [c.get("name", "?") for c in cols[:15]]
        lines.append(f"View: {vname}\n  Columns: {', '.join(col_strs)}")
    return "\n\n".join(lines) if lines else "No tables or views found."


def _extract_sql_from_llm_response(raw: str) -> Tuple[str, str]:
    """Parse LLM response for JSON with 'sql' and optional 'explanation'. Returns (sql, explanation)."""
    explanation = ""
    raw_clean = raw.strip()
    # Strip common LLM prefixes that break json.loads (e.g. "json\n{...}" or "```json\n{...}")
    if raw_clean.lower().startswith("json"):
        raw_clean = raw_clean[4:].lstrip()
    if raw_clean.startswith("```"):
        raw_clean = re.sub(r"^```(?:json)?\s*", "", raw_clean, flags=re.IGNORECASE)
        raw_clean = re.sub(r"\s*```\s*$", "", raw_clean)
    try:
        data = json.loads(raw_clean)
        sql = (data.get("sql") or "").strip()
        explanation = (data.get("explanation") or "").strip()
        if sql:
            return _normalize_generated_sql(sql), explanation
    except Exception:
        pass
    # Fallback: look for ```sql ... ``` or SELECT... block in original raw
    m = re.search(r"```(?:sql)?\s*([\s\S]+?)```", raw, re.IGNORECASE)
    if m:
        sql = m.group(1).strip().strip(";")
        return _normalize_generated_sql(sql), explanation
    m2 = re.search(r"(\bSELECT\b[\s\S]+?)(?=\n\n|\n```|\Z)", raw, re.IGNORECASE | re.DOTALL)
    if m2:
        sql = m2.group(1).strip().strip(";")
        return _normalize_generated_sql(sql), explanation
    return "", explanation


def _normalize_generated_sql(sql: str) -> str:
    """Remove trailing semicolon and extra whitespace."""
    if not sql:
        return sql
    sql = re.sub(r";\s*$", "", sql.strip())
    return sql.strip()


def _json_safe_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert row values to JSON-serializable form (e.g. datetime/decimal to str)."""
    out = []
    for row in rows:
        safe = {}
        for k, v in row.items():
            if v is None or isinstance(v, (str, int, float, bool)):
                safe[k] = v
            elif hasattr(v, "isoformat"):
                safe[k] = v.isoformat()
            else:
                safe[k] = str(v)
        out.append(safe)
    return out


def _summarize_result_for_question(
    question: str, columns: List[str], rows: List[Dict[str, Any]]
) -> Optional[str]:
    """
    Generate a Convobi-style narrative summary of the query result using the same LLM.
    Returns Markdown summary or None if LLM unavailable.
    """
    system = (
        "You are a helpful analyst. Summarize tabular data clearly and concisely. "
        "Always respond in valid Markdown."
    )
    sample = _json_safe_rows(rows[:20])
    user = (
        "Summarize the following query result for a non-technical stakeholder. Use Markdown only.\n"
        f"Question: {question}\n"
        f"Columns: {json.dumps(columns)}\n"
        f"First rows (sample): {json.dumps(sample)}\n\n"
        "Format your response in Markdown with these sections:\n"
        "- ## Executive summary — one sentence\n"
        "- ## Key observations — bullet list\n"
        "- ## Notable trends / anomalies — short bullets or paragraph\n"
        "- ## Suggested next steps — bullet list (optional)\n"
        "Use ** for bold, - or * for bullets, ## for section headers. Keep it concise."
    )
    return _get_convobi_llm_response(system, user)


def _get_convobi_llm_response(system: str, user: str) -> Optional[str]:
    """
    Use the lazily-resolved Convobi LLM to generate a response.

    Delegates to _get_convobi_llm() which resolves per-user credentials
    with a TTL cache. When called from db_connector (no user context),
    falls back to platform credentials.

    Returns the response text, or None if the LLM is not available.
    """
    try:
        from apps.convobi.main import _get_convobi_llm
        llm = _get_convobi_llm()
        from langchain_core.messages import SystemMessage, HumanMessage
        messages = [
            SystemMessage(content=system),
            HumanMessage(content=user),
        ]
        response = llm.invoke(messages)
        return (getattr(response, "content", None) or str(response) or "").strip()
    except Exception as e:
        logger.debug("Convobi LLM not available for db/invoke: %s", e)
        return None


def _generate_sql_via_llm(
    question: str,
    schema_summary: str,
    db_type: str,
    limit: Optional[int] = None,
) -> Tuple[str, str]:
    """
    Generate SQL from natural language using Convobi's LLM (apps.convobi.main._get_convobi_llm)
    if available; otherwise fall back to DB_INVOKE_LLM_URL HTTP API.
    Returns (sql, explanation). Raises ValueError if no LLM available or call fails.
    """
    dialect_rules = ""
    if db_type == "sqlite":
        dialect_rules = (
            "SQLite: do not use INTERVAL; use date('now','-N days'). Use strftime for dates. "
            "No semicolon at end of statement."
        )
    elif db_type == "mssql":
        dialect_rules = (
            "Microsoft SQL Server: use TOP N for limit. Use GETDATE() for current date. "
            "Use [brackets] for identifiers if needed. No semicolon at end."
        )
    else:
        dialect_rules = (
            f"Database: {db_type}. Use standard SQL. Use LIMIT for row limit where supported. "
            "Do not end with semicolon."
        )

    system = (
        "You are an expert SQL analyst. Generate only valid SQL from the user question using the given schema. "
        "Return JSON with exactly: {\"sql\": \"SELECT ...\", \"explanation\": \"brief explanation\"}. "
        "Use only tables and columns from the schema. "
    ) + dialect_rules

    user = (
        f"Schema:\n{schema_summary}\n\n"
        f"Question: {question}\n\n"
        f"Max rows to return: {limit if limit is not None else 'default'}\n\n"
        "Return JSON only: {\"sql\": \"...\", \"explanation\": \"...\"}"
    )

    # 1) Prefer Convobi's LLM (same as in convobi/main.py)
    raw = _get_convobi_llm_response(system, user)
    if raw:
        sql, explanation = _extract_sql_from_llm_response(raw)
        if sql:
            return sql, explanation
        raise ValueError("Could not extract SQL from LLM response. Try rephrasing your question.")

    # 2) Fallback: HTTP LLM API (DB_INVOKE_LLM_URL)
    base_url = (os.environ.get("DB_INVOKE_LLM_URL") or "").strip().rstrip("/")
    if not base_url:
        raise ValueError(
            "Natural language invoke requires an LLM. Use the same LLM as Convobi (_get_convobi_llm in apps/convobi/main.py) "
            "or set environment variable DB_INVOKE_LLM_URL (e.g. http://localhost:8000) to the base URL of your LLM API (POST /LLMs/chat)."
        )

    chat_url = f"{base_url}/LLMs/chat"
    model_id = (os.environ.get("DB_INVOKE_LLM_MODEL") or "").strip()

    if not model_id:
        try:
            models_url = f"{base_url}/LLMs/models"
            resp = httpx.get(models_url, timeout=15.0)
            if resp.status_code == 200:
                data = resp.json()
                models = data if isinstance(data, list) else data.get("models", data) or []
                if models:
                    first = models[0] if isinstance(models[0], dict) else {"id": models[0]}
                    model_id = first.get("id") or first.get("model_id") or (first if isinstance(first, str) else None)
        except Exception as e:
            logger.warning("Could not resolve LLM model_id: %s", e)
        if not model_id:
            raise ValueError(
                "DB_INVOKE_LLM_MODEL not set and could not get model from LLM API. "
                "Set DB_INVOKE_LLM_MODEL to your model id."
            )

    payload = {
        "model_id": model_id,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.2,
        "max_tokens": 2048,
    }

    try:
        resp = httpx.post(chat_url, json=payload, timeout=60.0)
        if resp.status_code != 200:
            raise ValueError(f"LLM API error {resp.status_code}: {resp.text}")
        data = resp.json()
        raw = (data.get("response") or "").strip()
        if not raw:
            raise ValueError("LLM returned empty response")
        sql, explanation = _extract_sql_from_llm_response(raw)
        if not sql:
            raise ValueError("Could not extract SQL from LLM response. Try rephrasing your question.")
        return sql, explanation
    except httpx.HTTPError as e:
        raise ValueError(f"LLM request failed: {e}") from e


# ---------------------------------------------------------------------------
# Core service
# ---------------------------------------------------------------------------


class DatabaseConnectorService:
    """
    Universal database connector supporting public *and* private databases.
    """

    def __init__(self):
        self._connections: Dict[str, Dict[str, Any]] = {}
        self._engines: Dict[str, Engine] = {}
        self._tunnels: Dict[str, _SSHTunnelWrapper] = {}
        self._load_persisted()

    # ---- persistence (PostgreSQL) ----

    def _load_persisted(self):
        """Load all saved connections from the db_connections PostgreSQL table."""
        try:
            engine = _get_pg_engine()
            with engine.begin() as conn:
                result = conn.execute(text(
                    "SELECT id, name,uploaded_file_name, db_type, connection_string, dialect, "
                    "tables_count, views_count, schemas, ssh_tunnel_enabled, "
                    "ssh_host, ssh_config, file_content_hash, user_id "
                    "FROM db_connections ORDER BY created_at"
                ))
                seen_hashes: Dict[str, str] = {}
                duplicate_ids: List[str] = []
                loaded: Dict[str, Dict[str, Any]] = {}

                for row in result.mappings():
                    cid = row["id"]
                    fch = row["file_content_hash"]
                    uid = str(row["user_id"]) if row["user_id"] else ""
                    dedup_key = f"{uid}:{fch}" if fch else None
                    if dedup_key and dedup_key in seen_hashes:
                        duplicate_ids.append(cid)
                        continue
                    if dedup_key:
                        seen_hashes[dedup_key] = cid

                    cs = row["connection_string"]

                    loaded[cid] = {
                        "id": cid,
                        "name": row["name"] or "Unnamed",
                        "uploaded_file_name": row["uploaded_file_name"],
                        "db_type": row["db_type"] or "unknown",
                        "connection_string": cs,
                        "dialect": row["dialect"] or "unknown",
                        "tables_count": row["tables_count"] or 0,
                        "views_count": row["views_count"] or 0,
                        "schemas": row["schemas"] if row["schemas"] else [],
                        "ssh_tunnel_enabled": bool(row["ssh_tunnel_enabled"]),
                        "ssh_host": row["ssh_host"],
                        "ssh_config": row["ssh_config"],
                        "file_content_hash": fch,
                        "user_id": str(row["user_id"]) if row["user_id"] else None,
                    }

                if duplicate_ids:
                    for did in duplicate_ids:
                        conn.execute(text("DELETE FROM db_connections WHERE id = :id"), {"id": did})
                    logger.info("Removed %d duplicate db_connections rows", len(duplicate_ids))

                self._connections = loaded
        except Exception as exc:
            logger.warning("Could not load saved connections from PostgreSQL: %s", exc)

    def _persist(self):
        """Sync the in-memory connections dict to the db_connections PostgreSQL table."""
        try:
            engine = _get_pg_engine()
            with engine.begin() as conn:
                existing_result = conn.execute(text("SELECT id FROM db_connections"))
                existing_ids = {row[0] for row in existing_result}
                current_ids = set(self._connections.keys())

                for rid in (existing_ids - current_ids):
                    conn.execute(text("DELETE FROM db_connections WHERE id = :id"), {"id": rid})

                for record in self._connections.values():
                    self._upsert_record(conn, record)
        except Exception as exc:
            logger.exception("Failed to persist connections to PostgreSQL: %s", exc)
            raise

    @staticmethod
    def _upsert_record(conn, record: Dict[str, Any]) -> None:
        """Insert or update a single connection record in PostgreSQL.

        Stores the connection_string directly in the DB (no Key Vault).
        """
        schemas_json = json.dumps(record.get("schemas", []))
        ssh_cfg = record.get("ssh_config")
        ssh_config_json = json.dumps(ssh_cfg) if ssh_cfg else None

        conn.execute(text("""
            INSERT INTO db_connections
                (id, name, uploaded_file_name,db_type, connection_string, dialect,
                 tables_count, views_count, schemas,
                 ssh_tunnel_enabled, ssh_host, ssh_config,
                 file_content_hash, user_id, updated_at)
            VALUES
                (:id, :name, :uploaded_file_name,:db_type, :connection_string, :dialect,
                 :tables_count, :views_count, CAST(:schemas AS jsonb),
                 :ssh_tunnel_enabled, :ssh_host, CAST(:ssh_config AS jsonb),
                 :file_content_hash, :user_id, NOW())
            ON CONFLICT (id) DO UPDATE SET
                name               = EXCLUDED.name,
                db_type            = EXCLUDED.db_type,
                uploaded_file_name = EXCLUDED.uploaded_file_name,
                connection_string  = EXCLUDED.connection_string,
                dialect            = EXCLUDED.dialect,
                tables_count       = EXCLUDED.tables_count,
                views_count        = EXCLUDED.views_count,
                schemas            = EXCLUDED.schemas,
                ssh_tunnel_enabled = EXCLUDED.ssh_tunnel_enabled,
                ssh_host           = EXCLUDED.ssh_host,
                ssh_config         = EXCLUDED.ssh_config,
                file_content_hash  = EXCLUDED.file_content_hash,
                user_id            = EXCLUDED.user_id,
                updated_at         = NOW()
        """), {
            "id": record["id"],
            "name": record.get("name", "Unnamed"),
            "uploaded_file_name": record.get("uploaded_file_name"),
            "db_type": record.get("db_type", "unknown"),
            "connection_string": record.get("connection_string", ""),
            "dialect": record.get("dialect"),
            "tables_count": record.get("tables_count", 0),
            "views_count": record.get("views_count", 0),
            "schemas": schemas_json,
            "ssh_tunnel_enabled": record.get("ssh_tunnel_enabled", False),
            "ssh_host": record.get("ssh_host"),
            "ssh_config": ssh_config_json,
            "file_content_hash": record.get("file_content_hash"),
            "user_id": record.get("user_id"),
        })

    # ---- engine creation (with optional SSH tunnel) ----

    @staticmethod
    def _perform_mssql_diagnostics(connection_string: str) -> None:
        """
        Perform MSSQL diagnostics before attempting SQLAlchemy connection.
        Logs:
        - SQLAlchemy connection string
        - Available ODBC drivers
        - Decoded ODBC connection string
        - Parsed server/port
        - DNS resolution
        - TCP connectivity
        """

        LOG = logging.getLogger(__name__)

        try:
            LOG.info(
                "[MSSQL_DEBUG] sqlalchemy_connection_string=%s",
                connection_string,
            )

            try:
                LOG.info(
                    "[MSSQL_DEBUG] available_odbc_drivers=%s",
                    pyodbc.drivers(),
                )
            except Exception as e:
                LOG.warning(
                    "[MSSQL_DEBUG] could_not_list_odbc_drivers=%s",
                    e,
                )

            server = None
            port = 1433

            # Try SQLAlchemy URL first
            try:
                url = make_url(connection_string)

                if url.host:
                    server = url.host

                if url.port:
                    port = url.port

            except Exception:
                pass

            # Handle mssql+pyodbc:///?odbc_connect=...
            if not server and "odbc_connect=" in connection_string:
                try:
                    parsed = urlparse(connection_string)
                    qs = parse_qs(parsed.query)

                    encoded_odbc = qs.get("odbc_connect", [None])[0]

                    if encoded_odbc:
                        odbc_cs = unquote(encoded_odbc)

                        LOG.info(
                            "[MSSQL_DEBUG] decoded_odbc=%s",
                            odbc_cs,
                        )

                        match = re.search(
                            r"Server\s*=\s*([^;]+)",
                            odbc_cs,
                            re.IGNORECASE,
                        )

                        if match:
                            server_part = match.group(1).strip()

                            if "," in server_part:
                                server, port_str = server_part.rsplit(",", 1)

                                try:
                                    port = int(port_str.strip())
                                except ValueError:
                                    port = 1433
                            else:
                                server = server_part
                                port = 1433

                except Exception as e:
                    LOG.warning(
                        "[MSSQL_DEBUG] failed_to_parse_odbc_connect=%s",
                        e,
                    )

            if not server:
                LOG.warning(
                    "[MSSQL_DEBUG] server=None (could not parse host from connection string)"
                )
                return

            LOG.info("[MSSQL_DEBUG] server=%s", server)
            LOG.info("[MSSQL_DEBUG] port=%s", port)

            # DNS Test
            dns_success = False
            resolved_ip = None

            try:
                resolved_ip = socket.gethostbyname(server)
                LOG.info(
                    "[MSSQL_DEBUG] attempting_tcp=%s:%s",
                    server,
                    port,
                )
                dns_success = True

                LOG.info(
                    "[MSSQL_DEBUG] dns_success=True"
                )
                LOG.info(
                    "[MSSQL_DEBUG] resolved_ip=%s",
                    resolved_ip,
                )

            except Exception as e:
                LOG.warning(
                    "[MSSQL_DEBUG] dns_success=False"
                )
                LOG.warning(
                    "[MSSQL_DEBUG] dns_error=%s",
                    e,
                )

            # TCP Test
            if dns_success:
                try:
                    sock = socket.create_connection(
                        (server, port),
                        timeout=30,
                    )
                    sock.close()

                    LOG.info(
                        "[MSSQL_DEBUG] tcp_success=True"
                    )
                    LOG.info(
                        "[MSSQL_DEBUG] tcp_error=None"
                    )

                except Exception as e:
                    LOG.warning(
                        "[MSSQL_DEBUG] tcp_success=False"
                    )
                    LOG.warning(
                        "[MSSQL_DEBUG] tcp_error=%s",
                        e,
                    )
            else:
                LOG.warning(
                    "[MSSQL_DEBUG] tcp_success=False"
                )
                LOG.warning(
                    "[MSSQL_DEBUG] tcp_error=DNS resolution failed"
                )

        except Exception as e:
            LOG.warning(
                "[MSSQL_DEBUG] diagnostics_failed=%s",
                e,
            )

    def _create_engine(
        self, connection_string: str, config: DBConnectionConfig
    ) -> Tuple[Engine, Optional[_SSHTunnelWrapper]]:
        tunnel: Optional[_SSHTunnelWrapper] = None

        if config.ssh_tunnel:
            parsed = urlparse(connection_string)
            remote_host = parsed.hostname or "localhost"
            db_info = DB_TYPES.get(
                config.db_type or _infer_db_type(connection_string), {}
            )
            remote_port = parsed.port or db_info.get("default_port", 5432)

            tunnel = _SSHTunnelWrapper(config.ssh_tunnel, remote_host, remote_port)
            local_host, local_port = tunnel.start()

            # Rewrite DSN to go through the local tunnel
            connection_string = connection_string.replace(
                f"{remote_host}:{remote_port}",
                f"{local_host}:{local_port}",
            )
            # Fallback if port wasn't explicit in the DSN
            if remote_host in connection_string:
                connection_string = connection_string.replace(
                    remote_host, f"{local_host}:{local_port}"
                )

        engine_kw: Dict[str, Any] = {
            "pool_pre_ping": True,
            "pool_size": config.pool_size,
            "pool_timeout": config.pool_timeout,
        }
        if config.connect_args:
            engine_kw["connect_args"] = config.connect_args

        # SQLite and DuckDB don't support pool_size / pool_timeout
        if connection_string.startswith("sqlite") or connection_string.startswith("duckdb"):
            engine_kw.pop("pool_size", None)
            engine_kw.pop("pool_timeout", None)

        # Run MSSQL connectivity diagnostics before attempting connection
        
        if connection_string.startswith("mssql"):
            self._perform_mssql_diagnostics(
                connection_string
            )


        engine = create_engine(connection_string, **engine_kw)
        return engine, tunnel

    # ---- public API ----

    def list_supported_databases(self) -> List[Dict[str, Any]]:
        """Return metadata about every supported DB type (drives the dropdown)."""
        out = []
        for key, info in DB_TYPES.items():
            out.append(
                {
                    "db_type": key,
                    "label": info["label"],
                    "default_port": info["default_port"],
                    "default_driver": info["driver"],
                    "drivers_available": info["drivers_available"],
                    "placeholder_host": info.get("placeholder_host", ""),
                    "supports_file_upload": info.get("supports_file_upload", False),
                }
            )
        return out
    
    # Service method for test connector functionality
    def test_saved_connection(
        self,
        connection_id: str,
        user_id: str = None,
    ) -> Dict[str, Any]:

        self._load_persisted()

        conn = self._connections.get(connection_id)

        if not conn:
            raise ValueError(
                f"Connection '{connection_id}' not found"
            )

        if user_id:
            self._verify_ownership(
                connection_id,
                user_id,
            )

        logger.info(
            "[DB_TEST_CONNECTION] connection_id=%s",
            connection_id,
        )

        connection_string = conn.get(
            "connection_string"
        )

        logger.info(
            "[DB_TEST_CONNECTION] connection_string=%s",
            connection_string,
        )
        db_type = conn.get("db_type")

        if DB_TYPES.get(
            db_type,
            {},
        ).get(
            "supports_file_upload",
            False,
        ):
            logger.info(
                "[DB_TEST_CONNECTION] ensuring file availability "
                "connection_id=%s",
                connection_id,
            )

            from apps.convobi.main import (
                get_saved_connection_string,
            )

            connection_string = get_saved_connection_string(
                connection_id,
            )

            if not connection_string:
                raise ValueError(
                    f"Connection '{connection_id}' could not be restored"
                )

            logger.info(
                "[DB_TEST_CONNECTION] file availability confirmed "
                "connection_id=%s",
                connection_id,
            )
        config = DBConnectionConfig(
            connection_string=connection_string,
            db_type=conn.get("db_type"),
        )

        return self.test_connection(config)
    
    def test_uploaded_file(
    self,
    file_id: str,
    ) -> Dict[str, Any]:

        from apps.convobi.main import get_uploaded_file_record

        record = get_uploaded_file_record(
            file_id=file_id,
        )

        if not record:
            raise ValueError(
                f"File '{file_id}' not found"
            )

        db_path = record.get("db_path")

        if db_path and not os.path.exists(db_path):

            logger.info(
                "[DB_TEST_FILE] local file missing path=%s",
                db_path,
            )

            try:
                from apps.convobi.routes import (
                    ensure_connector_file_available
                )

                ensure_connector_file_available(
                    record["connection_id"]
                )

                logger.info(
                    "[DB_TEST_FILE] restore complete path=%s",
                    db_path,
                )

            except Exception:
                logger.exception(
                    "[DB_TEST_FILE] restore failed"
                )

        logger.info(
            "[DB_TEST_FILE] record=%s",
            record,
        )

        config = DBConnectionConfig(
            db_type=record.get("format"),
            database_file_path=db_path,
        )

        return self.test_connection(config)


    # --- test connection (the "Test Connection" button) ---

    def test_connection(self, config: DBConnectionConfig) -> Dict[str, Any]:
        """
        Test a database connection **without** saving it.
        Works for both public (direct) and private (SSH tunnel) databases.
        """
        tunnel: Optional[_SSHTunnelWrapper] = None
        try:       
            logger.info(
                    "[DB_TEST] db_type=%s",
                    config.db_type,
                )
            logger.info(
                    "[DB_TEST] database_file_path=%s",
                    getattr(config, "database_file_path", None),
                )
            logger.info(
                    "[DB_TEST] connection_string=%s",
                    getattr(config, "connection_string", None),
                )
            cs = build_connection_string(config)
            logger.info(
                    "[DB_TEST] generated_connection_string=%s",
                    cs,
                )
            engine, tunnel = self._create_engine(cs, config)

            # Connectivity check
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            insp = inspect(engine)
            
            logger.info(
                "[DB_TEST] inspector=%s",
                type(insp).__name__,
            )

            tables = insp.get_table_names()
            
            logger.info(
                "[DB_TEST] tables=%s",
                tables,
            )

            logger.info(
                "[DB_TEST] tables_count=%s",
                len(tables),
            )

            views: List[str] = []
            try:
                views = insp.get_view_names()
            except Exception:
                pass
            schemas: List[str] = []
            try:
                schemas = insp.get_schema_names()
                
                logger.info(
                        "[DB_TEST] schemas=%s",
                        schemas,
                    )

            except Exception:
                logger.exception(
                        "[DB_TEST] schema discovery failed"
                    )


            db_type = config.db_type or _infer_db_type(cs)
            engine.dispose()

            return {
                "ok": True,
                "message": "Connection successful",
                "db_type": db_type,
                "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
                "tables_count": len(tables),
                "views_count": len(views),
                "schemas": schemas[:20],
                "ssh_tunnel_active": config.ssh_tunnel is not None,
            }
        except ImportError as exc:
            raise ValueError(str(exc))
        except Exception as exc:
            cs = build_connection_string(config)
            raise ValueError(_format_connection_error(exc, cs)) from exc
        finally:
            if tunnel:
                tunnel.stop()

    # --- connect & save (the "Next" button after test passes) ---

    def connect_and_save(self, config: DBConnectionConfig, *, user_id: str = None) -> Dict[str, Any]:
        """Test, save, and cache the engine for subsequent operations."""
        # For SQLite/DuckDB file uploads: reuse existing connection if same file content (avoids duplicates from double-submit)
        logger.info(
            "[CONNECT_SAVE] uploaded_file_name=%s",
            config.uploaded_file_name,
        )
        if config.file_content_hash and config.db_type in ("sqlite", "duckdb"):
            self._load_persisted()

            for c in self._connections.values():
                if (
                    c.get("file_content_hash") == config.file_content_hash
                    and c.get("user_id") == user_id
                ):
                    new_cs = build_connection_string(config)
                    LOG = logging.getLogger(__name__)

                    LOG.warning(
                        "[CONNECT_REUSE] Reusing existing connection_id=%s",
                        c.get("id"),
                    )

                    LOG.info(
                        "[CONNECT_REUSE] Old connection_string=%s",
                        c.get("connection_string"),
                    )

                    LOG.info(
                        "[CONNECT_REUSE] New connection_string=%s",
                        new_cs,
                    )

                    #
                    # Refresh the stored path so it points to the newly uploaded file.
                    #
                    c["connection_string"] = new_cs

                    #
                    # Optional but useful: refresh name/db_type too.
                    #
                    c["db_type"] = config.db_type
                    if config.name:
                        c["name"] = config.name

                    c["uploaded_file_name"] = config.uploaded_file_name

                    self._persist()

                    LOG.info(
                        "[CONNECT_REUSE] Connection metadata updated and persisted."
                    )

                    return {
                        "ok": True,
                        "connection_id": c["id"],
                        "name": c.get("name", "Unnamed"),
                        "db_type": c.get("db_type", "unknown"),
                        "dialect": c.get("dialect", "unknown"),
                        "tables_count": c.get("tables_count", 0),
                        "views_count": c.get("views_count", 0),
                        "schemas": c.get("schemas", []),
                        "connection_string_masked": mask_connection_string(
                            c.get("connection_string", "")
                        ),
                        "ssh_tunnel_active": False,
                        "message": "Connection saved successfully",
                        "reused_existing": True,
                    }

        test_result = self.test_connection(config)

        cs = build_connection_string(config)
        db_type = config.db_type or _infer_db_type(cs)
        name = (config.name or "").strip() or (
            f"{DB_TYPES.get(db_type, {}).get('label', db_type)} connection"
        )
        # If name is MSSQL-ITSM, use fixed connection_id so ITSM DB tool uses it by default
        if name == ITSM_CONNECTION_NAME:
            conn_id = ITSM_DEFAULT_CONNECTION_ID
        elif name == CRM_CONNECTION_NAME:
            conn_id = CRM_DEFAULT_CONNECTION_ID
        else:
            conn_id = str(uuid.uuid4())[:8]

        # If reusing an existing id (e.g. ITSM), dispose old engine and close tunnel first
        if conn_id in self._engines:
            old_engine = self._engines.pop(conn_id, None)
            if old_engine:
                try:
                    old_engine.dispose()
                except Exception:
                    pass
        if conn_id in self._tunnels:
            old_tunnel = self._tunnels.pop(conn_id, None)
            if old_tunnel:
                try:
                    old_tunnel.stop()
                except Exception:
                    pass

        engine, tunnel = self._create_engine(cs, config)
        self._engines[conn_id] = engine
        if tunnel:
            self._tunnels[conn_id] = tunnel

        record: Dict[str, Any] = {
            "id": conn_id,
            "name": name,
            "uploaded_file_name": config.uploaded_file_name,
            "db_type": db_type,
            "connection_string": cs,
            "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
            "tables_count": test_result["tables_count"],
            "views_count": test_result.get("views_count", 0),
            "schemas": test_result.get("schemas", []),
            "ssh_tunnel_enabled": config.ssh_tunnel is not None,
            "ssh_host": (
                config.ssh_tunnel.ssh_host if config.ssh_tunnel else None
            ),
        }
        if config.file_content_hash:
            record["file_content_hash"] = config.file_content_hash
        if user_id:
            record["user_id"] = user_id
        if config.ssh_tunnel:
            record["ssh_config"] = {
                "ssh_host": config.ssh_tunnel.ssh_host,
                "ssh_port": config.ssh_tunnel.ssh_port,
                "ssh_username": config.ssh_tunnel.ssh_username,
                "has_password": bool(config.ssh_tunnel.ssh_password),
                "has_private_key": bool(config.ssh_tunnel.ssh_private_key),
            }

        self._connections[conn_id] = record
        self._persist()

        return {
            "ok": True,
            "connection_id": conn_id,
            "name": name,
            "db_type": db_type,
            "dialect": record["dialect"],
            "tables_count": test_result["tables_count"],
            "views_count": test_result.get("views_count", 0),
            "schemas": test_result.get("schemas", []),
            "connection_string_masked": mask_connection_string(cs),
            "ssh_tunnel_active": config.ssh_tunnel is not None,
            "message": "Connection saved successfully",
        }

    # --- CRUD ---

    def _verify_ownership(self, connection_id: str, user_id: str) -> None:
        """Raise ValueError if connection doesn't belong to user."""
        c = self._connections.get(connection_id)
        if not c:
            raise ValueError(f"Connection '{connection_id}' not found")
        if user_id and c.get("user_id") and c["user_id"] != user_id:
            raise ValueError(f"Connection '{connection_id}' not found")

    def list_connections(self, *, user_id: str = None) -> List[Dict[str, Any]]:
        # Always re-load from DB so list reflects current state across workers
        # (fixes multi-worker and ensures deleted connectors don't reappear in list)
        self._load_persisted()
        out = []
        for c in self._connections.values():
            # Filter by user_id if provided
            if user_id and c.get("user_id") and c["user_id"] != user_id:
                continue
            out.append(
                {
                    "id": c["id"],
                    "name": c.get("name", "Unnamed"),
                    "uploaded_file_name": c.get("uploaded_file_name"),
                    "db_type": c.get("db_type", "unknown"),
                    "dialect": c.get("dialect", "unknown"),
                    "connection_string_masked": mask_connection_string(
                        c.get("connection_string", "")
                    ),
                    "tables_count": c.get("tables_count", 0),
                    "views_count": c.get("views_count", 0),
                    "ssh_tunnel_enabled": c.get("ssh_tunnel_enabled", False),
                    "ssh_host": c.get("ssh_host"),
                }
            )
        return out

    def get_connection(self, connection_id: str, *, user_id: str = None) -> Optional[Dict[str, Any]]:
        c = self._connections.get(connection_id)
        if not c:
            return None
        if user_id and c.get("user_id") and c["user_id"] != user_id:
            return None
        return {
            "id": c["id"],
            "name": c.get("name", "Unnamed"),
            "uploaded_file_name": c.get("uploaded_file_name"),
            "db_type": c.get("db_type", "unknown"),
            "dialect": c.get("dialect", "unknown"),
            "connection_string_masked": mask_connection_string(
                c.get("connection_string", "")
            ),
            "tables_count": c.get("tables_count", 0),
            "views_count": c.get("views_count", 0),
            "schemas": c.get("schemas", []),
            "ssh_tunnel_enabled": c.get("ssh_tunnel_enabled", False),
            "ssh_config": c.get("ssh_config"),
        }

    def delete_connection(self, connection_id: str, *, user_id: str = None) -> Dict[str, Any]:
        logger.info(
            "[CONNECTOR_DELETE] start connection_id=%s",
            connection_id,
        )
        if connection_id not in self._connections:
            raise ValueError(f"Connection '{connection_id}' not found")
        logger.info(
            "[CONNECTOR_DELETE] connection=%s",
            self._connections[connection_id],
        )
        if user_id:
            self._verify_ownership(connection_id, user_id)

        engine = self._engines.pop(connection_id, None)
        logger.info(
            "[CONNECTOR_DELETE] disposing engine"
        )
        if engine:
            engine.dispose()
        tunnel = self._tunnels.pop(connection_id, None)
        if tunnel:
            tunnel.stop()
        logger.info(
            "[CONNECTOR_DELETE] stopping tunnel"
        )

        name = self._connections[connection_id].get("name", "Unnamed")
        logger.info(
            "[CONNECTOR_DELETE] removing in-memory connection"
        )
        del self._connections[connection_id]
        self._persist()
        logger.info(
            "[CONNECTOR_DELETE] persisted deletion"
        )
        logger.info(
            "[CONNECTOR_DELETE] completed name=%s id=%s",
            name,
            connection_id,
        )
        return {"ok": True, "deleted_id": connection_id, "name": name}

    def update_connection(
        self, connection_id: str, updates: Dict[str, Any], *, user_id: str = None
    ) -> Dict[str, Any]:
        if connection_id not in self._connections:
            raise ValueError(f"Connection '{connection_id}' not found")
        if user_id:
            self._verify_ownership(connection_id, user_id)
        c = self._connections[connection_id]
        if "name" in updates:
            c["name"] = updates["name"]
        self._connections[connection_id] = c
        self._persist()
        return {"ok": True, "connection_id": connection_id, "name": c.get("name")}

    def update_connection_with_config(
        self, connection_id: str, config: DBConnectionConfig, *, user_id: str = None
    ) -> Dict[str, Any]:
        """
        Update an existing saved connection with new config (e.g. new DB file path).
        Tests the new connection, replaces engine/record, and persists.
        Same response shape as connect_and_save.
        """
        if connection_id not in self._connections:
            raise ValueError(f"Connection '{connection_id}' not found")
        if user_id:
            self._verify_ownership(connection_id, user_id)

        test_result = self.test_connection(config)
        cs = build_connection_string(config)
        db_type = config.db_type or _infer_db_type(cs)
        name = (config.name or "").strip() or self._connections[connection_id].get(
            "name", f"{DB_TYPES.get(db_type, {}).get('label', db_type)} connection"
        )

        # Dispose old engine and tunnel for this connection
        if connection_id in self._engines:
            old_engine = self._engines.pop(connection_id, None)
            if old_engine:
                try:
                    old_engine.dispose()
                except Exception:
                    pass
        if connection_id in self._tunnels:
            old_tunnel = self._tunnels.pop(connection_id, None)
            if old_tunnel:
                try:
                    old_tunnel.stop()
                except Exception:
                    pass

        engine, tunnel = self._create_engine(cs, config)
        self._engines[connection_id] = engine
        if tunnel:
            self._tunnels[connection_id] = tunnel

        record: Dict[str, Any] = {
            "id": connection_id,
            "name": name,
            "uploaded_file_name": config.uploaded_file_name,
            "db_type": db_type,
            "connection_string": cs,
            "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
            "tables_count": test_result["tables_count"],
            "views_count": test_result.get("views_count", 0),
            "schemas": test_result.get("schemas", []),
            "ssh_tunnel_enabled": config.ssh_tunnel is not None,
            "ssh_host": (
                config.ssh_tunnel.ssh_host if config.ssh_tunnel else None
            ),
        }
        if config.ssh_tunnel:
            record["ssh_config"] = {
                "ssh_host": config.ssh_tunnel.ssh_host,
                "ssh_port": config.ssh_tunnel.ssh_port,
                "ssh_username": config.ssh_tunnel.ssh_username,
                "has_password": bool(config.ssh_tunnel.ssh_password),
                "has_private_key": bool(config.ssh_tunnel.ssh_private_key),
            }
        else:
            record["ssh_config"] = None

        self._connections[connection_id] = record
        self._persist()

        return {
            "ok": True,
            "connection_id": connection_id,
            "name": name,
            "db_type": db_type,
            "dialect": record["dialect"],
            "tables_count": test_result["tables_count"],
            "views_count": test_result.get("views_count", 0),
            "schemas": test_result.get("schemas", []),
            "connection_string_masked": mask_connection_string(cs),
            "ssh_tunnel_active": config.ssh_tunnel is not None,
            "message": "Connection updated successfully",
        }

    # ---- schema introspection ----

    def _get_engine(self, connection_id: str) -> Engine:
        if connection_id in self._engines:
            return self._engines[connection_id]
        c = self._connections.get(connection_id)
        if not c:
            raise ValueError(f"Connection '{connection_id}' not found")
        cs = c.get("connection_string")
        if not cs:
            raise ValueError(f"Connection '{connection_id}' has no connection_string")
        cfg = DBConnectionConfig(connection_string=cs)
        engine, tunnel = self._create_engine(cs, cfg)
        self._engines[connection_id] = engine
        if tunnel:
            self._tunnels[connection_id] = tunnel
        return engine

    def get_schemas(self, connection_id: str) -> Dict[str, Any]:
        engine = self._get_engine(connection_id)
        insp = inspect(engine)
        schemas: List[str] = []
        try:
            schemas = insp.get_schema_names()
        except Exception:
            pass
        return {"connection_id": connection_id, "schemas": schemas}

    def get_tables(
        self, connection_id: str, schema_name: Optional[str] = None
    ) -> Dict[str, Any]:
        engine = self._get_engine(connection_id)
        insp = inspect(engine)
        tables = insp.get_table_names(schema=schema_name)
        views: List[str] = []
        try:
            views = insp.get_view_names(schema=schema_name)
        except Exception:
            pass
        return {
            "connection_id": connection_id,
            "schema": schema_name or "default",
            "tables": tables,
            "views": views,
            "tables_count": len(tables),
            "views_count": len(views),
        }

    def get_full_schema(
        self, connection_id: str, schema_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Full introspection: columns, PKs, FKs, indexes, row counts."""
        engine = self._get_engine(connection_id)
        insp = inspect(engine)

        tables_info: List[Dict[str, Any]] = []
        for table in insp.get_table_names(schema=schema_name):
            cols = []
            try:
                for col in insp.get_columns(table, schema=schema_name):
                    cols.append(
                        {
                            "name": col["name"],
                            "type": str(col["type"]),
                            "nullable": col.get("nullable", True),
                            "default": (
                                str(col["default"]) if col.get("default") else None
                            ),
                            "autoincrement": col.get("autoincrement"),
                        }
                    )
            except Exception as e:
                cols = [{"error": str(e)}]

            pk: List[str] = []
            try:
                pk_info = insp.get_pk_constraint(table, schema=schema_name)
                pk = pk_info.get("constrained_columns", []) if pk_info else []
            except Exception:
                pass

            fks: List[Dict[str, Any]] = []
            try:
                for fk in insp.get_foreign_keys(table, schema=schema_name):
                    fks.append(
                        {
                            "constrained_columns": fk.get("constrained_columns", []),
                            "referred_table": fk.get("referred_table"),
                            "referred_columns": fk.get("referred_columns", []),
                            "referred_schema": fk.get("referred_schema"),
                        }
                    )
            except Exception:
                pass

            indexes: List[Dict[str, Any]] = []
            try:
                for idx in insp.get_indexes(table, schema=schema_name):
                    indexes.append(
                        {
                            "name": idx.get("name"),
                            "columns": idx.get("column_names", []),
                            "unique": idx.get("unique", False),
                        }
                    )
            except Exception:
                pass

            row_count = None
            try:
                sp = f'"{schema_name}".' if schema_name else ""
                with engine.connect() as conn:
                    r = conn.execute(text(f'SELECT COUNT(*) FROM {sp}"{table}"'))
                    row_count = r.scalar()
            except Exception:
                pass

            tables_info.append(
                {
                    "table_name": table,
                    "columns": cols,
                    "primary_key": pk,
                    "foreign_keys": fks,
                    "indexes": indexes,
                    "row_count": row_count,
                }
            )

        views_info: List[Dict[str, Any]] = []
        try:
            for view in insp.get_view_names(schema=schema_name):
                vcols = []
                try:
                    for col in insp.get_columns(view, schema=schema_name):
                        vcols.append(
                            {"name": col["name"], "type": str(col["type"])}
                        )
                except Exception:
                    pass
                views_info.append({"view_name": view, "columns": vcols})
        except Exception:
            pass

        conn_info = self._connections.get(connection_id, {})
        return {
            "connection_id": connection_id,
            "name": conn_info.get("name", "Unknown"),
            "db_type": conn_info.get("db_type", "unknown"),
            "schema": schema_name or "default",
            "tables": tables_info,
            "views": views_info,
            "tables_count": len(tables_info),
            "views_count": len(views_info),
        }

    def preview_table(
        self,
        connection_id: str,
        table_name: str,
        schema_name: Optional[str] = None,
        limit: int = 50,
    ) -> Dict[str, Any]:
        engine = self._get_engine(connection_id)
        sp = f'"{schema_name}".' if schema_name else ""
        db_type = self._connections.get(connection_id, {}).get("db_type", "")

        if db_type == "mssql":
            q = f"SELECT TOP {limit} * FROM {sp}[{table_name}]"
        elif db_type == "oracle":
            q = f'SELECT * FROM {sp}"{table_name}" WHERE ROWNUM <= {limit}'
        else:
            q = f'SELECT * FROM {sp}"{table_name}" LIMIT {limit}'

        try:
            with engine.connect() as conn:
                result = conn.execute(text(q))
                columns = list(result.keys())
                rows = [dict(zip(columns, row)) for row in result.fetchall()]
                return {
                    "connection_id": connection_id,
                    "table_name": table_name,
                    "columns": columns,
                    "rows": rows,
                    "row_count": len(rows),
                    "limited_to": limit,
                }
        except Exception as exc:
            raise ValueError(f"Error previewing table '{table_name}': {exc}")

    def execute_query(
        self,
        connection_id: str,
        query: str,
        limit: int = 100,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        engine = self._get_engine(connection_id)
        q = query.strip()
        q_upper = q.upper()
        is_read = q_upper.startswith(("SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN"))

        try:
            with engine.connect() as conn:
                result = conn.execute(text(q))
                if is_read:
                    columns = list(result.keys())
                    rows = [
                        dict(zip(columns, row)) for row in result.fetchmany(limit)
                    ]
                    return {
                        "connection_id": connection_id,
                        "query": q,
                        "columns": columns,
                        "rows": rows,
                        "row_count": len(rows),
                        "limited_to": limit,
                        "type": "select",
                    }
                else:
                    conn.commit()
                    return {
                        "connection_id": connection_id,
                        "query": q,
                        "rows_affected": result.rowcount,
                        "type": "execute",
                        "message": f"Query executed. Rows affected: {result.rowcount}",
                    }
        except Exception as exc:
            raise ValueError(f"Query execution failed: {exc}")

    def invoke_with_question(
        self,
        connection_id: str,
        question: str,
        limit: int = 100,
        timeout: int = 30,
        *,
        user_id: str = None,
    ) -> Dict[str, Any]:
        """
        Answer a natural language question by generating SQL via LLM and executing it
        on the saved connection. Requires DB_INVOKE_LLM_URL (and optionally
        DB_INVOKE_LLM_MODEL) to be set.
        """
        conn = self._connections.get(connection_id)
        if not conn:
            raise ValueError(f"Connection '{connection_id}' not found")
        if user_id and conn.get("user_id") and conn["user_id"] != user_id:
            raise ValueError(f"Connection '{connection_id}' not found")
        db_type = conn.get("db_type", "sqlite")
        schema_result = self.get_full_schema(connection_id, schema_name=None)
        schema_summary = _build_schema_summary_for_nl(schema_result)
        generated_sql, explanation = _generate_sql_via_llm(
            question, schema_summary, db_type, limit=limit
        )
        result = self.execute_query(
            connection_id=connection_id,
            query=generated_sql,
            limit=limit,
            timeout=timeout,
        )
        result["question"] = question
        result["generated_sql"] = generated_sql
        result["explanation"] = explanation
        # Convobi-style narrative summary for read results
        if result.get("type") == "select" and result.get("rows") is not None and result.get("columns"):
            summary_text = _summarize_result_for_question(
                question, result["columns"], result["rows"]
            )
            if summary_text:
                result["summary"] = summary_text
        return result

    # ---- cleanup ----

    def cleanup(self):
        for engine in self._engines.values():
            try:
                engine.dispose()
            except Exception:
                pass
        self._engines.clear()
        for tunnel in self._tunnels.values():
            try:
                tunnel.stop()
            except Exception:
                pass
        self._tunnels.clear()



# """
# Universal Database Connector Service
# =====================================
# Supports connecting to any SQL database — both **public** (direct) and
# **private** (SSH tunnel through a bastion/jump host).

# Supported databases:
#   PostgreSQL · MySQL · MariaDB · Microsoft SQL Server · Oracle
#   SQLite · Google BigQuery · Snowflake · ClickHouse · Amazon Redshift

# Frontend form fields (matches UI):
#   Database Type  ·  Host  ·  Port  ·  Database Name
#   Username  ·  Password  ·  [Server IP shown for firewall rules]
# """

# import json
# import logging
# import os
# import re
# import socket
# import uuid
# from typing import Any, Dict, List, Optional, Tuple
# from urllib.parse import quote_plus, urlparse

# import httpx
# from pydantic import BaseModel, ConfigDict, Field
# from sqlalchemy import create_engine, inspect, text
# from sqlalchemy.engine import Engine

# logger = logging.getLogger(__name__)

# # ---------------------------------------------------------------------------
# # Persistence – PostgreSQL
# # ---------------------------------------------------------------------------
# from echolib.config import settings as _echo_settings

# _pg_sync_engine: Optional[Engine] = None


# def _get_pg_sync_url() -> str:
#     """Convert the async DATABASE_URL to a synchronous psycopg2 URL.

#     Also normalises the ``ssl`` query parameter to ``sslmode`` because
#     psycopg2 does not recognise ``ssl`` as a valid libpq connection
#     option (asyncpg accepts it, but psycopg2/libpq expects ``sslmode``).
#     """
#     url = _echo_settings.database_url
#     if "+asyncpg" in url:
#         url = url.replace("+asyncpg", "+psycopg2")
#     elif url.startswith("postgresql://"):
#         url = url.replace("postgresql://", "postgresql+psycopg2://", 1)

#     # Normalise ?ssl=<value> → ?sslmode=<value> for psycopg2/libpq compat
#     parsed = urlparse(url)
#     if parsed.query:
#         from urllib.parse import parse_qs, urlencode
#         params = parse_qs(parsed.query, keep_blank_values=True)
#         if "ssl" in params and "sslmode" not in params:
#             params["sslmode"] = params.pop("ssl")
#             new_query = urlencode(params, doseq=True)
#             url = parsed._replace(query=new_query).geturl()

#     return url


# def _get_pg_engine() -> Engine:
#     """Get or create a synchronous PostgreSQL engine for DB-connection persistence."""
#     global _pg_sync_engine
#     if _pg_sync_engine is not None:
#         return _pg_sync_engine

#     _pg_sync_engine = create_engine(
#         _get_pg_sync_url(), pool_pre_ping=True, pool_size=2, max_overflow=3
#     )
#     return _pg_sync_engine

# # When creating a connection with this name, use this fixed connection_id (for ITSM DB default)
# ITSM_CONNECTION_NAME = "MSSQL-ITSM"
# ITSM_DEFAULT_CONNECTION_ID = "9eb2583a"

# # When creating a connection with this name, use this fixed connection_id (for CRM DB default)
# CRM_CONNECTION_NAME = "CRM-DB"
# CRM_DEFAULT_CONNECTION_ID = "3cf29b94"

# # ---------------------------------------------------------------------------
# # Supported database types  (drives the "Database Type" dropdown)
# # ---------------------------------------------------------------------------
# DB_TYPES: Dict[str, Dict[str, Any]] = {
#     "postgresql": {
#         "label": "PostgreSQL",
#         "default_port": 5432,
#         "driver": "postgresql+psycopg2",
#         "drivers_available": [
#             "postgresql+psycopg2",
#             "postgresql+asyncpg",
#             "postgresql+pg8000",
#         ],
#         "placeholder_host": "db.example.com",
#     },
#     "mysql": {
#         "label": "MySQL",
#         "default_port": 3306,
#         "driver": "mysql+pymysql",
#         "drivers_available": ["mysql+pymysql", "mysql+mysqlconnector"],
#         "placeholder_host": "db.example.com",
#     },
#     "mariadb": {
#         "label": "MariaDB",
#         "default_port": 3306,
#         "driver": "mariadb+pymysql",
#         "drivers_available": ["mariadb+pymysql"],
#         "placeholder_host": "db.example.com",
#     },
#     "mssql": {
#         "label": "Microsoft SQL Server",
#         "default_port": 1433,
#         "driver": "mssql+pymssql",
#         "drivers_available": ["mssql+pymssql", "mssql+pyodbc"],
#         "placeholder_host": "sqlserver.example.com",
#     },
#     "oracle": {
#         "label": "Oracle",
#         "default_port": 1521,
#         "driver": "oracle+oracledb",
#         "drivers_available": ["oracle+oracledb", "oracle+cx_oracle"],
#         "placeholder_host": "oracle.example.com",
#     },
#     "sqlite": {
#         "label": "SQLite",
#         "default_port": None,
#         "driver": "sqlite",
#         "drivers_available": ["sqlite"],
#         "placeholder_host": "(upload DB file)",
#         "supports_file_upload": True,
#     },
#     "bigquery": {
#         "label": "Google BigQuery",
#         "default_port": None,
#         "driver": "bigquery",
#         "drivers_available": ["bigquery"],
#         "placeholder_host": "project-id",
#     },
#     "snowflake": {
#         "label": "Snowflake",
#         "default_port": 443,
#         "driver": "snowflake",
#         "drivers_available": ["snowflake"],
#         "placeholder_host": "account.snowflakecomputing.com",
#     },
#     "clickhouse": {
#         "label": "ClickHouse",
#         "default_port": 9000,
#         "driver": "clickhouse+native",
#         "drivers_available": ["clickhouse+native", "clickhouse+http"],
#         "placeholder_host": "localhost",
#     },
#     "redshift": {
#         "label": "Amazon Redshift",
#         "default_port": 5439,
#         "driver": "redshift+psycopg2",
#         "drivers_available": ["redshift+psycopg2"],
#         "placeholder_host": "cluster.region.redshift.amazonaws.com",
#     },
#     "hive": {
#         "label": "Apache Hive",
#         "default_port": 10000,
#         "driver": "hive",
#         "drivers_available": ["hive"],
#         "placeholder_host": "localhost",
#     },
#     "duckdb": {
#         "label": "DuckDB",
#         "default_port": None,
#         "driver": "duckdb",
#         "drivers_available": ["duckdb"],
#         "placeholder_host": "(upload DB file)",
#         "supports_file_upload": True,
#     },
# }

# # ---------------------------------------------------------------------------
# # Pydantic request / config models
# # ---------------------------------------------------------------------------


# class SSHTunnelConfig(BaseModel):
#     """SSH tunnel configuration for accessing private / firewalled databases."""

#     ssh_host: str = Field(..., description="SSH bastion / jump host address")
#     ssh_port: int = Field(22, description="SSH port")
#     ssh_username: str = Field(..., description="SSH username")
#     ssh_password: Optional[str] = Field(
#         None, description="SSH password (if not using key)"
#     )
#     ssh_private_key: Optional[str] = Field(
#         None, description="SSH private key content (PEM format)"
#     )
#     ssh_private_key_passphrase: Optional[str] = Field(
#         None, description="Passphrase for the private key"
#     )


# class DBConnectionConfig(BaseModel):
#     """
#     Database connection configuration — matches the frontend form exactly.

#     **Mode 1 – Structured parameters (preferred, matches UI form):**
#         db_type, host, port, database_name, username, password

#     **Mode 2 – Raw connection string:**
#         connection_string  (full SQLAlchemy DSN)

#     For **private databases** behind firewalls add ``ssh_tunnel``.
#     """

#     model_config = ConfigDict(populate_by_name=True)

#     # ---- Mode 1: form fields (matches UI) ----
#     db_type: Optional[str] = Field(
#         None,
#         description=(
#             "Database type key from the dropdown: "
#             "postgresql, mysql, mariadb, mssql, oracle, sqlite, "
#             "bigquery, snowflake, clickhouse, redshift, hive, duckdb"
#         ),
#     )
#     host: Optional[str] = Field(None, description="Database host / IP address")
#     port: Optional[int] = Field(
#         None, description="Database port (auto-filled per db_type if omitted)"
#     )
#     database_name: Optional[str] = Field(
#         None,
#         alias="databaseName",
#         description="Database name (or file path for SQLite, project-id for BigQuery)",
#     )
#     username: Optional[str] = Field(None, description="Database username")
#     password: Optional[str] = Field(None, description="Database password")

#     # ---- Snowflake-specific ----
#     account_url: Optional[str] = Field(
#         None,
#         description=(
#             "Snowflake account URL, e.g. 'your-account.snowflakecomputing.com'. "
#             "Used instead of host/port for Snowflake connections."
#         ),
#     )

#     # ---- SQL Server ODBC-specific ----
#     odbc_connection_string: Optional[str] = Field(
#         None,
#         alias="odbcConnectionString",
#         description=(
#             "Raw ODBC connection string for SQL Server, e.g. "
#             "'Driver={ODBC Driver 17 for SQL Server};Server=server;Database=database;UID=user;PWD=password;'"
#         ),
#     )

#     # ---- File-based databases (SQLite, DuckDB) ----
#     database_file_path: Optional[str] = Field(
#         None,
#         description=(
#             "Server path to DB file (set automatically when using uploaded_db_file_id). "
#             "Or provide a path manually for server-side files. "
#             "For DuckDB: file path or :memory:"
#         ),
#     )
#     uploaded_db_file_id: Optional[str] = Field(
#         None,
#         description=(
#             "ID returned from POST /connectors/db/upload. Use this to connect via uploaded DB file "
#             "instead of database_file_path. Supported for db_type: sqlite, duckdb."
#         ),
#     )

#     # ---- Mode 2: raw DSN ----
#     connection_string: Optional[str] = Field(
#         None,
#         description=(
#             "Full SQLAlchemy connection string, e.g. "
#             "postgresql://user:pass@host:5432/mydb. "
#             "When provided, the form fields above are ignored."
#         ),
#     )

#     # ---- Advanced ----
#     driver: Optional[str] = Field(
#         None,
#         description=(
#             "Database driver. Can be a SQLAlchemy dialect (e.g. 'mssql+pyodbc') "
#             "OR an ODBC driver name (e.g. 'ODBC Driver 18 for SQL Server'). "
#             "ODBC names are automatically placed into the query string. "
#             "Auto-selected if omitted."
#         ),
#     )
#     extra_params: Optional[Dict[str, str]] = Field(
#         None,
#         description=(
#             "Additional query-string parameters, e.g. "
#             "{'charset': 'utf8mb4', 'driver': 'ODBC Driver 18 for SQL Server'}"
#         ),
#     )
#     connect_args: Optional[Dict[str, Any]] = Field(
#         None,
#         description="Dict passed to create_engine(connect_args=...). Useful for SSL certificates etc.",
#     )
#     pool_size: int = Field(5, description="Connection pool size")
#     pool_timeout: int = Field(30, description="Pool timeout in seconds")

#     # ---- SSH tunnel for private databases ----
#     ssh_tunnel: Optional[SSHTunnelConfig] = Field(
#         None,
#         description="SSH tunnel config for private databases behind firewalls",
#     )

#     # ---- Display / save ----
#     name: Optional[str] = Field(
#         None,
#         alias="integrationName",
#         description="Display name for the saved connection (also accepts 'integrationName')",
#     )

#     # ---- Internal: file content hash for deduplication (SQLite/DuckDB uploads) ----
#     file_content_hash: Optional[str] = Field(
#         None,
#         description="SHA256 hash of uploaded file content; used to avoid duplicate connections for same file",
#     )


# class DBQueryRequest(BaseModel):
#     """Execute a query on a saved connection."""

#     query: str = Field(..., description="SQL query to execute")
#     limit: int = Field(100, description="Max rows to return")
#     timeout: int = Field(30, description="Query timeout in seconds")


# # ---------------------------------------------------------------------------
# # SSH Tunnel helper
# # ---------------------------------------------------------------------------


# class _SSHTunnelWrapper:
#     """Manages an SSH tunnel lifecycle."""

#     def __init__(
#         self, config: SSHTunnelConfig, remote_host: str, remote_port: int
#     ):
#         self.config = config
#         self.remote_host = remote_host
#         self.remote_port = remote_port
#         self._tunnel = None

#     def start(self) -> Tuple[str, int]:
#         """Start the tunnel. Returns (local_host, local_port)."""
#         try:
#             from sshtunnel import SSHTunnelForwarder
#         except ImportError:
#             raise ImportError(
#                 "The 'sshtunnel' package is required for SSH tunneling. "
#                 "Install it with:  pip install sshtunnel"
#             )

#         kwargs: Dict[str, Any] = {
#             "ssh_address_or_host": (self.config.ssh_host, self.config.ssh_port),
#             "ssh_username": self.config.ssh_username,
#             "remote_bind_address": (self.remote_host, self.remote_port),
#         }

#         if self.config.ssh_private_key:
#             import io
#             import paramiko

#             pkey = paramiko.RSAKey.from_private_key(
#                 io.StringIO(self.config.ssh_private_key),
#                 password=self.config.ssh_private_key_passphrase,
#             )
#             kwargs["ssh_pkey"] = pkey
#         elif self.config.ssh_password:
#             kwargs["ssh_password"] = self.config.ssh_password
#         else:
#             raise ValueError(
#                 "SSH tunnel requires either ssh_password or ssh_private_key"
#             )

#         self._tunnel = SSHTunnelForwarder(**kwargs)
#         self._tunnel.start()
#         local_host = "127.0.0.1"
#         local_port = self._tunnel.local_bind_port
#         logger.info(
#             "SSH tunnel established: %s:%s -> %s:%s",
#             local_host,
#             local_port,
#             self.remote_host,
#             self.remote_port,
#         )
#         return local_host, local_port

#     def stop(self):
#         if self._tunnel:
#             self._tunnel.stop()
#             self._tunnel = None
#             logger.info("SSH tunnel closed")


# # ---------------------------------------------------------------------------
# # Connection-string builder
# # ---------------------------------------------------------------------------


# def build_connection_string(config: DBConnectionConfig) -> str:
#     """
#     Build a SQLAlchemy DSN from the structured form fields.
#     If ``config.connection_string`` is already provided, return it as-is.
#     """
#     if config.connection_string:
#         return config.connection_string.strip()

#     if not config.db_type:
#         raise ValueError("Either 'connection_string' or 'db_type' must be provided")

#     db_type = config.db_type.lower()
#     if db_type not in DB_TYPES:
#         raise ValueError(
#             f"Unsupported db_type '{db_type}'. "
#             f"Supported: {', '.join(sorted(DB_TYPES.keys()))}"
#         )

#     info = DB_TYPES[db_type]

#     # --- SQLite (file-based) ---
#     if db_type == "sqlite":
#         path = config.database_file_path or config.database_name or ":memory:"
#         return f"sqlite:///{path}"

#     # --- DuckDB (file-based) ---
#     if db_type == "duckdb":
#         path = config.database_file_path or config.database_name or ":memory:"
#         # Strip file:// prefix if present – DuckDB SQLAlchemy driver expects raw path
#         if path.startswith("file:///"):
#             path = path[len("file:///"):]
#         elif path.startswith("file://"):
#             path = path[len("file://"):]
#         return f"duckdb:///{path}"

#     # --- BigQuery ---
#     if db_type == "bigquery":
#         project = config.database_name or ""
#         cs = f"bigquery://{project}"
#         if config.extra_params:
#             qs = "&".join(f"{k}={v}" for k, v in config.extra_params.items())
#             cs += f"?{qs}"
#         return cs

#     # --- SQL Server with raw ODBC connection string ---
#     if db_type == "mssql" and config.odbc_connection_string:
#         odbc_cs = config.odbc_connection_string.strip()
#         encoded = quote_plus(odbc_cs)
#         return f"mssql+pyodbc:///?odbc_connect={encoded}"

#     # --- Snowflake (uses account_url instead of host:port) ---
#     if db_type == "snowflake":
#         account = config.account_url or config.host or ""
#         # Remove trailing .snowflakecomputing.com if present
#         if account.endswith(".snowflakecomputing.com"):
#             account = account[: -len(".snowflakecomputing.com")]
#         user = quote_plus(config.username or "")
#         pwd = quote_plus(config.password or "")
#         db = config.database_name or ""
#         extra = dict(config.extra_params or {})
#         if user and pwd:
#             cs = f"snowflake://{user}:{pwd}@{account}/{db}"
#         elif user:
#             cs = f"snowflake://{user}@{account}/{db}"
#         else:
#             cs = f"snowflake://{account}/{db}"
#         if extra:
#             qs = "&".join(
#                 f"{k}={quote_plus(str(v))}" for k, v in extra.items()
#             )
#             cs += f"?{qs}"
#         return cs

#     # --- Resolve the driver ---
#     # The `driver` field can be either:
#     #   (a) a SQLAlchemy dialect+driver like "mssql+pyodbc"   →  used as URL scheme
#     #   (b) an ODBC driver name like "ODBC Driver 18 for SQL Server"
#     #       →  use the appropriate SQLAlchemy scheme and move the ODBC name into ?driver=
#     #   (c) omitted  →  use the default for this db_type
#     extra = dict(config.extra_params or {})
#     raw_driver = (config.driver or "").strip()

#     if raw_driver and ("+" not in raw_driver and "://" not in raw_driver):
#         # Looks like an ODBC / native driver name, not a SQLAlchemy dialect.
#         # e.g. "ODBC Driver 18 for SQL Server", "FreeTDS", "MySQL ODBC 8.0"
#         # → push it into the query-string as ?driver=... and pick the right
#         #   SQLAlchemy dialect automatically.
#         extra["driver"] = raw_driver
#         if db_type == "mssql":
#             sa_driver = "mssql+pyodbc"
#         elif db_type in ("mysql", "mariadb"):
#             sa_driver = info["driver"]  # mysql+pymysql, etc.
#         else:
#             sa_driver = info["driver"]
#     elif raw_driver:
#         sa_driver = raw_driver          # already a proper SQLAlchemy driver
#     else:
#         sa_driver = info["driver"]      # default for this db_type

#     host = config.host or "localhost"
#     port = config.port or info["default_port"]
#     user = quote_plus(config.username or "")
#     pwd = quote_plus(config.password or "")
#     db = config.database_name or ""

#     if user and pwd:
#         cs = f"{sa_driver}://{user}:{pwd}@{host}:{port}/{db}"
#     elif user:
#         cs = f"{sa_driver}://{user}@{host}:{port}/{db}"
#     else:
#         cs = f"{sa_driver}://{host}:{port}/{db}"

#     if extra:
#         qs = "&".join(
#             f"{k}={quote_plus(str(v))}" for k, v in extra.items()
#         )
#         cs += f"?{qs}"

#     return cs


# def _infer_db_type(connection_string: str) -> str:
#     """Infer db_type from a DSN scheme."""
#     scheme = urlparse(connection_string).scheme.lower().split("+")[0]
#     mapping = {
#         "postgresql": "postgresql",
#         "postgres": "postgresql",
#         "mysql": "mysql",
#         "mariadb": "mariadb",
#         "mssql": "mssql",
#         "oracle": "oracle",
#         "sqlite": "sqlite",
#         "bigquery": "bigquery",
#         "snowflake": "snowflake",
#         "clickhouse": "clickhouse",
#         "redshift": "redshift",
#         "hive": "hive",
#         "duckdb": "duckdb",
#     }
#     return mapping.get(scheme, scheme)


# # ---------------------------------------------------------------------------
# # Mask password
# # ---------------------------------------------------------------------------


# def mask_connection_string(cs: str) -> str:
#     """Mask password in a DSN for safe display."""
#     if not cs or "://" not in cs:
#         return cs or ""
#     try:
#         scheme, rest = cs.split("://", 1)
#         if "@" in rest:
#             creds, host_part = rest.split("@", 1)
#             if ":" in creds:
#                 user, _ = creds.split(":", 1)
#                 return f"{scheme}://{user}:****@{host_part}"
#         return f"{scheme}://****"
#     except Exception:
#         return "***"


# def _format_connection_error(exc: Exception, connection_string: str) -> str:
#     """Return a user-friendly connection error message (optionally with ODBC hints)."""
#     msg = str(exc).lower()
#     cs = (connection_string or "").strip()
#     scheme = urlparse(cs).scheme.lower() if cs else ""
#     if "im002" in msg or "data source name not found" in msg or "no default driver specified" in msg:
#         hint = (
#             "ODBC Driver Manager could not find a driver or DSN. "
#             "On Windows: install the correct ODBC driver (e.g. 'ODBC Driver 17/18 for SQL Server'). "
#             "Alternatively use mssql+pymssql://user:pass@host/db (pip install pymssql), or mssql+pyodbc://... with driver= in the query string."
#         )
#         return f"Connection failed: {exc}. {hint}"
#     if "mssql" in scheme or "sql server" in msg:
#         if "pyodbc" in msg or "odbc" in msg:
#             return (
#                 f"Connection failed: {exc}. "
#                 "For SQL Server: install 'ODBC Driver 17/18 for SQL Server' or use mssql+pymssql (pip install pymssql)."
#             )
#     return f"Connection failed: {exc}"


# # ---------------------------------------------------------------------------
# # Server public IP helper  (shown on the form so users can whitelist it)
# # ---------------------------------------------------------------------------

# _cached_server_ip: Optional[str] = None


# def get_server_public_ip() -> str:
#     """
#     Return the server's public IP address.
#     The frontend shows this so the user can add it to their DB firewall rules.
#     """
#     global _cached_server_ip
#     if _cached_server_ip:
#         return _cached_server_ip

#     # Try multiple services for reliability
#     services = [
#         "https://api.ipify.org",
#         "https://ifconfig.me/ip",
#         "https://icanhazip.com",
#         "https://checkip.amazonaws.com",
#     ]
#     for url in services:
#         try:
#             resp = httpx.get(url, timeout=5.0)
#             if resp.status_code == 200:
#                 ip = resp.text.strip()
#                 if ip:
#                     _cached_server_ip = ip
#                     return ip
#         except Exception:
#             continue

#     # Fallback: local hostname resolution
#     try:
#         hostname = socket.gethostname()
#         ip = socket.gethostbyname(hostname)
#         _cached_server_ip = ip
#         return ip
#     except Exception:
#         return "unknown"


# # ---------------------------------------------------------------------------
# # Natural language → SQL (for /db/invoke with question)
# # ---------------------------------------------------------------------------

# # Env: DB_INVOKE_LLM_URL = base URL for LLM API (e.g. http://localhost:8000), used as {url}/LLMs/chat
# # Env: DB_INVOKE_LLM_MODEL = optional model_id; if not set, first model from /LLMs/models is used


# def _build_schema_summary_for_nl(schema_result: Dict[str, Any]) -> str:
#     """Build a compact schema summary string for the LLM prompt from get_full_schema output."""
#     lines: List[str] = []
#     for table in schema_result.get("tables", [])[:30]:
#         tname = table.get("table_name", "?")
#         cols = table.get("columns", [])
#         col_strs = [f"{c.get('name', '?')} ({str(c.get('type', '')).split('(')[0]})" for c in cols[:25]]
#         lines.append(f"Table: {tname}\n  Columns: {', '.join(col_strs)}")
#     for view in schema_result.get("views", [])[:10]:
#         vname = view.get("view_name", "?")
#         cols = view.get("columns", [])
#         col_strs = [c.get("name", "?") for c in cols[:15]]
#         lines.append(f"View: {vname}\n  Columns: {', '.join(col_strs)}")
#     return "\n\n".join(lines) if lines else "No tables or views found."


# def _extract_sql_from_llm_response(raw: str) -> Tuple[str, str]:
#     """Parse LLM response for JSON with 'sql' and optional 'explanation'. Returns (sql, explanation)."""
#     explanation = ""
#     raw_clean = raw.strip()
#     # Strip common LLM prefixes that break json.loads (e.g. "json\n{...}" or "```json\n{...}")
#     if raw_clean.lower().startswith("json"):
#         raw_clean = raw_clean[4:].lstrip()
#     if raw_clean.startswith("```"):
#         raw_clean = re.sub(r"^```(?:json)?\s*", "", raw_clean, flags=re.IGNORECASE)
#         raw_clean = re.sub(r"\s*```\s*$", "", raw_clean)
#     try:
#         data = json.loads(raw_clean)
#         sql = (data.get("sql") or "").strip()
#         explanation = (data.get("explanation") or "").strip()
#         if sql:
#             return _normalize_generated_sql(sql), explanation
#     except Exception:
#         pass
#     # Fallback: look for ```sql ... ``` or SELECT... block in original raw
#     m = re.search(r"```(?:sql)?\s*([\s\S]+?)```", raw, re.IGNORECASE)
#     if m:
#         sql = m.group(1).strip().strip(";")
#         return _normalize_generated_sql(sql), explanation
#     m2 = re.search(r"(\bSELECT\b[\s\S]+?)(?=\n\n|\n```|\Z)", raw, re.IGNORECASE | re.DOTALL)
#     if m2:
#         sql = m2.group(1).strip().strip(";")
#         return _normalize_generated_sql(sql), explanation
#     return "", explanation


# def _normalize_generated_sql(sql: str) -> str:
#     """Remove trailing semicolon and extra whitespace."""
#     if not sql:
#         return sql
#     sql = re.sub(r";\s*$", "", sql.strip())
#     return sql.strip()


# def _json_safe_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
#     """Convert row values to JSON-serializable form (e.g. datetime/decimal to str)."""
#     out = []
#     for row in rows:
#         safe = {}
#         for k, v in row.items():
#             if v is None or isinstance(v, (str, int, float, bool)):
#                 safe[k] = v
#             elif hasattr(v, "isoformat"):
#                 safe[k] = v.isoformat()
#             else:
#                 safe[k] = str(v)
#         out.append(safe)
#     return out


# def _summarize_result_for_question(
#     question: str, columns: List[str], rows: List[Dict[str, Any]]
# ) -> Optional[str]:
#     """
#     Generate a Convobi-style narrative summary of the query result using the same LLM.
#     Returns Markdown summary or None if LLM unavailable.
#     """
#     system = (
#         "You are a helpful analyst. Summarize tabular data clearly and concisely. "
#         "Always respond in valid Markdown."
#     )
#     sample = _json_safe_rows(rows[:20])
#     user = (
#         "Summarize the following query result for a non-technical stakeholder. Use Markdown only.\n"
#         f"Question: {question}\n"
#         f"Columns: {json.dumps(columns)}\n"
#         f"First rows (sample): {json.dumps(sample)}\n\n"
#         "Format your response in Markdown with these sections:\n"
#         "- ## Executive summary — one sentence\n"
#         "- ## Key observations — bullet list\n"
#         "- ## Notable trends / anomalies — short bullets or paragraph\n"
#         "- ## Suggested next steps — bullet list (optional)\n"
#         "Use ** for bold, - or * for bullets, ## for section headers. Keep it concise."
#     )
#     return _get_convobi_llm_response(system, user)


# def _get_convobi_llm_response(system: str, user: str) -> Optional[str]:
#     """
#     Use the lazily-resolved Convobi LLM to generate a response.

#     Delegates to _get_convobi_llm() which resolves per-user credentials
#     with a TTL cache. When called from db_connector (no user context),
#     falls back to platform credentials.

#     Returns the response text, or None if the LLM is not available.
#     """
#     try:
#         from apps.convobi.main import _get_convobi_llm
#         llm = _get_convobi_llm()
#         from langchain_core.messages import SystemMessage, HumanMessage
#         messages = [
#             SystemMessage(content=system),
#             HumanMessage(content=user),
#         ]
#         response = llm.invoke(messages)
#         return (getattr(response, "content", None) or str(response) or "").strip()
#     except Exception as e:
#         logger.debug("Convobi LLM not available for db/invoke: %s", e)
#         return None


# def _generate_sql_via_llm(
#     question: str,
#     schema_summary: str,
#     db_type: str,
#     limit: Optional[int] = None,
# ) -> Tuple[str, str]:
#     """
#     Generate SQL from natural language using Convobi's LLM (apps.convobi.main._get_convobi_llm)
#     if available; otherwise fall back to DB_INVOKE_LLM_URL HTTP API.
#     Returns (sql, explanation). Raises ValueError if no LLM available or call fails.
#     """
#     dialect_rules = ""
#     if db_type == "sqlite":
#         dialect_rules = (
#             "SQLite: do not use INTERVAL; use date('now','-N days'). Use strftime for dates. "
#             "No semicolon at end of statement."
#         )
#     elif db_type == "mssql":
#         dialect_rules = (
#             "Microsoft SQL Server: use TOP N for limit. Use GETDATE() for current date. "
#             "Use [brackets] for identifiers if needed. No semicolon at end."
#         )
#     else:
#         dialect_rules = (
#             f"Database: {db_type}. Use standard SQL. Use LIMIT for row limit where supported. "
#             "Do not end with semicolon."
#         )

#     system = (
#         "You are an expert SQL analyst. Generate only valid SQL from the user question using the given schema. "
#         "Return JSON with exactly: {\"sql\": \"SELECT ...\", \"explanation\": \"brief explanation\"}. "
#         "Use only tables and columns from the schema. "
#     ) + dialect_rules

#     user = (
#         f"Schema:\n{schema_summary}\n\n"
#         f"Question: {question}\n\n"
#         f"Max rows to return: {limit if limit is not None else 'default'}\n\n"
#         "Return JSON only: {\"sql\": \"...\", \"explanation\": \"...\"}"
#     )

#     # 1) Prefer Convobi's LLM (same as in convobi/main.py)
#     raw = _get_convobi_llm_response(system, user)
#     if raw:
#         sql, explanation = _extract_sql_from_llm_response(raw)
#         if sql:
#             return sql, explanation
#         raise ValueError("Could not extract SQL from LLM response. Try rephrasing your question.")

#     # 2) Fallback: HTTP LLM API (DB_INVOKE_LLM_URL)
#     base_url = (os.environ.get("DB_INVOKE_LLM_URL") or "").strip().rstrip("/")
#     if not base_url:
#         raise ValueError(
#             "Natural language invoke requires an LLM. Use the same LLM as Convobi (_get_convobi_llm in apps/convobi/main.py) "
#             "or set environment variable DB_INVOKE_LLM_URL (e.g. http://localhost:8000) to the base URL of your LLM API (POST /LLMs/chat)."
#         )

#     chat_url = f"{base_url}/LLMs/chat"
#     model_id = (os.environ.get("DB_INVOKE_LLM_MODEL") or "").strip()

#     if not model_id:
#         try:
#             models_url = f"{base_url}/LLMs/models"
#             resp = httpx.get(models_url, timeout=15.0)
#             if resp.status_code == 200:
#                 data = resp.json()
#                 models = data if isinstance(data, list) else data.get("models", data) or []
#                 if models:
#                     first = models[0] if isinstance(models[0], dict) else {"id": models[0]}
#                     model_id = first.get("id") or first.get("model_id") or (first if isinstance(first, str) else None)
#         except Exception as e:
#             logger.warning("Could not resolve LLM model_id: %s", e)
#         if not model_id:
#             raise ValueError(
#                 "DB_INVOKE_LLM_MODEL not set and could not get model from LLM API. "
#                 "Set DB_INVOKE_LLM_MODEL to your model id."
#             )

#     payload = {
#         "model_id": model_id,
#         "messages": [
#             {"role": "system", "content": system},
#             {"role": "user", "content": user},
#         ],
#         "temperature": 0.2,
#         "max_tokens": 2048,
#     }

#     try:
#         resp = httpx.post(chat_url, json=payload, timeout=60.0)
#         if resp.status_code != 200:
#             raise ValueError(f"LLM API error {resp.status_code}: {resp.text}")
#         data = resp.json()
#         raw = (data.get("response") or "").strip()
#         if not raw:
#             raise ValueError("LLM returned empty response")
#         sql, explanation = _extract_sql_from_llm_response(raw)
#         if not sql:
#             raise ValueError("Could not extract SQL from LLM response. Try rephrasing your question.")
#         return sql, explanation
#     except httpx.HTTPError as e:
#         raise ValueError(f"LLM request failed: {e}") from e


# # ---------------------------------------------------------------------------
# # Core service
# # ---------------------------------------------------------------------------


# class DatabaseConnectorService:
#     """
#     Universal database connector supporting public *and* private databases.
#     """

#     def __init__(self):
#         self._connections: Dict[str, Dict[str, Any]] = {}
#         self._engines: Dict[str, Engine] = {}
#         self._tunnels: Dict[str, _SSHTunnelWrapper] = {}
#         self._load_persisted()

#     # ---- persistence (PostgreSQL) ----

#     def _load_persisted(self):
#         """Load all saved connections from the db_connections PostgreSQL table."""
#         try:
#             engine = _get_pg_engine()
#             with engine.begin() as conn:
#                 result = conn.execute(text(
#                     "SELECT id, name, db_type, connection_string, dialect, "
#                     "tables_count, views_count, schemas, ssh_tunnel_enabled, "
#                     "ssh_host, ssh_config, file_content_hash, user_id "
#                     "FROM db_connections ORDER BY created_at"
#                 ))
#                 seen_hashes: Dict[str, str] = {}
#                 duplicate_ids: List[str] = []
#                 loaded: Dict[str, Dict[str, Any]] = {}

#                 for row in result.mappings():
#                     cid = row["id"]
#                     fch = row["file_content_hash"]
#                     if fch and fch in seen_hashes:
#                         duplicate_ids.append(cid)
#                         continue
#                     if fch:
#                         seen_hashes[fch] = cid

#                     cs = row["connection_string"]

#                     loaded[cid] = {
#                         "id": cid,
#                         "name": row["name"] or "Unnamed",
#                         "db_type": row["db_type"] or "unknown",
#                         "connection_string": cs,
#                         "dialect": row["dialect"] or "unknown",
#                         "tables_count": row["tables_count"] or 0,
#                         "views_count": row["views_count"] or 0,
#                         "schemas": row["schemas"] if row["schemas"] else [],
#                         "ssh_tunnel_enabled": bool(row["ssh_tunnel_enabled"]),
#                         "ssh_host": row["ssh_host"],
#                         "ssh_config": row["ssh_config"],
#                         "file_content_hash": fch,
#                         "user_id": row["user_id"],
#                     }

#                 if duplicate_ids:
#                     for did in duplicate_ids:
#                         conn.execute(text("DELETE FROM db_connections WHERE id = :id"), {"id": did})
#                     logger.info("Removed %d duplicate db_connections rows", len(duplicate_ids))

#                 self._connections = loaded
#         except Exception as exc:
#             logger.warning("Could not load saved connections from PostgreSQL: %s", exc)

#     def _persist(self):
#         """Sync the in-memory connections dict to the db_connections PostgreSQL table."""
#         try:
#             engine = _get_pg_engine()
#             with engine.begin() as conn:
#                 existing_result = conn.execute(text("SELECT id FROM db_connections"))
#                 existing_ids = {row[0] for row in existing_result}
#                 current_ids = set(self._connections.keys())

#                 for rid in (existing_ids - current_ids):
#                     conn.execute(text("DELETE FROM db_connections WHERE id = :id"), {"id": rid})

#                 for record in self._connections.values():
#                     self._upsert_record(conn, record)
#         except Exception as exc:
#             logger.exception("Failed to persist connections to PostgreSQL: %s", exc)
#             raise

#     @staticmethod
#     def _upsert_record(conn, record: Dict[str, Any]) -> None:
#         """Insert or update a single connection record in PostgreSQL.

#         Stores the connection_string directly in the DB (no Key Vault).
#         """
#         schemas_json = json.dumps(record.get("schemas", []))
#         ssh_cfg = record.get("ssh_config")
#         ssh_config_json = json.dumps(ssh_cfg) if ssh_cfg else None

#         conn.execute(text("""
#             INSERT INTO db_connections
#                 (id, name, db_type, connection_string, dialect,
#                  tables_count, views_count, schemas,
#                  ssh_tunnel_enabled, ssh_host, ssh_config,
#                  file_content_hash, user_id, updated_at)
#             VALUES
#                 (:id, :name, :db_type, :connection_string, :dialect,
#                  :tables_count, :views_count, CAST(:schemas AS jsonb),
#                  :ssh_tunnel_enabled, :ssh_host, CAST(:ssh_config AS jsonb),
#                  :file_content_hash, :user_id, NOW())
#             ON CONFLICT (id) DO UPDATE SET
#                 name               = EXCLUDED.name,
#                 db_type            = EXCLUDED.db_type,
#                 connection_string  = EXCLUDED.connection_string,
#                 dialect            = EXCLUDED.dialect,
#                 tables_count       = EXCLUDED.tables_count,
#                 views_count        = EXCLUDED.views_count,
#                 schemas            = EXCLUDED.schemas,
#                 ssh_tunnel_enabled = EXCLUDED.ssh_tunnel_enabled,
#                 ssh_host           = EXCLUDED.ssh_host,
#                 ssh_config         = EXCLUDED.ssh_config,
#                 file_content_hash  = EXCLUDED.file_content_hash,
#                 user_id            = EXCLUDED.user_id,
#                 updated_at         = NOW()
#         """), {
#             "id": record["id"],
#             "name": record.get("name", "Unnamed"),
#             "db_type": record.get("db_type", "unknown"),
#             "connection_string": record.get("connection_string", ""),
#             "dialect": record.get("dialect"),
#             "tables_count": record.get("tables_count", 0),
#             "views_count": record.get("views_count", 0),
#             "schemas": schemas_json,
#             "ssh_tunnel_enabled": record.get("ssh_tunnel_enabled", False),
#             "ssh_host": record.get("ssh_host"),
#             "ssh_config": ssh_config_json,
#             "file_content_hash": record.get("file_content_hash"),
#             "user_id": record.get("user_id"),
#         })

#     # ---- engine creation (with optional SSH tunnel) ----

#     def _create_engine(
#         self, connection_string: str, config: DBConnectionConfig
#     ) -> Tuple[Engine, Optional[_SSHTunnelWrapper]]:
#         tunnel: Optional[_SSHTunnelWrapper] = None

#         if config.ssh_tunnel:
#             parsed = urlparse(connection_string)
#             remote_host = parsed.hostname or "localhost"
#             db_info = DB_TYPES.get(
#                 config.db_type or _infer_db_type(connection_string), {}
#             )
#             remote_port = parsed.port or db_info.get("default_port", 5432)

#             tunnel = _SSHTunnelWrapper(config.ssh_tunnel, remote_host, remote_port)
#             local_host, local_port = tunnel.start()

#             # Rewrite DSN to go through the local tunnel
#             connection_string = connection_string.replace(
#                 f"{remote_host}:{remote_port}",
#                 f"{local_host}:{local_port}",
#             )
#             # Fallback if port wasn't explicit in the DSN
#             if remote_host in connection_string:
#                 connection_string = connection_string.replace(
#                     remote_host, f"{local_host}:{local_port}"
#                 )

#         engine_kw: Dict[str, Any] = {
#             "pool_pre_ping": True,
#             "pool_size": config.pool_size,
#             "pool_timeout": config.pool_timeout,
#         }
#         if config.connect_args:
#             engine_kw["connect_args"] = config.connect_args

#         # SQLite and DuckDB don't support pool_size / pool_timeout
#         if connection_string.startswith("sqlite") or connection_string.startswith("duckdb"):
#             engine_kw.pop("pool_size", None)
#             engine_kw.pop("pool_timeout", None)

#         engine = create_engine(connection_string, **engine_kw)
#         return engine, tunnel

#     # ---- public API ----

#     def list_supported_databases(self) -> List[Dict[str, Any]]:
#         """Return metadata about every supported DB type (drives the dropdown)."""
#         out = []
#         for key, info in DB_TYPES.items():
#             out.append(
#                 {
#                     "db_type": key,
#                     "label": info["label"],
#                     "default_port": info["default_port"],
#                     "default_driver": info["driver"],
#                     "drivers_available": info["drivers_available"],
#                     "placeholder_host": info.get("placeholder_host", ""),
#                     "supports_file_upload": info.get("supports_file_upload", False),
#                 }
#             )
#         return out

#     # --- test connection (the "Test Connection" button) ---

#     def test_connection(self, config: DBConnectionConfig) -> Dict[str, Any]:
#         """
#         Test a database connection **without** saving it.
#         Works for both public (direct) and private (SSH tunnel) databases.
#         """
#         tunnel: Optional[_SSHTunnelWrapper] = None
#         try:
#             cs = build_connection_string(config)
#             engine, tunnel = self._create_engine(cs, config)

#             # Connectivity check
#             with engine.connect() as conn:
#                 conn.execute(text("SELECT 1"))

#             insp = inspect(engine)
#             tables = insp.get_table_names()
#             views: List[str] = []
#             try:
#                 views = insp.get_view_names()
#             except Exception:
#                 pass
#             schemas: List[str] = []
#             try:
#                 schemas = insp.get_schema_names()
#             except Exception:
#                 pass

#             db_type = config.db_type or _infer_db_type(cs)
#             engine.dispose()

#             return {
#                 "ok": True,
#                 "message": "Connection successful",
#                 "db_type": db_type,
#                 "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
#                 "tables_count": len(tables),
#                 "views_count": len(views),
#                 "schemas": schemas[:20],
#                 "ssh_tunnel_active": config.ssh_tunnel is not None,
#             }
#         except ImportError as exc:
#             raise ValueError(str(exc))
#         except Exception as exc:
#             cs = build_connection_string(config)
#             raise ValueError(_format_connection_error(exc, cs)) from exc
#         finally:
#             if tunnel:
#                 tunnel.stop()

#     # --- connect & save (the "Next" button after test passes) ---

#     def connect_and_save(self, config: DBConnectionConfig, *, user_id: str = None) -> Dict[str, Any]:
#         """Test, save, and cache the engine for subsequent operations."""
#         # For SQLite/DuckDB file uploads: reuse existing connection if same file content (avoids duplicates from double-submit)
#         if config.file_content_hash and config.db_type in ("sqlite", "duckdb"):
#             self._load_persisted()
#             for c in self._connections.values():
#                 if c.get("file_content_hash") == config.file_content_hash and c.get("user_id") == user_id:
#                     return {
#                         "ok": True,
#                         "connection_id": c["id"],
#                         "name": c.get("name", "Unnamed"),
#                         "db_type": c.get("db_type", "unknown"),
#                         "dialect": c.get("dialect", "unknown"),
#                         "tables_count": c.get("tables_count", 0),
#                         "views_count": c.get("views_count", 0),
#                         "schemas": c.get("schemas", []),
#                         "connection_string_masked": mask_connection_string(c.get("connection_string", "")),
#                         "ssh_tunnel_active": False,
#                         "message": "Connection saved successfully",
#                         "reused_existing": True,
#                     }

#         test_result = self.test_connection(config)

#         cs = build_connection_string(config)
#         db_type = config.db_type or _infer_db_type(cs)
#         name = (config.name or "").strip() or (
#             f"{DB_TYPES.get(db_type, {}).get('label', db_type)} connection"
#         )
#         # If name is MSSQL-ITSM, use fixed connection_id so ITSM DB tool uses it by default
#         if name == ITSM_CONNECTION_NAME:
#             conn_id = ITSM_DEFAULT_CONNECTION_ID
#         elif name == CRM_CONNECTION_NAME:
#             conn_id = CRM_DEFAULT_CONNECTION_ID
#         else:
#             conn_id = str(uuid.uuid4())[:8]

#         # If reusing an existing id (e.g. ITSM), dispose old engine and close tunnel first
#         if conn_id in self._engines:
#             old_engine = self._engines.pop(conn_id, None)
#             if old_engine:
#                 try:
#                     old_engine.dispose()
#                 except Exception:
#                     pass
#         if conn_id in self._tunnels:
#             old_tunnel = self._tunnels.pop(conn_id, None)
#             if old_tunnel:
#                 try:
#                     old_tunnel.stop()
#                 except Exception:
#                     pass

#         engine, tunnel = self._create_engine(cs, config)
#         self._engines[conn_id] = engine
#         if tunnel:
#             self._tunnels[conn_id] = tunnel

#         record: Dict[str, Any] = {
#             "id": conn_id,
#             "name": name,
#             "db_type": db_type,
#             "connection_string": cs,
#             "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
#             "tables_count": test_result["tables_count"],
#             "views_count": test_result.get("views_count", 0),
#             "schemas": test_result.get("schemas", []),
#             "ssh_tunnel_enabled": config.ssh_tunnel is not None,
#             "ssh_host": (
#                 config.ssh_tunnel.ssh_host if config.ssh_tunnel else None
#             ),
#         }
#         if config.file_content_hash:
#             record["file_content_hash"] = config.file_content_hash
#         if user_id:
#             record["user_id"] = user_id
#         if config.ssh_tunnel:
#             record["ssh_config"] = {
#                 "ssh_host": config.ssh_tunnel.ssh_host,
#                 "ssh_port": config.ssh_tunnel.ssh_port,
#                 "ssh_username": config.ssh_tunnel.ssh_username,
#                 "has_password": bool(config.ssh_tunnel.ssh_password),
#                 "has_private_key": bool(config.ssh_tunnel.ssh_private_key),
#             }

#         self._connections[conn_id] = record
#         self._persist()

#         return {
#             "ok": True,
#             "connection_id": conn_id,
#             "name": name,
#             "db_type": db_type,
#             "dialect": record["dialect"],
#             "tables_count": test_result["tables_count"],
#             "views_count": test_result.get("views_count", 0),
#             "schemas": test_result.get("schemas", []),
#             "connection_string_masked": mask_connection_string(cs),
#             "ssh_tunnel_active": config.ssh_tunnel is not None,
#             "message": "Connection saved successfully",
#         }

#     # --- CRUD ---

#     def _verify_ownership(self, connection_id: str, user_id: str) -> None:
#         """Raise ValueError if connection doesn't belong to user."""
#         c = self._connections.get(connection_id)
#         if not c:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         if user_id and c.get("user_id") and c["user_id"] != user_id:
#             raise ValueError(f"Connection '{connection_id}' not found")

#     def list_connections(self, *, user_id: str = None) -> List[Dict[str, Any]]:
#         # Always re-load from DB so list reflects current state across workers
#         # (fixes multi-worker and ensures deleted connectors don't reappear in list)
#         self._load_persisted()
#         out = []
#         for c in self._connections.values():
#             # Filter by user_id if provided
#             if user_id and c.get("user_id") and c["user_id"] != user_id:
#                 continue
#             out.append(
#                 {
#                     "id": c["id"],
#                     "name": c.get("name", "Unnamed"),
#                     "db_type": c.get("db_type", "unknown"),
#                     "dialect": c.get("dialect", "unknown"),
#                     "connection_string_masked": mask_connection_string(
#                         c.get("connection_string", "")
#                     ),
#                     "tables_count": c.get("tables_count", 0),
#                     "views_count": c.get("views_count", 0),
#                     "ssh_tunnel_enabled": c.get("ssh_tunnel_enabled", False),
#                     "ssh_host": c.get("ssh_host"),
#                 }
#             )
#         return out

#     def get_connection(self, connection_id: str, *, user_id: str = None) -> Optional[Dict[str, Any]]:
#         c = self._connections.get(connection_id)
#         if not c:
#             return None
#         if user_id and c.get("user_id") and c["user_id"] != user_id:
#             return None
#         return {
#             "id": c["id"],
#             "name": c.get("name", "Unnamed"),
#             "db_type": c.get("db_type", "unknown"),
#             "dialect": c.get("dialect", "unknown"),
#             "connection_string_masked": mask_connection_string(
#                 c.get("connection_string", "")
#             ),
#             "tables_count": c.get("tables_count", 0),
#             "views_count": c.get("views_count", 0),
#             "schemas": c.get("schemas", []),
#             "ssh_tunnel_enabled": c.get("ssh_tunnel_enabled", False),
#             "ssh_config": c.get("ssh_config"),
#         }

#     def delete_connection(self, connection_id: str, *, user_id: str = None) -> Dict[str, Any]:
#         if connection_id not in self._connections:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         if user_id:
#             self._verify_ownership(connection_id, user_id)

#         engine = self._engines.pop(connection_id, None)
#         if engine:
#             engine.dispose()
#         tunnel = self._tunnels.pop(connection_id, None)
#         if tunnel:
#             tunnel.stop()

#         name = self._connections[connection_id].get("name", "Unnamed")
#         del self._connections[connection_id]
#         self._persist()

#         return {"ok": True, "deleted_id": connection_id, "name": name}

#     def update_connection(
#         self, connection_id: str, updates: Dict[str, Any], *, user_id: str = None
#     ) -> Dict[str, Any]:
#         if connection_id not in self._connections:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         if user_id:
#             self._verify_ownership(connection_id, user_id)
#         c = self._connections[connection_id]
#         if "name" in updates:
#             c["name"] = updates["name"]
#         self._connections[connection_id] = c
#         self._persist()
#         return {"ok": True, "connection_id": connection_id, "name": c.get("name")}

#     def update_connection_with_config(
#         self, connection_id: str, config: DBConnectionConfig, *, user_id: str = None
#     ) -> Dict[str, Any]:
#         """
#         Update an existing saved connection with new config (e.g. new DB file path).
#         Tests the new connection, replaces engine/record, and persists.
#         Same response shape as connect_and_save.
#         """
#         if connection_id not in self._connections:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         if user_id:
#             self._verify_ownership(connection_id, user_id)

#         test_result = self.test_connection(config)
#         cs = build_connection_string(config)
#         db_type = config.db_type or _infer_db_type(cs)
#         name = (config.name or "").strip() or self._connections[connection_id].get(
#             "name", f"{DB_TYPES.get(db_type, {}).get('label', db_type)} connection"
#         )

#         # Dispose old engine and tunnel for this connection
#         if connection_id in self._engines:
#             old_engine = self._engines.pop(connection_id, None)
#             if old_engine:
#                 try:
#                     old_engine.dispose()
#                 except Exception:
#                     pass
#         if connection_id in self._tunnels:
#             old_tunnel = self._tunnels.pop(connection_id, None)
#             if old_tunnel:
#                 try:
#                     old_tunnel.stop()
#                 except Exception:
#                     pass

#         engine, tunnel = self._create_engine(cs, config)
#         self._engines[connection_id] = engine
#         if tunnel:
#             self._tunnels[connection_id] = tunnel

#         record: Dict[str, Any] = {
#             "id": connection_id,
#             "name": name,
#             "db_type": db_type,
#             "connection_string": cs,
#             "dialect": DB_TYPES.get(db_type, {}).get("label", db_type),
#             "tables_count": test_result["tables_count"],
#             "views_count": test_result.get("views_count", 0),
#             "schemas": test_result.get("schemas", []),
#             "ssh_tunnel_enabled": config.ssh_tunnel is not None,
#             "ssh_host": (
#                 config.ssh_tunnel.ssh_host if config.ssh_tunnel else None
#             ),
#         }
#         if config.ssh_tunnel:
#             record["ssh_config"] = {
#                 "ssh_host": config.ssh_tunnel.ssh_host,
#                 "ssh_port": config.ssh_tunnel.ssh_port,
#                 "ssh_username": config.ssh_tunnel.ssh_username,
#                 "has_password": bool(config.ssh_tunnel.ssh_password),
#                 "has_private_key": bool(config.ssh_tunnel.ssh_private_key),
#             }
#         else:
#             record["ssh_config"] = None

#         self._connections[connection_id] = record
#         self._persist()

#         return {
#             "ok": True,
#             "connection_id": connection_id,
#             "name": name,
#             "db_type": db_type,
#             "dialect": record["dialect"],
#             "tables_count": test_result["tables_count"],
#             "views_count": test_result.get("views_count", 0),
#             "schemas": test_result.get("schemas", []),
#             "connection_string_masked": mask_connection_string(cs),
#             "ssh_tunnel_active": config.ssh_tunnel is not None,
#             "message": "Connection updated successfully",
#         }

#     # ---- schema introspection ----

#     def _get_engine(self, connection_id: str) -> Engine:
#         if connection_id in self._engines:
#             return self._engines[connection_id]
#         c = self._connections.get(connection_id)
#         if not c:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         cs = c.get("connection_string")
#         if not cs:
#             raise ValueError(f"Connection '{connection_id}' has no connection_string")
#         cfg = DBConnectionConfig(connection_string=cs)
#         engine, tunnel = self._create_engine(cs, cfg)
#         self._engines[connection_id] = engine
#         if tunnel:
#             self._tunnels[connection_id] = tunnel
#         return engine

#     def get_schemas(self, connection_id: str) -> Dict[str, Any]:
#         engine = self._get_engine(connection_id)
#         insp = inspect(engine)
#         schemas: List[str] = []
#         try:
#             schemas = insp.get_schema_names()
#         except Exception:
#             pass
#         return {"connection_id": connection_id, "schemas": schemas}

#     def get_tables(
#         self, connection_id: str, schema_name: Optional[str] = None
#     ) -> Dict[str, Any]:
#         engine = self._get_engine(connection_id)
#         insp = inspect(engine)
#         tables = insp.get_table_names(schema=schema_name)
#         views: List[str] = []
#         try:
#             views = insp.get_view_names(schema=schema_name)
#         except Exception:
#             pass
#         return {
#             "connection_id": connection_id,
#             "schema": schema_name or "default",
#             "tables": tables,
#             "views": views,
#             "tables_count": len(tables),
#             "views_count": len(views),
#         }

#     def get_full_schema(
#         self, connection_id: str, schema_name: Optional[str] = None
#     ) -> Dict[str, Any]:
#         """Full introspection: columns, PKs, FKs, indexes, row counts."""
#         engine = self._get_engine(connection_id)
#         insp = inspect(engine)

#         tables_info: List[Dict[str, Any]] = []
#         for table in insp.get_table_names(schema=schema_name):
#             cols = []
#             try:
#                 for col in insp.get_columns(table, schema=schema_name):
#                     cols.append(
#                         {
#                             "name": col["name"],
#                             "type": str(col["type"]),
#                             "nullable": col.get("nullable", True),
#                             "default": (
#                                 str(col["default"]) if col.get("default") else None
#                             ),
#                             "autoincrement": col.get("autoincrement"),
#                         }
#                     )
#             except Exception as e:
#                 cols = [{"error": str(e)}]

#             pk: List[str] = []
#             try:
#                 pk_info = insp.get_pk_constraint(table, schema=schema_name)
#                 pk = pk_info.get("constrained_columns", []) if pk_info else []
#             except Exception:
#                 pass

#             fks: List[Dict[str, Any]] = []
#             try:
#                 for fk in insp.get_foreign_keys(table, schema=schema_name):
#                     fks.append(
#                         {
#                             "constrained_columns": fk.get("constrained_columns", []),
#                             "referred_table": fk.get("referred_table"),
#                             "referred_columns": fk.get("referred_columns", []),
#                             "referred_schema": fk.get("referred_schema"),
#                         }
#                     )
#             except Exception:
#                 pass

#             indexes: List[Dict[str, Any]] = []
#             try:
#                 for idx in insp.get_indexes(table, schema=schema_name):
#                     indexes.append(
#                         {
#                             "name": idx.get("name"),
#                             "columns": idx.get("column_names", []),
#                             "unique": idx.get("unique", False),
#                         }
#                     )
#             except Exception:
#                 pass

#             row_count = None
#             try:
#                 sp = f'"{schema_name}".' if schema_name else ""
#                 with engine.connect() as conn:
#                     r = conn.execute(text(f'SELECT COUNT(*) FROM {sp}"{table}"'))
#                     row_count = r.scalar()
#             except Exception:
#                 pass

#             tables_info.append(
#                 {
#                     "table_name": table,
#                     "columns": cols,
#                     "primary_key": pk,
#                     "foreign_keys": fks,
#                     "indexes": indexes,
#                     "row_count": row_count,
#                 }
#             )

#         views_info: List[Dict[str, Any]] = []
#         try:
#             for view in insp.get_view_names(schema=schema_name):
#                 vcols = []
#                 try:
#                     for col in insp.get_columns(view, schema=schema_name):
#                         vcols.append(
#                             {"name": col["name"], "type": str(col["type"])}
#                         )
#                 except Exception:
#                     pass
#                 views_info.append({"view_name": view, "columns": vcols})
#         except Exception:
#             pass

#         conn_info = self._connections.get(connection_id, {})
#         return {
#             "connection_id": connection_id,
#             "name": conn_info.get("name", "Unknown"),
#             "db_type": conn_info.get("db_type", "unknown"),
#             "schema": schema_name or "default",
#             "tables": tables_info,
#             "views": views_info,
#             "tables_count": len(tables_info),
#             "views_count": len(views_info),
#         }

#     def preview_table(
#         self,
#         connection_id: str,
#         table_name: str,
#         schema_name: Optional[str] = None,
#         limit: int = 50,
#     ) -> Dict[str, Any]:
#         engine = self._get_engine(connection_id)
#         sp = f'"{schema_name}".' if schema_name else ""
#         db_type = self._connections.get(connection_id, {}).get("db_type", "")

#         if db_type == "mssql":
#             q = f"SELECT TOP {limit} * FROM {sp}[{table_name}]"
#         elif db_type == "oracle":
#             q = f'SELECT * FROM {sp}"{table_name}" WHERE ROWNUM <= {limit}'
#         else:
#             q = f'SELECT * FROM {sp}"{table_name}" LIMIT {limit}'

#         try:
#             with engine.connect() as conn:
#                 result = conn.execute(text(q))
#                 columns = list(result.keys())
#                 rows = [dict(zip(columns, row)) for row in result.fetchall()]
#                 return {
#                     "connection_id": connection_id,
#                     "table_name": table_name,
#                     "columns": columns,
#                     "rows": rows,
#                     "row_count": len(rows),
#                     "limited_to": limit,
#                 }
#         except Exception as exc:
#             raise ValueError(f"Error previewing table '{table_name}': {exc}")

#     def execute_query(
#         self,
#         connection_id: str,
#         query: str,
#         limit: int = 100,
#         timeout: int = 30,
#     ) -> Dict[str, Any]:
#         engine = self._get_engine(connection_id)
#         q = query.strip()
#         q_upper = q.upper()
#         is_read = q_upper.startswith(("SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN"))

#         try:
#             with engine.connect() as conn:
#                 result = conn.execute(text(q))
#                 if is_read:
#                     columns = list(result.keys())
#                     rows = [
#                         dict(zip(columns, row)) for row in result.fetchmany(limit)
#                     ]
#                     return {
#                         "connection_id": connection_id,
#                         "query": q,
#                         "columns": columns,
#                         "rows": rows,
#                         "row_count": len(rows),
#                         "limited_to": limit,
#                         "type": "select",
#                     }
#                 else:
#                     conn.commit()
#                     return {
#                         "connection_id": connection_id,
#                         "query": q,
#                         "rows_affected": result.rowcount,
#                         "type": "execute",
#                         "message": f"Query executed. Rows affected: {result.rowcount}",
#                     }
#         except Exception as exc:
#             raise ValueError(f"Query execution failed: {exc}")

#     def invoke_with_question(
#         self,
#         connection_id: str,
#         question: str,
#         limit: int = 100,
#         timeout: int = 30,
#         *,
#         user_id: str = None,
#     ) -> Dict[str, Any]:
#         """
#         Answer a natural language question by generating SQL via LLM and executing it
#         on the saved connection. Requires DB_INVOKE_LLM_URL (and optionally
#         DB_INVOKE_LLM_MODEL) to be set.
#         """
#         conn = self._connections.get(connection_id)
#         if not conn:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         if user_id and conn.get("user_id") and conn["user_id"] != user_id:
#             raise ValueError(f"Connection '{connection_id}' not found")
#         db_type = conn.get("db_type", "sqlite")
#         schema_result = self.get_full_schema(connection_id, schema_name=None)
#         schema_summary = _build_schema_summary_for_nl(schema_result)
#         generated_sql, explanation = _generate_sql_via_llm(
#             question, schema_summary, db_type, limit=limit
#         )
#         result = self.execute_query(
#             connection_id=connection_id,
#             query=generated_sql,
#             limit=limit,
#             timeout=timeout,
#         )
#         result["question"] = question
#         result["generated_sql"] = generated_sql
#         result["explanation"] = explanation
#         # Convobi-style narrative summary for read results
#         if result.get("type") == "select" and result.get("rows") is not None and result.get("columns"):
#             summary_text = _summarize_result_for_question(
#                 question, result["columns"], result["rows"]
#             )
#             if summary_text:
#                 result["summary"] = summary_text
#         return result

#     # ---- cleanup ----

#     def cleanup(self):
#         for engine in self._engines.values():
#             try:
#                 engine.dispose()
#             except Exception:
#                 pass
#         self._engines.clear()
#         for tunnel in self._tunnels.values():
#             try:
#                 tunnel.stop()
#             except Exception:
#                 pass
#         self._tunnels.clear()
