"""
Connector Routes — DB-first implementation for API, MCP, and DB connectors.

All connector state is persisted in PostgreSQL. No Key Vault for connector secrets.
Auth credentials are stored in config_json JSONB columns and masked on read.
"""
from fastapi import APIRouter, Depends, HTTPException, Query, File, UploadFile, Form
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List, Text

from echolib.di import container
from echolib.security import get_current_user, resolve_user_id, require_user
from echolib.types import UserContext
from echolib.services import ConnectorManager
from echolib.database import get_db_session
from echolib.repositories.connectors_repository import ConnectorsRepository
from echolib.connectors.api_service import APIConnectorService
from echolib.connectors.api_schemas import (
    APIConnectorCreate,
    APIConnectorUpdate,
    APIConnectorInvoke,
    APIConnectorTest,
    AuthType,
    ConnectorStatus,
    mask_auth_config,
)
from echolib.repositories.connectors_repository import ConnectorsRepository
from echolib.services import OAuthService
from echolib.blob_storage import upload_to_blob, derive_blob_name_from_path

import asyncio
import hashlib
import os
import uuid
from pathlib import Path
from datetime import datetime
import logging
from fastapi import Request

from .db_connector import (
    DatabaseConnectorService,
    DBConnectionConfig,
    _get_pg_engine,
    text
)

# Uploaded DB files (SQLite, DuckDB) — saved under this dir
_UPLOADS_DIR = Path(__file__).resolve().parent / "uploads"

# Allowed extensions per db_type for file upload
_UPLOAD_EXTENSIONS = {
    "sqlite": (".sqlite", ".db", ".sqlite3"),
    "duckdb": (".duckdb", ".db"),
}

_UPLOAD_CHUNK_SIZE = 1024 * 1024  # 1 MB

# Maximum filesystem file upload limit
FILE_SYSTEM_THRESHOLD_BYTES = 1024 * 1024 # 1 MB

async def _stream_upload_to_disk(file: UploadFile, dest: Path) -> str:
    """Stream an uploaded file to disk in chunks, returning the SHA-256 hex digest."""
    sha = hashlib.sha256()
    chunks: list[bytes] = []

    while True:
        chunk = await file.read(_UPLOAD_CHUNK_SIZE)
        if not chunk:
            break
        sha.update(chunk)
        chunks.append(chunk)

    def _write(c: list[bytes]) -> None:
        with open(dest, "wb") as f:
            for part in c:
                f.write(part)

    await asyncio.to_thread(_write, chunks)
    return sha.hexdigest()


router = APIRouter(prefix='/connectors', tags=['Connector API'])

logger = logging.getLogger(__name__)


def mgr() -> ConnectorManager:
    """Dependency injection for ConnectorManager."""
    return container.resolve('connector.manager')


_connectors_repo = ConnectorsRepository()
_api_service = APIConnectorService(repository=_connectors_repo)


def _sanitize_connector_error(result: Dict[str, Any]) -> Dict[str, Any]:
    """Return a client-safe connector error payload when infra details may leak."""
    error_text = str(result.get("error") or "").lower()
    errors = result.get("errors") or []
    combined_errors = " ".join(str(item).lower() for item in errors)

    sensitive_markers = (
        "hostname",
        "private/loopback",
        "mcp_allowed_hosts",
        "url has no hostname",
        "url resolves",
    )
    should_sanitize = any(marker in error_text for marker in sensitive_markers) or any(
        marker in combined_errors for marker in sensitive_markers
    )

    if should_sanitize:
        return {"success": False, "error": "Invalid connector endpoint URL."}

    return result


# ============================================================================
# REQUEST/RESPONSE MODELS - MCP
# ============================================================================

class MCPConnectorCreateRequest(BaseModel):
    """MCP connector creation request."""
    name: str
    description: Optional[str] = None
    icon: Optional[str] = None
    transport_type: str = Field(description="Supported values: stdio, streamable_http")
    url: Optional[str] = None
    endpoint_url: Optional[str] = None
    auth_config: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None
    timeout: Optional[int] = 30
    enabled: Optional[bool] = True
    # Local MCP (STDIO)
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env_vars: Optional[Dict[str, str]] = None


class MCPConnectorInvokeRequest(BaseModel):
    connector_id: str
    payload: Optional[Dict[str, Any]] = None
    context: Optional[Dict[str, Any]] = None


class MCPConnectorUpdateRequest(BaseModel):
    """MCP connector update request."""
    connector_id: str
    updates: Dict[str, Any]


class MCPConnectorDeleteRequest(BaseModel):
    """MCP connector delete request."""
    connector_id: str


# ============================================================================
# REQUEST/RESPONSE MODELS - API
# ============================================================================

class APIConnectorSimpleCreateRequest(BaseModel):
    """Simple connector creation from workflow API request node."""
    method: str
    url: str
    auth_type: str = "none"
    auth_credentials: Optional[Dict[str, Any]] = None
    body: Optional[Dict[str, Any]] = None
    custom_headers: Optional[Dict[str, str]] = None
    description: Optional[str] = None
    source: Optional[str] = "workflow"
    name: Optional[str] = None
    timeout: Optional[int] = 30
    verify_ssl: Optional[bool] = True


class APIConnectorDeleteRequest(BaseModel):
    connector_id: str


# ============================================================================
# Authroization Code Flow
# ============================================================================
class OAuthAuthorizeRequest(BaseModel):
    provider: str = Field(...)

    scopes: List[str] = Field(
        default_factory=list
    )


@router.post("/oauth/authorize")
async def authorize_oauth(
    request: OAuthAuthorizeRequest,
    user: UserContext = Depends(require_user),
):
    oauth_service = OAuthService()

    result = await oauth_service.build_authorization_url(
        provider=request.provider,
        user_id=resolve_user_id(user),
        requested_scopes=request.scopes,
    )

    return {
        "provider": request.provider,
        "authorization_url": result["authorization_url"],
        "state": result["state"],
        "requested_scopes": result["requested_scopes"],
    }

@router.get("/oauth/callback")
async def oauth_callback(
    code: str = Query(...),
    state: str = Query(...),
):
    oauth_service = OAuthService()

    return await oauth_service.exchange_code(
        code=code,
        state=state,
    )

# ============================================================================
# MCP CONNECTOR ROUTES
# ============================================================================

@router.post("/mcp/create")

async def create_mcp_connector(
    req: MCPConnectorCreateRequest,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Create a new MCP connector and auto-discover MCP capabilities."""
    try:
        user_id = resolve_user_id(user)
        logger.info(
            "MCP connector creation requested: name=%s transport=%s user_id=%s",
            req.name,
            req.transport_type,
            user_id,
        )
        payload = req.model_dump(exclude_none=True)
        logger.debug(
            "MCP connector payload for '%s': %s",
            req.name,
            payload,
        )
        result = await manager.mcp.create(
            payload,
            user_id=user_id,
        )
        logger.info(
            "MCP create result for '%s': success=%s connector_id=%s",
            req.name,
            result.get("success"),
            result.get("connector_id"),
        )
        logger.debug(
            "Full MCP create response for '%s': %s",
            req.name,
            result,
        )
        if not result.get("success"):
            logger.error(
                "MCP connector create FAILED for '%s' (transport=%s): %s",
                req.name,
                req.transport_type,
                result,
            )
            raise HTTPException(
                status_code=400,
                detail=_sanitize_connector_error(result),
            )
        connector_id = result.get("connector_id")
        logger.info(
            "MCP connector created successfully: connector_id=%s name=%s",
            connector_id,
            req.name,
        )
        logger.info(
            "Returning successful create response for connector_id=%s",
            connector_id,
        )
        return result
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "Unexpected error while creating MCP connector '%s' "
            "(transport=%s): %s",
            req.name,
            req.transport_type,
            str(exc),
        )
        raise

@router.post("/mcp/invoke")
async def invoke_mcp_connector(
    req: MCPConnectorInvokeRequest,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Invoke MCP connector. Auto-generates workflow_id if not provided."""
    connector_id = req.connector_id
    payload = req.payload
    context = req.context or {}

    if not context.get("workflow_id"):
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        unique_id = uuid.uuid4().hex[:8]
        context["workflow_id"] = f"auto_{timestamp}_{unique_id}"

    user_id = resolve_user_id(user)
    try:
        result = await manager.mcp.invoke_async(connector_id, payload, context, user_id=user_id)

        if isinstance(result, dict):
            result["workflow_id_used"] = context["workflow_id"]
            if not result.get("success", True):
                raise HTTPException(status_code=502, detail=result)

        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"success": False, "error": str(e), "workflow_id_used": context["workflow_id"]}
        )


@router.get('/mcp/get')
async def get_mcp_connector(
    connector_id: str,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Get MCP connector with full metadata."""
    user_id = resolve_user_id(user)
    connector = await manager.mcp.get_async(connector_id, user_id=user_id)

    if not connector:
        raise HTTPException(status_code=404, detail="Connector not found")

    return connector


@router.get("/mcp/list")
async def list_mcp_connectors(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=1000),
    search: Optional[str] = Query(None),
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    from echolib.schemas.pagination import PaginatedResponse

    try:
        user_id = resolve_user_id(user)

        logger.info(
            "[MCP] Listing connectors user_id=%s page=%s page_size=%s search=%s",
            user_id,
            page,
            page_size,
            search,
        )

        repo = ConnectorsRepository()

        async with get_db_session() as db:
            connectors, total = (
                await repo.list_mcp_connectors_paginated(
                    db,
                    user_id=user_id,
                    page=page,
                    page_size=page_size,
                    search=search,
                )
            )

        logger.info(
            "[MCP] Connectors loaded user_id=%s total=%s returned=%s",
            user_id,
            total,
            len(connectors),
        )

        return PaginatedResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=[
                    {
                        "connector_id": c.connector_id,
                        "name": (c.config_json or {}).get("connector_name"),
                        "description": (
                            (c.config_json or {})
                            .get("creation_payload", {})
                            .get("description")
                        ),
                        "transport_type": (
                            (c.config_json or {})
                            .get("transport_type")
                        ),
                        "connected": c.connected,
                        "validation_status": (
                            (c.config_json or {})
                            .get("validation_status")
                        ),
                        "tool_count": len(
                            ((c.config_json or {})
                            .get("discovery", {})
                            .get("tools", []))
                        ),
                        "resource_count": len(
                            ((c.config_json or {})
                            .get("discovery", {})
                            .get("resources", []))
                        ),
                        "created_at": (
                            (c.config_json or {})
                            .get("created_at")
                        ),
                        "updated_at": (
                            (c.config_json or {})
                            .get("updated_at")
                        ),
                    }
                    for c in connectors
                ],
        )

    except Exception:
        logger.exception(
            "[MCP] Failed to list connectors"
        )
        raise

@router.put('/mcp/update')
async def update_mcp_connector(
    req: MCPConnectorUpdateRequest,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Update MCP connector with hybrid validation and mandatory testing."""
    user_id = resolve_user_id(user)
    result = await manager.mcp.update(req.connector_id, req.updates, user_id=user_id)

    if not result.get("success"):
        raise HTTPException(status_code=400, detail=_sanitize_connector_error(result))

    return result


@router.delete('/mcp/delete')
async def delete_mcp_connector(
    req: MCPConnectorDeleteRequest,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Delete an MCP connector."""
    user_id = resolve_user_id(user)
    result = await manager.mcp.delete_async(req.connector_id, user_id=user_id)

    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)

    return result


@router.get('/mcp/pool/status')
def get_connection_pool_status(
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Get connection pool status — shows active STDIO processes."""
    return manager.mcp.get_pool_status()


@router.post('/mcp/{connector_id}/refresh-discovery')
async def refresh_mcp_discovery(
    connector_id: str,
    manager: ConnectorManager = Depends(mgr),
    user: UserContext = Depends(require_user),
):
    """Re-probe an MCP connector to detect added/removed/changed tools."""
    user_id = resolve_user_id(user)
    result = await manager.mcp.refresh_discovery(connector_id, user_id=user_id)

    if not result.get("success"):
        raise HTTPException(status_code=400, detail=_sanitize_connector_error(result))

    return result


# ============================================================================
# API CONNECTOR ROUTES — DB-first implementation
# ============================================================================

@router.post("/api/create")
async def create_api_connector(
    req: APIConnectorCreate,
    user: UserContext = Depends(require_user),
):
    """Create an API connector. Validates -> tests -> saves to DB only if test passes."""
    user_id = resolve_user_id(user)
    result = await _api_service.create(req, user_id=user_id, test_before_save=True)

    if not result.get("success"):
        logger.error(
            "API connector create FAILED for '%s' (url=%s): %s",
            req.name, req.endpoint_url, result,
        )
        raise HTTPException(status_code=400, detail=result)

    return result


@router.post("/api/simple-create")
async def simple_create_api_connector(
    req: APIConnectorSimpleCreateRequest,
    user: UserContext = Depends(require_user),
):
    """Create a connector from the simple workflow API request form."""
    from urllib.parse import urlparse, parse_qs

    user_id = resolve_user_id(user)

    parsed = urlparse(req.url)
    base_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    query_params = {}
    if parsed.query:
        for k, v in parse_qs(parsed.query).items():
            query_params[k] = v[0] if len(v) == 1 else ",".join(v)

    auth_type = req.auth_type if req.auth_type != "no_auth" else "none"
    auth_config_dict: Dict[str, Any] = {"auth_type": auth_type}
    if req.auth_credentials:
        auth_config_dict.update(req.auth_credentials)

    name = req.name or f"{req.method} {parsed.netloc}{parsed.path[:30]}"

    create_payload = APIConnectorCreate(
        name=name,
        description=req.description or f"Auto-created from {req.method} {req.url}",
        endpoint_url=base_url,
        method=req.method.upper(),
        headers=req.custom_headers or {},
        query_params=query_params,
        default_body=req.body,
        timeout=req.timeout or 30,
        verify_ssl=req.verify_ssl if req.verify_ssl is not None else True,
        auth_type=auth_type,
        auth_config=auth_config_dict,
    )

    result = await _api_service.create(create_payload, user_id=user_id, test_before_save=True)

    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)

    return result


@router.post("/api/test")
async def test_api_connector(
    req: APIConnectorTest,
    user: UserContext = Depends(require_user),
):
    """Test a saved connector's connectivity and update its status."""
    user_id = resolve_user_id(user)
    result = await _api_service.test(req.connector_id, user_id=user_id)
    if result.error_type == "not_found":
        raise HTTPException(status_code=404, detail={"success": False, "error": result.error})
    return result.model_dump()


@router.post("/api/invoke")
async def invoke_api_connector(
    req: APIConnectorInvoke,
    user: UserContext = Depends(require_user),
):
    """Invoke a connector action. Reads config from DB, resolves auth, executes HTTP."""
    user_id = resolve_user_id(user)
    result = await _api_service.invoke(
        req.connector_id,
        user_id=user_id,
        headers=req.headers,
        query_params=req.query_params,
        body=req.body,
        timeout=req.timeout,
    )
    if result.error_type == "not_found":
        raise HTTPException(status_code=404, detail=result.model_dump())
    if not result.success and result.error_type in ("server_error",):
        raise HTTPException(status_code=502, detail=result.model_dump())
    return result.model_dump()


@router.get("/api/list")
async def list_api_connectors(
    page: int = Query(1, ge=1, description="Page number (1-based)"),
    page_size: int = Query(20, ge=1, le=1000, description="Items per page"),
    search: Optional[str] = Query(None, description="Search term for connector name"),
    user: UserContext = Depends(require_user),
):
    """List API connectors for the current user with pagination and optional search (secrets masked)."""
    from echolib.schemas.pagination import PaginatedResponse
    
    try:
        user_id = resolve_user_id(user)
        logger.info(
            "[API] user_id=%s",
            user_id,
        )
        repo = ConnectorsRepository()

        async with get_db_session() as db:
            connectors, total = await repo.list_api_connectors_paginated(
                db,
                user_id=user_id,
                page=page,
                page_size=page_size,
                search=search,
            )
        logger.info(
        "[API] Connectors loaded "
        "user_id=%s total=%s returned=%s",
        user_id,
        total,
        len(connectors),
        )
        # Convert to dict and mask secrets
        connector_dicts = []
        for c in connectors:
            c_dict = c.config_json.copy() if hasattr(c, 'config_json') else {}
            c_dict['connector_id'] = c.connector_id
            c_dict['status'] = c.status
            connector_dicts.append(c_dict)

        return PaginatedResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=connector_dicts,
        )
    except Exception as e:
        return {
            "page": page,
            "page_size": page_size,
            "total": 0,
            "items": [],
        }


@router.get("/api/get")
async def get_api_connector(
    connector_id: str = Query(..., description="Connector ID to fetch"),
    user: UserContext = Depends(require_user),
):
    """Get connector details by ID (secrets masked)."""
    user_id = resolve_user_id(user)
    connector = await _api_service.get(connector_id, user_id=user_id)
    if not connector:
        raise HTTPException(status_code=404, detail={"success": False, "error": f"Connector '{connector_id}' not found"})
    return {"success": True, **connector}


@router.put("/api/{connector_id}")
async def update_api_connector(
    connector_id: str,
    req: APIConnectorUpdate,
    user: UserContext = Depends(require_user),
):
    """Update connector configuration. Applies partial updates, re-tests, saves."""
    user_id = resolve_user_id(user)
    result = await _api_service.update(
        connector_id, req, user_id=user_id, test_after_update=True,
    )
    if not result.get("success"):
        status_code = 404 if "not found" in result.get("error", "") else 400
        raise HTTPException(status_code=status_code, detail=result)

    return result


# Legacy DELETE endpoint — must be registered BEFORE the path-parameter route
@router.delete("/api/delete")
async def delete_api_connector_legacy(
    req: APIConnectorDeleteRequest,
    user: UserContext = Depends(require_user),
):
    """Legacy delete endpoint (frontend sends body with connector_id)."""
    return await delete_api_connector(req.connector_id, user=user)


@router.delete("/api/{connector_id}")
async def delete_api_connector(
    connector_id: str,
    user: UserContext = Depends(require_user),
):
    """Delete a connector by ID."""
    user_id = resolve_user_id(user)
    result = await _api_service.delete(connector_id, user_id=user_id)
    if not result.get("success"):
        raise HTTPException(status_code=404, detail=result)

    return result

# ============================================================================
# UNIVERSAL DATABASE CONNECTOR
# ============================================================================

_db_service = DatabaseConnectorService()


class DBConnectionUpdateRequest(BaseModel):
    """Request to update a saved database connection."""
    name: Optional[str] = Field(None, description="New display name")


class DBInvokeRequest(BaseModel):
    """Request to run a natural language question on a saved database connection."""
    connection_id: str = Field(..., description="ID of the saved DB connection")
    question: str = Field(..., description="Natural language question")
    limit: int = Field(100, description="Max rows to return for read queries")
    timeout: int = Field(30, description="Query timeout in seconds")



class DBConnectionTestRequest(DBConnectionConfig):
    connection_id: Optional[str] = None
    file_id: Optional[str] = None




# ---------- Supported databases ----------

@router.get("/db/supported", summary="List Supported Database Types")
async def db_supported_databases():
    """List all supported database types with default ports and available drivers."""
    return {
        "databases": _db_service.list_supported_databases(),
        "ssh_tunnel_supported": True,
    }

# To get uploaded file information from postgres file_upload table
def get_uploaded_file_by_connection_id(
    connection_id: str,
) -> Optional[Dict[str, Any]]:
    LOG = logging.getLogger(__name__)

    LOG.info(
        "[FILE_REGISTRY_DB] lookup connection_id=%s",
        connection_id,
    )

    try:
        from apps.connector.db_connector import _get_pg_engine, text
        engine = _get_pg_engine()

        with engine.connect() as conn:

            row = conn.execute(
                text(
                    """
                    SELECT
                        file_id,
                        connection_id,
                        db_path,
                        blob_name,
                        original_path,
                        format,
                        sheets_json,
                        stored_locally,
                        file_size
                    FROM uploaded_files
                    WHERE connection_id = :connection_id
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                ),
                {
                    "connection_id": connection_id,
                },
            ).mappings().first()

        if not row:

            LOG.warning(
                "[FILE_REGISTRY_DB] connection_id not found=%s",
                connection_id,
            )

            return None

        LOG.info(
            "[FILE_REGISTRY_DB] found connection_id=%s",
            connection_id,
        )

        return dict(row)

    except Exception:

        LOG.exception(
            "[FILE_REGISTRY_DB] lookup failed connection_id=%s",
            connection_id,
        )

        return None

# ---------- Connect & Save with file (SQLite / DuckDB) ----------

@router.post("/db/connect-with-file", summary="Upload SQLite/DuckDB File and Save Connection")
async def db_connect_with_file(
    file: UploadFile = File(...),
    db_type: Optional[str] = Form(None),
    name: Optional[str] = Form(None),
    user: UserContext = Depends(get_current_user),
):
    """Upload a DB file and save connection in one request."""

    log_upload = logging.getLogger(__name__)

    log_upload.info(
        "[CONNECT_WITH_FILE] Received file upload. "
        "filename=%s db_type=%s",
        file.filename if file else None,
        db_type,
    )

    if not file or not file.filename:
        raise HTTPException(status_code=422, detail="No file provided")

    log_upload.info(
    "[CONNECT_WITH_FILE] uploaded_file_name=%s",
    file.filename,
    )

    ext = Path(file.filename).suffix.lower()

    if not ext:
        raise HTTPException(status_code=422, detail="File must have an extension")

    inferred = None
    for dtype, exts in _UPLOAD_EXTENSIONS.items():
        if ext in exts:
            inferred = dtype
            break

    if not inferred:
        raise HTTPException(
            status_code=415,
            detail=(
                f"Unsupported file type '{ext}'. "
                "Use .sqlite, .db, .sqlite3 for SQLite or .duckdb for DuckDB."
            ),
        )

    if db_type and db_type.lower() in _UPLOAD_EXTENSIONS:
        inferred = db_type.lower()

    _UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

    db_file_id = str(uuid.uuid4())

    log_upload.info(
        "[CONNECT_WITH_FILE] Generated db_file_id=%s",
        db_file_id,
    )

    stored_name = f"{db_file_id}{ext}"
    stored_path = _UPLOADS_DIR / stored_name

    log_upload.info(
        "[CONNECT_WITH_FILE] stored_name=%s",
        stored_name,
    )

    log_upload.info(
        "[CONNECT_WITH_FILE] stored_path=%s",
        stored_path,
    )

    try:
        file_content_hash = await _stream_upload_to_disk(
            file,
            stored_path,
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] File saved successfully"
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] file_exists=%s",
            stored_path.exists(),
        )

        
        if stored_path.exists():
            file_size_on_disk = stored_path.stat().st_size

            log_upload.info(
                "[CONNECT_WITH_FILE] file_size=%s bytes",
                file_size_on_disk,
            )

            log_upload.info(
                "[FILE_STORAGE] Saved to filesystem path=%s size=%s",
                stored_path,
                file_size_on_disk,
            )


        log_upload.info(
            "[CONNECT_WITH_FILE] file_content_hash=%s",
            file_content_hash,
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save uploaded file: {e}",
        )

    try:
        blob_name = derive_blob_name_from_path(stored_path)

        log_upload.info(
            "[CONNECT_WITH_FILE] Azure upload preparation"
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] db_file_id=%s",
            db_file_id,
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] stored_path=%s",
            stored_path,
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] blob_name=%s",
            blob_name,
        )

        file_size = stored_path.stat().st_size if stored_path.exists() else 0

        keep_local_copy = (
            file_size <= FILE_SYSTEM_THRESHOLD_BYTES
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] file_size=%s bytes keep_local_copy=%s",
            file_size,
            keep_local_copy,
        )

        uploaded = upload_to_blob(
            stored_path,
            blob_name,
        )

        if uploaded:
            log_upload.info(
                "[CONNECT_WITH_FILE] Upload successful. blob=%s",
                blob_name,
            )

            log_upload.info(
                "[FILE_STORAGE] Uploaded to blob path=%s blob=%s size=%s",
                stored_path,
                blob_name,
                file_size,
            )

            if not keep_local_copy:
                try:
                    stored_path.unlink(missing_ok=True)

                    log_upload.info(
                        "[FILE_STORAGE] Removed local copy path=%s size=%s threshold=%s source=blob_only",
                        stored_path,
                        file_size,
                        FILE_SYSTEM_THRESHOLD_BYTES,
                    )
                except Exception:
                    log_upload.exception(
                        "[CONNECT_WITH_FILE] Failed removing local file"
                    )

        else:
            log_upload.warning(
                "[CONNECT_WITH_FILE] Upload failed. blob=%s",
                blob_name,
            )

    except Exception:
        log_upload.exception(
            "[CONNECT_WITH_FILE] Error uploading to Azure Blob"
        )

    abs_path = os.path.abspath(stored_path)

    log_upload.info(
        "[CONNECT_WITH_FILE] abs_path=%s",
        abs_path,
    )

    log_upload.info(
        "[CONNECT_WITH_FILE] expected_connection_string=sqlite:///%s",
        abs_path,
    )

    effective_user_id = resolve_user_id(user)

    config = DBConnectionConfig(
        db_type=inferred,
        database_file_path=abs_path,
        uploaded_file_name=file.filename,
        name=(name or "").strip() or None,
        file_content_hash=file_content_hash,
    )
    log_upload.info(
        "[CONNECT_WITH_FILE] config.uploaded_file_name=%s",
        config.uploaded_file_name,
    )

    log_upload.info(
        "[CONNECT_WITH_FILE] About to call connect_and_save"
    )

    log_upload.info(
        "[CONNECT_WITH_FILE] config.database_file_path=%s",
        config.database_file_path,
    )

    try:
        result = _db_service.connect_and_save(
            config,
            user_id=effective_user_id,
        )
        from apps.convobi.main import save_uploaded_file_record
        connection_id = result["connection_id"]
        save_uploaded_file_record(
            file_id=db_file_id,
            connection_id=connection_id,
            db_path=str(stored_path),
            blob_name=blob_name,
            original_path=None,
            format_type=inferred,
            sheets=None,
            stored_locally=keep_local_copy,
            file_size=file_size,
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] connect_and_save result=%s",
            result,
        )

        log_upload.info(
            "[CONNECT_WITH_FILE] connect_and_save result=%s",
            result,
        )


        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {e}",
        )

# ---------- Update connection with new file ----------

@router.put("/db/{connection_id}/connect-with-file", summary="Update Connection with New File")
async def db_update_connection_with_file(
    connection_id: str,
    file: UploadFile = File(...),
    db_type: Optional[str] = Form(None),
    name: Optional[str] = Form(None),
    user: UserContext = Depends(get_current_user),
):
    """Update an existing connection by uploading a new SQLite or DuckDB file."""
    if not file or not file.filename:
        raise HTTPException(status_code=422, detail="No file provided")
    ext = Path(file.filename).suffix.lower()
    if not ext:
        raise HTTPException(status_code=422, detail="File must have an extension")

    inferred = None
    for dtype, exts in _UPLOAD_EXTENSIONS.items():
        if ext in exts:
            inferred = dtype
            break
    if not inferred:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{ext}'.",
        )
    if db_type and db_type.lower() in _UPLOAD_EXTENSIONS:
        inferred = db_type.lower()

    effective_user_id = resolve_user_id(user)
    conn = _db_service.get_connection(connection_id, user_id=effective_user_id)
    if not conn:
        raise HTTPException(status_code=404, detail=f"Connection '{connection_id}' not found")

    _UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    db_file_id = str(uuid.uuid4())
    stored_name = f"{db_file_id}{ext}"
    stored_path = _UPLOADS_DIR / stored_name

    try:
        file_content_hash = await _stream_upload_to_disk(file, stored_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded file: {e}")

    abs_path = os.path.abspath(stored_path)

    config = DBConnectionConfig(
        db_type=inferred,
        database_file_path=abs_path,
        name=(name or "").strip() or None,
        file_content_hash=file_content_hash,
    )
    try:
        result = _db_service.update_connection_with_config(
                connection_id,
                config,
                user_id=effective_user_id
            )

        from apps.convobi.main import save_uploaded_file_record

        save_uploaded_file_record(
                file_id=db_file_id,
                connection_id=connection_id,
                db_path=str(stored_path),
                blob_name=derive_blob_name_from_path(stored_path),
                original_path=None,
                format_type=inferred,
                sheets=None,
                stored_locally=True,
                file_size=stored_path.stat().st_size,
            )

        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")

# Helper function for test connection
def get_uploaded_file_record(
    file_id: str = None,
    connection_id: str = None,
):
    engine = _get_pg_engine()

    with engine.begin() as conn:

        if file_id:
            result = conn.execute(
                text("""
                    SELECT *
                    FROM uploaded_files
                    WHERE file_id = :file_id
                    LIMIT 1
                """),
                {
                    "file_id": file_id,
                },
            )

        elif connection_id:
            result = conn.execute(
                text("""
                    SELECT *
                    FROM uploaded_files
                    WHERE connection_id = :connection_id
                    LIMIT 1
                """),
                {
                    "connection_id": connection_id,
                },
            )

        else:
            return None

        row = result.mappings().first()

        return dict(row) if row else None
# ---------- Test Connection ----------
@router.post("/db/test", summary="Test Database Connection")
async def db_test_connection(
    request: DBConnectionTestRequest,
    user: UserContext = Depends(get_current_user),
):

    effective_user_id = resolve_user_id(user)

    logger.info(
        "[DB_TEST] request=%s",
        request.model_dump(),
    )

    try:

        if request.connection_id:

            return _db_service.test_saved_connection(
                request.connection_id,
                user_id=effective_user_id,
            )

        if request.file_id:

            return _db_service.test_uploaded_file(
                request.file_id,
            )

        return _db_service.test_connection(request)

    except HTTPException:
        raise

    except ValueError as e:

        logger.exception(
            "[DB_TEST] validation error"
        )

        raise HTTPException(
            status_code=400,
            detail=str(e),
        )

    except Exception as e:

        logger.exception(
            "[DB_TEST] unexpected error"
        )

        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {e}",
        )

# @router.post("/db/test", summary="Test Database Connection")
# async def db_test_connection(config: DBConnectionConfig):

#     logger.info(
#         "[DB_TEST] request received "
#         "db_type=%s "
#         "database_file_path=%s "
#         "host=%s "
#         "database_name=%s",
#         getattr(config, "db_type", None),
#         getattr(config, "database_file_path", None),
#         getattr(config, "host", None),
#         getattr(config, "database_name", None),
#     )

#     try:
#         result = _db_service.test_connection(config)

#         logger.info(
#             "[DB_TEST] result=%s",
#             result,
#         )

#         return result

#     except HTTPException:
#         raise

#     except ValueError as e:

#         logger.exception(
#             "[DB_TEST] validation error"
#         )

#         raise HTTPException(
#             status_code=400,
#             detail=str(e),
#         )

#     except Exception as e:

#         logger.exception(
#             "[DB_TEST] unexpected error"
#         )

#         raise HTTPException(
#             status_code=500,
#             detail=f"Unexpected error: {e}"
#         )

# ---------- Connect & Save ----------

@router.post("/db/connect", summary="Connect & Save Database")
async def db_connect_and_save(
    config: DBConnectionConfig,
    user: UserContext = Depends(get_current_user),
):
    """Test connection, then save it for future use. Returns connection_id."""
    try:
        effective_user_id = resolve_user_id(user)
        result = _db_service.connect_and_save(config, user_id=effective_user_id)
        return result
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")


# ---------- List saved connections ----------

@router.get("/db/list", summary="List Saved Database Connections")
async def db_list_connections(user: UserContext = Depends(get_current_user)):
    """List all saved database connections for the current user (credentials masked)."""
    effective_user_id = resolve_user_id(user)
    return {"connections": _db_service.list_connections(user_id=effective_user_id)}


# ---------- Get connection details ----------

@router.get("/db/{connection_id}", summary="Get Database Connection Details")
async def db_get_connection(connection_id: str, user: UserContext = Depends(get_current_user)):
    """Get details of a saved database connection by ID."""
    effective_user_id = resolve_user_id(user)
    conn = _db_service.get_connection(connection_id, user_id=effective_user_id)
    if not conn:
        raise HTTPException(status_code=404, detail=f"Connection '{connection_id}' not found")
    return conn


# ---------- Update connection ----------

@router.put("/db/{connection_id}", summary="Update Database Connection")
async def db_update_connection(
    connection_id: str,
    req: DBConnectionUpdateRequest,
    user: UserContext = Depends(get_current_user),
):
    """Update a saved connection (rename, etc.)."""
    try:
        effective_user_id = resolve_user_id(user)
        return _db_service.update_connection(
            connection_id, req.model_dump(exclude_none=True), user_id=effective_user_id
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ---------- Delete connection ----------

@router.delete("/db/{connection_id}", summary="Delete Database Connection")
async def db_delete_connection(connection_id: str, user: UserContext = Depends(get_current_user)):
    """Delete a saved connection and clean up engine / SSH tunnel."""
    try:
        effective_user_id = resolve_user_id(user)
        return _db_service.delete_connection(connection_id, user_id=effective_user_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ---------- Invoke (execute query on saved connection) ----------

@router.post("/db/invoke", summary="Run Natural Language Question on Database")
async def db_invoke(req: DBInvokeRequest, user: UserContext = Depends(get_current_user)):
    """Run a natural language question on a saved database connection (requires LLM)."""
    try:
        effective_user_id = resolve_user_id(user)
        return _db_service.invoke_with_question(
            connection_id=req.connection_id,
            question=req.question.strip(),
            limit=req.limit,
            timeout=req.timeout,
            user_id=effective_user_id,
        )
    except ValueError as e:
        msg = str(e)
        if "not found" in msg.lower():
            raise HTTPException(status_code=404, detail=msg)
        raise HTTPException(status_code=400, detail=msg)

