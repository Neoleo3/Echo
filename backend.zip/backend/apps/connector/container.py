import os
from pathlib import Path

from echolib.di import container
from echolib.services import ConnectorManager


# Keep connector artifacts outside the code repository.
_connector_root = Path.home() / ".echoai" / "connectors"
os.environ.setdefault("API_CONNECTOR_STORAGE_DIR", str(_connector_root / "api"))
os.environ.setdefault("MCP_STORAGE_DIR", str(_connector_root / "mcp"))
 
_mgr = ConnectorManager()
container.register('connector.manager', lambda:_mgr)

# Connector Middleware: the only path from an agent's ``definition.connectors``
# to a real API / MCP / database call. ``AgentFactory`` imports the builder
# directly (as it does the tool builder); the registration is here so other
# apps -- applications, in a later phase -- resolve the same implementation
# rather than growing a second one.
from apps.connector.middleware import build_connector_middleware  # noqa: E402

container.register('connector.middleware', lambda: build_connector_middleware)
 
 