from fastapi import APIRouter, Depends, HTTPException
from echolib.di import container
from echolib.security import user_context, get_current_user
from echolib.types import *

from echolib.services import ChatOrchestrator
from echolib.types import Session, UserContext
from echolib.utils import new_id
from apps.analytics.token_limit import TokenLimitExceededException
from apps.analytics.token_governance_handler import handle_token_limit_exception

router = APIRouter(prefix='/chat', tags=['ChatApi'])

def orch() -> ChatOrchestrator:
    return container.resolve('chat.orchestrator')

@router.post('/chat')
async def chat(message: dict, user: UserContext = Depends(get_current_user)):
    try:
        sess = Session(id=new_id('sess_'), user_id=user.user_id, data={})
        return orch().orchestrate(message, sess)
    except TokenLimitExceededException as ex:
        handle_token_limit_exception(ex, "CHAT_ORCHESTRATE", user.user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get('/stream')
async def stream(prompt: str, user: UserContext = Depends(get_current_user)):
    try:
        # use LLM stream via orchestrator's LLM (not exposed directly here)
        tokens = []
        orch().llm.stream(prompt, lambda t: tokens.append(t))
        return {'tokens': tokens}
    except TokenLimitExceededException as ex:
        handle_token_limit_exception(ex, "CHAT_STREAM", user.user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
