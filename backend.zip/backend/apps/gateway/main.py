"""
EchoAI Gateway - Main Application Entry Point

This is the unified gateway for the EchoAI platform. All services are registered
as FastAPI routers and mounted under a single application.

Features:
- Database connection pool (PostgreSQL with asyncpg)
- Memcached session caching (optional, configurable)
- Auth middleware (optional vs required mode via AUTH_ENFORCEMENT)
- CORS configuration for development
- Tool operation logging middleware

Lifespan Events:
- Startup: Initialize database pool, connect to Memcached
- Shutdown: Close database connections, disconnect from Memcached

Configuration (via environment/.env):
- DATABASE_URL: PostgreSQL connection string
- MEMCACHED_ENABLED: Enable/disable Memcached caching
- MEMCACHED_HOSTS: Memcached server addresses
- AUTH_ENFORCEMENT: "optional" or "required"
"""

from contextlib import asynccontextmanager
import logging
import time
import asyncio
import sys
import os

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse


from echolib.config import settings
from echolib.database import database_lifespan, set_main_event_loop as set_db_main_loop
from echolib.cache import cache_lifespan
from echolib.security import AuthMiddleware
from echolib.secrets_provider import secrets
from echolib.utils import remove_server_header_middleware

# Import containers to register providers
from apps.session import container as _sess_container  # noqa: F401
from apps.rag import container as _rag_container  # noqa: F401
from apps.llm import container as _llm_container  # noqa: F401
from apps.tool import container as _tool_container  # noqa: F401
from apps.appmgr import container as _app_container  # noqa: F401
from apps.workflow import container as _wf_container  # noqa: F401
from apps.agent import container as _agent_container  # noqa: F401
from apps.connector import container as _conn_container  # noqa: F401
from apps.chat import container as _chat_container  # noqa: F401
from apps.workbench import container as _wb_container  # noqa: F401

from apps.appmgr.Agentic_Applications.agentic_routes import router as agentic_app_router
from apps.notifications.routes import router as notifications_router
from apps.agent_trust.routes import agent_trust_router
# Import containers to register providers
from apps.convobi import container as _convobi_container  # noqa: F401
from apps.knowledge import container as _knowledge_container  # noqa: F401

# Routers
from apps.session.routes import router as session_router
from apps.rag.routes import router as rag_router
from apps.llm.routes import router as llm_router
from apps.tool.routes import router as tool_router
from apps.appmgr.routes import router as app_router
from apps.appmgr.routes import lookup_router as app_lookup_router
from apps.appmgr.routes import skills_router as app_skills_router
from apps.appmgr.llm_config_routes import llm_config_router
from apps.workflow.routes import router as wf_router
from apps.agent.routes import router as agent_router
from apps.connector.routes import router as conn_router
from apps.connector.marketplace.routes import router as marketplace_router
from apps.chat.routes import router as chat_router
from apps.workbench.routes import router as workbench_router
# from apps.llm.workbench_routes import router as llm_workbench_router

try:
    from apps.analytics.routes import router as analytics_router
    analytics_router_import_error = None
except Exception as exc:
    analytics_router = None
    analytics_router_import_error = exc

# User Management router
from apps.user_management.routes import router as user_mgmt_router

# Routers
from apps.convobi.routes import router as convobi_router
from apps.knowledge.routes import router as knowledge_router

# Token limit - analytics
from apps.analytics.token_limit import TokenLimitExceededException
 
# ==============================================================================
# Router Registration
# =========================================================================
 


# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Multipart defaults in Starlette are 1MB per part, which causes frequent
# failures for normal document uploads. Patch Request.form defaults globally
# so file uploads across the gateway can handle larger knowledge files.
_MULTIPART_MAX_PART_SIZE_BYTES = int(
    os.getenv("ECHO_MULTIPART_MAX_PART_SIZE_MB", "64")
) * 1024 * 1024
_MULTIPART_MAX_FILES = int(os.getenv("ECHO_MULTIPART_MAX_FILES", "1000"))
_MULTIPART_MAX_FIELDS = int(os.getenv("ECHO_MULTIPART_MAX_FIELDS", "1000"))


def _patch_multipart_limits() -> None:
    from starlette.requests import Request as _StRequest

    original_get_form = _StRequest._get_form
    original_form = _StRequest.form

    async def _patched_get_form(
        self,
        *,
        max_files: int | float = _MULTIPART_MAX_FILES,
        max_fields: int | float = _MULTIPART_MAX_FIELDS,
        max_part_size: int = _MULTIPART_MAX_PART_SIZE_BYTES,
    ):
        return await original_get_form(
            self,
            max_files=max_files,
            max_fields=max_fields,
            max_part_size=max_part_size,
        )

    def _patched_form(
        self,
        *,
        max_files: int | float = _MULTIPART_MAX_FILES,
        max_fields: int | float = _MULTIPART_MAX_FIELDS,
        max_part_size: int = _MULTIPART_MAX_PART_SIZE_BYTES,
    ):
        return original_form(
            self,
            max_files=max_files,
            max_fields=max_fields,
            max_part_size=max_part_size,
        )

    _StRequest._get_form = _patched_get_form
    _StRequest.form = _patched_form

    logger.info(
        "Multipart limits configured: max_part_size=%dMB max_files=%d max_fields=%d",
        _MULTIPART_MAX_PART_SIZE_BYTES // (1024 * 1024),
        _MULTIPART_MAX_FILES,
        _MULTIPART_MAX_FIELDS,
    )


try:
    _patch_multipart_limits()
except Exception:
    logger.warning(
        "Failed to patch multipart limits — uploads will use Starlette defaults (1MB per part)",
        exc_info=True,
    )

if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


# ---------------------------------------------------------------------------
# TTL cleanup: generated files (PPT, Excel, charts)
# ---------------------------------------------------------------------------

_CLEANUP_INTERVAL_SECONDS = 3600  # run once per hour


async def _run_generated_files_cleanup_loop() -> None:
    """
    Background loop that purges expired generated files from disk and DB.

    WHY: Agent tools (ppt_generator, excel_generator, data_analyst charts)
    write files to disk with a 24-hour TTL. Without cleanup, generated/
    directories fill indefinitely. This loop runs every hour, queries
    expired rows, removes files from disk, then soft-deletes DB records.

    The loop is started by the lifespan manager and cancelled on shutdown.
    All exceptions are caught per-iteration so a single failure never stops
    the cleanup service.

    Raises:
        asyncio.CancelledError: Raised when the task is cancelled during
            graceful shutdown â€” propagated so asyncio can clean up.
    """
    from echolib.repositories.generated_file_repo import GeneratedFileRepository

    _repo = GeneratedFileRepository()

    logger.info("TTL cleanup loop started (interval=%ds)", _CLEANUP_INTERVAL_SECONDS)
    while True:
        try:
            await asyncio.sleep(_CLEANUP_INTERVAL_SECONDS)
            await _purge_expired_generated_files(_repo)
        except asyncio.CancelledError:
            logger.info("TTL cleanup loop cancelled â€” shutting down")
            raise
        except Exception:
            logger.exception("TTL cleanup iteration failed â€” will retry next cycle")


async def _purge_expired_generated_files(
    repo: "GeneratedFileRepository",  # type: ignore[name-defined]
) -> None:
    """
    Single cleanup pass: fetch expired records, delete disk files, soft-delete DB rows.

    WHY: Separated from the loop so it can also be called during integration
    tests or startup without waiting for the hourly interval.

    Args:
        repo: GeneratedFileRepository instance for DB operations.

    Returns:
        None. Logs counts at INFO level. Errors per-file are logged and skipped.
    """
    import os
    from echolib.database import get_db_session

    try:
        async with get_db_session() as db:
            expired = await repo.get_expired_files(db)
    except Exception:
        logger.exception("Failed to fetch expired generated files from DB")
        return

    if not expired:
        logger.debug("TTL cleanup: no expired generated files found")
        return

    logger.info("TTL cleanup: found %d expired generated file(s) to purge", len(expired))
    purged_count = 0
    for record in expired:
        try:
            # 1. Delete from disk
            if record.file_path and os.path.isfile(record.file_path):
                os.remove(record.file_path)
                logger.debug(
                    "TTL cleanup: deleted disk file '%s' (key=%s)",
                    record.file_path, record.download_key,
                )
        except OSError:
            logger.warning(
                "TTL cleanup: failed to delete disk file '%s' â€” soft-deleting DB record anyway",
                record.file_path,
            )

        try:
            # 2. Soft-delete DB record (get_db_session auto-commits on clean exit)
            async with get_db_session() as db:
                await repo.soft_delete(db, str(record.generated_file_id))
            purged_count += 1
        except Exception:
            logger.exception(
                "TTL cleanup: failed to soft-delete DB record %s",
                record.generated_file_id,
            )

    logger.info("TTL cleanup: purged %d/%d expired file(s)", purged_count, len(expired))


async def _refresh_allocation_cache():
    """Load active token allocations into MetricsCollector's sync budget cache."""
    try:
        from echolib.database import get_db_session
        from echolib.models.user_token_allocation import UserTokenAllocation
        from echolib.otel import get_metrics_collector
        from sqlalchemy import select

        async with get_db_session() as db:
            q = select(UserTokenAllocation).where(UserTokenAllocation.is_active == True)
            allocs = (await db.execute(q)).scalars().all()

        cache = {}
        for a in allocs:
            cache[str(a.user_id)] = {
                "token_limit": a.token_limit,
                "token_duration": a.token_duration,
            }

        collector = get_metrics_collector()
        if collector:
            collector.set_allocation_cache(cache)
    except Exception:
        logger.debug("Failed to refresh allocation cache", exc_info=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.

    Handles startup and shutdown of:
    - Database connection pool
    - Memcached cache client
    """
    logger.info("=" * 60)
    logger.info("ðŸš€ Starting EchoAI Gateway...")
    logger.info("=" * 60)
    logger.info(f"ðŸ“‹ Configuration:")
    logger.info(f"   - Auth Enforcement: {settings.auth_enforcement}")
    logger.info(f"   - Memcached Enabled: {settings.memcached_enabled}")
    logger.info(f"   - Service Mode: {settings.service_mode}")
    logger.info(f"   - Key Vault: {'enabled' if settings.key_vault_enabled else 'disabled'}")

    # SSO startup diagnostic
    if settings.sso_enabled and not settings.sso_client_id:
        import os
        live_val = os.getenv("SSO_CLIENT_ID", "")
        if live_val:
            logger.warning(
                "SSO_CLIENT_ID was empty at Settings() init but is now available in os.environ. "
                "This indicates a startup timing issue — dynamic fallback will be used."
            )
        else:
            logger.error(
                "SSO is enabled but SSO_CLIENT_ID is empty in both settings and os.environ. "
                "SSO login will fail. Check Azure App Service Configuration."
            )

    # Ensure SecretsProvider is initialized before any downstream service.
    # This is idempotent â€” config.py already calls initialize() at import time,
    # but the explicit call here makes the startup contract visible and ensures
    # the provider is ready even if config.py was imported in an unusual order.
    secrets.initialize(
        key_vault_url=settings.key_vault_url or None,
        key_vault_enabled=settings.key_vault_enabled,
        secret_prefix=settings.key_vault_prefix or None,
    )
    if secrets.is_keyvault_enabled:
        logger.info("âœ… SecretsProvider connected to Key Vault (%s)", settings.key_vault_url)
    else:
        logger.info("â„¹ï¸ SecretsProvider using environment variables only (Key Vault disabled)")

    # Initialize database
    async with database_lifespan():
        logger.info("âœ… Database connection pool initialized")

        # Store the main event loop so that sync wrappers (the LLM resolver's
        # synchronous facade, and anything else called from a worker thread) can
        # schedule async DB work on the correct loop instead of creating a new one.
        from echolib.llm_resolver import set_main_event_loop
        set_main_event_loop()

        from echolib.credential_resolver import set_main_event_loop as set_cred_main_loop
        set_cred_main_loop()

        # Capture main loop for database sync bridges used by sync runtime paths.
        set_db_main_loop()

        # Capture the main event loop for tool execution modules. Tools run
        # synchronously inside worker threads but schedule async DB operations
        # back on this loop via run_coroutine_threadsafe().
        _loop = asyncio.get_running_loop()

        # Tool execution shares the same loop. Without this the sync tool bridge
        # falls back to a private loop, which breaks asyncpg-backed tools because
        # their connections are bound to the loop that created them.
        try:
            from apps.tool.async_bridge import set_main_loop as _set_tool_loop
            _set_tool_loop(_loop)
        except Exception:
            logger.warning("Tool async bridge unavailable at startup", exc_info=True)

        # Ensure the default admin user exists in the database.
        # This prevents UUID instability: without this call the login
        # endpoint would create a new user row (with a random UUID)
        # every time the admin email is used after a fresh DB or restart.
        try:
            from echolib.database import get_db_session
            from echolib.repositories.base import ensure_default_user_exists
            async with get_db_session() as db:
                await ensure_default_user_exists(db)
            logger.info("âœ… Default admin user verified")
        except RuntimeError as e:
            if "Event loop is closed" in str(e):
                logger.info("Skipping default user verification during loop shutdown")
            else:
                logger.warning(f"Failed to verify default user at startup: {e}")
        except Exception as e:
            logger.warning(f"Failed to verify default user at startup: {e}")

        # Finish agent attachments whose conversion a previous run was killed
        # partway through. Conversion happens inside this process, so without
        # this sweep a redeploy mid-ingest stranded the row on 'pending'
        # permanently and the user's only recourse was to upload the document
        # again. Unconditional and non-fatal: the sweep never blocks startup.
        try:
            from apps.agent.file_attachments import recover_interrupted_ingests

            swept = await recover_interrupted_ingests()
            if swept.get("claimed"):
                logger.info("Interrupted attachment sweep at startup: %s", swept)
        except Exception as e:
            logger.warning(f"Interrupted attachment sweep at startup failed: {e}")

        # Initialize cache (optional - gracefully handles connection failures)
        async with cache_lifespan():
            if settings.memcached_enabled:
                from echolib.cache import cache_client
                if cache_client.is_available:
                    logger.info("âœ… Memcached cache layer initialized")
                else:
                    logger.warning("âš ï¸ Memcached unavailable - using database only")
            else:
                logger.info("â„¹ï¸ Memcached disabled - using database only")

            # ---------------------------------------------------------------
            # Observability Initialization (OTel-only)
            # ---------------------------------------------------------------
            try:
                from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
                from opentelemetry.instrumentation.threading import ThreadingInstrumentor

                # 1. Thread context propagation (for asyncio.to_thread + ThreadPoolExecutor)
                ThreadingInstrumentor().instrument()

                # 2. FastAPI auto-instrumentation (HTTP request spans)
                FastAPIInstrumentor.instrument_app(app)

                # Agent and tool spans are emitted directly by ``echolib.otel``
                # (see ``AgentFactory`` and ``ToolExecutor``); no framework
                # auto-instrumentor is involved. The CrewAI instrumentor that
                # used to be imported here was never installed, and because its
                # ImportError aborted this whole block, the two instrumentors
                # above were silently never attached either.
                logger.info("OTel instrumentors attached (Threading, FastAPI)")
            except Exception as e:
                logger.warning(
                    f"OTel instrumentor initialization failed (app will continue without tracing): {e}"
                )

            # Requests / httpx auto-instrumentation (traces outbound HTTP calls)
            try:
                from opentelemetry.instrumentation.requests import RequestsInstrumentor
                RequestsInstrumentor().instrument()
            except Exception:
                pass
            try:
                from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
                HTTPXClientInstrumentor().instrument()
            except Exception:
                pass

            # ---------------------------------------------------------------
            # EchoAI OTel Metrics + DB Telemetry Initialization
            # ---------------------------------------------------------------
            batch_writer = None
            budget_rotation_task = None
            try:
                from echolib.otel import init_otel, shutdown_otel
                init_otel()
                logger.info("âœ… EchoAI OTel metrics layer initialized")

                # Wire SSE event bus to MetricsCollector
                try:
                    from echolib.telemetry_stream import get_event_bus
                    from echolib.otel import get_metrics_collector
                    event_bus = get_event_bus()
                    collector = get_metrics_collector()
                    if collector:
                        collector._event_bus = event_bus
                    logger.info("Telemetry SSE event bus wired")
                except Exception as e:
                    logger.debug(f"SSE event bus wiring failed: {e}")

                # Start async batch writer for DB telemetry persistence
                if settings.DB_TELEMETRY_ENABLED:
                    from echolib.repositories.telemetry_repo import AsyncBatchWriter
                    batch_writer = AsyncBatchWriter(batch_size=100, flush_interval=5.0)
                    await batch_writer.start()
                    logger.info("âœ… Telemetry batch writer started")

                    # Wire batch writer to MetricsCollector
                    try:
                        from echolib.otel import get_metrics_collector
                        collector = get_metrics_collector()
                        if collector:
                            collector._batch_writer = batch_writer
                    except Exception:
                        pass

                    # Rotate expired token-usage periods on startup
                    try:
                        from echolib.database import get_db_session
                        from echolib.repositories.telemetry_repo import TelemetryRepository
                        repo = TelemetryRepository()
                        async with get_db_session() as db:
                            rotated = await repo.rotate_periods(db)
                            await db.commit()
                        if rotated:
                            logger.info(f"Rotated {rotated} expired token-usage periods")
                    except Exception as e:
                        logger.warning(f"Period rotation at startup failed: {e}")

                # Budget maintenance loop (refreshes allocation cache + rotates periods hourly)
                if settings.TOKEN_BUDGET_ENFORCEMENT != "disabled":
                    async def _budget_maintenance_loop():
                        from echolib.repositories.telemetry_repo import TelemetryRepository
                        from echolib.database import get_db_session
                        repo = TelemetryRepository()
                        while True:
                            try:
                                await asyncio.sleep(3600)
                                await _refresh_allocation_cache()
                                async with get_db_session() as db:
                                    rotated = await repo.rotate_periods(db)
                                    await db.commit()
                                if rotated:
                                    logger.info("Budget maintenance: closed %d expired period(s)", rotated)
                            except asyncio.CancelledError:
                                raise
                            except Exception:
                                logger.exception("Budget maintenance iteration failed")

                    budget_rotation_task = asyncio.create_task(
                        _budget_maintenance_loop(), name="budget_maintenance"
                    )
                    logger.info("âœ… Token budget maintenance task started")

                # Initial allocation cache load
                await _refresh_allocation_cache()

            except Exception as e:
                logger.warning(
                    "EchoAI OTel initialization failed (app continues without custom metrics): %s", e
                )

            from apps.convobi.main import app as convobi_app, lifespan as convobi_lifespan
            async with convobi_lifespan(convobi_app):
                logger.info("âœ… Convobi state initialized (NLP DB under /convobi)")

                # Rehydrate custom LLM models from DB into ConfigLoader
                try:
                    from apps.llm.routes import rehydrate_custom_models_from_db
                    await rehydrate_custom_models_from_db()
                    logger.info("âœ… Custom LLM model rehydration complete")
                except Exception as e:
                    logger.warning("Custom LLM model rehydration failed (non-fatal): %s", e)

                # Eagerly initialize ToolService + ToolExecutor so that
                # any init errors surface during startup (visible in logs)
                # rather than on the first /tools/list request (silent 500).
                try:
                    from echolib.di import container as di_container
                    di_container.resolve('tool.service')
                    logger.info("\u2705 ToolService initialized")
                except Exception as e:
                    logger.error("ToolService eager initialization failed: %s", e, exc_info=True)

                # Start TTL cleanup background task for generated files.
                # This runs every hour and purges expired PPT/Excel/chart files
                # from disk + soft-deletes the corresponding DB records.
                cleanup_task = asyncio.create_task(
                    _run_generated_files_cleanup_loop(),
                    name="generated_files_ttl_cleanup",
                )
                logger.info("âœ… Generated files TTL cleanup task started")

                # Agent Trust: live cost/audit subscriber + periodic reconciliation
                # (continuous, no Judge LLM involved -- see echolib/service/agent_trust/cost_service.py)
                from apps.agent_trust import container as agent_trust_container
                _agent_trust_cost_service = agent_trust_container.resolve("agent_trust.cost")
                agent_trust_cost_subscriber_task = asyncio.create_task(
                    _agent_trust_cost_service.run_live_subscriber(),
                    name="agent_trust_cost_subscriber",
                )
                agent_trust_cost_reconcile_task = asyncio.create_task(
                    _agent_trust_cost_service.run_reconciliation_loop(),
                    name="agent_trust_cost_reconciliation",
                )
                logger.info("âœ… Agent Trust cost subscriber + reconciliation tasks started")

                logger.info("=" * 60)
                logger.info("ðŸŽ‰ EchoAI Gateway READY")
                logger.info("=" * 60)
                try:
                    yield
                finally:
                    # Graceful shutdown: cancel the cleanup loop
                    cleanup_task.cancel()
                    try:
                        await cleanup_task
                    except asyncio.CancelledError:
                        pass
                    logger.info("TTL cleanup task stopped")

                    for _task in (agent_trust_cost_subscriber_task, agent_trust_cost_reconcile_task):
                        _task.cancel()
                        try:
                            await _task
                        except asyncio.CancelledError:
                            pass
                    logger.info("Agent Trust cost tasks stopped")

                    # Shutdown OTel batch writer + budget rotation
                    if budget_rotation_task:
                        budget_rotation_task.cancel()
                        try:
                            await budget_rotation_task
                        except asyncio.CancelledError:
                            pass
                        logger.info("Budget rotation task stopped")

                    if batch_writer:
                        try:
                            await batch_writer.stop()
                            logger.info("Telemetry batch writer stopped")
                        except Exception:
                            logger.warning("Batch writer shutdown error (non-fatal)")

                    try:
                        from echolib.otel import shutdown_otel
                        shutdown_otel()
                        logger.info("OTel shutdown complete")
                    except Exception:
                        pass

                    # Shutdown MCP persistent sessions
                    try:
                        from echolib.di import container as _di
                        _mcp_svc = _di.resolve("connector.manager").mcp
                        _sm = getattr(_mcp_svc, "_session_manager", None)
                        if _sm is not None:
                            await _sm.shutdown()
                    except Exception:
                        pass

                    # Close the HITL checkpointer pool. Opened lazily by the
                    # first HITL workflow; a no-op when none ever ran.
                    try:
                        from apps.workflow.runtime.checkpointer import (
                            close_postgres_checkpointer,
                        )
                        close_postgres_checkpointer()
                    except Exception:
                        pass

    logger.info("ðŸ‘‹ EchoAI Gateway shutdown complete")


# Create FastAPI application with lifespan
app = FastAPI(
    title=f"{settings.app_name} (Gateway)",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    swagger_ui_parameters={
    "docExpansion": "none"},
)

# ==============================================================================
# Token Limit Exception catcher helper below - TokenLimitExceededException
# ==============================================================================

@app.exception_handler(TokenLimitExceededException)
async def token_limit_exception_handler(
    request: Request,
    exc: TokenLimitExceededException,
):
    """
    Global handler for token governance violations.

    Converts TokenLimitExceededException into a
    consistent API response across all EchoAI features.
    """

    logger.warning(
        "[TOKEN GOVERNANCE] request blocked "
        "path=%s limit_type=%s usage=%s limit=%s",
        request.url.path,
        exc.limit_type,
        exc.current_usage,
        exc.limit_value,
    )

    return JSONResponse(
        status_code=429,
        content={
            "error": "TOKEN_LIMIT_EXCEEDED",
            "limit_type": exc.limit_type,
            "message": exc.message,
            "current_usage": exc.current_usage,
            "limit": exc.limit_value,
        },
    )
# ==============================================================================
# Middleware Configuration
# ==============================================================================

# CORS middleware - restrict to configured trusted origins and necessary methods/headers.
# Auth endpoints require credentials support and specific method/header allowlists for security.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allowed_origins_list,
    allow_credentials=True,
    # Restrict to common HTTP methods; auth flows use GET (callback), POST (login), OPTIONS (preflight)
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"],
    # Restrict to necessary headers; disallow dangerous custom headers by default.
    allow_headers=[
        "Accept",
        "Accept-Encoding",
        "Accept-Language",
        "Authorization",
        "Content-Type",
        "DNT",
        "Origin",
        "User-Agent",
        "X-Forwarded-For",
        "X-Forwarded-Proto",
        "X-Forwarded-Host",
        "X-Request-ID",
    ],
)

# Auth middleware - extracts user from JWT and attaches to request.state
app.add_middleware(AuthMiddleware)

# Mount static directory to serve uploaded logos (e.g., /static/logos/<file>.png)
app.mount("/static", StaticFiles(directory="static"), name="static")


# Tool System Logging Middleware
@app.middleware("http")
async def log_tool_operations(request: Request, call_next):
    """
    Middleware to log all tool-related operations for debugging and monitoring.
    Logs: discovery, invocation, registration, deletion, and errors.
    """
    start_time = time.time()
    path = request.url.path
    method = request.method

    # Check if this is a tool-related request
    is_tool_request = path.startswith("/tools")
    is_sso_request = path.startswith("/sessions/sso/")

    if is_sso_request:
        forwarded_for = request.headers.get("x-forwarded-for", "")
        user_agent = request.headers.get("user-agent", "")[:120]
        logger.info(f"SSO Request: {method} {path} | ip={forwarded_for} | ua={user_agent}")

    if is_tool_request:
        logger.info(f"Tool Request: {method} {path}")

        # Log request details for specific operations
        if "/tools/discover" in path:
            logger.info("Tool Discovery initiated")
        elif "/tools/invoke" in path:
            tool_identifier = path.split("/")[-1] if "/" in path else "unknown"
            logger.info(f"Tool Invocation: {tool_identifier}")
        elif "/tools/list" in path:
            logger.info("Listing all registered tools")
        elif method == "POST" and path == "/tools/register":
            logger.info("Tool Registration request")
        elif method == "DELETE":
            tool_id = path.split("/")[-1]
            logger.info(f"Tool Deletion request: {tool_id}")

    # Process request
    try:
        response = await call_next(request)

        # Log completion with execution time
        if is_sso_request:
            duration = (time.time() - start_time) * 1000
            status = response.status_code
            level = "info" if status < 400 else ("warning" if status < 500 else "error")
            getattr(logger, level)(
                f"SSO Request completed: {method} {path} | "
                f"status={status} | duration={duration:.0f}ms"
            )

        if is_tool_request:
            duration = (time.time() - start_time) * 1000  # Convert to ms
            status = response.status_code

            if status >= 200 and status < 300:
                logger.info(
                    f"Tool Request completed: {method} {path} - "
                    f"Status: {status} - Duration: {duration:.2f}ms"
                )
            elif status >= 400 and status < 500:
                logger.warning(
                    f"Tool Request client error: {method} {path} - "
                    f"Status: {status} - Duration: {duration:.2f}ms"
                )
            elif status >= 500:
                logger.error(
                    f"Tool Request server error: {method} {path} - "
                    f"Status: {status} - Duration: {duration:.2f}ms"
                )

        return response

    except Exception as e:
        duration = (time.time() - start_time) * 1000
        logger.error(
            f"Tool Request exception: {method} {path} - "
            f"Error: {str(e)} - Duration: {duration:.2f}ms"
        )
        raise


@app.middleware("http")
async def remove_server_header(request: Request, call_next):
    return await remove_server_header_middleware(request, call_next)


# ==============================================================================
# Health Check
# ==============================================================================


@app.get("/healthz")
@app.get("/api/health")
async def healthz():
    """
    Health check endpoint.

    Returns:
        Status and service mode.
    """
    return {
        "status": "ok",
        "mode": settings.service_mode,
        "auth_enforcement": settings.auth_enforcement,
    }


@app.get("/health/db")
async def health_db():
    """
    Database health check.

    Tests database connectivity by executing a simple query.
    """
    from echolib.database import get_db_session
    from sqlalchemy import text

    try:
        async with get_db_session() as db:
            result = await db.execute(text("SELECT 1"))
            _ = result.scalar()
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        return {"status": "error", "database": str(e)}


@app.get("/health/cache")
async def health_cache():
    """
    Cache health check.

    Tests Memcached connectivity by performing a test set/get operation.
    """
    from echolib.cache import cache_client

    response = {
        "status": "ok" if cache_client.is_available else "unavailable",
        "cache_enabled": settings.memcached_enabled,
        "cache_available": cache_client.is_available,
        "hosts": settings.memcached_hosts if settings.memcached_enabled else None,
        "ttl_seconds": settings.memcached_ttl if settings.memcached_enabled else None,
    }

    # If cache is available, test it with a ping
    if cache_client.is_available:
        test_key = "health_check_test"
        test_value = {"test": "ping", "timestamp": time.time()}
        set_result = await cache_client.set(test_key, test_value, ttl=10)
        get_result = await cache_client.get(test_key)
        await cache_client.delete(test_key)

        response["test_set"] = "ok" if set_result else "failed"
        response["test_get"] = "ok" if get_result else "failed"

    return response


@app.get("/health/observability")
async def health_observability():
    """
    Observability health check.

    Checks that OTel is initialized and reports status.
    """
    try:
        from opentelemetry import trace, metrics
        tp = trace.get_tracer_provider()
        mp = metrics.get_meter_provider()
        tp_name = type(tp).__name__
        mp_name = type(mp).__name__
        return {
            "status": "ok",
            "tracer_provider": tp_name,
            "meter_provider": mp_name,
            "otel_enabled": settings.OTEL_ENABLED,
            "otel_collector_enabled": settings.OTEL_COLLECTOR_ENABLED,
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


@app.get("/metrics")
async def prometheus_metrics():
    """
    Prometheus-compatible metrics scrape endpoint.

    Returns metrics in Prometheus exposition format if the
    opentelemetry-exporter-prometheus reader is active.
    Falls back to a JSON summary from the in-process collector.
    """
    try:
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        from fastapi.responses import Response
        return Response(
            content=generate_latest(),
            media_type=CONTENT_TYPE_LATEST,
        )
    except ImportError:
        # Prometheus client not installed â€” return JSON from collector
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_overview()



# ==============================================================================
# Router Registration
# ==============================================================================
app.include_router(convobi_router, prefix="/convobi")
app.include_router(session_router)
app.include_router(rag_router)
app.include_router(llm_router)
app.include_router(tool_router)
app.include_router(agentic_app_router)
app.include_router(app_router)
app.include_router(app_lookup_router)
app.include_router(app_skills_router)
app.include_router(llm_config_router)
app.include_router(wf_router)
app.include_router(agent_router)
app.include_router(conn_router)
app.include_router(marketplace_router)
app.include_router(chat_router)
app.include_router(workbench_router, prefix="/api")
# app.include_router(llm_workbench_router)
if analytics_router is not None:
    app.include_router(analytics_router)
else:
    logger.warning("Skipping analytics router registration: %s", analytics_router_import_error)
app.include_router(knowledge_router)
app.include_router(user_mgmt_router)
app.include_router(notifications_router)
app.include_router(agent_trust_router)

# ---------------------------------------------------------------------------
# OpenAPI schema patcher — fix file upload fields so Swagger shows a file
# picker instead of a plain text input.
#
# FastAPI serialises List[UploadFile] = File(...) as  { type: array,
# items: { type: string } }  in the OpenAPI JSON.  Swagger UI needs
# items.format == "binary" to render the file chooser widget.
# We also handle the single-file case (type: string without format: binary)
# and allOf / $ref wrappers that newer FastAPI versions emit.
# ---------------------------------------------------------------------------
from fastapi.openapi.utils import get_openapi as _get_openapi


def _fix_file_props(properties: dict) -> None:
    """Mutate *properties* dict in-place: string→binary for file fields."""
    for prop_name, prop_val in properties.items():
        if not isinstance(prop_val, dict):
            continue
        # Array of files:  { type: array, items: { type: string } }
        if prop_val.get("type") == "array":
            items = prop_val.get("items", {})
            if items.get("type") == "string" and items.get("format") != "binary":
                items["format"] = "binary"
        # Single file:  { type: string }  (no format)
        elif (
            prop_val.get("type") == "string"
            and prop_val.get("format") not in ("binary", "date", "date-time", "email", "uri", "uuid", "password")
        ):
            # Only patch fields whose name hints at a file upload
            lower = prop_name.lower()
            if lower in ("file", "files") or "upload" in lower:
                prop_val["format"] = "binary"


def _resolve_schema(schema_node: dict, components: dict) -> dict:
    """Follow a single $ref or allOf wrapper and return the concrete schema dict."""
    if "$ref" in schema_node:
        ref_path = schema_node["$ref"]  # e.g. "#/components/schemas/Body_create..."
        parts = ref_path.lstrip("#/").split("/")
        target = components
        for p in parts[1:]:  # skip "components"
            target = target.get(p, {})
        return target
    if "allOf" in schema_node:
        for sub in schema_node["allOf"]:
            resolved = _resolve_schema(sub, components)
            if resolved:
                return resolved
    return schema_node


def _custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    schema = _get_openapi(
        title=app.title,
        version=app.version,
        description=app.description or "",
        routes=app.routes,
    )

    components = schema.get("components", {})

    # 1. Patch component schemas (covers $ref-based references)
    for _schema_name, schema_obj in components.get("schemas", {}).items():
        props = schema_obj.get("properties", {})
        if props:
            _fix_file_props(props)

    # 2. Patch inline path schemas (multipart/form-data request bodies)
    for _path, path_item in schema.get("paths", {}).items():
        for _method, operation in path_item.items():
            if not isinstance(operation, dict):
                continue
            content = operation.get("requestBody", {}).get("content", {})
            for media_type, media_obj in content.items():
                if "multipart/form-data" not in media_type:
                    continue
                raw_schema = media_obj.get("schema", {})
                resolved = _resolve_schema(raw_schema, components)
                props = resolved.get("properties", {})
                if props:
                    _fix_file_props(props)

    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = _custom_openapi


# ==============================================================================
# WebSocket Endpoint for Execution Transparency
# ==============================================================================


@app.websocket("/ws/execution/{run_id}")
async def websocket_execution(websocket: WebSocket, run_id: str):
    """
    WebSocket endpoint for real-time execution transparency.

    Clients connect to receive step-level events during workflow execution.
    Events include: run_started, step_started, step_completed, step_failed,
    run_completed, run_failed.

    Args:
        websocket: WebSocket connection
        run_id: Run identifier to subscribe to

    Usage:
        1. POST /workflows/chat/send returns run_id immediately
        2. Client connects to ws://host/ws/execution/{run_id}
        3. Client receives events as workflow executes
        4. Connection closes after run_completed/run_failed
    """
    from apps.workflow.runtime.ws_manager import ws_manager

    await ws_manager.connect(run_id, websocket)
    try:
        # Keep-alive loop - wait for messages or disconnect
        while True:
            # receive_text() will raise WebSocketDisconnect on client disconnect
            await websocket.receive_text()
    except WebSocketDisconnect:
        await ws_manager.disconnect(run_id, websocket)
        logger.info(f"WebSocket client disconnected from run {run_id}")



