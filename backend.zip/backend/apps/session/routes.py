"""
EchoAI Session API Routes

Provides CRUD operations for chat sessions with:
- Embedded messages (JSONB)
- Memcached caching with PostgreSQL fallback
- Tool selection per session
- Tool configuration overrides

Routes:
    POST /sessions/login - Dev login (create token + refresh token)
    POST /sessions/refresh - Exchange refresh token for new token pair
    GET /sessions/me - Get current user info
    POST /sessions/logout - Invalidate session + revoke refresh tokens

    GET /sessions - List user's chat sessions
    POST /sessions - Create new session
    GET /sessions/{id} - Get session with embedded messages
    DELETE /sessions/{id} - Soft delete session
    PATCH /sessions/{id}/title - Update session title
    POST /sessions/{id}/tools - Set selected tools for session
    PUT /sessions/{id}/tools/{tool_id}/config - Set tool config override
    DELETE /sessions/{id}/tools/{tool_id}/config - Remove tool config override

    POST /sessions/{id}/messages - Add message to session
    GET /sessions/{id}/messages - Get session messages
"""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
from starlette.responses import JSONResponse, StreamingResponse
from sqlalchemy import func, select, update

from echolib.config import settings
from echolib.di import container
from echolib.security import (
    get_current_user,
    require_user,
    create_token,
    create_refresh_token,
    hash_refresh_token,
    resolve_user_id,
)
from echolib.types import UserContext
from echolib.database import get_db_session
from echolib.models.refresh_token import RefreshToken
from echolib.models.user import User
from echolib.repositories.session_repo import SessionRepository
from echolib.repositories.session_tool_config_repo import SessionToolConfigRepository
from echolib.service.pdf_export import generate_chat_pdf
from echolib.repositories.base import (
    DEFAULT_USER_ID,
    DEFAULT_USER_EMAIL,
    is_valid_uuid,
    safe_uuid,
)

import jwt                           # For decoding Microsoft id_token
import httpx                          # For async HTTP calls to Microsoft token endpoint
from urllib.parse import urlencode    # For proper URL encoding of query params
import time as _time                  # For SSO state expiry tracking
import uuid as _uuid                  # For SSO request correlation IDs


def _get_sso_config() -> dict:
    """
    Resolve SSO configuration at request time.

    The global ``settings`` singleton is created once at import time.
    On Azure App Service, environment variables may not be fully injected
    into the process before the first import of echolib.config.  This
    helper falls back to ``os.getenv()`` when the frozen settings values
    are empty, ensuring SSO works even if env vars arrive after startup.
    """
    import os
    return {
        "tenant_id": settings.sso_tenant_id or os.getenv("SSO_TENANT_ID", ""),
        "client_id": settings.sso_client_id or os.getenv("SSO_CLIENT_ID", ""),
        "client_secret": settings.sso_client_secret or os.getenv("SSO_CLIENT_SECRET", ""),
        "redirect_uri": settings.sso_redirect_uri or os.getenv("SSO_REDIRECT_URI", ""),
        "scopes": settings.sso_scopes or os.getenv("SSO_SCOPES", "openid profile email"),
    }

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sessions", tags=["SessionApi"])

_AUTH_SESSION_ID_METADATA_KEY = "auth_session_id"


# ==============================================================================
# Pydantic Models for Request/Response
# ==============================================================================


class CreateSessionRequest(BaseModel):
    """Request to create a new chat session."""

    title: Optional[str] = Field(default="New Chat", max_length=255)
    context_type: str = Field(
        default="general",
        description="Session context type: general, workflow, agent, workflow_design",
    )
    context_id: Optional[str] = Field(
        default=None, description="UUID of workflow or agent for context binding"
    )
    workflow_mode: Optional[str] = Field(
        default=None, description="For workflow contexts: draft, test, final"
    )
    workflow_version: Optional[str] = Field(default=None)
    initial_context: Optional[Dict[str, Any]] = Field(default_factory=dict)
    state_schema: Optional[Dict[str, Any]] = Field(default_factory=dict)
    variables: Optional[Dict[str, Any]] = Field(default_factory=dict)


class UpdateTitleRequest(BaseModel):
    """Request to update session title."""

    title: str = Field(..., min_length=1, max_length=255)


class SetToolsRequest(BaseModel):
    """Request to set selected tools for session."""

    tool_ids: List[str] = Field(default_factory=list)


class ToolConfigRequest(BaseModel):
    """Request to set tool configuration override."""

    config: Dict[str, Any] = Field(default_factory=dict)


class AddMessageRequest(BaseModel):
    """Request to add a message to session."""

    role: str = Field(..., description="Message role: user, assistant, system")
    content: str = Field(..., min_length=1)
    agent_id: Optional[str] = Field(default=None)
    run_id: Optional[str] = Field(default=None)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class SessionSummary(BaseModel):
    """Session summary for list responses."""

    session_id: str
    title: str
    context_type: str
    context_id: Optional[str]
    workflow_mode: Optional[str]
    message_count: int
    created_at: str
    last_activity: str


class SessionDetail(BaseModel):
    """Full session detail with messages."""

    session_id: str
    user_id: str
    title: str
    context_type: str
    context_id: Optional[str]
    workflow_mode: Optional[str]
    workflow_version: Optional[str]
    messages: List[Dict[str, Any]]
    selected_tool_ids: List[str]
    context_data: Dict[str, Any]
    variables: Dict[str, Any]
    state_schema: Dict[str, Any]
    run_ids: List[str]
    created_at: str
    last_activity: str


# ==============================================================================
# Repository Helpers
# ==============================================================================


def get_session_repo() -> SessionRepository:
    """Get session repository instance."""
    return SessionRepository()


def get_tool_config_repo() -> SessionToolConfigRepository:
    """Get session tool config repository instance."""
    return SessionToolConfigRepository()


def _set_auth_cookies(response: JSONResponse, access_token: str, refresh_token: str) -> None:
    """Set secure access/refresh cookies using centralized security settings."""
    for cookie_name in settings.auth_access_cookie_names:
        response.set_cookie(
            key=cookie_name,
            value=access_token,
            max_age=settings.auth_access_cookie_max_age_seconds,
            **settings.auth_cookie_common_kwargs,
        )
    response.set_cookie(
        key=settings.auth_refresh_cookie_name,
        value=refresh_token,
        max_age=settings.auth_refresh_cookie_max_age_seconds,
        **settings.auth_cookie_common_kwargs,
    )


def _clear_auth_cookies(response: JSONResponse) -> None:
    """Clear auth cookies with matching cookie attributes."""
    for cookie_name in settings.auth_access_cookie_names:
        response.delete_cookie(
            key=cookie_name,
            **settings.auth_cookie_common_kwargs,
        )
    response.delete_cookie(
        key=settings.auth_refresh_cookie_name,
        **settings.auth_cookie_common_kwargs,
    )


def _build_auth_response(payload: Dict[str, Any]) -> JSONResponse:
    """Return JSON payload and attach secure auth cookies."""
    response = JSONResponse(content=payload)
    _set_auth_cookies(
        response=response,
        access_token=payload["token"],
        refresh_token=payload["refresh_token"],
    )
    return response


def _create_auth_session(user_id: str, email: str) -> tuple[Optional[Dict[str, Any]], str]:
    """Create the canonical auth session id used by login and refresh."""
    session_data = None
    session_id = None

    try:
        store = container.resolve("session.store")
        session = store.createSession(user_id, {"email": email})
        session_data = session.model_dump()
        session_id = session_data.get("session_id") or session_data.get("id")
    except Exception:
        pass

    if not session_id:
        session_id = str(uuid4())

    return session_data, session_id


def _get_auth_session_id(user: User) -> Optional[str]:
    """Read the persisted auth session id from user metadata."""
    user_metadata = user.user_metadata if isinstance(user.user_metadata, dict) else {}
    session_id = user_metadata.get(_AUTH_SESSION_ID_METADATA_KEY)
    if isinstance(session_id, str) and session_id.strip():
        return session_id
    return None


def _set_auth_session_id(user: User, session_id: str) -> None:
    """Persist the canonical auth session id so refresh can reproduce login."""
    user_metadata = user.user_metadata if isinstance(user.user_metadata, dict) else {}
    user.user_metadata = {
        **user_metadata,
        _AUTH_SESSION_ID_METADATA_KEY: session_id,
    }


# ==============================================================================
# Legacy Auth Routes (Backward Compatibility)
# ==============================================================================


async def _login_by_email(email: str) -> dict:
    """
    Shared login logic: look up or create user by email, issue JWT + refresh token.

    Used by both POST /sessions/login and GET /sessions/sso/callback.

    Args:
        email: User's email address.

    Returns:
        dict with token, refresh_token, user_id, email, display_name, session_id,
        and optionally 'session' if the in-memory session store is active.
    """
    from datetime import datetime as _dt, timezone as _tz

    session_data = None
    session_id = None

    async with get_db_session() as db:
        # 1. Look up existing user by email (case-insensitive, including inactive)
        result = await db.execute(
            select(User).where(
                func.lower(User.email) == email.lower().strip(),
            )
        )
        existing_user = result.scalar_one_or_none()
        user_record = existing_user

        if existing_user:
            # Reject deactivated users
            if not existing_user.is_active:
                raise HTTPException(
                    status_code=403,
                    detail="Your account has been deactivated. Please contact an administrator.",
                )
            existing_user.last_login_at = _dt.now(_tz.utc).replace(tzinfo=None)
            await db.flush()
            user_id = str(existing_user.user_id)
            user_uuid = existing_user.user_id
            display_name = existing_user.display_name or email.split("@")[0]
            # Role resolution: bootstrap mode uses config, normal mode uses DB
            if settings.rbac_bootstrap_mode:
                role = settings.resolve_role_for_email(email)
                if existing_user.role != role:
                    existing_user.role = role
                    await db.flush()
            else:
                role = existing_user.role
            logger.info(f"Existing user logged in: {email} (user_id={user_id}, role={role})")
        else:
            if email.lower().strip() == DEFAULT_USER_EMAIL.lower():
                new_uuid = UUID(DEFAULT_USER_ID) if not isinstance(DEFAULT_USER_ID, UUID) else DEFAULT_USER_ID
            else:
                new_uuid = uuid4()
            display_name = email.split("@")[0]
            # Bootstrap mode: resolve from config. Normal mode: default to "user".
            if settings.rbac_bootstrap_mode:
                role = settings.resolve_role_for_email(email)
            else:
                role = "user"
            new_user = User(
                user_id=new_uuid,
                email=email.lower().strip(),
                display_name=display_name,
                last_login_at=_dt.now(_tz.utc).replace(tzinfo=None),
                user_metadata={},
                is_active=True,
                role=role,
            )
            db.add(new_user)
            await db.flush()
            user_id = str(new_uuid)
            user_uuid = new_uuid
            user_record = new_user
            logger.info(f"New user created: {email} (user_id={user_id}, role={role})")

        session_data, session_id = _create_auth_session(user_id, email)
        _set_auth_session_id(user_record, session_id)
        await db.flush()

        # Create JWT access token (includes role claim)
        tok = create_token(user_id, email, role=role)

        # Revoke all existing active refresh tokens
        await db.execute(
            update(RefreshToken)
            .where(
                RefreshToken.user_id == user_uuid,
                RefreshToken.is_revoked == False,  # noqa: E712
            )
            .values(is_revoked=True)
        )

        # Create new refresh token
        raw_refresh, token_hash = create_refresh_token(user_id, email)
        rt = RefreshToken(
            user_id=user_uuid,
            token_hash=token_hash,
            expires_at=datetime.now(timezone.utc) + timedelta(
                days=settings.refresh_token_expire_days,
            ),
            is_revoked=False,
        )
        db.add(rt)
        await db.flush()

    response = {
        "token": tok,
        "refresh_token": raw_refresh,
        "user_id": user_id,
        "email": email,
        "display_name": display_name,
        "role": role,
        "session_id": session_id,
    }
    if session_data:
        response["session"] = session_data
    return response


@router.post("/login")
async def login(email: str):
    """
    Dev login endpoint -- creates or retrieves a user, then returns a JWT
    **and** a refresh token.

    In production, this will be replaced by Microsoft Entra ID (OAuth/OIDC).
    """
    payload = await _login_by_email(email)
    return _build_auth_response(payload)


@router.post("/refresh")
async def refresh_access_token(request: Request, payload: Dict[str, Any]):
    """
    Exchange a valid refresh token for a new access token and a new refresh
    token (token rotation).

    The old refresh token is revoked immediately upon use.  If an already-
    revoked token is presented the request is rejected, preventing replay
    attacks.

    This endpoint does **not** require ``require_user`` because the caller's
    access token is expected to have expired -- that is the whole reason they
    are calling this endpoint.
    """
    raw_refresh = payload.get("refresh_token")
    if not raw_refresh:
        raw_refresh = request.cookies.get(settings.auth_refresh_cookie_name)
    if not raw_refresh:
        raise HTTPException(status_code=401, detail="Refresh token required")

    token_hash_value = hash_refresh_token(raw_refresh)

    async with get_db_session() as db:
        # 1. Look up the refresh token by hash
        result = await db.execute(
            select(RefreshToken).where(
                RefreshToken.token_hash == token_hash_value,
                RefreshToken.is_revoked == False,  # noqa: E712
            )
        )
        stored_token = result.scalar_one_or_none()

        if not stored_token:
            raise HTTPException(status_code=401, detail="Invalid refresh token")

        # 2. Check expiry
        stored_expires = stored_token.expires_at
        if stored_expires.tzinfo is None:
            stored_expires = stored_expires.replace(tzinfo=timezone.utc)
        if stored_expires < datetime.now(timezone.utc):
            stored_token.is_revoked = True
            await db.flush()
            raise HTTPException(status_code=401, detail="Refresh token expired")

        # 3. Revoke old refresh token (rotation)
        stored_token.is_revoked = True
        await db.flush()

        # 4. Look up the user to get email / active status
        user_result = await db.execute(
            select(User).where(
                User.user_id == stored_token.user_id,
                User.is_active == True,  # noqa: E712
            )
        )
        user = user_result.scalar_one_or_none()

        if not user:
            raise HTTPException(status_code=401, detail="User not found or deactivated")

        user_id = str(user.user_id)
        email = user.email
        display_name = user.display_name or email.split("@")[0]
        role = user.role
        session_id = _get_auth_session_id(user)
        if not session_id:
            session_id = str(uuid4())
            _set_auth_session_id(user, session_id)
            await db.flush()

        # 5. Issue new access token (re-read role from DB for freshness)
        new_access = create_token(user_id, email, role=role)

        # 6. Issue new refresh token (rotation)
        new_raw_refresh, new_hash = create_refresh_token(user_id, email)
        new_rt = RefreshToken(
            user_id=user.user_id,
            token_hash=new_hash,
            expires_at=datetime.now(timezone.utc) + timedelta(
                days=settings.refresh_token_expire_days,
            ),
            is_revoked=False,
        )
        db.add(new_rt)
        await db.flush()

    response_payload = {
        "token": new_access,
        "refresh_token": new_raw_refresh,
        "user_id": user_id,
        "email": email,
        "display_name": display_name,
        "role": role,
        "session_id": session_id,
    }
    return _build_auth_response(response_payload)


@router.get("/me")
async def me(user: UserContext = Depends(require_user)):
    """Get current user info including role."""
    return user.model_dump()


@router.post("/logout")
async def logout(
    session_id: str,
    user: Optional[UserContext] = Depends(get_current_user),
):
    """
    Invalidate session and revoke all refresh tokens for the user.

    The ``session_id`` parameter invalidates the in-memory session store
    entry (legacy behaviour).  If a valid JWT is provided in the
    Authorization header the endpoint also revokes every refresh token
    belonging to the authenticated user.
    """
    # Legacy: invalidate in-memory session store
    try:
        store = container.resolve("session.store")
        store.invalidateSession(session_id)
    except Exception:
        pass  # Session store not configured -- acceptable

    # Revoke all refresh tokens for the authenticated user (if known)
    if user and user.user_id and is_valid_uuid(user.user_id):
        user_uuid = safe_uuid(user.user_id)
        if user_uuid:
            try:
                async with get_db_session() as db:
                    await db.execute(
                        update(RefreshToken)
                        .where(
                            RefreshToken.user_id == user_uuid,
                            RefreshToken.is_revoked == False,  # noqa: E712
                        )
                        .values(is_revoked=True)
                    )
                logger.info(
                    f"Revoked all refresh tokens for user_id={user.user_id}"
                )
            except Exception:
                logger.warning(
                    "Failed to revoke refresh tokens during logout",
                    exc_info=True,
                )

    response = JSONResponse(content={"ok": True, "session_id": session_id})
    _clear_auth_cookies(response)
    return response


# ==============================================================================
# SSO Helpers (Microsoft Entra ID)
# ==============================================================================

# In-memory CSRF state store for SSO flows.
# Key: state_token, Value: {"expires_at": <unix_timestamp>}
# In production, use Memcached or Redis for multi-instance deployments.
_sso_states: Dict[str, Dict[str, Any]] = {}

# Cleanup stale states periodically (max 1000 entries before forced prune)
_SSO_STATE_TTL_SECONDS = 600  # 10 minutes


def _cleanup_expired_sso_states() -> None:
    """Remove expired SSO state entries to prevent memory leak."""
    now = _time.time()
    expired = [k for k, v in _sso_states.items() if now > v.get("expires_at", 0)]
    for k in expired:
        del _sso_states[k]


async def _exchange_code_for_tokens(code: str, correlation_id: str = "") -> dict:
    """
    Exchange Microsoft authorization code for access/id tokens.

    Makes a POST request to Microsoft's token endpoint.

    Args:
        code: Authorization code from Microsoft redirect.
        correlation_id: Request correlation ID for log tracing.

    Returns:
        Token response dict containing access_token, id_token, etc.

    Raises:
        HTTPException: If token exchange fails or network error occurs.
    """
    sso = _get_sso_config()
    token_url = f"https://login.microsoftonline.com/{sso['tenant_id']}/oauth2/v2.0/token"

    payload = {
        "client_id": sso["client_id"],
        "client_secret": sso["client_secret"],
        "code": code,
        "redirect_uri": sso["redirect_uri"],
        "grant_type": "authorization_code",
        "scope": sso["scopes"],
    }

    logger.info(f"[SSO {correlation_id}] Exchanging code with Microsoft (redirect_uri={sso['redirect_uri']})")

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                token_url,
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
    except httpx.TimeoutException:
        logger.error(f"[SSO {correlation_id}] Token exchange timed out after 30s")
        raise HTTPException(status_code=502, detail="SSO token exchange timed out — Microsoft endpoint unreachable")
    except httpx.RequestError as e:
        logger.error(f"[SSO {correlation_id}] Token exchange network error: {type(e).__name__}: {e}")
        raise HTTPException(status_code=502, detail=f"SSO token exchange network error: {type(e).__name__}")

    if response.status_code != 200:
        try:
            error_data = response.json()
        except Exception:
            error_data = {}
        error_msg = error_data.get("error_description", error_data.get("error", "Token exchange failed"))
        logger.error(
            f"[SSO {correlation_id}] Token exchange failed | "
            f"HTTP {response.status_code} | error={error_data.get('error', 'unknown')} | "
            f"description={error_msg}"
        )
        raise HTTPException(status_code=400, detail=f"SSO token exchange failed: {error_msg}")

    token_data = response.json()

    if "id_token" not in token_data:
        logger.error(f"[SSO {correlation_id}] Token response missing id_token. Keys: {list(token_data.keys())}")
        raise HTTPException(status_code=400, detail="SSO token response missing id_token")

    return token_data


def _extract_email_from_id_token(token_data: dict, correlation_id: str = "") -> str:
    """
    Extract user email from Microsoft's id_token.

    Attempts JWKS-based signature verification first using Microsoft's
    public keys endpoint. Falls back to unverified decode if JWKS
    validation fails (e.g. network issues during key fetch).

    Email is extracted from (in priority order):
    1. 'email' claim
    2. 'preferred_username' claim

    Args:
        token_data: Token response from Microsoft's token endpoint.
        correlation_id: Request correlation ID for log tracing.

    Returns:
        User email address.

    Raises:
        HTTPException: If email cannot be extracted.
    """
    id_token_str = token_data.get("id_token", "")

    claims = None

    # Attempt JWKS-based signature verification
    try:
        claims = _verify_id_token_with_jwks(id_token_str)
        logger.info(f"[SSO {correlation_id}] id_token verified via JWKS")
    except Exception as e:
        logger.warning(f"[SSO {correlation_id}] JWKS verification failed, falling back to unverified decode: {e}")

    # Fallback: decode without verification (token came from Microsoft HTTPS endpoint)
    if claims is None:
        try:
            claims = jwt.decode(
                id_token_str,
                options={"verify_signature": False},
                algorithms=["RS256"],
            )
        except jwt.InvalidTokenError as e:
            logger.error(f"[SSO {correlation_id}] id_token decode failed: {e}")
            raise HTTPException(status_code=400, detail="Failed to decode SSO id_token")

    # Extract email from claims (priority: email > preferred_username)
    email = claims.get("email") or claims.get("preferred_username")

    if not email:
        logger.error(f"[SSO {correlation_id}] id_token missing email claim. Available claims: {list(claims.keys())}")
        raise HTTPException(status_code=400, detail="SSO token does not contain user email")

    logger.info(f"[SSO {correlation_id}] Email extracted: {email}")
    return email.lower().strip()


# JWKS cache for Microsoft's public signing keys
_jwks_cache: Optional[dict] = None
_jwks_cache_time: float = 0.0
_JWKS_CACHE_TTL = 3600  # 1 hour


def _get_microsoft_jwks() -> dict:
    """Fetch and cache Microsoft Entra ID JWKS keys."""
    import time as _t
    global _jwks_cache, _jwks_cache_time

    if _jwks_cache and (_t.time() - _jwks_cache_time) < _JWKS_CACHE_TTL:
        return _jwks_cache

    import httpx
    sso = _get_sso_config()
    jwks_url = f"https://login.microsoftonline.com/{sso['tenant_id']}/discovery/v2.0/keys"
    resp = httpx.get(jwks_url, timeout=10)
    resp.raise_for_status()
    _jwks_cache = resp.json()
    _jwks_cache_time = _t.time()
    return _jwks_cache


def _verify_id_token_with_jwks(id_token_str: str) -> dict:
    """Verify and decode id_token using Microsoft JWKS public keys."""
    from jwt.algorithms import RSAAlgorithm

    # Get the key ID from the token header
    unverified_header = jwt.get_unverified_header(id_token_str)
    kid = unverified_header.get("kid")
    if not kid:
        raise ValueError("id_token header missing 'kid'")

    # Fetch JWKS and find matching key
    jwks = _get_microsoft_jwks()
    matching_key = None
    for key in jwks.get("keys", []):
        if key.get("kid") == kid:
            matching_key = key
            break

    if not matching_key:
        raise ValueError(f"No matching JWKS key found for kid={kid}")

    # Build RSA public key and verify
    public_key = RSAAlgorithm.from_jwk(matching_key)
    sso = _get_sso_config()
    claims = jwt.decode(
        id_token_str,
        public_key,
        algorithms=["RS256"],
        audience=sso["client_id"],
        options={"verify_exp": True},
    )
    return claims


# ==============================================================================
# SSO Endpoints (MUST come before /{session_id} catch-all routes)
# ==============================================================================


@router.get("/sso/login")
async def sso_login():
    """
    Initiate SSO login by returning the Microsoft Entra ID authorization URL.

    Generates a CSRF state token (stored in-memory with 10-min TTL) and
    builds a properly-encoded authorization URL.

    Returns:
        dict with authorization_url and state token.
    """
    if not settings.sso_enabled:
        raise HTTPException(status_code=404, detail="SSO is not enabled")

    import secrets as _secrets

    # Prune expired states before creating a new one
    _cleanup_expired_sso_states()

    # Generate + store CSRF state token
    state = _secrets.token_urlsafe(32)
    _sso_states[state] = {"expires_at": _time.time() + _SSO_STATE_TTL_SECONDS}

    sso = _get_sso_config()

    params = {
        "client_id": sso["client_id"],
        "response_type": "code",
        "redirect_uri": sso["redirect_uri"],
        "response_mode": "query",
        "scope": sso["scopes"],
        "state": state,
    }

    base_url = f"https://login.microsoftonline.com/{sso['tenant_id']}/oauth2/v2.0/authorize"
    authorization_url = f"{base_url}?{urlencode(params)}"

    return {
        "authorization_url": authorization_url,
        "state": state,
    }


@router.get("/sso/callback")
async def sso_callback(
    code: Optional[str] = None,
    state: Optional[str] = None,
    error: Optional[str] = None,
    error_description: Optional[str] = None,
):
    """
    SSO callback endpoint for Microsoft Entra ID OAuth2 Authorization Code Flow.

    Microsoft redirects here after user authenticates. This endpoint:
    1. Validates no error from Microsoft
    2. Validates CSRF state token
    3. Exchanges authorization code for tokens
    4. Decodes id_token to extract user email
    5. Runs the same login logic as POST /sessions/login
    6. Returns the exact same response format

    Args:
        code: Authorization code from Microsoft.
        state: CSRF state token for validation.
        error: Error code from Microsoft (if auth failed).
        error_description: Human-readable error description.

    Returns:
        Same response as POST /sessions/login.
    """
    correlation_id = str(_uuid.uuid4())[:8]
    sso_start = _time.time()
    logger.info(
        f"[SSO {correlation_id}] Callback received | "
        f"code={'present' if code else 'absent'} | "
        f"state={'present' if state else 'absent'} | "
        f"error={error or 'none'}"
    )

    if not settings.sso_enabled:
        logger.warning(f"[SSO {correlation_id}] Rejected: SSO is not enabled")
        raise HTTPException(status_code=404, detail="SSO is not enabled")

    # Handle Microsoft error responses
    if error:
        logger.error(f"[SSO {correlation_id}] Microsoft auth error: {error} - {error_description}")
        raise HTTPException(
            status_code=400,
            detail=f"SSO authentication failed: {error_description or error}",
        )

    if not code:
        logger.warning(f"[SSO {correlation_id}] Missing authorization code")
        raise HTTPException(status_code=400, detail="Authorization code is required")

    # Validate CSRF state token
    if state:
        state_data = _sso_states.pop(state, None)
        if not state_data:
            logger.warning(f"[SSO {correlation_id}] Unknown/expired state token")
            raise HTTPException(status_code=400, detail="Invalid or expired SSO state token. Please try again.")
        if _time.time() > state_data.get("expires_at", 0):
            logger.warning(f"[SSO {correlation_id}] State token expired")
            raise HTTPException(status_code=400, detail="SSO state token expired. Please try again.")
        logger.info(f"[SSO {correlation_id}] State token validated")
    else:
        logger.warning(f"[SSO {correlation_id}] No state parameter (CSRF protection skipped)")

    # Exchange authorization code for tokens
    t0 = _time.time()
    token_data = await _exchange_code_for_tokens(code, correlation_id)
    logger.info(f"[SSO {correlation_id}] Token exchange completed in {(_time.time() - t0) * 1000:.0f}ms")

    # Extract email from id_token
    t1 = _time.time()
    email = _extract_email_from_id_token(token_data, correlation_id)
    logger.info(f"[SSO {correlation_id}] Email extraction completed in {(_time.time() - t1) * 1000:.0f}ms")

    # Reuse the EXACT same login logic as POST /sessions/login
    try:
        result = await _login_by_email(email)
        total_ms = (_time.time() - sso_start) * 1000
        logger.info(f"[SSO {correlation_id}] Login successful for {email} | total={total_ms:.0f}ms")
        return _build_auth_response(result)
    except HTTPException as e:
        logger.error(f"[SSO {correlation_id}] Login failed for {email}: {e.detail}")
        raise
    except Exception as e:
        logger.error(f"[SSO {correlation_id}] Unexpected error during login for {email}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An internal error occurred during SSO login.")


# ==============================================================================
# Session CRUD Routes
# ==============================================================================


@router.get("", response_model=Dict[str, Any])
async def list_sessions(
    context_type: Optional[str] = Query(
        default=None, description="Filter by context type"
    ),
    context_id: Optional[str] = Query(
        default=None, description="Filter by context ID"
    ),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    user: UserContext = Depends(get_current_user),
):
    """
    List user's chat sessions.

    Supports filtering by context_type and context_id for finding
    sessions bound to specific workflows or agents.
    """
    repo = get_session_repo()

    effective_user_id = resolve_user_id(user)

    async with get_db_session() as db:
        if context_type:
            sessions = await repo.list_by_context(
                db=db,
                user_id=effective_user_id,
                context_type=context_type,
                context_id=context_id,
                limit=limit,
                offset=offset,
            )
        else:
            sessions = await repo.list_by_user(
                db=db, user_id=effective_user_id, limit=limit, offset=offset
            )

        return {
            "sessions": [s.to_summary_dict() for s in sessions],
            "count": len(sessions),
            "limit": limit,
            "offset": offset,
        }


@router.post("", response_model=Dict[str, Any])
async def create_session(
    request: CreateSessionRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Create a new chat session.

    Session can be bound to different contexts:
    - general: Free-form chat (default)
    - workflow: Testing a specific workflow
    - agent: Direct chat with an agent
    - workflow_design: Iterating on workflow design
    """
    repo = get_session_repo()

    # Validate context_type
    valid_context_types = {"general", "workflow", "agent", "workflow_design"}
    if request.context_type not in valid_context_types:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid context_type. Must be one of: {valid_context_types}",
        )

    # Validate workflow_mode if provided
    if request.workflow_mode:
        valid_modes = {"draft", "test", "final"}
        if request.workflow_mode not in valid_modes:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid workflow_mode. Must be one of: {valid_modes}",
            )

    # Build session data
    session_data = {
        "title": request.title or "New Chat",
        "context_type": request.context_type,
        "context_id": UUID(request.context_id) if request.context_id else None,
        "workflow_mode": request.workflow_mode,
        "workflow_version": request.workflow_version,
        "context_data": request.initial_context or {},
        "state_schema": request.state_schema or {},
        "variables": request.variables or {},
        "messages": [],
        "selected_tool_ids": [],
        "run_ids": [],
    }

    # Resolve user ID (handles anonymous users)
    effective_user_id = resolve_user_id(user)

    async with get_db_session() as db:
        session = await repo.create(db=db, user_id=effective_user_id, data=session_data)

        # Add system message for workflow contexts
        if request.context_type == "workflow" and request.context_id:
            system_msg = {
                "id": f"msg_{uuid4().hex[:12]}",
                "role": "system",
                "content": f"Started testing workflow: {request.context_id}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "agent_id": None,
                "run_id": None,
                "metadata": {},
            }
            await repo.add_message(
                db=db,
                session_id=str(session.session_id),
                user_id=effective_user_id,
                message=system_msg,
            )
            # Refresh to get updated session
            session = await repo.get_by_id(
                db=db, session_id=str(session.session_id), user_id=effective_user_id
            )

        return {
            "session_id": str(session.session_id),
            "title": session.title,
            "context_type": session.context_type,
            "context_id": str(session.context_id) if session.context_id else None,
            "created_at": session.created_at.isoformat() if session.created_at else None,
            "message": "Session created successfully",
        }


@router.get("/{session_id}", response_model=Dict[str, Any])
async def get_session(
    session_id: str,
    user: UserContext = Depends(get_current_user),
):
    """
    Get session with embedded messages.

    Uses Memcached caching with PostgreSQL fallback.
    Cache key format: session:{session_id}
    """
    repo = get_session_repo()

    effective_user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Use dict version for efficient cache retrieval
        session_dict = await repo.get_by_id_dict(
            db=db, session_id=session_id, user_id=effective_user_id
        )

        if not session_dict:
            raise HTTPException(status_code=404, detail="Session not found")

        return session_dict


@router.delete("/{session_id}")
async def delete_session(
    session_id: str,
    user: UserContext = Depends(get_current_user),
):
    """
    Soft delete a session.

    Sets is_deleted=True and invalidates cache.
    """
    repo = get_session_repo()

    effective_user_id = resolve_user_id(user)

    async with get_db_session() as db:
        deleted = await repo.delete(db=db, id=session_id, user_id=effective_user_id)

        if not deleted:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "success": True,
            "session_id": session_id,
            "message": "Session deleted",
        }


@router.patch("/{session_id}/title")
async def update_session_title(
    session_id: str,
    request: UpdateTitleRequest,
    user: UserContext = Depends(get_current_user),
):
    """Update session title."""
    repo = get_session_repo()

    async with get_db_session() as db:
        session = await repo.update(
            db=db,
            id=session_id,
            user_id=resolve_user_id(user),
            updates={"title": request.title},
        )

        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "session_id": str(session.session_id),
            "title": session.title,
            "message": "Title updated",
        }


# ==============================================================================
# Tool Selection Routes
# ==============================================================================


@router.post("/{session_id}/tools")
async def set_session_tools(
    session_id: str,
    request: SetToolsRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Set selected tools for session.

    Replaces the current tool selection with the provided list.
    """
    repo = get_session_repo()

    async with get_db_session() as db:
        session = await repo.update_tools(
            db=db,
            session_id=session_id,
            user_id=resolve_user_id(user),
            tool_ids=request.tool_ids,
        )

        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "session_id": str(session.session_id),
            "selected_tool_ids": [str(tid) for tid in session.selected_tool_ids]
            if session.selected_tool_ids
            else [],
            "message": f"Selected {len(request.tool_ids)} tools",
        }


@router.put("/{session_id}/tools/{tool_id}/config")
async def set_tool_config(
    session_id: str,
    tool_id: str,
    request: ToolConfigRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Set tool configuration override for this session.

    Allows customizing tool behavior per-session without modifying
    the global tool definition.
    """
    session_repo = get_session_repo()
    config_repo = get_tool_config_repo()

    async with get_db_session() as db:
        # Verify session exists and belongs to user
        session = await session_repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Upsert tool config
        config = await config_repo.upsert_config(
            db=db,
            session_id=session_id,
            tool_id=tool_id,
            user_id=resolve_user_id(user),
            config=request.config,
        )

        return {
            "session_id": session_id,
            "tool_id": tool_id,
            "config": config.config_overrides if config else {},
            "message": "Tool config updated",
        }


@router.delete("/{session_id}/tools/{tool_id}/config")
async def delete_tool_config(
    session_id: str,
    tool_id: str,
    user: UserContext = Depends(get_current_user),
):
    """Remove tool configuration override for this session."""
    session_repo = get_session_repo()
    config_repo = get_tool_config_repo()

    async with get_db_session() as db:
        # Verify session exists and belongs to user
        session = await session_repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Delete config
        deleted = await config_repo.delete_config(
            db=db, session_id=session_id, tool_id=tool_id, user_id=resolve_user_id(user)
        )

        return {
            "session_id": session_id,
            "tool_id": tool_id,
            "deleted": deleted,
            "message": "Tool config removed" if deleted else "Config not found",
        }


@router.get("/{session_id}/tools/configs")
async def get_session_tool_configs(
    session_id: str,
    user: UserContext = Depends(get_current_user),
):
    """Get all tool configuration overrides for a session."""
    session_repo = get_session_repo()
    config_repo = get_tool_config_repo()

    async with get_db_session() as db:
        # Verify session exists and belongs to user
        session = await session_repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Get all configs for session
        configs = await config_repo.get_configs_for_session(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )

        return {
            "session_id": session_id,
            "configs": [
                {
                    "tool_id": str(c.tool_id),
                    "config_overrides": c.config_overrides,
                    "created_at": c.created_at.isoformat() if c.created_at else None,
                }
                for c in configs
            ],
            "count": len(configs),
        }


# ==============================================================================
# Message Routes
# ==============================================================================


@router.post("/{session_id}/messages")
async def add_message(
    session_id: str,
    request: AddMessageRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Add a message to session.

    Messages are embedded in the session's messages JSONB array.
    """
    repo = get_session_repo()

    # Validate role
    valid_roles = {"user", "assistant", "system"}
    if request.role not in valid_roles:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid role. Must be one of: {valid_roles}",
        )

    # Build message dict
    message = {
        "id": f"msg_{uuid4().hex[:12]}",
        "role": request.role,
        "content": request.content,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "agent_id": request.agent_id,
        "run_id": request.run_id,
        "metadata": request.metadata or {},
    }

    async with get_db_session() as db:
        session = await repo.add_message(
            db=db,
            session_id=session_id,
            user_id=resolve_user_id(user),
            message=message,
        )

        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "session_id": str(session.session_id),
            "message_id": message["id"],
            "message_count": len(session.messages) if session.messages else 0,
        }


@router.get("/{session_id}/messages")
async def get_messages(
    session_id: str,
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    user: UserContext = Depends(get_current_user),
):
    """
    Get messages from a session.

    Returns messages in chronological order with optional pagination.
    """
    repo = get_session_repo()

    async with get_db_session() as db:
        session_dict = await repo.get_by_id_dict(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )

        if not session_dict:
            raise HTTPException(status_code=404, detail="Session not found")

        messages = session_dict.get("messages", [])

        # Apply pagination
        paginated = messages[offset : offset + limit]

        return {
            "session_id": session_id,
            "messages": paginated,
            "total": len(messages),
            "limit": limit,
            "offset": offset,
        }


# ==============================================================================
# Context Update Routes
# ==============================================================================


@router.patch("/{session_id}/context")
async def update_session_context(
    session_id: str,
    context_updates: Dict[str, Any],
    user: UserContext = Depends(get_current_user),
):
    """Update session context data (merge with existing)."""
    repo = get_session_repo()

    async with get_db_session() as db:
        # Get current session
        session = await repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Merge context
        current_context = session.context_data or {}
        current_context.update(context_updates)

        # Update session
        updated = await repo.update(
            db=db,
            id=session_id,
            user_id=resolve_user_id(user),
            updates={"context_data": current_context},
        )

        return {
            "session_id": session_id,
            "context_data": updated.context_data if updated else {},
            "message": "Context updated",
        }


@router.patch("/{session_id}/variables")
async def update_session_variables(
    session_id: str,
    variable_updates: Dict[str, Any],
    user: UserContext = Depends(get_current_user),
):
    """Update session workflow variables (merge with existing)."""
    repo = get_session_repo()

    async with get_db_session() as db:
        # Get current session
        session = await repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Merge variables
        current_vars = session.variables or {}
        current_vars.update(variable_updates)

        # Update session
        updated = await repo.update(
            db=db,
            id=session_id,
            user_id=resolve_user_id(user),
            updates={"variables": current_vars},
        )

        return {
            "session_id": session_id,
            "variables": updated.variables if updated else {},
            "message": "Variables updated",
        }


@router.post("/{session_id}/run")
async def add_run_id(
    session_id: str,
    run_id: str = Query(..., description="Execution run ID to add"),
    user: UserContext = Depends(get_current_user),
):
    """Add an execution run ID to the session."""
    repo = get_session_repo()

    async with get_db_session() as db:
        # Get current session
        session = await repo.get_by_id(
            db=db, session_id=session_id, user_id=resolve_user_id(user)
        )
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        # Add run ID to list
        run_ids = list(session.run_ids) if session.run_ids else []
        run_uuid = UUID(run_id)
        if run_uuid not in run_ids:
            run_ids.append(run_uuid)

        # Update session
        updated = await repo.update(
            db=db,
            id=session_id,
            user_id=resolve_user_id(user),
            updates={"run_ids": run_ids},
        )

        return {
            "session_id": session_id,
            "run_ids": [str(rid) for rid in updated.run_ids] if updated else [],
            "message": "Run ID added",
        }


# ==============================================================================
# PDF Export Route
# ==============================================================================


@router.get("/{session_id}/export/pdf")
async def export_session_pdf(
    session_id: str,
    user: UserContext = Depends(get_current_user),
):
    """
    Export a chat session as a downloadable PDF.

    Generates a PDF containing all messages from the session's
    embedded JSONB messages array.
    """
    repo = get_session_repo()

    effective_user_id = resolve_user_id(user)

    async with get_db_session() as db:
        session = await repo.get_by_id(
            db=db, session_id=session_id, user_id=effective_user_id
        )

        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        messages = session.messages or []
        title = session.title or "Untitled Session"
        date_str = (
            session.created_at.strftime("%Y-%m-%d")
            if session.created_at
            else ""
        )

    buf = generate_chat_pdf(
        title=title,
        date=date_str,
        message_count=len(messages),
        messages=messages,
    )

    return StreamingResponse(
        buf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f'attachment; filename="chat_export_{session_id}.pdf"'
            ),
        },
    )
