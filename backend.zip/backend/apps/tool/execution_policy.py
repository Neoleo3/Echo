from __future__ import annotations

import json
from typing import Any, Dict, Optional

from echolib.config import settings

# Fallback ceiling on tool invocations per agent execution, used when
# ``echolib.config`` cannot be read. The live value is
# ``settings.workflow_tool_calls_hard_cap``.
#
# This bounds how many tool calls an agent may make in total. The separate
# "one call per distinct tool" rule below is unchanged and deliberately so: a
# document generator called twice produces two files, which its own manifest
# warns against. Raising this lets an agent use more *different* tools -- read
# the source, search the knowledge base, then generate the artifact -- which is
# what a research-then-write agent needs and what three did not allow.
HARD_MAX_TOOL_CALLS_PER_AGENT = 3
HARD_MAX_ITERATIONS_PER_AGENT = 3


def _hard_max_tool_calls() -> int:
    """The configured absolute ceiling on tool calls per agent execution."""
    try:
        value = int(
            getattr(
                settings, "workflow_tool_calls_hard_cap", HARD_MAX_TOOL_CALLS_PER_AGENT
            )
        )
    except Exception:  # noqa: BLE001 -- tuning must never fail an execution
        return HARD_MAX_TOOL_CALLS_PER_AGENT
    return max(0, value)
TOOL_OUTCOME_ANSWERED = "answered"
TOOL_OUTCOME_WEAK = "weak"
TOOL_OUTCOME_FAILED = "failed"
TOOL_OUTCOME_VALIDATION_FAILED = "validation_failed"
RETRYABLE_TOOL_OUTCOMES = {TOOL_OUTCOME_WEAK, TOOL_OUTCOME_FAILED, TOOL_OUTCOME_VALIDATION_FAILED}


def _coerce_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def resolve_tool_call_limit(default_value: int = HARD_MAX_TOOL_CALLS_PER_AGENT) -> int:
    requested = _coerce_int(
        getattr(settings, "workflow_max_tool_calls_per_agent", default_value),
        default_value,
    )
    return max(0, min(requested, _hard_max_tool_calls()))


def ensure_tool_budget_state(
    tool_budget_state: Optional[Dict[str, Any]] = None,
    default_value: int = HARD_MAX_TOOL_CALLS_PER_AGENT,
) -> Dict[str, Any]:
    state = tool_budget_state or {}
    resolved_limit = resolve_tool_call_limit(default_value=default_value)
    state.setdefault("calls", 0)
    state["max_calls"] = max(
        0,
        min(
            _coerce_int(state.get("max_calls", resolved_limit), resolved_limit),
            _hard_max_tool_calls(),
        ),
    )
    state.setdefault("tool_calls", {})
    state.setdefault("tool_attempts", {})
    state.setdefault("tool_outcomes", {})
    state.setdefault("call_signatures", set())
    state.setdefault("successful_calls", 0)
    state.setdefault("failed_calls", 0)
    state.setdefault("weak_calls", 0)
    state.setdefault("blocked_calls", 0)
    state.setdefault("last_error", None)
    return state


def _signature_for_input(tool_id: str, tool_input: Dict[str, Any]) -> str:
    try:
        serialized = json.dumps(tool_input, sort_keys=True, default=str)
    except (TypeError, ValueError):
        serialized = str(tool_input)
    return f"{tool_id}:{serialized}"


def reserve_tool_call(
    tool_budget_state: Dict[str, Any],
    tool_id: str,
    tool_input: Dict[str, Any],
) -> Optional[Dict[str, str]]:
    state = ensure_tool_budget_state(tool_budget_state)

    if state["calls"] >= state["max_calls"]:
        error = {
            "error": (
                f"Tool call budget exceeded for this agent execution "
                f"({state['max_calls']} max)."
            ),
            "error_type": "tool_call_budget_exceeded",
        }
        state["last_error"] = error["error"]
        return error

    state["calls"] += 1

    next_attempt = state["tool_attempts"].get(tool_id, 0) + 1
    state["tool_attempts"][tool_id] = next_attempt

    allow_validation_correction_retry = False
    if state["tool_calls"].get(tool_id, 0) >= 1:
        prior_outcome = state["tool_outcomes"].get(tool_id)
        if prior_outcome == TOOL_OUTCOME_VALIDATION_FAILED and next_attempt <= 2:
            # Permit exactly one corrective retry after a validation failure.
            allow_validation_correction_retry = True
        else:
            state["blocked_calls"] += 1
            error = {
                "error": "Tool already called once for this agent execution.",
                "error_type": "tool_call_repeat_blocked",
            }
            state["last_error"] = error["error"]
            return error

    sig_key = _signature_for_input(tool_id, tool_input)
    if sig_key in state["call_signatures"] and not allow_validation_correction_retry:
        state["blocked_calls"] += 1
        error = {
            "error": "Duplicate tool input blocked for this agent execution.",
            "error_type": "tool_call_duplicate_input_blocked",
        }
        state["last_error"] = error["error"]
        return error

    state["tool_calls"][tool_id] = state["tool_calls"].get(tool_id, 0) + 1
    state["call_signatures"].add(sig_key)
    return None


def record_tool_result(
    tool_budget_state: Dict[str, Any],
    *,
    success: bool,
    tool_id: Optional[str] = None,
    outcome: Optional[str] = None,
    error_message: Optional[str] = None,
) -> None:
    state = ensure_tool_budget_state(tool_budget_state)
    resolved_outcome = outcome or (
        TOOL_OUTCOME_ANSWERED if success else TOOL_OUTCOME_FAILED
    )

    if tool_id:
        state["tool_outcomes"][tool_id] = resolved_outcome

    if resolved_outcome == TOOL_OUTCOME_ANSWERED:
        state["successful_calls"] += 1
        return

    if resolved_outcome == TOOL_OUTCOME_WEAK:
        state["weak_calls"] += 1
        if error_message:
            state["last_error"] = error_message
        return

    state["failed_calls"] += 1
    if error_message:
        state["last_error"] = error_message


def clamp_max_iteration(requested: Any, default_value: int = HARD_MAX_ITERATIONS_PER_AGENT) -> int:
    requested_int = _coerce_int(requested, default_value)
    configured_cap = _coerce_int(
        getattr(settings, "workflow_max_iteration_cap", default_value),
        default_value,
    )
    effective_cap = max(1, min(configured_cap, HARD_MAX_ITERATIONS_PER_AGENT))
    return max(1, min(requested_int, effective_cap))


def format_tool_error_message(error_message: str, error_type: str) -> str:
    return (
        f"Tool Error ({error_type}): {error_message}. "
        "Do not retry this tool in this agent execution. "
        "If the user asked for live or connector-backed data, state clearly that retrieval failed or a required prerequisite is missing."
    )


def _is_substantive_output(text: str, fallback_length: int) -> bool:
    """Detect whether agent output is a substantive answer worth preserving.

    The agent may answer from prompt context (RAG excerpts) even when
    tools fail. Such outputs should NOT be replaced by a generic fallback.
    """
    if len(text) < 200:
        return False
    # Significantly longer than the fallback message itself
    if len(text) > max(fallback_length * 3, 400):
        return True
    # Contains markdown structure indicating a formatted report
    markdown_markers = ("## ", "### ", "**", "- ", "1. ", "| ")
    marker_count = sum(1 for m in markdown_markers if m in text)
    if marker_count >= 2:
        return True
    return False


def apply_failure_fallback(
    output_text: str,
    tool_budget_state: Optional[Dict[str, Any]],
    fallback_message: str,
) -> str:
    state = ensure_tool_budget_state(tool_budget_state)
    if state["calls"] <= 0:
        return output_text
    non_answering_calls = state["failed_calls"] + state["weak_calls"]
    if state["successful_calls"] > 0 or non_answering_calls <= 0:
        return output_text

    normalized_output = (output_text or "").strip()
    if not normalized_output:
        return fallback_message

    lowered = normalized_output.lower()
    explicit_markers = ("could not", "couldn't", "unable", "failed", "error", "missing")
    if any(marker in lowered for marker in explicit_markers):
        return output_text

    # Preserve substantive outputs where the agent answered from prompt
    # context (RAG chunks, document excerpts) without needing tool data.
    if _is_substantive_output(normalized_output, len(fallback_message)):
        return output_text

    # A weak-only API pass can still produce a concrete verified answer from
    # metadata fields. Preserve that final answer, but continue to collapse
    # pure retry-guidance text to the generic fallback.
    retry_guidance_markers = (
        "tool guidance:",
        "may retry this api tool one more time",
        "no further retry is allowed",
    )
    if state["failed_calls"] == 0 and state["weak_calls"] > 0:
        if not any(marker in lowered for marker in retry_guidance_markers):
            return output_text

    return fallback_message
