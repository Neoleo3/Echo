"""
Sync-to-async bridge for tool execution.

WHAT: Holds the gateway's main event loop and runs coroutines from synchronous
      runtime code (LangGraph sync nodes, LangChain tool wrappers).
WHY:  This bridge previously lived in ``apps.workflow.runtime.langchain_adapter``,
      which forced ``apps/tool/executor.py`` to import from ``apps.workflow`` --
      an inverted dependency between two sibling apps. The tool layer is the
      primary consumer, so it owns the bridge.

Scheduling on the gateway loop matters because asyncpg connections are bound to
the loop that created them; running tool coroutines on a private loop breaks
every DB-backed tool with "Future attached to a different loop".
"""
from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Optional

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_SECONDS = 60

# Extra wall-clock allowance when waiting on a worker thread that is itself
# waiting on the loop, so the outer wait never expires before the inner one.
_RESULT_GRACE_SECONDS = 5

_main_loop: Optional[asyncio.AbstractEventLoop] = None

_BRIDGE_POOL = ThreadPoolExecutor(max_workers=8, thread_name_prefix="tool-async-bridge")


def set_main_loop(loop: asyncio.AbstractEventLoop) -> None:
    """Store the gateway's main event loop for later sync-to-async bridging."""
    global _main_loop
    _main_loop = loop
    logger.info("Tool async bridge captured the main event loop")


def get_main_loop() -> Optional[asyncio.AbstractEventLoop]:
    """Return the captured main event loop, or None when it was never set."""
    return _main_loop


def _await_on_loop(coro: Any, loop: asyncio.AbstractEventLoop, timeout: int) -> Any:
    return asyncio.run_coroutine_threadsafe(coro, loop).result(timeout=timeout)


def run_async(coro: Any, timeout: int = DEFAULT_TIMEOUT_SECONDS) -> Any:
    """
    Run a coroutine from synchronous code.

    WHAT: Schedules ``coro`` on the running loop of this thread when there is
          one, otherwise on the captured gateway loop, otherwise on a private
          loop as a last resort.
    WHY:  Blocking on the loop we are currently running on would deadlock, so
          that case is handed to a worker thread.
    INPUT: A coroutine and a timeout in seconds.
    OUTPUT: The coroutine's result.
    RAISES: Whatever the coroutine raises, plus TimeoutError on expiry.
    """
    try:
        running = asyncio.get_running_loop()
    except RuntimeError:
        running = None

    target = running or _main_loop

    if target is not None and not target.is_closed():
        if running is not None:
            return _BRIDGE_POOL.submit(
                _await_on_loop, coro, target, timeout
            ).result(timeout=timeout + _RESULT_GRACE_SECONDS)
        try:
            return _await_on_loop(coro, target, timeout)
        except RuntimeError:
            # Scheduling failed (loop closed between the check and the call).
            # Execution failures are NOT caught here: re-running an already
            # awaited coroutine is impossible and would mask the real error.
            logger.debug("Main loop unusable, falling back to a private loop", exc_info=True)

    return asyncio.run(coro)
