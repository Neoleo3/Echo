"""
Tool Registry Module

This module provides the ToolRegistry class for managing tool registration,
discovery, and retrieval in the EchoAI system. It handles both local tools
(Python functions) and external tools (MCP servers, API endpoints).

The registry maintains an index of all available tools and provides methods
for querying, filtering, and validating tools for agent use.
"""

import asyncio
import json
import logging
import threading
import uuid as _uuid
from pathlib import Path
from typing import Dict, List, Optional, Any, Awaitable, Callable

from echolib.types import ToolDef, ToolType
from echolib.config import settings as _settings
from echolib.repositories.tool_repo import ToolRepository
from echolib.database import get_db_session
from echolib.repositories.base import DEFAULT_USER_ID

from .storage import ToolStorage

logger = logging.getLogger(__name__)

# ─── DB Dual-Write Constants ───
# Fixed UUID namespace for deterministic tool_id → UUID conversion.
# Tool.tool_id (DB) is UUID but ToolDef.tool_id is str (e.g. "tool_api_jira").
# uuid5(TOOL_NS, str) ensures the same string always maps to the same UUID.
_TOOL_NS = _uuid.UUID("a1b2c3d4-e5f6-7890-abcd-ef1234567890")

# System user ID for tools synced at startup (no HTTP/user context).
# Reuses the DEFAULT_USER_ID already defined in echolib.repositories.base.
SYSTEM_USER_ID = DEFAULT_USER_ID
DEFAULT_TOOL_ICON = "default"

# Marker written by the removed connector→tool synthesis path. Retained only
# so already-persisted synthetic tools can be recognised and purged on load.
LEGACY_CONNECTOR_SYNC_SOURCE = "connector_sync"


def _tool_id_to_uuid(tool_id_str: str) -> _uuid.UUID:
    """Deterministic UUID from a string tool_id. Idempotent and reversible."""
    return _uuid.uuid5(_TOOL_NS, tool_id_str)


class ToolRegistry:
    """
    Central registry for managing tools across the EchoAI platform.

    The ToolRegistry is responsible for:
    - Registering new tools (local, MCP, API)
    - Discovering available tools from configured locations
    - Providing tool metadata and schemas
    - Filtering tools by type, capability, or agent requirements
    - Validating tool inputs against schemas

    Attributes:
        storage (ToolStorage): Persistence layer for tool definitions
        discovery_dirs (List[Path]): Directories to scan for local tools
        _cache (Dict[str, ToolDef]): In-memory cache of registered tools
    """

    def __init__(
        self,
        storage: ToolStorage,
        discovery_dirs: Optional[List[Path]] = None,
        tool_repo: Optional[ToolRepository] = None
    ):
        """
        Initialize the ToolRegistry.

        Args:
            storage: ToolStorage instance for persistence
            discovery_dirs: Optional list of directories to scan for tool manifests
            tool_repo: Optional ToolRepository for DB dual-write persistence.
                       If provided, tools are written to both filesystem AND database.
                       DB writes are non-blocking — failures never block filesystem ops.
        """
        self.storage = storage
        self.discovery_dirs = discovery_dirs or []
        self._cache: Dict[str, ToolDef] = {}
        self._tool_repo: Optional[ToolRepository] = tool_repo

        # Load all existing tools into cache
        self._load_all()

        # NOTE: Connectors are NOT synthesised into tools. They attach to an
        # agent as ``definition.connectors`` and are reached through the
        # connector middleware, not through this registry.

        logger.info(
            f"ToolRegistry initialized with {len(self._cache)} tools, "
            f"{len(self.discovery_dirs)} discovery directories"
            f"{', DB dual-write enabled' if self._tool_repo else ''}"
        )

    # ──────────────────────────────────────────────────────────────────────
    # DB Dual-Write Helpers
    # ──────────────────────────────────────────────────────────────────────

    def _schedule_db_write(self, coro_factory: Callable[[], Awaitable[None]]) -> None:
        """
        Schedule an async DB coroutine from sync context. Non-blocking, fail-safe.

        Inside FastAPI (running event loop): uses loop.create_task() — fire-and-forget.
        Outside event loop (startup/CLI): spawns a daemon thread with its own loop.
        """
        if self._tool_repo is None:
            return

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._safe_db_op(coro_factory))
        except RuntimeError:
            # No running event loop — spawn one in a daemon thread
            threading.Thread(
                target=lambda: asyncio.run(self._safe_db_op(coro_factory)),
                daemon=True
            ).start()

    async def _safe_db_op(self, coro_factory: Callable[[], Awaitable[None]]) -> None:
        """Execute an async DB operation with error handling. Never raises."""
        try:
            await coro_factory()
        except Exception as e:
            logger.warning(f"DB dual-write failed (non-blocking): {e}")

    async def _persist_tool_to_db(self, tool: ToolDef, user_id: str) -> None:
        """
        Persist a ToolDef to the database via ToolRepository.

        Uses the repository's atomic upsert to avoid duplicate insert races
        when the same tool is persisted concurrently.
        """
        tool_data = {
            "tool_id": _tool_id_to_uuid(tool.tool_id),
            "name": tool.name,
            "description": tool.description,
            "tool_type": tool.tool_type.value,
            "definition": tool.model_dump(mode="json"),
            "status": tool.status or "active",
            "version": tool.version or "1.0",
            "tags": tool.tags or [],
        }

        async with get_db_session() as db:
            await self._tool_repo.upsert_tool_definition(
                db,
                user_id=user_id,
                tool_data=tool_data,
            )
            logger.debug(f"DB dual-write: upserted tool '{tool.tool_id}'")

    async def _delete_tool_from_db(self, tool_id: str, user_id: str) -> None:
        """Soft-delete a tool from the database via ToolRepository."""
        tool_uuid = str(_tool_id_to_uuid(tool_id))

        async with get_db_session() as db:
            deleted = await self._tool_repo.delete(db, tool_uuid, user_id)
            if deleted:
                logger.debug(f"DB dual-write: soft-deleted tool '{tool_id}'")
            else:
                logger.debug(f"DB dual-write: tool '{tool_id}' not found in DB (OK)")

    # ──────────────────────────────────────────────────────────────────────

    def register(
        self,
        tool: ToolDef,
        user_id: Optional[str] = None,
        *,
        schedule_db_write: bool = True,
    ) -> Dict[str, str]:
        """
        Register a new tool or update an existing one.

        Persists to filesystem (primary) and database (secondary, non-blocking).
        DB failure never blocks registration — filesystem is the source of truth.

        Args:
            tool: ToolDef instance to register
            user_id: Optional owner user ID for DB persistence.
                     Defaults to SYSTEM_USER_ID for startup sync / CLI usage.
            schedule_db_write: When True, schedule the usual fire-and-forget
                               DB dual-write. Callers that must guarantee
                               persistence disable this and await the write.

        Returns:
            Dict with registration result (tool_id, status, message)

        Raises:
            ValueError: If tool definition is invalid
        """
        # Validate required fields
        if not tool.name:
            raise ValueError("Tool must have a name")

        if not tool.description:
            raise ValueError("Tool must have a description")

        # Ensure tool_id is set
        if not tool.tool_id:
            tool_id = f"tool_{tool.name.lower().replace(' ', '_').replace('-', '_')}"
            # Create a new tool with the generated ID
            tool = ToolDef(
                tool_id=tool_id,
                name=tool.name,
                description=tool.description,
                tool_type=tool.tool_type,
                input_schema=tool.input_schema,
                output_schema=tool.output_schema,
                execution_config=tool.execution_config,
                version=tool.version,
                tags=tool.tags,
                status=tool.status,
                metadata=tool.metadata
            )

        # Check if updating existing tool
        is_update = tool.tool_id in self._cache

        # Ensure a default icon if none was provided (works for create and update)
        if not getattr(tool, "icon", None):
            tool.icon = DEFAULT_TOOL_ICON

        resolved_user_id = self._normalize_user_id(user_id or SYSTEM_USER_ID)

        try:
            # Persist to filesystem (primary store) — skipped when TOOL_DB_WRITE_ONLY
            if not _settings.TOOL_DB_WRITE_ONLY:
                self.storage.save_tool(tool)
            else:
                logger.info(f"Filesystem write skipped for tool '{tool.tool_id}' (TOOL_DB_WRITE_ONLY=true)")

            # Update cache (always — keeps in-memory state consistent)
            self._cache[tool.tool_id] = tool

            status = "updated" if is_update else "registered"
            logger.info(f"Tool '{tool.tool_id}' {status}")

            # Dual-write to DB (non-blocking, fail-safe)
            if self._tool_repo is not None and schedule_db_write:
                self._schedule_db_write(
                    lambda: self._persist_tool_to_db(tool, resolved_user_id)
                )

            return {
                "tool_id": tool.tool_id,
                "status": status,
                "message": f"Tool '{tool.name}' {status} successfully"
            }

        except Exception as e:
            logger.error(f"Failed to register tool '{tool.name}': {e}")
            raise ValueError(f"Failed to register tool: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # Async-safe tool retrieval (DB-backed)
    # ──────────────────────────────────────────────────────────────────────

    def _hydrate_tool_from_row(self, tool_key: str, row: Any) -> Optional[ToolDef]:
        """Reconstruct ToolDef from a repository row and cache it."""
        if not row or not getattr(row, "definition", None):
            return None

        try:
            tool = ToolDef(**row.definition)
            if _is_legacy_connector_tool(tool):
                logger.debug(
                    "Ignoring legacy connector-synced tool '%s' from DB", tool_key
                )
                return None
            self._cache[tool.tool_id] = tool
            return tool
        except Exception as parse_err:
            logger.debug(
                "Failed to parse ToolDef from DB for '%s': %s",
                tool_key,
                parse_err,
            )
            return None

    async def get_async(self, tool_id: str) -> Optional[ToolDef]:
        """
        Retrieve a tool definition by ID with async-safe DB fallback.

        Use this from async request paths. DB lookup is user-agnostic
        (``get_by_id_any_user``) so tools created under a real user ID are
        resolvable after server restart.
        """
        if tool_id in self._cache:
            return self._cache[tool_id]

        if self._tool_repo is not None:
            try:
                tool_uuid = str(_tool_id_to_uuid(tool_id))
                async with get_db_session() as db:
                    row = await self._tool_repo.get_by_id_any_user(db, tool_uuid)
                tool = self._hydrate_tool_from_row(tool_id, row)
                if tool:
                    return tool
            except Exception as exc:
                logger.debug("Async DB lookup failed for tool '%s': %s", tool_id, exc)

        return self._get_from_storage(tool_id)

    async def get_async_for_user(
        self,
        tool_id: str,
        user_id: Optional[str],
    ) -> Optional[ToolDef]:
        """
        Retrieve a tool definition scoped for a specific user.

        Every registered tool is globally visible: per-owner scoping existed
        only for connector-synced tools, which no longer exist. ``user_id`` is
        retained so callers keep a stable signature.
        """
        return await self.get_async(tool_id)

    def get(self, tool_id: str) -> Optional[ToolDef]:
        """
        Retrieve a tool definition by its ID.

        Lookup order:
          1. In-memory cache (fastest path).
          2. Filesystem storage (gated by LEGACY_FILE_READ_ENABLED).

        IMPORTANT: This synchronous method is intentionally cache/filesystem-only.
        Async DB access must use get_async() so request handlers do not bridge
        across event loops and corrupt the shared asyncpg connection state.

        Args:
            tool_id: Unique identifier of the tool

        Returns:
            ToolDef instance if found, None otherwise
        """
        # 1. Try cache first (always)
        if tool_id in self._cache:
            return self._cache[tool_id]

        return self._get_from_storage(tool_id)

    def _get_from_storage(self, tool_id: str) -> Optional[ToolDef]:
        """Load a tool from filesystem storage when legacy fallback is enabled."""
        if _settings.LEGACY_FILE_READ_ENABLED:
            logger.warning(
                "LEGACY_FS_FALLBACK: Loading tool '%s' from filesystem "
                "(cache miss).",
                tool_id,
            )
            tool = self.storage.load_tool(tool_id)
            if tool:
                self._cache[tool_id] = tool
                return tool
        else:
            logger.info(f"Filesystem fallback read skipped for tool '{tool_id}' (LEGACY_FILE_READ_ENABLED=false)")

        logger.debug(f"Tool '{tool_id}' not found")
        return None

    async def get_by_name_async(self, name: str) -> Optional[ToolDef]:
        """
        Retrieve a tool definition by name with async-safe DB fallback.

        DB lookup is user-agnostic so tools are always resolvable regardless
        of which user created them.
        """
        name_lower = name.lower()
        for tool in self._cache.values():
            if tool.name.lower() == name_lower:
                return tool

        if self._tool_repo is not None:
            try:
                async with get_db_session() as db:
                    row = await self._tool_repo.get_by_name_any_user(db, name)
                tool = self._hydrate_tool_from_row(name, row)
                if tool:
                    return tool
            except Exception as exc:
                logger.debug("Async DB lookup by name failed for tool '%s': %s", name, exc)

        return None

    async def get_by_name_async_for_user(
        self,
        name: str,
        user_id: Optional[str],
    ) -> Optional[ToolDef]:
        """
        Retrieve a tool definition by name scoped for a specific user.

        Every registered tool is globally visible — see ``get_async_for_user``.
        """
        return await self.get_by_name_async(name)

    def get_by_name(self, name: str) -> Optional[ToolDef]:
        """
        Retrieve a tool definition by its name.

        Lookup order:
          1. In-memory cache (fastest path).

        IMPORTANT: This synchronous method is cache-only. Async callers that
        need DB-backed lookup must use get_by_name_async().

        Args:
            name: Human-readable name of the tool

        Returns:
            ToolDef instance if found, None otherwise
        """
        # 1. Cache lookup
        name_lower = name.lower()
        for tool in self._cache.values():
            if tool.name.lower() == name_lower:
                return tool

        return None

    def get_tool_id_by_name(self, name: str) -> Optional[str]:
        """
        Get tool_id by tool name.

        This method supports frontend tool resolution where tools
        are referenced by name.

        Args:
            name: Human-readable name of the tool

        Returns:
            tool_id if found, None otherwise
        """
        tool = self.get_by_name(name)
        return tool.tool_id if tool else None

    def list_all(self) -> List[ToolDef]:
        """
        List all registered tools.

        Returns:
            List of all ToolDef instances in the registry
        """
        return list(self._cache.values())

    def list_all_for_user(self, user_id: Optional[str]) -> List[ToolDef]:
        """List all tools visible to the specified user — see ``get_async_for_user``."""
        return self.list_all()

    def list_by_type(self, tool_type: ToolType) -> List[ToolDef]:
        """
        List all tools of a specific type.

        Args:
            tool_type: ToolType enum value to filter by

        Returns:
            List of ToolDef instances matching the specified type
        """
        return [
            tool for tool in self._cache.values()
            if tool.tool_type == tool_type
        ]

    def list_by_type_for_user(
        self,
        tool_type: ToolType,
        user_id: Optional[str],
    ) -> List[ToolDef]:
        """List tools of a type visible to the specified user — see ``get_async_for_user``."""
        return self.list_by_type(tool_type)

    def list_by_status(self, status: str) -> List[ToolDef]:
        """
        List all tools with a specific status.

        Args:
            status: Status string to filter by (active, deprecated, disabled)

        Returns:
            List of ToolDef instances with the specified status
        """
        return [
            tool for tool in self._cache.values()
            if tool.status == status.lower()
        ]

    def list_by_tags(self, tags: List[str]) -> List[ToolDef]:
        """
        List tools that have any of the specified tags.

        Args:
            tags: List of tags to filter by

        Returns:
            List of ToolDef instances that have at least one matching tag
        """
        tags_lower = {tag.lower() for tag in tags}
        return [
            tool for tool in self._cache.values()
            if any(tag.lower() in tags_lower for tag in tool.tags)
        ]

    def list_by_tags_for_user(
        self,
        tags: List[str],
        user_id: Optional[str],
    ) -> List[ToolDef]:
        """List tools by tags visible to the specified user — see ``get_async_for_user``."""
        return self.list_by_tags(tags)

    def delete(self, tool_id: str, user_id: Optional[str] = None) -> bool:
        """
        Delete a tool from the registry.

        Removes from filesystem (primary) and soft-deletes in DB (secondary, non-blocking).

        Args:
            tool_id: Unique identifier of the tool to delete
            user_id: Optional owner user ID for DB soft-delete.
                     Defaults to SYSTEM_USER_ID.

        Returns:
            True if deletion successful, False if tool not found
        """
        if tool_id not in self._cache:
            logger.warning(f"Tool '{tool_id}' not found for deletion")
            return False

        try:
            # Delete from filesystem (primary store) — skipped when TOOL_DB_WRITE_ONLY
            if not _settings.TOOL_DB_WRITE_ONLY:
                success = self.storage.delete_tool(tool_id)
            else:
                logger.info(f"Filesystem delete skipped for tool '{tool_id}' (TOOL_DB_WRITE_ONLY=true)")
                success = True  # Treat as success since DB is authoritative

            if success:
                # Remove from cache
                del self._cache[tool_id]
                logger.info(f"Tool '{tool_id}' deleted from registry")

                # Dual-delete from DB (non-blocking, fail-safe)
                if self._tool_repo is not None:
                    resolved_user_id = user_id or SYSTEM_USER_ID
                    self._schedule_db_write(
                        lambda: self._delete_tool_from_db(tool_id, resolved_user_id)
                    )

            return success

        except Exception as e:
            logger.error(f"Failed to delete tool '{tool_id}': {e}")
            return False

    def discover_local_tools(self) -> List[ToolDef]:
        """
        Discover and register tools from configured discovery directories.

        Scans each directory in discovery_dirs for tool_manifest.json files
        and automatically registers the discovered tools.

        Returns:
            List of newly discovered ToolDef instances
        """
        discovered = []

        if not self.discovery_dirs:
            logger.info("No discovery directories configured")
            return discovered

        for discovery_dir in self.discovery_dirs:
            discovery_path = Path(discovery_dir)

            if not discovery_path.exists():
                logger.warning(f"Discovery directory does not exist: {discovery_path}")
                continue

            logger.info(f"Scanning directory for tools: {discovery_path}")

            # Scan for tool_manifest.json in each subdirectory
            for tool_dir in discovery_path.iterdir():
                if not tool_dir.is_dir():
                    continue

                manifest_path = tool_dir / "tool_manifest.json"
                if not manifest_path.exists():
                    logger.debug(f"No manifest found in {tool_dir.name}")
                    continue

                try:
                    # Load and parse manifest
                    tool = self._load_manifest(manifest_path)
                    if not tool:
                        continue

                    # Check if tool already registered (idempotent discovery)
                    existing = self.get(tool.tool_id)
                    if existing:
                        logger.info(f"Tool {tool.tool_id} already registered, skipping")
                        continue

                    # Register the discovered tool
                    self.register(tool)
                    discovered.append(tool)
                    logger.info(
                        f"Discovered and registered tool: {tool.tool_id} ({tool.name})"
                    )

                except Exception as e:
                    logger.error(
                        f"Failed to load tool from {manifest_path}: {e}"
                    )
                    continue

        logger.info(f"Discovery complete. Found {len(discovered)} new tools")
        return discovered

    def _load_manifest(self, manifest_path: Path) -> Optional[ToolDef]:
        """
        Load a tool definition from a manifest file.

        Args:
            manifest_path: Path to tool_manifest.json file

        Returns:
            ToolDef instance if valid, None otherwise
        """
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Convert tool_type string to enum if present
            if 'tool_type' in data and isinstance(data['tool_type'], str):
                tool_type_str = data['tool_type'].upper()
                try:
                    data['tool_type'] = ToolType[tool_type_str]
                except KeyError:
                    try:
                        data['tool_type'] = ToolType(data['tool_type'].lower())
                    except ValueError:
                        logger.warning(
                            f"Unknown tool_type '{data['tool_type']}' in {manifest_path}, "
                            f"defaulting to LOCAL"
                        )
                        data['tool_type'] = ToolType.LOCAL

            tool_def = ToolDef(**data)
            return tool_def

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in manifest {manifest_path}: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to parse manifest {manifest_path}: {e}")
            return None

    def get_tools_for_agent(self, tool_ids: List[str]) -> List[ToolDef]:
        """
        Get all tools required by an agent.

        Args:
            tool_ids: List of tool identifiers the agent needs

        Returns:
            List of ToolDef instances for the requested tools
        """
        tools = []

        for tool_id in tool_ids:
            tool = self.get(tool_id)
            if tool:
                if tool.status == "active":
                    tools.append(tool)
                else:
                    logger.warning(
                        f"Tool '{tool_id}' is {tool.status}, skipping"
                    )
            else:
                # Try finding by name as fallback (for frontend compatibility)
                tool = self.get_by_name(tool_id)
                if tool and tool.status == "active":
                    tools.append(tool)
                else:
                    logger.warning(f"Tool '{tool_id}' not found for agent")

        return tools

    def validate_tool_input(self, tool_id: str, input_data: Dict[str, Any]) -> bool:
        """
        Validate input data against a tool's input schema.

        Args:
            tool_id: ID of the tool to validate against
            input_data: Input data to validate

        Returns:
            True if validation passes

        Raises:
            ValueError: If validation fails with details
            KeyError: If tool not found
        """
        tool = self.get(tool_id)
        if not tool:
            raise KeyError(f"Tool '{tool_id}' not found")

        if not tool.input_schema:
            return True

        try:
            import jsonschema
            jsonschema.validate(instance=input_data, schema=tool.input_schema)
            return True

        except jsonschema.ValidationError as e:
            error_msg = f"Input validation failed for tool '{tool_id}': {e.message}"
            logger.warning(error_msg)
            raise ValueError(error_msg)

        except jsonschema.SchemaError as e:
            error_msg = f"Invalid schema for tool '{tool_id}': {e.message}"
            logger.error(error_msg)
            raise ValueError(error_msg)

    def validate_tool_output(self, tool_id: str, output_data: Dict[str, Any]) -> bool:
        """
        Validate output data against a tool's output schema.

        Args:
            tool_id: ID of the tool to validate against
            output_data: Output data to validate

        Returns:
            True if validation passes

        Raises:
            ValueError: If validation fails
            KeyError: If tool not found
        """
        tool = self.get(tool_id)
        if not tool:
            raise KeyError(f"Tool '{tool_id}' not found")

        if not tool.output_schema:
            return True

        try:
            import jsonschema
            jsonschema.validate(instance=output_data, schema=tool.output_schema)
            return True

        except jsonschema.ValidationError as e:
            error_msg = f"Output validation failed for tool '{tool_id}': {e.message}"
            logger.warning(error_msg)
            raise ValueError(error_msg)

    def _load_all(self) -> None:
        """
        Load all tools into the cache from filesystem storage.

        Called during __init__() which runs at import time BEFORE the
        async event loop exists.  Async DB calls are NOT safe here.

        Tools written by the removed connector→tool synthesis path are skipped
        and their files deleted, so an instance that ran the old code converges
        on the new behaviour without an operator step.
        """
        try:
            tools = self.storage.load_all()
            loaded = 0
            purged = 0

            for tool in tools:
                if _is_legacy_connector_tool(tool):
                    purged += 1
                    try:
                        self.storage.delete_tool(tool.tool_id)
                    except Exception as purge_err:
                        logger.warning(
                            "Failed to remove legacy connector tool file '%s': %s",
                            tool.tool_id,
                            purge_err,
                        )
                    continue

                self._cache[tool.tool_id] = tool
                loaded += 1

            logger.debug("Loaded %d tools from filesystem into cache", loaded)
            if purged:
                logger.info(
                    "Purged %d legacy connector-synced tool(s) from filesystem storage",
                    purged,
                )
        except Exception as e:
            logger.error("Failed to load tools from storage: %s", e)

    def refresh_cache(self) -> int:
        """
        Refresh the in-memory cache from filesystem storage.

        Returns:
            Number of tools loaded
        """
        self._cache.clear()
        self._load_all()
        logger.info("Tool cache refreshed: %d tools loaded from filesystem", len(self._cache))

        return len(self._cache)

    def count(self) -> int:
        """
        Get the number of registered tools.

        Returns:
            Total count of tools in registry
        """
        return len(self._cache)

    def search(self, query: str) -> List[ToolDef]:
        """
        Search tools by name or description.

        Args:
            query: Search string (case-insensitive)

        Returns:
            List of matching ToolDef instances
        """
        query_lower = query.lower()
        return [
            tool for tool in self._cache.values()
            if query_lower in tool.name.lower()
            or query_lower in tool.description.lower()
        ]

    def search_for_user(self, query: str, user_id: Optional[str]) -> List[ToolDef]:
        """Search tools visible to the specified user — see ``get_async_for_user``."""
        return self.search(query)

    # ──────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _normalize_user_id(user_id: Optional[Any]) -> Optional[str]:
        if user_id is None:
            return None

        normalized = str(user_id).strip()
        return normalized or None


def _is_legacy_connector_tool(tool: ToolDef) -> bool:
    """
    True when a tool was written by the removed connector→tool synthesis path.

    WHAT: Detects the ``connector_sync`` marker stamped into execution_config.
    WHY:  Connectors are no longer synthesised into tools. Rows and files left
          behind by the old path must not be served to agents; they are skipped
          on load and their agent attachments are migrated to
          ``definition.connectors``.
    INPUT: A ToolDef loaded from storage or the database.
    OUTPUT: True when the definition is a legacy synthetic connector tool.
    """
    execution_config = tool.execution_config or {}
    return execution_config.get("source") == LEGACY_CONNECTOR_SYNC_SOURCE
