"""
Canonical Echo tool spec -> LangChain tool builder.

WHAT: Turns the tool references stored on an agent definition into LangChain
      ``StructuredTool`` objects backed by Echo's ToolExecutor.
WHY:  Tool binding used to exist twice -- ``apps/agent/factory/factory.py``
      hand-rolled OpenAI function schemas for standalone chat while
      ``apps/workflow/runtime/langchain_adapter.py`` built StructuredTools for
      workflow nodes. The two disagreed on schema hydration, budget enforcement
      and error text. With a single agent instantiation path there can only be
      one builder, and it belongs to the tool app so ``apps.agent`` never has to
      import ``apps.workflow``.

Observability is injected, not imported: callers pass ``on_tool_start`` /
``on_tool_end`` hooks so the workflow runtime can emit transparency events
without this module knowing that transparency exists.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from apps.tool.async_bridge import run_async
from apps.tool.execution_policy import (
    TOOL_OUTCOME_VALIDATION_FAILED,
    ensure_tool_budget_state,
    format_tool_error_message,
    record_tool_result,
    reserve_tool_call,
)

logger = logging.getLogger(__name__)

DEFAULT_TOOL_TIMEOUT_SECONDS = 300

VALIDATION_RETRY_HINT = (
    "Tool input validation failed. "
    "Retry this tool once with corrected required fields only."
)

VALIDATION_GIVE_UP_HINT = (
    "Tool input validation still failed after one correction attempt. "
    "Continue without this tool and provide a best-effort answer, "
    "stating that live tool retrieval could not be completed."
)

# Called as ``on_tool_start(tool_id, tool_name, kwargs) -> step_id | None``.
OnToolStart = Callable[[str, str, Dict[str, Any]], Optional[str]]
# Called as ``on_tool_end(step_id, result) -> None``.
OnToolEnd = Callable[[Optional[str], Any], None]


def format_tool_success_output(result: Any) -> str:
    """Convert successful tool results into the text payload agents and routes expect.

    Workflow download-link registration only scans string outputs. Many tools return
    structured dicts where the human-facing message lives under ``result`` or where
    downloadable-file metadata is exposed as ``file_path``/``filename``. Normalize
    those shapes here so every workflow path surfaces a link-registerable marker.
    """
    output = getattr(result, "output", result)

    if isinstance(output, str):
        return output

    if isinstance(output, dict):
        for key in ("result", "answer", "message", "text", "content", "summary"):
            value = output.get(key)
            if isinstance(value, str) and value.strip():
                return value

        file_path = output.get("file_path")
        filename = output.get("filename")
        if isinstance(file_path, str) and file_path.strip() and isinstance(filename, str) and filename.strip():
            return (
                f"File '{filename}' generated successfully.\n\n"
                f"[GENERATED_FILE:{file_path}:{filename}]"
            )

        formatted_parts = [f"{k}: {v}" for k, v in output.items()]
        if formatted_parts:
            return "Tool Result:\n" + "\n".join(formatted_parts)
        return "Tool executed successfully."

    if isinstance(output, list):
        return "Tool Result:\n" + "\n".join(str(item) for item in output)

    if output is None:
        return "Tool executed successfully."

    return str(output)


def is_validation_error(error_text: str, error_type: str) -> bool:
    """Detect tool failures caused by malformed arguments rather than execution."""
    etype = (error_type or "").strip().lower()
    if "validation" in etype:
        return True

    lowered = (error_text or "").lower()
    markers = (
        "validation failed",
        "required property",
        "input validation",
        "invalid input",
    )
    return any(marker in lowered for marker in markers)


# A tool that completed without raising, but declined to do the work and asked
# the caller to try again with better input.
#
# The document generator does this: its sparse-content gate returns an ordinary
# result dict whose ``result`` text begins ``ERROR:`` and whose ``file_path`` is
# empty, telling the model to supply richer sections and call it again. Because
# the call did not raise, it took the success branch below, ``is_validation_error``
# never saw the text, and ``record_tool_result`` booked it as ANSWERED -- so the
# corrective retry that ``execution_policy`` already implements was never
# granted, and ``reserve_tool_call`` then blocked the second attempt outright.
#
# The tool asked for a retry the platform forbade. The model, handed an
# instruction it could not obey, fell back to prose -- which is the "no document,
# just text" outcome.
_REJECTION_PREFIXES = ("error:", "invalid:", "cannot generate", "unable to generate")


def is_tool_rejection(result: Any) -> Optional[str]:
    """
    The rejection message when a tool declined the work, else ``None``.

    WHAT: Recognises a *successful* return that is really a refusal asking for
          corrected input.
    WHY:  Without this a tool's own "try again with more content" instruction is
          unreachable: the platform records success and blocks the retry.
    OUTPUT: The message to hand back, or ``None`` for a genuine result. Never
            raises -- an unrecognised shape is treated as a real result, which
            is the behaviour every tool had before this existed.

    Deliberately narrow. A rejection must BOTH read as one and carry no
    artifact, so a tool that produces a file and merely mentions the word error
    in its summary is untouched.
    """
    output = getattr(result, "output", result)
    if not isinstance(output, dict):
        return None

    message = output.get("result")
    if not isinstance(message, str) or not message.strip():
        return None

    if not message.strip().lower().startswith(_REJECTION_PREFIXES):
        return None

    # A rejection produced nothing. If any artifact reference is present the
    # tool did its job and the wording is incidental.
    for key in ("file_path", "filename", "file_id", "download_url"):
        if str(output.get(key) or "").strip():
            return None

    return message.strip()


def _is_usable_json_schema(schema: Optional[dict]) -> bool:
    """
    Whether a declared schema can be handed to the provider unchanged.

    Strict about shape, silent about contents: it must be an object schema with
    at least one property, which is what the function-calling API requires.
    Beyond that the tool author's schema is trusted -- they wrote it for exactly
    this purpose.

    Anything else takes the Pydantic path below, so no existing tool changes
    behaviour unless its schema is genuinely richer than the flat model could
    express.
    """
    if not isinstance(schema, dict):
        return False
    if schema.get("type", "object") != "object":
        return False
    properties = schema.get("properties")
    return isinstance(properties, dict) and bool(properties)


def args_schema_from_input(tool_id: str, input_schema: Optional[dict]):
    """
    The argument schema a model is shown for one tool.

    WHAT: Passes the tool's own JSON Schema through when it is usable, and falls
          back to the Pydantic builder below only when it is not.
    WHY:  A tool manifest already *is* JSON Schema -- the dialect the provider's
          function-calling API consumes. Rebuilding it as a Pydantic model and
          letting LangChain convert it back is a lossy round trip, and what it
          loses is every level of nesting.

          The fallback's type map sends ``array`` to a bare ``list`` and
          ``object`` to a bare ``dict``, discarding ``items`` and nested
          ``properties``. The document generator declares ``sections`` as an
          array of objects with heading, body, table and charts; what reached
          the model was::

              "sections": {
                "anyOf": [{"items": {}, "type": "array"}, {"type": "null"}],
                "default": null
              }

          An array of *anything*, optional, defaulting to null. The model was
          told the payload existed and nothing about how to build one, so it
          either declined to call the tool or called it with an empty payload.
          Eleven of nineteen tools were affected, including every document
          generator.

          This bites harder on newer models, not softer: the GPT-5 family
          applies strict schema validation by default, so an underspecified
          schema is treated far less forgivingly than GPT-4 treated it. GPT-4
          guessed from the description; GPT-5 does not guess.
    INPUT: The tool id and its declared ``input_schema``.
    OUTPUT: The raw schema dict, or a Pydantic model. ``StructuredTool`` accepts
            both and ``tool_func(**kwargs)`` already takes arbitrary keyword
            arguments, so nothing downstream depends on which is returned.

    Backward compatible: an absent or malformed schema takes exactly the path it
    took before, including the single-``input`` fallback.
    """
    from pydantic import Field, create_model

    def _simple():
        return create_model(f"{tool_id}_Args", input=(str, Field("", description="Tool input")))

    if _is_usable_json_schema(input_schema):
        return input_schema

    try:
        props = (input_schema or {}).get("properties", {}) if isinstance(input_schema, dict) else {}
        required = set((input_schema or {}).get("required", []) or [])
        if not props or not isinstance(props, dict):
            return _simple()

        type_map = {
            "string": str,
            "integer": int,
            "number": float,
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        fields: Dict[str, Any] = {}
        for name, spec in props.items():
            spec = spec if isinstance(spec, dict) else {}
            jtype = spec.get("type", "string")
            if isinstance(jtype, list):
                jtype = next((t for t in jtype if t != "null"), "string")
            pytype = type_map.get(jtype, str) if isinstance(jtype, str) else str
            desc = spec.get("description", "")
            if not isinstance(desc, str):
                desc = ""
            if name in required:
                fields[str(name)] = (pytype, Field(..., description=desc))
            else:
                fields[str(name)] = (Optional[pytype], Field(None, description=desc))
        return create_model(f"{tool_id}_Args", **fields) if fields else _simple()
    except Exception:
        return _simple()


def resolve_tool_executor() -> Optional[Any]:
    """Resolve shared ToolExecutor instance from DI container."""
    try:
        from apps.tool.container import get_executor

        executor = get_executor()
        logger.debug(
            "Resolved tool executor type=%s module=%s has_invoke_sync=%s",
            type(executor).__name__,
            type(executor).__module__,
            hasattr(executor, "invoke_sync"),
        )
        return executor
    except Exception as e:
        logger.warning("Tool system unavailable, skipping tool binding: %s", e)
        return None


def resolve_tool_registry() -> Optional[Any]:
    """Resolve shared ToolRegistry instance from DI container."""
    try:
        from apps.tool.container import get_registry

        registry = get_registry()
        logger.debug(
            "Resolved tool registry type=%s module=%s",
            type(registry).__name__,
            type(registry).__module__,
        )
        return registry
    except Exception as e:
        logger.warning("Tool registry unavailable, schema hydration skipped: %s", e)
        return None


def hydrate_tool_spec(tool_spec: Dict[str, Any], tool_registry: Optional[Any]) -> Dict[str, Any]:
    """Merge a thin agent/workflow tool spec with the canonical ToolDef from registry."""
    if not isinstance(tool_spec, dict):
        return tool_spec

    tool_id = tool_spec.get("tool_id") or tool_spec.get("id")
    if not tool_id or tool_registry is None:
        return tool_spec

    try:
        tool_def = tool_registry.get(tool_id)
        if tool_def is None and hasattr(tool_registry, "get_by_name"):
            tool_def = tool_registry.get_by_name(tool_id)
    except Exception:
        logger.debug("Failed to hydrate tool spec for '%s' from registry", tool_id, exc_info=True)
        return tool_spec

    if tool_def is None:
        logger.debug("No registry ToolDef found for '%s'; using provided tool spec only", tool_id)
        return tool_spec

    hydrated_spec: Dict[str, Any] = {
        "tool_id": tool_def.tool_id,
        "id": tool_def.tool_id,
        "name": tool_def.name,
        "description": tool_def.description,
        "input_schema": tool_def.input_schema,
        "output_schema": tool_def.output_schema,
        "tool_type": getattr(tool_def.tool_type, "value", tool_def.tool_type),
        "execution_config": tool_def.execution_config,
        "metadata": tool_def.metadata,
    }
    hydrated_spec.update({k: v for k, v in tool_spec.items() if v is not None})

    logger.debug(
        "Hydrated tool spec for '%s': provided_keys=%s schema_keys=%s required=%s",
        tool_id,
        sorted(tool_spec.keys()),
        sorted(((hydrated_spec.get("input_schema") or {}).get("properties") or {}).keys()),
        list(((hydrated_spec.get("input_schema") or {}).get("required") or [])),
    )
    return hydrated_spec


def invoke_tool_with_compat(
    executor: Any,
    *,
    tool_id: str,
    input_data: Dict[str, Any],
    user_id: Optional[str],
    exec_context: Dict[str, Any],
    timeout_seconds: int,
):
    """Invoke a tool using invoke_sync when available, falling back to the async bridge."""
    if hasattr(executor, "invoke_sync"):
        return executor.invoke_sync(
            tool_id=tool_id,
            input_data=input_data,
            user_id=user_id,
            exec_context=exec_context,
            timeout_seconds=timeout_seconds,
        )

    if not hasattr(executor, "invoke"):
        raise AttributeError(
            f"Executor '{type(executor).__name__}' has neither invoke_sync nor invoke"
        )

    logger.warning(
        "Executor '%s' missing invoke_sync; falling back to async invoke bridge",
        type(executor).__name__,
    )
    context = {
        "user_id": user_id,
        "exec_context": exec_context,
    }
    return run_async(
        executor.invoke(tool_id=tool_id, input_data=input_data, context=context),
        timeout=timeout_seconds,
    )


def _normalize_tool_specs(tool_specs: Any) -> List[Dict[str, Any]]:
    """Coerce every accepted tool reference shape into a list of dict specs."""
    normalized: List[Dict[str, Any]] = []

    for tool_spec in tool_specs or []:
        # Agents store tools either as dict specs ({"tool_id": ...}) or as bare
        # tool-id strings, depending on which producer wrote the definition.
        if isinstance(tool_spec, str):
            normalized.append({"tool_id": tool_spec})
        elif isinstance(tool_spec, dict):
            normalized.append(tool_spec)
        else:
            logger.warning(
                "Skipping unsupported tool spec of type %s: %r",
                type(tool_spec).__name__,
                tool_spec,
            )

    return normalized


def _make_tool_wrapper(
    *,
    executor: Any,
    tool_id: str,
    tool_name: str,
    input_schema: Optional[dict],
    user_id: Optional[str],
    exec_context: Dict[str, Any],
    budget_state: Dict[str, Any],
    on_tool_start: Optional[OnToolStart],
    on_tool_end: Optional[OnToolEnd],
) -> Callable[..., str]:
    """Build the synchronous callable a StructuredTool will invoke."""

    def _start(kwargs: Dict[str, Any]) -> Optional[str]:
        if on_tool_start is None:
            return None
        try:
            return on_tool_start(tool_id, tool_name, kwargs)
        except Exception:
            logger.debug("on_tool_start hook failed for '%s'", tool_id, exc_info=True)
            return None

    def _end(step_id: Optional[str], payload: Any) -> None:
        if on_tool_end is None or step_id is None:
            return
        try:
            on_tool_end(step_id, payload)
        except Exception:
            logger.debug("on_tool_end hook failed for '%s'", tool_id, exc_info=True)

    def _validation_hint(attempt_no: int) -> str:
        return VALIDATION_RETRY_HINT if attempt_no <= 1 else VALIDATION_GIVE_UP_HINT

    def tool_func(**kwargs) -> str:
        """Execute an Echo tool via ToolExecutor under the per-agent budget policy."""
        logger.debug(
            "LangChain tool '%s' invoked with args=%s required=%s",
            tool_id,
            kwargs,
            list(((input_schema or {}).get("required") or [])) if isinstance(input_schema, dict) else [],
        )

        step_id = _start(kwargs)

        # The budget layer enforces what ToolCallLimitMiddleware cannot: dedupe
        # by input signature and a single corrective retry after a validation
        # failure. The middleware only counts calls.
        budget_error = reserve_tool_call(budget_state, tool_id, kwargs)
        attempt_no = int((budget_state.get("tool_attempts") or {}).get(tool_id, 1))
        if budget_error:
            error_text = format_tool_error_message(
                budget_error["error"],
                budget_error["error_type"],
            )
            _end(step_id, error_text)
            return error_text

        try:
            result = invoke_tool_with_compat(
                executor,
                tool_id=tool_id,
                input_data=kwargs,
                user_id=user_id,
                exec_context=exec_context,
                timeout_seconds=DEFAULT_TOOL_TIMEOUT_SECONDS,
            )

            if bool(getattr(result, "success", True)):
                # A tool can succeed at running and still decline the work,
                # asking for corrected input. Booking that as ANSWERED is what
                # made the tool's own "call me again with more content"
                # instruction impossible to follow.
                rejection = is_tool_rejection(result)
                if rejection:
                    record_tool_result(
                        budget_state,
                        success=False,
                        tool_id=tool_id,
                        outcome=TOOL_OUTCOME_VALIDATION_FAILED,
                        error_message=rejection,
                    )
                    retry_available = attempt_no <= 1
                    logger.info(
                        "\n"
                        "  ┌─ TOOL DECLINED ─ %s\n"
                        "  │  reason  : %s\n"
                        "  │  attempt : %d\n"
                        "  └─ %s",
                        tool_id,
                        rejection.splitlines()[0][:160],
                        attempt_no,
                        (
                            "one corrective retry is available"
                            if retry_available
                            else "no retry left; the agent must answer without it"
                        ),
                    )
                    # The tool's own guidance first, then what the platform will
                    # actually permit -- so the model is never told to retry when
                    # the budget is spent.
                    guidance = (
                        "Call this tool once more with substantially richer "
                        "content: full narrative per section, and tables where "
                        "the data supports them."
                        if retry_available
                        else "Do not call this tool again. Produce your answer "
                             "directly and state that the document could not be "
                             "generated from the available content."
                    )
                    text = f"{rejection}\n\n{guidance}"
                    _end(step_id, text)
                    return text

                record_tool_result(budget_state, success=True, tool_id=tool_id)
                _end(step_id, result)
                return format_tool_success_output(result)

            result_meta = getattr(result, "metadata", {}) or {}
            error_type = str(result_meta.get("error_type", "execution_error"))
            error_message = str(getattr(result, "error", None) or "Tool execution failed")
        except Exception as e:
            error_message = str(e)
            error_type = "validation_error" if is_validation_error(error_message, "") else "execution_error"
            logger.error("Tool '%s' execution failed: %s", tool_name, e)

        failed_validation = is_validation_error(error_message, error_type)
        record_tool_result(
            budget_state,
            success=False,
            tool_id=tool_id,
            outcome=TOOL_OUTCOME_VALIDATION_FAILED if failed_validation else None,
            error_message=error_message,
        )

        error_text = (
            _validation_hint(attempt_no)
            if failed_validation
            else format_tool_error_message(error_message, error_type)
        )
        _end(step_id, error_text)
        return error_text

    tool_func.__name__ = tool_id
    return tool_func


def build_langchain_tools(
    tool_specs: Any,
    exec_context: Optional[Dict[str, Any]] = None,
    user_id: Optional[str] = None,
    run_id: Optional[str] = None,
    tool_budget_state: Optional[Dict[str, Any]] = None,
    *,
    on_tool_start: Optional[OnToolStart] = None,
    on_tool_end: Optional[OnToolEnd] = None,
) -> List[Any]:
    """
    Build LangChain StructuredTool wrappers from Echo tool specifications.

    WHAT: Hydrates each tool reference against the registry, derives a Pydantic
          args schema and wraps ToolExecutor behind the per-agent budget policy.
    WHY:  Single tool-binding implementation for every agent execution path.
    INPUT: Tool ids or specs, execution context, user id, optional run id,
           optional shared budget state, optional observability hooks.
    OUTPUT: List of StructuredTool objects (empty when the tool system is down).

    Args:
        tool_specs: Tool ids or tool spec dicts from an agent definition.
        exec_context: Execution context forwarded to ToolExecutor.
        user_id: Authenticated user UUID used for tool credential resolution.
        run_id: Retained for caller-side correlation; unused here directly.
        tool_budget_state: Shared budget dict, created when omitted.
        on_tool_start: Optional hook invoked before execution, returns a step id.
        on_tool_end: Optional hook invoked with that step id and the outcome.
    """
    from langchain_core.tools import StructuredTool

    tools: List[Any] = []

    executor = resolve_tool_executor()
    if executor is None:
        return tools

    tool_registry = resolve_tool_registry()
    budget_state = ensure_tool_budget_state(tool_budget_state)
    resolved_context = exec_context or {}

    for tool_spec in _normalize_tool_specs(tool_specs):
        tool_spec = hydrate_tool_spec(tool_spec, tool_registry)

        tool_id = tool_spec.get("tool_id") or tool_spec.get("id")
        if not tool_id:
            logger.warning("Skipping tool spec without an identifier: %r", tool_spec)
            continue

        tool_name = tool_spec.get("name", tool_id)
        description = tool_spec.get("description", f"Tool: {tool_name}")
        input_schema = tool_spec.get("input_schema")

        wrapper_fn = _make_tool_wrapper(
            executor=executor,
            tool_id=tool_id,
            tool_name=tool_name,
            input_schema=input_schema,
            user_id=user_id,
            exec_context=resolved_context,
            budget_state=budget_state,
            on_tool_start=on_tool_start,
            on_tool_end=on_tool_end,
        )
        wrapper_fn.__doc__ = description

        resolved_schema = args_schema_from_input(tool_id, input_schema)
        _log_tool_schema(tool_id, resolved_schema)

        tools.append(
            StructuredTool.from_function(
                func=wrapper_fn,
                name=tool_id,
                description=description,
                args_schema=resolved_schema,
            )
        )

    logger.info("Built %d LangChain tools for agent", len(tools))
    return tools


def _log_tool_schema(tool_id: str, schema: Any) -> None:
    """
    Record what the model will actually be shown for this tool.

    WHY: A tool that is bound, reaches the wire and is never called looks
         identical in the logs to one the model simply chose not to use. The
         difference is the schema it was handed, and that was invisible -- it
         took repeated production failures to establish that the document
         generator's ``sections`` was arriving as an untyped, optional,
         null-defaulting array.

    Names and shapes only: no argument values, so nothing a user typed is
    logged. Never raises.
    """
    try:
        if not isinstance(schema, dict):
            logger.info("  tool %-28s args: generated model (no declared schema)", tool_id)
            return

        properties = schema.get("properties") or {}
        required = schema.get("required") or []
        shapes = []
        for name, spec in properties.items():
            if not isinstance(spec, dict):
                continue
            kind = spec.get("type", "?")
            if kind == "array":
                items = spec.get("items") or {}
                inner = items.get("properties")
                if inner:
                    shapes.append(f"{name}[{len(inner)} fields]")
                elif items.get("type"):
                    shapes.append(f"{name}[{items['type']}]")
                else:
                    # The defect this logging exists to surface.
                    shapes.append(f"{name}[UNSPECIFIED]")
            elif kind == "object" and spec.get("properties"):
                shapes.append(f"{name}{{{len(spec['properties'])} fields}}")
            else:
                shapes.append(f"{name}:{kind}")

        logger.info(
            "  tool %-28s args: %s", tool_id, ", ".join(shapes) or "(none)",
        )
        logger.info("  %-33s required: %s", "", ", ".join(required) or "(nothing)")
    except Exception:  # noqa: BLE001 -- diagnostics never fail a build
        logger.debug("Tool '%s': schema could not be described", tool_id, exc_info=True)
