"""
Tool Executor Module

This module provides the ToolExecutor class for executing tools registered
in the EchoAI system. It handles invocation of local Python functions,
MCP server calls, and external API requests.

The executor manages the lifecycle of tool execution including input validation,
execution routing, error handling, and output validation.
"""

import asyncio
import functools
import importlib
import inspect
import logging
import random
import time
from typing import Dict, Any, Optional

from echolib.types import ToolDef, ToolType, ToolResult

logger = logging.getLogger(__name__)


async def _with_retry(coro_factory, max_attempts: int = 3, base_delay: float = 0.5):
    """
    Retry an async operation with exponential backoff on transient errors.

    Only retries on errors that are likely transient (timeout, connection,
    runtime). Non-retryable errors propagate immediately.

    Args:
        coro_factory: Zero-arg callable that returns an awaitable each time
            it is called. Must create a NEW coroutine per attempt.
        max_attempts: Maximum number of attempts before giving up.
        base_delay: Initial delay in seconds; doubles each retry.

    Returns:
        The result of the awaitable on the first successful attempt.

    Raises:
        The last exception encountered after all attempts are exhausted.
    """
    last_exc = None
    for attempt in range(max_attempts):
        try:
            return await coro_factory()
        except (asyncio.TimeoutError, OSError, RuntimeError, ConnectionError) as exc:
            last_exc = exc
            if attempt < max_attempts - 1:
                delay = min(base_delay * (2 ** attempt) + random.uniform(0, base_delay), 5.0)
                logger.warning(
                    "Tool call failed (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1, max_attempts, delay, exc,
                )
                await asyncio.sleep(delay)
    raise last_exc


class ToolExecutor:
    """
    Executor for invoking tools across different execution contexts.

    The ToolExecutor is responsible for:
    - Routing tool invocations to the appropriate handler (local/MCP/API)
    - Validating inputs and outputs against tool schemas
    - Managing async execution and timeouts
    - Error handling and result formatting

    Attributes:
        registry: Reference to ToolRegistry for resolving tool definitions
        default_timeout: Default timeout for tool execution in seconds
        _local_instances: Cache for local tool class instances
    """

    def __init__(self, registry: Any, default_timeout: int = 60, connector_manager: Any = None):
        """
        Initialize the ToolExecutor.

        Args:
            registry: ToolRegistry instance for tool lookups
            default_timeout: Default execution timeout in seconds
            connector_manager: Optional ConnectorManager for managed tool execution
        """
        self.registry = registry
        self.default_timeout = default_timeout
        self.connector_manager = connector_manager
        self._local_instances: Dict[str, Any] = {}

        logger.info(
            f"ToolExecutor initialized with default timeout={default_timeout}s"
        )

    def _normalize_sync_context(
        self,
        *,
        context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        exec_context: Optional[Dict[str, Any]] = None,
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Normalize legacy sync-call arguments into the async invoke() context shape."""
        normalized = dict(context or {})

        if user_id is not None and "user_id" not in normalized:
            normalized["user_id"] = user_id

        if extra_context:
            normalized.update({key: value for key, value in extra_context.items() if value is not None})

        if not exec_context:
            return normalized

        try:
            from apps.workflow.aura_pipeline.middleware import tool_context_from_exec

            return tool_context_from_exec(exec_context, normalized)
        except Exception:
            logger.debug("Falling back to raw exec_context in sync tool invocation", exc_info=True)
            normalized.setdefault("exec_context", exec_context)
            return normalized

    def _run_sync_bridge(self, coro: Any, *, timeout: int) -> Any:
        """Execute an async tool call from sync runtimes via the shared tool async bridge.

        The bridge used to live in ``apps.workflow.runtime.langchain_adapter``,
        which made the tool app depend on the workflow app. It now lives beside
        this executor, its primary consumer.
        """
        from apps.tool.async_bridge import run_async

        return run_async(coro, timeout=timeout)

    def invoke_sync(
        self,
        tool_id: str,
        input_data: Dict[str, Any],
        *,
        context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        exec_context: Optional[Dict[str, Any]] = None,
        timeout_seconds: Optional[int] = None,
        **extra_context: Any,
    ) -> ToolResult:
        """Backward-compatible sync facade for runtimes that cannot await invoke()."""
        resolved_timeout = timeout_seconds or self.default_timeout
        normalized_context = self._normalize_sync_context(
            context=context,
            user_id=user_id,
            exec_context=exec_context,
            extra_context=extra_context,
        )
        return self._run_sync_bridge(
            self.invoke(tool_id=tool_id, input_data=input_data, context=normalized_context),
            timeout=resolved_timeout,
        )

    def _get_connector_manager(self):
        """
        Get ConnectorManager instance. Uses injected instance first,
        falls back to lazy DI resolution.

        Returns:
            ConnectorManager instance or None if unavailable
        """
        if self.connector_manager:
            return self.connector_manager
        try:
            from echolib.di import container
            return container.resolve('connector.manager')
        except (KeyError, ImportError):
            return None

    def _resolve_timeout_seconds(self, tool: ToolDef) -> int:
        config = tool.execution_config or {}
        try:
            requested = int(config.get("timeout_seconds", self.default_timeout))
        except (TypeError, ValueError):
            requested = self.default_timeout
        return max(1, requested)

    def _schema_allows_null(self, schema: Any) -> bool:
        if not isinstance(schema, dict):
            return False

        schema_type = schema.get("type")
        if schema_type == "null":
            return True
        if isinstance(schema_type, list) and "null" in schema_type:
            return True

        for key in ("oneOf", "anyOf", "allOf"):
            options = schema.get(key)
            if isinstance(options, list) and any(self._schema_allows_null(option) for option in options):
                return True

        return False

    def _normalize_input_for_schema(self, schema: Any, value: Any) -> Any:
        if not isinstance(schema, dict):
            return value

        schema_type = schema.get("type")
        properties = schema.get("properties")
        if (
            (schema_type == "object" or (isinstance(schema_type, list) and "object" in schema_type) or isinstance(properties, dict))
            and isinstance(value, dict)
        ):
            required = set(schema.get("required", []))
            normalized: Dict[str, Any] = {}
            for key, item in value.items():
                field_schema = properties.get(key, {}) if isinstance(properties, dict) else {}
                if item is None and key not in required and not self._schema_allows_null(field_schema):
                    continue
                normalized[key] = self._normalize_input_for_schema(field_schema, item)
            return normalized

        items_schema = schema.get("items")
        if (
            (schema_type == "array" or (isinstance(schema_type, list) and "array" in schema_type) or isinstance(items_schema, dict))
            and isinstance(value, list)
            and isinstance(items_schema, dict)
        ):
            return [self._normalize_input_for_schema(items_schema, item) for item in value]

        return value

    async def invoke(
        self,
        tool_id: str,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> ToolResult:
        """
        Invoke a tool with the given input data.

        This is the main entry point for tool execution. It handles:
        - Tool lookup (user-scoped for connector visibility)
        - Input validation
        - Routing to appropriate execution handler
        - Output validation
        - Error handling

        Args:
            tool_id: Unique identifier of the tool to invoke
            input_data: Input parameters for the tool
            context: Optional context (agent_id, workflow_id, user_id, etc.)

        Returns:
            ToolResult with output data and execution metadata
        """
        start_time = time.time()
        context = context or {}
        user_id = context.get("user_id")

        # ── AURA execution primitives (opt-in; no-op when flags absent) ──
        # Simulation (P3) short-circuits real execution; policy gate (P4) can
        # deny a tool before it runs. Guarded so it can never break execution.
        if context.get("aura_simulation") or context.get("aura_policy") or context.get("execution_mode") == "simulation":
            try:
                from apps.workflow.aura_pipeline.middleware import precheck
                _short, _payload = precheck(tool_id, input_data, context)
                if _short and _payload is not None:
                    return ToolResult(
                        name=tool_id, tool_id=tool_id, output=_payload, success=True,
                        error=None, metadata={"simulated": True, "context": context},
                    )
                if _short:
                    return ToolResult(
                        name=tool_id, tool_id=tool_id, output={}, success=False,
                        error=f"Policy gate denied tool '{tool_id}'",
                        metadata={"policy_denied": True, "context": context},
                    )
            except Exception:
                logger.debug("AURA precheck skipped (non-fatal)", exc_info=True)

        # Get tool from registry (user-scoped for connector visibility)
        if user_id:
            tool = await self.registry.get_async_for_user(tool_id, user_id)
        else:
            tool = await self.registry.get_async(tool_id)
        if not tool:
            logger.warning(f"Tool '{tool_id}' not found in registry")
            return ToolResult(
                name="unknown",
                tool_id=tool_id,
                output={},
                success=False,
                error=f"Tool '{tool_id}' not found",
                metadata={"context": context}
            )

        logger.info(f"Invoking tool '{tool.name}' (id={tool_id}, type={tool.tool_type})")
        timeout_seconds = self._resolve_timeout_seconds(tool)
        normalized_input_data = self._normalize_input_for_schema(tool.input_schema, input_data)
        if logger.isEnabledFor(logging.DEBUG):
            raw_keys = sorted(input_data.keys()) if isinstance(input_data, dict) else []
            normalized_keys = sorted(normalized_input_data.keys()) if isinstance(normalized_input_data, dict) else []
            dropped_keys = [key for key in raw_keys if key not in normalized_keys]
            logger.debug(
                "Tool '%s' payload normalization: raw_keys=%s normalized_keys=%s dropped_keys=%s raw_input=%s normalized_input=%s",
                tool.name,
                raw_keys,
                normalized_keys,
                dropped_keys,
                input_data,
                normalized_input_data,
            )

        # OTel tracing — imported lazily so the module works without OTel
        try:
            from echolib.otel import trace_operation, tool_metrics, get_metrics_collector, _get_user_id
        except ImportError:
            trace_operation = None
            tool_metrics = None
            get_metrics_collector = None
            _get_user_id = lambda: "anonymous"

        try:
            _uid = _get_user_id()
        except Exception:
            _uid = "anonymous"

        # Wrap entire execution inside an OTel span
        from contextlib import nullcontext
        _span_ctx = nullcontext()
        if trace_operation:
            _span_ctx = trace_operation("tool.invoke", {
                "tool.name": tool.name,
                "tool.type": tool.tool_type.value,
                "tool.id": tool_id,
                "user.id": _uid,
            })

        with _span_ctx:
          try:
            # Validate input against schema
            self._validate_input(tool, normalized_input_data)

            # Route to appropriate executor based on tool type
            if tool.tool_type == ToolType.LOCAL:
                result = await self._execute_local(
                    tool, normalized_input_data, timeout_seconds=timeout_seconds, context=context
                )
            elif tool.tool_type == ToolType.MCP:
                result = await self._execute_mcp(tool, normalized_input_data, context)
            elif tool.tool_type == ToolType.API:
                result = await self._execute_api(tool, normalized_input_data)
            else:
                raise ValueError(f"Unknown tool type: {tool.tool_type}")

            # Validate output against schema (soft validation - log warning only)
            self._validate_output(tool, result)

            execution_time = time.time() - start_time

            # Record OTel tool metrics
            try:
                if tool_metrics and hasattr(tool_metrics, "executions_total"):
                    attrs = {"tool_name": tool.name, "tool_type": tool.tool_type.value, "status": "success"}
                    tool_metrics.executions_total.add(1, attrs)
                    tool_metrics.execution_duration.record(execution_time * 1000, attrs)
                if get_metrics_collector:
                    get_metrics_collector().record_tool_call(
                        tool_name=tool.name, tool_type=tool.tool_type.value,
                        duration_ms=execution_time * 1000, status="success",
                        user_id=_uid,
                    )
            except Exception:
                pass

            logger.info(
                f"Tool '{tool.name}' executed successfully in {execution_time:.3f}s"
            )

            return ToolResult(
                name=tool.name,
                tool_id=tool_id,
                output=result,
                success=True,
                error=None,
                metadata={
                    "execution_time": execution_time,
                    "tool_type": tool.tool_type.value,
                    "tool_version": tool.version,
                    "context": context
                }
            )

          except ValueError as e:
            execution_time = time.time() - start_time
            logger.warning(f"Tool '{tool.name}' validation error: {e}")
            return ToolResult(
                name=tool.name,
                tool_id=tool_id,
                output={},
                success=False,
                error=str(e),
                metadata={
                    "execution_time": execution_time,
                    "error_type": "validation_error",
                    "context": context
                }
            )

          except asyncio.TimeoutError:
            execution_time = time.time() - start_time
            logger.error(f"Tool '{tool.name}' execution timed out after {execution_time:.3f}s")
            return ToolResult(
                name=tool.name,
                tool_id=tool_id,
                output={},
                success=False,
                error=f"Execution timed out after {timeout_seconds}s",
                metadata={
                    "execution_time": execution_time,
                    "error_type": "timeout_error",
                    "context": context
                }
            )

          except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Tool '{tool.name}' execution failed: {e}", exc_info=True)
            # Record error metrics
            try:
                if tool_metrics and hasattr(tool_metrics, "errors_total"):
                    attrs = {"tool_name": tool.name, "tool_type": tool.tool_type.value, "error_type": "execution_error"}
                    tool_metrics.errors_total.add(1, attrs)
                if get_metrics_collector:
                    get_metrics_collector().record_tool_call(
                        tool_name=tool.name, tool_type=tool.tool_type.value,
                        duration_ms=execution_time * 1000, status="error",
                        user_id=_uid,
                    )
            except Exception:
                pass
            return ToolResult(
                name=tool.name,
                tool_id=tool_id,
                output={},
                success=False,
                error=f"Execution failed: {str(e)}",
                metadata={
                    "execution_time": execution_time,
                    "error_type": "execution_error",
                    "context": context
                }
            )

    def _validate_input(self, tool: ToolDef, input_data: Dict[str, Any]) -> None:
        """
        Validate input data against tool's input schema.

        Raises:
            ValueError: If validation fails with detailed error message
        """
        if not tool.input_schema:
            logger.debug(f"Tool '{tool.name}' has no input schema, skipping validation")
            return

        try:
            import jsonschema
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(
                    "Validating tool '%s' input against schema: required=%s input=%s",
                    tool.name,
                    list((tool.input_schema or {}).get("required", [])) if isinstance(tool.input_schema, dict) else [],
                    input_data,
                )
            jsonschema.validate(instance=input_data, schema=tool.input_schema)
            logger.debug(f"Input validation passed for tool '{tool.name}'")

        except jsonschema.ValidationError as e:
            error_path = " -> ".join(str(p) for p in e.absolute_path) if e.absolute_path else "root"
            error_msg = f"Input validation failed at '{error_path}': {e.message}"
            logger.warning(f"Tool '{tool.name}': {error_msg}")
            raise ValueError(error_msg)

        except jsonschema.SchemaError as e:
            error_msg = f"Invalid input schema for tool '{tool.name}': {e.message}"
            logger.error(error_msg)
            raise ValueError(error_msg)

    def _validate_output(self, tool: ToolDef, output_data: Dict[str, Any]) -> None:
        """
        Validate output data against tool's output schema.

        Output validation is softer — logs warnings but doesn't fail.
        """
        if not tool.output_schema:
            logger.debug(f"Tool '{tool.name}' has no output schema, skipping validation")
            return

        try:
            import jsonschema
            jsonschema.validate(instance=output_data, schema=tool.output_schema)
            logger.debug(f"Output validation passed for tool '{tool.name}'")

        except jsonschema.ValidationError as e:
            error_path = " -> ".join(str(p) for p in e.absolute_path) if e.absolute_path else "root"
            logger.warning(
                f"Tool '{tool.name}' output validation warning at '{error_path}': {e.message}"
            )

        except jsonschema.SchemaError as e:
            logger.warning(
                f"Invalid output schema for tool '{tool.name}': {e.message}"
            )

    async def _execute_local(
        self,
        tool: ToolDef,
        input_data: Dict[str, Any],
        *,
        timeout_seconds: int,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a local Python function tool.

        Dynamically imports the specified module, instantiates the class
        (with caching), and calls the method with input_data.

        Args:
            tool: ToolDef with a local ``execution_config``.
            input_data: Validated input parameters.
            timeout_seconds: Per-call ceiling.
            context: Optional execution context. Forwarded only to methods that
                declare a ``context`` parameter -- see ``_context_kwargs``.
        """
        config = tool.execution_config
        if not config:
            raise ValueError(f"Tool '{tool.name}' has no execution_config")

        module_path = config.get("module")
        class_name = config.get("class")
        method_name = config.get("method")

        if not all([module_path, class_name, method_name]):
            raise ValueError(
                f"Tool '{tool.name}' execution_config missing required fields: "
                f"module={module_path}, class={class_name}, method={method_name}"
            )

        logger.debug(
            f"Executing local tool: {module_path}.{class_name}.{method_name}"
        )

        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise ImportError(
                f"Cannot import module '{module_path}' for tool '{tool.name}': {e}"
            )

        try:
            cls = getattr(module, class_name)
        except AttributeError:
            raise AttributeError(
                f"Class '{class_name}' not found in module '{module_path}'"
            )

        cache_key = f"{module_path}.{class_name}"

        if cache_key not in self._local_instances:
            try:
                self._local_instances[cache_key] = cls()
                logger.debug(f"Created new instance for {cache_key}")
            except Exception as e:
                raise RuntimeError(
                    f"Cannot instantiate class '{class_name}': {e}"
                )

        instance = self._local_instances[cache_key]

        try:
            method = getattr(instance, method_name)
        except AttributeError:
            raise AttributeError(
                f"Method '{method_name}' not found in class '{class_name}'"
            )

        # Execution context, forwarded only to methods that ask for it. A local
        # tool that needs to know who is calling, or which session's files it may
        # read, previously had no way to find out: ``context`` reached
        # ``invoke()`` and stopped there, so the only way to give a tool
        # session-scoped state was to build a bespoke wrapper that closed over
        # it -- which is exactly what the deleted CrewAI executor did for
        # ``data_analyst``. Opt-in by signature, so every existing tool is called
        # byte-identically.
        ctx_kwargs = self._context_kwargs(method, context, input_data)

        # Execute method (handle both sync and async)
        try:
            if asyncio.iscoroutinefunction(method):
                if self._supports_kwargs(method, input_data):
                    result = await asyncio.wait_for(
                        method(**input_data, **ctx_kwargs),
                        timeout=timeout_seconds
                    )
                else:
                    result = await asyncio.wait_for(
                        method(input_data, **ctx_kwargs),
                        timeout=timeout_seconds
                    )
            else:
                loop = asyncio.get_event_loop()
                call = (
                    functools.partial(method, **input_data, **ctx_kwargs)
                    if self._supports_kwargs(method, input_data)
                    else functools.partial(method, input_data, **ctx_kwargs)
                )
                result = await asyncio.wait_for(
                    loop.run_in_executor(None, call),
                    timeout=timeout_seconds
                )

        except asyncio.TimeoutError:
            raise asyncio.TimeoutError(
                f"Tool '{tool.name}' execution timed out"
            )

        # Normalize result to dict
        return self._normalize_result(result)

    def _context_kwargs(
        self,
        method: Any,
        context: Optional[Dict[str, Any]],
        input_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Decide whether to pass the execution context to a local tool method.

        Only when the method declares a ``context`` parameter and the tool's own
        schema does not already own that name -- a tool whose input schema has a
        ``context`` field means something else by it, and shadowing it would
        replace the caller's value.
        """
        if not context:
            return {}
        if isinstance(input_data, dict) and "context" in input_data:
            return {}

        try:
            sig = inspect.signature(method)
        except (TypeError, ValueError):
            return {}

        return {"context": context} if "context" in sig.parameters else {}

    def _supports_kwargs(self, method: Any, input_data: Dict[str, Any]) -> bool:
        """Return True if the callable can accept the provided keyword arguments."""
        if not isinstance(input_data, dict):
            return False

        try:
            sig = inspect.signature(method)
        except (TypeError, ValueError):
            return False

        params = list(sig.parameters.values())
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params):
            return True

        allowed = {
            p.name
            for p in params
            if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
        }
        return all(k in allowed for k in input_data.keys())

    async def _execute_mcp(
        self,
        tool: ToolDef,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute tool via MCP (Model Context Protocol) server.

        Args:
            tool: ToolDef containing execution_config with connector_id
            input_data: Validated input parameters
            context: Optional execution context with user_id

        Returns:
            Dict containing the MCP response
        """
        config = tool.execution_config
        if not config:
            raise ValueError(f"Tool '{tool.name}' has no execution_config")

        connector_id = config.get("connector_id")
        if not connector_id:
            raise ValueError(
                f"Tool '{tool.name}' execution_config missing 'connector_id'"
            )

        logger.debug(f"Executing MCP tool via connector '{connector_id}'")
        context = context or {}
        user_id = context.get("user_id")
        if not user_id:
            try:
                from echolib.security import get_current_user_id
                user_id = get_current_user_id()
            except Exception:
                user_id = None

        # MANAGED MODE: Delegate to ConnectorManager when available
        cm = self._get_connector_manager()
        if cm is not None:
            remote_tool_name = config.get("remote_tool_name")
            mcp_payload = input_data
            if remote_tool_name:
                mcp_payload = {
                    "tool_name": remote_tool_name,
                    "arguments": input_data,
                }

            # mcp.invoke_async() is ASYNC — await directly, no thread wrapping.
            # Wrapped with retry for transient failures (timeout, connection).
            result = await _with_retry(
                lambda: cm.mcp.invoke_async(
                    connector_id=connector_id,
                    payload=mcp_payload,
                    context=context,
                    user_id=user_id,
                )
            )
            return result if isinstance(result, dict) else {"result": result}

        # Legacy fallback: direct HTTP call (only if ConnectorManager unavailable)
        payload = {
            "connector_id": connector_id,
            "payload": input_data
        }

        try:
            import httpx

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "http://localhost:8000/connectors/mcp/invoke",
                    json=payload,
                    timeout=self.default_timeout
                )

                if response.status_code == 200:
                    return response.json()
                else:
                    error_detail = response.text
                    raise RuntimeError(
                        f"MCP call failed with status {response.status_code}: {error_detail}"
                    )

        except httpx.TimeoutException:
            raise asyncio.TimeoutError(
                f"MCP call to connector '{connector_id}' timed out"
            )

        except httpx.HTTPError as e:
            raise RuntimeError(f"MCP HTTP error: {e}")

        except ImportError:
            raise ImportError(
                "httpx package is required for MCP tool execution. "
                "Install it with: pip install httpx"
            )

    async def _execute_api(self, tool: ToolDef, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute tool via direct HTTP API call.

        Args:
            tool: ToolDef containing execution_config with url, method, headers
            input_data: Validated input parameters

        Returns:
            Dict containing the API response
        """
        config = tool.execution_config
        if not config:
            raise ValueError(f"Tool '{tool.name}' has no execution_config")

        # MANAGED MODE: Delegate to ConnectorManager when connector_id is present
        if "connector_id" in config:
            cm = self._get_connector_manager()
            if cm is not None:
                # api.invoke() is now ASYNC (DB-first APIConnectorService).
                # Resolve user_id from context or security module.
                user_id = None
                try:
                    from echolib.security import get_current_user_id
                    user_id = get_current_user_id()
                except Exception:
                    pass

                if user_id is None:
                    raise RuntimeError(
                        f"Tool '{tool.name}' requires user context for managed API execution"
                    )

                result = await _with_retry(
                    lambda: cm.api.invoke(
                        config["connector_id"],
                        user_id=user_id,
                        body=input_data,
                    )
                )
                if hasattr(result, "model_dump"):
                    result = result.model_dump()
                return result if isinstance(result, dict) else {"result": result}
            else:
                raise RuntimeError(
                    f"Tool '{tool.name}' requires ConnectorManager for managed API execution, "
                    "but ConnectorManager is not available"
                )

        # Legacy/Manual API tool logic (Raw HTTP via httpx)
        url = config.get("url")
        if not url:
            raise ValueError(
                f"Tool '{tool.name}' execution_config missing 'url'"
            )

        http_method = config.get("method", "POST").upper()
        headers = config.get("headers", {})
        timeout = config.get("timeout", self.default_timeout)

        logger.debug(f"Executing API tool: {http_method} {url}")

        try:
            import httpx

            async with httpx.AsyncClient() as client:
                if http_method == "GET":
                    response = await client.get(
                        url,
                        params=input_data,
                        headers=headers,
                        timeout=timeout
                    )
                else:
                    response = await client.request(
                        method=http_method,
                        url=url,
                        json=input_data,
                        headers=headers,
                        timeout=timeout
                    )

                if response.status_code >= 200 and response.status_code < 300:
                    try:
                        return response.json()
                    except Exception:
                        return {"response": response.text}
                else:
                    error_detail = response.text
                    raise RuntimeError(
                        f"API call failed with status {response.status_code}: {error_detail}"
                    )

        except httpx.TimeoutException:
            raise asyncio.TimeoutError(f"API call to '{url}' timed out")

        except httpx.HTTPError as e:
            raise RuntimeError(f"API HTTP error: {e}")

        except ImportError:
            raise ImportError(
                "httpx package is required for API tool execution. "
                "Install it with: pip install httpx"
            )

    def _normalize_result(self, result: Any) -> Dict[str, Any]:
        """
        Normalize tool execution result to a dictionary.
        """
        if result is None:
            return {"result": None}

        if isinstance(result, dict):
            return result

        if hasattr(result, 'model_dump'):
            return result.model_dump()

        if hasattr(result, 'dict') and callable(result.dict):
            return result.dict()

        return {"result": result}

    def clear_instance_cache(self) -> int:
        """
        Clear the local tool instance cache.

        Returns:
            Number of instances cleared
        """
        count = len(self._local_instances)
        self._local_instances.clear()
        logger.info(f"Cleared {count} cached tool instances")
        return count

    def get_cached_instances(self) -> Dict[str, str]:
        """
        Get list of cached tool instances.

        Returns:
            Dict mapping cache_key to class name
        """
        return {
            key: type(instance).__name__
            for key, instance in self._local_instances.items()
        }
