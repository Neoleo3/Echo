import logging
from typing import Any, Dict, List, Optional

from echolib.types import ToolDef, ToolResult

from .executor import ToolExecutor
from .registry import ToolRegistry

logger = logging.getLogger(__name__)


class ToolService:
    """Async facade for tool-management routes.

    This service keeps the `/tools/*` API on a stable async contract while
    delegating canonical tool ownership to `ToolRegistry` and `ToolExecutor`.
    Workflow and agent runtime should continue using the registry and executor
    directly.
    """

    def __init__(self, registry: ToolRegistry, executor: ToolExecutor) -> None:
        self.registry = registry
        self.executor = executor

    async def create_tool(
        self,
        tool: ToolDef,
        user_id: Optional[str] = None,
    ) -> Dict[str, str]:
        return self.registry.register(tool, user_id=user_id)

    async def list_tools(self, user_id: Optional[str] = None) -> List[ToolDef]:
        return self.registry.list_all_for_user(user_id)

    async def invoke_tool(
        self,
        tool_key: str,
        args: Optional[Dict[str, Any]],
        user_id: Optional[str] = None,
        *,
        resolve_by: str = "tool_id",
        context: Optional[Dict[str, Any]] = None,
    ) -> ToolResult:
        if resolve_by == "tool_id":
            tool = (
                await self.registry.get_async_for_user(tool_key, user_id)
                if user_id
                else await self.registry.get_async(tool_key)
            )
        elif resolve_by == "name":
            tool = (
                await self.registry.get_by_name_async_for_user(tool_key, user_id)
                if user_id
                else await self.registry.get_by_name_async(tool_key)
            )
        else:
            raise ValueError(f"Unsupported resolve_by mode: {resolve_by}")

        if not tool:
            raise ValueError(f"Tool '{tool_key}' not found")

        invoke_context = dict(context or {})
        if user_id and "user_id" not in invoke_context:
            invoke_context["user_id"] = user_id

        logger.debug(
            "Invoking tool via ToolService facade: tool_key=%s resolved_tool_id=%s resolve_by=%s",
            tool_key,
            tool.tool_id,
            resolve_by,
        )

        return await self.executor.invoke(
            tool.tool_id,
            args or {},
            context=invoke_context,
        )
