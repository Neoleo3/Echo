"""
Request and response contracts for the Agent Trust API.

Two numbers define an agent: ``trust_score`` (0-100) and ``trust_state``.
Everything else is explanation -- the per-check breakdown and the list of
unearned points -- shaped so the UI can render it without needing to know how
the score was produced.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

TrustState = Literal["UNREVIEWED", "TRUSTED", "NEEDS_REVIEW", "HIGH_RISK"]
CheckStatus = Literal["pass", "partial", "fail", "not_configured", "not_verified"]
AssertionType = Literal["semantic_judge", "keyword_match"]


# ---------------------------------------------------------------------------
# Shared fragments
# ---------------------------------------------------------------------------


class Owner(BaseModel):
    user_id: str
    name: Optional[str] = None
    email: Optional[str] = None


class TrustCheck(BaseModel):
    """One slice of the 100-point score."""

    key: str
    label: str
    status: CheckStatus
    points_earned: int
    points_possible: int
    points_available: int = Field(description="Points the user can still win back.")
    summary: str
    fix: Optional[str] = None
    detail: Dict[str, Any] = Field(default_factory=dict)


class Improvement(BaseModel):
    key: str
    label: str
    points: int = Field(description="Exact score increase once this is resolved.")
    status: CheckStatus
    reason: str
    action: str


class AgentUsage(BaseModel):
    window: str
    total_runs: int
    input_tokens: int
    output_tokens: int
    total_tokens: int
    total_cost_usd: float
    cost_is_estimated: bool = Field(
        description="True when cost was priced from telemetry because no cost record exists yet."
    )
    last_used_at: Optional[str] = None


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


class AttentionItem(BaseModel):
    agent_id: str
    name: str
    trust_score: Optional[int] = None
    trust_state: TrustState
    reason: str


class TrendPoint(BaseModel):
    date: str
    average_trust_score: int
    reviews: int


class DashboardResponse(BaseModel):
    total_agents: int
    average_trust_score: Optional[int] = None
    by_trust_state: Dict[str, int]
    needs_attention: List[AttentionItem]
    needs_attention_total: int
    trend: List[TrendPoint]


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------


class AgentListItem(BaseModel):
    agent_id: str
    name: str
    owner: Owner
    environment: Optional[str] = None
    trust_score: Optional[int] = None
    trust_state: TrustState
    last_reviewed_at: Optional[str] = None
    stale: bool
    total_runs: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    last_used_at: Optional[str] = None
    updated_at: Optional[str] = None


class AgentListResponse(BaseModel):
    total: int
    limit: int
    offset: int
    items: List[AgentListItem]


class WorkflowRef(BaseModel):
    workflow_id: str
    name: Optional[str] = None
    status: Optional[str] = None


class AppRef(BaseModel):
    application_id: str
    link: Literal["direct", "via_workflow"]


class UsageSites(BaseModel):
    workflows: List[WorkflowRef]
    apps: List[AppRef]


class AgentOverviewResponse(BaseModel):
    agent_id: str
    name: str
    description: Optional[str] = None
    owner: Owner
    environment: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    trust_score: Optional[int] = None
    trust_state: TrustState
    last_reviewed_at: Optional[str] = None
    stale: bool
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    checks: List[TrustCheck]
    improvements: List[Improvement]
    open_alerts: int
    usage: AgentUsage
    used_in: UsageSites


# ---------------------------------------------------------------------------
# Agent review workspace
# ---------------------------------------------------------------------------


class AssignedPolicy(BaseModel):
    policy_id: str
    name: str
    framework: Optional[str] = None
    severity: Optional[str] = None
    assigned_by: Optional[str] = None
    assigned_at: Optional[str] = None


class SuiteRunSummary(BaseModel):
    status: str
    total: int
    passed: int
    failed: int
    results: List[Dict[str, Any]] = Field(default_factory=list)
    at: Optional[str] = None


class AssignedSuite(BaseModel):
    suite_id: str
    name: str
    description: Optional[str] = None
    test_count: int
    source: Literal["user", "ai"]
    last_run: Optional[SuiteRunSummary] = None


class SecurityProbe(BaseModel):
    attack_type: str
    attack_name: str
    blocked: bool
    verdict: Optional[str] = None
    rationale: Optional[str] = None


class SecuritySummary(BaseModel):
    total_probes: int
    blocked: int
    last_scan_at: Optional[str] = None
    probes: List[SecurityProbe]


class CredentialSummary(BaseModel):
    evaluated_at: Optional[str] = None
    declared: List[Dict[str, Any]] = Field(default_factory=list)
    drift: List[Dict[str, Any]] = Field(default_factory=list)


class AgentReviewResponse(BaseModel):
    agent_id: str
    name: str
    trust_score: Optional[int] = None
    trust_state: TrustState
    last_reviewed_at: Optional[str] = None
    stale: bool
    checks: List[TrustCheck]
    improvements: List[Improvement]
    policies: List[AssignedPolicy]
    test_suites: List[AssignedSuite]
    security: SecuritySummary
    credentials: CredentialSummary


# ---------------------------------------------------------------------------
# Timeline
# ---------------------------------------------------------------------------


class TimelineEntry(BaseModel):
    seq: int
    event: str
    category: str
    title: str
    at: str
    actor: Optional[str] = None
    outcome: Optional[str] = None
    severity: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)
    hash: str
    parent_hash: str


class TimelineResponse(BaseModel):
    entries: List[TimelineEntry]
    next_cursor: Optional[int] = None
    has_more: bool


# ---------------------------------------------------------------------------
# Review execution
# ---------------------------------------------------------------------------


class RecommendPoliciesRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    force_refresh: bool = False


class ReviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    agent_ids: List[str] = Field(
        min_length=1,
        max_length=25,
        description="One id for a single review, many for a bulk review.",
    )


class ReviewResult(BaseModel):
    agent_id: str
    name: Optional[str] = None
    status: Literal["reviewed", "failed"]
    trust_score: Optional[int] = None
    trust_state: Optional[TrustState] = None
    previous_score: Optional[int] = None
    error: Optional[str] = None


class ReviewResponse(BaseModel):
    reviewed: int
    failed: int
    correlation_id: str
    results: List[ReviewResult]


# ---------------------------------------------------------------------------
# Functional test suites
# ---------------------------------------------------------------------------


class TestCase(BaseModel):
    """One functional test -- these are the fields a user fills in."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=200, description="Short label for the test.")
    input: str = Field(min_length=1, description="The message sent to the agent.")
    expected: str = Field(
        min_length=1,
        description="The property the answer must have, not a specific fact.",
    )
    assertion_type: AssertionType = Field(
        default="semantic_judge",
        description=(
            "'semantic_judge' grades meaning with an LLM; "
            "'keyword_match' is a plain substring check."
        ),
    )
    keywords: List[str] = Field(
        default_factory=list,
        description="Required only when assertion_type is 'keyword_match'.",
    )
    rationale: Optional[str] = Field(default=None, description="Why this test matters.")


class TestSuiteCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = Field(default=None, max_length=1000)
    test_cases: List[TestCase] = Field(min_length=1, max_length=50)
    source: Literal["user", "ai"] = Field(
        default="user",
        description="Set to 'ai' when saving an accepted recommendation.",
    )


class TestSuiteResponse(BaseModel):
    suite_id: str
    agent_id: str
    name: str
    description: Optional[str] = None
    test_count: int
    source: Literal["user", "ai"]


class RecommendedSuiteResponse(BaseModel):
    agent_id: str
    suggested_name: str
    grounded_on: Dict[str, List[Optional[str]]] = Field(
        description="The agent facts the recommendation was allowed to use."
    )
    test_cases: List[TestCase]


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------


class BackfillResponse(BaseModel):
    profiles: Dict[str, int]
    cost_records: Dict[str, int]


class ChainVerificationResponse(BaseModel):
    valid: bool
    total_entries: Optional[int] = None
    broken_at_id: Optional[int] = None
    reason: Optional[str] = None


class BudgetCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    scope: Literal["org", "department", "agent"]
    scope_id: Optional[str] = None
    limit_usd: float = Field(gt=0)
    period: Literal["daily", "weekly", "monthly"] = "monthly"
    alert_threshold_pct: int = Field(default=80, ge=1, le=100)
    hard_stop: bool = False


class BudgetResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    scope: str
    scope_id: Optional[str] = None
    limit_usd: float
    period: str
    alert_threshold_pct: int
    hard_stop: bool
    is_active: bool
