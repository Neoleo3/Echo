from echolib.di import container
from echolib.services import RAGService
from echolib.service.rag.vector_store import VectorDocumentStore
from echolib.service.rag.graph_rag_service import GraphDocumentStore, GraphRAGService
from echolib.service.rag.hybrid_rag_service import HybridRAGService
from echolib.service.rag.trad_rag import TraditionalRAGService
from echolib.service.rag.session_rag_manager import SessionRAGManager

from apps.rag.session_documents import DurableSessionDocumentManager

# Traditional RAG with Vector Store (FAISS + OpenAI embeddings)
_vector_store = VectorDocumentStore(
    embedding_model="embedding_text",
    dimension=1536
)
container.register('rag.store', lambda: _vector_store)
container.register('rag.service', lambda: RAGService(_vector_store))

# # Graph RAG
# _graph_store = GraphDocumentStore()
# container.register('rag.graph_store', lambda: _graph_store)
# container.register('rag.graph_service', lambda: GraphRAGService(_graph_store))

# # Hybrid RAG (combines vector + graph)
# container.register('rag.hybrid_service', lambda: HybridRAGService(_vector_store, _graph_store))

# Traditional RAG (file-based with Azure OpenAI)
_traditional_rag_service = TraditionalRAGService()
container.register('rag.traditional_service', lambda: _traditional_rag_service)

# Session-scoped RAG (for app chat file uploads).
#
# Documents uploaded into a conversation are stored in Postgres, not on local
# disk: the platform runs more than one replica with no shared filesystem, so a
# disk-backed index was invisible to every other replica and gone after any
# restart — while the application_documents row survived and kept reporting the
# document as ready. The disk-backed manager is retained and composed in, so
# any session indexed before this change keeps answering until it is
# re-uploaded.
_legacy_session_rag_manager = SessionRAGManager()
_session_rag_manager = DurableSessionDocumentManager(legacy=_legacy_session_rag_manager)
container.register('rag.session_manager', lambda: _session_rag_manager)
container.register('rag.session_manager_legacy', lambda: _legacy_session_rag_manager)