"""
Durable retrieval over documents uploaded into an application chat.

WHAT: The component registered as ``rag.session_manager``. It converts, embeds
      and searches the files a user uploads mid-conversation, storing every
      part of that in Postgres.
WHY:  The previous implementation kept the uploaded file under
      ``APP_UPLOADS_DIR`` and its FAISS index under
      ``APP_UPLOADS_DIR/rag_indexes/{session_id}/``. This deployment runs more
      than one replica with no shared filesystem, so neither survived a
      restart, a redeploy, or a request routed elsewhere — while the
      ``application_documents`` row did survive. The conversation went on
      listing a document whose content had vanished, the readiness ledger went
      on reporting it ready, and the agent answered as though nothing had been
      uploaded. The only recovery available to a user was to upload it again.

      That is the failure this class removes. It is the same decision already
      taken for agent attachments in Phase 6, applied to the surface it was not
      applied to, and it is what production assistants do: Copilot Studio
      chunks an uploaded file, vector-indexes it into durable storage, and has
      the orchestrator query it when a request needs grounding.

DESIGN
------
* **Same three-method surface as before.** ``process_document``, ``retrieve``
  and ``has_documents`` keep their signatures, so ``OrchestrationPipeline``,
  the session-document middleware and the upload routes are unchanged.
* **Composed, not rewritten.** The legacy :class:`SessionRAGManager` is held
  as a delegate and still answers for any session whose index was built before
  this shipped. Nothing that works today stops working; sessions simply stop
  being created that way.
* **No new conversion or embedding code.** Conversion is ``apps.markitdown``,
  which already owns MarkItDown, the OCR fallback and the credential cascade.
  Ranking is ``apps.markitdown.similarity``. This module orchestrates and
  persists; it parses nothing itself.
* **Lives under ``apps/``, not ``echolib/``.** It depends on ``apps.markitdown``,
  and ``echolib`` must not import from ``apps.*``.

ASYNC/SYNC BOUNDARY
--------------------
Database operations (``_store``, ``_load_rows``, ``_count``) are scheduled via
an async/sync bridge (``run_db_coro_sync``) to avoid pooled connection mismatches.
When called from an async FastAPI request handler, these operations MUST run
in a worker thread to prevent same-event-loop deadlock. The ``process_document``
method uses ``asyncio.to_thread()`` to move storage operations off the main loop.
"""
from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ConvertedDocument:
    """
    What one upload produced, with conversion and embedding reported apart.

    The two fail independently: conversion needs no model, embedding needs a
    resolvable credential. Keeping them separate is what lets a document be
    stored as readable-but-not-searchable rather than thrown away entirely.
    """

    content_md: str = ""
    chunks: List[Dict[str, Any]] = field(default_factory=list)
    char_count: int = 0
    converted_by: Optional[str] = None
    ocr_skipped_reason: Optional[str] = None
    error: Optional[str] = None

    @property
    def readable(self) -> bool:
        """True when text came out, whether or not it could be embedded."""
        return bool((self.content_md or "").strip())

    @property
    def searchable(self) -> bool:
        return bool(self.chunks)

# One conversation's uploads are a bounded corpus, but the bound is a property
# of user behaviour rather than of the schema. This caps a retrieval and the
# repository logs when the assumption stops holding.
DEFAULT_SEARCH_LIMIT = int(os.getenv("APP_SESSION_DOC_SEARCH_LIMIT", "2000"))

# How much retrieved text is handed back on one call. The middleware clips
# again for its own budget; this bounds what crosses the process first.
MAX_RESULT_CHARS = int(os.getenv("APP_SESSION_DOC_RESULT_CHARS", "12000"))

# How far a document reaches past the conversation that uploaded it.
#SCOPE_SESSION = "session"
SCOPE_SESSION = "user_application"
SCOPE_USER_APPLICATION = "user_application"

# ``session`` is the default deliberately. A document uploaded into a chat is
# conversation-local until a deployment says otherwise, because widening it is
# a visibility decision and the safe direction for an unstated one is narrower.
# ``user_application`` lets a user's own uploads follow them across their
# sessions in one application; it never crosses users, which the repository
# enforces by joining on ``application_chat_sessions.user_id``.
DEFAULT_DOCUMENT_SCOPE = os.getenv("APP_DOCUMENT_SCOPE", SCOPE_SESSION).strip().lower()


def _effective_scope(scope: Optional[str]) -> str:
    """Resolve a requested scope against the deployment default."""
    requested = (scope or "").strip().lower() or DEFAULT_DOCUMENT_SCOPE
    if requested in (SCOPE_SESSION, SCOPE_USER_APPLICATION):
        return requested
    logger.warning(
        "Unknown document scope '%s'; falling back to '%s'", requested, SCOPE_SESSION
    )
    return SCOPE_SESSION


class DurableSessionDocumentManager:
    """Session-scoped document retrieval backed by Postgres."""

    def __init__(self, legacy: Optional[Any] = None) -> None:
        """
        Args:
            legacy: The disk-backed :class:`SessionRAGManager`, kept so
                sessions indexed before this shipped keep answering. Optional
                so the durable path can be constructed on its own.
        """
        self._legacy = legacy
        logger.info(
            "Session documents are stored in Postgres%s",
            " (legacy disk indexes still readable)" if legacy else "",
        )

    # -- ingestion --------------------------------------------------------

    async def process_document(
        self,
        session_id: str,
        file_path: Optional[str] = None,
        filename: Optional[str] = None,
        *,
        data: Optional[bytes] = None,
        application_id: Optional[str] = None,
        document_id: Optional[str] = None,
        user_id: Optional[str] = None,
        credential_id: Optional[str] = None,
        mime_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Convert, embed and store one uploaded document.

        WHAT: Turns bytes into passages with embeddings and writes them to
              ``application_document_chunks``.
        WHY:  Retrieval has to survive the process that performed the upload.
        INPUT: ``data`` is preferred; ``file_path`` is read when it is the only
               source, so the previous call shape keeps working.
        OUTPUT: ``{"chunk_count": int, "status": "ready"}`` — the same contract
                the upload route already handles.

        Falls back to the legacy disk index when the caller cannot say which
        application and document these passages belong to, because without
        those two ids there is no row to attach them to.

        ASYNC/SYNC BOUNDARY: When called from an async context (FastAPI request),
        the storage operation runs in a worker thread via asyncio.to_thread() to
        prevent same-event-loop deadlock. The method is synchronous so existing
        callers do not change.
        """
        payload = data
        if payload is None and file_path:
            try:
                with open(file_path, "rb") as handle:
                    payload = handle.read()
            except OSError:
                logger.exception("Could not read '%s' for indexing", file_path)
                payload = None

        name = filename or (os.path.basename(file_path) if file_path else "upload")

        if not application_id or not document_id or payload is None:
            return self._legacy_process(session_id, file_path, name)

        # Off the loop, deliberately. Conversion is CPU-bound and the OCR pass
        # makes one blocking vision call per page, but the decisive reason is
        # credentials: ``resolve_llm_credential_sync`` refuses to run on the
        # event-loop thread and returns None there, so both the vision client
        # and the embeddings client silently resolved to nothing. The document
        # then converted correctly, produced no passages, and was recorded as
        # failed -- with no error anywhere naming the cause.
        conversion = await asyncio.to_thread(
            self._convert,
            payload,
            name,
            user_id=user_id,
            credential_id=credential_id,
            mime_type=mime_type,
        )

        chunks = conversion.chunks
        if not chunks:
            logger.warning(
                "No passages produced from '%s'%s",
                name,
                " (the text was extracted but could not be embedded)"
                if conversion.content_md
                else "",
            )

        written = 0
        if chunks:
            written = await self._store_in_thread(
                application_id=application_id,
                chat_session_id=session_id,
                document_id=document_id,
                source_name=name,
                chunks=chunks,
            )
            logger.info(
                "Indexed '%s' for session %s: %d passage(s) in Postgres",
                name, session_id, written,
            )

        # The converted markdown travels back with the count. The caller stores
        # it, so a document that was read but could not be embedded stays
        # readable instead of being discarded -- which is what used to happen,
        # and why a perfectly converted file was reported to the user as failed.
        return {
            "chunk_count": written,
            "status": "ready",
            "content_md": conversion.content_md,
            "char_count": conversion.char_count,
            "converted_by": conversion.converted_by,
            "ocr_skipped_reason": conversion.ocr_skipped_reason,
            "error": conversion.error,
        }

    # -- retrieval --------------------------------------------------------

    def retrieve(
        self,
        session_id: str,
        query: str,
        top_k: int = 10,
        *,
        user_id: Optional[str] = None,
        credential_id: Optional[str] = None,
        application_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> str:
        """
        Search this conversation's documents and return the matching passages.

        Returns the empty string when nothing matches or nothing is indexed,
        which is what the caller already treats as "no document context".
        A retrieval that could not run must not look like one that found
        nothing relevant, so that case is logged rather than silently blank.

        ``scope`` widens the corpus past the current conversation:

        - ``session`` (the default) — only this chat's uploads. Conversation
          -local documents stay conversation-local.
        - ``user_application`` — every document *this user* has uploaded into
          *this application*, current conversation first. Requires both
          ``application_id`` and ``user_id``; without them it degrades to
          session scope rather than widening to something unintended.
        """
        cleaned = (query or "").strip()
        if not cleaned or not session_id:
            return ""

        try:
            from apps.markitdown import embed_query, search_chunks
        except Exception:
            logger.warning("Document conversion layer unavailable", exc_info=True)
            return self._legacy_retrieve(session_id, cleaned, top_k)

        query_vector = embed_query(
            cleaned, user_id=user_id, credential_id=credential_id
        )
        if not query_vector:
            logger.warning(
                "No embedding model resolved; session document search cannot run "
                "(user_id=%s). Passages cannot be ranked without one.",
                user_id or "<none>",
            )
            return self._legacy_retrieve(session_id, cleaned, top_k)

        rows = self._load_rows(
            session_id, application_id=application_id, user_id=user_id, scope=scope
        )
        if not rows:
            return self._legacy_retrieve(session_id, cleaned, top_k)

        hits = search_chunks(query_vector, rows, top_k=top_k)
        if not hits:
            return ""

        # Same shape the previous implementation returned — filename, newline,
        # passage — so every consumer renders it unchanged.
        rendered: List[str] = []
        used = 0
        for hit in hits:
            block = f"{hit.source_name or 'Document'}\n{hit.content}"
            if used + len(block) > MAX_RESULT_CHARS:
                break
            rendered.append(block)
            used += len(block)

        return "\n\n".join(rendered)

    def has_documents(
        self,
        session_id: str,
        *,
        application_id: Optional[str] = None,
        user_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> bool:
        """True when there is anything indexed to search under this scope."""
        if not session_id:
            return False

        if self._count(
            session_id, application_id=application_id, user_id=user_id, scope=scope
        ) > 0:
            return True

        if self._legacy is not None:
            try:
                return bool(self._legacy.has_documents(session_id))
            except Exception:
                logger.debug("Legacy index check failed", exc_info=True)
        return False

    # -- internals --------------------------------------------------------

    def _convert(
        self,
        payload: bytes,
        name: str,
        *,
        user_id: Optional[str],
        credential_id: Optional[str],
        mime_type: Optional[str],
    ) -> "ConvertedDocument":
        """
        Convert, then embed, reporting both outcomes separately.

        WHAT: Runs ``ingest_file`` and returns the markdown alongside whatever
              passages could be embedded.
        WHY:  Conversion and embedding fail for different reasons and have
              different consequences. Conversion needs no model at all; embedding
              needs a resolvable credential. Collapsing them into "did we get
              chunks?" meant a document that converted perfectly was discarded
              and reported as failed the moment embeddings were unavailable.
        OUTPUT: A :class:`ConvertedDocument`. Never raises — a failure is a
                value, so one bad file cannot abort a batch upload.

        Synchronous and blocking: MarkItDown, the OCR vision calls and the
        embedding calls all block, and credential resolution refuses to run on
        the event-loop thread. Always called through ``asyncio.to_thread``.

        A short document comes back from ``ingest_file`` in *inline* mode with
        no passages, because an agent's own attachment of that size is injected
        whole. A session document is never injected whole — it is always
        searched — so its markdown is split and embedded here instead.
        """
        from apps.markitdown import ingest_file

        try:
            result = ingest_file(
                data=payload,
                filename=name,
                user_id=user_id,
                credential_id=credential_id,
                mime_type=mime_type,
                keep_original=False,
            )
        except Exception as exc:
            logger.exception("Could not convert '%s'", name)
            return ConvertedDocument(error=f"This file could not be converted: {exc}")

        markdown = result.content_md or ""
        chunks = [c.to_dict() for c in (result.chunks or [])]

        if not chunks and markdown:
            chunks = self._embed_markdown(
                markdown, user_id=user_id, credential_id=credential_id
            )

        return ConvertedDocument(
            content_md=markdown,
            chunks=chunks,
            char_count=len(markdown),
            converted_by=getattr(result, "converted_by", None),
            ocr_skipped_reason=getattr(result, "ocr_skipped_reason", None),
            error=None if markdown else (getattr(result, "error_message", None)
                                         or "No text could be read from this file."),
        )

    @staticmethod
    def _embed_markdown(
        markdown: str,
        *,
        user_id: Optional[str],
        credential_id: Optional[str],
    ) -> List[Dict[str, Any]]:
        """Split converted markdown and embed each passage."""
        text = (markdown or "").strip()
        if not text:
            return []

        from apps.markitdown import embed_query
        from apps.markitdown import similarity
        from apps.markitdown.chunking import split_markdown

        documents = split_markdown(text)
        chunks: List[Dict[str, Any]] = []

        for index, document in enumerate(documents):
            content = getattr(document, "page_content", "") or ""
            if not content.strip():
                continue
            vector = embed_query(
                content, user_id=user_id, credential_id=credential_id
            )
            if not vector:
                # No embedding model resolved. Storing an unembedded passage
                # would make the document look indexed and match nothing.
                logger.warning("No embedding model resolved; passage not stored")
                return []
            chunks.append(
                {
                    "chunk_index": index,
                    "content": content,
                    "embedding": similarity.encode(vector),
                    "dimensions": len(vector),
                    "embedding_model": "",
                }
            )

        return chunks

    def _store(
        self,
        *,
        application_id: str,
        chat_session_id: str,
        document_id: str,
        source_name: str,
        chunks: Sequence[Dict[str, Any]],
    ) -> int:
        """Write passages, replacing anything this document had before."""
        from echolib.database import get_db_session, run_db_coro_sync
        from echolib.repositories.application_document_chunk_repo import (
            ApplicationDocumentChunkRepository,
        )

        async def _write() -> int:
            async with get_db_session() as db:
                written = await ApplicationDocumentChunkRepository().replace_for_document(
                    db,
                    application_id=application_id,
                    chat_session_id=chat_session_id,
                    document_id=document_id,
                    source_name=source_name,
                    chunks=chunks,
                )
                await db.commit()
                return written

        try:
            return int(run_db_coro_sync(_write))
        except Exception:
            logger.exception("Could not store passages for document '%s'", document_id)
            return 0

    async def _store_in_thread(
        self,
        *,
        application_id: str,
        chat_session_id: str,
        document_id: str,
        source_name: str,
        chunks: Sequence[Dict[str, Any]],
    ) -> int:
        """
        Store passages in a worker thread to avoid same-event-loop deadlock.

        WHY: When called from an async FastAPI handler, _store() would call
        run_db_coro_sync() on the main event loop, creating a deadlock.
        This method moves the entire operation to a worker thread.

        RETURNS: Number of passages successfully persisted to PostgreSQL.
        If storage fails, returns 0 and logs the error.
        """
        return await asyncio.to_thread(
            self._store,
            application_id=application_id,
            chat_session_id=chat_session_id,
            document_id=document_id,
            source_name=source_name,
            chunks=chunks,
        )

    def _load_rows(
        self,
        session_id: str,
        *,
        application_id: Optional[str] = None,
        user_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Load the passages this retrieval may rank.

        Session scope is the default and is what conversation-local uploads
        keep. The wider scope is only taken when it was asked for *and* both
        ids needed to bound it safely are present — a widening that cannot be
        bounded is not performed at all.
        """
        from echolib.database import get_db_session, run_db_coro_sync
        from echolib.repositories.application_document_chunk_repo import (
            ApplicationDocumentChunkRepository,
        )

        effective = _effective_scope(scope)
        widen = (
            effective == SCOPE_USER_APPLICATION
            and bool(application_id)
            and bool(user_id)
        )

        async def _read() -> List[Dict[str, Any]]:
            repo = ApplicationDocumentChunkRepository()
            async with get_db_session() as db:
                if widen:
                    return await repo.load_for_user_application(
                        db,
                        application_id=str(application_id),
                        user_id=str(user_id),
                        chat_session_id=session_id,
                        limit=DEFAULT_SEARCH_LIMIT,
                    )
                return await repo.load_for_session(
                    db, chat_session_id=session_id, limit=DEFAULT_SEARCH_LIMIT
                )

        try:
            return list(run_db_coro_sync(_read) or [])
        except Exception:
            logger.exception("Could not load passages for session '%s'", session_id)
            return []

    def _count(
        self,
        session_id: str,
        *,
        application_id: Optional[str] = None,
        user_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> int:
        """How many passages are stored under this scope."""
        from echolib.database import get_db_session, run_db_coro_sync
        from echolib.repositories.application_document_chunk_repo import (
            ApplicationDocumentChunkRepository,
        )

        widen = (
            _effective_scope(scope) == SCOPE_USER_APPLICATION
            and bool(application_id)
            and bool(user_id)
        )

        async def _read() -> int:
            repo = ApplicationDocumentChunkRepository()
            async with get_db_session() as db:
                if widen:
                    return await repo.count_for_user_application(
                        db, str(application_id), str(user_id)
                    )
                return await repo.count_for_session(db, session_id)

        try:
            return int(run_db_coro_sync(_read) or 0)
        except Exception:
            logger.debug("Could not count passages for '%s'", session_id, exc_info=True)
            return 0

    # -- legacy delegation ------------------------------------------------

    def _legacy_process(
        self, session_id: str, file_path: Optional[str], filename: str
    ) -> Dict[str, Any]:
        if self._legacy is None or not file_path:
            logger.warning(
                "'%s' could not be indexed durably and no legacy path is "
                "available", filename,
            )
            return {"chunk_count": 0, "status": "ready"}

        logger.info("Indexing '%s' through the legacy disk index", filename)
        return self._legacy.process_document(session_id, file_path, filename)

    def _legacy_retrieve(self, session_id: str, query: str, top_k: int) -> str:
        if self._legacy is None:
            return ""
        try:
            return self._legacy.retrieve(session_id, query, top_k=top_k) or ""
        except Exception:
            logger.debug("Legacy retrieval failed", exc_info=True)
            return ""


__all__ = ["DEFAULT_SEARCH_LIMIT", "DurableSessionDocumentManager"]
