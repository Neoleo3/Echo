"""
Sandbox value types.

Pure data. No I/O, no imports from ``apps.*``, so a backend, a caller and a
future remote implementation can all depend on this without cycles.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Optional


class SandboxUnavailable(RuntimeError):
    """Raised when the configured backend cannot run code at all."""


def _env_int(name: str, default: int) -> int:
    """Read a positive integer setting, falling back on anything unusable."""
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


@dataclass(frozen=True)
class SandboxLimits:
    """
    Resource ceilings for one execution.

    ``timeout_seconds`` is the only limit every platform can enforce; the memory
    and file-size caps rely on POSIX ``setrlimit`` and are recorded as
    unenforced on Windows rather than silently assumed.
    """

    timeout_seconds: int = field(default_factory=lambda: _env_int("ECHO_SANDBOX_TIMEOUT", 30))
    memory_mb: int = field(default_factory=lambda: _env_int("ECHO_SANDBOX_MEMORY_MB", 512))
    cpu_seconds: int = field(default_factory=lambda: _env_int("ECHO_SANDBOX_CPU_SECONDS", 30))
    max_output_bytes: int = field(default_factory=lambda: _env_int("ECHO_SANDBOX_MAX_OUTPUT", 1_000_000))
    max_file_mb: int = field(default_factory=lambda: _env_int("ECHO_SANDBOX_MAX_FILE_MB", 64))


@dataclass(frozen=True)
class SandboxRequest:
    """One unit of work handed to a backend."""

    code: str
    language: str = "python"
    variables: Dict[str, Any] = field(default_factory=dict)
    label: str = "code"
    limits: SandboxLimits = field(default_factory=SandboxLimits)
    # Extra environment entries the code legitimately needs. Never populated
    # from os.environ -- the point of the scrub is that nothing leaks by
    # default, so anything required must be named here by the caller.
    env: Dict[str, str] = field(default_factory=dict)

    def with_limits(self, limits: SandboxLimits) -> "SandboxRequest":
        """Return a copy with different limits; the original is untouched."""
        return replace(self, limits=limits)


@dataclass(frozen=True)
class SandboxResult:
    """
    What an execution produced.

    ``success`` is about the code, not about the sandbox: a backend that could
    not start at all raises ``SandboxUnavailable`` instead of returning here.
    """

    success: bool
    output: Any = None
    stdout: str = ""
    stderr: str = ""
    variables: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    timed_out: bool = False
    duration_ms: int = 0
    backend: str = ""
    unenforced_limits: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Legacy-shaped dict: the contract Code nodes and tools already emit."""
        return {
            "success": self.success,
            "output": self.output,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "variables": dict(self.variables),
            "error": self.error,
        }


__all__ = [
    "SandboxLimits",
    "SandboxRequest",
    "SandboxResult",
    "SandboxUnavailable",
]
