"""
Sandbox backends.

One interface, one shipped implementation, a registry so another can be added
without touching a caller.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .types import (
    SandboxLimits,
    SandboxRequest,
    SandboxResult,
    SandboxUnavailable,
)

logger = logging.getLogger(__name__)

BACKEND_ENV_VAR = "ECHO_SANDBOX_BACKEND"
BACKEND_LOCAL = "local_subprocess"

_CHILD = Path(__file__).with_name("child.py")

# Variables a child genuinely needs to start. Everything else -- every
# credential, connection string and token this process holds -- is dropped.
# This is an allow-list rather than a deny-list on purpose: a deny-list has to
# be updated every time a new secret is added to the deployment, and the one
# time it is forgotten the secret ships to whatever the model wrote.
_ENV_ALLOW_LIST = (
    "PATH",
    "SYSTEMROOT",
    "COMSPEC",
    "TEMP",
    "TMP",
    "LANG",
    "LC_ALL",
    "TZ",
)


def scrubbed_env(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Build the child's environment from an allow-list.

    WHAT: Copies only the handful of variables an interpreter or compiler needs
          to start, plus whatever the caller explicitly named.
    WHY:  ``os.environ.copy()`` handed executed code ``DATABASE_URL``,
          ``JWT_SECRET``, ``SSO_CLIENT_SECRET``, ``AZURE_STORAGE_CONNECTION_STRING``,
          ``NEO4J_PASSWORD`` and ``LANGFUSE_SECRET_KEY``. One ``print(os.environ)``
          exfiltrated the deployment.
    """
    env = {name: os.environ[name] for name in _ENV_ALLOW_LIST if name in os.environ}
    # Keep the child out of the parent's import path and off its bytecode cache.
    env["PYTHONNOUSERSITE"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    if extra:
        env.update({str(k): str(v) for k, v in extra.items()})
    return env


def _rlimit_preexec(limits: SandboxLimits) -> Optional[Callable[[], None]]:
    """
    Build a ``preexec_fn`` applying POSIX resource limits, or ``None``.

    Returns ``None`` on Windows, where ``resource`` does not exist; the caller
    records which limits went unenforced rather than implying they were applied.
    """
    try:
        import resource
    except ImportError:
        return None

    def apply() -> None:  # pragma: no cover - runs in the forked child
        memory_bytes = limits.memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))
        resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds))
        file_bytes = limits.max_file_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (file_bytes, file_bytes))
        try:
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except (ValueError, OSError):
            pass

    return apply


class SandboxBackend:
    """Interface every backend implements."""

    name = "sandbox"

    def run(self, request: SandboxRequest) -> SandboxResult:
        raise NotImplementedError


class LocalSubprocessBackend(SandboxBackend):
    """
    Run code in a fresh, isolated interpreter on this host.

    WHAT: ``python -I -B child.py`` in a temporary working directory, with a
          scrubbed environment, a wall-clock timeout and POSIX resource limits.
    WHY:  It removes the two properties that made the previous in-process
          ``exec`` dangerous -- shared address space and a populated
          environment -- with no infrastructure to provision, which matters for
          a platform that runs both on-premise and in a container.
    LIMITS: This is process isolation, not containment. It does not stop code
            reading files the service account can read, and on Windows only the
            timeout is enforced. Those gaps are reported on the result rather
            than papered over; a remote backend is the answer when they matter.
    """

    name = BACKEND_LOCAL

    def run(self, request: SandboxRequest) -> SandboxResult:
        if request.language != "python":
            raise SandboxUnavailable(
                f"{self.name} runs Python; '{request.language}' is handled by the caller."
            )
        if not request.code or not request.code.strip():
            return SandboxResult(
                success=False, error="No code provided.", backend=self.name
            )

        limits = request.limits
        unenforced: List[str] = []
        preexec = _rlimit_preexec(limits)
        if preexec is None:
            unenforced = ["memory_mb", "cpu_seconds", "max_file_mb"]

        work_dir = tempfile.mkdtemp(prefix="echo_sandbox_")
        started = time.monotonic()
        try:
            code_path = os.path.join(work_dir, "user_code.py")
            payload_path = os.path.join(work_dir, "payload.json")
            result_path = os.path.join(work_dir, "result.json")

            Path(code_path).write_text(request.code, encoding="utf-8")
            Path(payload_path).write_text(
                json.dumps({"variables": _jsonable_variables(request.variables)}),
                encoding="utf-8",
            )

            # -I isolates: no user site-packages, no PYTHONPATH, no cwd on
            # sys.path. -B leaves no bytecode behind in the temp directory.
            command = [
                sys.executable,
                "-I",
                "-B",
                str(_CHILD),
                payload_path,
                result_path,
                code_path,
            ]

            popen_kwargs: Dict[str, Any] = {
                "cwd": work_dir,
                "env": scrubbed_env(request.env),
                "stdout": subprocess.PIPE,
                "stderr": subprocess.PIPE,
                "text": True,
                "encoding": "utf-8",
                "errors": "replace",
            }
            if preexec is not None:
                popen_kwargs["preexec_fn"] = preexec

            try:
                completed = subprocess.run(
                    command, timeout=limits.timeout_seconds, **popen_kwargs
                )
            except subprocess.TimeoutExpired:
                return SandboxResult(
                    success=False,
                    error=(
                        f"Execution exceeded the {limits.timeout_seconds}s limit "
                        "and was stopped."
                    ),
                    timed_out=True,
                    duration_ms=_elapsed_ms(started),
                    backend=self.name,
                    unenforced_limits=unenforced,
                )

            envelope = _read_envelope(result_path)
            if envelope is None:
                # The child died before writing -- a resource limit, a segfault,
                # or sys.exit inside the user's code.
                stderr = _clip(completed.stderr, limits.max_output_bytes)
                return SandboxResult(
                    success=False,
                    stderr=stderr,
                    error=(
                        "The code stopped without producing a result "
                        f"(exit code {completed.returncode})."
                        + (f" {stderr.strip()}" if stderr.strip() else "")
                    ),
                    duration_ms=_elapsed_ms(started),
                    backend=self.name,
                    unenforced_limits=unenforced,
                )

            stdout = _clip(envelope.get("stdout") or "", limits.max_output_bytes)
            return SandboxResult(
                success=bool(envelope.get("ok")),
                output=envelope.get("output") if envelope.get("output") is not None else stdout,
                stdout=stdout,
                stderr=_clip(completed.stderr or "", limits.max_output_bytes),
                variables=envelope.get("variables") or {},
                error=envelope.get("error"),
                duration_ms=_elapsed_ms(started),
                backend=self.name,
                unenforced_limits=unenforced,
            )
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)


def _elapsed_ms(started: float) -> int:
    return int((time.monotonic() - started) * 1000)


def _clip(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n... output truncated at {limit} characters ..."


def _jsonable_variables(variables: Dict[str, Any]) -> Dict[str, Any]:
    """Make injected values crossing the process boundary JSON-safe."""
    safe: Dict[str, Any] = {}
    for key, value in (variables or {}).items():
        try:
            json.dumps(value)
            safe[key] = value
        except (TypeError, ValueError):
            safe[key] = str(value)
    return safe


def _read_envelope(path: str) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_REGISTRY: Dict[str, Callable[[], SandboxBackend]] = {
    BACKEND_LOCAL: LocalSubprocessBackend,
}
_active: Optional[SandboxBackend] = None


def register_backend(name: str, factory: Callable[[], SandboxBackend]) -> None:
    """
    Register a backend under a name selectable by ``ECHO_SANDBOX_BACKEND``.

    This is the seam for a remote sandbox -- E2B, Modal, or an internal runner.
    Nothing in this package needs to change to add one.
    """
    _REGISTRY[name] = factory


def reset_backend() -> None:
    """Drop the cached backend. For process-level reconfiguration only."""
    global _active
    _active = None


def get_backend() -> SandboxBackend:
    """Resolve the configured backend once per process."""
    global _active
    if _active is not None:
        return _active

    requested = (os.getenv(BACKEND_ENV_VAR) or BACKEND_LOCAL).strip()
    factory = _REGISTRY.get(requested)
    if factory is None:
        logger.warning(
            "Unknown sandbox backend '%s'; using '%s'. Registered: %s",
            requested,
            BACKEND_LOCAL,
            ", ".join(sorted(_REGISTRY)),
        )
        factory = _REGISTRY[BACKEND_LOCAL]

    _active = factory()
    logger.info("Sandbox backend: %s", _active.name)
    return _active


__all__ = [
    "BACKEND_ENV_VAR",
    "BACKEND_LOCAL",
    "LocalSubprocessBackend",
    "SandboxBackend",
    "get_backend",
    "register_backend",
    "reset_backend",
    "scrubbed_env",
]
