"""
Sandbox child program. Runs in its own interpreter; never imported by the app.

WHAT: Loads a JSON payload, executes the user's Python with those names bound,
      and writes a JSON envelope describing what happened.
WHY:  Running this as a separate process is the whole point -- a crash, an
      infinite loop, a memory blow-up or an ``os.environ`` read all stay here,
      where the environment has been scrubbed and the limits applied by the
      parent before ``exec`` ever runs.

Contract, all paths given as argv:
    argv[1]  payload JSON in   {"variables": {...}}
    argv[2]  result JSON out   {"ok", "output", "variables", "error"}
    argv[3]  user code file

The result goes to a file rather than stdout because stdout belongs to the
user's own ``print`` calls -- mixing them would make the envelope unparseable
the first time someone printed a brace.
"""
import io
import json
import sys
import traceback
import types
from contextlib import redirect_stdout

# Values that survive back to the caller. Anything else -- a module, a function,
# an open handle -- is local to this process and meaningless outside it.
SERIALIZABLE = (str, int, float, bool, list, dict, tuple, type(None))

MAX_VALUE_REPR = 10_000


def _collect(namespace, injected):
    """Return the JSON-safe names the code bound, excluding what we injected."""
    collected = {}
    for key, value in namespace.items():
        if key.startswith("_") or key in injected:
            continue
        if callable(value) or isinstance(value, types.ModuleType):
            continue
        if not isinstance(value, SERIALIZABLE):
            continue
        try:
            json.dumps(value)
        except (TypeError, ValueError):
            continue
        collected[key] = value
    return collected


def _jsonable(value):
    """Best-effort JSON representation; falls back to a bounded repr."""
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return str(value)[:MAX_VALUE_REPR]


def main():
    payload_path, result_path, code_path = sys.argv[1], sys.argv[2], sys.argv[3]

    with open(payload_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    with open(code_path, "r", encoding="utf-8") as handle:
        code = handle.read()

    variables = payload.get("variables") or {}
    namespace = {"__name__": "__sandbox__", "__builtins__": __builtins__}
    namespace.update(variables)
    injected = set(variables) | {"__name__", "__builtins__"}

    stdout_buffer = io.StringIO()
    envelope = {"ok": False, "output": None, "variables": {}, "error": None}

    try:
        with redirect_stdout(stdout_buffer):
            exec(compile(code, "<sandbox>", "exec"), namespace, namespace)
        envelope["ok"] = True
        if "result" in namespace:
            envelope["output"] = _jsonable(namespace["result"])
        envelope["variables"] = _collect(namespace, injected)
    except BaseException:  # noqa: BLE001 -- reported, not swallowed
        envelope["error"] = traceback.format_exc()

    envelope["stdout"] = stdout_buffer.getvalue()

    with open(result_path, "w", encoding="utf-8") as handle:
        json.dump(envelope, handle)

    sys.exit(0 if envelope["ok"] else 1)


if __name__ == "__main__":
    main()
