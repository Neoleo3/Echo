"""
Sandboxed code execution.

WHAT: The one place this platform runs code it did not write -- a workflow Code
      node authored on the canvas, or Python an agent generated to answer a
      question.
WHY:  Both used to call ``exec(code, {"__builtins__": __builtins__})`` inside
      the API process. That is not a sandbox by any reading: ``__builtins__``
      carries ``__import__``, ``open``, ``eval`` and ``compile``, so an
      allow-list of injected modules restricts nothing, and the code ran with
      the process's own environment -- ``DATABASE_URL``, ``JWT_SECRET``, the
      storage connection string, the Key Vault credential -- in ``os.environ``.
      For the agent tool the code was written by a language model, which makes
      it remote code execution driven by whatever text reached the prompt.

Design: one interface, swappable backends.

    SandboxBackend.run(request) -> SandboxResult

``LocalSubprocessBackend`` is the default and needs no infrastructure: a fresh
interpreter in isolated mode, a scrubbed environment, a temporary working
directory, a wall-clock timeout, and address-space / CPU / file-size limits
where the platform provides them. It is a strong boundary against accident and
a real one against secret exfiltration; it is *not* a container, so it does not
by itself stop a determined attacker from reading world-readable files on the
host.

For untrusted code at scale the production answer is a remote sandbox --
LangChain's own guidance is that the Pyodide-based ``langchain-sandbox`` is not
for production and that E2B / Modal / OpenShell backends are what you reach for.
Those are a data-residency decision, not a code decision, so this package
defines the seam and ships the local backend; ``ECHO_SANDBOX_BACKEND`` selects
another once one is registered.
"""
from __future__ import annotations

from .backends import (
    LocalSubprocessBackend,
    SandboxBackend,
    get_backend,
    register_backend,
    reset_backend,
)
from .types import (
    SandboxLimits,
    SandboxRequest,
    SandboxResult,
    SandboxUnavailable,
)

__all__ = [
    "LocalSubprocessBackend",
    "SandboxBackend",
    "SandboxLimits",
    "SandboxRequest",
    "SandboxResult",
    "SandboxUnavailable",
    "get_backend",
    "register_backend",
    "reset_backend",
    "run_python",
]


def run_python(
    code: str,
    *,
    variables: "dict | None" = None,
    timeout: "int | None" = None,
    label: str = "code",
) -> SandboxResult:
    """
    Run Python in the configured sandbox.

    WHAT: Convenience wrapper over ``get_backend().run(...)``.
    WHY:  Every caller wants the same thing -- code plus some JSON-shaped inputs,
          back a result, stdout and whatever names the code bound. Keeping that
          in one function means a backend change is invisible to callers.
    INPUT: Source, optional variables injected as module-level names, optional
           timeout override, a label used in logs.
    OUTPUT: ``SandboxResult``. Failures are reported on the result, not raised,
            because a caller mid-workflow needs the error text to show the user.
    """
    request = SandboxRequest(
        code=code,
        language="python",
        variables=dict(variables or {}),
        label=label,
    )
    if timeout is not None:
        request = request.with_limits(SandboxLimits(timeout_seconds=timeout))
    return get_backend().run(request)
