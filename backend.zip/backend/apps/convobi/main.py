"""
Convobi - LangGraph + SQLDatabaseToolkit NLP-to-SQL Agent
==========================================================
Rewrites the legacy procedural NLP-to-SQL pipeline with a LangGraph
ReAct-style agent powered by LangChain's SQLDatabaseToolkit (4 tools)
plus custom Plotly visualisation and summarisation tools.

Key design choices
------------------
* **Same API surface** - QueryRequest / QueryResponse / SchemaResponse /
  SummarizeRequest models are identical so the UI and Echo Agent are
  unchanged.
* **SQLDatabaseToolkit** provides: ListSQLDatabaseTool,
  InfoSQLDatabaseTool, QuerySQLDatabaseTool, QuerySQLCheckerTool.
* **Custom tools** added: PlotlyVisualizationTool, DataSummarizerTool.
* **Session memory** via MemorySaver (default) or PostgresSaver (env).
* **invoke_convobi_agent()** - programmatic entry-point for Echo Agent
  tools / workflow subgraph integration.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse
import socket
from collections import defaultdict, deque


import pandas as pd
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine.url import make_url
from echolib.otel import OTelLLMWrapper

# LangChain / LangGraph
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
    trim_messages,
)
from langchain_core.messages.utils import count_tokens_approximately
from langchain_core.tools import tool
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver
from langgraph.errors import GraphRecursionError

from typing import Annotated, TypedDict
from apps.connector.db_connector import _get_pg_engine

# ITSM DB connection IDs — when active, use itsm_column_glossary
ITSM_CONNECTION_IDS = {"9eb2583a"}

try:
    from . import column_glossary
    from . import itsm_column_glossary
except ImportError:
    column_glossary = None
    itsm_column_glossary = None

# Write data to uploaded_files postgres table
def save_uploaded_file_record(
    *,
    file_id: str,
    db_path: str,
    connection_id : Optional[str] = None,
    blob_name: str,
    original_path: Optional[str],
    format_type: Optional[str],
    sheets: Optional[List[Dict[str, Any]]],
    stored_locally: bool,
    file_size: int,
) -> None:

    LOG.info(
        "[FILE_REGISTRY_DB] saving file_id=%s",
        file_id,
    )
    LOG.info(
    "[FILE_REGISTRY_DB] values file_id=%s db_path=%s blob=%s stored_locally=%s size=%s",
    file_id,
    db_path,
    blob_name,
    stored_locally,
    file_size,
    )

    engine = _get_pg_engine()

    with engine.begin() as conn:

        conn.execute(
            text(
                """
                INSERT INTO uploaded_files
                (
                    file_id,
                    connection_id,
                    db_path,
                    blob_name,
                    original_path,
                    format,
                    sheets_json,
                    stored_locally,
                    file_size
                )
                VALUES
                (
                    :file_id,
                    :connection_id,
                    :db_path,
                    :blob_name,
                    :original_path,
                    :format,
                    :sheets_json,
                    :stored_locally,
                    :file_size
                )
                """
            ),
            {
                "file_id": file_id,
                "connection_id": connection_id,
                "db_path": db_path,
                "blob_name": blob_name,
                "original_path": original_path,
                "format": format_type,
                "sheets_json": json.dumps(sheets or []),
                "stored_locally": stored_locally,
                "file_size": file_size,
            },
        )

    LOG.info(
        "[FILE_REGISTRY_DB] saved file_id=%s",
        file_id,
    )

# Read from uploaded_files postgres table
def get_uploaded_file_record(
    file_id: str,
) -> Optional[Dict[str, Any]]:

    LOG.info(
        "[FILE_REGISTRY_DB] lookup file_id=%s",
        file_id,
    )

    try:

        engine = _get_pg_engine()

        with engine.connect() as conn:

            row = conn.execute(
                text(
                    """
                    SELECT
                        file_id,
                        db_path,
                        blob_name,
                        connection_id,
                        original_path,
                        format,
                        sheets_json,
                        stored_locally,
                        file_size
                    FROM uploaded_files
                    WHERE file_id = :file_id
                    """
                ),
                {"file_id": file_id},
            ).mappings().first()

        if not row:

            LOG.warning(
                "[FILE_REGISTRY_DB] file_id not found=%s",
                file_id,
            )

            return None

        LOG.info(
            "[FILE_REGISTRY_DB] found file_id=%s",
            file_id,
        )

        return dict(row)

    except Exception:

        LOG.exception(
            "[FILE_REGISTRY_DB] lookup failed file_id=%s",
            file_id,
        )

        return None
    
    
def _is_itsm_connection() -> bool:
    """True if the active connection is ITSM (SummitAI)."""
    try:
        cid = app_state.get("active_connection_id")
    except NameError:
        cid = None
    if cid and cid in ITSM_CONNECTION_IDS:
        return True
    # Fallback: check saved connection name
    try:
        from pathlib import Path as _Path
        saved = _Path(__file__).resolve().parent.parent / "connector" / "saved_db_connections.json"
        if saved.exists() and cid:
            with open(saved, "r", encoding="utf-8") as f:
                data = json.load(f)
            for conn in data.get("connections", []):
                if conn.get("id") == cid:
                    name = (conn.get("name") or "").upper()
                    return "ITSM" in name or "SUMMITAI" in name
    except Exception:
        pass
    return False


def _get_active_glossary():
    """Return (glossary_dict, get_description_func) for the active connection."""
    # File uploads: load from per-file glossary
    fid = app_state.get("active_file_id")
    if fid:
        path = get_glossary_path_for_file_id(fid)
        if path and path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    gloss = json.load(f)
                def _file_desc(col: str) -> str:
                    k = (col or "").strip().upper()
                    return gloss.get(k) or gloss.get(k.replace("_", " ")) or ""
                return gloss, _file_desc
            except Exception:
                pass
        return {}, lambda c: ""
    # DB connections (small SQLite/other): load from per-connection glossary
    cid = app_state.get("active_connection_id")
    if cid and not _is_itsm_connection():
        path = get_glossary_path_for_connection_id(cid)
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    gloss = json.load(f)
                def _conn_desc(col: str) -> str:
                    k = (col or "").strip().upper()
                    return gloss.get(k) or gloss.get(k.replace("_", " ")) or ""
                return gloss, _conn_desc
            except Exception:
                pass
        return {}, lambda c: ""
    if _is_itsm_connection() and itsm_column_glossary:
        return itsm_column_glossary.COLUMN_GLOSSARY, itsm_column_glossary.get_column_glossary_description
    if column_glossary:
        return column_glossary.COLUMN_GLOSSARY, column_glossary.get_column_glossary_description
    return {}, lambda c: ""


def get_column_glossary_description(column_name: str) -> str:
    """Return glossary description for column. Uses ITSM glossary when ITSM DB is active."""
    _, get_desc = _get_active_glossary()
    return get_desc(column_name)


def _get_column_glossary_dict() -> Dict[str, str]:
    """Return the active COLUMN_GLOSSARY dict (for get_column_for_term, build_glossary_from_schema)."""
    glossary, _ = _get_active_glossary()
    return glossary


COLUMN_GLOSSARY = {}  # Placeholder; runtime uses _get_column_glossary_dict()

LOG = logging.getLogger("nlpdb")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# ---------------------------------------------------------------------------
# Configuration (env vars)
# ---------------------------------------------------------------------------
DEFAULT_DB_URL = os.getenv("DATABASE_URL")
SUPPORTED_DIALECTS = {"sqlite", "postgres", "mysql", "mssql", "oracle", "bigquery", "snowflake"}
CURRENT_DIALECT = os.getenv("DB_DIALECT", "sqlite").strip().lower()
if CURRENT_DIALECT not in SUPPORTED_DIALECTS:
    CURRENT_DIALECT = "sqlite"
CURRENT_CONNECTOR = None

UPLOADS_DIR = os.getenv("UPLOADS_DIR", "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

# Per-connection schema doc cache (for small SQLite/other DBs - editable schema documentation)
CONVOBI_SCHEMA_CACHE_DIR = Path(os.getenv("CONVOBI_SCHEMA_CACHE_DIR", "convobi_schema_cache"))
CONVOBI_SCHEMA_CACHE_DIR.mkdir(parents=True, exist_ok=True)

CONVOBI_CHECKPOINTER = os.getenv("CONVOBI_CHECKPOINTER", "memory").strip().lower()
CONVOBI_CHECKPOINT_POSTGRES_URL = os.getenv("CONVOBI_CHECKPOINT_POSTGRES_URL", "")

DB_WRITE_ACCESS_FILE = os.getenv("DB_WRITE_ACCESS_FILE", "db_write_access.json")

CONVOBI_AGENT_VERBOSE = os.getenv(
    "CONVOBI_AGENT_VERBOSE", "true"
).strip().lower() in ("true", "1", "yes")

# ---------------------------------------------------------------------------
# LLM Setup — per-user resolution via echolib.llm_resolver
# ---------------------------------------------------------------------------
from echolib.llm_resolver import resolve_and_build_llm, resolve_and_build_llm_sync


async def _get_convobi_llm_async(user_id: Optional[str] = None) -> Any:
    """
    Async LLM resolver — safe to call from ``async def`` route handlers.

    Uses the native async ``resolve_and_build_llm`` directly on the
    running event loop, avoiding the deadlock that occurs when the sync
    wrapper tries to schedule a coroutine back onto the same blocked loop.
    """
    return await resolve_and_build_llm(
        user_id=user_id,
        component="convobi",
        temperature=0.1,
        allow_platform_fallback=True,
        framework="langchain",
    )


def _get_convobi_llm_sync(user_id: Optional[str] = None) -> Any:
    """
    Sync LLM resolver — for truly synchronous call sites only.

    Used by ``invoke_convobi_agent()`` (LangGraph ``.invoke()`` is sync)
    and ``AgentTools/convobi/service.py``.  Must NOT be called from an
    async route handler; use ``_get_convobi_llm_async`` instead.
    """
    return resolve_and_build_llm_sync(
        user_id=user_id,
        component="convobi",
        temperature=0.1,
        allow_platform_fallback=True,
        framework="langchain",
    )

# ---------------------------------------------------------------------------
# Pydantic models (IDENTICAL to legacy - API compatibility)
# ---------------------------------------------------------------------------


class QueryRequest(BaseModel):
    question: str = Field(..., description="Natural language question")
    language: str = Field("sql", description="Query language: only 'sql' is supported")
    max_results: Optional[int] = Field(None, description="Maximum number of rows")
    use_cache: bool = Field(True, description="Return cached result when available")
    auto_proceed: bool = Field(True, description="If True, execute even when warnings are present (default True)")
    connector_id: Optional[str] = Field(None, description="ID of the DB connection from POST /connectors/plugin/load to recognize which DB is used")
    file_id: Optional[str] = Field(None, description="ID of an uploaded file from POST /convobi/files/upload; use either connector_id or file_id")


class QueryResponse(BaseModel):
    success: bool
    response: Optional[str] = Field(None, description="Brief, direct answer to the user's question")
    sql: Optional[str] = None
    explanation: Optional[str] = None
    data: Optional[List[Dict[str, Any]]] = None
    row_count: Optional[int] = None
    columns: Optional[List[str]] = None
    visualization_hints: Optional[Dict[str, Any]] = None
    execution_time_ms: Optional[float] = None
    confidence: Optional[float] = None
    optimizations: Optional[List[str]] = None
    warnings: Optional[List[str]] = None
    error: Optional[str] = None
    summary: Optional[str] = None
    visualization: Optional[Dict[str, Any]] = None
    visualization_spec: Optional[Dict[str, Any]] = None
    visualization_html: Optional[str] = None
    optimized_question: Optional[str] = None
    feedback_attempts: Optional[int] = None
    tables_used: Optional[Dict[str, Any]] = Field(None, description="Tables referenced in the SQL query with column types and sample data")
    agent_steps: Optional[List[Dict[str, Any]]] = Field(None, description="Agent reasoning trace (only when CONVOBI_AGENT_VERBOSE=true)")


class SchemaResponse(BaseModel):
    tables: Dict[str, Any]
    total_tables: int
    summary: str


class SummarizeRequest(BaseModel):
    question: str
    columns: List[str]
    data: List[Dict[str, Any]]
    visualization_hints: Optional[Dict[str, Any]] = None


class InvokeRequest(BaseModel):
    """Request body for POST /convobi/invoke - direct LangGraph agent invocation."""
    message: str = Field(..., description="Natural language message for the agent")
    session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")
    connection_id: Optional[str] = Field(None, description="DB connection ID")
    file_id: Optional[str] = Field(None, description="Uploaded file ID")
    max_results: Optional[int] = Field(None, description="Max rows to return")


class InvokeResponse(BaseModel):
    """Response for POST /convobi/invoke — matches QueryResponse minus visualization_hints, visualization_spec, feedback_attempts."""
    success: bool
    response: str = ""
    sql: Optional[str] = None
    explanation: Optional[str] = None
    data: Optional[List[Dict[str, Any]]] = None
    row_count: Optional[int] = None
    columns: Optional[List[str]] = None
    execution_time_ms: Optional[float] = None
    confidence: Optional[float] = None
    optimizations: Optional[List[str]] = None
    warnings: Optional[List[str]] = None
    error: Optional[str] = None
    summary: Optional[str] = None
    visualization: Optional[Dict[str, Any]] = None
    visualization_html: Optional[str] = None
    optimized_question: Optional[str] = None
    session_id: str = ""
    tables_used: Optional[Dict[str, Any]] = Field(None, description="Tables referenced in the SQL query with column types and sample data")
    agent_steps: Optional[List[Dict[str, Any]]] = Field(None, description="Agent reasoning trace (only when CONVOBI_AGENT_VERBOSE=true)")

# ---------------------------------------------------------------------------
# Plotly Visualization Helpers
# ---------------------------------------------------------------------------


def _infer_chart_type(columns: List[str], data: List[Dict[str, Any]]) -> str:
    """Heuristic: pick a chart type from columns and data shape."""
    if not columns or not data:
        return "table"
    sample = data[:20]
    num_cols: List[str] = []
    cat_cols: List[str] = []
    date_cols: List[str] = []
    for col in columns:
        vals = [r.get(col) for r in sample if r.get(col) is not None]
        if not vals:
            continue
        if all(isinstance(v, (int, float)) for v in vals):
            num_cols.append(col)
        elif any(_looks_like_date(v) for v in vals[:5]):
            date_cols.append(col)
        else:
            cat_cols.append(col)
    if date_cols and num_cols:
        return "line"
    if cat_cols and num_cols:
        unique_cats = len({r.get(cat_cols[0]) for r in data if r.get(cat_cols[0]) is not None})
        if unique_cats <= 8 and len(num_cols) == 1:
            return "pie"
        return "bar"
    if len(num_cols) >= 2:
        return "scatter"
    return "bar" if num_cols else "table"


def _looks_like_date(val: Any) -> bool:
    s = str(val)
    return bool(re.search(r"\d{4}[-/]\d{1,2}", s)) or bool(re.search(r"\d{1,2}[-/]\d{1,2}[-/]\d{2,4}", s))


def _json_serial_default(obj: Any) -> Any:
    """Convert non-JSON-serializable values (datetime, Decimal) for Plotly."""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return int(obj) if obj == int(obj) else float(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__!r} is not JSON serializable")


def _summarize_visualization_html_for_log(value: Optional[str]) -> Dict[str, Any]:
    html = value or ""
    prefix = " ".join(html[:120].split())
    return {
        "exists": bool(value),
        "length": len(html),
        "starts_with_doctype": html.startswith("<!DOCTYPE"),
        "starts_with_escaped_doctype": html.startswith("&lt;!DOCTYPE"),
        "escaped_tag_count": html.count("&lt;"),
        "prefix": prefix,
    }


def build_plotly_visualization(columns: List[str], data: List[Dict[str, Any]], question: str = "") -> Optional[Dict[str, Any]]:
    """Build Plotly visualization metadata payload for frontend rendering."""
    if not columns or not data:
        LOG.info(
            "[ConvoBI][Viz] skipping visualization build: columns=%s data_rows=%s",
            len(columns or []),
            len(data or []),
        )
        return None
    chart_type = _infer_chart_type(columns, data)
    if chart_type == "table":
        LOG.info(
            "[ConvoBI][Viz] skipping visualization build: chart_type=%s columns=%s data_rows=%s",
            chart_type,
            len(columns or []),
            len(data or []),
        )
        return None

    LOG.info(
        "[ConvoBI][Viz] building visualization: chart_type=%s columns=%s data_rows=%s question_len=%s",
        chart_type,
        len(columns),
        len(data),
        len(question or ""),
    )

    traces: List[Dict[str, Any]] = []
    layout: Dict[str, Any] = {
        "margin": {"t": 40, "b": 60, "l": 60, "r": 30},
        "font": {"family": "system-ui, sans-serif"},
        "template": "plotly_white",
    }

    num_cols = [
        c for c in columns
        if all(isinstance(r.get(c), (int, float, type(None))) for r in data[:20])
        and any(r.get(c) is not None for r in data[:20])
    ]
    cat_cols = [c for c in columns if c not in num_cols]
    date_cols = [
        c for c in cat_cols
        if any(_looks_like_date(r.get(c)) for r in data[:5] if r.get(c) is not None)
    ]

    if chart_type == "line" and date_cols and num_cols:
        x_col = date_cols[0]
        for y_col in num_cols[:3]:
            traces.append({
                "x": [r.get(x_col) for r in data],
                "y": [r.get(y_col) for r in data],
                "type": "scatter",
                "mode": "lines+markers",
                "name": y_col,
            })
        layout["xaxis"] = {"title": x_col}
        layout["yaxis"] = {"title": num_cols[0] if len(num_cols) == 1 else "Value"}

    elif chart_type == "bar":
        x_col = cat_cols[0] if cat_cols else columns[0]
        y_col = num_cols[0] if num_cols else (columns[1] if len(columns) > 1 else columns[0])
        traces.append({
            "x": [r.get(x_col) for r in data],
            "y": [r.get(y_col) for r in data],
            "type": "bar",
            "name": y_col,
        })
        layout["xaxis"] = {"title": x_col}
        layout["yaxis"] = {"title": y_col}

    elif chart_type == "pie":
        label_col = cat_cols[0] if cat_cols else columns[0]
        value_col = num_cols[0] if num_cols else (columns[1] if len(columns) > 1 else columns[0])
        traces.append({
            "labels": [r.get(label_col) for r in data],
            "values": [r.get(value_col) for r in data],
            "type": "pie",
        })

    elif chart_type == "scatter" and len(num_cols) >= 2:
        traces.append({
            "x": [r.get(num_cols[0]) for r in data],
            "y": [r.get(num_cols[1]) for r in data],
            "type": "scatter",
            "mode": "markers",
            "name": f"{num_cols[0]} vs {num_cols[1]}",
        })
        layout["xaxis"] = {"title": num_cols[0]}
        layout["yaxis"] = {"title": num_cols[1]}

    else:
        return None

    if question:
        layout["title"] = {"text": question[:80], "font": {"size": 14}}

    LOG.info("TRACES=%s", traces)
    LOG.info("LAYOUT=%s", layout)

    return {
        "enabled": True,
        "chart_type": chart_type,
        "traces": traces,
        "layout": layout,
    }


def build_plotly_html(
    columns: List[str],
    data: List[Dict[str, Any]],
    question: str = "",
    visualization: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """Build a self-contained Plotly.js HTML snippet for embedding in an iframe."""
    viz = visualization or build_plotly_visualization(columns, data, question)
    if not viz:
        return None

    traces = viz.get("traces", [])
    layout = viz.get("layout", {})

    spec_json = json.dumps(
    {"data": traces, "layout": layout},
    default=_json_serial_default,
    )

    spec_escaped = spec_json.replace("</", "<\\/")

    html = (
    "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<style>html,body{width:100%;height:100%;margin:0;padding:0;"
    "font-family:system-ui,sans-serif}"
    "#chart{width:100%;height:100%;min-height:300px}</style>"
    "<script src='https://cdn.plot.ly/plotly-2.35.0.min.js'></script>"
    "</head><body><div id='chart'></div><script>(function(){"
    "var spec=" + spec_escaped + ";"
    "Plotly.newPlot('chart',spec.data,spec.layout,"
    "{responsive:true,displayModeBar:true});"
    "})();</script></body></html>"
    )

    LOG.info("FINAL_HTML_START=%s", html[:1000])
    LOG.info("FINAL_HTML_REPR=%s", repr(html[:1000]))

    return html
# ---------------------------------------------------------------------------
# LangGraph Agent State
# ---------------------------------------------------------------------------


class AgentState(TypedDict):
    messages: Annotated[list, add_messages]


# ---------------------------------------------------------------------------
# Schema hint for agent (column examples)
# ---------------------------------------------------------------------------


# ~4 chars/token; 750 tokens = 3000 chars — more examples for accuracy
_SCHEMA_HINT_MAX_CHARS = 3000

# Tool output truncation to avoid context overflow (128k limit)
# ~1500 tokens per tool call; schema/query outputs can be huge
_MAX_TOOL_OUTPUT_CHARS = 6000


# Simple stemmer: common suffixes
_STEM_SUFFIXES = [
    ("ies", "y"), ("es", ""), ("s", ""), ("ed", ""), ("ing", ""),
    ("ly", ""), ("er", ""), ("est", ""), ("tion", ""), ("ally", ""),
]

# Synonym expansion for column matching
_TERM_SYNONYMS: Dict[str, List[str]] = {
    "win": ["wins", "won", "winning"],
    "loss": ["lost", "losing"],
    "revenue": ["sales", "amount", "value", "fee", "fees"],
    "customer": ["client", "account"],
    "date": ["month", "year", "time", "period"],
    "service": ["group", "line", "area"],
    "industry": ["sector", "segment"],
}


def _stem_word(word: str) -> str:
    """Simple stem: remove common suffixes."""
    w = word.lower()
    for suf, repl in _STEM_SUFFIXES:
        if len(w) > len(suf) + 2 and w.endswith(suf):
            return w[:-len(suf)] + repl
    return w


def _expand_with_synonyms(word: str) -> List[str]:
    """Return word and its synonyms for matching."""
    w = word.lower()
    result = [w]
    for base, syns in _TERM_SYNONYMS.items():
        if w == base or w in syns:
            result.extend([base] + syns)
    return list(dict.fromkeys(result))


def _extract_question_keywords(question: str) -> List[str]:
    """Extract meaningful keywords from question for relevance scoring. Includes stemmed forms and synonyms."""
    if not question or not question.strip():
        return []
    stop = {
        "the", "a", "an", "what", "how", "many", "show", "give", "me", "list",
        "get", "of", "in", "for", "to", "by", "from", "with", "and", "or",
        "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
        "do", "does", "did", "will", "would", "could", "should", "can", "may",
    }
    words = re.findall(r"[a-zA-Z0-9_]+", question.lower())
    seen: set = set()
    result: List[str] = []
    for w in words:
        if len(w) > 1 and w not in stop and w not in seen:
            seen.add(w)
            result.append(w)
            stemmed = _stem_word(w)
            if stemmed != w and stemmed not in seen:
                seen.add(stemmed)
                result.append(stemmed)
            for syn in _expand_with_synonyms(w):
                if syn not in seen and len(syn) > 1:
                    seen.add(syn)
                    result.append(syn)
    return result


def _score_table_relevance(tname: str, keywords: List[str]) -> int:
    """Score table name relevance to question keywords."""
    if not keywords:
        return 0
    tlower = tname.lower()
    return sum(1 for k in keywords if k in tlower)


def _score_column_relevance(col_name: str, examples: List[str], keywords: List[str]) -> int:
    """Score column relevance: name + example values."""
    if not keywords:
        return 0
    score = sum(1 for k in keywords if k in col_name.lower())
    ex_str = " ".join(str(e).lower() for e in (examples or [])[:20])
    score += sum(1 for k in keywords if k in ex_str)
    return score


def _format_schema_hint_for_question(
    tables: Dict[str, Any],
    question: str,
    max_chars: int = _SCHEMA_HINT_MAX_CHARS,
) -> str:
    """
    Format question-aware column examples. Only includes tables/columns
    relevant to the question to stay within token budget.
    """
    if not tables or not question:
        return ""
    keywords = _extract_question_keywords(question)
    lines = ["COLUMN EXAMPLES (pick columns whose examples match the question):", ""]
    total = len("\n".join(lines))
    max_per_col = 5
    max_col_len = 25
    max_cols_per_table = 10

    # Score and sort tables by relevance
    scored_tables = [
        (tname, _score_table_relevance(tname, keywords))
        for tname in tables.keys()
    ]
    scored_tables.sort(key=lambda x: (-x[1], x[0]))
    # If no keyword match, include first few tables; otherwise take top relevant
    if not any(s > 0 for _, s in scored_tables):
        top_tables = [t for t, _ in scored_tables[:4]]
    else:
        top_tables = [t for t, s in scored_tables if s > 0][:6]
        if len(top_tables) < 2:
            top_tables = [t for t, _ in scored_tables[:4]]

    for tname in top_tables:
        if total >= max_chars:
            break
        tbl = tables.get(tname, {})
        cols = tbl.get("columns", [])
        if not cols:
            continue
        # Score columns and take most relevant
        col_scores = [
            (c, _score_column_relevance(
                c.get("name", ""),
                c.get("examples", []),
                keywords,
            ))
            for c in cols
        ]
        col_scores.sort(key=lambda x: (-x[1], x[0].get("name", "")))
        top_cols = [c for c, s in col_scores[:max_cols_per_table]]
        if not top_cols and cols:
            top_cols = cols[:max_cols_per_table]

        block = [f"Table {tname}:"]
        for col in top_cols:
            if total >= max_chars:
                break
            name = col.get("name", "")
            examples = col.get("examples", [])[:max_per_col]
            dtype = col.get("type", "UNKNOWN")

            block.append(
                f"  {name} [TYPE={dtype}]"
            )

            if examples:
                preview = ", ".join(
                    str(v)[:max_col_len]
                    for v in examples
                )

                block.append(
                    f"    Examples: {preview}"
                )
        block.append("")
        block_str = "\n".join(block)
        total += len(block_str)
        lines.extend(block)

    if total >= max_chars:
        lines.append("(truncated)")
    return "\n".join(lines)


def _format_schema_hint_for_agent(tables: Dict[str, Any]) -> str:
    """
    Format a compact schema hint with column examples for the agent.
    Used when no question is available (e.g. connection activation).
    Capped at ~500 tokens to avoid context overflow (128k limit).
    """
    if not tables:
        return ""
    lines = ["\n\nCOLUMN EXAMPLES (pick columns whose examples match the question):", ""]
    total = len("\n".join(lines))
    max_per_col = 3
    max_col_len = 20
    max_tables = 4
    max_cols_per_table = 8

    for tname in sorted(tables.keys())[:max_tables]:
        if total >= _SCHEMA_HINT_MAX_CHARS:
            break
        tbl = tables[tname]
        cols = tbl.get("columns", [])[:max_cols_per_table]
        if not cols:
            continue
        block = [f"Table {tname}:"]
        for col in cols:
            if total >= _SCHEMA_HINT_MAX_CHARS:
                break
            name = col.get("name", "")
            examples = col.get("examples", [])[:max_per_col]
            if examples:
                preview = ", ".join(str(v)[:max_col_len] for v in examples)
                # The below adds schema hin to LLM
                dtype = col.get("type", "UNKNOWN")
                block.append(
                    f"  {name} [TYPE={dtype}]"
                )

                block.append(
                    f"    Examples: {preview}"
                )
            else:
                dtype = col.get("type", "UNKNOWN")

                block.append(
                    f"  {name} [TYPE={dtype}]"
                )
        block.append("")
        block_str = "\n".join(block)
        total += len(block_str)
        lines.extend(block)

    if total >= _SCHEMA_HINT_MAX_CHARS:
        lines.append("(truncated)")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# System Prompt Builder
# ---------------------------------------------------------------------------


_PROMPT_CONFIG_PATH = Path(__file__).parent / "convobi_prompt_config.json"
_PROMPT_CONFIG_CACHE: Dict[str, Any] = {}
_PROMPT_CONFIG_MTIME: float = 0


def _load_prompt_config() -> Dict[str, Any]:
    """Load per-database prompt config from JSON."""
    global _PROMPT_CONFIG_CACHE, _PROMPT_CONFIG_MTIME
    path = os.getenv("CONVOBI_PROMPT_CONFIG", str(_PROMPT_CONFIG_PATH))
    try:
        mtime = os.path.getmtime(path) if os.path.exists(path) else 0
        if mtime != _PROMPT_CONFIG_MTIME or not _PROMPT_CONFIG_CACHE:
            _PROMPT_CONFIG_MTIME = mtime
            with open(path, "r", encoding="utf-8") as f:
                _PROMPT_CONFIG_CACHE = json.load(f)
    except Exception as e:
        LOG.warning("Could not load prompt config from %s: %s. Using empty config.", path, e)
        _PROMPT_CONFIG_CACHE = {"domains": {"default": {"few_shot_examples": "", "domain_rules": "", "term_to_column": {}, "glossary_hint": ""}}}
    return _PROMPT_CONFIG_CACHE


def _get_prompt_config_for_connection() -> Dict[str, Any]:
    """Return prompt config for the active connection (per-database variables)."""
    config = _load_prompt_config()
    mapping = config.get("connection_domain_mapping", {})
    domains = config.get("domains", {})

    domain_key = mapping.get("default", "default")
    try:
        cid = app_state.get("active_connection_id")
        if cid and cid in mapping:
            domain_key = mapping[cid]
        elif cid:
            saved = Path(__file__).resolve().parent.parent / "connector" / "saved_db_connections.json"
            if saved.exists():
                with open(saved, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for conn in data.get("connections", []):
                    if conn.get("id") == cid:
                        name = (conn.get("name") or "").upper()
                        if ("ITSM" in name or "SUMMITAI" in name) and "itsm" in domains:
                            domain_key = "itsm"
                        elif ("CRM" in name or "OPPORTUNITIES" in name) and "crm" in domains:
                            domain_key = "crm"
                        break
    except Exception:
        pass

    domain = domains.get(domain_key, domains.get("default", {}))
    return {
        "few_shot_examples": domain.get("few_shot_examples", ""),
        "domain_rules": domain.get("domain_rules", ""),
        "term_to_column": domain.get("term_to_column", {}),
        "glossary_hint": domain.get("glossary_hint", ""),
    }


def _build_system_prompt(
    dialect: str,
    glossary_hint: str = "",
    few_shot_examples: str = "",
    domain_rules: str = "",
    term_to_column: Optional[Dict[str, str]] = None,
) -> str:
    dialect_rules = {
        "sqlite": (
            "SQLite rules: use date('now','-N units')/strftime, LIMIT (not TOP), "
            "CURRENT_TIMESTAMP not NOW(), no INTERVAL, no DATE_TRUNC."
        ),
        "mssql": (
            "MSSQL rules: use TOP N (not LIMIT), FORMAT(col,'yyyy-MM') for month, "
            "DATEADD/DATEDIFF for date arithmetic, GETDATE() for current time."
        ),
        "postgres": (
            "PostgreSQL rules: use LIMIT, DATE_TRUNC, INTERVAL, NOW(), "
            "TO_CHAR for date formatting."
        ),
        "mysql": (
            "MySQL rules: use LIMIT, DATE_FORMAT, NOW(), INTERVAL, "
            "DATE_SUB/DATE_ADD for date arithmetic."
        ),
        "oracle": (
            "Oracle rules: use ROWNUM or FETCH FIRST N ROWS ONLY, SYSDATE, "
            "TO_CHAR for date formatting, ADD_MONTHS for date arithmetic."
        ),
    }
    rules = dialect_rules.get(dialect, dialect_rules["sqlite"])

    # Per-database variables appended at END of prompt to avoid context dilution in the middle
    db_specific_section = ""
    if few_shot_examples and few_shot_examples.strip():
        db_specific_section += "\n\n--- DATABASE-SPECIFIC EXAMPLES (for this connection only) ---\n" + few_shot_examples.strip()
    if domain_rules and domain_rules.strip():
        db_specific_section += "\n\n--- DATABASE-SPECIFIC RULES ---\n" + domain_rules.strip()
    if glossary_hint and glossary_hint.strip():
        db_specific_section += "\n\n--- DATABASE-SPECIFIC GLOSSARY / COLUMN GUIDANCE ---\n" + glossary_hint.strip()
    term_map = term_to_column or {}
    if term_map:
        lines = [f"- {term}: {guidance}" for term, guidance in term_map.items()]
        db_specific_section += "\n\n--- TERM-TO-COLUMN MAPPING (for this connection) ---\n" + "\n".join(lines)

    return (
        "You are an expert data analyst and SQL agent. "
        "You have access to a SQL database and tools to explore and query it.\n\n"
        "WORKFLOW:\n"
        "1. Use sql_db_list_tables to discover available tables.\n"
        "2. Use sql_db_schema to understand relevant table structures and column examples.\n"
        "3. ALWAYS use sql_db_query_checker to validate your SQL before executing.\n"
        "4. Use sql_db_query to execute the query and get results.\n"
        "5. If sql_db_query fails, read the error, fix the SQL, and retry (up to 2 retries).\n"
        "6. Analyze the results thoroughly and formulate a detailed structured response.\n\n"
        f"DATABASE DIALECT: {dialect}\n{rules}\n\n"
        "RULES:\n"
        "- Only use tables and columns that exist in the schema.\n"
        "- Do NOT use DML (INSERT, UPDATE, DELETE, DROP) unless explicitly asked.\n"
        "- Use ALL column examples from the tables: scan every column's examples before choosing. Use get_column_for_term tool when unsure about column mapping.\n"
        "- COLUMN EXAMPLES ARE AUTHORITATIVE. Always inspect actual example values before generating SQL.\n"
        "- Do not rely solely on column names.\n"
        "- Physical data types and example values must both be considered.\n"
        "- DATE HANDLING RULES (CRITICAL):\n"
        "- Column examples are authoritative.\n"
        "- Always inspect date column examples before generating SQL for date-related questions.\n"
        "- Before using any date function, verify that the stored values are compatible with the database dialect.\n"
        "- Never assume a TEXT column can be parsed as a date.\n"
        "- Derive filtering, grouping, sorting, and aggregation logic from the actual stored format shown in the examples.\n"
        "- If the stored format is not natively supported by the database, use SQL logic compatible with the stored representation instead.\n"
        "- When uncertain, prefer SQL that directly matches the stored value format over SQL that relies on date parsing functions.\n"
        "- For date questions, always review the column examples first and choose an approach compatible with the stored values.\n"
        "- When the user mentions specific values (e.g. industry names, Win, Loss), match them to columns whose examples contain those values.\n"
        "- When a value is in double quotes (e.g. \"Chopra, Ajay\"), treat it as ONE string. Use = 'Chopra, Ajay' not IN ('Chopra', 'Ajay'). Do NOT split by comma.\n"
        "- When multiple columns have similar names, compare ALL their examples and select the one whose examples best match the question.\n"
        "- For trends/monthly breakdowns, GROUP BY the time period and "
        "return one row per period.\n"
        "- If a query fails, read the error and fix the SQL.\n"
        "- When choosing columns, prefer the column whose NAME or examples "
        "match the question.\n"
        "- For monthly trend or trend-over-time questions: GROUP BY the time "
        "period (month) and SELECT the period label plus the aggregate; "
        "return one row per period, not a single total.\n"
        "- For 'last N months' questions, filter by the date column.\n"
        "- Do NOT add LIMIT or TOP unless the user explicitly asks for a limited "
        "number (e.g. 'top 10', 'first 5', 'show only 20'). Otherwise return all "
        "matching rows.\n\n"
        "RESPONSE FORMAT:\n"
        "After obtaining the query results, you MUST respond with ONLY a valid JSON object "
        "(no markdown code fences, no extra text before or after). The JSON MUST have exactly "
        "these keys:\n"
        "{\n"
        '  "sql": "the exact SQL query you executed",\n'
        '  "response": "A brief, direct 1-3 sentence answer using ONLY the actual '
        'names and numbers from the sql_db_query results. No markdown, no formatting.",\n'
        '  "explanation": "One clear sentence explaining what the query does and '
        'why you chose this approach",\n'
        '  "summary": "A comprehensive analytical markdown report (using ONLY actual query results) structured as follows:\\n\\n'
        "## Key Findings\\n"
        "- State the direct answer with **bold key numbers/totals** from the query results\\n"
        "- Include percentages and proportions where applicable\\n\\n"
        "## Analytics\\n"
        "- Provide statistical breakdowns (min, max, average, total counts)\\n"
        "- Calculate percentage distributions across categories\\n"
        "- Highlight the top/bottom performers or values\\n\\n"
        "## Trends & Patterns\\n"
        "- Identify time-based trends (increasing, decreasing, stable, seasonal)\\n"
        "- Note rate of change between periods (e.g. +15% month-over-month)\\n"
        "- Call out any cyclical or seasonal patterns\\n\\n"
        "## Insights & Anomalies\\n"
        "- Highlight anything unusual, unexpected, or noteworthy\\n"
        "- Compare against what might be expected\\n"
        "- Note any data gaps or outliers\\n\\n"
        "## Actionable Takeaways\\n"
        "- Suggest next steps or areas to investigate further\\n"
        '- Recommend follow-up queries if the data suggests deeper questions",\n'
        '  "confidence": <float 0.0-1.0>,\n'
        '  "warnings": ["list any assumptions, ambiguities, or data quality issues"],\n'
        '  "optimizations": ["SQL performance suggestions or alternative approaches, if any"]\n'
        "}\n\n"
        "CRITICAL - NEVER HALLUCINATE:\n"
        "- If a relationship between tables is not shown by sql_db_schema, do not invent one.\n"
        "- If a join path does not exist, explain that the question cannot be answered.\n"
        "- Never create columns that are not present in sql_db_schema output.\n"
        "- Never create foreign keys, joins, mappings, or relationships.\n"
        "- When schema is insufficient, stop and explain what information is missing.\n"
        "- Use ONLY names, numbers, and values from the actual sql_db_query results.\n"
        "- Never invent or fabricate person names, counts, or statistics.\n"
        "- If results are empty or truncated, say so explicitly—do not invent placeholders like 'John Doe' or '150'.\n"
        "- NEVER use SQL column names (e.g. [Resolved Updated By User Name], ticket_count) as the answer—those are column labels, not data. The result format is a list of tuples like [('ActualName', 123)]; use the tuple values.\n"
        "- If sql_db_query returns an empty string or [] (zero rows), you MUST respond with 'No data is available' or 'No results found'—never invent dummy data, example names, or fake statistics. Do not fill in Key Findings, Analytics, or Insights with fabricated content.\n\n"
        "ANALYSIS GUIDELINES:\n"
        "- Always compute totals and averages when the data supports it.\n"
        "- For time-series data, compute period-over-period change (absolute and %).\n"
        "- For categorical data, show the distribution (% share of each category).\n"
        "- If the result has only 1 row, provide context by explaining what the number means.\n"
        "- If the result has multiple rows, look for patterns: which is highest/lowest, "
        "is there a trend, are values clustered or spread out.\n"
        "- Never just restate the raw numbers — interpret them, but only using actual data.\n\n"
        "CONFIDENCE GUIDE:\n"
        "- 0.95-1.0: Perfect match — unambiguous question, clean data, exact answer.\n"
        "- 0.80-0.94: Good match — minor assumptions made (e.g. date range inferred).\n"
        "- 0.60-0.79: Reasonable match — notable assumptions or partial data.\n"
        "- Below 0.60: Significant uncertainty — explain in warnings.\n\n"
        "If the query fails and you cannot recover, still return the JSON with "
        '"sql" set to the attempted query, "confidence" below 0.5, and explain '
        'the error in "summary" and "warnings".'
        f"{db_specific_section}"
    )


# ---------------------------------------------------------------------------
# Agent Builder
# ---------------------------------------------------------------------------


def _get_term_to_column_map() -> Dict[str, str]:
    """Return term-to-column mapping from per-database prompt config."""
    return _get_prompt_config_for_connection().get("term_to_column", {})


def _create_get_column_for_term_tool() -> Any:
    """Create tool to look up the correct column for a business term."""
    @tool
    def get_column_for_term(term: str) -> str:
        """Look up the correct database column for a business term. Use when unsure which column to use for wins, revenue, customer, service group, tickets, incidents, status, etc. Returns the column name and usage guidance."""
        t = str(term).strip().lower()
        if not t:
            return "Provide a business term (e.g. wins, revenue, customer, ticket, incident, status)."
        term_map = _get_term_to_column_map()
        for key, guidance in term_map.items():
            if key in t or t in key:
                return guidance
        glossary = _get_column_glossary_dict()
        matches = []
        for col, desc in glossary.items():
            if t in col.lower() or t in desc.lower():
                matches.append(f"{col}: {desc[:120]}...")
        if matches:
            return "Possible columns:\n" + "\n".join(matches[:5])
        return f"No specific mapping for '{term}'. Check sql_db_schema for column examples."
    return get_column_for_term


def _build_checkpointer():
    """Create the appropriate checkpointer based on env config."""
    if CONVOBI_CHECKPOINTER == "postgres" and CONVOBI_CHECKPOINT_POSTGRES_URL:
        try:
            from langgraph.checkpoint.postgres import PostgresSaver
            return PostgresSaver.from_conn_string(CONVOBI_CHECKPOINT_POSTGRES_URL)
        except Exception as e:
            LOG.warning("PostgresSaver init failed (%s); falling back to MemorySaver", e)
    return MemorySaver()


def build_agent(
    llm: Any,
    db_instance: SQLDatabase,
    dialect: str,
    glossary_hint: str = "",
    checkpointer: Any = None,
):
    """
    Build a LangGraph ReAct agent with SQLDatabaseToolkit tools +
    custom visualisation / summarisation tools.

    Returns a compiled LangGraph that can be .invoke()-ed.
    """
    # ---- legacy toolkit built (failed as otel wrapper changed) -------
    # toolkit = SQLDatabaseToolkit(db=db_instance, llm=llm)

    toolkit_llm = (
    llm.wrapped_llm
    if isinstance(llm, OTelLLMWrapper)
        else llm
    )

    LOG.info(
        "[ConvoBI] SQLDatabaseToolkit using llm_type=%s",
        type(toolkit_llm).__name__,
    )

    from langchain_core.language_models import BaseLanguageModel

    def debug_llm_chain(llm):
        current = llm
        depth = 0

        LOG.error(
            "[LLM_DEBUG] START type=%s",
            type(current),
        )

        while current and depth < 10:

            LOG.error(
                "[LLM_DEBUG] depth=%s type=%s is_base=%s",
                depth,
                type(current),
                isinstance(current, BaseLanguageModel),
            )

            LOG.error(
                "[LLM_DEBUG] has_wrapped_llm=%s has__llm=%s",
                hasattr(current, "wrapped_llm"),
                hasattr(current, "_llm"),
            )

            if hasattr(current, "wrapped_llm"):

                LOG.error(
                    "[LLM_DEBUG] unwrapping via wrapped_llm -> %s",
                    type(current.wrapped_llm),
                )

                current = current.wrapped_llm

            elif hasattr(current, "_llm"):

                LOG.error(
                    "[LLM_DEBUG] unwrapping via _llm -> %s",
                    type(current._llm),
                )

                current = current._llm

            else:
                break

            depth += 1

        LOG.error(
            "[LLM_DEBUG] FINAL type=%s is_base=%s",
            type(current),
            isinstance(current, BaseLanguageModel),
        )

        return current


    toolkit_llm = debug_llm_chain(llm)

    LOG.error(
        "[SQL_TOOLKIT] FINAL_LLM_TYPE=%s",
        type(toolkit_llm),
    )

    LOG.error(
        "[SQL_TOOLKIT] FINAL_IS_BASE=%s",
        isinstance(toolkit_llm, BaseLanguageModel),
    )

    LOG.error(
        "[SQL_TOOLKIT] FINAL_MRO=%s",
        type(toolkit_llm).mro(),
    )

    try:
        toolkit = SQLDatabaseToolkit(
            db=db_instance,
            llm=toolkit_llm,
        )
    except Exception:
        LOG.exception(
            "[SQL_TOOLKIT] CREATION FAILED"
        )

        LOG.error(
            "[SQL_TOOLKIT] LLM_TYPE=%s",
            type(toolkit_llm),
        )

        LOG.error(
            "[SQL_TOOLKIT] IS_BASE=%s",
            isinstance(toolkit_llm, BaseLanguageModel),
        )

        raise
    toolkit_tools = toolkit.get_tools()
    column_lookup_tool = _create_get_column_for_term_tool()

    all_tools = list(toolkit_tools) + [column_lookup_tool]
    raw_tool_node = ToolNode(all_tools)

    prompt_cfg = _get_prompt_config_for_connection()
    hint = glossary_hint or prompt_cfg.get("glossary_hint", "")
    system_prompt = _build_system_prompt(
        dialect,
        glossary_hint=hint,
        few_shot_examples=prompt_cfg.get("few_shot_examples", ""),
        domain_rules=prompt_cfg.get("domain_rules", ""),
        term_to_column=prompt_cfg.get("term_to_column", {}),
    )

    llm_with_tools = llm.bind_tools(all_tools)

    def agent_node(state: AgentState) -> Dict[str, Any]:
        msgs = list(state["messages"])
        if not msgs or not isinstance(msgs[0], SystemMessage):
            msgs = [SystemMessage(content=system_prompt)] + msgs

        # Trim to avoid context overflow (128k limit); keep system + recent messages
        msgs = trim_messages(
            msgs,
            max_tokens=80_000,
            token_counter=count_tokens_approximately,
            strategy="last",
            include_system=True,
            start_on="human",
        )

        step_count = sum(1 for m in msgs if isinstance(m, (AIMessage, ToolMessage)))
        if CONVOBI_AGENT_VERBOSE:
            LOG.info("[ConvoBI Agent] Step %d — invoking LLM (messages=%d)", step_count, len(msgs))
        else:
            LOG.debug("[ConvoBI Agent] Invoking LLM (messages=%d)", len(msgs))

        t0 = time.time()
        response = llm_with_tools.invoke(msgs)
        elapsed = (time.time() - t0) * 1000

        if getattr(response, "tool_calls", None):
            tool_names = ", ".join(tc.get("name", "?") for tc in response.tool_calls)
            if CONVOBI_AGENT_VERBOSE:
                LOG.info(
                    "[ConvoBI Agent] Step %d — LLM requesting tools: [%s] (%.0fms)",
                    step_count, tool_names, elapsed,
                )
            else:
                LOG.debug("[ConvoBI Agent] LLM → tools: [%s] (%.0fms)", tool_names, elapsed)
        else:
            content_preview = (getattr(response, "content", "") or "")[:200]
            if CONVOBI_AGENT_VERBOSE:
                LOG.info(
                    "[ConvoBI Agent] Step %d — LLM final response (%.0fms): %s...",
                    step_count, elapsed, content_preview,
                )
            else:
                LOG.debug("[ConvoBI Agent] LLM final response (%.0fms)", elapsed)

        return {"messages": [response]}

    def logging_tool_node(state: AgentState) -> Dict[str, Any]:
        last_msg = state["messages"][-1]
        tool_names: List[str] = []
        if isinstance(last_msg, AIMessage) and getattr(last_msg, "tool_calls", None):
            tool_names = [tc.get("name", "?") for tc in last_msg.tool_calls]
            if CONVOBI_AGENT_VERBOSE:
                for tc in last_msg.tool_calls:
                    args_str = json.dumps(tc.get("args", {}), default=str)[:500]
                    LOG.info("[ConvoBI Tools] Executing: %s | Args: %s", tc.get("name"), args_str)
            else:
                LOG.debug("[ConvoBI Tools] Executing: %s", ", ".join(tool_names))

        t0 = time.time()
        tables_cache = app_state.get(
            "tables_cache",
            {},
        )
        VALIDATED_SQL_TOOLS = {
            "sql_db_query",
            "sql_db_query_checker",
        }
        for tc in getattr(last_msg, "tool_calls", []):
            if tc.get("name") not in VALIDATED_SQL_TOOLS:
                continue
            sql = tc.get(
                "args",
                {},
            ).get(
                "query",
                "",
            )
            if tc.get("name") == "sql_db_query":
                LOG.info("[SQL] generated")

            elif tc.get("name") == "sql_db_query_checker":
                LOG.debug("[SQL_CHECKER] invoked")
            valid, error = validate_sql_against_schema(
            sql,
            tables_cache,
            )
            if not valid:

                sql_hash = _sql_fingerprint(sql)

                seen_sqls = app_state.setdefault(
                    "seen_sql_hashes",
                    set(),
                )

                if sql_hash in seen_sqls:

                    LOG.error(
                        "[AGENT_SQL_LOOP] repeated_invalid_sql_detected "
                        "hash=%s sql=%s",
                        sql_hash,
                        sql[:300],
                    )

                    return {
                        "messages": [
                            ToolMessage(
                                content=(
                                    "FINAL_SQL_VALIDATION_ERROR\n\n"
                                    "The same invalid SQL query was "
                                    "generated multiple times.\n\n"
                                    "Agent execution stopped."
                                ),
                                tool_call_id=tc["id"],
                                name=tc["name"],
                            )
                        ]
                    }

                seen_sqls.add(sql_hash)

                attempts = (
                    app_state.get(
                        "invalid_sql_attempts",
                        0,
                    ) + 1
                )

                app_state[
                    "invalid_sql_attempts"
                ] = attempts

                LOG.warning(
                    "[SQL_VALIDATOR] invalid_attempt=%s reason=%s",
                    attempts,
                    error,
                )
                if attempts >= MAX_INVALID_SQL_ATTEMPTS:
                    LOG.error(
                        "[AGENT_SQL_ABORT] "
                        "max_invalid_attempts_reached "
                        "attempts=%s",
                        attempts,
                    )

                    return {
                        "messages": [
                            ToolMessage(
                                content=(
                                    "FINAL_SQL_VALIDATION_ERROR\n\n"
                                    f"{error}\n\n"
                                    "The agent generated invalid SQL "
                                    "multiple times.\n\n"
                                    "Execution stopped."
                                ),
                                tool_call_id=tc["id"],
                                name=tc["name"],
                            )
                        ]
                    }
                LOG.warning(
                    "[SQL_VALIDATOR] blocked "
                    "attempt=%s sql=%s reason=%s",
                    attempts,
                    sql[:500],
                    error,
                )
                return {
                    "messages": [
                        ToolMessage(
                            content=f"SQL_VALIDATION_ERROR: {error}",
                            tool_call_id=tc["id"],
                            name=tc["name"],
                        )
                    ]
                }
        result = raw_tool_node.invoke(state)
        for msg in result.get("messages", []):
            if not isinstance(msg, ToolMessage):
                continue

        elapsed = (time.time() - t0) * 1000
        for msg in result.get("messages", []):
            if not isinstance(msg, ToolMessage):
                continue

            LOG.debug("Tool executed: %s", msg.name)

        # Truncate tool outputs to avoid context overflow (128k limit)
        # Higher limits for schema and query results (both critical for accuracy—truncation causes hallucination)
        truncated_messages = []
        for msg in result.get("messages", []):
            if isinstance(msg, ToolMessage) and msg.content:
                tool_name = (msg.name or "").lower()
                if tool_name == "sql_db_schema":
                    limit = 10000
                elif tool_name == "sql_db_query":
                    limit = 15000  # Query results must be visible to avoid inventing names/numbers
                else:
                    limit = _MAX_TOOL_OUTPUT_CHARS
                if len(msg.content) > limit:
                    msg = ToolMessage(
                        content=msg.content[:limit]
                        + "\n\n[... output truncated due to length ...]",
                        tool_call_id=msg.tool_call_id,
                        name=msg.name,
                    )
            truncated_messages.append(msg)
        result = {"messages": truncated_messages}

        if CONVOBI_AGENT_VERBOSE:
            for msg in result.get("messages", []):
                if isinstance(msg, ToolMessage):
                    status = (
                        "ERROR"
                        if "error" in (msg.content or "").lower()[:100]
                        else "OK"
                    )
                    LOG.info(
                        "[ConvoBI Tools] %s [%s] (%.0fms)",
                        msg.name,
                        status,
                        elapsed,
                    )
        else:
            LOG.debug(
                "[ConvoBI Tools] %s completed (%.0fms)",
                ", ".join(tool_names),
                elapsed,
            )

        return result

    def should_continue(state: AgentState) -> str:
        last = state["messages"][-1]
        if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
            if CONVOBI_AGENT_VERBOSE:
                LOG.info("[ConvoBI Router] → tools")
            return "tools"
        if CONVOBI_AGENT_VERBOSE:
            LOG.info("[ConvoBI Router] → END")
        return END

    graph = StateGraph(AgentState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", logging_tool_node)
    graph.add_edge(START, "agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", END: END},
    )
    graph.add_edge("tools", "agent")

    return graph.compile(checkpointer=checkpointer)


# ---------------------------------------------------------------------------
# Result Parsing - Extract SQL, data, summary from agent messages
# ---------------------------------------------------------------------------


def _try_parse_structured_response(text_content: Optional[str]) -> Optional[Dict[str, Any]]:
    """Try to parse the agent's final message as a structured JSON response."""
    if not text_content:
        return None
    content = text_content.strip()

    # Direct JSON parse
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict) and ("sql" in parsed or "summary" in parsed):
            return parsed
    except (json.JSONDecodeError, ValueError):
        pass

    # Extract JSON from markdown code fences
    json_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", content, re.DOTALL)
    if json_match:
        try:
            parsed = json.loads(json_match.group(1).strip())
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass

    # Find a JSON object embedded in text
    brace_start = content.find("{")
    brace_end = content.rfind("}")
    if brace_start >= 0 and brace_end > brace_start:
        try:
            parsed = json.loads(content[brace_start : brace_end + 1])
            if isinstance(parsed, dict) and ("sql" in parsed or "summary" in parsed):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass

    return None


def _extract_agent_steps(messages: list) -> List[Dict[str, Any]]:
    """Build a structured reasoning trace from the agent's message history."""
    steps: List[Dict[str, Any]] = []
    step_num = 0
    ts = datetime.now().isoformat()

    for msg in messages:
        if isinstance(msg, SystemMessage):
            continue

        if isinstance(msg, HumanMessage):
            step_num += 1
            steps.append({
                "step": step_num,
                "node": "input",
                "event": "user_message",
                "content": (msg.content or "")[:200],
                "timestamp": ts,
            })

        elif isinstance(msg, AIMessage):
            step_num += 1
            if getattr(msg, "tool_calls", None):
                for tc in msg.tool_calls:
                    steps.append({
                        "step": step_num,
                        "node": "agent",
                        "event": "tool_call",
                        "tool": tc.get("name", "unknown"),
                        "input": json.dumps(tc.get("args", {}), default=str)[:500],
                        "timestamp": ts,
                    })
            else:
                steps.append({
                    "step": step_num,
                    "node": "agent",
                    "event": "final_response",
                    "content": (msg.content or "")[:500],
                    "timestamp": ts,
                })

        elif isinstance(msg, ToolMessage):
            step_num += 1
            output = (msg.content or "")[:1000]
            status = "error" if "error" in output.lower()[:100] else "success"
            steps.append({
                "step": step_num,
                "node": "tools",
                "event": "tool_result",
                "tool": getattr(msg, "name", "unknown"),
                "status": status,
                "output": output,
                "timestamp": ts,
            })

    return steps


def _extract_table_names_from_sql(sql: str) -> List[str]:
    """Parse SQL to extract referenced table names (FROM, JOIN, INTO clauses)."""
    if not sql:
        return []
    normalised = re.sub(r"--[^\n]*", " ", sql)
    normalised = re.sub(r"/\*.*?\*/", " ", normalised, flags=re.DOTALL)
    normalised = " ".join(normalised.split())

    patterns = [
        r'\bFROM\s+"?(\w+)"?',
        r'\bJOIN\s+"?(\w+)"?',
        r'\bINTO\s+"?(\w+)"?',
        r'\bUPDATE\s+"?(\w+)"?',
    ]
    tables: List[str] = []
    for pat in patterns:
        tables.extend(re.findall(pat, normalised, re.IGNORECASE))

    seen: set = set()
    unique: List[str] = []
    for t in tables:
        low = t.lower()
        if low not in seen:
            seen.add(low)
            unique.append(t)
    return unique


def _extract_tables_used(
    sql: Optional[str],
    db_instance: SQLDatabase,
    result_columns: Optional[List[str]] = None,
    sample_rows: int = 5,
) -> Optional[Dict[str, Any]]:
    """
    Extract metadata and sample data for tables referenced in the SQL.

    Only includes the columns that actually appear in the query output
    (intersected with each table's real columns). This keeps the response
    focused on exactly the data used to produce the final result.

    Args:
        sql: The executed SQL query.
        db_instance: Active SQLDatabase connection.
        result_columns: Column names from the query result — used to
            filter each table down to only the relevant columns.
        sample_rows: Number of sample rows per table (default 5).
    """
    if not sql or not db_instance:
        return None

    table_names = _extract_table_names_from_sql(sql)
    if not table_names:
        return None

    usable = set(db_instance.get_usable_table_names())
    engine = db_instance._engine
    dialect_name = engine.dialect.name.lower()
    insp = inspect(engine)
    result: Dict[str, Any] = {}

    result_cols_lower = {c.lower() for c in (result_columns or [])}

    for tname in table_names:
        if tname not in usable:
            matched = [u for u in usable if u.lower() == tname.lower()]
            if matched:
                tname = matched[0]
            else:
                continue

        try:
            db_columns = insp.get_columns(tname)
            all_col_names = [c["name"] for c in db_columns]

            if result_cols_lower:
                relevant_cols = [
                    c for c in all_col_names if c.lower() in result_cols_lower
                ]
            else:
                relevant_cols = all_col_names

            if not relevant_cols:
                relevant_cols = all_col_names

            quoted_cols = ", ".join(f'"{c}"' for c in relevant_cols)

            total_rows: Optional[int] = None
            sample_data: List[Dict[str, Any]] = []
            try:
                with engine.connect() as conn:
                    rc = conn.execute(
                        text(f'SELECT COUNT(*) FROM "{tname}"')
                    ).scalar()
                    total_rows = int(rc) if rc is not None else None

                    if dialect_name in ("mssql",):
                        sample_sql = f'SELECT TOP {sample_rows} {quoted_cols} FROM "{tname}"'
                    elif dialect_name in ("oracle",):
                        sample_sql = (
                            f'SELECT {quoted_cols} FROM "{tname}" '
                            f"WHERE ROWNUM <= {sample_rows}"
                        )
                    else:
                        sample_sql = f'SELECT {quoted_cols} FROM "{tname}" LIMIT {sample_rows}'

                    rows = conn.execute(text(sample_sql))
                    keys = list(rows.keys())
                    sample_data = [
                        {k: _serialise_value(v) for k, v in zip(keys, row)}
                        for row in rows.fetchall()
                    ]
            except Exception as exc:
                LOG.debug("Sample data fetch failed for %s: %s", tname, exc)

            result[tname] = {
                "name": tname,
                "row_count": total_rows,
                "sample_data": sample_data,
            }
        except Exception as e:
            LOG.debug("Could not inspect table %s: %s", tname, e)

    return result if result else None


def _serialise_value(val: Any) -> Any:
    """Make a DB cell value JSON-serialisable."""
    if val is None or isinstance(val, (str, int, float, bool)):
        return val
    if isinstance(val, datetime):
        return val.isoformat()
    return str(val)


def _parse_agent_results(
    messages: list,
    db_instance: SQLDatabase,
    question: str,
) -> Dict[str, Any]:
    """
    Walk through agent messages to extract the SQL that was executed,
    the raw result, and build structured data for the API response.

    Two-tier parsing:
      1. Try to parse the final AI message as structured JSON (sql, explanation,
         summary, confidence, warnings, optimizations).
      2. Fall back to heuristics if the LLM did not produce valid JSON.
    """
    sql_executed: Optional[str] = None
    raw_result: Optional[str] = None
    final_text: Optional[str] = None
    data: Optional[List[Dict[str, Any]]] = None
    columns: Optional[List[str]] = None
    row_count: Optional[int] = None

    response: Optional[str] = None
    explanation: Optional[str] = None
    summary: Optional[str] = None
    confidence: Optional[float] = None
    warnings: Optional[List[str]] = None
    optimizations: Optional[List[str]] = None

    error_retries = 0

    for msg in messages:
        if isinstance(msg, AIMessage):
            if getattr(msg, "tool_calls", None):
                for tc in msg.tool_calls:
                    if tc.get("name") == "sql_db_query":
                        sql_executed = tc.get("args", {}).get("query", sql_executed)
            elif msg.content:
                final_text = msg.content

        if isinstance(msg, ToolMessage) and msg.name == "sql_db_query":
            raw_result = msg.content
            if raw_result and "error" in raw_result.lower()[:100]:
                error_retries += 1

    # --- Tier 1: Structured JSON from the LLM ---
    structured = _try_parse_structured_response(final_text)
    if structured:
        response = structured.get("response")
        explanation = structured.get("explanation")
        summary = structured.get("summary")
        confidence = structured.get("confidence")
        if isinstance(confidence, (int, float)):
            confidence = max(0.0, min(1.0, float(confidence)))
        else:
            confidence = None
        warnings = structured.get("warnings")
        if not isinstance(warnings, list):
            warnings = None
        optimizations = structured.get("optimizations")
        if not isinstance(optimizations, list):
            optimizations = None
        if not sql_executed and structured.get("sql"):
            sql_executed = structured["sql"]
        LOG.info("[ConvoBI Parse] Structured JSON response parsed successfully")
    else:
        # --- Tier 2: Heuristic fallback ---
        if final_text:
            sentences = final_text.split(". ")
            response = (sentences[0].strip() + ".") if sentences else final_text[:200]
            explanation = (sentences[1].strip() + ".") if len(sentences) > 1 else response
            summary = final_text
        LOG.info("[ConvoBI Parse] Heuristic fallback — structured JSON not available")

    # Re-execute the last successful SQL to get structured data
    if sql_executed and raw_result and "Error" not in (raw_result or "")[:50]:
        try:
            engine = db_instance._engine
            with engine.connect() as conn:
                result = conn.execute(text(sql_executed))
                columns = list(result.keys())
                rows = result.fetchall()
                data = [dict(zip(columns, row)) for row in rows]
                row_count = len(data)
        except Exception as e:
            LOG.warning("Re-execution for structured data failed: %s", e)
            data = None
            columns = None

    # Override LLM response when query returned no data — prevent hallucinated/dummy data
    if sql_executed and row_count is not None and row_count == 0:
        response = "No data is available for the specified criteria."
        summary = (
            "## Key Findings\n"
            "- No data was found in the database for the specified query parameters.\n\n"
            "## Data Availability\n"
            "- The query executed successfully but returned zero rows.\n"
            "- This may indicate that no records exist for the requested time period, filters, or criteria.\n"
            "- Please verify the date range, filters, or try a different query."
        )
        confidence = 0.5

    # Heuristic confidence when LLM didn't provide one
    if confidence is None:
        if data is not None and row_count and row_count > 0:
            confidence = 0.9 if error_retries == 0 else 0.7
        elif sql_executed and raw_result:
            confidence = 0.6
        else:
            confidence = 0.3

    # Heuristic warnings from retries
    if warnings is None:
        warnings = []
    if error_retries > 0:
        warnings.append(f"Query required {error_retries} retry attempt(s) due to errors")
    if not warnings:
        warnings = None

    return {
        "sql": sql_executed,
        "raw_result": raw_result,
        "response": response,
        "explanation": explanation,
        "summary": summary,
        "data": data,
        "columns": columns,
        "row_count": row_count,
        "confidence": confidence,
        "warnings": warnings,
        "optimizations": optimizations,
    }


# ---------------------------------------------------------------------------
# Programmatic Agent Invocation (for tools, subagents, workflows)
# ---------------------------------------------------------------------------


def invoke_convobi_agent(
    question: str,
    connection_string: Optional[str] = None,
    session_id: Optional[str] = None,
    max_results: Optional[int] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Invoke the Convi BI LangGraph agent programmatically.

    This is the primary integration point for:
    - AgentTools/convobi/service.py (ConvoBIService)
    - Echo Agent subagent calls
    - Workflow nodes that need NLP-to-SQL

    Args:
        question: Natural-language question.
        connection_string: SQLAlchemy connection string. Falls back to
            the currently active connection.
        session_id: Session / thread ID for memory continuity.
        max_results: Optional row limit hint appended to the question.
        user_id: Authenticated user UUID for per-user LLM resolution.

    Returns:
        Dict with keys compatible with InvokeResponse / QueryResponse fields.
    """
    try:
        llm = _get_convobi_llm_sync(user_id)
    except Exception as exc:
        LOG.warning("LLM resolution failed for user=%s: %s", user_id, exc)
        return {"success": False, "error": "LLM not configured for Convobi agent"}

    cs = connection_string or app_state.get("active_connection_string") or ""
    if not cs:
        return {"success": False, "error": "No database connection string available"}

    dialect = _dialect_from_connection_string(cs)
    sid = session_id or str(uuid.uuid4())
    start_ms = time.time() * 1000

    LOG.info("[ConvoBI] Invoking agent: question='%s' session=%s", question[:100], sid)

    try:
        db_instance = SQLDatabase.from_uri(
            cs,
            sample_rows_in_table_info=3,
            max_string_length=100,
        )
    except Exception as e:
        return {"success": False, "error": f"Cannot connect to database: {e}"}

    try:
        tables = get_schema_info(db_instance)
        app_state["tables_cache"] = tables
        # Reset per-request SQL tracking

        app_state["invalid_sql_attempts"] = 0

        app_state["seen_sql_hashes"] = set()
        db_id = app_state.get("db_id")
        if (
            app_state.get("schema_graph") is None
            or app_state.get("schema_graph_db_id") != db_id
        ):
            schema_graph = build_schema_graph(
                tables
            )
            app_state["schema_graph"] = schema_graph
            app_state["schema_graph_db_id"] = db_id
        else:
            schema_graph = app_state["schema_graph"]
            LOG.debug(
                "[SCHEMA_GRAPH] cache_hit db_id=%s",
                db_id,
            )
        schema_hint = _format_schema_hint_for_question(tables, question)
        checkpointer = app_state.get("checkpointer") or _build_checkpointer()
        agent = build_agent(
            llm, db_instance, dialect,
            glossary_hint="",
            checkpointer=checkpointer,
        )

        limit_hint = f" (return at most {max_results} rows)" if max_results and max_results > 0 else ""
        user_msg = f"{schema_hint}\n\nQuestion: {question}{limit_hint}" if schema_hint else f"{question}{limit_hint}"

        config = {
            "configurable": {"thread_id": sid},
            "recursion_limit": 50,
        }
        
        try:
            app_state["invalid_sql_cache"] = set()
            result = agent.invoke(
                {"messages": [HumanMessage(content=user_msg)]},
                config,
            )
        except GraphRecursionError:

            LOG.error(
                "[AGENT_LOOP] recursion_limit_exceeded "
                "session=%s question=%s",
                sid,
                question[:300],
            )

            return {
                "success": False,
                "error": (
                    "I couldn't answer this question using "
                    "the available data. The required "
                    "relationships or fields were not found "
                    "in the uploaded database."
                ),
                "error_type": "unanswerable_question",
            }


        elapsed_ms = time.time() * 1000 - start_ms
        parsed = _parse_agent_results(result["messages"], db_instance, question)

        LOG.info(
            "[ConvoBI] Parsed agent results: columns=%s row_count=%s has_data=%s has_sql=%s",
            len(parsed.get("columns") or []),
            parsed.get("row_count"),
            parsed.get("data") is not None,
            bool(parsed.get("sql")),
        )

        viz_payload = None
        viz_html = None
        if parsed["columns"] and parsed["data"]:
            viz_payload = build_plotly_visualization(
                parsed["columns"], parsed["data"], question,
            )
            viz_html = build_plotly_html(
                parsed["columns"], parsed["data"], question,
                visualization=viz_payload,
            )

        LOG.info(
            "[ConvoBI] Visualization payload ready: %s",
            _summarize_visualization_html_for_log(viz_html),
        )

        # Tables used — sample data (only relevant columns) from tables in the SQL
        tables_used = _extract_tables_used(
            parsed["sql"], db_instance,
            result_columns=parsed.get("columns"),
            sample_rows=5,
        )

        # Agent steps (only when verbose)
        steps = _extract_agent_steps(result["messages"]) if CONVOBI_AGENT_VERBOSE else None

        success = parsed.get("data") is not None or parsed.get("explanation") is not None

        LOG.info(
            "[ConvoBI] Agent completed: success=%s rows=%s sql_found=%s elapsed=%.0fms",
            success,
            parsed.get("row_count"),
            bool(parsed.get("sql")),
            elapsed_ms,
        )

        return {
            "success": success,
            "response": parsed.get("response") or "",
            "sql": parsed["sql"],
            "explanation": parsed["explanation"],
            "summary": parsed["summary"],
            "data": parsed["data"],
            "columns": parsed["columns"],
            "row_count": parsed["row_count"],
            "confidence": parsed["confidence"],
            "warnings": parsed["warnings"],
            "optimizations": parsed["optimizations"],
            "execution_time_ms": elapsed_ms,
            "visualization": viz_payload,
            "visualization_html": viz_html,
            "tables_used": tables_used,
            "session_id": sid,
            "agent_steps": steps,
            "error": None if success else parsed.get("raw_result"),
        }

    except Exception as e:
        LOG.exception("invoke_convobi_agent failed")
        return {"success": False, "error": str(e)}


# ---------------------------------------------------------------------------
# Connection & Schema helpers
# ---------------------------------------------------------------------------


def _dialect_from_connection_string(cs: str) -> str:
    cs_lower = (cs or "").strip().lower()
    if cs_lower.startswith("sqlite"):
        return "sqlite"
    if "postgres" in cs_lower:
        return "postgres"
    if "mysql" in cs_lower:
        return "mysql"
    if "mssql" in cs_lower or "pyodbc" in cs_lower or "pymssql" in cs_lower:
        return "mssql"
    if "oracle" in cs_lower:
        return "oracle"
    return "sqlite"


def _normalize_connection_string(cs: str) -> str:
    cs = (cs or "").strip()

    if not cs:
        return cs

    lower = cs.lower()

    if "+asyncpg" in lower:
        cs = cs.replace("+asyncpg", "+psycopg2")

    if lower.startswith("sqlite:////"):
        return cs

    if lower.startswith("sqlite:"):
        path = cs[7:].lstrip("/")

        if path == ":memory:" or not path:
            return "sqlite://"

        if not os.path.isabs(path) and "://" not in path:
            path = os.path.abspath(path)

        return "sqlite:///" + path.replace("\\", "/")

    return cs


def compute_db_id(connection_string: str, dialect: str) -> str:
    raw = f"{dialect}:{connection_string}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _get_db_path_for_file_id(file_id: str) -> Optional[str]:
    """Get db_path from registry. Handles both legacy (str) and new (dict) formats."""
    registry = app_state.get("file_id_registry") or {}
    entry = registry.get(file_id)
    if entry is None:
        return None
    if isinstance(entry, dict):
        return entry.get("db_path")
    return str(entry)


def _load_file_id_registry_from_disk() -> None:
    """Load file_id_registry from disk so it survives server restarts."""
    
    path = Path(UPLOADS_DIR) / "file_id_registry.json"

    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            app_state["file_id_registry"] = data.get("registry", {})

            LOG.info(
                "[REGISTRY_LOAD] loaded_keys=%s",
                list(app_state["file_id_registry"].keys())
            )

        except Exception as e:
            LOG.warning("Could not load file_id_registry: %s", e)



def _save_file_id_registry_to_disk() -> None:
    """Persist file_id_registry to disk."""
    path = Path(UPLOADS_DIR) / "file_id_registry.json"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"registry": app_state.get("file_id_registry", {})}, f, indent=2)
    except Exception as e:
        LOG.warning("Could not save file_id_registry: %s", e)


def get_file_upload_info(file_id: str) -> Optional[Dict[str, Any]]:
    """Get upload info for file_id. Returns {db_path, original_path, format, sheets} or None.
    format is 'csv' or 'xlsx'. sheets is list of {sheet_name, table_name} for xlsx."""
    registry = app_state.get("file_id_registry") or {}
    entry = registry.get(file_id)
    if entry is None:
        return None
    if isinstance(entry, dict):
        return entry
    return {"db_path": str(entry), "original_path": None, "format": None, "sheets": []}


def get_connection_string_for_file_id(file_id: str) -> Optional[str]:
    
    LOG.info(
        "[FILE_LOOKUP] hostname=%s file_id=%s",
        socket.gethostname(),
        file_id,
    )

    LOG.info(
        "[FILE_LOOKUP] registry_keys=%s",
        list((app_state.get("file_id_registry") or {}).keys()),
    )

    db_path = _get_db_path_for_file_id(file_id)
    LOG.info(
    "[FILE_LOOKUP] db_path_found=%s db_path=%s",
    db_path is not None,
    db_path,
    )
    
    blob_name = None

    if not db_path:

        LOG.warning(
            "[FILE_LOOKUP] file_id missing in memory. Reloading registry."
        )

        _load_file_id_registry_from_disk()

        db_path = _get_db_path_for_file_id(file_id)

        if not db_path:

            LOG.warning(
                "[FILE_LOOKUP] not found in local registry. Trying postgres."
            )

            record = get_uploaded_file_record(file_id)

            if not record:

                LOG.error(
                    "[FILE_LOOKUP] file_id=%s not found in postgres",
                    file_id,
                )

                return None

            db_path = record["db_path"]
            blob_name = record["blob_name"]

            LOG.info(
                "[FILE_LOOKUP] recovered from postgres file_id=%s db_path=%s blob=%s",
                file_id,
                db_path,
                blob_name,
            )

    logger_convo = logging.getLogger(__name__)
    LOG.info(
    "[FILE_LOOKUP] registry_file_exists=%s path=%s",
    Path(UPLOADS_DIR, "file_id_registry.json").exists(),
    Path(UPLOADS_DIR, "file_id_registry.json")
    )
    LOG.info(
        "[FILE_LOOKUP_DEBUG] hostname=%s pid=%s registry_count=%s",
        socket.gethostname(),
        os.getpid(),
        len(app_state.get("file_id_registry", {})),
    )

    # Restore from blob if local file missing (container restart)
    if not Path(db_path).exists():
        logger_convo.warning(
            "[ConvoBI] Local DB file not found: %s. Attempting Azure Blob restore.",
            db_path,
        )

        try:
            from echolib.blob_storage import (
                download_from_blob,
                derive_blob_name_from_path,
            )

            if not blob_name:
                blob_name = derive_blob_name_from_path(db_path)

            LOG.info(
                "[FILE_RESTORE] blob_name=%s",
                blob_name,
            )

            restored = download_from_blob(blob_name, db_path)

            if restored and Path(db_path).exists():
                logger_convo.info(
                    "[ConvoBI] DB file successfully fetched from Azure Blob. "
                    "blob=%s local=%s",
                    blob_name,
                    db_path,
                )
            else:
                logger_convo.warning(
                    "[ConvoBI] Azure Blob restore failed. "
                    "blob=%s local=%s",
                    blob_name,
                    db_path,
                )
                return None

        except Exception:
            logger_convo.exception(
                "[ConvoBI] Error while restoring DB file from Azure Blob: %s",
                db_path,
            )
            return None

    return f"sqlite:///{db_path}"

def restore_db_from_blob_if_missing(db_path: str) -> bool:

    path = Path(db_path)

    LOG.info(
        "[BLOB_RESTORE] requested_db_path=%s",
        db_path,
    )

    LOG.info(
        "[BLOB_RESTORE] exists_before=%s",
        path.exists(),
    )

    if path.exists():
        LOG.info(
            "[BLOB_RESTORE] file already exists"
        )
        return True

    try:
        from echolib.blob_storage import (
            download_from_blob,
            derive_blob_name_from_path,
        )

        blob_name = derive_blob_name_from_path(
            db_path
        )

        LOG.info(
            "[BLOB_RESTORE] derived_blob_name=%s",
            blob_name,
        )

        restored = download_from_blob(
            blob_name,
            db_path,
        )

        LOG.info(
            "[BLOB_RESTORE] download_result=%s",
            restored,
        )

        LOG.info(
            "[BLOB_RESTORE] exists_after=%s",
            path.exists(),
        )

        if path.exists():
            LOG.info(
                "[BLOB_RESTORE] file_size=%s",
                path.stat().st_size,
            )

        return restored and path.exists()

    except Exception:
        LOG.exception(
            "[BLOB_RESTORE] restore failed"
        )
        return False

# Helper function to fetch details from postgres file_upload table
def get_uploaded_file_by_connection_id(
    connection_id: str,
) -> Optional[Dict[str, Any]]:

    LOG.info(
        "[FILE_REGISTRY_DB] lookup connection_id=%s",
        connection_id,
    )

    try:

        engine = _get_pg_engine()

        with engine.connect() as conn:

            row = conn.execute(
                text(
                    """
                    SELECT *
                    FROM uploaded_files
                    WHERE connection_id = :connection_id
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                ),
                {
                    "connection_id": connection_id,
                },
            ).mappings().first()

        if not row:

            LOG.warning(
                "[FILE_REGISTRY_DB] connection_id not found=%s",
                connection_id,
            )

            return None

        LOG.info(
            "[FILE_REGISTRY_DB] found connection_id=%s",
            connection_id,
        )

        return dict(row)

    except Exception:

        LOG.exception(
            "[FILE_REGISTRY_DB] lookup failed connection_id=%s",
            connection_id,
        )

        return None
# For connector_id based api calls
def get_saved_connection_string(connection_id: str) -> Optional[str]:
    
    LOG.info(
        "[CONNECTOR] requested_connection_id=%s",
        connection_id,
    )

    LOG.info(
        "[CONNECTOR] inline_connection_ids=%s",
        list((app_state.get("inline_connections") or {}).keys()),
    )

    LOG.info(
        "[CONNECTOR] Resolving connection_id=%s",
        connection_id,
    )

    inline = app_state.get("inline_connections") or {}
    if connection_id in inline:
        LOG.info(
            "[CONNECTOR] Found inline connection: %s",
            inline[connection_id],
        )
        return inline[connection_id]

    try:
        from apps.connector.db_connector import _get_pg_engine

        engine = _get_pg_engine()

        with engine.connect() as conn:
            row = conn.execute(
                text(
                    """
                    SELECT connection_string
                    FROM db_connections
                    WHERE id = :id
                    """
                ),
                {"id": connection_id},
            ).fetchone()
        
        LOG.info(
            "[CONNECTOR] postgres_row_found=%s",
            row is not None,
        )


        if not row:
            LOG.error(
                "[CONNECTOR] No row found for connection_id=%s",
                connection_id,
            )
            return None

        connection_string = row[0]

        LOG.info(
            "[CONNECTOR] connection_string=%s",
            connection_string,
        )

        if connection_string.lower().startswith("sqlite:///"):
            db_path = connection_string.replace(
                "sqlite:///",
                "",
                1,
            )

            LOG.info(
                "[CONNECTOR] db_path=%s",
                db_path,
            )

            LOG.info(
                "[CONNECTOR] file_exists_before_restore=%s",
                Path(db_path).exists(),
            )
            
            LOG.info(
                "[CONNECTOR] uploads_dir_exists=%s",
                os.path.exists("/app/apps/connector/uploads"),
            )

            if os.path.exists("/app/apps/connector/uploads"):
                LOG.info(
                    "[CONNECTOR] uploads_files=%s",
                    os.listdir("/app/apps/connector/uploads"),
                )
            record = get_uploaded_file_by_connection_id(
                connection_id,
            )

            if record:

                LOG.info(
                    "[CONNECTOR_FILE_DB] found mapping connection_id=%s blob=%s",
                    connection_id,
                    record.get("blob_name"),
                )

            else:

                LOG.warning(
                    "[CONNECTOR_FILE_DB] no mapping found for connection_id=%s",
                    connection_id,
                )
            if not Path(db_path).exists():

                if record:

                    try:

                        from echolib.blob_storage import download_from_blob

                        blob_name = record["blob_name"]

                        LOG.info(
                            "[CONNECTOR_FILE_RESTORE] connection_id=%s blob=%s db_path=%s",
                            connection_id,
                            blob_name,
                            db_path,
                        )

                        restored = download_from_blob(
                            blob_name,
                            db_path,
                        )
                        if restored:

                            LOG.info(
                                "[CONNECTOR_FILE_RESTORE] restored successfully path=%s",
                                db_path,
                            )

                        else:

                            LOG.warning(
                                "[CONNECTOR_FILE_RESTORE] restore failed path=%s",
                                db_path,
                            )

                            return None

                        if not restored:
                            return None

                    except Exception:

                        LOG.exception(
                            "[CONNECTOR_FILE_RESTORE] failed"
                        )

                        return None

                else:

                    if not restore_db_from_blob_if_missing(
                        db_path
                    ):
                        return None

        return connection_string

    except Exception:
        LOG.exception(
            "[CONNECTOR] Failed resolving connection"
        )
        return None
def _resolve_connection_string(
    connection_id: Optional[str] = None,
    file_id: Optional[str] = None,
) -> Optional[str]:
    """Resolve a connection_id or file_id to a connection string."""
    if file_id:
        return get_connection_string_for_file_id(file_id)
    if connection_id:
        return get_saved_connection_string(connection_id)
    return app_state.get("active_connection_string")


def user_has_write_access(
    connection_id: Optional[str],
    file_id: Optional[str],
    user_id: str,
    email: str,
) -> bool:
    if file_id and (user_id or email):
        return True
    if not connection_id:
        return False
    path = Path(DB_WRITE_ACCESS_FILE)
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            entry = data.get("connections", {}).get(connection_id, {})
            if user_id and user_id in entry.get("user_ids", []):
                return True
            if email and email in entry.get("emails", []):
                return True
        except Exception:
            pass
    return False


def execute_ddl(ddl: str) -> Tuple[bool, Optional[str], Optional[int]]:
    cs = app_state.get("active_connection_string")
    if not cs:
        return False, "No active database connection", None
    try:
        engine = create_engine(cs)
        with engine.connect() as conn:
            result = conn.execute(text(ddl))
            conn.commit()
            return True, None, result.rowcount
    except Exception as e:
        return False, str(e), None


def export_sqlite_to_csv_excel(
    db_path: str,
    output_path: str,
    format_type: str,
    sheets: Optional[List[Dict[str, str]]] = None,
    schema_metadata: Optional[Dict[str, Dict[str, Dict[str, Any]]]] = None,
) -> bool:
    """
    Export SQLite data back to the uploaded CSV or Excel file.
    Overwrites the file at output_path with the modified data (new column names, types, etc.).
    format_type: 'csv' or 'xlsx'
    sheets: for xlsx, list of {sheet_name, table_name}. If None, uses single table.
    schema_metadata: {table: {column: {name: "new_name", ...}}} to apply column renames during export.
    """
    try:
        abs_db = Path(db_path).resolve()
        abs_out = Path(output_path).resolve()
        abs_out.parent.mkdir(parents=True, exist_ok=True)
        # SQLite URL: use forward slashes for Windows compatibility
        sqlite_url = f"sqlite:///{str(abs_db).replace(chr(92), '/')}"
        engine = create_engine(sqlite_url)
        meta = schema_metadata or {}

        def _apply_column_renames(df: pd.DataFrame, table: str) -> pd.DataFrame:
            """Rename columns based on schema_metadata. Handles both DDL-renamed and metadata-only renames."""
            tbl_meta = meta.get(table, {})
            renames = {}
            for col in df.columns:
                output_name = None
                override = tbl_meta.get(col) or tbl_meta.get(col.upper())
                if override and override.get("name"):
                    output_name = str(override["name"]).strip()
                else:
                    for meta_col, meta_val in tbl_meta.items():
                        if meta_val.get("original_name") == col:
                            output_name = str(meta_val.get("name", meta_col)).strip()
                            break
                if output_name and output_name != col:
                    renames[col] = output_name
            return df.rename(columns=renames) if renames else df

        with engine.connect() as conn:
            if format_type == "csv":
                tables = inspect(engine).get_table_names()
                if not tables:
                    return False
                df = pd.read_sql_table(tables[0], conn)
                df = _apply_column_renames(df, tables[0])
                df.to_csv(abs_out, index=False, encoding="utf-8")
            elif format_type == "xlsx":
                with pd.ExcelWriter(abs_out, engine="openpyxl") as writer:
                    if sheets:
                        for s in sheets:
                            tbl = s.get("table_name")
                            sh = s.get("sheet_name", tbl)
                            if tbl:
                                df = pd.read_sql_table(tbl, conn)
                                df = _apply_column_renames(df, tbl)
                                df.to_excel(writer, sheet_name=sh[:31], index=False)
                    else:
                        tables = inspect(engine).get_table_names()
                        for t in tables:
                            df = pd.read_sql_table(t, conn)
                            df = _apply_column_renames(df, t)
                            df.to_excel(writer, sheet_name=t[:31], index=False)
            else:
                return False
        LOG.info("Exported to %s (%s)", abs_out, format_type)
        return True
    except Exception as e:
        LOG.warning("Export to %s failed: %s", format_type, e)
        return False


def generate_ddl_for_schema_edit(
    table: str,
    column: str,
    current_col: Dict[str, Any],
    new_name: Optional[str],
    new_type: Optional[str],
    new_nullable: Optional[bool],
    new_primary_key: Optional[bool],
    new_foreign_key: Optional[str],
    dialect: str,
) -> List[str]:
    """
    Generate DDL statements to apply schema changes to the database.
    Returns list of SQL statements (may be empty if no DB changes needed).
    """
    ddl_list: List[str] = []
    d = (dialect or "sqlite").lower()
    q = lambda x: _quote_identifier(str(x), d)
    qt = lambda x: _quote_table_for_sql(str(x), d)

    curr_name = current_col.get("name") or column
    curr_type = str(current_col.get("type", ""))
    curr_nullable = current_col.get("nullable", True)
    curr_pk = current_col.get("primary_key", False)
    curr_fk = current_col.get("foreign_key")

    # Effective new values (only apply if different)
    name_changed = new_name and str(new_name).strip() and str(new_name).strip() != curr_name
    type_changed = new_type and str(new_type).strip() and str(new_type).strip().upper() != str(curr_type).upper()
    nullable_changed = new_nullable is not None and new_nullable != curr_nullable
    pk_changed = new_primary_key is not None and new_primary_key != curr_pk
    fk_changed = (new_foreign_key is not None and str(new_foreign_key).strip() != str(curr_fk or "").strip())

    if d == "sqlite":
        # SQLite: only RENAME COLUMN is straightforward (3.25.0+)
        if name_changed:
            ddl_list.append(
                f'ALTER TABLE {qt(table)} RENAME COLUMN {q(curr_name)} TO {q(str(new_name).strip())}'
            )
        # Type, nullable, PK, FK in SQLite require table recreation - skip for now
        # (would need CREATE TABLE new AS SELECT, DROP old, RENAME)

    elif d in ("postgresql", "postgres"):
        # 1. Rename
        if name_changed:
            ddl_list.append(
                f'ALTER TABLE {qt(table)} RENAME COLUMN {q(curr_name)} TO {q(str(new_name).strip())}'
            )
            curr_name = str(new_name).strip()

        # 2. Type
        if type_changed:
            new_type_str = str(new_type).strip()
            ddl_list.append(
                f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} TYPE {new_type_str}'
            )

        # 3. Nullable
        if nullable_changed:
            if new_nullable:
                ddl_list.append(f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} DROP NOT NULL')
            else:
                ddl_list.append(f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} SET NOT NULL')

        # 4. Primary key (drop old, add new)
        if pk_changed:
            pk_name = f"{table}_pkey"
            ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT IF EXISTS {q(pk_name)}')
            if new_primary_key:
                ddl_list.append(f'ALTER TABLE {qt(table)} ADD PRIMARY KEY ({q(curr_name)})')

        # 5. Foreign key (PostgreSQL default: table_column_fkey)
        if fk_changed:
            fk_name = f"{table}_{curr_name}_fkey"
            ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT IF EXISTS {q(fk_name)}')
            if new_foreign_key and str(new_foreign_key).strip():
                ref = str(new_foreign_key).strip()
                if "." in ref:
                    ref_tbl, ref_col = ref.split(".", 1)
                    fk_constraint_name = f"fk_{table}_{curr_name}"
                    ddl_list.append(
                        f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(fk_constraint_name)} '
                        f'FOREIGN KEY ({q(curr_name)}) REFERENCES {qt(ref_tbl)} ({q(ref_col)})'
                    )

    elif d in ("mysql", "mariadb"):
        # Use CHANGE COLUMN for MySQL 5.7+ compatibility (RENAME COLUMN is 8.0.3+ only)
        if name_changed:
            new_type_str = str(new_type).strip() if new_type else curr_type
            null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
            ddl_list.append(
                f'ALTER TABLE {qt(table)} CHANGE COLUMN {q(curr_name)} {q(str(new_name).strip())} '
                f'{new_type_str} {null_part}'
            )
            curr_name = str(new_name).strip()

        if (type_changed or nullable_changed) and not name_changed:
            new_type_str = str(new_type).strip() if new_type else curr_type
            null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
            ddl_list.append(
                f'ALTER TABLE {qt(table)} MODIFY COLUMN {q(curr_name)} {new_type_str} {null_part}'
            )

        if pk_changed:
            ddl_list.append(f'ALTER TABLE {qt(table)} DROP PRIMARY KEY')
            if new_primary_key:
                ddl_list.append(f'ALTER TABLE {qt(table)} ADD PRIMARY KEY ({q(curr_name)})')

        if fk_changed and new_foreign_key and str(new_foreign_key).strip():
            fk_name = f"fk_{table}_{curr_name}"
            ref = str(new_foreign_key).strip()
            if "." in ref:
                ref_tbl, ref_col = ref.split(".", 1)
                ddl_list.append(
                    f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(fk_name)} '
                    f'FOREIGN KEY ({q(curr_name)}) REFERENCES {qt(ref_tbl)} ({q(ref_col)})'
                )

    elif d in ("mssql", "pyodbc"):
        if name_changed:
            ddl_list.append(
                f'EXEC sp_rename \'{table}.{curr_name}\', \'{str(new_name).strip()}\', \'COLUMN\''
            )
            curr_name = str(new_name).strip()

        if type_changed or nullable_changed:
            new_type_str = str(new_type).strip() if new_type else curr_type
            null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
            ddl_list.append(
                f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} {new_type_str} {null_part}'
            )

        if pk_changed:
            pk_name = f"PK_{table}"
            ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT {q(pk_name)}')
            if new_primary_key:
                ddl_list.append(f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(pk_name)} PRIMARY KEY ({q(curr_name)})')

    return ddl_list


def _perform_mssql_diagnostics(connection_string: str) -> None:
    """
    Perform pre-connection diagnostics for MSSQL connections.
    Tests DNS resolution and TCP connectivity before SQLAlchemy attempts connection.
    All diagnostics are non-fatal and logged with [MSSQL_DEBUG] prefix.
    
    Args:
        connection_string: SQLAlchemy connection string (e.g., mssql+pyodbc://...)
    """
    LOG = logging.getLogger(__name__)
    
    # Only diagnose MSSQL connections
    cs_lower = (connection_string or "").lower()
    if not any(x in cs_lower for x in ("mssql", "pyodbc")):
        return
    
    try:
        # Parse connection string safely
        url = make_url(connection_string)
        server = url.host
        port = url.port or 1433  # Default MSSQL port
        
        if not server:
            LOG.warning("[MSSQL_DEBUG] server=None (could not parse host from connection string)")
            return
        
        LOG.info(f"[MSSQL_DEBUG] server={server}")
        LOG.info(f"[MSSQL_DEBUG] port={port}")
        
        # Test DNS resolution
        dns_success = False
        resolved_ip = None
        dns_error = None
        try:
            resolved_ip = socket.gethostbyname(server)
            dns_success = True
            LOG.info(f"[MSSQL_DEBUG] resolved_ip={resolved_ip}")
            LOG.info("[MSSQL_DEBUG] dns_success=True")
        except socket.gaierror as e:
            dns_error = str(e)
            LOG.warning(f"[MSSQL_DEBUG] resolved_ip=None")
            LOG.warning("[MSSQL_DEBUG] dns_success=False")
            LOG.warning(f"[MSSQL_DEBUG] dns_error={dns_error}")
        except Exception as e:
            dns_error = str(e)
            LOG.warning(f"[MSSQL_DEBUG] resolved_ip=None")
            LOG.warning("[MSSQL_DEBUG] dns_success=False")
            LOG.warning(f"[MSSQL_DEBUG] dns_error={dns_error}")
        
        # Test TCP connectivity (only if DNS succeeded)
        tcp_success = False
        tcp_error = None
        if dns_success and resolved_ip:
            try:
                sock = socket.create_connection((server, port), timeout=5)
                sock.close()
                tcp_success = True
                LOG.info("[MSSQL_DEBUG] tcp_success=True")
                LOG.info("[MSSQL_DEBUG] tcp_error=None")
            except socket.timeout as e:
                tcp_error = "Connection timeout"
                LOG.warning("[MSSQL_DEBUG] tcp_success=False")
                LOG.warning(f"[MSSQL_DEBUG] tcp_error={tcp_error}")
            except ConnectionRefusedError as e:
                tcp_error = "Connection refused"
                LOG.warning("[MSSQL_DEBUG] tcp_success=False")
                LOG.warning(f"[MSSQL_DEBUG] tcp_error={tcp_error}")
            except Exception as e:
                tcp_error = str(e)
                LOG.warning("[MSSQL_DEBUG] tcp_success=False")
                LOG.warning(f"[MSSQL_DEBUG] tcp_error={tcp_error}")
        else:
            LOG.warning("[MSSQL_DEBUG] tcp_success=False")
            LOG.warning("[MSSQL_DEBUG] tcp_error=DNS resolution failed, skipping TCP test")
    
    except Exception as e:
        # Catch-all: diagnostic itself failed, but don't block connection attempt
        LOG.warning(f"[MSSQL_DEBUG] Diagnostics failed: {e}")


def activate_connection(
    connection_string: str,
    connection_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Activate a database connection - create SQLDatabase + rebuild agent."""
    global CURRENT_DIALECT, CURRENT_CONNECTOR
    LOG = logging.getLogger(__name__)
    LOG.info(
        "[NORMALIZE] incoming=%s",
        connection_string,
    )

    cs = _normalize_connection_string(connection_string)
    
    LOG.info(
        "[NORMALIZE] outgoing=%s",
        cs,
    )

    dialect = _dialect_from_connection_string(cs)
    CURRENT_DIALECT = dialect
    CURRENT_CONNECTOR = "sql"
    
    
    db_path = None

    if cs.startswith("sqlite:///"):
        db_path = cs.replace("sqlite:///", "", 1)

    LOG = logging.getLogger(__name__)

    LOG.info(
        "[DEBUG_SQLITE_OPEN] connection_string=%s",
        cs,
    )

    LOG.info(
        "[DEBUG_SQLITE_OPEN] cwd=%s",
        os.getcwd(),
    )

    LOG.info(
        "[DEBUG_SQLITE_OPEN] app_exists=%s",
        os.path.exists("/app"),
    )

    LOG.info(
        "[DEBUG_SQLITE_OPEN] uploads_exists=%s",
        os.path.exists("/app/apps/connector/uploads"),
    )

    if db_path:
        LOG.info(
            "[DEBUG_SQLITE_OPEN] path=%s exists=%s",
            db_path,
            os.path.exists(db_path),
        )

        if os.path.exists(db_path):
            LOG.info(
                "[DEBUG_SQLITE_OPEN] size=%s",
                os.path.getsize(db_path),
            )


    try:
        # Run MSSQL connectivity diagnostics before attempting connection
        _perform_mssql_diagnostics(cs)
        
        db_instance = SQLDatabase.from_uri(
            cs,
            sample_rows_in_table_info=3,
            max_string_length=100,
        )
    except Exception as e:
        raise RuntimeError(f"Cannot connect to database: {e}")

    app_state["db"] = db_instance
    app_state["active_connection_string"] = cs
    app_state["active_connection_id"] = connection_id
    app_state["db_id"] = compute_db_id(cs, dialect)

    # Agent is no longer pre-built here. It is built per-request in
    # execute_query / invoke_agent with the authenticated user's LLM
    # (resolved via the tiered credential system: user -> platform fallback).
    app_state.pop("agent", None)

    table_names = db_instance.get_usable_table_names()
    app_state["conversation_history"] = []

    return {
        "ok": True,
        "dialect": dialect,
        "connector": "sql",
        "tables_loaded": len(table_names),
        "tables": list(table_names),
    }


def ensure_connection_active() -> None:
    """Make sure we have an active SQLDatabase; try DEFAULT_DB_URL if needed."""
    if app_state.get("db") is not None:
        return
    cs = DEFAULT_DB_URL
    if cs:
        activate_connection(cs)


# ---------------------------------------------------------------------------
# Schema helpers (using SQLDatabase metadata)
# ---------------------------------------------------------------------------


def _quote_identifier(name: str, dialect: str) -> str:
    """Quote identifier for raw SQL. MSSQL uses [name], others use "name"."""
    if (dialect or "").lower() in ("mssql", "pyodbc"):
        # MSSQL: square brackets; escape ] as ]]
        escaped = str(name).replace("]", "]]")
        return f"[{escaped}]"
    return f'"{name}"'


def _quote_table_for_sql(tname: str, dialect: str) -> str:
    """Quote table name for raw SQL. Handles schema.table for MSSQL."""
    if (dialect or "").lower() in ("mssql", "pyodbc"):
        # MSSQL: [schema].[table] if dot present, else [table]
        parts = str(tname).split(".", 1)
        return ".".join(_quote_identifier(p, dialect) for p in parts)
    return f'"{tname}"'


def _get_dialect_for_schema(engine: Any) -> str:
    """Detect dialect for schema queries. MSSQL needs TOP/brackets; fallback to URL if needed."""
    dialect = (getattr(engine.dialect, "name", None) or "").lower()
    if dialect in ("mssql", "pyodbc"):
        return dialect
    # Fallback: check connection URL (e.g. mssql+pyodbc)
    try:
        url_str = str(getattr(engine, "url", ""))
        if "mssql" in url_str.lower() or "pyodbc" in url_str.lower():
            return "mssql"
    except Exception:
        pass
    return dialect or "sqlite"


def get_schema_info(db_instance: SQLDatabase) -> Dict[str, Any]:
    """Build schema info dict from SQLDatabase for API responses."""
    tables: Dict[str, Any] = {}
    table_names = db_instance.get_usable_table_names()
    engine = db_instance._engine
    dialect_name = _get_dialect_for_schema(engine)

    insp = inspect(engine)
    for tname in sorted(table_names):
        cols_info: List[Dict[str, Any]] = []
        try:
            # MSSQL: split schema.table for inspector calls
            schema_name, table_name = None, tname
            if dialect_name in ("mssql", "pyodbc") and "." in str(tname):
                parts = str(tname).split(".", 1)
                schema_name, table_name = parts[0], parts[1]
            db_columns = insp.get_columns(table_name, schema=schema_name)
            pk_constraint = insp.get_pk_constraint(table_name, schema=schema_name) or {}
            pk_cols = pk_constraint.get("constrained_columns", [])
            fks = insp.get_foreign_keys(table_name, schema=schema_name)
            fk_map: Dict[str, str] = {}
            for fk in fks:
                for col in fk.get("constrained_columns", []):
                    ref = (
                        f"{fk.get('referred_table', '')}."
                        f"{','.join(fk.get('referred_columns', []))}"
                    )
                    fk_map[col] = ref

            quoted_table = _quote_table_for_sql(tname, dialect_name)
            row_count: Optional[int] = None
            try:
                with engine.connect() as conn:
                    rc = conn.execute(text(f"SELECT COUNT(*) FROM {quoted_table}")).scalar()
                    row_count = int(rc) if rc is not None else None
            except Exception:
                pass

            col_examples: Dict[str, List[str]] = {}
            try:
                with engine.connect() as conn:
                    for c in db_columns:
                        cname = c["name"]
                        try:
                            quoted_col = _quote_identifier(cname, dialect_name)
                            # MSSQL uses TOP N, not LIMIT; Oracle uses ROWNUM
                            if dialect_name in ("mssql", "pyodbc"):
                                # MSSQL: DISTINCT must come before TOP
                                distinct_sql = (
                                    f"SELECT DISTINCT TOP 50 {quoted_col} FROM {quoted_table} "
                                    f"WHERE {quoted_col} IS NOT NULL"
                                )
                            elif dialect_name == "oracle":
                                distinct_sql = (
                                    f"SELECT DISTINCT {quoted_col} FROM {quoted_table} "
                                    f"WHERE {quoted_col} IS NOT NULL AND ROWNUM <= 50"
                                )
                            else:
                                distinct_sql = (
                                    f'SELECT DISTINCT "{cname}" FROM "{tname}" '
                                    f'WHERE "{cname}" IS NOT NULL LIMIT 50'
                                )
                            rows = conn.execute(text(distinct_sql)).fetchall()
                            col_examples[cname] = [str(r[0]) for r in rows]
                        except Exception as e:
                            LOG.warning(
                                "Distinct values failed for %s.%s (dialect=%s): %s",
                                tname, cname, dialect_name, e,
                            )
                            col_examples[cname] = []
            except Exception as e:
                LOG.warning("Column examples fetch failed for %s (dialect=%s): %s", tname, dialect_name, e)

            for c in db_columns:
                cname = c["name"]
                gloss = get_column_glossary_description(cname)
                examples = col_examples.get(cname, [])
                cols_info.append({
                    "name": cname,
                    "type": str(c.get("type", "unknown")),
                    "nullable": c.get("nullable", True),
                    "primary_key": cname in pk_cols,
                    "foreign_key": fk_map.get(cname),
                    "meaning": gloss or None,
                    "description": gloss or None,
                    "confidence": 0.8 if gloss else None,
                    "source": "glossary" if gloss else None,
                    "examples": examples,
                    "example_values": ", ".join(examples[:10]) if examples else None,
                })

            relationships: List[str] = []
            for fk in fks:
                ref_table = fk.get("referred_table", "")
                ref_cols = fk.get("referred_columns", [])
                src_cols = fk.get("constrained_columns", [])
                if ref_table and src_cols:
                    relationships.append(
                        f"{','.join(src_cols)} -> "
                        f"{ref_table}.{','.join(ref_cols)}"
                    )
            tables[tname] = {
                "name": tname,
                "row_count": row_count,
                "columns": cols_info,
                "relationships": relationships,
            }
        except Exception as e:
            LOG.warning("Error inspecting table %s: %s", tname, e)
            tables[tname] = {
                "name": tname,
                "row_count": None,
                "columns": [],
                "relationships": [],
            }
    return tables

def build_schema_graph(
    tables: Dict[str, Any],
) -> Dict[str, set]:
    """
    Build adjacency graph from FK relationships.
    Example:
    orders -> customers
    customers -> orders
    Stored as bidirectional graph so path finding is easy.
    """
    graph: Dict[str, set] = defaultdict(set)
    edge_count = 0
    for table_name, table_info in tables.items():
        graph.setdefault(table_name, set())
        relationships = table_info.get(
            "relationships",
            [],
        )
        for rel in relationships:
            try:
                _, rhs = rel.split("->", 1)
                target_table = (
                    rhs.strip()
                    .split(".", 1)[0]
                    .strip()
                )
                graph[table_name].add(
                    target_table
                )
                graph[target_table].add(
                    table_name
                )
                edge_count += 1
            except Exception:
                LOG.warning(
                    "[SCHEMA_GRAPH] could_not_parse relation=%s table=%s",
                    rel,
                    table_name,
                )
    LOG.info(
        "[SCHEMA_GRAPH] graph_created tables=%s edges=%s",
        len(graph),
        edge_count,
    )
    return graph
def schema_path_exists(
    graph: Dict[str, set],
    source: str,
    target: str,
) -> bool:
    if source == target:
        return True
    visited = set()
    queue = deque([source])
    while queue:
        node = queue.popleft()
        if node == target:
            return True
        if node in visited:
            continue
        visited.add(node)
        for nxt in graph.get(node, set()):
            if nxt not in visited:
                queue.append(nxt)
    return False

def validate_sql_against_schema(
    sql: str,
    tables: Dict[str, Any],
) -> Tuple[bool, str]:
    """
    Validate generated SQL against discovered schema.
    Checks:
    - table existence
    - alias resolution
    - column existence
    """
    if not sql:
        return True, ""
    try:
        table_columns = {
            table_name.lower(): {
                c["name"].lower()
                for c in table_info.get("columns", [])
            }
            for table_name, table_info in tables.items()
        }
        # ------------------------
        # Extract tables + aliases
        # -------------------------
        alias_map = {}
        pattern = re.compile(
            r"\b(?:FROM|JOIN)\s+([a-zA-Z_][a-zA-Z0-9_]*)"
            r"(?:\s+([a-zA-Z_][a-zA-Z0-9_]*))?",
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql):
            table_name = match.group(1)
            alias = match.group(2)
            if table_name.lower() not in table_columns:
                return (
                    False,
                    f"Table '{table_name}' does not exist",
                )
            if alias:
                alias_map[alias.lower()] = table_name.lower()
        # -------------------------
        # Validate alias.column
        # ------------------------
        column_pattern = re.compile(
            r"([a-zA-Z_][a-zA-Z0-9_]*)"
            r"\."
            r"([a-zA-Z_][a-zA-Z0-9_]*)"
        )
        for match in column_pattern.finditer(sql):
            alias = match.group(1).lower()
            column = match.group(2).lower()

            if alias not in alias_map:
                continue
            table_name = alias_map[alias]

            if column not in table_columns.get(table_name, set()):
                return (
                    False,
                    f"Column '{column}' does not exist in table '{table_name}'"
                )
        return True, ""
    except Exception as exc:
        LOG.exception(
            "[SQL_VALIDATOR] failed"
        )
        return (
            True,
            f"Validator error: {exc}",
        )

def _sql_fingerprint(
    sql: str,
) -> str:
    """
    Create a normalized hash for SQL repeat detection.
    """

    normalized = (
        sql.strip()
        .lower()
        .replace("\n", " ")
    )

    normalized = re.sub(
        r"\s+",
        " ",
        normalized,
    )

    return hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()
    
# Paths for glossary JSON (enriched with DB examples)
_GLOSSARY_JSON_PATH = Path(__file__).parent / "column_glossary.json"
_ITSM_GLOSSARY_JSON_PATH = Path(__file__).parent / "itsm_column_glossary.json"

# Max examples per column in glossary description; each value truncated to this many chars
_GLOSSARY_MAX_EXAMPLES = 30
_GLOSSARY_MAX_VALUE_LEN = 60


def _get_glossary_json_path() -> Path:
    """Return the JSON path for the active connection's glossary."""
    return _ITSM_GLOSSARY_JSON_PATH if _is_itsm_connection() else _GLOSSARY_JSON_PATH


def get_glossary_path_for_file_id(file_id: str) -> Optional[Path]:
    """Return the glossary JSON path for an uploaded file. Creates dir if needed."""
    db_path = _get_db_path_for_file_id(file_id)
    if not db_path:
        return None
    glossary_path = Path(db_path).with_suffix(".glossary.json")
    glossary_path.parent.mkdir(parents=True, exist_ok=True)
    return glossary_path


def get_schema_metadata_path_for_file_id(file_id: str) -> Optional[Path]:
    """Return the schema metadata JSON path for an uploaded file (nullable, PK, FK, type, name overrides)."""
    db_path = _get_db_path_for_file_id(file_id)
    if not db_path:
        return None
    meta_path = Path(db_path).with_suffix(".schema_metadata.json")
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    return meta_path


def get_glossary_path_for_connection_id(connection_id: str) -> Path:
    """Return the glossary JSON path for a DB connection (small SQLite/other DBs)."""
    safe_id = re.sub(r"[^a-zA-Z0-9_-]", "_", connection_id or "")[:64] or "default"
    base = CONVOBI_SCHEMA_CACHE_DIR / safe_id
    base.mkdir(parents=True, exist_ok=True)
    return base / "glossary.json"


def get_schema_metadata_path_for_connection_id(connection_id: str) -> Path:
    """Return the schema metadata JSON path for a DB connection (small SQLite/other DBs)."""
    safe_id = re.sub(r"[^a-zA-Z0-9_-]", "_", connection_id or "")[:64] or "default"
    base = CONVOBI_SCHEMA_CACHE_DIR / safe_id
    base.mkdir(parents=True, exist_ok=True)
    return base / "schema_metadata.json"


def load_schema_metadata_for_file(file_id: str) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Load schema metadata overrides for an uploaded file. Returns {table: {column: {nullable, primary_key, ...}}}."""
    path = get_schema_metadata_path_for_file_id(file_id)
    if not path or not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("tables", {})
    except Exception:
        return {}


def load_schema_metadata_for_connection(connection_id: str) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Load schema metadata overrides for a DB connection. Returns {table: {column: {nullable, primary_key, ...}}}."""
    path = get_schema_metadata_path_for_connection_id(connection_id)
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("tables", {})
    except Exception:
        return {}


def update_schema_column_metadata(
    file_id: Optional[str] = None,
    connection_id: Optional[str] = None,
    table: str = "",
    column: str = "",
    nullable: Optional[bool] = None,
    primary_key: Optional[bool] = None,
    foreign_key: Optional[str] = None,
    type_: Optional[str] = None,
    name: Optional[str] = None,
    meaning: Optional[str] = None,
    description: Optional[str] = None,
    remove_old_column: Optional[str] = None,
    original_name: Optional[str] = None,
) -> None:
    """Update schema metadata for a column. Provide file_id OR connection_id. Only provided fields are updated.
    If remove_old_column is set (e.g. when renaming), remove that key before updating."""
    if file_id:
        path = get_schema_metadata_path_for_file_id(file_id)
    elif connection_id:
        path = get_schema_metadata_path_for_connection_id(connection_id)
    else:
        return
    if not path:
        return
    data: Dict[str, Any] = {"tables": {}}
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if "tables" not in data:
                data["tables"] = {}
        except Exception:
            data["tables"] = {}
    if table not in data["tables"]:
        data["tables"][table] = {}
    if remove_old_column and remove_old_column in data["tables"][table]:
        del data["tables"][table][remove_old_column]
    if column not in data["tables"][table]:
        data["tables"][table][column] = {}
    entry = data["tables"][table][column]
    if nullable is not None:
        entry["nullable"] = nullable
    if primary_key is not None:
        entry["primary_key"] = primary_key
    if foreign_key is not None:
        entry["foreign_key"] = foreign_key if str(foreign_key).strip() else None
    if type_ is not None:
        entry["type"] = str(type_).strip() or entry.get("type")
    if name is not None:
        entry["name"] = str(name).strip() or column
    if meaning is not None:
        entry["meaning"] = str(meaning).strip() or None
    if description is not None:
        entry["description"] = str(description).strip() or None
    if original_name is not None:
        entry["original_name"] = str(original_name).strip() or None
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())


def apply_schema_metadata_overrides(
    tables: Dict[str, Any],
    file_id: Optional[str] = None,
    connection_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Apply schema metadata overrides to tables when file_id or connection_id is set. Returns merged tables."""
    if file_id:
        meta = load_schema_metadata_for_file(file_id)
    elif connection_id:
        meta = load_schema_metadata_for_connection(connection_id)
    else:
        return tables
    if not meta:
        return tables
    result = dict(tables)
    for tname, cols in result.items():
        if tname not in meta:
            continue
        table_meta = meta[tname]
        new_cols = []
        for c in cols.get("columns", []):
            cname = c.get("name", "")
            override = table_meta.get(cname) or table_meta.get(cname.upper())
            if not override:
                new_cols.append(c)
                continue
            merged = dict(c)
            if "nullable" in override:
                merged["nullable"] = override["nullable"]
            if "primary_key" in override:
                merged["primary_key"] = override["primary_key"]
            if "foreign_key" in override:
                merged["foreign_key"] = override["foreign_key"]
            if "type" in override:
                merged["type"] = str(override["type"])
            if "name" in override:
                merged["name"] = override["name"]
            if "meaning" in override:
                merged["meaning"] = override["meaning"]
            if "description" in override:
                merged["description"] = override["description"]
            new_cols.append(merged)
        result[tname] = {**cols, "columns": new_cols}
    return result


def _parse_glossary_value(val: str) -> Tuple[str, str]:
    """Split glossary text into (semantic_part, examples_part). Examples part includes 'Examples: '."""
    if not val or not isinstance(val, str):
        return "", ""
    s = val.strip()
    # Look for " Examples: " (case-insensitive) to split
    idx = s.upper().rfind(" EXAMPLES:")
    if idx >= 0:
        return s[:idx].strip(), s[idx:].strip()
    return s, ""


def update_glossary_column_description(
    glossary_path: Path,
    column_key: str,
    new_meaning: Optional[str],
    new_description: Optional[str],
    remove_old_key: Optional[str] = None,
) -> None:
    """
    Update meaning/description in glossary JSON, preserving Examples part.
    column_key: uppercase column name (e.g. SALESSTAGECODE).
    If remove_old_key is set (e.g. when renaming), remove that key and use its value for the new key if new_description is empty.
    """
    data: Dict[str, str] = {}
    if glossary_path.exists():
        try:
            with open(glossary_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            pass
    key = (column_key or "").strip().upper()
    if not key:
        return
    existing = data.get(key, "")
    if remove_old_key:
        old_key = (remove_old_key or "").strip().upper()
        if old_key and old_key in data:
            if not existing:
                existing = data[old_key]
            del data[old_key]
    semantic, examples_part = _parse_glossary_value(existing)
    meaning = (new_meaning or semantic).strip() or semantic
    description = (new_description or meaning).strip() or meaning
    combined = f"{description} {examples_part}".strip() if examples_part else description
    data[key] = combined
    glossary_path.parent.mkdir(parents=True, exist_ok=True)
    with open(glossary_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())


def build_glossary_from_schema(tables: Dict[str, Any]) -> Dict[str, str]:
    """
    Build column glossary enriched with unique examples from the database.
    Merges with existing COLUMN_GLOSSARY: keeps existing descriptions and appends
    or updates the examples section with actual unique values from the DB.
    Uses ITSM glossary when ITSM DB is active.
    """
    # Merge examples from all tables (column name -> set of unique values)
    col_examples: Dict[str, set] = {}
    for tname, tbl in tables.items():
        for col in tbl.get("columns", []):
            cname = col.get("name", "")
            if not cname:
                continue
            key = cname.strip().upper()
            examples = col.get("examples", [])
            if key not in col_examples:
                col_examples[key] = set()
            for v in examples:
                if v is not None and str(v).strip():
                    col_examples[key].add(str(v).strip())

    result: Dict[str, str] = {}
    existing = _get_column_glossary_dict()
    # Prefer built-in descriptions for CRM Win/Loss columns
    if not _is_itsm_connection() and column_glossary:
        try:
            existing = dict(existing)
            for k in ("KPMG_STATUSREASON", "SALESSTAGECODE"):
                if hasattr(column_glossary, "_BUILTIN_GLOSSARY") and k in column_glossary._BUILTIN_GLOSSARY:
                    existing[k] = column_glossary._BUILTIN_GLOSSARY[k]
        except (ImportError, AttributeError):
            pass

    for key, values in col_examples.items():
        sorted_vals = sorted(values, key=str)[:_GLOSSARY_MAX_EXAMPLES]
        examples_str = ", ".join(str(v)[:_GLOSSARY_MAX_VALUE_LEN] for v in sorted_vals)

        if key in existing:
            desc = existing[key]
            # If description already has examples (contains ": val1, val2"), replace that part
            if ", " in desc and len(desc) > 80:
                # Keep the semantic part (before last ":" with comma-sep values)
                parts = desc.rsplit(":", 1)
                if len(parts) == 2 and ", " in parts[1] and len(parts[1]) > 20:
                    desc = parts[0].strip()
            if examples_str:
                result[key] = f"{desc} Examples: {examples_str}"
            else:
                result[key] = desc
            # Emphasize SALESSTAGECODE for Win/Loss when examples contain Win
            if key == "SALESSTAGECODE" and any("win" in str(v).lower() for v in values):
                if "prefer over KPMG_STATUSREASON" not in result[key]:
                    result[key] += " Use for win/loss filtering. Prefer over KPMG_STATUSREASON."
        else:
            # New column: humanize name and add examples
            human = key.replace("_", " ").replace("  ", " ").strip()
            if examples_str:
                result[key] = f"{human}. Examples: {examples_str}"
            else:
                result[key] = human

    # Preserve existing entries not in schema (e.g. ticket columns when only opportunities connected)
    for key, desc in existing.items():
        if key not in result:
            result[key] = desc

    return dict(sorted(result.items()))


def refresh_glossary_from_db(db_instance: SQLDatabase) -> Dict[str, Any]:
    """
    Refresh column glossary from database schema and examples.
    Writes to column_glossary.json (or itsm_column_glossary.json when ITSM DB) and updates the in-memory glossary.
    Returns updated glossary and stats.
    """
    tables = get_schema_info(db_instance)
    updated = build_glossary_from_schema(tables)
    json_path = _get_glossary_json_path()
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(updated, f, indent=2, ensure_ascii=False)
        LOG.info("Glossary refreshed: %d columns written to %s", len(updated), json_path)
    except Exception as e:
        LOG.warning("Could not write glossary JSON: %s", e)
        raise

    # Update in-memory glossary so subsequent requests use new descriptions
    mod = itsm_column_glossary if _is_itsm_connection() and itsm_column_glossary else column_glossary
    if mod:
        mod.COLUMN_GLOSSARY.clear()
        mod.COLUMN_GLOSSARY.update(updated)

    return {
        "columns_updated": len(updated),
        "path": str(json_path),
    }


def build_schema_summary(tables: Dict[str, Any]) -> str:
    total = len(tables)
    lines = [
        "# Schema Summary",
        "",
        f"**Total Tables:** {total}",
        "",
        "## Tables",
        "",
    ]
    if tables:
        lines.append("| ID | Table | Rows | Columns |")
        lines.append("|----|-------|------|---------|")
        for idx, tn in enumerate(sorted(tables.keys())):
            t = tables[tn]
            rows = t.get("row_count") if t.get("row_count") is not None else "\u2014"
            cols = len(t.get("columns") or [])
            lines.append(f"| {idx} | {tn} | {rows} | {cols} |")
    else:
        lines.append("No tables loaded.")
    return "\n".join(lines)

RECOMMENDATION_CACHE_DIR = Path(
    os.getenv(
        "CONVOBI_RECOMMENDATION_CACHE_DIR",
        "convobi_recommendation_cache",
    )
)

RECOMMENDATION_CACHE_DIR.mkdir(
    parents=True,
    exist_ok=True,
)
# ---------------------------------------------------------------------------
# Agent SQL Safety Controls
# ---------------------------------------------------------------------------

MAX_INVALID_SQL_ATTEMPTS = 2

MAX_REPEAT_SQL_ATTEMPTS = 1

MAX_RECOMMEND_CONTEXT_CHARS = 25000


def build_recommendation_context(
    tables: Dict[str, Any],
) -> str:
    """
    Lightweight schema context for recommendation generation.

    Only sends:
    - table names
    - row counts
    - column names

    Examples, glossary data, sample values and relationships
    are intentionally excluded.
    """

    lines: List[str] = []

    current_chars = 0
    tables_sent = 0

    sorted_tables = sorted(
        tables.items(),
        key=lambda x: x[1].get("row_count") or 0,
        reverse=True,
    )

    for table_name, table_info in sorted_tables:

        row_count = table_info.get(
            "row_count",
            0,
        )

        column_names = [
            c.get("name", "")
            for c in table_info.get(
                "columns",
                []
            )
            if c.get("name")
        ]

        block = (
            f"TABLE: {table_name}\n"
            f"ROWS: {row_count}\n"
            f"COLUMNS: {', '.join(column_names)}\n\n"
        )

        if (
            current_chars + len(block)
            > MAX_RECOMMEND_CONTEXT_CHARS
        ):
            break

        lines.append(block)

        current_chars += len(block)
        tables_sent += 1

    LOG.info(
        "[RECOMMEND_CONTEXT] "
        "tables_total=%s "
        "tables_sent=%s "
        "chars=%s",
        len(tables),
        tables_sent,
        current_chars,
    )

    return "".join(lines)

def build_recommendation_cache_key(
    tables: Dict[str, Any],
) -> str:
    """
    Create cache key from schema.
    """
    fingerprint: List[str] = []
    for table_name in sorted(
        tables.keys()
    ):
        table = tables[table_name]
        fingerprint.append(
            table_name
        )
        for column in table.get(
            "columns",
            [],
        ):
            fingerprint.append(
                column.get(
                    "name",
                    "",
                )
            )
    return hashlib.sha256(
        "|".join(
            fingerprint
        ).encode()
    ).hexdigest()

async def generate_recommended_questions(
    *,
    user_id: str,
    db: SQLDatabase,
    force_refresh: bool = False,
) -> Dict[str, Any]:
    """
    Generate starter questions for a database schema.
    """
    LOG.info(
    "[RECOMMEND_ENGINE] started force_refresh=%s user_id=%s",
    force_refresh,
    user_id,
    )
    tables = get_schema_info(db)
    LOG.info(
    "[RECOMMEND_ENGINE] tables_loaded=%s",
    len(tables),
    )
    schema_hash = (
        build_recommendation_cache_key(
            tables,
        )
    )
    LOG.info(
    "[RECOMMEND_ENGINE] schema_hash=%s",
    schema_hash,
    )
    cache_file = (
        RECOMMENDATION_CACHE_DIR
        / f"{schema_hash}.json"
    )
    if (
        not force_refresh
        and cache_file.exists()
    ):
        try:
            with open(
                cache_file,
                "r",
                encoding="utf-8",
            ) as f:
                cached = json.load(f)
            LOG.info(
                "[RECOMMEND_CACHE] HIT hash=%s questions=%s",
                schema_hash,
                len(cached.get("questions", [])),
            )
            return {
                "success": True,
                "questions": cached[
                    "questions"
                ],
                "source": "cache",
                "generated_at": cached[
                    "generated_at"
                ],
            }
        except Exception:
            LOG.exception(
                "[RECOMMEND_CACHE] read failed hash=%s",
                schema_hash,
            )
    
    schema_context = (
        build_recommendation_context(
            tables
        )
    )
    LOG.info(
    "[RECOMMEND_ENGINE] context_length=%s",
    len(schema_context),
    )
    LOG.info(
    "[RECOMMEND_LLM] resolving user_id=%s",
    user_id,
    )
    llm = await _get_convobi_llm_async(
        user_id
    )
    LOG.info(
    "[RECOMMEND_LLM] resolved llm_type=%s",
    type(llm).__name__,
    )
    prompt = f"""
You are an expert Business Intelligence Analyst.
Generate exactly 8 high-quality business questions.
Rules:
- Use only tables and columns from the schema.
- Questions must be answerable using SQL.
- Prefer tables containing data.
- Avoid duplicates.
- Mix operational, trend, aggregate and analytical questions.
- Questions should look like dashboard starter questions.
Return ONLY valid JSON.
{{
  "questions": [
    "question1",
    "question2",
    "question3",
    "question4",
    "question5",
    "question6",
    "question7",
    "question8"
  ]
}}
SCHEMA:
{schema_context}
"""
    start_ms = time.time() * 1000

    LOG.info(
    "[RECOMMEND_PROMPT] schema_chars=%s prompt_chars=%s",
    len(schema_context),
    len(prompt),
    )
    response = llm.invoke(
        [
            HumanMessage(
                content=prompt,
            )
        ]
    )
    elapsed_ms = time.time() * 1000 - start_ms

    LOG.info(
        "[RECOMMEND_LLM] completed elapsed_ms=%.0f",
        elapsed_ms,
    )
    content = getattr(
        response,
        "content",
        "",
    )
    LOG.info(
    "[RECOMMEND_LLM] raw_response=%s",
    str(content)[:2000],
    )
    questions: List[str] = []
    try:
        response_text = (response.content or "").strip()
        response_text = re.sub(
            r"^```(?:json)?\s*",
            "",
            response_text,
            flags=re.IGNORECASE,
        )
        response_text = re.sub(
            r"\s*```$",
            "",
            response_text,
        )
        response_text = response_text.strip()
        try:
            parsed = json.loads(response_text)
        except json.JSONDecodeError:
            match = re.search(
                r"\{.*\}",
                response_text,
                re.DOTALL,
            )
            if not match:
                raise
            parsed = json.loads(
                match.group(0)
            )
        questions = parsed.get(
            "questions",
            []
        )
        LOG.info(
            "[RECOMMEND_PARSE] parsed questions=%s",
            len(questions),
        )
    except Exception:
        LOG.exception(
            "[QUESTIONS] json parse failed"
        )
    questions = [
        str(q).strip()
        for q in questions
        if str(q).strip()
    ]
    questions = questions[:8]
    if not questions:
        populated_tables = [
            t
            for t, v in tables.items()
            if (
                v.get(
                    "row_count"
                )
                or 0
            )
            > 0
        ]
        LOG.info(
            "[RECOMMEND_SCHEMA] total_tables=%s populated_tables=%s",
            len(tables),
            len(populated_tables),
        )
        fallback = []
        for table in populated_tables[:8]:

            fallback.append(
                f"What insights are available from {table}?"
            )
        questions = fallback
    generated_at = (
        datetime.utcnow()
        .isoformat()
    )
    try:
        with open(
            cache_file,
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                {
                    "generated_at": generated_at,
                    "questions": questions,
                },
                f,
                indent=2,
            )
    except Exception:
        LOG.exception(
            "[QUESTIONS] cache write failed"
        )
    LOG.info(
    "[RECOMMEND_ENGINE] completed source=%s questions=%s",
    "llm",
    len(questions),
    )
    return {
        "success": True,
        "questions": questions,
        "generated_at": generated_at,
        "source": "llm",
    }
# ---------------------------------------------------------------------------
# Global App State
# ---------------------------------------------------------------------------

app_state: Dict[str, Any] = {
    "db": None,                         # SQLDatabase instance
    "agent": None,                      # compiled LangGraph agent
    "checkpointer": None,               # MemorySaver or PostgresSaver
    "llm": None,                        # reserved for runtime LLM reference
    "active_connection_string": None,    # current connection string
    "active_connection_id": None,        # current connection ID
    "active_file_id": None,             # current uploaded file ID
    "db_id": None,                      # hash of connection for caching
    "schema_graph": None,
    "schema_graph_db_id": None,
    "conversation_history": [],          # last N query records
    "file_id_registry": {},              # file_id -> db_path
    "inline_connections": {},            # connection_id -> connection_string
    "invalid_sql_cache": set(),
}


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    global CURRENT_DIALECT, CURRENT_CONNECTOR

    # LLM is now lazily resolved per-user via _get_convobi_llm()
    app_state["llm"] = None
    app_state["checkpointer"] = _build_checkpointer()
    _load_file_id_registry_from_disk()

    connection_string = os.getenv("DATABASE_URL")

    if not connection_string:
        CURRENT_DIALECT = "sqlite"
        CURRENT_CONNECTOR = None
        LOG.info("Application initialized without datasource.")
        yield
        LOG.info("Application shutdown complete")
        return

    try:
        cs = _normalize_connection_string(connection_string)
        # Run sync DB I/O in thread to avoid greenlet/async conflict in lifespan
        result = await asyncio.to_thread(activate_connection, cs)
        LOG.info(
            "Application initialized (dialect=%s, tables=%s)",
            CURRENT_DIALECT,
            result.get("tables_loaded", 0),
        )
    except Exception as e:
        LOG.error(
            "Startup connection failed: %s. Running without datasource.", e,
        )
        CURRENT_DIALECT = "sqlite"
        CURRENT_CONNECTOR = None

    yield

    LOG.info("Application shutdown complete")


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Convobi NLP Database Interface (LangGraph + SQLDatabaseToolkit)",
    description="Natural language to SQL with LangGraph agent and session memory.",
    version="2.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from .routes import router  # noqa: E402
app.include_router(router)

# """
# Convobi - LangGraph + SQLDatabaseToolkit NLP-to-SQL Agent
# ==========================================================
# Rewrites the legacy procedural NLP-to-SQL pipeline with a LangGraph
# ReAct-style agent powered by LangChain's SQLDatabaseToolkit (4 tools)
# plus custom Plotly visualisation and summarisation tools.

# Key design choices
# ------------------
# * **Same API surface** - QueryRequest / QueryResponse / SchemaResponse /
#   SummarizeRequest models are identical so the UI and Echo Agent are
#   unchanged.
# * **SQLDatabaseToolkit** provides: ListSQLDatabaseTool,
#   InfoSQLDatabaseTool, QuerySQLDatabaseTool, QuerySQLCheckerTool.
# * **Custom tools** added: PlotlyVisualizationTool, DataSummarizerTool.
# * **Session memory** via MemorySaver (default) or PostgresSaver (env).
# * **invoke_convobi_agent()** - programmatic entry-point for Echo Agent
#   tools / workflow subgraph integration.
# """

# from __future__ import annotations

# import asyncio
# import hashlib
# import json
# import logging
# import os
# import re
# import time
# import uuid
# from contextlib import asynccontextmanager
# from datetime import date, datetime
# from decimal import Decimal
# from pathlib import Path
# from typing import Any, Dict, List, Optional, Tuple
# from urllib.parse import urlparse

# import pandas as pd
# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from pydantic import BaseModel, Field
# from sqlalchemy import create_engine, inspect, text

# # LangChain / LangGraph
# from langchain_core.messages import (
#     AIMessage,
#     HumanMessage,
#     SystemMessage,
#     ToolMessage,
#     trim_messages,
# )
# from langchain_core.messages.utils import count_tokens_approximately
# from langchain_core.tools import tool
# from langchain_community.utilities.sql_database import SQLDatabase
# from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit

# from langgraph.graph import StateGraph, START, END
# from langgraph.graph.message import add_messages
# from langgraph.prebuilt import ToolNode
# from langgraph.checkpoint.memory import MemorySaver

# from typing import Annotated, TypedDict

# # ITSM DB connection IDs — when active, use itsm_column_glossary
# ITSM_CONNECTION_IDS = {"9eb2583a"}

# try:
#     from . import column_glossary
#     from . import itsm_column_glossary
# except ImportError:
#     column_glossary = None
#     itsm_column_glossary = None


# def _is_itsm_connection() -> bool:
#     """True if the active connection is ITSM (SummitAI)."""
#     try:
#         cid = app_state.get("active_connection_id")
#     except NameError:
#         cid = None
#     if cid and cid in ITSM_CONNECTION_IDS:
#         return True
#     # Fallback: check saved connection name
#     try:
#         from pathlib import Path as _Path
#         saved = _Path(__file__).resolve().parent.parent / "connector" / "saved_db_connections.json"
#         if saved.exists() and cid:
#             with open(saved, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#             for conn in data.get("connections", []):
#                 if conn.get("id") == cid:
#                     name = (conn.get("name") or "").upper()
#                     return "ITSM" in name or "SUMMITAI" in name
#     except Exception:
#         pass
#     return False


# def _get_active_glossary():
#     """Return (glossary_dict, get_description_func) for the active connection."""
#     # File uploads: load from per-file glossary
#     fid = app_state.get("active_file_id")
#     if fid:
#         path = get_glossary_path_for_file_id(fid)
#         if path and path.exists():
#             try:
#                 with open(path, "r", encoding="utf-8") as f:
#                     gloss = json.load(f)
#                 def _file_desc(col: str) -> str:
#                     k = (col or "").strip().upper()
#                     return gloss.get(k) or gloss.get(k.replace("_", " ")) or ""
#                 return gloss, _file_desc
#             except Exception:
#                 pass
#         return {}, lambda c: ""
#     # DB connections (small SQLite/other): load from per-connection glossary
#     cid = app_state.get("active_connection_id")
#     if cid and not _is_itsm_connection():
#         path = get_glossary_path_for_connection_id(cid)
#         if path.exists():
#             try:
#                 with open(path, "r", encoding="utf-8") as f:
#                     gloss = json.load(f)
#                 def _conn_desc(col: str) -> str:
#                     k = (col or "").strip().upper()
#                     return gloss.get(k) or gloss.get(k.replace("_", " ")) or ""
#                 return gloss, _conn_desc
#             except Exception:
#                 pass
#         return {}, lambda c: ""
#     if _is_itsm_connection() and itsm_column_glossary:
#         return itsm_column_glossary.COLUMN_GLOSSARY, itsm_column_glossary.get_column_glossary_description
#     if column_glossary:
#         return column_glossary.COLUMN_GLOSSARY, column_glossary.get_column_glossary_description
#     return {}, lambda c: ""


# def get_column_glossary_description(column_name: str) -> str:
#     """Return glossary description for column. Uses ITSM glossary when ITSM DB is active."""
#     _, get_desc = _get_active_glossary()
#     return get_desc(column_name)


# def _get_column_glossary_dict() -> Dict[str, str]:
#     """Return the active COLUMN_GLOSSARY dict (for get_column_for_term, build_glossary_from_schema)."""
#     glossary, _ = _get_active_glossary()
#     return glossary


# COLUMN_GLOSSARY = {}  # Placeholder; runtime uses _get_column_glossary_dict()

# LOG = logging.getLogger("nlpdb")
# logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# # ---------------------------------------------------------------------------
# # Configuration (env vars)
# # ---------------------------------------------------------------------------
# DEFAULT_DB_URL = os.getenv("DATABASE_URL")
# SUPPORTED_DIALECTS = {"sqlite", "postgres", "mysql", "mssql", "oracle", "bigquery", "snowflake"}
# CURRENT_DIALECT = os.getenv("DB_DIALECT", "sqlite").strip().lower()
# if CURRENT_DIALECT not in SUPPORTED_DIALECTS:
#     CURRENT_DIALECT = "sqlite"
# CURRENT_CONNECTOR = None

# UPLOADS_DIR = os.getenv("UPLOADS_DIR", "uploads")
# os.makedirs(UPLOADS_DIR, exist_ok=True)

# # Per-connection schema doc cache (for small SQLite/other DBs - editable schema documentation)
# CONVOBI_SCHEMA_CACHE_DIR = Path(os.getenv("CONVOBI_SCHEMA_CACHE_DIR", "convobi_schema_cache"))
# CONVOBI_SCHEMA_CACHE_DIR.mkdir(parents=True, exist_ok=True)

# CONVOBI_CHECKPOINTER = os.getenv("CONVOBI_CHECKPOINTER", "memory").strip().lower()
# CONVOBI_CHECKPOINT_POSTGRES_URL = os.getenv("CONVOBI_CHECKPOINT_POSTGRES_URL", "")

# DB_WRITE_ACCESS_FILE = os.getenv("DB_WRITE_ACCESS_FILE", "db_write_access.json")

# CONVOBI_AGENT_VERBOSE = os.getenv(
#     "CONVOBI_AGENT_VERBOSE", "true"
# ).strip().lower() in ("true", "1", "yes")

# # ---------------------------------------------------------------------------
# # LLM Setup — lazy per-user resolution via echolib.llm_resolver
# # ---------------------------------------------------------------------------
# from echolib.llm_resolver import resolve_and_build_llm_sync

# _user_llm_cache: Dict[str, Tuple[Any, float]] = {}
# _CACHE_TTL_SECONDS = 300  # 5 minutes


# def _get_convobi_llm(user_id: Optional[str] = None) -> Any:
#     """
#     Get or create a cached LLM instance for the given user.

#     WHAT: Lazily resolves and builds an LLM via the centralized llm_resolver,
#           caching per user_id with a TTL to avoid expensive per-request rebuilds.
#     WHY:  Replaces the module-level CONVOBI_LLM global so that each user gets
#           their own LLM instance resolved through the tiered credential system
#           (user creds -> app creds -> platform fallback).
#     INPUT: user_id -- authenticated user UUID, or None for platform fallback.
#     OUTPUT: A LangChain BaseChatModel instance ready for use.
#     """
#     cache_key = user_id or "__platform__"
#     now = time.time()

#     if cache_key in _user_llm_cache:
#         llm, created_at = _user_llm_cache[cache_key]
#         if now - created_at < _CACHE_TTL_SECONDS:
#             return llm

#     llm = resolve_and_build_llm_sync(
#         user_id=user_id,
#         component="convobi",
#         temperature=0.1,
#         allow_platform_fallback=True,
#         framework="langchain",
#     )
#     _user_llm_cache[cache_key] = (llm, now)
#     return llm

# # ---------------------------------------------------------------------------
# # Pydantic models (IDENTICAL to legacy - API compatibility)
# # ---------------------------------------------------------------------------


# class QueryRequest(BaseModel):
#     question: str = Field(..., description="Natural language question")
#     language: str = Field("sql", description="Query language: only 'sql' is supported")
#     max_results: Optional[int] = Field(None, description="Maximum number of rows")
#     use_cache: bool = Field(True, description="Return cached result when available")
#     auto_proceed: bool = Field(True, description="If True, execute even when warnings are present (default True)")
#     connector_id: Optional[str] = Field(None, description="ID of the DB connection from POST /connectors/plugin/load to recognize which DB is used")
#     file_id: Optional[str] = Field(None, description="ID of an uploaded file from POST /convobi/files/upload; use either connector_id or file_id")


# class QueryResponse(BaseModel):
#     success: bool
#     response: Optional[str] = Field(None, description="Brief, direct answer to the user's question")
#     sql: Optional[str] = None
#     explanation: Optional[str] = None
#     data: Optional[List[Dict[str, Any]]] = None
#     row_count: Optional[int] = None
#     columns: Optional[List[str]] = None
#     visualization_hints: Optional[Dict[str, Any]] = None
#     execution_time_ms: Optional[float] = None
#     confidence: Optional[float] = None
#     optimizations: Optional[List[str]] = None
#     warnings: Optional[List[str]] = None
#     error: Optional[str] = None
#     summary: Optional[str] = None
#     visualization_spec: Optional[Dict[str, Any]] = None
#     visualization_html: Optional[str] = None
#     optimized_question: Optional[str] = None
#     feedback_attempts: Optional[int] = None
#     tables_used: Optional[Dict[str, Any]] = Field(None, description="Tables referenced in the SQL query with column types and sample data")
#     agent_steps: Optional[List[Dict[str, Any]]] = Field(None, description="Agent reasoning trace (only when CONVOBI_AGENT_VERBOSE=true)")


# class SchemaResponse(BaseModel):
#     tables: Dict[str, Any]
#     total_tables: int
#     summary: str


# class SummarizeRequest(BaseModel):
#     question: str
#     columns: List[str]
#     data: List[Dict[str, Any]]
#     visualization_hints: Optional[Dict[str, Any]] = None


# class InvokeRequest(BaseModel):
#     """Request body for POST /convobi/invoke - direct LangGraph agent invocation."""
#     message: str = Field(..., description="Natural language message for the agent")
#     session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")
#     connection_id: Optional[str] = Field(None, description="DB connection ID")
#     file_id: Optional[str] = Field(None, description="Uploaded file ID")
#     max_results: Optional[int] = Field(None, description="Max rows to return")


# class InvokeResponse(BaseModel):
#     """Response for POST /convobi/invoke — matches QueryResponse minus visualization_hints, visualization_spec, feedback_attempts."""
#     success: bool
#     response: str = ""
#     sql: Optional[str] = None
#     explanation: Optional[str] = None
#     data: Optional[List[Dict[str, Any]]] = None
#     row_count: Optional[int] = None
#     columns: Optional[List[str]] = None
#     execution_time_ms: Optional[float] = None
#     confidence: Optional[float] = None
#     optimizations: Optional[List[str]] = None
#     warnings: Optional[List[str]] = None
#     error: Optional[str] = None
#     summary: Optional[str] = None
#     visualization_html: Optional[str] = None
#     optimized_question: Optional[str] = None
#     session_id: str = ""
#     tables_used: Optional[Dict[str, Any]] = Field(None, description="Tables referenced in the SQL query with column types and sample data")
#     agent_steps: Optional[List[Dict[str, Any]]] = Field(None, description="Agent reasoning trace (only when CONVOBI_AGENT_VERBOSE=true)")


# # ---------------------------------------------------------------------------
# # Plotly Visualization Helpers
# # ---------------------------------------------------------------------------


# def _infer_chart_type(columns: List[str], data: List[Dict[str, Any]]) -> str:
#     """Heuristic: pick a chart type from columns and data shape."""
#     if not columns or not data:
#         return "table"
#     sample = data[:20]
#     num_cols: List[str] = []
#     cat_cols: List[str] = []
#     date_cols: List[str] = []
#     for col in columns:
#         vals = [r.get(col) for r in sample if r.get(col) is not None]
#         if not vals:
#             continue
#         if all(isinstance(v, (int, float)) for v in vals):
#             num_cols.append(col)
#         elif any(_looks_like_date(v) for v in vals[:5]):
#             date_cols.append(col)
#         else:
#             cat_cols.append(col)
#     if date_cols and num_cols:
#         return "line"
#     if cat_cols and num_cols:
#         unique_cats = len({r.get(cat_cols[0]) for r in data if r.get(cat_cols[0]) is not None})
#         if unique_cats <= 8 and len(num_cols) == 1:
#             return "pie"
#         return "bar"
#     if len(num_cols) >= 2:
#         return "scatter"
#     return "bar" if num_cols else "table"


# def _looks_like_date(val: Any) -> bool:
#     s = str(val)
#     return bool(re.search(r"\d{4}[-/]\d{1,2}", s)) or bool(re.search(r"\d{1,2}[-/]\d{1,2}[-/]\d{2,4}", s))


# def _json_serial_default(obj: Any) -> Any:
#     """Convert non-JSON-serializable values (datetime, Decimal) for Plotly."""
#     if isinstance(obj, (datetime, date)):
#         return obj.isoformat()
#     if isinstance(obj, Decimal):
#         return int(obj) if obj == int(obj) else float(obj)
#     raise TypeError(f"Object of type {obj.__class__.__name__!r} is not JSON serializable")


# def build_plotly_html(columns: List[str], data: List[Dict[str, Any]], question: str = "") -> Optional[str]:
#     """Build a self-contained Plotly.js HTML snippet for embedding in an iframe."""
#     if not columns or not data:
#         return None
#     chart_type = _infer_chart_type(columns, data)
#     if chart_type == "table":
#         return None

#     traces: List[Dict[str, Any]] = []
#     layout: Dict[str, Any] = {
#         "margin": {"t": 40, "b": 60, "l": 60, "r": 30},
#         "font": {"family": "system-ui, sans-serif"},
#         "template": "plotly_white",
#     }

#     num_cols = [
#         c for c in columns
#         if all(isinstance(r.get(c), (int, float, type(None))) for r in data[:20])
#         and any(r.get(c) is not None for r in data[:20])
#     ]
#     cat_cols = [c for c in columns if c not in num_cols]
#     date_cols = [
#         c for c in cat_cols
#         if any(_looks_like_date(r.get(c)) for r in data[:5] if r.get(c) is not None)
#     ]

#     if chart_type == "line" and date_cols and num_cols:
#         x_col = date_cols[0]
#         for y_col in num_cols[:3]:
#             traces.append({
#                 "x": [r.get(x_col) for r in data],
#                 "y": [r.get(y_col) for r in data],
#                 "type": "scatter",
#                 "mode": "lines+markers",
#                 "name": y_col,
#             })
#         layout["xaxis"] = {"title": x_col}
#         layout["yaxis"] = {"title": num_cols[0] if len(num_cols) == 1 else "Value"}

#     elif chart_type == "bar":
#         x_col = cat_cols[0] if cat_cols else columns[0]
#         y_col = num_cols[0] if num_cols else (columns[1] if len(columns) > 1 else columns[0])
#         traces.append({
#             "x": [r.get(x_col) for r in data],
#             "y": [r.get(y_col) for r in data],
#             "type": "bar",
#             "name": y_col,
#         })
#         layout["xaxis"] = {"title": x_col}
#         layout["yaxis"] = {"title": y_col}

#     elif chart_type == "pie":
#         label_col = cat_cols[0] if cat_cols else columns[0]
#         value_col = num_cols[0] if num_cols else (columns[1] if len(columns) > 1 else columns[0])
#         traces.append({
#             "labels": [r.get(label_col) for r in data],
#             "values": [r.get(value_col) for r in data],
#             "type": "pie",
#         })

#     elif chart_type == "scatter" and len(num_cols) >= 2:
#         traces.append({
#             "x": [r.get(num_cols[0]) for r in data],
#             "y": [r.get(num_cols[1]) for r in data],
#             "type": "scatter",
#             "mode": "markers",
#             "name": f"{num_cols[0]} vs {num_cols[1]}",
#         })
#         layout["xaxis"] = {"title": num_cols[0]}
#         layout["yaxis"] = {"title": num_cols[1]}

#     else:
#         return None

#     if question:
#         layout["title"] = {"text": question[:80], "font": {"size": 14}}

#     spec_json = json.dumps({"data": traces, "layout": layout}, default=_json_serial_default)
#     spec_escaped = spec_json.replace("</", "<\\/")

#     return (
#         "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
#         "<meta name='viewport' content='width=device-width,initial-scale=1'>"
#         "<style>html,body{width:100%;height:100%;margin:0;padding:0;"
#         "font-family:system-ui,sans-serif}"
#         "#chart{width:100%;height:100%;min-height:300px}</style>"
#         "<script src='https://cdn.plot.ly/plotly-2.35.0.min.js'></script>"
#         "</head><body><div id='chart'></div><script>(function(){"
#         "var spec=" + spec_escaped + ";"
#         "Plotly.newPlot('chart',spec.data,spec.layout,"
#         "{responsive:true,displayModeBar:true});"
#         "})();</script></body></html>"
#     )


# # ---------------------------------------------------------------------------
# # LangGraph Agent State
# # ---------------------------------------------------------------------------


# class AgentState(TypedDict):
#     messages: Annotated[list, add_messages]


# # ---------------------------------------------------------------------------
# # Schema hint for agent (column examples)
# # ---------------------------------------------------------------------------


# # ~4 chars/token; 750 tokens = 3000 chars — more examples for accuracy
# _SCHEMA_HINT_MAX_CHARS = 3000

# # Tool output truncation to avoid context overflow (128k limit)
# # ~1500 tokens per tool call; schema/query outputs can be huge
# _MAX_TOOL_OUTPUT_CHARS = 6000


# # Simple stemmer: common suffixes
# _STEM_SUFFIXES = [
#     ("ies", "y"), ("es", ""), ("s", ""), ("ed", ""), ("ing", ""),
#     ("ly", ""), ("er", ""), ("est", ""), ("tion", ""), ("ally", ""),
# ]

# # Synonym expansion for column matching
# _TERM_SYNONYMS: Dict[str, List[str]] = {
#     "win": ["wins", "won", "winning"],
#     "loss": ["lost", "losing"],
#     "revenue": ["sales", "amount", "value", "fee", "fees"],
#     "customer": ["client", "account"],
#     "date": ["month", "year", "time", "period"],
#     "service": ["group", "line", "area"],
#     "industry": ["sector", "segment"],
# }


# def _stem_word(word: str) -> str:
#     """Simple stem: remove common suffixes."""
#     w = word.lower()
#     for suf, repl in _STEM_SUFFIXES:
#         if len(w) > len(suf) + 2 and w.endswith(suf):
#             return w[:-len(suf)] + repl
#     return w


# def _expand_with_synonyms(word: str) -> List[str]:
#     """Return word and its synonyms for matching."""
#     w = word.lower()
#     result = [w]
#     for base, syns in _TERM_SYNONYMS.items():
#         if w == base or w in syns:
#             result.extend([base] + syns)
#     return list(dict.fromkeys(result))


# def _extract_question_keywords(question: str) -> List[str]:
#     """Extract meaningful keywords from question for relevance scoring. Includes stemmed forms and synonyms."""
#     if not question or not question.strip():
#         return []
#     stop = {
#         "the", "a", "an", "what", "how", "many", "show", "give", "me", "list",
#         "get", "of", "in", "for", "to", "by", "from", "with", "and", "or",
#         "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
#         "do", "does", "did", "will", "would", "could", "should", "can", "may",
#     }
#     words = re.findall(r"[a-zA-Z0-9_]+", question.lower())
#     seen: set = set()
#     result: List[str] = []
#     for w in words:
#         if len(w) > 1 and w not in stop and w not in seen:
#             seen.add(w)
#             result.append(w)
#             stemmed = _stem_word(w)
#             if stemmed != w and stemmed not in seen:
#                 seen.add(stemmed)
#                 result.append(stemmed)
#             for syn in _expand_with_synonyms(w):
#                 if syn not in seen and len(syn) > 1:
#                     seen.add(syn)
#                     result.append(syn)
#     return result


# def _score_table_relevance(tname: str, keywords: List[str]) -> int:
#     """Score table name relevance to question keywords."""
#     if not keywords:
#         return 0
#     tlower = tname.lower()
#     return sum(1 for k in keywords if k in tlower)


# def _score_column_relevance(col_name: str, examples: List[str], keywords: List[str]) -> int:
#     """Score column relevance: name + example values."""
#     if not keywords:
#         return 0
#     score = sum(1 for k in keywords if k in col_name.lower())
#     ex_str = " ".join(str(e).lower() for e in (examples or [])[:20])
#     score += sum(1 for k in keywords if k in ex_str)
#     return score


# def _format_schema_hint_for_question(
#     tables: Dict[str, Any],
#     question: str,
#     max_chars: int = _SCHEMA_HINT_MAX_CHARS,
# ) -> str:
#     """
#     Format question-aware column examples. Only includes tables/columns
#     relevant to the question to stay within token budget.
#     """
#     if not tables or not question:
#         return ""
#     keywords = _extract_question_keywords(question)
#     lines = ["COLUMN EXAMPLES (pick columns whose examples match the question):", ""]
#     total = len("\n".join(lines))
#     max_per_col = 5
#     max_col_len = 25
#     max_cols_per_table = 10

#     # Score and sort tables by relevance
#     scored_tables = [
#         (tname, _score_table_relevance(tname, keywords))
#         for tname in tables.keys()
#     ]
#     scored_tables.sort(key=lambda x: (-x[1], x[0]))
#     # If no keyword match, include first few tables; otherwise take top relevant
#     if not any(s > 0 for _, s in scored_tables):
#         top_tables = [t for t, _ in scored_tables[:4]]
#     else:
#         top_tables = [t for t, s in scored_tables if s > 0][:6]
#         if len(top_tables) < 2:
#             top_tables = [t for t, _ in scored_tables[:4]]

#     for tname in top_tables:
#         if total >= max_chars:
#             break
#         tbl = tables.get(tname, {})
#         cols = tbl.get("columns", [])
#         if not cols:
#             continue
#         # Score columns and take most relevant
#         col_scores = [
#             (c, _score_column_relevance(
#                 c.get("name", ""),
#                 c.get("examples", []),
#                 keywords,
#             ))
#             for c in cols
#         ]
#         col_scores.sort(key=lambda x: (-x[1], x[0].get("name", "")))
#         top_cols = [c for c, s in col_scores[:max_cols_per_table]]
#         if not top_cols and cols:
#             top_cols = cols[:max_cols_per_table]

#         block = [f"Table {tname}:"]
#         for col in top_cols:
#             if total >= max_chars:
#                 break
#             name = col.get("name", "")
#             examples = col.get("examples", [])[:max_per_col]
#             if examples:
#                 preview = ", ".join(str(v)[:max_col_len] for v in examples)
#                 block.append(f"  {name}: {preview}")
#             else:
#                 block.append(f"  {name}")
#         block.append("")
#         block_str = "\n".join(block)
#         total += len(block_str)
#         lines.extend(block)

#     if total >= max_chars:
#         lines.append("(truncated)")
#     return "\n".join(lines)


# def _format_schema_hint_for_agent(tables: Dict[str, Any]) -> str:
#     """
#     Format a compact schema hint with column examples for the agent.
#     Used when no question is available (e.g. connection activation).
#     Capped at ~500 tokens to avoid context overflow (128k limit).
#     """
#     if not tables:
#         return ""
#     lines = ["\n\nCOLUMN EXAMPLES (pick columns whose examples match the question):", ""]
#     total = len("\n".join(lines))
#     max_per_col = 3
#     max_col_len = 20
#     max_tables = 4
#     max_cols_per_table = 8

#     for tname in sorted(tables.keys())[:max_tables]:
#         if total >= _SCHEMA_HINT_MAX_CHARS:
#             break
#         tbl = tables[tname]
#         cols = tbl.get("columns", [])[:max_cols_per_table]
#         if not cols:
#             continue
#         block = [f"Table {tname}:"]
#         for col in cols:
#             if total >= _SCHEMA_HINT_MAX_CHARS:
#                 break
#             name = col.get("name", "")
#             examples = col.get("examples", [])[:max_per_col]
#             if examples:
#                 preview = ", ".join(str(v)[:max_col_len] for v in examples)
#                 block.append(f"  {name}: {preview}")
#             else:
#                 block.append(f"  {name}")
#         block.append("")
#         block_str = "\n".join(block)
#         total += len(block_str)
#         lines.extend(block)

#     if total >= _SCHEMA_HINT_MAX_CHARS:
#         lines.append("(truncated)")
#     return "\n".join(lines)


# # ---------------------------------------------------------------------------
# # System Prompt Builder
# # ---------------------------------------------------------------------------


# _PROMPT_CONFIG_PATH = Path(__file__).parent / "convobi_prompt_config.json"
# _PROMPT_CONFIG_CACHE: Dict[str, Any] = {}
# _PROMPT_CONFIG_MTIME: float = 0


# def _load_prompt_config() -> Dict[str, Any]:
#     """Load per-database prompt config from JSON."""
#     global _PROMPT_CONFIG_CACHE, _PROMPT_CONFIG_MTIME
#     path = os.getenv("CONVOBI_PROMPT_CONFIG", str(_PROMPT_CONFIG_PATH))
#     try:
#         mtime = os.path.getmtime(path) if os.path.exists(path) else 0
#         if mtime != _PROMPT_CONFIG_MTIME or not _PROMPT_CONFIG_CACHE:
#             _PROMPT_CONFIG_MTIME = mtime
#             with open(path, "r", encoding="utf-8") as f:
#                 _PROMPT_CONFIG_CACHE = json.load(f)
#     except Exception as e:
#         LOG.warning("Could not load prompt config from %s: %s. Using empty config.", path, e)
#         _PROMPT_CONFIG_CACHE = {"domains": {"default": {"few_shot_examples": "", "domain_rules": "", "term_to_column": {}, "glossary_hint": ""}}}
#     return _PROMPT_CONFIG_CACHE


# def _get_prompt_config_for_connection() -> Dict[str, Any]:
#     """Return prompt config for the active connection (per-database variables)."""
#     config = _load_prompt_config()
#     mapping = config.get("connection_domain_mapping", {})
#     domains = config.get("domains", {})

#     domain_key = mapping.get("default", "default")
#     try:
#         cid = app_state.get("active_connection_id")
#         if cid and cid in mapping:
#             domain_key = mapping[cid]
#         elif cid:
#             saved = Path(__file__).resolve().parent.parent / "connector" / "saved_db_connections.json"
#             if saved.exists():
#                 with open(saved, "r", encoding="utf-8") as f:
#                     data = json.load(f)
#                 for conn in data.get("connections", []):
#                     if conn.get("id") == cid:
#                         name = (conn.get("name") or "").upper()
#                         if ("ITSM" in name or "SUMMITAI" in name) and "itsm" in domains:
#                             domain_key = "itsm"
#                         elif ("CRM" in name or "OPPORTUNITIES" in name) and "crm" in domains:
#                             domain_key = "crm"
#                         break
#     except Exception:
#         pass

#     domain = domains.get(domain_key, domains.get("default", {}))
#     return {
#         "few_shot_examples": domain.get("few_shot_examples", ""),
#         "domain_rules": domain.get("domain_rules", ""),
#         "term_to_column": domain.get("term_to_column", {}),
#         "glossary_hint": domain.get("glossary_hint", ""),
#     }


# def _build_system_prompt(
#     dialect: str,
#     glossary_hint: str = "",
#     few_shot_examples: str = "",
#     domain_rules: str = "",
#     term_to_column: Optional[Dict[str, str]] = None,
# ) -> str:
#     dialect_rules = {
#         "sqlite": (
#             "SQLite rules: use date('now','-N units')/strftime, LIMIT (not TOP), "
#             "CURRENT_TIMESTAMP not NOW(), no INTERVAL, no DATE_TRUNC."
#         ),
#         "mssql": (
#             "MSSQL rules: use TOP N (not LIMIT), FORMAT(col,'yyyy-MM') for month, "
#             "DATEADD/DATEDIFF for date arithmetic, GETDATE() for current time."
#         ),
#         "postgres": (
#             "PostgreSQL rules: use LIMIT, DATE_TRUNC, INTERVAL, NOW(), "
#             "TO_CHAR for date formatting."
#         ),
#         "mysql": (
#             "MySQL rules: use LIMIT, DATE_FORMAT, NOW(), INTERVAL, "
#             "DATE_SUB/DATE_ADD for date arithmetic."
#         ),
#         "oracle": (
#             "Oracle rules: use ROWNUM or FETCH FIRST N ROWS ONLY, SYSDATE, "
#             "TO_CHAR for date formatting, ADD_MONTHS for date arithmetic."
#         ),
#     }
#     rules = dialect_rules.get(dialect, dialect_rules["sqlite"])

#     # Per-database variables appended at END of prompt to avoid context dilution in the middle
#     db_specific_section = ""
#     if few_shot_examples and few_shot_examples.strip():
#         db_specific_section += "\n\n--- DATABASE-SPECIFIC EXAMPLES (for this connection only) ---\n" + few_shot_examples.strip()
#     if domain_rules and domain_rules.strip():
#         db_specific_section += "\n\n--- DATABASE-SPECIFIC RULES ---\n" + domain_rules.strip()
#     if glossary_hint and glossary_hint.strip():
#         db_specific_section += "\n\n--- DATABASE-SPECIFIC GLOSSARY / COLUMN GUIDANCE ---\n" + glossary_hint.strip()
#     term_map = term_to_column or {}
#     if term_map:
#         lines = [f"- {term}: {guidance}" for term, guidance in term_map.items()]
#         db_specific_section += "\n\n--- TERM-TO-COLUMN MAPPING (for this connection) ---\n" + "\n".join(lines)

#     return (
#         "You are an expert data analyst and SQL agent. "
#         "You have access to a SQL database and tools to explore and query it.\n\n"
#         "WORKFLOW:\n"
#         "1. Use sql_db_list_tables to discover available tables.\n"
#         "2. Use sql_db_schema to understand relevant table structures and column examples.\n"
#         "3. ALWAYS use sql_db_query_checker to validate your SQL before executing.\n"
#         "4. Use sql_db_query to execute the query and get results.\n"
#         "5. If sql_db_query fails, read the error, fix the SQL, and retry (up to 2 retries).\n"
#         "6. Analyze the results thoroughly and formulate a detailed structured response.\n\n"
#         f"DATABASE DIALECT: {dialect}\n{rules}\n\n"
#         "RULES:\n"
#         "- Only use tables and columns that exist in the schema.\n"
#         "- Do NOT use DML (INSERT, UPDATE, DELETE, DROP) unless explicitly asked.\n"
#         "- Use ALL column examples from the tables: scan every column's examples before choosing. Use get_column_for_term tool when unsure about column mapping.\n"
#         "- When the user mentions specific values (e.g. industry names, Win, Loss), match them to columns whose examples contain those values.\n"
#         "- When a value is in double quotes (e.g. \"Chopra, Ajay\"), treat it as ONE string. Use = 'Chopra, Ajay' not IN ('Chopra', 'Ajay'). Do NOT split by comma.\n"
#         "- When multiple columns have similar names, compare ALL their examples and select the one whose examples best match the question.\n"
#         "- For trends/monthly breakdowns, GROUP BY the time period and "
#         "return one row per period.\n"
#         "- If a query fails, read the error and fix the SQL.\n"
#         "- When choosing columns, prefer the column whose NAME or examples "
#         "match the question.\n"
#         "- For monthly trend or trend-over-time questions: GROUP BY the time "
#         "period (month) and SELECT the period label plus the aggregate; "
#         "return one row per period, not a single total.\n"
#         "- For 'last N months' questions, filter by the date column.\n"
#         "- Do NOT add LIMIT or TOP unless the user explicitly asks for a limited "
#         "number (e.g. 'top 10', 'first 5', 'show only 20'). Otherwise return all "
#         "matching rows.\n\n"
#         "RESPONSE FORMAT:\n"
#         "After obtaining the query results, you MUST respond with ONLY a valid JSON object "
#         "(no markdown code fences, no extra text before or after). The JSON MUST have exactly "
#         "these keys:\n"
#         "{\n"
#         '  "sql": "the exact SQL query you executed",\n'
#         '  "response": "A brief, direct 1-3 sentence answer using ONLY the actual '
#         'names and numbers from the sql_db_query results. No markdown, no formatting.",\n'
#         '  "explanation": "One clear sentence explaining what the query does and '
#         'why you chose this approach",\n'
#         '  "summary": "A comprehensive analytical markdown report (using ONLY actual query results) structured as follows:\\n\\n'
#         "## Key Findings\\n"
#         "- State the direct answer with **bold key numbers/totals** from the query results\\n"
#         "- Include percentages and proportions where applicable\\n\\n"
#         "## Analytics\\n"
#         "- Provide statistical breakdowns (min, max, average, total counts)\\n"
#         "- Calculate percentage distributions across categories\\n"
#         "- Highlight the top/bottom performers or values\\n\\n"
#         "## Trends & Patterns\\n"
#         "- Identify time-based trends (increasing, decreasing, stable, seasonal)\\n"
#         "- Note rate of change between periods (e.g. +15% month-over-month)\\n"
#         "- Call out any cyclical or seasonal patterns\\n\\n"
#         "## Insights & Anomalies\\n"
#         "- Highlight anything unusual, unexpected, or noteworthy\\n"
#         "- Compare against what might be expected\\n"
#         "- Note any data gaps or outliers\\n\\n"
#         "## Actionable Takeaways\\n"
#         "- Suggest next steps or areas to investigate further\\n"
#         '- Recommend follow-up queries if the data suggests deeper questions",\n'
#         '  "confidence": <float 0.0-1.0>,\n'
#         '  "warnings": ["list any assumptions, ambiguities, or data quality issues"],\n'
#         '  "optimizations": ["SQL performance suggestions or alternative approaches, if any"]\n'
#         "}\n\n"
#         "CRITICAL - NEVER HALLUCINATE:\n"
#         "- Use ONLY names, numbers, and values from the actual sql_db_query results.\n"
#         "- Never invent or fabricate person names, counts, or statistics.\n"
#         "- If results are empty or truncated, say so explicitly—do not invent placeholders like 'John Doe' or '150'.\n"
#         "- NEVER use SQL column names (e.g. [Resolved Updated By User Name], ticket_count) as the answer—those are column labels, not data. The result format is a list of tuples like [('ActualName', 123)]; use the tuple values.\n"
#         "- If sql_db_query returns an empty string or [] (zero rows), you MUST respond with 'No data is available' or 'No results found'—never invent dummy data, example names, or fake statistics. Do not fill in Key Findings, Analytics, or Insights with fabricated content.\n\n"
#         "ANALYSIS GUIDELINES:\n"
#         "- Always compute totals and averages when the data supports it.\n"
#         "- For time-series data, compute period-over-period change (absolute and %).\n"
#         "- For categorical data, show the distribution (% share of each category).\n"
#         "- If the result has only 1 row, provide context by explaining what the number means.\n"
#         "- If the result has multiple rows, look for patterns: which is highest/lowest, "
#         "is there a trend, are values clustered or spread out.\n"
#         "- Never just restate the raw numbers — interpret them, but only using actual data.\n\n"
#         "CONFIDENCE GUIDE:\n"
#         "- 0.95-1.0: Perfect match — unambiguous question, clean data, exact answer.\n"
#         "- 0.80-0.94: Good match — minor assumptions made (e.g. date range inferred).\n"
#         "- 0.60-0.79: Reasonable match — notable assumptions or partial data.\n"
#         "- Below 0.60: Significant uncertainty — explain in warnings.\n\n"
#         "If the query fails and you cannot recover, still return the JSON with "
#         '"sql" set to the attempted query, "confidence" below 0.5, and explain '
#         'the error in "summary" and "warnings".'
#         f"{db_specific_section}"
#     )


# # ---------------------------------------------------------------------------
# # Agent Builder
# # ---------------------------------------------------------------------------


# def _get_term_to_column_map() -> Dict[str, str]:
#     """Return term-to-column mapping from per-database prompt config."""
#     return _get_prompt_config_for_connection().get("term_to_column", {})


# def _create_get_column_for_term_tool() -> Any:
#     """Create tool to look up the correct column for a business term."""
#     @tool
#     def get_column_for_term(term: str) -> str:
#         """Look up the correct database column for a business term. Use when unsure which column to use for wins, revenue, customer, service group, tickets, incidents, status, etc. Returns the column name and usage guidance."""
#         t = str(term).strip().lower()
#         if not t:
#             return "Provide a business term (e.g. wins, revenue, customer, ticket, incident, status)."
#         term_map = _get_term_to_column_map()
#         for key, guidance in term_map.items():
#             if key in t or t in key:
#                 return guidance
#         glossary = _get_column_glossary_dict()
#         matches = []
#         for col, desc in glossary.items():
#             if t in col.lower() or t in desc.lower():
#                 matches.append(f"{col}: {desc[:120]}...")
#         if matches:
#             return "Possible columns:\n" + "\n".join(matches[:5])
#         return f"No specific mapping for '{term}'. Check sql_db_schema for column examples."
#     return get_column_for_term


# def _build_checkpointer():
#     """Create the appropriate checkpointer based on env config."""
#     if CONVOBI_CHECKPOINTER == "postgres" and CONVOBI_CHECKPOINT_POSTGRES_URL:
#         try:
#             from langgraph.checkpoint.postgres import PostgresSaver
#             return PostgresSaver.from_conn_string(CONVOBI_CHECKPOINT_POSTGRES_URL)
#         except Exception as e:
#             LOG.warning("PostgresSaver init failed (%s); falling back to MemorySaver", e)
#     return MemorySaver()


# def build_agent(
#     llm: Any,
#     db_instance: SQLDatabase,
#     dialect: str,
#     glossary_hint: str = "",
#     checkpointer: Any = None,
# ):
#     """
#     Build a LangGraph ReAct agent with SQLDatabaseToolkit tools +
#     custom visualisation / summarisation tools.

#     Returns a compiled LangGraph that can be .invoke()-ed.
#     """
#     toolkit = SQLDatabaseToolkit(db=db_instance, llm=llm)
#     toolkit_tools = toolkit.get_tools()
#     column_lookup_tool = _create_get_column_for_term_tool()

#     all_tools = list(toolkit_tools) + [column_lookup_tool]
#     raw_tool_node = ToolNode(all_tools)

#     prompt_cfg = _get_prompt_config_for_connection()
#     hint = glossary_hint or prompt_cfg.get("glossary_hint", "")
#     system_prompt = _build_system_prompt(
#         dialect,
#         glossary_hint=hint,
#         few_shot_examples=prompt_cfg.get("few_shot_examples", ""),
#         domain_rules=prompt_cfg.get("domain_rules", ""),
#         term_to_column=prompt_cfg.get("term_to_column", {}),
#     )

#     llm_with_tools = llm.bind_tools(all_tools)

#     def agent_node(state: AgentState) -> Dict[str, Any]:
#         msgs = list(state["messages"])
#         if not msgs or not isinstance(msgs[0], SystemMessage):
#             msgs = [SystemMessage(content=system_prompt)] + msgs

#         # Trim to avoid context overflow (128k limit); keep system + recent messages
#         msgs = trim_messages(
#             msgs,
#             max_tokens=80_000,
#             token_counter=count_tokens_approximately,
#             strategy="last",
#             include_system=True,
#             start_on="human",
#         )

#         step_count = sum(1 for m in msgs if isinstance(m, (AIMessage, ToolMessage)))
#         if CONVOBI_AGENT_VERBOSE:
#             LOG.info("[ConvoBI Agent] Step %d — invoking LLM (messages=%d)", step_count, len(msgs))
#         else:
#             LOG.debug("[ConvoBI Agent] Invoking LLM (messages=%d)", len(msgs))

#         t0 = time.time()
#         response = llm_with_tools.invoke(msgs)
#         elapsed = (time.time() - t0) * 1000

#         if getattr(response, "tool_calls", None):
#             tool_names = ", ".join(tc.get("name", "?") for tc in response.tool_calls)
#             if CONVOBI_AGENT_VERBOSE:
#                 LOG.info(
#                     "[ConvoBI Agent] Step %d — LLM requesting tools: [%s] (%.0fms)",
#                     step_count, tool_names, elapsed,
#                 )
#             else:
#                 LOG.debug("[ConvoBI Agent] LLM → tools: [%s] (%.0fms)", tool_names, elapsed)
#         else:
#             content_preview = (getattr(response, "content", "") or "")[:200]
#             if CONVOBI_AGENT_VERBOSE:
#                 LOG.info(
#                     "[ConvoBI Agent] Step %d — LLM final response (%.0fms): %s...",
#                     step_count, elapsed, content_preview,
#                 )
#             else:
#                 LOG.debug("[ConvoBI Agent] LLM final response (%.0fms)", elapsed)

#         return {"messages": [response]}

#     def logging_tool_node(state: AgentState) -> Dict[str, Any]:
#         last_msg = state["messages"][-1]
#         tool_names: List[str] = []
#         if isinstance(last_msg, AIMessage) and getattr(last_msg, "tool_calls", None):
#             tool_names = [tc.get("name", "?") for tc in last_msg.tool_calls]
#             if CONVOBI_AGENT_VERBOSE:
#                 for tc in last_msg.tool_calls:
#                     args_str = json.dumps(tc.get("args", {}), default=str)[:500]
#                     LOG.info("[ConvoBI Tools] Executing: %s | Args: %s", tc.get("name"), args_str)
#             else:
#                 LOG.debug("[ConvoBI Tools] Executing: %s", ", ".join(tool_names))

#         t0 = time.time()
#         result = raw_tool_node.invoke(state)
#         elapsed = (time.time() - t0) * 1000

#         # Truncate tool outputs to avoid context overflow (128k limit)
#         # Higher limits for schema and query results (both critical for accuracy—truncation causes hallucination)
#         truncated_messages = []
#         for msg in result.get("messages", []):
#             if isinstance(msg, ToolMessage) and msg.content:
#                 tool_name = (msg.name or "").lower()
#                 if tool_name == "sql_db_schema":
#                     limit = 10000
#                 elif tool_name == "sql_db_query":
#                     limit = 15000  # Query results must be visible to avoid inventing names/numbers
#                 else:
#                     limit = _MAX_TOOL_OUTPUT_CHARS
#                 if len(msg.content) > limit:
#                     msg = ToolMessage(
#                         content=msg.content[:limit]
#                         + "\n\n[... output truncated due to length ...]",
#                         tool_call_id=msg.tool_call_id,
#                         name=msg.name,
#                     )
#             truncated_messages.append(msg)
#         result = {"messages": truncated_messages}

#         if CONVOBI_AGENT_VERBOSE:
#             for msg in result.get("messages", []):
#                 if isinstance(msg, ToolMessage):
#                     output_preview = (msg.content or "")[:1000]
#                     status = "ERROR" if "error" in (msg.content or "").lower()[:100] else "OK"
#                     LOG.info(
#                         "[ConvoBI Tools] %s [%s] (%.0fms): %s",
#                         msg.name, status, elapsed, output_preview,
#                     )
#         else:
#             LOG.debug("[ConvoBI Tools] %s completed (%.0fms)", ", ".join(tool_names), elapsed)

#         return result

#     def should_continue(state: AgentState) -> str:
#         last = state["messages"][-1]
#         if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
#             if CONVOBI_AGENT_VERBOSE:
#                 LOG.info("[ConvoBI Router] → tools")
#             return "tools"
#         if CONVOBI_AGENT_VERBOSE:
#             LOG.info("[ConvoBI Router] → END")
#         return END

#     graph = StateGraph(AgentState)
#     graph.add_node("agent", agent_node)
#     graph.add_node("tools", logging_tool_node)
#     graph.add_edge(START, "agent")
#     graph.add_conditional_edges(
#         "agent",
#         should_continue,
#         {"tools": "tools", END: END},
#     )
#     graph.add_edge("tools", "agent")

#     return graph.compile(checkpointer=checkpointer)


# # ---------------------------------------------------------------------------
# # Result Parsing - Extract SQL, data, summary from agent messages
# # ---------------------------------------------------------------------------


# def _try_parse_structured_response(text_content: Optional[str]) -> Optional[Dict[str, Any]]:
#     """Try to parse the agent's final message as a structured JSON response."""
#     if not text_content:
#         return None
#     content = text_content.strip()

#     # Direct JSON parse
#     try:
#         parsed = json.loads(content)
#         if isinstance(parsed, dict) and ("sql" in parsed or "summary" in parsed):
#             return parsed
#     except (json.JSONDecodeError, ValueError):
#         pass

#     # Extract JSON from markdown code fences
#     json_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", content, re.DOTALL)
#     if json_match:
#         try:
#             parsed = json.loads(json_match.group(1).strip())
#             if isinstance(parsed, dict):
#                 return parsed
#         except (json.JSONDecodeError, ValueError):
#             pass

#     # Find a JSON object embedded in text
#     brace_start = content.find("{")
#     brace_end = content.rfind("}")
#     if brace_start >= 0 and brace_end > brace_start:
#         try:
#             parsed = json.loads(content[brace_start : brace_end + 1])
#             if isinstance(parsed, dict) and ("sql" in parsed or "summary" in parsed):
#                 return parsed
#         except (json.JSONDecodeError, ValueError):
#             pass

#     return None


# def _extract_agent_steps(messages: list) -> List[Dict[str, Any]]:
#     """Build a structured reasoning trace from the agent's message history."""
#     steps: List[Dict[str, Any]] = []
#     step_num = 0
#     ts = datetime.now().isoformat()

#     for msg in messages:
#         if isinstance(msg, SystemMessage):
#             continue

#         if isinstance(msg, HumanMessage):
#             step_num += 1
#             steps.append({
#                 "step": step_num,
#                 "node": "input",
#                 "event": "user_message",
#                 "content": (msg.content or "")[:200],
#                 "timestamp": ts,
#             })

#         elif isinstance(msg, AIMessage):
#             step_num += 1
#             if getattr(msg, "tool_calls", None):
#                 for tc in msg.tool_calls:
#                     steps.append({
#                         "step": step_num,
#                         "node": "agent",
#                         "event": "tool_call",
#                         "tool": tc.get("name", "unknown"),
#                         "input": json.dumps(tc.get("args", {}), default=str)[:500],
#                         "timestamp": ts,
#                     })
#             else:
#                 steps.append({
#                     "step": step_num,
#                     "node": "agent",
#                     "event": "final_response",
#                     "content": (msg.content or "")[:500],
#                     "timestamp": ts,
#                 })

#         elif isinstance(msg, ToolMessage):
#             step_num += 1
#             output = (msg.content or "")[:1000]
#             status = "error" if "error" in output.lower()[:100] else "success"
#             steps.append({
#                 "step": step_num,
#                 "node": "tools",
#                 "event": "tool_result",
#                 "tool": getattr(msg, "name", "unknown"),
#                 "status": status,
#                 "output": output,
#                 "timestamp": ts,
#             })

#     return steps


# def _extract_table_names_from_sql(sql: str) -> List[str]:
#     """Parse SQL to extract referenced table names (FROM, JOIN, INTO clauses)."""
#     if not sql:
#         return []
#     normalised = re.sub(r"--[^\n]*", " ", sql)
#     normalised = re.sub(r"/\*.*?\*/", " ", normalised, flags=re.DOTALL)
#     normalised = " ".join(normalised.split())

#     patterns = [
#         r'\bFROM\s+"?(\w+)"?',
#         r'\bJOIN\s+"?(\w+)"?',
#         r'\bINTO\s+"?(\w+)"?',
#         r'\bUPDATE\s+"?(\w+)"?',
#     ]
#     tables: List[str] = []
#     for pat in patterns:
#         tables.extend(re.findall(pat, normalised, re.IGNORECASE))

#     seen: set = set()
#     unique: List[str] = []
#     for t in tables:
#         low = t.lower()
#         if low not in seen:
#             seen.add(low)
#             unique.append(t)
#     return unique


# def _extract_tables_used(
#     sql: Optional[str],
#     db_instance: SQLDatabase,
#     result_columns: Optional[List[str]] = None,
#     sample_rows: int = 5,
# ) -> Optional[Dict[str, Any]]:
#     """
#     Extract metadata and sample data for tables referenced in the SQL.

#     Only includes the columns that actually appear in the query output
#     (intersected with each table's real columns). This keeps the response
#     focused on exactly the data used to produce the final result.

#     Args:
#         sql: The executed SQL query.
#         db_instance: Active SQLDatabase connection.
#         result_columns: Column names from the query result — used to
#             filter each table down to only the relevant columns.
#         sample_rows: Number of sample rows per table (default 5).
#     """
#     if not sql or not db_instance:
#         return None

#     table_names = _extract_table_names_from_sql(sql)
#     if not table_names:
#         return None

#     usable = set(db_instance.get_usable_table_names())
#     engine = db_instance._engine
#     dialect_name = engine.dialect.name.lower()
#     insp = inspect(engine)
#     result: Dict[str, Any] = {}

#     result_cols_lower = {c.lower() for c in (result_columns or [])}

#     for tname in table_names:
#         if tname not in usable:
#             matched = [u for u in usable if u.lower() == tname.lower()]
#             if matched:
#                 tname = matched[0]
#             else:
#                 continue

#         try:
#             db_columns = insp.get_columns(tname)
#             all_col_names = [c["name"] for c in db_columns]

#             if result_cols_lower:
#                 relevant_cols = [
#                     c for c in all_col_names if c.lower() in result_cols_lower
#                 ]
#             else:
#                 relevant_cols = all_col_names

#             if not relevant_cols:
#                 relevant_cols = all_col_names

#             quoted_cols = ", ".join(f'"{c}"' for c in relevant_cols)

#             total_rows: Optional[int] = None
#             sample_data: List[Dict[str, Any]] = []
#             try:
#                 with engine.connect() as conn:
#                     rc = conn.execute(
#                         text(f'SELECT COUNT(*) FROM "{tname}"')
#                     ).scalar()
#                     total_rows = int(rc) if rc is not None else None

#                     if dialect_name in ("mssql",):
#                         sample_sql = f'SELECT TOP {sample_rows} {quoted_cols} FROM "{tname}"'
#                     elif dialect_name in ("oracle",):
#                         sample_sql = (
#                             f'SELECT {quoted_cols} FROM "{tname}" '
#                             f"WHERE ROWNUM <= {sample_rows}"
#                         )
#                     else:
#                         sample_sql = f'SELECT {quoted_cols} FROM "{tname}" LIMIT {sample_rows}'

#                     rows = conn.execute(text(sample_sql))
#                     keys = list(rows.keys())
#                     sample_data = [
#                         {k: _serialise_value(v) for k, v in zip(keys, row)}
#                         for row in rows.fetchall()
#                     ]
#             except Exception as exc:
#                 LOG.debug("Sample data fetch failed for %s: %s", tname, exc)

#             result[tname] = {
#                 "name": tname,
#                 "row_count": total_rows,
#                 "sample_data": sample_data,
#             }
#         except Exception as e:
#             LOG.debug("Could not inspect table %s: %s", tname, e)

#     return result if result else None


# def _serialise_value(val: Any) -> Any:
#     """Make a DB cell value JSON-serialisable."""
#     if val is None or isinstance(val, (str, int, float, bool)):
#         return val
#     if isinstance(val, datetime):
#         return val.isoformat()
#     return str(val)


# def _parse_agent_results(
#     messages: list,
#     db_instance: SQLDatabase,
#     question: str,
# ) -> Dict[str, Any]:
#     """
#     Walk through agent messages to extract the SQL that was executed,
#     the raw result, and build structured data for the API response.

#     Two-tier parsing:
#       1. Try to parse the final AI message as structured JSON (sql, explanation,
#          summary, confidence, warnings, optimizations).
#       2. Fall back to heuristics if the LLM did not produce valid JSON.
#     """
#     sql_executed: Optional[str] = None
#     raw_result: Optional[str] = None
#     final_text: Optional[str] = None
#     data: Optional[List[Dict[str, Any]]] = None
#     columns: Optional[List[str]] = None
#     row_count: Optional[int] = None

#     response: Optional[str] = None
#     explanation: Optional[str] = None
#     summary: Optional[str] = None
#     confidence: Optional[float] = None
#     warnings: Optional[List[str]] = None
#     optimizations: Optional[List[str]] = None

#     error_retries = 0

#     for msg in messages:
#         if isinstance(msg, AIMessage):
#             if getattr(msg, "tool_calls", None):
#                 for tc in msg.tool_calls:
#                     if tc.get("name") == "sql_db_query":
#                         sql_executed = tc.get("args", {}).get("query", sql_executed)
#             elif msg.content:
#                 final_text = msg.content

#         if isinstance(msg, ToolMessage) and msg.name == "sql_db_query":
#             raw_result = msg.content
#             if raw_result and "error" in raw_result.lower()[:100]:
#                 error_retries += 1

#     # --- Tier 1: Structured JSON from the LLM ---
#     structured = _try_parse_structured_response(final_text)
#     if structured:
#         response = structured.get("response")
#         explanation = structured.get("explanation")
#         summary = structured.get("summary")
#         confidence = structured.get("confidence")
#         if isinstance(confidence, (int, float)):
#             confidence = max(0.0, min(1.0, float(confidence)))
#         else:
#             confidence = None
#         warnings = structured.get("warnings")
#         if not isinstance(warnings, list):
#             warnings = None
#         optimizations = structured.get("optimizations")
#         if not isinstance(optimizations, list):
#             optimizations = None
#         if not sql_executed and structured.get("sql"):
#             sql_executed = structured["sql"]
#         LOG.info("[ConvoBI Parse] Structured JSON response parsed successfully")
#     else:
#         # --- Tier 2: Heuristic fallback ---
#         if final_text:
#             sentences = final_text.split(". ")
#             response = (sentences[0].strip() + ".") if sentences else final_text[:200]
#             explanation = (sentences[1].strip() + ".") if len(sentences) > 1 else response
#             summary = final_text
#         LOG.info("[ConvoBI Parse] Heuristic fallback — structured JSON not available")

#     # Re-execute the last successful SQL to get structured data
#     if sql_executed and raw_result and "Error" not in (raw_result or "")[:50]:
#         try:
#             engine = db_instance._engine
#             with engine.connect() as conn:
#                 result = conn.execute(text(sql_executed))
#                 columns = list(result.keys())
#                 rows = result.fetchall()
#                 data = [dict(zip(columns, row)) for row in rows]
#                 row_count = len(data)
#         except Exception as e:
#             LOG.warning("Re-execution for structured data failed: %s", e)
#             data = None
#             columns = None

#     # Override LLM response when query returned no data — prevent hallucinated/dummy data
#     if sql_executed and row_count is not None and row_count == 0:
#         response = "No data is available for the specified criteria."
#         summary = (
#             "## Key Findings\n"
#             "- No data was found in the database for the specified query parameters.\n\n"
#             "## Data Availability\n"
#             "- The query executed successfully but returned zero rows.\n"
#             "- This may indicate that no records exist for the requested time period, filters, or criteria.\n"
#             "- Please verify the date range, filters, or try a different query."
#         )
#         confidence = 0.5

#     # Heuristic confidence when LLM didn't provide one
#     if confidence is None:
#         if data is not None and row_count and row_count > 0:
#             confidence = 0.9 if error_retries == 0 else 0.7
#         elif sql_executed and raw_result:
#             confidence = 0.6
#         else:
#             confidence = 0.3

#     # Heuristic warnings from retries
#     if warnings is None:
#         warnings = []
#     if error_retries > 0:
#         warnings.append(f"Query required {error_retries} retry attempt(s) due to errors")
#     if not warnings:
#         warnings = None

#     return {
#         "sql": sql_executed,
#         "raw_result": raw_result,
#         "response": response,
#         "explanation": explanation,
#         "summary": summary,
#         "data": data,
#         "columns": columns,
#         "row_count": row_count,
#         "confidence": confidence,
#         "warnings": warnings,
#         "optimizations": optimizations,
#     }


# # ---------------------------------------------------------------------------
# # Programmatic Agent Invocation (for tools, subagents, workflows)
# # ---------------------------------------------------------------------------


# def invoke_convobi_agent(
#     question: str,
#     connection_string: Optional[str] = None,
#     session_id: Optional[str] = None,
#     max_results: Optional[int] = None,
#     user_id: Optional[str] = None,
# ) -> Dict[str, Any]:
#     """
#     Invoke the Convi BI LangGraph agent programmatically.

#     This is the primary integration point for:
#     - AgentTools/convobi/service.py (ConvoBIService)
#     - Echo Agent subagent calls
#     - Workflow nodes that need NLP-to-SQL

#     Args:
#         question: Natural-language question.
#         connection_string: SQLAlchemy connection string. Falls back to
#             the currently active connection.
#         session_id: Session / thread ID for memory continuity.
#         max_results: Optional row limit hint appended to the question.
#         user_id: Authenticated user UUID for per-user LLM resolution.

#     Returns:
#         Dict with keys compatible with InvokeResponse / QueryResponse fields.
#     """
#     try:
#         llm = _get_convobi_llm(user_id)
#     except Exception as exc:
#         LOG.warning("LLM resolution failed for user=%s: %s", user_id, exc)
#         return {"success": False, "error": "LLM not configured for Convobi agent"}

#     cs = connection_string or app_state.get("active_connection_string") or ""
#     if not cs:
#         return {"success": False, "error": "No database connection string available"}

#     dialect = _dialect_from_connection_string(cs)
#     sid = session_id or str(uuid.uuid4())
#     start_ms = time.time() * 1000

#     LOG.info("[ConvoBI] Invoking agent: question='%s' session=%s", question[:100], sid)

#     try:
#         db_instance = SQLDatabase.from_uri(
#             cs,
#             sample_rows_in_table_info=3,
#             max_string_length=100,
#         )
#     except Exception as e:
#         return {"success": False, "error": f"Cannot connect to database: {e}"}

#     try:
#         tables = get_schema_info(db_instance)
#         schema_hint = _format_schema_hint_for_question(tables, question)
#         checkpointer = app_state.get("checkpointer") or _build_checkpointer()
#         agent = build_agent(
#             llm, db_instance, dialect,
#             glossary_hint="",
#             checkpointer=checkpointer,
#         )

#         limit_hint = f" (return at most {max_results} rows)" if max_results and max_results > 0 else ""
#         user_msg = f"{schema_hint}\n\nQuestion: {question}{limit_hint}" if schema_hint else f"{question}{limit_hint}"

#         config = {"configurable": {"thread_id": sid}}
#         result = agent.invoke(
#             {"messages": [HumanMessage(content=user_msg)]},
#             config,
#         )

#         elapsed_ms = time.time() * 1000 - start_ms
#         parsed = _parse_agent_results(result["messages"], db_instance, question)

#         viz_html = None
#         if parsed["columns"] and parsed["data"]:
#             viz_html = build_plotly_html(
#                 parsed["columns"], parsed["data"], question,
#             )

#         # Tables used — sample data (only relevant columns) from tables in the SQL
#         tables_used = _extract_tables_used(
#             parsed["sql"], db_instance,
#             result_columns=parsed.get("columns"),
#             sample_rows=5,
#         )

#         # Agent steps (only when verbose)
#         steps = _extract_agent_steps(result["messages"]) if CONVOBI_AGENT_VERBOSE else None

#         success = parsed.get("data") is not None or parsed.get("explanation") is not None

#         LOG.info(
#             "[ConvoBI] Agent completed: success=%s rows=%s sql_found=%s elapsed=%.0fms",
#             success,
#             parsed.get("row_count"),
#             bool(parsed.get("sql")),
#             elapsed_ms,
#         )

#         return {
#             "success": success,
#             "response": parsed.get("response") or "",
#             "sql": parsed["sql"],
#             "explanation": parsed["explanation"],
#             "summary": parsed["summary"],
#             "data": parsed["data"],
#             "columns": parsed["columns"],
#             "row_count": parsed["row_count"],
#             "confidence": parsed["confidence"],
#             "warnings": parsed["warnings"],
#             "optimizations": parsed["optimizations"],
#             "execution_time_ms": elapsed_ms,
#             "visualization_html": viz_html,
#             "tables_used": tables_used,
#             "session_id": sid,
#             "agent_steps": steps,
#             "error": None if success else parsed.get("raw_result"),
#         }

#     except Exception as e:
#         LOG.exception("invoke_convobi_agent failed")
#         return {"success": False, "error": str(e)}


# # ---------------------------------------------------------------------------
# # Connection & Schema helpers
# # ---------------------------------------------------------------------------


# def _dialect_from_connection_string(cs: str) -> str:
#     cs_lower = (cs or "").strip().lower()
#     if cs_lower.startswith("sqlite"):
#         return "sqlite"
#     if "postgres" in cs_lower:
#         return "postgres"
#     if "mysql" in cs_lower:
#         return "mysql"
#     if "mssql" in cs_lower or "pyodbc" in cs_lower or "pymssql" in cs_lower:
#         return "mssql"
#     if "oracle" in cs_lower:
#         return "oracle"
#     return "sqlite"


# def _normalize_connection_string(cs: str) -> str:
#     cs = (cs or "").strip()
#     if not cs:
#         return cs
#     lower = cs.lower()
#     # LangChain SQLDatabase uses sync engine; async drivers (asyncpg) cause greenlet errors
#     if "+asyncpg" in lower:
#         cs = cs.replace("+asyncpg", "+psycopg2")
#     if lower.startswith("sqlite:"):
#         path = cs[7:].lstrip("/")
#         if path == ":memory:" or not path:
#             return "sqlite://"
#         if not os.path.isabs(path) and "://" not in path:
#             path = os.path.abspath(path)
#         return "sqlite:///" + path.replace("\\", "/")
#     return cs


# def compute_db_id(connection_string: str, dialect: str) -> str:
#     raw = f"{dialect}:{connection_string}"
#     return hashlib.sha256(raw.encode()).hexdigest()[:16]


# def _get_db_path_for_file_id(file_id: str) -> Optional[str]:
#     """Get db_path from registry. Handles both legacy (str) and new (dict) formats."""
#     registry = app_state.get("file_id_registry") or {}
#     entry = registry.get(file_id)
#     if entry is None:
#         return None
#     if isinstance(entry, dict):
#         return entry.get("db_path")
#     return str(entry)


# def _load_file_id_registry_from_disk() -> None:
#     """Load file_id_registry from disk so it survives server restarts."""
#     path = Path(UPLOADS_DIR) / "file_id_registry.json"
#     if path.exists():
#         try:
#             with open(path, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#             app_state["file_id_registry"] = data.get("registry", {})
#         except Exception as e:
#             LOG.warning("Could not load file_id_registry: %s", e)


# def _save_file_id_registry_to_disk() -> None:
#     """Persist file_id_registry to disk."""
#     path = Path(UPLOADS_DIR) / "file_id_registry.json"
#     try:
#         path.parent.mkdir(parents=True, exist_ok=True)
#         with open(path, "w", encoding="utf-8") as f:
#             json.dump({"registry": app_state.get("file_id_registry", {})}, f, indent=2)
#     except Exception as e:
#         LOG.warning("Could not save file_id_registry: %s", e)


# def get_file_upload_info(file_id: str) -> Optional[Dict[str, Any]]:
#     """Get upload info for file_id. Returns {db_path, original_path, format, sheets} or None.
#     format is 'csv' or 'xlsx'. sheets is list of {sheet_name, table_name} for xlsx."""
#     registry = app_state.get("file_id_registry") or {}
#     entry = registry.get(file_id)
#     if entry is None:
#         return None
#     if isinstance(entry, dict):
#         return entry
#     return {"db_path": str(entry), "original_path": None, "format": None, "sheets": []}


# def get_connection_string_for_file_id(file_id: str) -> Optional[str]:
#     db_path = _get_db_path_for_file_id(file_id)
#     if not db_path:
#         return None
#     return f"sqlite:///{db_path}"


# def get_saved_connection_string(connection_id: str) -> Optional[str]:
#     inline = app_state.get("inline_connections") or {}
#     if connection_id in inline:
#         return inline[connection_id]
#     try:
#         from apps.connector.db_connector import _get_pg_engine
#         engine = _get_pg_engine()
#         with engine.connect() as conn:
#             row = conn.execute(
#                 text("SELECT connection_string FROM db_connections WHERE id = :id"),
#                 {"id": connection_id},
#             ).fetchone()
#             if row:
#                 return row[0]
#     except Exception:
#         pass
#     return None


# def _resolve_connection_string(
#     connection_id: Optional[str] = None,
#     file_id: Optional[str] = None,
# ) -> Optional[str]:
#     """Resolve a connection_id or file_id to a connection string."""
#     if file_id:
#         return get_connection_string_for_file_id(file_id)
#     if connection_id:
#         return get_saved_connection_string(connection_id)
#     return app_state.get("active_connection_string")


# def user_has_write_access(
#     connection_id: Optional[str],
#     file_id: Optional[str],
#     user_id: str,
#     email: str,
# ) -> bool:
#     if file_id and (user_id or email):
#         return True
#     if not connection_id:
#         return False
#     path = Path(DB_WRITE_ACCESS_FILE)
#     if path.exists():
#         try:
#             with open(path, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#             entry = data.get("connections", {}).get(connection_id, {})
#             if user_id and user_id in entry.get("user_ids", []):
#                 return True
#             if email and email in entry.get("emails", []):
#                 return True
#         except Exception:
#             pass
#     return False


# def execute_ddl(ddl: str) -> Tuple[bool, Optional[str], Optional[int]]:
#     cs = app_state.get("active_connection_string")
#     if not cs:
#         return False, "No active database connection", None
#     try:
#         engine = create_engine(cs)
#         with engine.connect() as conn:
#             result = conn.execute(text(ddl))
#             conn.commit()
#             return True, None, result.rowcount
#     except Exception as e:
#         return False, str(e), None


# def export_sqlite_to_csv_excel(
#     db_path: str,
#     output_path: str,
#     format_type: str,
#     sheets: Optional[List[Dict[str, str]]] = None,
#     schema_metadata: Optional[Dict[str, Dict[str, Dict[str, Any]]]] = None,
# ) -> bool:
#     """
#     Export SQLite data back to the uploaded CSV or Excel file.
#     Overwrites the file at output_path with the modified data (new column names, types, etc.).
#     format_type: 'csv' or 'xlsx'
#     sheets: for xlsx, list of {sheet_name, table_name}. If None, uses single table.
#     schema_metadata: {table: {column: {name: "new_name", ...}}} to apply column renames during export.
#     """
#     try:
#         abs_db = Path(db_path).resolve()
#         abs_out = Path(output_path).resolve()
#         abs_out.parent.mkdir(parents=True, exist_ok=True)
#         # SQLite URL: use forward slashes for Windows compatibility
#         sqlite_url = f"sqlite:///{str(abs_db).replace(chr(92), '/')}"
#         engine = create_engine(sqlite_url)
#         meta = schema_metadata or {}

#         def _apply_column_renames(df: pd.DataFrame, table: str) -> pd.DataFrame:
#             """Rename columns based on schema_metadata. Handles both DDL-renamed and metadata-only renames."""
#             tbl_meta = meta.get(table, {})
#             renames = {}
#             for col in df.columns:
#                 output_name = None
#                 override = tbl_meta.get(col) or tbl_meta.get(col.upper())
#                 if override and override.get("name"):
#                     output_name = str(override["name"]).strip()
#                 else:
#                     for meta_col, meta_val in tbl_meta.items():
#                         if meta_val.get("original_name") == col:
#                             output_name = str(meta_val.get("name", meta_col)).strip()
#                             break
#                 if output_name and output_name != col:
#                     renames[col] = output_name
#             return df.rename(columns=renames) if renames else df

#         with engine.connect() as conn:
#             if format_type == "csv":
#                 tables = inspect(engine).get_table_names()
#                 if not tables:
#                     return False
#                 df = pd.read_sql_table(tables[0], conn)
#                 df = _apply_column_renames(df, tables[0])
#                 df.to_csv(abs_out, index=False, encoding="utf-8")
#             elif format_type == "xlsx":
#                 with pd.ExcelWriter(abs_out, engine="openpyxl") as writer:
#                     if sheets:
#                         for s in sheets:
#                             tbl = s.get("table_name")
#                             sh = s.get("sheet_name", tbl)
#                             if tbl:
#                                 df = pd.read_sql_table(tbl, conn)
#                                 df = _apply_column_renames(df, tbl)
#                                 df.to_excel(writer, sheet_name=sh[:31], index=False)
#                     else:
#                         tables = inspect(engine).get_table_names()
#                         for t in tables:
#                             df = pd.read_sql_table(t, conn)
#                             df = _apply_column_renames(df, t)
#                             df.to_excel(writer, sheet_name=t[:31], index=False)
#             else:
#                 return False
#         LOG.info("Exported to %s (%s)", abs_out, format_type)
#         return True
#     except Exception as e:
#         LOG.warning("Export to %s failed: %s", format_type, e)
#         return False


# def generate_ddl_for_schema_edit(
#     table: str,
#     column: str,
#     current_col: Dict[str, Any],
#     new_name: Optional[str],
#     new_type: Optional[str],
#     new_nullable: Optional[bool],
#     new_primary_key: Optional[bool],
#     new_foreign_key: Optional[str],
#     dialect: str,
# ) -> List[str]:
#     """
#     Generate DDL statements to apply schema changes to the database.
#     Returns list of SQL statements (may be empty if no DB changes needed).
#     """
#     ddl_list: List[str] = []
#     d = (dialect or "sqlite").lower()
#     q = lambda x: _quote_identifier(str(x), d)
#     qt = lambda x: _quote_table_for_sql(str(x), d)

#     curr_name = current_col.get("name") or column
#     curr_type = str(current_col.get("type", ""))
#     curr_nullable = current_col.get("nullable", True)
#     curr_pk = current_col.get("primary_key", False)
#     curr_fk = current_col.get("foreign_key")

#     # Effective new values (only apply if different)
#     name_changed = new_name and str(new_name).strip() and str(new_name).strip() != curr_name
#     type_changed = new_type and str(new_type).strip() and str(new_type).strip().upper() != str(curr_type).upper()
#     nullable_changed = new_nullable is not None and new_nullable != curr_nullable
#     pk_changed = new_primary_key is not None and new_primary_key != curr_pk
#     fk_changed = (new_foreign_key is not None and str(new_foreign_key).strip() != str(curr_fk or "").strip())

#     if d == "sqlite":
#         # SQLite: only RENAME COLUMN is straightforward (3.25.0+)
#         if name_changed:
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} RENAME COLUMN {q(curr_name)} TO {q(str(new_name).strip())}'
#             )
#         # Type, nullable, PK, FK in SQLite require table recreation - skip for now
#         # (would need CREATE TABLE new AS SELECT, DROP old, RENAME)

#     elif d in ("postgresql", "postgres"):
#         # 1. Rename
#         if name_changed:
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} RENAME COLUMN {q(curr_name)} TO {q(str(new_name).strip())}'
#             )
#             curr_name = str(new_name).strip()

#         # 2. Type
#         if type_changed:
#             new_type_str = str(new_type).strip()
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} TYPE {new_type_str}'
#             )

#         # 3. Nullable
#         if nullable_changed:
#             if new_nullable:
#                 ddl_list.append(f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} DROP NOT NULL')
#             else:
#                 ddl_list.append(f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} SET NOT NULL')

#         # 4. Primary key (drop old, add new)
#         if pk_changed:
#             pk_name = f"{table}_pkey"
#             ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT IF EXISTS {q(pk_name)}')
#             if new_primary_key:
#                 ddl_list.append(f'ALTER TABLE {qt(table)} ADD PRIMARY KEY ({q(curr_name)})')

#         # 5. Foreign key (PostgreSQL default: table_column_fkey)
#         if fk_changed:
#             fk_name = f"{table}_{curr_name}_fkey"
#             ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT IF EXISTS {q(fk_name)}')
#             if new_foreign_key and str(new_foreign_key).strip():
#                 ref = str(new_foreign_key).strip()
#                 if "." in ref:
#                     ref_tbl, ref_col = ref.split(".", 1)
#                     fk_constraint_name = f"fk_{table}_{curr_name}"
#                     ddl_list.append(
#                         f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(fk_constraint_name)} '
#                         f'FOREIGN KEY ({q(curr_name)}) REFERENCES {qt(ref_tbl)} ({q(ref_col)})'
#                     )

#     elif d in ("mysql", "mariadb"):
#         # Use CHANGE COLUMN for MySQL 5.7+ compatibility (RENAME COLUMN is 8.0.3+ only)
#         if name_changed:
#             new_type_str = str(new_type).strip() if new_type else curr_type
#             null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} CHANGE COLUMN {q(curr_name)} {q(str(new_name).strip())} '
#                 f'{new_type_str} {null_part}'
#             )
#             curr_name = str(new_name).strip()

#         if (type_changed or nullable_changed) and not name_changed:
#             new_type_str = str(new_type).strip() if new_type else curr_type
#             null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} MODIFY COLUMN {q(curr_name)} {new_type_str} {null_part}'
#             )

#         if pk_changed:
#             ddl_list.append(f'ALTER TABLE {qt(table)} DROP PRIMARY KEY')
#             if new_primary_key:
#                 ddl_list.append(f'ALTER TABLE {qt(table)} ADD PRIMARY KEY ({q(curr_name)})')

#         if fk_changed and new_foreign_key and str(new_foreign_key).strip():
#             fk_name = f"fk_{table}_{curr_name}"
#             ref = str(new_foreign_key).strip()
#             if "." in ref:
#                 ref_tbl, ref_col = ref.split(".", 1)
#                 ddl_list.append(
#                     f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(fk_name)} '
#                     f'FOREIGN KEY ({q(curr_name)}) REFERENCES {qt(ref_tbl)} ({q(ref_col)})'
#                 )

#     elif d in ("mssql", "pyodbc"):
#         if name_changed:
#             ddl_list.append(
#                 f'EXEC sp_rename \'{table}.{curr_name}\', \'{str(new_name).strip()}\', \'COLUMN\''
#             )
#             curr_name = str(new_name).strip()

#         if type_changed or nullable_changed:
#             new_type_str = str(new_type).strip() if new_type else curr_type
#             null_part = "NULL" if (new_nullable if new_nullable is not None else curr_nullable) else "NOT NULL"
#             ddl_list.append(
#                 f'ALTER TABLE {qt(table)} ALTER COLUMN {q(curr_name)} {new_type_str} {null_part}'
#             )

#         if pk_changed:
#             pk_name = f"PK_{table}"
#             ddl_list.append(f'ALTER TABLE {qt(table)} DROP CONSTRAINT {q(pk_name)}')
#             if new_primary_key:
#                 ddl_list.append(f'ALTER TABLE {qt(table)} ADD CONSTRAINT {q(pk_name)} PRIMARY KEY ({q(curr_name)})')

#     return ddl_list


# def activate_connection(
#     connection_string: str,
#     connection_id: Optional[str] = None,
# ) -> Dict[str, Any]:
#     """Activate a database connection - create SQLDatabase + rebuild agent."""
#     global CURRENT_DIALECT, CURRENT_CONNECTOR
#     cs = _normalize_connection_string(connection_string)
#     dialect = _dialect_from_connection_string(cs)
#     CURRENT_DIALECT = dialect
#     CURRENT_CONNECTOR = "sql"

#     try:
#         db_instance = SQLDatabase.from_uri(
#             cs,
#             sample_rows_in_table_info=3,
#             max_string_length=100,
#         )
#     except Exception as e:
#         raise RuntimeError(f"Cannot connect to database: {e}")

#     app_state["db"] = db_instance
#     app_state["active_connection_string"] = cs
#     app_state["active_connection_id"] = connection_id
#     app_state["db_id"] = compute_db_id(cs, dialect)

#     try:
#         llm = _get_convobi_llm()
#         checkpointer = app_state.get("checkpointer") or _build_checkpointer()
#         app_state["agent"] = build_agent(
#             llm, db_instance, dialect,
#             glossary_hint="",
#             checkpointer=checkpointer,
#         )
#     except Exception:
#         LOG.warning("LLM not available during activate_connection; agent not built.")

#     table_names = db_instance.get_usable_table_names()
#     app_state["conversation_history"] = []

#     return {
#         "ok": True,
#         "dialect": dialect,
#         "connector": "sql",
#         "tables_loaded": len(table_names),
#         "tables": list(table_names),
#     }


# def ensure_connection_active() -> None:
#     """Make sure we have an active SQLDatabase; try DEFAULT_DB_URL if needed."""
#     if app_state.get("db") is not None:
#         return
#     cs = DEFAULT_DB_URL
#     if cs:
#         activate_connection(cs)


# # ---------------------------------------------------------------------------
# # Schema helpers (using SQLDatabase metadata)
# # ---------------------------------------------------------------------------


# def _quote_identifier(name: str, dialect: str) -> str:
#     """Quote identifier for raw SQL. MSSQL uses [name], others use "name"."""
#     if (dialect or "").lower() in ("mssql", "pyodbc"):
#         # MSSQL: square brackets; escape ] as ]]
#         escaped = str(name).replace("]", "]]")
#         return f"[{escaped}]"
#     return f'"{name}"'


# def _quote_table_for_sql(tname: str, dialect: str) -> str:
#     """Quote table name for raw SQL. Handles schema.table for MSSQL."""
#     if (dialect or "").lower() in ("mssql", "pyodbc"):
#         # MSSQL: [schema].[table] if dot present, else [table]
#         parts = str(tname).split(".", 1)
#         return ".".join(_quote_identifier(p, dialect) for p in parts)
#     return f'"{tname}"'


# def _get_dialect_for_schema(engine: Any) -> str:
#     """Detect dialect for schema queries. MSSQL needs TOP/brackets; fallback to URL if needed."""
#     dialect = (getattr(engine.dialect, "name", None) or "").lower()
#     if dialect in ("mssql", "pyodbc"):
#         return dialect
#     # Fallback: check connection URL (e.g. mssql+pyodbc)
#     try:
#         url_str = str(getattr(engine, "url", ""))
#         if "mssql" in url_str.lower() or "pyodbc" in url_str.lower():
#             return "mssql"
#     except Exception:
#         pass
#     return dialect or "sqlite"


# def get_schema_info(db_instance: SQLDatabase) -> Dict[str, Any]:
#     """Build schema info dict from SQLDatabase for API responses."""
#     tables: Dict[str, Any] = {}
#     table_names = db_instance.get_usable_table_names()
#     engine = db_instance._engine
#     dialect_name = _get_dialect_for_schema(engine)

#     insp = inspect(engine)
#     for tname in sorted(table_names):
#         cols_info: List[Dict[str, Any]] = []
#         try:
#             # MSSQL: split schema.table for inspector calls
#             schema_name, table_name = None, tname
#             if dialect_name in ("mssql", "pyodbc") and "." in str(tname):
#                 parts = str(tname).split(".", 1)
#                 schema_name, table_name = parts[0], parts[1]
#             db_columns = insp.get_columns(table_name, schema=schema_name)
#             pk_constraint = insp.get_pk_constraint(table_name, schema=schema_name) or {}
#             pk_cols = pk_constraint.get("constrained_columns", [])
#             fks = insp.get_foreign_keys(table_name, schema=schema_name)
#             fk_map: Dict[str, str] = {}
#             for fk in fks:
#                 for col in fk.get("constrained_columns", []):
#                     ref = (
#                         f"{fk.get('referred_table', '')}."
#                         f"{','.join(fk.get('referred_columns', []))}"
#                     )
#                     fk_map[col] = ref

#             quoted_table = _quote_table_for_sql(tname, dialect_name)
#             row_count: Optional[int] = None
#             try:
#                 with engine.connect() as conn:
#                     rc = conn.execute(text(f"SELECT COUNT(*) FROM {quoted_table}")).scalar()
#                     row_count = int(rc) if rc is not None else None
#             except Exception:
#                 pass

#             col_examples: Dict[str, List[str]] = {}
#             try:
#                 with engine.connect() as conn:
#                     for c in db_columns:
#                         cname = c["name"]
#                         try:
#                             quoted_col = _quote_identifier(cname, dialect_name)
#                             # MSSQL uses TOP N, not LIMIT; Oracle uses ROWNUM
#                             if dialect_name in ("mssql", "pyodbc"):
#                                 # MSSQL: DISTINCT must come before TOP
#                                 distinct_sql = (
#                                     f"SELECT DISTINCT TOP 50 {quoted_col} FROM {quoted_table} "
#                                     f"WHERE {quoted_col} IS NOT NULL"
#                                 )
#                             elif dialect_name == "oracle":
#                                 distinct_sql = (
#                                     f"SELECT DISTINCT {quoted_col} FROM {quoted_table} "
#                                     f"WHERE {quoted_col} IS NOT NULL AND ROWNUM <= 50"
#                                 )
#                             else:
#                                 distinct_sql = (
#                                     f'SELECT DISTINCT "{cname}" FROM "{tname}" '
#                                     f'WHERE "{cname}" IS NOT NULL LIMIT 50'
#                                 )
#                             rows = conn.execute(text(distinct_sql)).fetchall()
#                             col_examples[cname] = [str(r[0]) for r in rows]
#                         except Exception as e:
#                             LOG.warning(
#                                 "Distinct values failed for %s.%s (dialect=%s): %s",
#                                 tname, cname, dialect_name, e,
#                             )
#                             col_examples[cname] = []
#             except Exception as e:
#                 LOG.warning("Column examples fetch failed for %s (dialect=%s): %s", tname, dialect_name, e)

#             for c in db_columns:
#                 cname = c["name"]
#                 gloss = get_column_glossary_description(cname)
#                 examples = col_examples.get(cname, [])
#                 cols_info.append({
#                     "name": cname,
#                     "type": str(c.get("type", "unknown")),
#                     "nullable": c.get("nullable", True),
#                     "primary_key": cname in pk_cols,
#                     "foreign_key": fk_map.get(cname),
#                     "meaning": gloss or None,
#                     "description": gloss or None,
#                     "confidence": 0.8 if gloss else None,
#                     "source": "glossary" if gloss else None,
#                     "examples": examples,
#                     "example_values": ", ".join(examples[:10]) if examples else None,
#                 })

#             relationships: List[str] = []
#             for fk in fks:
#                 ref_table = fk.get("referred_table", "")
#                 ref_cols = fk.get("referred_columns", [])
#                 src_cols = fk.get("constrained_columns", [])
#                 if ref_table and src_cols:
#                     relationships.append(
#                         f"{','.join(src_cols)} -> "
#                         f"{ref_table}.{','.join(ref_cols)}"
#                     )

#             tables[tname] = {
#                 "name": tname,
#                 "row_count": row_count,
#                 "columns": cols_info,
#                 "relationships": relationships,
#             }
#         except Exception as e:
#             LOG.warning("Error inspecting table %s: %s", tname, e)
#             tables[tname] = {
#                 "name": tname,
#                 "row_count": None,
#                 "columns": [],
#                 "relationships": [],
#             }

#     return tables


# # Paths for glossary JSON (enriched with DB examples)
# _GLOSSARY_JSON_PATH = Path(__file__).parent / "column_glossary.json"
# _ITSM_GLOSSARY_JSON_PATH = Path(__file__).parent / "itsm_column_glossary.json"

# # Max examples per column in glossary description; each value truncated to this many chars
# _GLOSSARY_MAX_EXAMPLES = 30
# _GLOSSARY_MAX_VALUE_LEN = 60


# def _get_glossary_json_path() -> Path:
#     """Return the JSON path for the active connection's glossary."""
#     return _ITSM_GLOSSARY_JSON_PATH if _is_itsm_connection() else _GLOSSARY_JSON_PATH


# def get_glossary_path_for_file_id(file_id: str) -> Optional[Path]:
#     """Return the glossary JSON path for an uploaded file. Creates dir if needed."""
#     db_path = _get_db_path_for_file_id(file_id)
#     if not db_path:
#         return None
#     glossary_path = Path(db_path).with_suffix(".glossary.json")
#     glossary_path.parent.mkdir(parents=True, exist_ok=True)
#     return glossary_path


# def get_schema_metadata_path_for_file_id(file_id: str) -> Optional[Path]:
#     """Return the schema metadata JSON path for an uploaded file (nullable, PK, FK, type, name overrides)."""
#     db_path = _get_db_path_for_file_id(file_id)
#     if not db_path:
#         return None
#     meta_path = Path(db_path).with_suffix(".schema_metadata.json")
#     meta_path.parent.mkdir(parents=True, exist_ok=True)
#     return meta_path


# def get_glossary_path_for_connection_id(connection_id: str) -> Path:
#     """Return the glossary JSON path for a DB connection (small SQLite/other DBs)."""
#     safe_id = re.sub(r"[^a-zA-Z0-9_-]", "_", connection_id or "")[:64] or "default"
#     base = CONVOBI_SCHEMA_CACHE_DIR / safe_id
#     base.mkdir(parents=True, exist_ok=True)
#     return base / "glossary.json"


# def get_schema_metadata_path_for_connection_id(connection_id: str) -> Path:
#     """Return the schema metadata JSON path for a DB connection (small SQLite/other DBs)."""
#     safe_id = re.sub(r"[^a-zA-Z0-9_-]", "_", connection_id or "")[:64] or "default"
#     base = CONVOBI_SCHEMA_CACHE_DIR / safe_id
#     base.mkdir(parents=True, exist_ok=True)
#     return base / "schema_metadata.json"


# def load_schema_metadata_for_file(file_id: str) -> Dict[str, Dict[str, Dict[str, Any]]]:
#     """Load schema metadata overrides for an uploaded file. Returns {table: {column: {nullable, primary_key, ...}}}."""
#     path = get_schema_metadata_path_for_file_id(file_id)
#     if not path or not path.exists():
#         return {}
#     try:
#         with open(path, "r", encoding="utf-8") as f:
#             data = json.load(f)
#         return data.get("tables", {})
#     except Exception:
#         return {}


# def load_schema_metadata_for_connection(connection_id: str) -> Dict[str, Dict[str, Dict[str, Any]]]:
#     """Load schema metadata overrides for a DB connection. Returns {table: {column: {nullable, primary_key, ...}}}."""
#     path = get_schema_metadata_path_for_connection_id(connection_id)
#     if not path.exists():
#         return {}
#     try:
#         with open(path, "r", encoding="utf-8") as f:
#             data = json.load(f)
#         return data.get("tables", {})
#     except Exception:
#         return {}


# def update_schema_column_metadata(
#     file_id: Optional[str] = None,
#     connection_id: Optional[str] = None,
#     table: str = "",
#     column: str = "",
#     nullable: Optional[bool] = None,
#     primary_key: Optional[bool] = None,
#     foreign_key: Optional[str] = None,
#     type_: Optional[str] = None,
#     name: Optional[str] = None,
#     meaning: Optional[str] = None,
#     description: Optional[str] = None,
#     remove_old_column: Optional[str] = None,
#     original_name: Optional[str] = None,
# ) -> None:
#     """Update schema metadata for a column. Provide file_id OR connection_id. Only provided fields are updated.
#     If remove_old_column is set (e.g. when renaming), remove that key before updating."""
#     if file_id:
#         path = get_schema_metadata_path_for_file_id(file_id)
#     elif connection_id:
#         path = get_schema_metadata_path_for_connection_id(connection_id)
#     else:
#         return
#     if not path:
#         return
#     data: Dict[str, Any] = {"tables": {}}
#     if path.exists():
#         try:
#             with open(path, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#             if "tables" not in data:
#                 data["tables"] = {}
#         except Exception:
#             data["tables"] = {}
#     if table not in data["tables"]:
#         data["tables"][table] = {}
#     if remove_old_column and remove_old_column in data["tables"][table]:
#         del data["tables"][table][remove_old_column]
#     if column not in data["tables"][table]:
#         data["tables"][table][column] = {}
#     entry = data["tables"][table][column]
#     if nullable is not None:
#         entry["nullable"] = nullable
#     if primary_key is not None:
#         entry["primary_key"] = primary_key
#     if foreign_key is not None:
#         entry["foreign_key"] = foreign_key if str(foreign_key).strip() else None
#     if type_ is not None:
#         entry["type"] = str(type_).strip() or entry.get("type")
#     if name is not None:
#         entry["name"] = str(name).strip() or column
#     if meaning is not None:
#         entry["meaning"] = str(meaning).strip() or None
#     if description is not None:
#         entry["description"] = str(description).strip() or None
#     if original_name is not None:
#         entry["original_name"] = str(original_name).strip() or None
#     path.parent.mkdir(parents=True, exist_ok=True)
#     with open(path, "w", encoding="utf-8") as f:
#         json.dump(data, f, indent=2, ensure_ascii=False)
#         f.flush()
#         os.fsync(f.fileno())


# def apply_schema_metadata_overrides(
#     tables: Dict[str, Any],
#     file_id: Optional[str] = None,
#     connection_id: Optional[str] = None,
# ) -> Dict[str, Any]:
#     """Apply schema metadata overrides to tables when file_id or connection_id is set. Returns merged tables."""
#     if file_id:
#         meta = load_schema_metadata_for_file(file_id)
#     elif connection_id:
#         meta = load_schema_metadata_for_connection(connection_id)
#     else:
#         return tables
#     if not meta:
#         return tables
#     result = dict(tables)
#     for tname, cols in result.items():
#         if tname not in meta:
#             continue
#         table_meta = meta[tname]
#         new_cols = []
#         for c in cols.get("columns", []):
#             cname = c.get("name", "")
#             override = table_meta.get(cname) or table_meta.get(cname.upper())
#             if not override:
#                 new_cols.append(c)
#                 continue
#             merged = dict(c)
#             if "nullable" in override:
#                 merged["nullable"] = override["nullable"]
#             if "primary_key" in override:
#                 merged["primary_key"] = override["primary_key"]
#             if "foreign_key" in override:
#                 merged["foreign_key"] = override["foreign_key"]
#             if "type" in override:
#                 merged["type"] = str(override["type"])
#             if "name" in override:
#                 merged["name"] = override["name"]
#             if "meaning" in override:
#                 merged["meaning"] = override["meaning"]
#             if "description" in override:
#                 merged["description"] = override["description"]
#             new_cols.append(merged)
#         result[tname] = {**cols, "columns": new_cols}
#     return result


# def _parse_glossary_value(val: str) -> Tuple[str, str]:
#     """Split glossary text into (semantic_part, examples_part). Examples part includes 'Examples: '."""
#     if not val or not isinstance(val, str):
#         return "", ""
#     s = val.strip()
#     # Look for " Examples: " (case-insensitive) to split
#     idx = s.upper().rfind(" EXAMPLES:")
#     if idx >= 0:
#         return s[:idx].strip(), s[idx:].strip()
#     return s, ""


# def update_glossary_column_description(
#     glossary_path: Path,
#     column_key: str,
#     new_meaning: Optional[str],
#     new_description: Optional[str],
#     remove_old_key: Optional[str] = None,
# ) -> None:
#     """
#     Update meaning/description in glossary JSON, preserving Examples part.
#     column_key: uppercase column name (e.g. SALESSTAGECODE).
#     If remove_old_key is set (e.g. when renaming), remove that key and use its value for the new key if new_description is empty.
#     """
#     data: Dict[str, str] = {}
#     if glossary_path.exists():
#         try:
#             with open(glossary_path, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#         except Exception:
#             pass
#     key = (column_key or "").strip().upper()
#     if not key:
#         return
#     existing = data.get(key, "")
#     if remove_old_key:
#         old_key = (remove_old_key or "").strip().upper()
#         if old_key and old_key in data:
#             if not existing:
#                 existing = data[old_key]
#             del data[old_key]
#     semantic, examples_part = _parse_glossary_value(existing)
#     meaning = (new_meaning or semantic).strip() or semantic
#     description = (new_description or meaning).strip() or meaning
#     combined = f"{description} {examples_part}".strip() if examples_part else description
#     data[key] = combined
#     glossary_path.parent.mkdir(parents=True, exist_ok=True)
#     with open(glossary_path, "w", encoding="utf-8") as f:
#         json.dump(data, f, indent=2, ensure_ascii=False)
#         f.flush()
#         os.fsync(f.fileno())


# def build_glossary_from_schema(tables: Dict[str, Any]) -> Dict[str, str]:
#     """
#     Build column glossary enriched with unique examples from the database.
#     Merges with existing COLUMN_GLOSSARY: keeps existing descriptions and appends
#     or updates the examples section with actual unique values from the DB.
#     Uses ITSM glossary when ITSM DB is active.
#     """
#     # Merge examples from all tables (column name -> set of unique values)
#     col_examples: Dict[str, set] = {}
#     for tname, tbl in tables.items():
#         for col in tbl.get("columns", []):
#             cname = col.get("name", "")
#             if not cname:
#                 continue
#             key = cname.strip().upper()
#             examples = col.get("examples", [])
#             if key not in col_examples:
#                 col_examples[key] = set()
#             for v in examples:
#                 if v is not None and str(v).strip():
#                     col_examples[key].add(str(v).strip())

#     result: Dict[str, str] = {}
#     existing = _get_column_glossary_dict()
#     # Prefer built-in descriptions for CRM Win/Loss columns
#     if not _is_itsm_connection() and column_glossary:
#         try:
#             existing = dict(existing)
#             for k in ("KPMG_STATUSREASON", "SALESSTAGECODE"):
#                 if hasattr(column_glossary, "_BUILTIN_GLOSSARY") and k in column_glossary._BUILTIN_GLOSSARY:
#                     existing[k] = column_glossary._BUILTIN_GLOSSARY[k]
#         except (ImportError, AttributeError):
#             pass

#     for key, values in col_examples.items():
#         sorted_vals = sorted(values, key=str)[:_GLOSSARY_MAX_EXAMPLES]
#         examples_str = ", ".join(str(v)[:_GLOSSARY_MAX_VALUE_LEN] for v in sorted_vals)

#         if key in existing:
#             desc = existing[key]
#             # If description already has examples (contains ": val1, val2"), replace that part
#             if ", " in desc and len(desc) > 80:
#                 # Keep the semantic part (before last ":" with comma-sep values)
#                 parts = desc.rsplit(":", 1)
#                 if len(parts) == 2 and ", " in parts[1] and len(parts[1]) > 20:
#                     desc = parts[0].strip()
#             if examples_str:
#                 result[key] = f"{desc} Examples: {examples_str}"
#             else:
#                 result[key] = desc
#             # Emphasize SALESSTAGECODE for Win/Loss when examples contain Win
#             if key == "SALESSTAGECODE" and any("win" in str(v).lower() for v in values):
#                 if "prefer over KPMG_STATUSREASON" not in result[key]:
#                     result[key] += " Use for win/loss filtering. Prefer over KPMG_STATUSREASON."
#         else:
#             # New column: humanize name and add examples
#             human = key.replace("_", " ").replace("  ", " ").strip()
#             if examples_str:
#                 result[key] = f"{human}. Examples: {examples_str}"
#             else:
#                 result[key] = human

#     # Preserve existing entries not in schema (e.g. ticket columns when only opportunities connected)
#     for key, desc in existing.items():
#         if key not in result:
#             result[key] = desc

#     return dict(sorted(result.items()))


# def refresh_glossary_from_db(db_instance: SQLDatabase) -> Dict[str, Any]:
#     """
#     Refresh column glossary from database schema and examples.
#     Writes to column_glossary.json (or itsm_column_glossary.json when ITSM DB) and updates the in-memory glossary.
#     Returns updated glossary and stats.
#     """
#     tables = get_schema_info(db_instance)
#     updated = build_glossary_from_schema(tables)
#     json_path = _get_glossary_json_path()
#     try:
#         with open(json_path, "w", encoding="utf-8") as f:
#             json.dump(updated, f, indent=2, ensure_ascii=False)
#         LOG.info("Glossary refreshed: %d columns written to %s", len(updated), json_path)
#     except Exception as e:
#         LOG.warning("Could not write glossary JSON: %s", e)
#         raise

#     # Update in-memory glossary so subsequent requests use new descriptions
#     mod = itsm_column_glossary if _is_itsm_connection() and itsm_column_glossary else column_glossary
#     if mod:
#         mod.COLUMN_GLOSSARY.clear()
#         mod.COLUMN_GLOSSARY.update(updated)

#     return {
#         "columns_updated": len(updated),
#         "path": str(json_path),
#     }


# def build_schema_summary(tables: Dict[str, Any]) -> str:
#     total = len(tables)
#     lines = [
#         "# Schema Summary",
#         "",
#         f"**Total Tables:** {total}",
#         "",
#         "## Tables",
#         "",
#     ]
#     if tables:
#         lines.append("| ID | Table | Rows | Columns |")
#         lines.append("|----|-------|------|---------|")
#         for idx, tn in enumerate(sorted(tables.keys())):
#             t = tables[tn]
#             rows = t.get("row_count") if t.get("row_count") is not None else "\u2014"
#             cols = len(t.get("columns") or [])
#             lines.append(f"| {idx} | {tn} | {rows} | {cols} |")
#     else:
#         lines.append("No tables loaded.")
#     return "\n".join(lines)


# # ---------------------------------------------------------------------------
# # Global App State
# # ---------------------------------------------------------------------------

# app_state: Dict[str, Any] = {
#     "db": None,                         # SQLDatabase instance
#     "agent": None,                      # compiled LangGraph agent
#     "checkpointer": None,               # MemorySaver or PostgresSaver
#     "llm": None,                        # reserved for runtime LLM reference
#     "active_connection_string": None,    # current connection string
#     "active_connection_id": None,        # current connection ID
#     "active_file_id": None,             # current uploaded file ID
#     "db_id": None,                      # hash of connection for caching
#     "conversation_history": [],          # last N query records
#     "file_id_registry": {},              # file_id -> db_path
#     "inline_connections": {},            # connection_id -> connection_string
# }


# # ---------------------------------------------------------------------------
# # Lifespan
# # ---------------------------------------------------------------------------


# @asynccontextmanager
# async def lifespan(app_instance: FastAPI):
#     global CURRENT_DIALECT, CURRENT_CONNECTOR

#     # LLM is now lazily resolved per-user via _get_convobi_llm()
#     app_state["llm"] = None
#     app_state["checkpointer"] = _build_checkpointer()
#     _load_file_id_registry_from_disk()

#     connection_string = os.getenv("DATABASE_URL")

#     if not connection_string:
#         CURRENT_DIALECT = "sqlite"
#         CURRENT_CONNECTOR = None
#         LOG.info("Application initialized without datasource.")
#         yield
#         LOG.info("Application shutdown complete")
#         return

#     try:
#         cs = _normalize_connection_string(connection_string)
#         # Run sync DB I/O in thread to avoid greenlet/async conflict in lifespan
#         result = await asyncio.to_thread(activate_connection, cs)
#         LOG.info(
#             "Application initialized (dialect=%s, tables=%s)",
#             CURRENT_DIALECT,
#             result.get("tables_loaded", 0),
#         )
#     except Exception as e:
#         LOG.error(
#             "Startup connection failed: %s. Running without datasource.", e,
#         )
#         CURRENT_DIALECT = "sqlite"
#         CURRENT_CONNECTOR = None

#     yield

#     LOG.info("Application shutdown complete")


# # ---------------------------------------------------------------------------
# # FastAPI App
# # ---------------------------------------------------------------------------

# app = FastAPI(
#     title="Convobi NLP Database Interface (LangGraph + SQLDatabaseToolkit)",
#     description="Natural language to SQL with LangGraph agent and session memory.",
#     version="2.0.0",
#     lifespan=lifespan,
# )
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# from .routes import router  # noqa: E402
# app.include_router(router)
