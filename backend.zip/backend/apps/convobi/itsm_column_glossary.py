# ITSM Column glossary — SummitAI / IT Service Management DB
# Run: python -m apps.convobi.sync_glossary_from_schema (with ITSM DB connected)
#
# Purpose: Definitive source for ITSM column names. Prevents hallucinated columns.
# If itsm_column_glossary.json exists (from POST /schema/glossary/refresh on ITSM DB), it overrides at runtime.

import json
from pathlib import Path

_GLOSSARY_JSON = Path(__file__).parent / "itsm_column_glossary.json"

_BUILTIN_GLOSSARY = {
    # Core identifiers
    "INCIDENTID": "Incident/ticket unique identifier. Use for incident counts and joins.",
    "INCIDENT_NUMBER": "Incident number; display or reference ID",
    "TICKET ID": "Unique ticket or incident identifier",
    "TICKET NO": "Ticket number; display or reference number",
    "TICKET_NUMBER": "Ticket number; display or reference",
    "REQUESTID": "Service request unique identifier",
    "REQUEST_ID": "Service request ID",
    "SR_NUMBER": "Service request number",
    "WORKORDERID": "Work order identifier",
    "WORKORDER ID": "Work order identifier",
    # Status & lifecycle
    "STATUS": "Current ticket/incident status (e.g. Open, In Progress, Resolved, Closed). Use for 'status' questions.",
    "STATUSID": "Status identifier/code",
    "STATUS_ID": "Status identifier",
    "PRIORITY": "Ticket priority (e.g. Critical, High, Medium, Low)",
    "PRIORITYID": "Priority identifier",
    "PRIORITY_ID": "Priority identifier",
    "PRIORITYNAME": "Priority display name",
    "SEVERITY": "Severity level (e.g. Critical, High, Medium, Low)",
    "SEVERITYID": "Severity identifier",
    "SEVERITY NAME": "Severity name (e.g. Critical, High, Medium, Low)",
    "SEVERITY DISPLAY": "Severity display label",
    "RESOLUTION STATUS": "Resolution status (e.g. Resolved, Pending)",
    "CLOSURE CODE": "Closure code or reason",
    "CLOSURE DATE": "Date when ticket was closed",
    "RESOLUTION CODE": "Resolution code or type",
    "RESOLUTION": "Resolution or solution text",
    "SOLUTION": "Resolution or solution text",
    # Dates & times
    "CREATEDDATE": "When the incident/ticket was created",
    "CREATED_DATE": "Record creation date/time",
    "CREATEDON": "Record creation date/time",
    "REGISTERED TIME": "When the ticket was registered or created",
    "UPDATED TIME": "When the ticket was last updated",
    "UPDATEDDATE": "When the record was last updated",
    "CLOSEDDATE": "Date when ticket was closed",
    "CLOSED_DATE": "Date when ticket was closed",
    "RESOLUTION TIME": "When the ticket was resolved",
    "RESPONSE TIME": "When the first response was made",
    "RESOLUTION DEADLINE": "Date/time by which resolution is due",
    "RESPONSE DEADLINE": "Date/time by which first response is due",
    "TARGET COMPLETION DATE": "Target date for completion",
    "SCHEDULE DATE": "Scheduled date for work",
    # SLA
    "SLA NAME": "SLA agreement name",
    "RESOLUTION SLA MET": "Whether resolution SLA was met",
    "RESPONSE SLA MET": "Whether response SLA was met",
    "RESOLUTION SLA MINS": "Resolution SLA in minutes",
    "RESPONSE SLA MINS": "Response SLA in minutes",
    "RESOLUTION SLA REASON": "Reason if resolution SLA was not met",
    "RESPONSE SLA REASON": "Reason when response SLA was not met",
    "RESPONSE PRIORITY NAME": "Ticket response priority/severity label (e.g. Severity-3)",
    "RESPONSE PRIORITY SLA": "Response priority SLA",
    # Assignment
    "ASSIGNEDTO": "User/group the ticket is assigned to",
    "ASSIGNED_TO": "Assigned user or group",
    "ASSIGNEDTOID": "Assigned user/group ID",
    "ASSIGNED GROUP": "Assigned group or workgroup name",
    "ASSIGNED GROUP ID": "Assigned group identifier",
    "WORKGROUP NAME": "Workgroup or team name",
    "WORKGROUP ASSIGNED TIME": "When workgroup was assigned",
    "ASSIGNED ENGINEER USERID": "Assigned engineer user ID",
    "ASSIGNED ENGINEER UNAME": "Assigned engineer user name",
    "ASSIGNED ENGINEER USER NAME": "Assigned engineer name. Use for 'who completed' — the analyst who did the work.",
    "ASSIGNED ENGINEER EMAIL": "Assigned engineer email",
    "ASSIGNED WORKGROUP ID": "Assigned workgroup identifier",
    "RESOLVED UPDATED BY USER NAME": "User who last updated the resolution text. May NOT be the analyst who completed the work; prefer ASSIGNED ENGINEER USER NAME for 'who completed'.",
    "RESOLVED UPDATED BY USERID": "User ID who last updated resolution",
    "RESOLVED UPDATED BY EMAILID": "Email of user who last updated resolution",
    # Caller / requester
    "CALLER USER NAME": "Caller user name",
    "CALLER USER ID": "Caller user ID",
    "CALLER EMAIL": "Caller email",
    "CALLER CONTACT": "Caller contact number",
    "CALLER MOBILE": "Caller mobile",
    "LOGGED BY USER NAME": "Name of person who logged the ticket",
    "LOGGED BY USER ID": "User ID of person who logged the ticket",
    "LOGGED BY EMAIL": "Email of person who logged",
    "REPORTER": "Person who reported the incident",
    "REPORTERID": "Reporter user ID",
    # Category & classification
    "CATEGORY": "Ticket category",
    "CATEGORY ID": "Category identifier",
    "CATEGORYID": "Category identifier",
    "SUBCATEGORY": "Ticket subcategory",
    "SUBCATEGORY ID": "Subcategory identifier",
    "CLASSIFICATION": "Ticket classification (e.g. type or category code)",
    "CLASSIFICATION ID": "Classification identifier",
    "SUP FUNCTION": "Support function code",
    "SUP FUNCTION NAME": "Support function name",
    # Description & content
    "DESCRIPTION": "Ticket description or summary",
    "TITLE": "Incident/ticket title or subject",
    "SUBJECT": "Ticket subject",
    "SUMMARY": "Brief summary of the incident",
    "DETAILS": "Detailed description",
    "TEMPLATE NAME": "Template name used for ticket",
    "TEMPLATE SYMPTOM": "Template symptom description",
    # Source & medium
    "SOURCE": "Source of the ticket (e.g. portal, email, phone)",
    "MEDIUM": "Channel or medium through which ticket was raised",
    "CHANNEL": "Channel (portal, email, phone, etc.)",
    # Impact & urgency
    "IMPACT": "Impact level or description",
    "IMPACT NAME": "Impact name or description",
    "IMPACTID": "Impact identifier",
    "URGENCY": "Urgency level",
    "URGENCYID": "Urgency identifier",
    # Customer / contact
    "CUSTOMER": "Customer name or identifier",
    "CUSTOMER ID": "Customer identifier",
    "CUSTOMERID": "Customer identifier",
    "CONTACT": "Contact person",
    "CONTACTID": "Contact identifier",
    "LOCATION": "Location name or code",
    "LOCATION ID": "Location identifier",
    "LOCATIONID": "Location identifier",
    # Device / asset
    "DEVICE HOST NAME": "Device host name",
    "HOSTNAME": "Host name",
    "IP ADDRESS": "IP address",
    "MAC ADDRESS": "MAC address",
    "SERIAL NO": "Serial number",
    "SERIAL NUMBER": "Serial number",
    "MODEL NO": "Model number",
    "ASSETID": "Asset identifier",
    "ASSET ID": "Asset identifier",
    # Escalation & follow-up
    "IS AUTO ESCALATED": "Whether ticket was auto-escalated",
    "IS MANUAL ESCALATED": "Whether ticket was manually escalated",
    "MANUAL ESCALATION DATE": "Date when manually escalated",
    "MANUAL ESCALATION REMARKS": "Remarks for manual escalation",
    "ESCALATION RESPONSED": "Whether escalation was responded to",
    "FOLLOWUP CALL COUNT": "Number of follow-up calls",
    "NO OF TIME REOPENED": "Number of times ticket was reopened",
    "REOPEN TICKET": "Whether ticket was reopened (flag or count)",
    # FCR (First Contact Resolution)
    "FCR MET": "Whether first contact resolution was met",
    "FCR TICKET": "First contact resolution ticket indicator",
    "FCR COMMENTS": "First contact resolution comments",
    # Pending & duration
    "PENDING REASON": "Reason ticket is pending",
    "TOTAL PENDING DURATION": "Total time ticket was in pending state",
    "TOTAL PENDING DURATION SLA MINUTES": "Total pending duration within SLA in minutes",
    "RESOLUTION ELAPSETIME": "Elapsed time to resolution",
    "RESPONSE ELAPSETIME": "Elapsed time to first response",
    "RESPONSE DEADLINEMINUTES": "Response deadline in minutes",
    "RESOLUTION DEADLINE MINUTES": "Resolution deadline in minutes",
    "NO OF DAYS": "Number of days (e.g. duration)",
    "NO OF HOURS": "Number of hours",
    "NO OF MINUTES": "Number of minutes",
    "AGEING": "Ageing (e.g. days open or age bucket)",
    # Other
    "TENANT ID": "Tenant identifier",
    "TENANTID": "Tenant identifier",
    "IS ATTACHMENTS AVAILABLE": "Whether attachments are available (yes/no)",
    "IS KB AVAILABLE": "Whether KB article is available",
    "TICKET CLOSING MODE": "Mode in which ticket was closed",
    "WORKORDER NAME": "Work order name",
    "CHILD INCIDENT COUNT": "Number of child incidents",
    "PARENT TICKET NO": "Parent ticket number",
    "PTICKET ID": "Parent or partner ticket ID",
    "FETCH_TIMESTAMP": "When the data was fetched or last synced from source system",
    "MODIFIEDON": "Record last modified date/time",
    "MODIFIEDBY": "User who last modified the record",
}


def _load_glossary() -> dict:
    """Load glossary from JSON if exists (DB-enriched), else use built-in ITSM glossary."""
    if _GLOSSARY_JSON.exists():
        try:
            with open(_GLOSSARY_JSON, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return _BUILTIN_GLOSSARY


COLUMN_GLOSSARY = _load_glossary()


def get_column_glossary_description(column_name: str) -> str:
    """Return glossary description for column if known, else empty string. Case-insensitive. Tries underscore/space variants."""
    if not column_name:
        return ""
    key = str(column_name).strip().upper()
    return COLUMN_GLOSSARY.get(key) or COLUMN_GLOSSARY.get(key.replace("_", " ")) or ""
