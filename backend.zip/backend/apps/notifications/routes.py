"""
Notification endpoints for the approval-queue feature.
"""

from fastapi import APIRouter, HTTPException
from fastapi.params import Depends
from uuid import UUID

from echolib.database import get_db_session
from echolib.security import require_user, resolve_user_id
from echolib.types import UserContext
from echolib.repositories.notification_repo import NotificationRepository

router = APIRouter(prefix="/api/notifications", tags=["notifications"])

_repo = NotificationRepository()


@router.get("")
async def list_notifications(
    user: UserContext = Depends(require_user),
):
    """List all notifications for the current user (newest first)."""
    user_id_str = resolve_user_id(user)
    async with get_db_session() as db:
        items = await _repo.list_all(db, user_id=user_id_str)
        return [
            {
                "notification_id": str(n.notification_id),
                "type": n.type,
                "title": n.title,
                "message": n.message,
                "reference_id": str(n.reference_id) if n.reference_id else None,
                "reference_type": n.reference_type,
                "is_read": n.is_read,
                "created_at": n.created_at.isoformat(),
            }
            for n in items
        ]


@router.get("/unread-count")
async def unread_count(
    user: UserContext = Depends(require_user),
):
    """Return the number of unread notifications."""
    user_id_str = resolve_user_id(user)
    async with get_db_session() as db:
        count = await _repo.count_unread(db, user_id=user_id_str)
        return {"count": count}


@router.post("/{notification_id}/read")
async def mark_read(
    notification_id: str,
    user: UserContext = Depends(require_user),
):
    """Mark a single notification as read."""
    user_id_str = resolve_user_id(user)
    async with get_db_session() as db:
        ok = await _repo.mark_read(db, notification_id=notification_id, user_id=user_id_str)
        if not ok:
            raise HTTPException(status_code=404, detail="Notification not found")
        await db.commit()
        return {"ok": True}


@router.post("/mark-all-read")
async def mark_all_read(
    user: UserContext = Depends(require_user),
):
    """Mark all notifications as read for the current user."""
    user_id_str = resolve_user_id(user)
    async with get_db_session() as db:
        count = await _repo.mark_all_read(db, user_id=user_id_str)
        await db.commit()
        return {"marked": count}
