"""
EchoAI Knowledge Base — Service Layer

Orchestrates all knowledge base operations:
- CRUD (create, list, get, update, delete)
- File storage and upload management
- Search (delegates to retriever module)
- Processing trigger (asyncio background tasks — no Celery/Redis needed)
- Stats aggregation

Uses LLMFactory for embeddings; all DB access goes through repositories.
"""

import asyncio
import logging
import os
import shutil
import uuid
from typing import Any, Dict, List, Optional

from fastapi import UploadFile

from echolib.credential_resolver import resolve_llm_credential_sync
from echolib.database import get_db_session
from echolib.llm_factory import LLMFactory
from echolib.repositories.knowledge_repo import (
    KnowledgeBaseRepository,
    KnowledgeDocumentRepository,
)
from apps.knowledge.schemas import (
    KnowledgeBaseCreate,
    KnowledgeBaseUpdate,
)
from apps.knowledge.vector_store import (
    KNOWLEDGE_STORAGE_DIR,
    _file_storage_dir,
    delete_faiss_index,
)
from apps.knowledge.graph_store import delete_graph_data, get_graph_stats
from apps.knowledge import retriever

logger = logging.getLogger(__name__)


class KnowledgeService:
    """
    Central service for knowledge base operations.

    Instantiated once and registered in the DI container.
    """

    def __init__(self, llm_factory: LLMFactory):
        self.llm_factory = llm_factory
        self.kb_repo = KnowledgeBaseRepository()
        self.doc_repo = KnowledgeDocumentRepository()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_credential_id(value: Optional[str]) -> bool:
        """Check if a value looks like a credential UUID (not a model name)."""
        if not value:
            return False
        try:
            uuid.UUID(value)
            return True
        except (ValueError, TypeError):
            return False

    def _get_embeddings(
        self,
        embedding_model: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        indexed_model: Optional[str] = None,
    ):
        """
        Get a LangChain Embeddings instance.

        Delegates to :mod:`apps.knowledge.embeddings`, which ingestion also
        uses. That shared module is the point: this function and the one in
        ``apps/knowledge/tasks.py`` were separate implementations that
        disagreed, so a base was indexed by one model and queried by another.

        The previous body ended in ``embedding_model or "embedding_text"``
        paired with the user's *chat* default credential, which meant a base
        with no configured model asked a chat deployment for embeddings and got
        404 DeploymentNotFound on every search. That constant is gone.

        Returns ``None`` when this user can reach no embedding model at all.
        Callers degrade to keyword search over the same passages rather than
        failing the turn, so a misconfigured base still answers from its text.

        **There is deliberately no Azure fallback here.** An earlier version
        ended in one, and it was the wrong answer twice over: ``resolve`` is
        documented never to raise, so the handler was unreachable; and a
        substituted embedding model embeds the *query* in a different vector
        space than the *passages* were indexed with, so the search returns
        plausible-looking nonsense rather than nothing. ``resolve``'s Tier 0
        exists precisely to prevent that mismatch, and falling back past it
        would reintroduce the defect it was written to close. Keyword search
        over the real passages is the honest degradation.
        """
        from apps.knowledge import embeddings as embedding_resolver

        return embedding_resolver.resolve(
            embedding_model,
            user_id,
            llm_factory=self.llm_factory,
            indexed_model=indexed_model,
        )

    def embeddings_for_knowledge_base(
        self,
        embedding_model: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        indexed_model: Optional[str] = None,
    ):
        """
        The embeddings client a knowledge base's index was built with.

        WHAT: Public surface over :meth:`_get_embeddings`.
        WHY:  A vector index is only searchable by the model that wrote it —
              embeddings from two different models are not interchangeable even
              at identical dimensions. Ingestion, the application pipeline and
              the agent's ``kb__<alias>`` tool now all resolve through the one
              module, so they cannot disagree about which model that is.
        OUTPUT: The client, or ``None`` when no embedding model can be resolved
                for this user. ``None`` is a real answer: vector search is
                unavailable and the caller falls back to keyword search over the
                same passages. It used to raise, which turned a recoverable
                misconfiguration into a dead knowledge base.

        Must not be called from the event-loop thread: credential resolution is
        synchronous and refuses there. Every caller today is already off it.
        """
        return self._get_embeddings(
            embedding_model, user_id=user_id, indexed_model=indexed_model
        )

    def _get_llm(self, model_id: Optional[str] = None, user_id: Optional[str] = None):
        """
        Get a LangChain chat LLM instance for graph extraction.

        When ``user_id`` is provided, credentials are resolved via the
        centralized credential resolver.  If ``model_id`` is a credential
        UUID, the specific credential is resolved.
        """
        if user_id:
            credential_id = model_id if self._is_credential_id(model_id) else None
            cred = self._resolve_user_creds_sync(user_id, credential_id=credential_id)
            if cred:
                # Extract the real model name from the credential when a UUID was passed
                if credential_id:
                    real_model = (
                        cred.get("deployment_name")
                        or cred.get("model")
                        or "gpt-4o-mini"
                    )
                else:
                    real_model = model_id or "gpt-4o-mini"
                try:
                    return self.llm_factory.get_model_from_credential(
                        credential=cred,
                        model_name=real_model,
                    )
                except Exception:
                    logger.debug("User credential LLM failed, falling back to LLMFactory default")

        if model_id and not self._is_credential_id(model_id):
            wrapper = self.llm_factory.get_model(model_id)
        else:
            wrapper = self.llm_factory.get_default_model()
        return wrapper._client

    @staticmethod
    def _resolve_user_creds_sync(
        user_id: str, credential_id: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Synchronous wrapper around the async credential resolver.

        Delegates to the centralized ``resolve_llm_credential_sync`` in
        ``echolib.credential_resolver``.

        Args:
            user_id: The user whose credentials to resolve.
            credential_id: Optional specific credential to resolve. When
                omitted the user's default credential is returned.
        """
        return resolve_llm_credential_sync(user_id, credential_id=credential_id)

    # ------------------------------------------------------------------
    # File upload helpers
    # ------------------------------------------------------------------

    _UPLOAD_CHUNK_SIZE = 1024 * 1024  # 1 MB

    async def _save_upload_file(self, upload_file: UploadFile, destination_path: str) -> int:
        """Persist an uploaded file to disk without buffering the full payload in memory."""
        temp_path = f"{destination_path}.part"
        total_bytes = 0

        try:
            await upload_file.seek(0)
            with open(temp_path, "wb") as output_file:
                while True:
                    chunk = await upload_file.read(self._UPLOAD_CHUNK_SIZE)
                    if not chunk:
                        break
                    output_file.write(chunk)
                    total_bytes += len(chunk)

            os.replace(temp_path, destination_path)
            return total_bytes
        except Exception:
            for path in (temp_path, destination_path):
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except OSError:
                    logger.warning("Failed to clean up partial upload file '%s'", path)
            raise
        finally:
            await upload_file.close()

    @staticmethod
    def _build_stored_path(file_dir: str, doc_id: str, filename: Optional[str]) -> str:
        from pathlib import Path
        safe_filename = Path(filename or f"upload_{doc_id}").name or f"upload_{doc_id}"
        return os.path.join(file_dir, f"{doc_id}_{safe_filename}")

    @staticmethod
    async def _retained_bytes(stored_path: str) -> Optional[bytes]:
        """
        The upload's bytes, for ``knowledge_documents.content_bytes``.

        WHAT: Reads back the file that was just written, so the original is kept
              in Postgres alongside the copy on disk.
        WHY:  The disk copy is on the container's writable layer and does not
              survive a restart or reach another replica. Without a durable
              original, reprocessing a knowledge base fails with "No valid files
              to process" and the only recovery left is a re-upload.
        OUTPUT: The bytes, or ``None`` when retention is switched off or the
                file could not be read — the row is written either way, and the
                pipeline reports a missing original honestly.

        Retention follows ``MARKITDOWN_KEEP_ORIGINALS``, the switch agent
        attachments already use. No new setting.
        """
        from apps.markitdown import config as md_config

        if not md_config.keep_originals():
            return None

        def _read() -> Optional[bytes]:
            try:
                with open(stored_path, "rb") as handle:
                    return handle.read()
            except OSError:
                logger.warning(
                    "Original bytes for '%s' could not be retained", stored_path,
                    exc_info=True,
                )
                return None

        return await asyncio.to_thread(_read)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def create_knowledge_base(
        self,
        user_id: str,
        data: KnowledgeBaseCreate,
        files: List[UploadFile],
    ) -> Dict[str, Any]:
        """
        Create a knowledge base, save uploaded files, and dispatch processing.

        Returns the created KB dict with document list.
        """
        kb_id = str(uuid.uuid4())

        async with get_db_session() as db:
            # Create KB record
            kb_data = data.model_dump()
            kb_data["id"] = uuid.UUID(kb_id)
            kb_data["status"] = "pending"
            kb = await self.kb_repo.create(db, user_id, kb_data)

            # Save files and create document records
            file_dir = _file_storage_dir(kb_id)
            os.makedirs(file_dir, exist_ok=True)

            doc_records = []
            saved_paths = []
            try:
                for upload_file in files:
                    doc_id = str(uuid.uuid4())
                    filename = upload_file.filename or f"upload_{doc_id}"
                    stored_path = self._build_stored_path(file_dir, doc_id, filename)

                    # Save file to disk (chunked to avoid buffering large files)
                    file_size = await self._save_upload_file(upload_file, stored_path)

                    file_type = os.path.splitext(filename)[1].lower().lstrip(".")

                    doc_data = {
                        "id": uuid.UUID(doc_id),
                        "knowledge_base_id": uuid.UUID(kb_id),
                        "original_filename": filename,
                        "stored_path": stored_path,
                        "content_bytes": await self._retained_bytes(stored_path),
                        "file_size": file_size,
                        "file_type": file_type,
                        "processing_status": "pending",
                    }
                    doc_records.append(doc_data)
                    saved_paths.append(stored_path)
            except Exception:
                for stored_path in saved_paths:
                    try:
                        if os.path.exists(stored_path):
                            os.remove(stored_path)
                    except OSError:
                        logger.warning("Failed to clean up knowledge upload '%s'", stored_path)
                raise

            docs = await self.doc_repo.bulk_create(db, doc_records)

            # Build response
            kb_dict = kb.to_dict()
            kb_dict["documents"] = [d.to_dict() for d in docs]

        # Dispatch background processing task (no Celery needed)
        if saved_paths:
            from apps.knowledge.tasks import fire_and_forget_process
            await fire_and_forget_process(kb_id)
            logger.info("Dispatched background processing for KB %s", kb_id)

        return kb_dict

    async def list_knowledge_bases(
        self, user_id: str, limit: int = 100, offset: int = 0
    ) -> Dict[str, Any]:
        """List all knowledge bases for a user."""
        async with get_db_session() as db:
            kbs = await self.kb_repo.list_by_user(db, user_id, limit=limit, offset=offset)
            items = []
            for kb in kbs:
                d = kb.to_dict()
                d["documents"] = [doc.to_dict() for doc in kb.documents] if kb.documents else []
                items.append(d)
            return {"items": items, "total": len(items)}

    async def list_knowledge_bases_paginated(
        self,
        user_id: str,
        *,
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List knowledge bases for a user with pagination and optional search.

        Routes must go through this (or another service method) rather than
        resolving a repository/session directly from the DI container: the
        only knowledge DI key ever registered is "knowledge.service"
        (apps/knowledge/container.py); "knowledge.repository" and
        "database.session" have no provider and raise KeyError on resolve.
        """
        async with get_db_session() as db:
            kbs, total = await self.kb_repo.list_by_user_paginated(
                db, user_id, page=page, page_size=page_size, search=search
            )
            items = [kb.to_dict() for kb in kbs]
            return {"page": page, "page_size": page_size, "total": total, "items": items}

    async def get_knowledge_base(
        self, kb_id: str, user_id: str
    ) -> Optional[Dict[str, Any]]:
        """Get a single knowledge base with its documents."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return None
            d = kb.to_dict()
            d["documents"] = [doc.to_dict() for doc in kb.documents] if kb.documents else []
            return d

    async def update_knowledge_base(
        self, kb_id: str, user_id: str, data: KnowledgeBaseUpdate
    ) -> Optional[Dict[str, Any]]:
        """Update knowledge base metadata/config."""
        updates = data.model_dump(exclude_none=True)
        if not updates:
            return await self.get_knowledge_base(kb_id, user_id)

        async with get_db_session() as db:
            kb = await self.kb_repo.update(db, kb_id, user_id, updates)
            if not kb:
                return None
            d = kb.to_dict()
            d["documents"] = [doc.to_dict() for doc in kb.documents] if kb.documents else []
            return d

    async def delete_knowledge_base(self, kb_id: str, user_id: str) -> bool:
        """Soft delete KB. Also clean up FAISS index and Neo4j data."""
        async with get_db_session() as db:
            deleted = await self.kb_repo.delete(db, kb_id, user_id)

        if deleted:
            # Clean up storage (best effort, offloaded to thread)
            try:
                await asyncio.to_thread(delete_faiss_index, kb_id)
            except Exception as e:
                logger.warning("Failed to delete FAISS index for KB %s: %s", kb_id, e)
            try:
                await asyncio.to_thread(delete_graph_data, kb_id)
            except Exception as e:
                logger.warning("Failed to delete graph data for KB %s: %s", kb_id, e)

        return deleted

    # ------------------------------------------------------------------
    # Documents
    # ------------------------------------------------------------------

    async def add_documents(
        self, kb_id: str, user_id: str, files: List[UploadFile]
    ) -> Optional[List[Dict[str, Any]]]:
        """Add more documents to an existing KB and trigger processing."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return None

            file_dir = _file_storage_dir(kb_id)
            os.makedirs(file_dir, exist_ok=True)

            doc_records = []
            saved_paths = []
            try:
                for upload_file in files:
                    doc_id = str(uuid.uuid4())
                    filename = upload_file.filename or f"upload_{doc_id}"
                    stored_path = self._build_stored_path(file_dir, doc_id, filename)

                    file_size = await self._save_upload_file(upload_file, stored_path)
                    file_type = os.path.splitext(filename)[1].lower().lstrip(".")

                    doc_data = {
                        "id": uuid.UUID(doc_id),
                        "knowledge_base_id": uuid.UUID(kb_id),
                        "original_filename": filename,
                        "stored_path": stored_path,
                        "content_bytes": await self._retained_bytes(stored_path),
                        "file_size": file_size,
                        "file_type": file_type,
                        "processing_status": "pending",
                    }
                    doc_records.append(doc_data)
                    saved_paths.append(stored_path)
            except Exception:
                for stored_path in saved_paths:
                    try:
                        if os.path.exists(stored_path):
                            os.remove(stored_path)
                    except OSError:
                        logger.warning("Failed to clean up knowledge upload '%s'", stored_path)
                raise

            docs = await self.doc_repo.bulk_create(db, doc_records)

            # Update KB status back to processing
            await self.kb_repo.update_status(db, kb_id, "processing")

        # Dispatch background processing for the new documents
        from apps.knowledge.tasks import fire_and_forget_process
        await fire_and_forget_process(kb_id)

        return [d.to_dict() for d in docs]

    async def list_documents(
        self, kb_id: str, user_id: str
    ) -> Optional[List[Dict[str, Any]]]:
        """List documents in a KB."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return None
            docs = await self.doc_repo.list_by_kb(db, kb_id)
            return [d.to_dict() for d in docs]

    async def delete_document(
        self, kb_id: str, doc_id: str, user_id: str
    ) -> bool:
        """Delete a document from a KB (hard delete — removes file too)."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return False

            doc = await self.doc_repo.get_by_id(db, doc_id)
            if not doc or str(doc.knowledge_base_id) != kb_id:
                return False

            # Remove file from disk
            if doc.stored_path and os.path.exists(doc.stored_path):
                await asyncio.to_thread(os.remove, doc.stored_path)

            return await self.doc_repo.delete(db, doc_id)

    # ------------------------------------------------------------------
    # Processing
    # ------------------------------------------------------------------

    async def reprocess_knowledge_base(self, kb_id: str, user_id: str) -> bool:
        """Trigger full reprocessing of a KB (re-parse, re-chunk, re-embed, re-graph)."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return False

            # Reset all document statuses
            docs = await self.doc_repo.list_by_kb(db, kb_id)
            for doc in docs:
                await self.doc_repo.update_status(db, str(doc.id), "pending")

            # Reset KB status
            await self.kb_repo.update_status(db, kb_id, "processing")

        # Clean old indexes (offloaded to thread)
        try:
            await asyncio.to_thread(delete_faiss_index, kb_id)
        except Exception:
            pass
        try:
            await asyncio.to_thread(delete_graph_data, kb_id)
        except Exception:
            pass

        # Dispatch background processing
        from apps.knowledge.tasks import fire_and_forget_process
        await fire_and_forget_process(kb_id)
        return True

    async def get_processing_status(
        self, kb_id: str, user_id: str
    ) -> Optional[Dict[str, Any]]:
        """Get processing status for a KB with per-document breakdown."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return None

            docs = kb.documents or []
            status_counts = {"pending": 0, "processing": 0, "completed": 0, "failed": 0}
            for doc in docs:
                status_counts[doc.processing_status] = status_counts.get(
                    doc.processing_status, 0
                ) + 1

            return {
                "kb_id": str(kb.id),
                "status": kb.status,
                "error_message": kb.error_message,
                "total_documents": len(docs),
                "completed_documents": status_counts["completed"],
                "failed_documents": status_counts["failed"],
                "processing_documents": status_counts["processing"],
                "pending_documents": status_counts["pending"],
                "documents": [d.to_dict() for d in docs],
            }

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search_knowledge_base(
        self,
        kb_id: str,
        user_id: str,
        query: str,
        top_k: Optional[int] = None,
        search_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Search a specific knowledge base."""
        async with get_db_session() as db:
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if not kb:
                return None

            # Use KB defaults if not overridden
            effective_top_k = top_k if top_k is not None else kb.top_k
            effective_search_type = search_type if search_type is not None else kb.search_type

            # Only fetch embeddings when the processing type needs them.
            # Graph-only KBs don't use vector search, so skip embeddings
            # to avoid errors when no embedding model is configured.
            embeddings = None
            if kb.processing_type in ("vector", "hybrid"):
                # Off the loop for the same reason the retrieval call below is:
                # ``_get_embeddings`` resolves the user's credential through
                # ``resolve_llm_credential_sync``, which cannot run on the
                # event-loop thread and returns None there, dropping the search
                # to the platform default model that may not be configured.
                def _resolve_embeddings(
                    configured=kb.embedding_model, base_id=str(kb.id)
                ):
                    from apps.knowledge import chunk_store

                    return self._get_embeddings(
                        configured,
                        user_id=user_id,
                        # What the passages were indexed with outranks what the
                        # base was configured with; the latter is usually unset.
                        indexed_model=chunk_store.indexed_embedding_model(base_id),
                    )

                embeddings = await asyncio.to_thread(_resolve_embeddings)
                if embeddings is None:
                    logger.warning(
                        "No embedding model resolved for knowledge base %s; "
                        "searching its stored passages by keyword",
                        kb.id,
                    )

            results = await asyncio.to_thread(
                retriever.search,
                kb_id=str(kb.id),
                query=query,
                embeddings=embeddings,
                search_type=effective_search_type,
                top_k=effective_top_k,
                vector_weight=kb.vector_weight,
                keyword_weight=kb.keyword_weight,
                processing_type=kb.processing_type,
            )

            # Enrich with KB name
            for r in results:
                r["knowledge_base_name"] = kb.name

            return {
                "query": query,
                "results": results,
                "total_results": len(results),
                "search_type": effective_search_type,
                "top_k": effective_top_k,
            }

    async def search_multiple(
        self,
        user_id: str,
        query: str,
        kb_ids: List[str],
        top_k: Optional[int] = None,
        search_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Search across multiple knowledge bases and merge results."""
        all_results = []

        for kb_id in kb_ids:
            result = await self.search_knowledge_base(
                kb_id, user_id, query, top_k, search_type
            )
            if result:
                all_results.extend(result["results"])

        # Sort by score descending and limit
        all_results.sort(key=lambda x: x.get("score", 0), reverse=True)
        effective_top_k = top_k or 5
        all_results = all_results[:effective_top_k]

        return {
            "query": query,
            "results": all_results,
            "total_results": len(all_results),
            "search_type": search_type or "similarity",
            "top_k": effective_top_k,
        }

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    async def get_global_stats(self, user_id: str) -> Dict[str, Any]:
        """Get global stats for the dashboard."""
        async with get_db_session() as db:
            return await self.kb_repo.get_stats(db, user_id)

    async def get_kb_stats(self, kb_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Get stats for a specific KB."""
        async with get_db_session() as db:
            stats = await self.kb_repo.get_kb_stats(db, kb_id, user_id)
            if not stats:
                return None

            # Add graph stats if processing_type includes graph
            kb = await self.kb_repo.get_by_id(db, kb_id, user_id)
            if kb and kb.processing_type in ("graph", "hybrid"):
                try:
                    graph_stats = await asyncio.to_thread(get_graph_stats, kb_id)
                    stats.update(graph_stats)
                except Exception as e:
                    logger.warning("Failed to get graph stats for KB %s: %s", kb_id, e)

            return stats
