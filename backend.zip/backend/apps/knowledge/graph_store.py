"""
EchoAI Knowledge Base — Neo4j Graph Store

Manages knowledge graph data in Neo4j using LangChain's LLMGraphTransformer
for entity/relationship extraction and Neo4jGraph for storage.

All entities and relationships are tagged with ``kb_id`` so a single shared
Neo4j database can serve multiple knowledge bases.

Requires environment variables:
    NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE
"""

import logging
import os
import re
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document
from langchain_core.language_models import BaseLanguageModel

logger = logging.getLogger(__name__)

# Neo4j connection config from environment
# NEO4J_URI = os.getenv("NEO4J_URI", "neo4j://127.0.0.1:7687")
# NEO4J_USERNAME = os.getenv("NEO4J_USERNAME", "neo4j")
# NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")
# NEO4J_DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
NEO4J_DATABASE = os.getenv("NEO4J_DATABASE")


# def _get_neo4j_graph():
#     """
#     Create a Neo4jGraph instance from LangChain Community.

#     Lazy import to avoid hard dependency when graph features are not used.
#     """
#     from langchain_community.graphs import Neo4jGraph

#     return Neo4jGraph(
#         url=NEO4J_URI,
#         username=NEO4J_USERNAME,
#         password=NEO4J_PASSWORD,
#         database=NEO4J_DATABASE,
#     )

def _get_neo4j_graph():
    """
    Create and validate a Neo4jGraph connection.

    The import remains lazy so installations that do not use graph features
    do not load the Neo4j integration unnecessarily.
    """
    from langchain_neo4j import Neo4jGraph

    missing_settings = []

    if not NEO4J_URI:
        missing_settings.append("NEO4J_URI")
    if not NEO4J_USERNAME:
        missing_settings.append("NEO4J_USERNAME")
    if not NEO4J_PASSWORD:
        missing_settings.append("NEO4J_PASSWORD")

    if missing_settings:
        raise RuntimeError(
            "Neo4j is not configured. Missing environment variable(s): "
            + ", ".join(missing_settings)
        )

    try:
        graph = Neo4jGraph(
            url=NEO4J_URI,
            username=NEO4J_USERNAME,
            password=NEO4J_PASSWORD,
            database=NEO4J_DATABASE,
            refresh_schema=False,
        )

        logger.info(
            "Connected to Neo4j database '%s' at %s",
            NEO4J_DATABASE,
            NEO4J_URI,
        )

        return graph

    except Exception as exc:
        logger.exception(
            "Failed to connect to Neo4j database '%s' at %s",
            NEO4J_DATABASE,
            NEO4J_URI,
        )
        raise RuntimeError(
            "Could not connect to Neo4j. Verify NEO4J_URI, "
            "NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE, "
            "network access, and TLS configuration."
        ) from exc
    
def extract_and_store_graph(
    kb_id: str,
    documents: List[Document],
    llm: BaseLanguageModel,
) -> Dict[str, Any]:
    """
    Extract entities and relationships from documents using LLMGraphTransformer,
    then store them in Neo4j tagged with the knowledge base ID.

    Args:
        kb_id: Knowledge base ID for tagging.
        documents: LangChain Documents (chunks) to process.
        llm: LangChain LLM instance for entity/relation extraction.

    Returns:
        Dict with counts: {"nodes_created": int, "relationships_created": int}
    """
    from langchain_experimental.graph_transformers import LLMGraphTransformer

    logger.info("Extracting graph from %d documents for KB %s", len(documents), kb_id)

    # Use ignore_tool_usage=True to bypass with_structured_output() which
    # requires json_schema support (not available on Ollama /v1 or some Azure
    # deployments).  Prompt-based extraction works universally with any LLM
    # that can produce JSON text.
    transformer = LLMGraphTransformer(llm=llm, ignore_tool_usage=True)

    # Extract graph documents in batches with progress logging.
    # Each doc requires an LLM call (2-10+ s), so 100+ docs can take
    # 10-30 min.  Batching gives visibility that the process is alive.
    BATCH_SIZE = 20
    graph_documents = []
    total = len(documents)
    for batch_start in range(0, total, BATCH_SIZE):
        batch_end = min(batch_start + BATCH_SIZE, total)
        batch = documents[batch_start:batch_end]
        logger.info(
            "Graph extraction progress for KB %s: processing docs %d-%d of %d",
            kb_id, batch_start + 1, batch_end, total,
        )
        batch_results = transformer.convert_to_graph_documents(batch)
        graph_documents.extend(batch_results)
    logger.info("Graph extraction completed for KB %s: %d graph documents", kb_id, len(graph_documents))

    if not graph_documents:
        logger.info("No graph entities extracted for KB %s", kb_id)
        return {"nodes_created": 0, "relationships_created": 0}

    # Tag all nodes and relationships with kb_id
    total_nodes = 0
    total_rels = 0
    for graph_doc in graph_documents:
        for node in graph_doc.nodes:
            node.properties = node.properties or {}
            node.properties["kb_id"] = kb_id
            total_nodes += 1
        for rel in graph_doc.relationships:
            rel.properties = rel.properties or {}
            rel.properties["kb_id"] = kb_id
            total_rels += 1

    # Store in Neo4j
    graph = _get_neo4j_graph()
    graph.add_graph_documents(
        graph_documents,
        baseEntityLabel=True,
        include_source=True,
    )

    logger.info(
        "Graph stored for KB %s: %d nodes, %d relationships",
        kb_id,
        total_nodes,
        total_rels,
    )

    return {"nodes_created": total_nodes, "relationships_created": total_rels}


# Common English stopwords to filter out from graph keyword matching.
# These match too broadly against entity names and produce irrelevant results.
_STOPWORDS = frozenset({
    "a", "an", "the", "is", "am", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could", "should",
    "may", "might", "shall", "can", "need", "dare", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "through", "during", "before",
    "after", "above", "below", "between", "out", "off", "over", "under", "again",
    "further", "then", "once", "here", "there", "when", "where", "why", "how",
    "all", "each", "every", "both", "few", "more", "most", "other", "some", "such",
    "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very",
    "and", "but", "or", "if", "while", "because", "until", "about", "what",
    "which", "who", "whom", "this", "that", "these", "those", "it", "its",
    "he", "she", "his", "her", "they", "them", "their", "we", "us", "our",
    "you", "your", "me", "my", "i",
})


def _extract_keywords(query: str) -> List[str]:
    """Extract meaningful keywords from a query, filtering stopwords and punctuation."""
    # Strip punctuation from each word (e.g. 'india?' → 'india', 'RBI,' → 'rbi')
    raw_words = query.lower().split()
    words = [re.sub(r'[^\w]', '', w) for w in raw_words]
    return [w for w in words if len(w) > 2 and w not in _STOPWORDS]


def query_graph(
    kb_id: str,
    query: str,
    llm: Optional[BaseLanguageModel] = None,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Query the knowledge graph for entities and relationships related to a query.

    Uses a Cypher query to find nodes matching meaningful keywords (stopwords
    removed) from the query.  Computes a keyword-overlap relevance score and
    also traverses to source Document nodes to retrieve source_filename and
    chunk_index metadata.

    Args:
        kb_id: Knowledge base ID to scope the search.
        query: Natural language query.
        llm: LLM instance (reserved for future query expansion, optional).
        top_k: Maximum results to return.

    Returns:
        List of dicts with entity/relationship information, keyword match
        count, and source document metadata.
    """
    keywords = _extract_keywords(query)
    if not keywords:
        logger.info("No meaningful keywords extracted from query %r for KB %s", query, kb_id)
        return []

    logger.info("Graph query keywords for KB %s: %s", kb_id, keywords)

    graph = _get_neo4j_graph()

    # Cypher query that:
    # 1. Filters nodes by kb_id and keyword match (using pre-filtered keywords)
    # 2. Counts how many keywords matched (for relevance scoring)
    # 3. Traverses to related nodes
    # 4. Traverses to source Document node (linked by MENTIONS relationship
    #    from add_graph_documents with include_source=True)
    # 5. Orders by match count (best matches first)
    cypher = """
    WITH $keywords AS keywords
    MATCH (n)
    WHERE n.kb_id = $kb_id
      AND ANY(kw IN keywords WHERE
        toLower(n.id) CONTAINS kw
        OR toLower(coalesce(n.name, '')) CONTAINS kw
      )
    WITH n,
         size([kw IN keywords WHERE
           toLower(n.id) CONTAINS kw
           OR toLower(coalesce(n.name, '')) CONTAINS kw
         ]) AS match_count
    OPTIONAL MATCH (n)-[r]->(m)
    WHERE m.kb_id = $kb_id
    OPTIONAL MATCH (d:Document)-[:MENTIONS]->(n)
    RETURN n, r, m, type(r) AS rel_type, match_count,
           d.source_filename AS source_filename,
           d.chunk_index AS chunk_index
    ORDER BY match_count DESC
    LIMIT $top_k
    """

    try:
        results = graph.query(
            cypher,
            params={"kb_id": kb_id, "keywords": keywords, "top_k": top_k},
        )
    except Exception as e:
        logger.error("Neo4j query failed for KB %s: %s", kb_id, e)
        return []

    total_keywords = len(keywords)
    formatted: List[Dict[str, Any]] = []
    for record in results:
        item: Dict[str, Any] = {}

        n = record.get("n")
        if n:
            item["source_node"] = dict(n) if isinstance(n, dict) else str(n)

        # Use rel_type (clean string like "CONTAINS") instead of raw r object
        rel_type = record.get("rel_type")
        if rel_type:
            item["relationship"] = rel_type

        m = record.get("m")
        if m:
            item["target_node"] = dict(m) if isinstance(m, dict) else str(m)

        # Keyword match relevance: fraction of query keywords that matched
        match_count = record.get("match_count", 0)
        item["match_score"] = match_count / total_keywords if total_keywords > 0 else 0.0

        # Source document metadata from the linked Document node
        item["source_filename"] = record.get("source_filename") or ""
        item["chunk_index"] = record.get("chunk_index")

        item["kb_id"] = kb_id
        formatted.append(item)

    return formatted


def delete_graph_data(kb_id: str) -> int:
    """
    Delete all nodes and relationships tagged with the given kb_id.

    Returns the number of nodes deleted.
    """
    graph = _get_neo4j_graph()

    cypher = """
    MATCH (n {kb_id: $kb_id})
    DETACH DELETE n
    RETURN count(n) as deleted
    """

    try:
        result = graph.query(cypher, params={"kb_id": kb_id})
        deleted = result[0].get("deleted", 0) if result else 0
        logger.info("Deleted %d graph nodes for KB %s", deleted, kb_id)
        return deleted
    except Exception as e:
        logger.error("Failed to delete graph data for KB %s: %s", kb_id, e)
        return 0


def get_graph_stats(kb_id: str) -> Dict[str, Any]:
    """Get node and relationship counts for a knowledge base."""
    graph = _get_neo4j_graph()

    try:
        node_result = graph.query(
            "MATCH (n {kb_id: $kb_id}) RETURN count(n) as count",
            params={"kb_id": kb_id},
        )
        node_count = node_result[0].get("count", 0) if node_result else 0

        rel_result = graph.query(
            "MATCH (n {kb_id: $kb_id})-[r]->() RETURN count(r) as count",
            params={"kb_id": kb_id},
        )
        rel_count = rel_result[0].get("count", 0) if rel_result else 0

        return {"node_count": node_count, "relationship_count": rel_count}
    except Exception as e:
        logger.error("Failed to get graph stats for KB %s: %s", kb_id, e)
        return {"node_count": 0, "relationship_count": 0}
