"""
The one place a knowledge base's embedding client is resolved.

WHAT: Turns ``knowledge_bases.embedding_model`` -- which may be a credential
      UUID, a model name, or nothing at all -- into an embeddings client, or
      into an honest ``None``.
WHY:  Ingestion and retrieval used to resolve embeddings through two separate
      functions (``apps/knowledge/tasks.py`` and ``apps/knowledge/service.py``)
      that did not agree. Ingestion had a platform fallback; retrieval did not.
      So a knowledge base was indexed by one model and queried by another, or
      queried by one that does not exist -- and a vector index can only be read
      by the model that wrote it. Both paths now compute the same answer from
      the same input, because they call the same function.

THE DEFECT THIS REPLACES
------------------------
Both old resolvers ended in the same two lines::

    cred = resolve_llm_credential_sync(user_id)        # the user's *chat* default
    real_model = embedding_model or "embedding_text"

A knowledge base with no embedding model configured -- the default, since the
picker is optional and the column is nullable -- therefore asked the user's chat
credential for a deployment named ``embedding_text``. Azure routes by
deployment name and a chat deployment does not serve ``/embeddings``, so every
call answered ``404 DeploymentNotFound``: at query time, and again inside the
rebuild that was supposed to recover from it. The knowledge base held its text
the whole time and reported itself empty.

Nothing here pairs a credential with a model name it was not registered for.

RESOLUTION ORDER
----------------
0. The model the base's stored passages were actually embedded with, when the
   caller supplies it. Index-time truth beats configured intent.
1. ``embedding_model`` is a credential UUID -- the explicit choice. The model
   name comes from that credential, never from a constant.
2. ``embedding_model`` is a model name -- an embedding-capable credential that
   serves it.
3. Nothing configured -- the best embedding-capable credential this user can
   reach. This is the tier that fixes the reported bug.
4. The model catalogue, for a name defined in ``llm_provider.json``.
5. The platform's Azure fallback, which is what ingestion already used.
6. ``None``.

Tier 6 is a real outcome, not an error: callers degrade to keyword search over
the same passages rather than failing the turn.

ASYNC/SYNC BOUNDARY
-------------------
Credential resolution is synchronous and refuses to run on the event-loop
thread. Every caller reaches this module from a worker thread already
(``asyncio.to_thread``) or from ingestion, which is off the request path.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Optional

from echolib.secrets_provider import secrets as secrets_provider

logger = logging.getLogger(__name__)

# Used only when the platform's own Azure fallback is reached and no deployment
# name has been configured for it. It is never combined with a user credential,
# which is the mistake this module exists to remove.
_PLATFORM_AZURE_EMBEDDING_DEPLOYMENT = "embedding_text"


def is_credential_id(value: Optional[str]) -> bool:
    """Whether ``value`` is a credential UUID rather than a model name."""
    if not value:
        return False
    try:
        uuid.UUID(str(value))
        return True
    except (ValueError, TypeError, AttributeError):
        return False


def model_name_of(client: Any) -> Optional[str]:
    """
    The model an embeddings client actually uses.

    WHAT: Reads the name off the client, preferring the OTel wrapper's recorded
          ``_model`` and falling back to the underlying LangChain attributes.
    WHY:  ``knowledge_bases.embedding_model`` holds what was *configured*, which
          is usually ``NULL``, and it is what used to be written to every stored
          passage. So a base embedded by the platform fallback recorded no model
          at all, and nothing downstream could tell which vector space its
          passages were in. Recording the effective model is what makes an
          index/query mismatch detectable instead of silent.
    """
    if client is None:
        return None
    for attribute in ("_model", "model", "azure_deployment", "deployment"):
        value = getattr(client, attribute, None)
        if isinstance(value, str) and value.strip() and value != "unknown":
            return value.strip()
    return None


def _client_from_credential(
    cred: dict, model_name: str, llm_factory: Any = None
) -> Optional[Any]:
    """
    Build an embeddings client from a resolved credential.

    Returns ``None`` rather than raising: this is one candidate in a cascade,
    and a provider that cannot embed must not end the search for one that can.
    """
    from echolib.otel import _wrap_embeddings_with_otel

    if not cred or not model_name:
        return None

    if llm_factory is None:
        from echolib.llm_factory import LLMFactory

        llm_factory = LLMFactory()

    model_config = {
        "provider": cred.get("provider", ""),
        "base_url": cred.get("base_url", ""),
        "api_key": cred.get("api_key", ""),
        "api_key_env": None,
        "model_name": model_name,
        "embedding_model": model_name,
    }

    try:
        client = llm_factory.client_builder.build_embeddings_client(model_config)
    except Exception:
        logger.warning(
            "Embeddings client could not be built for credential %s "
            "(provider=%s, model=%s)",
            cred.get("credential_id"), cred.get("provider"), model_name,
            exc_info=True,
        )
        return None

    return _wrap_embeddings_with_otel(
        client,
        provider_name=cred.get("provider") or "unknown",
        model_name=model_name,
    )


def platform_fallback_embeddings() -> Optional[Any]:
    """
    The platform's own Azure embeddings deployment.

    WHAT: The last tier before giving up, and the one ingestion has always used
          when a user's configured model failed.
    WHY:  It lives here rather than in ``tasks.py`` so that retrieval reaches
          the *same* deployment ingestion did. When these two differ, passages
          are written in one vector space and queried in another, and every
          search silently ranks on noise.

    Reads the ``FALLBACK_AZURE_OPENAI_*`` secrets already configured for this
    deployment, falling back to the older ``AZURE_OPENAI_*`` names. No new
    setting is introduced.
    """
    from langchain_openai import AzureOpenAIEmbeddings

    from echolib.otel import _wrap_embeddings_with_otel

    api_key = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_KEY")
        or secrets_provider.get_secret("AZURE_OPENAI_API_KEY", "")
    )
    if not api_key:
        logger.info(
            "No platform Azure embeddings key is configured; the platform "
            "fallback is unavailable"
        )
        return None

    endpoint = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
        or secrets_provider.get_secret(
            "AZURE_OPENAI_ENDPOINT", "https://aiabotgpt.openai.azure.com/"
        )
    )
    deployment = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
        or _PLATFORM_AZURE_EMBEDDING_DEPLOYMENT
    )

    try:
        client = AzureOpenAIEmbeddings(
            azure_endpoint=endpoint,
            api_key=api_key,
            azure_deployment=deployment,
            model=_PLATFORM_AZURE_EMBEDDING_DEPLOYMENT,
            api_version="2024-02-01",
        )
    except Exception:
        logger.warning(
            "The platform Azure embeddings client could not be built", exc_info=True
        )
        return None

    logger.info("Using the platform Azure embeddings fallback (%s)", deployment)
    return _wrap_embeddings_with_otel(
        client, provider_name="azure", model_name=deployment
    )


def _catalog_embeddings(model_name: str, llm_factory: Any = None) -> Optional[Any]:
    """The model catalogue's client for a name defined in ``llm_provider.json``."""
    from echolib.otel import _wrap_embeddings_with_otel

    if llm_factory is None:
        from echolib.llm_factory import LLMFactory

        llm_factory = LLMFactory()

    try:
        wrapper = llm_factory.get_model(model_name)
        client = wrapper._embeddings_client
    except Exception:
        logger.debug(
            "'%s' is not an embedding model in the platform catalogue", model_name
        )
        return None

    if client is None:
        return None

    return _wrap_embeddings_with_otel(
        client,
        provider_name=getattr(wrapper, "_provider", "unknown"),
        model_name=model_name,
    )


def resolve(
    embedding_model: Optional[str] = None,
    user_id: Optional[str] = None,
    *,
    llm_factory: Any = None,
    indexed_model: Optional[str] = None,
) -> Optional[Any]:
    """
    The embeddings client for a knowledge base.

    INPUT: ``embedding_model`` as stored on the base -- a credential UUID, a
           model name, or ``None``. ``indexed_model`` is the model its stored
           passages were actually embedded with, when known.
    OUTPUT: A LangChain ``Embeddings`` client, or ``None`` when this user can
            reach no embedding model. Never raises.

    ``None`` is not a failure to report upward as an error. It means vector
    search is unavailable for this base right now, and the caller answers from
    keyword search over the same passages instead.
    """
    from echolib.credential_resolver import (
        resolve_embedding_credential_sync,
        resolve_llm_credential_sync,
    )

    if llm_factory is None:
        from echolib.llm_factory import LLMFactory

        llm_factory = LLMFactory()

    # --- Tier 0: what the passages were actually embedded with ---------------
    # The strongest signal there is. A base configured with nothing but indexed
    # under the platform fallback must be queried under the platform fallback,
    # or the query lands in a different vector space than the passages.
    if indexed_model and user_id:
        cred = resolve_embedding_credential_sync(user_id, indexed_model)
        if cred:
            client = _client_from_credential(
                cred, cred.get("embedding_model") or indexed_model, llm_factory
            )
            if client is not None:
                logger.info(
                    "Embeddings resolved from the model the passages were "
                    "indexed with: %s", indexed_model,
                )
                return client

    # --- Tier 1: an explicitly chosen credential -----------------------------
    if user_id and is_credential_id(embedding_model):
        cred = resolve_llm_credential_sync(user_id, credential_id=embedding_model)
        if cred:
            # The credential names its own model. The old code fell back to a
            # constant here, which is how a credential ended up being asked for
            # a deployment it does not have.
            model_name = (
                cred.get("deployment_name")
                or cred.get("_original_model")
                or cred.get("credential_name")
                or ""
            )
            client = _client_from_credential(cred, model_name, llm_factory)
            if client is not None:
                return client
            logger.warning(
                "The embedding credential configured for this knowledge base "
                "(%s) could not build a client; continuing down the cascade",
                embedding_model,
            )

    # --- Tier 2: a named model, served by a credential that has it -----------
    named_model = embedding_model if not is_credential_id(embedding_model) else None
    if user_id and named_model:
        cred = resolve_embedding_credential_sync(user_id, named_model)
        if cred:
            client = _client_from_credential(
                cred, cred.get("embedding_model") or named_model, llm_factory
            )
            if client is not None:
                return client

    # --- Tier 3: any embedding-capable credential this user can reach --------
    # The tier the reported bug needed. Previously this fell through to the
    # user's *chat* default paired with a hard-coded embedding model name.
    if user_id:
        cred = resolve_embedding_credential_sync(user_id)
        if cred:
            model_name = cred.get("embedding_model") or ""
            client = _client_from_credential(cred, model_name, llm_factory)
            if client is not None:
                logger.info(
                    "No embedding model is configured for this knowledge base; "
                    "using the embedding credential '%s' (%s)",
                    cred.get("credential_name"), model_name,
                )
                return client

    # --- Tier 4: the platform model catalogue --------------------------------
    if named_model:
        client = _catalog_embeddings(named_model, llm_factory)
        if client is not None:
            return client

    # --- Tier 5: the platform's Azure fallback -------------------------------
    client = platform_fallback_embeddings()
    if client is not None:
        return client

    # --- Tier 6: nothing ------------------------------------------------------
    logger.warning(
        "No embedding model could be resolved (configured embedding_model=%r, "
        "user=%s). Vector search is unavailable; callers will fall back to "
        "keyword search over the stored passages.",
        embedding_model, user_id,
    )
    return None


__all__ = [
    "is_credential_id",
    "model_name_of",
    "platform_fallback_embeddings",
    "resolve",
]
