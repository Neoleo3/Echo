"""
Knowledge adapter for MarkItDown-based document extraction.

This module gives the knowledge pipeline a small, stable interface for
document-to-markdown conversion while keeping conversion logic centralized
inside apps.markitdown.
"""

from __future__ import annotations

import mimetypes
import os
from dataclasses import dataclass
from typing import Optional

from apps.markitdown import converter
from apps.markitdown.errors import MarkItDownError


@dataclass(frozen=True)
class ExtractionResult:
    """Normalized extraction output consumed by the knowledge task pipeline."""

    markdown: str
    converted_by: str
    ocr_skipped_reason: Optional[str]
    char_count: int


def _guess_mime_type(file_path: str) -> Optional[str]:
    guessed, _ = mimetypes.guess_type(file_path)
    return guessed


def extract_markdown_from_file(
    file_path: str,
    *,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    mime_type: Optional[str] = None,
) -> ExtractionResult:
    """
    Convert a file on disk to markdown through apps.markitdown.

    Raises ValueError with user-safe messages on failure.
    """
    filename = os.path.basename(file_path)
    with open(file_path, "rb") as handle:
        payload = handle.read()

    try:
        result = converter.convert_bytes(
            payload,
            filename=filename,
            mimetype=mime_type or _guess_mime_type(file_path),
            user_id=user_id,
            credential_id=credential_id,
        )
    except MarkItDownError as exc:
        raise ValueError(str(exc)) from exc
    except Exception as exc:
        raise ValueError(f"Failed to convert '{filename}': {exc}") from exc

    markdown = (result.markdown or "").strip()
    if not markdown:
        raise ValueError(
            f"No text could be extracted from '{filename}'. "
            "The file may be empty, unreadable, or image content may be unavailable."
        )

    return ExtractionResult(
        markdown=markdown,
        converted_by=result.converted_by,
        ocr_skipped_reason=result.ocr_skipped_reason,
        char_count=result.char_count,
    )
