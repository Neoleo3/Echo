"""
EchoAI Knowledge Base — Background Processing Tasks

Async processing pipeline for knowledge bases (no Celery/Redis required):
1. Collect pending documents, rehydrating any whose file is no longer on disk
2. Convert files to markdown with MarkItDown
3. Split markdown into chunks (MarkdownHeader + Recursive)
4. Embed chunks once, then write them to Postgres and to FAISS
5. Extract entities/relations into Neo4j (if graph or hybrid processing)
6. Update DB statuses

Uses asyncio.create_task() — runs in the FastAPI event loop background.
Task is idempotent — re-running processes only pending/failed documents.

WHERE THE PASSAGES GO
---------------------
``knowledge_document_chunks`` is the durable store and the FAISS directory is a
local cache of it. Both are written from the *same* embedding pass, so keeping
the cache costs no extra model call — this platform bills every embedding to
the user's own credential.

The order matters: Postgres is written even when embedding fails, because text
that was extracted successfully is still readable whole and must not be thrown
away over an unavailable credential.
"""

import asyncio
import logging
import os
from typing import Any, List, Optional

from echolib.secrets_provider import secrets as secrets_provider

from echolib.database import get_db_session
from echolib.llm_factory import LLMFactory
from echolib.llm_resolver import resolve_and_build_llm_sync
from echolib.repositories.knowledge_repo import (
    KnowledgeBaseRepository,
    KnowledgeDocumentRepository,
)
from apps.knowledge import chunk_store
from apps.knowledge.markitdown_adapter import extract_markdown_from_file
from apps.knowledge.vector_store import (
    add_to_faiss_index_from_vectors,
    split_markdown,
)
from apps.knowledge.graph_store import extract_and_store_graph
from echolib.otel import _wrap_embeddings_with_otel
from langchain_openai import AzureOpenAIEmbeddings

logger = logging.getLogger(__name__)


async def fire_and_forget_process(kb_id: str) -> None:
    """
    Launch KB processing as a background asyncio task.
    
    Must be called with await from any async context:
     await fire_and_forget_process(kb_id)

    The task runs in the current event loop and logs errors internally
    without propagating them to the caller.
    """
    asyncio.create_task(_safe_process(kb_id))
    logger.info("Background processing task created for KB %s", kb_id)


async def _safe_process(kb_id: str) -> None:
    """Wrapper that catches all errors and updates KB status."""
    try:
        await _process_kb(kb_id)
        logger.info("Processing completed for KB %s", kb_id)
    except Exception as exc:
        logger.error("Processing failed for KB %s: %s", kb_id, exc, exc_info=True)
        await _set_kb_error(kb_id, str(exc))


async def _set_kb_error(kb_id: str, error_message: str):
    """Set KB status to error."""
    kb_repo = KnowledgeBaseRepository()
    async with get_db_session() as db:
        await kb_repo.update_status(db, kb_id, "error", error_message)


async def _process_kb(kb_id: str):
    """Core processing logic (async). Runs as a background task."""
    kb_repo = KnowledgeBaseRepository()
    doc_repo = KnowledgeDocumentRepository()

    # Load KB and its documents (no user scoping — background task)
    async with get_db_session() as db:
        from sqlalchemy import select
        from echolib.models.knowledge import KnowledgeBase, KnowledgeDocument
        from echolib.repositories.base import safe_uuid

        kb_uuid = safe_uuid(kb_id)
        if kb_uuid is None:
            logger.error("Invalid KB ID: %s", kb_id)
            return

        result = await db.execute(
            select(KnowledgeBase).where(KnowledgeBase.id == kb_uuid)
        )
        kb = result.scalar_one_or_none()
        if not kb:
            logger.error("KB %s not found", kb_id)
            return
        
        # Extract all KB config as plain Python values before session closes
        kb_processing_type = kb.processing_type
        kb_chunk_size = kb.chunk_size
        kb_chunk_overlap = kb.chunk_overlap
        kb_embedding_model = kb.embedding_model
        kb_graph_model = kb.graph_model
        kb_user_id = str(kb.user_id) if kb.user_id else None
        
        # Update status to processing
        await kb_repo.update_status(db, kb_id, "processing")

        # Get pending documents
        doc_result = await db.execute(
            select(KnowledgeDocument)
            .where(
                KnowledgeDocument.knowledge_base_id == kb.id,
                KnowledgeDocument.processing_status.in_(["pending", "failed"]),
            )
        )
        raw_docs = doc_result.scalars().all()
        #Extract all doc fields as plain dicts to avoid error
        pending_docs = [
            {
                "id": str(doc.id),
                "stored_path": doc.stored_path,
                "original_filename": doc.original_filename,
            }
            for doc in raw_docs
        ]

    if not pending_docs:
        logger.info("No pending documents for KB %s", kb_id)
        async with get_db_session() as db:
            await kb_repo.update_status(db, kb_id, "synced")
        return

    # ---------------------------------------------------------------
    # Step 1: Convert files to markdown using MarkItDown
    # ---------------------------------------------------------------
    # A document's file lives on the container's own disk, which does not
    # survive a restart and is invisible to any other replica. Reprocessing a
    # knowledge base therefore used to fail with "No valid files to process"
    # and set the base to 'error' -- the one recovery the product offered could
    # not work. The original bytes are in Postgres now, so a missing file is
    # written back before it is declared missing.
    valid_docs = await _rehydrate_missing_files(kb_id, pending_docs)

    if not valid_docs:
        # No file anywhere -- but the extracted markdown is in Postgres and is
        # everything retrieval actually needs. Rebuilding from it keeps a
        # working knowledge base working. Marking the base 'error' here is what
        # used to turn a reprocess of an older base into a *worse* state than
        # not reprocessing it at all: the ledger then reported it unreachable
        # and the application stopped seeing it entirely.
        logger.warning("No valid file paths found on disk for KB %s", kb_id)
        recovered = await _recover_from_stored_markdown(
            kb_id, LLMFactory(), kb_embedding_model, kb_user_id
        )
        async with get_db_session() as db:
            if recovered:
                await kb_repo.update_status(db, kb_id, "synced")
            else:
                await kb_repo.update_status(
                    db, kb_id, "error", "No valid files to process"
                )
        return

    # Build filename -> doc mapping
    filename_to_doc = {}
    for doc in valid_docs:
        fname = os.path.basename(doc["stored_path"])
        if fname:
            filename_to_doc[fname] = doc
    
    # Mark all docs as processing
    async with get_db_session() as db:
        for doc in valid_docs:
            await doc_repo.update_status(db, doc["id"], "processing")

    # Convert each file using the shared MarkItDown extraction layer.
    conversion_results = {}
    for doc in valid_docs:
        stored_path = doc["stored_path"]
        fname = os.path.basename(stored_path)
        try:
            extraction = await asyncio.to_thread(
                extract_markdown_from_file,
                stored_path,
                user_id=kb_user_id,
            )
            conversion_results[fname] = {
                "status": "complete",
                "markdown": extraction.markdown,
                "converted_by": extraction.converted_by,
                "ocr_skipped_reason": extraction.ocr_skipped_reason,
            }
            logger.info(
                "Extraction succeeded for %s (%d chars, backend=%s, ocr_skipped=%s)",
                fname,
                extraction.char_count,
                extraction.converted_by,
                extraction.ocr_skipped_reason or "none",
            )
        except Exception as e:
            logger.error("Extraction failed for %s: %s", fname, e, exc_info=True)
            conversion_results[fname] = {"status": "failed", "error": f"Text extraction failed: {str(e)}"}


    # ---------------------------------------------------------------
    # Step 2: Process each document's markdown
    # ---------------------------------------------------------------
    # LLMFactory is retained for embeddings construction (model catalog path).
    # Chat LLMs (graph extraction) use resolve_and_build_llm_sync instead.
    llm_factory = LLMFactory()
    all_chunks = []
    # Passages kept per document as well as in one list: FAISS takes them all
    # together, while ``knowledge_document_chunks`` replaces one document's
    # passages at a time so a re-ingest cannot strand the others.
    chunks_by_document: List[dict] = []
    has_errors = False

    for filename, result in conversion_results.items():
       doc = filename_to_doc.get(filename)
       if not doc:
           logger.warning("No matching document for result: %s", filename)
           continue
       if result["status"] == "failed":
           async with get_db_session() as db:
               await doc_repo.update_status(
                   db, doc["id"], "failed", result.get("error", "Extraction failed")
               )
           has_errors = True
           continue
       markdown = result.get("markdown", "")
       if not markdown.strip():
           async with get_db_session() as db:
               await doc_repo.update_status(
                   db, doc["id"], "failed", "No text could be extracted from file"
               )
           has_errors = True
           continue
       # Split into chunks using plain scalar values (not detached ORM attributes)
       source_meta = {
           "source_filename": doc["original_filename"],
           "document_id": doc["id"],
           "knowledge_base_id": kb_id,
       }
       # Filtered once, here: every list downstream -- the vectors, the FAISS
       # write, the per-document slice -- is aligned against this one by
       # position, and a second filter anywhere would shift it by one.
       chunks = chunk_store.usable(
           split_markdown(
               markdown,
               chunk_size=kb_chunk_size,
               chunk_overlap=kb_chunk_overlap,
               source_metadata=source_meta,
           )
       )
       logger.info(
           "Document %s: %d chunks from %d chars",
           doc["original_filename"],
           len(chunks),
           len(markdown),
       )
       async with get_db_session() as db:
           await doc_repo.update_status(
               db,
               doc["id"],
               "completed",
               chunk_count=len(chunks),
               docling_markdown=markdown,
           )
       chunks_by_document.append(
           {
               "document_id": doc["id"],
               "filename": doc["original_filename"],
               "offset": len(all_chunks),
               "chunks": chunks,
           }
       )
       all_chunks.extend(chunks)

    # ---------------------------------------------------------------
    # Step 3: Embed once, then write Postgres and FAISS from the same vectors
    # ---------------------------------------------------------------
    if kb_processing_type in ("vector", "hybrid") and all_chunks:
        embeddings, vectors = await _embed_all_chunks(
            llm_factory, kb_embedding_model, kb_user_id, all_chunks, kb_id
        )

        # The durable copy first, and unconditionally. A passage with no vector
        # is still stored: it keeps the base readable, and it becomes
        # searchable again the moment the embedding credential resolves.
        #
        # The model recorded is the one that *did* the embedding, not the one
        # the base was configured with. Those differ whenever the platform
        # fallback was used, and the configured value is usually NULL -- so
        # writing it made every passage claim no model and left an index/query
        # mismatch undetectable.
        stored = await _store_passages(
            kb_id,
            chunks_by_document,
            vectors,
            _effective_embedding_model(embeddings, kb_embedding_model),
        )
        logger.info(
            "Stored %d passage(s) for KB %s in Postgres", stored, kb_id
        )

        if vectors is None:
            has_errors = True
        else:
            # The local cache. Its loss is not an ingest failure -- the durable
            # copy above is what retrieval falls back to on any replica.
            try:
                await asyncio.to_thread(
                    add_to_faiss_index_from_vectors,
                    kb_id, all_chunks, vectors, embeddings,
                )
            except Exception as exc:
                logger.warning(
                    "FAISS cache for KB %s could not be written (%s); retrieval "
                    "will use the stored passages",
                    kb_id, exc, exc_info=True,
                )

    # ---------------------------------------------------------------
    # Step 4: Extract graph into Neo4j (graph / hybrid)
    # ---------------------------------------------------------------
    if kb_processing_type in ("graph", "hybrid") and all_chunks:
        try:
            llm = _get_graph_llm_resolved(kb_user_id, kb_graph_model)
            graph_result = await asyncio.to_thread(extract_and_store_graph, kb_id, all_chunks, llm)
            logger.info(
                "Graph extraction for KB %s: %d nodes, %d rels",
                kb_id,
                graph_result.get("nodes_created", 0),
                graph_result.get("relationships_created", 0),
            )
        except Exception as e:
            logger.error("Graph extraction failed for KB %s: %s", kb_id, e, exc_info=True)
            # Fallback: retry with Azure OpenAI graph LLM
            try:
                logger.info("Retrying graph extraction with Azure OpenAI fallback LLM for KB %s", kb_id)
                llm = _get_azure_fallback_graph_llm()
                graph_result = await asyncio.to_thread(extract_and_store_graph, kb_id, all_chunks, llm)
                logger.info(
                    "Graph extraction (Azure fallback) for KB %s: %d nodes, %d rels",
                    kb_id,
                    graph_result.get("nodes_created", 0),
                    graph_result.get("relationships_created", 0),
                )
            except Exception as e2:
                logger.error("Graph extraction Azure fallback also failed for KB %s: %s", kb_id, e2, exc_info=True)
                has_errors = True

    # ---------------------------------------------------------------
    # Step 5: Update KB status
    # ---------------------------------------------------------------
    final_status = "synced" if not has_errors else "error"
    error_msg = "Some documents failed processing" if has_errors else None

    async with get_db_session() as db:
        await kb_repo.update_status(db, kb_id, final_status, error_msg)

    logger.info("KB %s processing finished with status: %s", kb_id, final_status)


async def _rehydrate_missing_files(
    kb_id: str, pending_docs: List[dict]
) -> List[dict]:
    """
    Return the documents that have a readable file, writing back any that do not.

    WHAT: Keeps documents whose ``stored_path`` exists, and for the rest writes
          ``knowledge_documents.content_bytes`` back to that path first.
    WHY:  ``stored_path`` points into the container's writable layer. After a
          restart, a redeploy, or on a replica that did not handle the upload,
          the file is simply not there — so reprocessing set the whole base to
          ``error`` and the only remaining recovery was to upload the document
          again. The bytes are in Postgres; this puts the file back.
    OUTPUT: The processable subset, in the input's order. Never raises: a
            document that cannot be restored is dropped and reported, exactly
            as a missing file was before.
    """
    from sqlalchemy import select

    from echolib.models.knowledge import KnowledgeDocument
    from echolib.repositories.base import safe_uuid

    def _readable(doc: dict) -> bool:
        return bool(doc.get("stored_path")) and os.path.exists(doc["stored_path"])

    missing = [doc for doc in pending_docs if not _readable(doc)]
    if not missing:
        return list(pending_docs)

    logger.info(
        "KB %s: %d document file(s) are not on this replica's disk; restoring "
        "them from stored bytes",
        kb_id, len(missing),
    )

    restored: List[dict] = []
    for doc in missing:
        stored_path = doc.get("stored_path")
        doc_uuid = safe_uuid(doc["id"])
        if not stored_path or doc_uuid is None:
            continue

        try:
            async with get_db_session() as db:
                row = (
                    await db.execute(
                        select(KnowledgeDocument.content_bytes).where(
                            KnowledgeDocument.id == doc_uuid
                        )
                    )
                ).first()
            content = row.content_bytes if row is not None else None
        except Exception:
            logger.warning(
                "Stored bytes for document %s could not be read", doc["id"],
                exc_info=True,
            )
            content = None

        if not content:
            logger.warning(
                "Document '%s' of KB %s has neither a file on disk nor stored "
                "bytes; it cannot be processed",
                doc.get("original_filename") or doc["id"], kb_id,
            )
            continue

        try:
            os.makedirs(os.path.dirname(stored_path), exist_ok=True)
            await asyncio.to_thread(_write_bytes, stored_path, content)
            restored.append(doc)
        except Exception:
            logger.warning(
                "Document '%s' of KB %s could not be restored to disk",
                doc.get("original_filename") or doc["id"], kb_id, exc_info=True,
            )

    if restored:
        logger.info("KB %s: restored %d document file(s)", kb_id, len(restored))

    # Input order, so conversion and status updates stay predictable.
    keep = {id(doc) for doc in restored}
    return [doc for doc in pending_docs if _readable(doc) or id(doc) in keep]


def _write_bytes(path: str, content: bytes) -> None:
    """Write a restored upload to disk. Synchronous, called off the loop."""
    with open(path, "wb") as handle:
        handle.write(content)


def _effective_embedding_model(
    embeddings: Any, configured: Optional[str]
) -> Optional[str]:
    """
    The model name to record against passages that were just embedded.

    Prefers what the client actually is over what the base was configured with,
    because those diverge exactly when it matters: the platform fallback embeds
    successfully under a model the base never named.
    """
    from apps.knowledge.embeddings import model_name_of

    return model_name_of(embeddings) or configured


async def _embed_all_chunks(
    llm_factory: LLMFactory,
    embedding_model: Optional[str],
    user_id: Optional[str],
    chunks: List[Any],
    kb_id: str,
):
    """
    Embed every passage once, with the existing credential cascade.

    WHAT: Resolves the base's embedding client and embeds all passages in one
          pass. Returns ``(embeddings_client, vectors)``.
    WHY:  Both stores are written from this one result. Embedding separately for
          each would double what the user's own credential is billed for an
          ingest.
    OUTPUT: ``vectors`` is ``None`` when neither the configured model nor the
            platform fallback could embed — the caller still stores the text.
    """
    texts = [chunk.page_content for chunk in chunks]

    # try:
    #     embeddings = _get_embeddings(llm_factory, embedding_model, user_id=user_id)
    #     vectors = await asyncio.to_thread(embeddings.embed_documents, texts)
    #     return embeddings, vectors

    try:
        embeddings = await asyncio.to_thread(
            _get_embeddings,
            llm_factory,
            embedding_model,
            user_id,
        )
        vectors = await asyncio.to_thread(
            embeddings.embed_documents,
            texts,
        )
        return embeddings, vectors
    except Exception as exc:
        logger.error(
            "Embedding failed for KB %s with the configured model: %s",
            kb_id, exc, exc_info=True,
        )

    try:
        logger.info("Retrying embeddings for KB %s with the Azure fallback", kb_id)
        embeddings = _get_azure_fallback_embeddings()
        vectors = await asyncio.to_thread(embeddings.embed_documents, texts)
        return embeddings, vectors
    except Exception as exc:
        logger.error(
            "Azure fallback embeddings also failed for KB %s: %s",
            kb_id, exc, exc_info=True,
        )

    return None, None


async def _recover_from_stored_markdown(
    kb_id: str,
    llm_factory: LLMFactory,
    embedding_model: Optional[str],
    user_id: Optional[str],
) -> int:
    """
    Rebuild a base's passages from the markdown Postgres already holds.

    WHAT: Re-splits, re-embeds and re-stores every document that has extracted
          text, and marks those documents ``completed``.
    WHY:  A base whose files are gone from disk is not a broken base — its text
          survived, and the text is what retrieval reads. This is the recovery
          that used to be impossible, and it needs neither the original file nor
          a re-upload.
    OUTPUT: How many passages were written. ``0`` means there really was nothing
            left, which is the only case that deserves an ``error`` status.
    """
    inputs = await chunk_store.aload_rebuild_inputs(kb_id)
    documents = inputs.get("documents") or []
    if not documents:
        return 0

    doc_repo = KnowledgeDocumentRepository()
    total = 0

    for entry in documents:
        chunks = chunk_store.usable(
            split_markdown(
                entry["markdown"],
                chunk_size=inputs["chunk_size"],
                chunk_overlap=inputs["chunk_overlap"],
                source_metadata={
                    "source_filename": entry["filename"],
                    "document_id": entry["document_id"],
                    "knowledge_base_id": kb_id,
                },
            )
        )
        if not chunks:
            continue

        _embeddings, vectors = await _embed_all_chunks(
            llm_factory, embedding_model, user_id, chunks, kb_id
        )
        rows = chunk_store.build_rows(
            chunks,
            vectors,
            embedding_model=_effective_embedding_model(_embeddings, embedding_model),
        )
        total += await chunk_store.astore_document_chunks(
            kb_id, entry["document_id"], entry["filename"], rows
        )

        async with get_db_session() as db:
            await doc_repo.update_status(
                db, entry["document_id"], "completed", chunk_count=len(chunks)
            )

    if total:
        logger.info(
            "KB %s recovered: %d passage(s) rebuilt from stored markdown "
            "without the original files",
            kb_id, total,
        )
    return total


async def _store_passages(
    kb_id: str,
    chunks_by_document: List[dict],
    vectors: Optional[List[List[float]]],
    embedding_model: Optional[str],
) -> int:
    """
    Write every document's passages to ``knowledge_document_chunks``.

    The vectors arrive as one flat list covering every passage in order, so
    each document takes the slice at its recorded offset. One document's write
    failing does not stop the others: each is replaced independently.
    """
    total = 0
    for entry in chunks_by_document:
        chunks = entry["chunks"]
        offset = entry["offset"]
        slice_ = (
            vectors[offset:offset + len(chunks)] if vectors is not None else None
        )
        rows = chunk_store.build_rows(
            chunks, slice_, embedding_model=embedding_model
        )
        total += await chunk_store.astore_document_chunks(
            kb_id, entry["document_id"], entry["filename"], rows
        )
    return total


def _is_credential_id(value: Optional[str]) -> bool:
    """Check if a value looks like a credential UUID (not a model name)."""
    if not value:
        return False
    try:
        from uuid import UUID
        UUID(value)
        return True
    except (ValueError, TypeError):
        return False


def _get_embeddings(
    llm_factory: LLMFactory,
    embedding_model: str = None,
    user_id: Optional[str] = None,
):
    """
    Get the embeddings client for a knowledge base.

    Delegates to :mod:`apps.knowledge.embeddings`, the module retrieval also
    uses. These were two separate implementations that resolved differently:
    this one had a platform Azure fallback and the retrieval one did not, so a
    base could be *indexed* by the fallback deployment and then *queried*
    against a deployment that does not exist. A vector index is only readable
    by the model that wrote it, so that divergence made the base unsearchable
    while every row in the database looked healthy.

    Raises ``ValueError`` when nothing at all resolves, so ``_embed_all_chunks``
    keeps its existing behaviour of storing the text unembedded rather than
    failing the ingest.
    """
    from apps.knowledge import embeddings as embedding_resolver

    client = embedding_resolver.resolve(
        embedding_model, user_id, llm_factory=llm_factory
    )
    if client is None:
        raise ValueError(
            "No embedding model could be resolved for this knowledge base "
            f"(configured embedding_model={embedding_model!r}). Select an "
            "embedding model for the knowledge base, or register a credential "
            "that provides one."
        )
    return client


def _get_llm_resolved(user_id: Optional[str] = None) -> Any:
    """
    Get a LangChain chat LLM via the centralized credential resolver.

    WHAT: Builds a LangChain BaseChatModel using the tiered resolution
          (user credential -> app credential -> platform fallback).
    WHY:  Replaces the previous LLMFactory path so that knowledge tasks
          use the same credential resolution as every other LLM consumer.
    INPUT: user_id -- KB owner's user ID (None triggers platform fallback).
    OUTPUT: A LangChain BaseChatModel instance.
    """
    return resolve_and_build_llm_sync(
        user_id=user_id,
        component="knowledge",
        temperature=0.1,
        allow_platform_fallback=True,
        framework="langchain",
    )


def _get_azure_fallback_embeddings():
    """
    Build an Azure OpenAI embeddings client as a platform fallback.

    Delegates to :func:`apps.knowledge.embeddings.platform_fallback_embeddings`
    so that ingestion and retrieval reach the *same* deployment. They used to
    read the same secrets from two copies of this function, and only ingestion
    had one at all -- which is how passages came to be written in one vector
    space and queried in another.

    Raises ``ValueError`` when no platform key is configured, preserving the
    contract ``_embed_all_chunks`` already handles.
    """
    from apps.knowledge.embeddings import platform_fallback_embeddings

    client = platform_fallback_embeddings()
    if client is None:
        raise ValueError(
            "FALLBACK_AZURE_OPENAI_API_KEY / AZURE_OPENAI_API_KEY not set — "
            "cannot use Azure fallback embeddings"
        )
    return client


def _get_azure_fallback_graph_llm():
    """
    Build an Azure OpenAI chat LLM as a platform fallback for graph extraction.

    Used when the user-selected graph model (e.g. Ollama) fails.
    Reads credentials from the FALLBACK_AZURE_OPENAI_* env vars first
    (matching the resolver pattern in llm_resolver.py), then falls back
    to AZURE_OPENAI_* for backward compatibility.
    """
    from langchain_openai import AzureChatOpenAI

    api_key = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_KEY")
        or secrets_provider.get_secret("AZURE_OPENAI_API_KEY", "")
    )
    endpoint = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
        or secrets_provider.get_secret("AZURE_OPENAI_ENDPOINT", "https://aiabotgpt.openai.azure.com/")
    )
    deployment = secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_DEPLOYMENT") or "gpt-4o-mini"
    api_version = secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_VERSION") or "2025-01-01-preview"
    if not api_key:
        raise ValueError("FALLBACK_AZURE_OPENAI_API_KEY / AZURE_OPENAI_API_KEY not set — cannot use Azure fallback graph LLM")

    logger.info("Building Azure OpenAI fallback graph LLM (%s)", deployment)
    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        api_key=api_key,
        azure_deployment=deployment,
        api_version=api_version,
        temperature=0.1,

    )

def _get_graph_llm_resolved(user_id: Optional[str] = None, graph_model: Optional[str] = None) -> Any:
    """
    Get a LangChain-compatible chat LLM for graph extraction via the resolver.

    WHAT: Builds a LangChain BaseChatModel through the centralized credential
          resolver (user -> app -> platform fallback tiers).
    WHY:  LLMGraphTransformer requires a BaseChatModel with
          ``with_structured_output``.  The resolver already returns a
          LangChain BaseChatModel (AzureChatOpenAI, ChatOpenAI, etc.) which
          satisfies this requirement.  This replaces the old LLMFactory +
          hardcoded Azure fallback path so graph extraction uses the same
          credential resolution as all other LLM consumers.
    INPUT: user_id -- KB owner's user ID (None triggers platform fallback).
           graph_model -- User-selected model name/credential_id for graph extraction.
    OUTPUT: A LangChain BaseChatModel instance suitable for graph extraction.
    """
    # If graph_model is a credential UUID, pass it as credential_id (not model name)
    credential_id = graph_model if _is_credential_id(graph_model) else None
    model_override = None if credential_id else graph_model

    logger.info(
        "Building graph extraction LLM via resolver for user_id=%s, model=%s, credential_id=%s",
        user_id, model_override, credential_id,
    )
    return resolve_and_build_llm_sync(
        user_id=user_id,
        credential_id=credential_id,
        component="knowledge",
        temperature=0.1,
        allow_platform_fallback=True,
        framework="langchain",
        model=model_override,
    )

def _extract_text_locally(file_path: str, file_ext: str) -> str:
   """
    Deprecated: local extractors are no longer used by the active KB pipeline.

   Extract text from a document using local Python libraries.
   Returns extracted text formatted as markdown.
   Supports: .pdf .docx .txt .md .csv .xlsx .xls .pptx
   Image files (.png .jpg .jpeg) are handled by the OCR connector — not this function.
   """
   if file_ext in (".png", ".jpg", ".jpeg"):
       raise ValueError(
           f"Image file '{os.path.basename(file_path)}' requires OCR processing. "
           "Set ocr_method on the knowledge base (markitdown)."
       )
   text = ""
   if file_ext == ".pdf":
       from pypdf import PdfReader
       reader = PdfReader(file_path)
       pages = []
       for i, page in enumerate(reader.pages):
           page_text = page.extract_text() or ""
           if page_text.strip():
               pages.append(f"## Page {i + 1}\n\n{page_text.strip()}")
       text = "\n\n".join(pages)
   elif file_ext == ".docx":
       
       import docx
       doc = docx.Document(file_path)
       paragraphs = []
       for para in doc.paragraphs:
           if para.text.strip():
               if para.style.name.startswith("Heading 1"):
                   paragraphs.append(f"# {para.text.strip()}")
               elif para.style.name.startswith("Heading 2"):
                   paragraphs.append(f"## {para.text.strip()}")
               elif para.style.name.startswith("Heading 3"):
                   paragraphs.append(f"### {para.text.strip()}")
               else:
                   paragraphs.append(para.text.strip())
       text = "\n\n".join(paragraphs)
   elif file_ext in (".txt", ".md", ".rst", ".log"):
       with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
           text = f.read()
   elif file_ext == ".csv":
       import csv
       rows = []
       with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
           reader = csv.reader(f)
           headers = next(reader, None)
           if headers:
               rows.append("| " + " | ".join(headers) + " |")
               rows.append("| " + " | ".join(["---"] * len(headers)) + " |")
           for row in reader:
               rows.append("| " + " | ".join(str(c) for c in row) + " |")
       text = "\n".join(rows)
   elif file_ext in (".xlsx", ".xls"):
       
       
       import openpyxl
       wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
       sheets = []
       for sheet_name in wb.sheetnames:
           ws = wb[sheet_name]
           rows = []
           for row in ws.iter_rows(values_only=True):
               if any(cell is not None for cell in row):
                   rows.append(
                       "| " + " | ".join(str(c) if c is not None else "" for c in row) + " |"
                   )
           if rows:
               sheets.append(f"## Sheet: {sheet_name}\n\n" + "\n".join(rows))
       text = "\n\n".join(sheets)
   elif file_ext == ".pptx":
       
       from pptx import Presentation
       prs = Presentation(file_path)
       slides = []
       for i, slide in enumerate(prs.slides, 1):
           slide_texts = []
           for shape in slide.shapes:
               if shape.has_text_frame:
                   for para in shape.text_frame.paragraphs:
                       if para.text.strip():
                           slide_texts.append(para.text.strip())
           if slide_texts:
               slides.append(f"## Slide {i}\n\n" + "\n\n".join(slide_texts))
       text = "\n\n".join(slides)
   else:
       try:
           with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
               text = f.read()
       except Exception:
           raise ValueError(
               f"Unsupported file type '{file_ext}'. "
               "Supported: .pdf .docx .txt .md .csv .xlsx .xls .pptx .png .jpg .jpeg"
           )
   if not text.strip():
       raise ValueError(
           f"No text could be extracted from '{os.path.basename(file_path)}'. "
           "The file may be empty, image-only, or password protected."
       )
   # PostgreSQL rejects null bytes (0x00) in text/varchar columns.
   # Some PDF extractors (pypdf) produce them from binary font mappings.
   text = text.replace("\x00", "")
   return text