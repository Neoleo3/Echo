"""
EchoAI Knowledge Base — Pydantic Schemas

Request / response models for knowledge base API endpoints.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class KnowledgeBaseCreate(BaseModel):
    """Request body when creating a knowledge base (files sent as multipart)."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(default="", max_length=2000)
    source_type: str = Field(default="file_upload")
    processing_type: str = Field(
        default="vector",
        pattern="^(vector|graph|hybrid)$",
        description="vector | graph | hybrid",
    )
    search_type: str = Field(
        default="similarity",
        pattern="^(similarity|hybrid)$",
        description="similarity | hybrid (vector + BM25)",
    )
    top_k: int = Field(default=5, ge=1, le=100)
    chunk_size: int = Field(default=1000, ge=100, le=10000)
    chunk_overlap: int = Field(default=200, ge=0, le=5000)
    embedding_model: Optional[str] = Field(
        default=None,
        description="Model ID from llm_provider.json for embeddings. None = system default.",
    )
    graph_model: Optional[str] = Field(
        default=None,
        description="Model ID from llm_provider.json for graph extraction LLM. None = system default.",
    )
    vector_weight: float = Field(default=0.5, ge=0.0, le=1.0)
    keyword_weight: float = Field(default=0.5, ge=0.0, le=1.0)
    ocr_method: Optional[str] = Field(
        default=None,
        pattern="^(markitdown)$",
        description="Extraction backend: markitdown. None = system default.",
    )


class KnowledgeBaseUpdate(BaseModel):
    """Request body for updating a knowledge base."""

    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    description: Optional[str] = Field(default=None, max_length=2000)
    processing_type: Optional[str] = Field(
        default=None, pattern="^(vector|graph|hybrid)$"
    )
    search_type: Optional[str] = Field(
        default=None, pattern="^(similarity|hybrid)$"
    )
    top_k: Optional[int] = Field(default=None, ge=1, le=100)
    chunk_size: Optional[int] = Field(default=None, ge=100, le=10000)
    chunk_overlap: Optional[int] = Field(default=None, ge=0, le=5000)
    embedding_model: Optional[str] = None
    graph_model: Optional[str] = None
    vector_weight: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    keyword_weight: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    ocr_method: Optional[str] = Field(
        default=None,
        pattern="^(markitdown)$",
    )


class KnowledgeSearchRequest(BaseModel):
    """Request body for searching a knowledge base."""

    query: str = Field(..., min_length=1)
    top_k: Optional[int] = Field(default=None, ge=1, le=100, description="Override KB default")
    search_type: Optional[str] = Field(
        default=None,
        pattern="^(similarity|hybrid)$",
        description="Override KB default",
    )


class KnowledgeMultiSearchRequest(BaseModel):
    """Request body for searching across multiple knowledge bases."""

    query: str = Field(..., min_length=1)
    kb_ids: List[str] = Field(..., min_length=1)
    top_k: Optional[int] = Field(default=None, ge=1, le=100)
    search_type: Optional[str] = Field(
        default=None, pattern="^(similarity|hybrid)$"
    )


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class DocumentResponse(BaseModel):
    """Response model for a single document."""

    id: str
    knowledge_base_id: str
    original_filename: str
    file_size: Optional[int] = None
    file_type: Optional[str] = None
    chunk_count: int = 0
    processing_status: str
    error_message: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class KnowledgeBaseResponse(BaseModel):
    """Response model for a knowledge base."""

    id: str
    name: str
    description: Optional[str] = ""
    source_type: str = "file_upload"
    processing_type: str
    status: str
    error_message: Optional[str] = None
    search_type: str
    top_k: int
    chunk_size: int
    chunk_overlap: int
    embedding_model: Optional[str] = None
    graph_model: Optional[str] = None
    vector_weight: float
    keyword_weight: float
    ocr_method: Optional[str] = None
    document_count: int = 0
    documents: List[DocumentResponse] = []
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class KnowledgeBaseListResponse(BaseModel):
    """Paginated list of knowledge bases."""

    items: List[KnowledgeBaseResponse]
    total: int


class KnowledgeStatsResponse(BaseModel):
    """Global stats for the dashboard cards."""

    total_sources: int = 0
    synced: int = 0
    processing: int = 0
    errors: int = 0
    pending: int = 0
    total_documents: int = 0
    total_chunks: int = 0


class KBStatsResponse(BaseModel):
    """Stats for a single knowledge base."""

    kb_id: str
    name: str
    status: str
    processing_type: str
    document_count: int = 0
    chunk_count: int = 0
    completed_documents: int = 0
    failed_documents: int = 0


class SearchResultItem(BaseModel):
    """A single search result."""

    content: str
    score: float = 0.0
    metadata: Dict[str, Any] = {}
    source_document: Optional[str] = None
    chunk_index: Optional[int] = None
    knowledge_base_id: Optional[str] = None
    knowledge_base_name: Optional[str] = None


class KnowledgeSearchResponse(BaseModel):
    """Response from a knowledge base search."""

    query: str
    results: List[SearchResultItem]
    total_results: int
    search_type: str
    top_k: int


class ProcessingStatusResponse(BaseModel):
    """Processing status for a knowledge base."""

    kb_id: str
    status: str
    error_message: Optional[str] = None
    total_documents: int = 0
    completed_documents: int = 0
    failed_documents: int = 0
    processing_documents: int = 0
    pending_documents: int = 0
    documents: List[DocumentResponse] = []
