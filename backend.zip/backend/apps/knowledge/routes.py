"""
EchoAI Knowledge Base — API Routes

All endpoints are user-scoped via resolve_user_id().
Prefix: /knowledge
"""

import logging
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
)
from sqlalchemy import select

from echolib.database import get_db_session
from echolib.di import container
from echolib.models.user_llm_credential import UserLlmCredential
from echolib.security import get_current_user, require_admin_or_above, require_user, resolve_user_id
from echolib.types import UserContext

from apps.knowledge.schemas import (
    DocumentResponse,
    KBStatsResponse,
    KnowledgeBaseCreate,
    KnowledgeBaseListResponse,
    KnowledgeBaseResponse,
    KnowledgeBaseUpdate,
    KnowledgeMultiSearchRequest,
    KnowledgeSearchRequest,
    KnowledgeSearchResponse,
    KnowledgeStatsResponse,
    ProcessingStatusResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/knowledge", tags=["knowledge"])

# Maximum file size for KB uploads (50 MB per file)
_KB_MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024


# ---------------------------------------------------------------------------
# DI Helpers
# ---------------------------------------------------------------------------

def _get_service():
    from apps.knowledge.service import KnowledgeService
    return container.resolve("knowledge.service")


# ---------------------------------------------------------------------------
# Models (for embedding dropdown)
# ---------------------------------------------------------------------------


@router.get("/models")
async def list_available_models(
    user: UserContext = Depends(get_current_user),
):
    """
    Return available models for the knowledge base embedding/graph model dropdowns.

    Returns the same response shape **and the same rows** as GET /LLMs/models/list
    so the frontend can use a consistent contract across all pages (apps,
    workflows, knowledge).

    Platform ("system user") credentials are included alongside the caller's own.
    This endpoint used to select on ``user_id == caller`` alone while
    ``/LLMs/models/list`` selected on ``caller OR system`` — so an account that
    had registered no credential of its own saw models on every page except this
    one, created a knowledge base with no usable embedding model, and ingestion
    then failed in ``_get_embeddings`` with "No default model configured". The
    divergence looked like a role problem because it split on whoever happened to
    own a credential.

    Response:
        {
            "models": [{"id": ..., "name": ..., "provider": ..., ...}],
            "providers": [{"id": ..., "name": ..., "known_models": [...], ...}]
        }
    """
    from sqlalchemy import case, or_

    from echolib.credential_resolver import SYSTEM_USER_ID, is_embedding_credential
    from echolib.llm_factory import LLMFactory

    user_id = resolve_user_id(user)
    user_uuid = UUID(user_id)
    system_uuid = UUID(SYSTEM_USER_ID)

    # ---- Fetch user + platform credentials from DB (same as /LLMs/models/list) ----
    models: List[Dict[str, Any]] = []
    async with get_db_session() as db:
        stmt = (
            select(UserLlmCredential)
            .where(
                or_(
                    UserLlmCredential.user_id == user_uuid,
                    UserLlmCredential.user_id == system_uuid,
                ),
                UserLlmCredential.is_deleted.is_(False),
            )
            .order_by(
                # System credentials first, then the user's own — identical
                # ordering to /LLMs/models/list so the two pickers agree.
                case(
                    (UserLlmCredential.user_id == system_uuid, 0),
                    else_=1,
                ),
                UserLlmCredential.created_at.asc(),
            )
        )
        result = await db.execute(stmt)
        rows = result.scalars().all()

        # for row in rows:
        #     meta = row.config_metadata or {}
        #     model_name = meta.get("model_name", "") or row.credential_name or ""
        #     models.append({
        #         "id": str(row.credential_id),
        #         "name": row.credential_name,
        #         "provider": row.provider,
        #         "model_name": model_name,
        #         "is_default": row.is_default,
        #         "is_embedding": "embed" in model_name.lower(),
        #         "description": meta.get("description", ""),
        #         "icon": meta.get("icon", "default"),
        #     })

        for row in rows:
            meta = row.config_metadata or {}
            model_name = meta.get("model_name", "") or row.credential_name or ""
            canonical_model_id = meta.get("model_id", "") or str(row.credential_id)
            models.append({
                "id": str(row.credential_id),
                "model_id": canonical_model_id,
                "canonical_model_id": canonical_model_id,
                "catalog_type": "credential",
                "name": row.credential_name,
                "provider": row.provider,
                "model_name": model_name,
                "is_default": row.is_default,
                "is_default_embedding": row.is_default_embedding,
                "is_embedding": is_embedding_credential(meta, row.credential_name),
                "description": meta.get("description", ""),
                "icon": meta.get("icon", "default"),
                # Additive. Lets the picker label a platform-provided model and
                # lets the caller tell "I registered this" from "this came with
                # the platform" without a second request.
                "is_system": row.user_id == system_uuid,
            })

    # ---- Provider catalog (same as GET /LLMs/models/list) ----
    response: Dict[str, Any] = {"models": models}

    factory = LLMFactory()
    providers = factory.config_loader.get_providers()
    if providers:
        response["providers"] = providers

    return response


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


@router.post("/", response_model=KnowledgeBaseResponse)
async def create_knowledge_base(
    name: str = Form(...),
    description: str = Form(""),
    source_type: str = Form("file_upload"),
    processing_type: str = Form("vector"),
    search_type: str = Form("similarity"),
    top_k: int = Form(5),
    chunk_size: int = Form(1000),
    chunk_overlap: int = Form(200),
    embedding_model: Optional[str] = Form(None),
    graph_model: Optional[str] = Form(None),
    vector_weight: float = Form(0.5),
    keyword_weight: float = Form(0.5),
    ocr_method: Optional[str] = Form(None),
    files: List[UploadFile] = File(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Create a new knowledge base with uploaded files.

    Files are saved to disk and processing is dispatched as an asyncio background task.
    Extraction is performed by the shared MarkItDown pipeline.
    The KB status will be 'pending' initially, then 'processing', then 'synced' or 'error'.
    """
    # Validate file sizes (50 MB per file)
    for f in files:
        if f.size is not None and f.size > _KB_MAX_FILE_SIZE_BYTES:
            actual_mb = f.size / (1024 * 1024)
            raise HTTPException(
                status_code=413,
                detail=(
                    f"File '{f.filename}' exceeds the 50 MB limit "
                    f"({actual_mb:.1f} MB)."
                ),
            )

    svc = _get_service()
    user_id = resolve_user_id(user)

    data = KnowledgeBaseCreate(
        name=name,
        description=description,
        source_type=source_type,
        processing_type=processing_type,
        search_type=search_type,
        top_k=top_k,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        embedding_model=embedding_model,
        graph_model=graph_model,
        vector_weight=vector_weight,
        keyword_weight=keyword_weight,
        ocr_method=ocr_method,
    )

    result = await svc.create_knowledge_base(user_id, data, files)
    return result


@router.get("/", response_model=KnowledgeBaseListResponse)
async def list_knowledge_bases(
    page: int = Query(1, ge=1, description="Page number (1-based)"),
    page_size: int = Query(20, ge=1, le=1000, description="Items per page"),
    search: Optional[str] = Query(None, description="Search term for knowledge base name"),
    user: UserContext = Depends(require_user),
):
    """List knowledge bases for the current user with pagination and optional search."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    try:
        return await svc.list_knowledge_bases_paginated(
            user_id,
            page=page,
            page_size=page_size,
            search=search,
        )
    except Exception:
        logger.exception("Failed to list knowledge bases for user %s", user_id)
        return {
            "page": page,
            "page_size": page_size,
            "total": 0,
            "items": [],
        }


@router.get("/stats", response_model=KnowledgeStatsResponse)
async def get_global_stats(
    user: UserContext = Depends(get_current_user),
):
    """Get global knowledge base stats for the dashboard."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    return await svc.get_global_stats(user_id)


@router.post("/search", response_model=KnowledgeSearchResponse)
async def search_multiple_kbs(
    request: KnowledgeMultiSearchRequest,
    user: UserContext = Depends(get_current_user),
):
    """Search across multiple knowledge bases."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    return await svc.search_multiple(
        user_id,
        query=request.query,
        kb_ids=request.kb_ids,
        top_k=request.top_k,
        search_type=request.search_type,
    )


@router.get("/{kb_id}", response_model=KnowledgeBaseResponse)
async def get_knowledge_base(
    kb_id: str,
    user: UserContext = Depends(get_current_user),
):
    """Get a single knowledge base with its documents."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.get_knowledge_base(kb_id, user_id)
    if not result:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


@router.put("/{kb_id}", response_model=KnowledgeBaseResponse)
async def update_knowledge_base(
    kb_id: str,
    data: KnowledgeBaseUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update knowledge base metadata and configuration."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.update_knowledge_base(kb_id, user_id, data)
    if not result:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


@router.delete("/{kb_id}")
async def delete_knowledge_base(
    kb_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Soft delete a knowledge base and clean up indexes."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    deleted = await svc.delete_knowledge_base(kb_id, user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return {"status": "deleted", "kb_id": kb_id}


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------


@router.post("/{kb_id}/documents", response_model=List[DocumentResponse])
async def add_documents(
    kb_id: str,
    files: List[UploadFile] = File(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """Upload additional files to an existing knowledge base."""
    # Validate file sizes (50 MB per file)
    for f in files:
        if f.size is not None and f.size > _KB_MAX_FILE_SIZE_BYTES:
            actual_mb = f.size / (1024 * 1024)
            raise HTTPException(
                status_code=413,
                detail=(
                    f"File '{f.filename}' exceeds the 50 MB limit "
                    f"({actual_mb:.1f} MB)."
                ),
            )

    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.add_documents(kb_id, user_id, files)
    if result is None:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


@router.get("/{kb_id}/documents", response_model=List[DocumentResponse])
async def list_documents(
    kb_id: str,
    user: UserContext = Depends(get_current_user),
):
    """List all documents in a knowledge base."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.list_documents(kb_id, user_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


@router.delete("/{kb_id}/documents/{doc_id}")
async def delete_document(
    kb_id: str,
    doc_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Remove a document from a knowledge base."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    deleted = await svc.delete_document(kb_id, doc_id, user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"status": "deleted", "doc_id": doc_id}


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------


@router.post("/{kb_id}/reprocess")
async def reprocess_knowledge_base(
    kb_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Trigger full reprocessing of a knowledge base (re-parse, re-chunk, re-index)."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    success = await svc.reprocess_knowledge_base(kb_id, user_id)
    if not success:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return {"status": "reprocessing", "kb_id": kb_id}


@router.get("/{kb_id}/status", response_model=ProcessingStatusResponse)
async def get_processing_status(
    kb_id: str,
    user: UserContext = Depends(get_current_user),
):
    """Get processing status with per-document breakdown."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.get_processing_status(kb_id, user_id)
    if not result:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@router.post("/{kb_id}/search", response_model=KnowledgeSearchResponse)
async def search_knowledge_base(
    kb_id: str,
    request: KnowledgeSearchRequest,
    user: UserContext = Depends(get_current_user),
):
    """Search a specific knowledge base. Returns results with source documents."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.search_knowledge_base(
        kb_id, user_id, request.query, request.top_k, request.search_type
    )
    if not result:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


@router.get("/{kb_id}/stats", response_model=KBStatsResponse)
async def get_kb_stats(
    kb_id: str,
    user: UserContext = Depends(get_current_user),
):
    """Get statistics for a specific knowledge base."""
    svc = _get_service()
    user_id = resolve_user_id(user)
    result = await svc.get_kb_stats(kb_id, user_id)
    if not result:
        raise HTTPException(status_code=404, detail="Knowledge base not found")
    return result
