"""
Knowledge-base search over Postgres, for when the local index is not there.

WHAT: The same two strategies ``retriever`` offers — vector similarity and
      vector+keyword hybrid — computed over ``knowledge_document_chunks``
      instead of over a FAISS index on the container's disk.
WHY:  The FAISS index is written by one replica to its own filesystem and is
      gone after any restart. Every knowledge base on this platform therefore
      stopped being searchable at some point without a single database row
      changing. Passages are now in Postgres; this module is the search over
      them.

It is not a replacement. ``retriever`` still uses FAISS whenever an index is
present on the replica handling the request — that path is faster and is
unchanged. This is what happens instead of returning nothing.

**Results are shaped exactly like the FAISS ones.** Same keys, same 0-1 score
range, same ``source_document``. Callers -- the orchestration pipeline's Phase 2
retrieval, the agent's ``kb__`` tool -- cannot tell which store answered, which
is the point: the fallback must not be a second behaviour to reason about.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document

logger = logging.getLogger(__name__)

# Reciprocal Rank Fusion constant. 60 is the value LangChain's EnsembleRetriever
# uses, so hybrid results rank the same way they did over FAISS.
RRF_K = 60


def _as_document(row: Dict[str, Any]) -> Document:
    """One stored passage as the ``Document`` the keyword retriever expects."""
    return Document(
        page_content=str(row.get("content") or ""),
        metadata={
            "source_filename": row.get("source_name") or "",
            "document_id": row.get("document_id") or "",
            "knowledge_base_id": row.get("knowledge_base_id") or "",
            "chunk_index": row.get("chunk_index"),
            "heading": row.get("heading") or "",
        },
    )


def _result(row: Dict[str, Any], kb_id: str, score: float) -> Dict[str, Any]:
    """One retrieval result, in the shape the FAISS path returns."""
    return {
        "content": str(row.get("content") or ""),
        "score": round(float(score), 4),
        "metadata": {
            "source_filename": row.get("source_name") or "",
            "document_id": row.get("document_id") or "",
            "chunk_index": row.get("chunk_index"),
            "heading": row.get("heading") or "",
            "search_source": "postgres",
        },
        "source_document": row.get("source_name") or "",
        "chunk_index": row.get("chunk_index"),
        "knowledge_base_id": kb_id,
    }


def chunk_store_indexed_model(kb_id: str) -> Optional[str]:
    """The model this base's passages were indexed with, for diagnostics only."""
    from apps.knowledge import chunk_store

    try:
        return chunk_store.indexed_embedding_model(kb_id)
    except Exception:
        return None


def keyword_rank(
    rows: List[Dict[str, Any]], query: str, top_k: int
) -> List[tuple]:
    """
    BM25 ranking over stored passages, with no embedding model involved.

    WHAT: ``[(row_index, score)]`` best first, scores normalized to 0-1.
    WHY:  Vector search needs an embedding model to be reachable. When it is
          not -- a deleted credential, an endpoint that 404s, a base indexed by
          a model this user cannot reach -- the passages are still right here in
          Postgres and still contain the answer. Returning nothing in that
          situation is indistinguishable from an empty knowledge base, and it is
          what made an attached PDF look like it had never been uploaded.
    OUTPUT: Empty only when there is genuinely nothing to rank or ``rank_bm25``
            is unavailable.

    Lexical matching is weaker than dense retrieval on paraphrased questions and
    stronger on identifiers, invoice numbers and internal names. It is a real
    answer, not a placeholder.
    """
    if not rows or not (query or "").strip():
        return []

    try:
        from langchain_community.retrievers import BM25Retriever
    except Exception:
        logger.warning(
            "Keyword ranking is unavailable (rank_bm25 is not installed)",
            exc_info=True,
        )
        return []

    try:
        documents = [_as_document(row) for row in rows]
        by_content: Dict[str, int] = {}
        for index, document in enumerate(documents):
            by_content.setdefault(document.page_content, index)

        retriever = BM25Retriever.from_documents(documents, k=max(1, int(top_k)))
        ordered = retriever.invoke(query)
    except Exception:
        logger.warning("Keyword ranking failed", exc_info=True)
        return []

    # BM25Retriever returns rank order without scores. Rank position is the only
    # signal available, so it is turned into a descending 0-1 score the same way
    # the FAISS hybrid path already derives one.
    total = max(len(ordered), 1)
    ranked: List[tuple] = []
    for position, document in enumerate(ordered):
        index = by_content.get(document.page_content)
        if index is not None:
            ranked.append((index, round(1.0 - (position / total), 4)))
    return ranked


def load_searchable_rows(
    kb_id: str,
    embeddings: Optional[Any] = None,
    *,
    allow_rebuild: bool = True,
) -> List[Dict[str, Any]]:
    """
    Every stored passage of a knowledge base, rebuilding them if there are none.

    WHAT: Reads ``knowledge_document_chunks``; when the base has no rows and an
          embeddings client is available, reconstructs them from the markdown
          Postgres already holds and reads again.
    WHY:  Bases ingested before passages became durable have no rows. Rebuilding
          on first use is what makes this fix apply to knowledge bases that
          already exist — including ones whose original file is no longer on
          any disk — instead of only to ones uploaded from now on.
    OUTPUT: Rows ready for ranking, possibly empty. Never raises.

    The rebuild happens at most once per base: the next call finds the rows.
    """
    from apps.knowledge import chunk_store

    rows = chunk_store.load_rows(kb_id)

    if rows and allow_rebuild and embeddings is not None:
        # Passages exist but none carry a vector: they were stored during a
        # window when no embedding model resolved. Now one does, so re-embed
        # rather than leaving the base permanently keyword-only -- the rebuild
        # otherwise only ever runs when there are *no* rows, and these rows
        # would keep it from ever running again.
        if not any(row.get("embedding") for row in rows):
            logger.info(
                "Knowledge base %s holds %d readable but unembedded passage(s) "
                "and an embedding model is now available; re-embedding them",
                kb_id, len(rows),
            )
            if chunk_store.rebuild_from_markdown(kb_id, embeddings) > 0:
                return chunk_store.load_rows(kb_id)
        return rows

    if rows or not allow_rebuild:
        return rows

    logger.info(
        "Knowledge base %s has no stored passages; rebuilding them from its "
        "extracted markdown",
        kb_id,
    )
    if chunk_store.rebuild_from_markdown(kb_id, embeddings) <= 0:
        return []
    return chunk_store.load_rows(kb_id)


def similarity_search(
    kb_id: str,
    query: str,
    embeddings: Any,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Vector similarity over the stored passages.

    Cosine similarity, which is a dot product because both sides are unit
    vectors — the same maths ``apps/markitdown/similarity`` already performs for
    agent attachments and chat uploads. Scores arrive in 0-1 without the
    reciprocal-and-rescale step the FAISS path needs, because FAISS returns
    squared L2 distances and this returns similarity directly.
    """
    from apps.markitdown.similarity import rank

    rows = load_searchable_rows(kb_id, embeddings)
    if not rows:
        logger.warning("Knowledge base %s has no stored passages", kb_id)
        return []

    top_k = max(1, int(top_k))

    def _keyword_fallback(reason: str) -> List[Dict[str, Any]]:
        """
        Answer from the passages themselves when vector ranking cannot.

        The text is present and was extracted successfully; only the *ranking*
        is degraded. Returning ``[]`` here reported the base as empty, and the
        model then told the user their document contained nothing relevant.
        """
        ranked = keyword_rank(rows, query, top_k)
        if not ranked:
            logger.warning(
                "Knowledge base %s: %s, and keyword ranking returned nothing",
                kb_id, reason,
            )
            return []
        logger.warning(
            "Knowledge base %s: %s — answering from keyword search over its "
            "%d stored passage(s)",
            kb_id, reason, len(rows),
        )
        results = [_result(rows[index], kb_id, score) for index, score in ranked]
        for result in results:
            result["metadata"]["search_source"] = "postgres_keyword"
        return results

    if embeddings is None:
        return _keyword_fallback("no embedding model is available")

    try:
        query_vector = embeddings.embed_query(query)
    except Exception:
        logger.warning(
            "The query could not be embedded for knowledge base %s", kb_id,
            exc_info=True,
        )
        return _keyword_fallback("the query could not be embedded")

    ranked = rank(query_vector, rows, top_k=top_k)
    if not ranked:
        indexed = chunk_store_indexed_model(kb_id)
        return _keyword_fallback(
            "no passage shares the query's dimensionality, so it was indexed "
            f"with a different model ({indexed or 'unrecorded'})"
        )

    # A dot product of unit vectors is in [-1, 1]; the callers and the prompt
    # both read scores as 0-1, so negatives are clamped rather than rescaled.
    # Rescaling would make the best of a set of poor matches look perfect.
    return [
        _result(rows[index], kb_id, max(0.0, score))
        for index, score in ranked
    ]


def hybrid_search(
    kb_id: str,
    query: str,
    embeddings: Any,
    top_k: int = 5,
    vector_weight: float = 0.5,
    keyword_weight: float = 0.5,
) -> List[Dict[str, Any]]:
    """
    Vector similarity fused with BM25 keyword matching over the same passages.

    Reciprocal Rank Fusion with the base's own weights, matching what
    ``EnsembleRetriever`` did over FAISS — so a base tuned for keyword-heavy
    documents keeps that tuning when it is answered from Postgres.
    """
    from apps.markitdown.similarity import rank

    rows = load_searchable_rows(kb_id, embeddings)
    if not rows:
        logger.warning("Knowledge base %s has no stored passages", kb_id)
        return []

    fused: Dict[int, float] = {}

    if embeddings is None:
        # Not an error worth a traceback: the keyword half below is a complete
        # answer on its own, which is the whole reason this path is split in two.
        logger.info(
            "No embedding model for knowledge base %s; hybrid search will use "
            "keyword matching alone",
            kb_id,
        )
    else:
        try:
            query_vector = embeddings.embed_query(query)
            for position, (index, _score) in enumerate(
                rank(query_vector, rows, top_k=len(rows))
            ):
                fused[index] = fused.get(index, 0.0) + vector_weight / (RRF_K + position + 1)
        except Exception:
            logger.warning(
                "Vector half of the hybrid search failed for knowledge base %s; "
                "continuing with keyword matching alone",
                kb_id, exc_info=True,
            )

    try:
        from langchain_community.retrievers import BM25Retriever

        documents = [_as_document(row) for row in rows]
        by_content = {document.page_content: index for index, document in enumerate(documents)}
        retriever = BM25Retriever.from_documents(documents, k=max(1, int(top_k)))
        for position, document in enumerate(retriever.invoke(query)):
            index = by_content.get(document.page_content)
            if index is not None:
                fused[index] = fused.get(index, 0.0) + keyword_weight / (RRF_K + position + 1)
    except Exception:
        logger.warning(
            "Keyword half of the hybrid search failed for knowledge base %s; "
            "continuing with vector matching alone",
            kb_id, exc_info=True,
        )

    if not fused:
        return []

    ordered = sorted(fused.items(), key=lambda pair: pair[1], reverse=True)[
        : max(1, int(top_k))
    ]

    # RRF scores are small and have no absolute meaning, so they are normalized
    # to 0-1 the same way the FAISS hybrid path derived a score from rank.
    best = ordered[0][1] or 1.0
    return [_result(rows[index], kb_id, score / best) for index, score in ordered]


def has_passages(kb_id: str) -> bool:
    """Whether this base has any stored passage, without loading them."""
    from apps.knowledge import chunk_store

    return chunk_store.count_rows(kb_id) > 0


__all__ = [
    "has_passages",
    "hybrid_search",
    "keyword_rank",
    "load_searchable_rows",
    "similarity_search",
]
