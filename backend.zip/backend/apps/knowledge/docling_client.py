"""
EchoAI Knowledge Base — Docling API Client

Async HTTP client for the Docling document-to-markdown conversion service.
Always uses batch convert for consistency, even for single files.
"""

import asyncio
import logging
import os
from typing import Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)

# Configurable via environment
DOCLING_API_URL = os.getenv("DOCLING_API_URL", "http://10.188.100.130:8122")
DOCLING_POLL_INTERVAL = int(os.getenv("DOCLING_POLL_INTERVAL", "5"))  # seconds
DOCLING_TIMEOUT = int(os.getenv("DOCLING_TIMEOUT", "600"))  # 10 minute total timeout


class DoclingClient:
    """
    Async client for the Docling document conversion API.

    Uses batch convert endpoint for all conversions.
    Polls for completion and returns markdown per file.
    """

    def __init__(self, base_url: str = None):
        self.base_url = (base_url or DOCLING_API_URL).rstrip("/")
        self.poll_interval = DOCLING_POLL_INTERVAL
        self.timeout = DOCLING_TIMEOUT

        logger.info(
            "DoclingClient initialized with base_url=%s",
            self.base_url,
        )

    async def health_check(self) -> bool:
        """Check if the Docling service is reachable."""
        try:
            logger.info("Docling base URL: %s", self.base_url)

            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{self.base_url}/health")

                logger.info(
                "Docling health response | status=%s | body=%s",
                resp.status_code,
                resp.text,
            )

            return resp.status_code == 200
        except Exception:
            logger.exception("Docling health check failed")
            return False
  
    async def convert_files(
        self, file_paths: List[str]
    ) -> Dict[str, Dict[str, str]]:
        """
        Convert multiple files to markdown via Docling batch API.

        Args:
            file_paths: List of absolute file paths to convert.

        Returns:
            Dict mapping filename → {"status": "completed"|"failed", "markdown": "...", "error": "..."}
        """
        if not file_paths:
            return {}

        results: Dict[str, Dict[str, str]] = {}

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(self.timeout)) as client:
                # Build multipart file upload — wrap in try/finally so handles
                # are closed even if open() fails mid-loop on a later file.
                files = []
                try:
                    for fp in file_paths:
                        filename = os.path.basename(fp)
                        files.append(
                            ("files", (filename, open(fp, "rb"), "application/octet-stream"))
                        )

                    # Submit batch conversion
                    logger.info(
                        "Submitting batch conversion for %d files to Docling",
                        len(file_paths),
                    )
                    resp = await client.post(
                        f"{self.base_url}/batch/convert", files=files
                    )
                    resp.raise_for_status()
                    batch_data = resp.json()
                    job_id = batch_data["job_id"]
                    logger.info("Docling batch job created: %s", job_id)
                finally:
                    # Ensure ALL opened file handles are closed
                    for _, (_, fh, _) in files:
                        fh.close()

                # Poll for completion
                elapsed = 0
                job_status = "unknown"
                while elapsed < self.timeout:
                    await asyncio.sleep(self.poll_interval)
                    elapsed += self.poll_interval

                    status_resp = await client.get(
                        f"{self.base_url}/batch/status/{job_id}"
                    )
                    status_resp.raise_for_status()
                    status_data = status_resp.json()

                    job_status = status_data.get("status", "")
                    logger.info(
                        "Docling job %s status: %s (completed=%s, failed=%s)",
                        job_id,
                        job_status,
                        status_data.get("completed_files", 0),
                        status_data.get("failed_files", 0),
                    )

                    if job_status in ("completed", "failed"):
                        break

                # If we exited the loop due to timeout, fail all files
                if job_status not in ("completed", "failed"):
                    logger.error(
                        "Docling job %s times out after %ds - marking all files failed",
                        job_id, self.timeout,
                    )
                    for fp in file_paths:
                        filename = os.path.basename(fp)
                        results[filename] = {
                            "status": "failed",
                            "error": f"Docling conversion timed out after {self.timeout}s",
                        }
                    return results

                # Retrieve results
                result_resp = await client.get(
                    f"{self.base_url}/batch/result/{job_id}"
                )
                result_resp.raise_for_status()
                result_data = result_resp.json()

                for filename, file_result in result_data.get("results", {}).items():
                    file_status = file_result.get("status", "failed")
                    if file_status == "completed":
                        results[filename] = {
                            "status": "completed",
                            "markdown": file_result.get("markdown", ""),
                        }
                    else:
                        results[filename] = {
                            "status": "failed",
                            "error": file_result.get("error", "Unknown error"),
                        }

        except httpx.HTTPError as e:
            logger.error("Docling HTTP error: %s", e)
            # Mark all files as failed
            for fp in file_paths:
                filename = os.path.basename(fp)
                if filename not in results:
                    results[filename] = {
                        "status": "failed",
                        "error": f"Docling API error: {str(e)}",
                    }
        except Exception as e:
            logger.error("Docling conversion error: %s", e, exc_info=True)
            for fp in file_paths:
                filename = os.path.basename(fp)
                if filename not in results:
                    results[filename] = {
                        "status": "failed",
                        "error": f"Unexpected error: {str(e)}",
                    }

        return results
