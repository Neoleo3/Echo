"""
The durable half of knowledge-base retrieval.

WHAT: Persistence and loading of ``knowledge_document_chunks`` — the passages
      of a knowledge base and their embeddings — plus the rebuild that
      reconstructs them from the markdown Postgres already holds.
WHY:  A knowledge base's passages used to exist only inside a FAISS index on
      the container's own disk. That disk does not survive a restart and is
      invisible to every other replica, so an attached knowledge base stopped
      being searchable without anything in the database changing. The
      Application Context Ledger asked the filesystem, was told there was no
      index, and reported the base ``UNAVAILABLE`` — so retrieval was skipped
      and no ``kb__`` tool was bound, and the chat answered as though the base
      were empty.

      Passages now live in Postgres, where ``knowledge_documents.docling_markdown``
      already lived. FAISS is still written and still read when it is present:
      it is a warm local cache, no longer the system of record.

THE REBUILD
-----------
A base ingested before this shipped has no rows in the new table and, after any
restart, no index either — but its extracted markdown is in Postgres and always
was. :func:`rebuild_from_markdown` re-splits and re-embeds from that, once, on
the first search that needs it. That is what makes the fix apply to knowledge
bases that already exist rather than only to ones uploaded from now on, without
asking anyone to upload a document a second time.

ASYNC/SYNC BOUNDARY
-------------------
Retrieval runs synchronously inside a worker thread (the callers wrap it in
``asyncio.to_thread``), so database access here goes through
``run_db_coro_sync``. Ingestion is already async and calls the ``a``-prefixed
functions directly. Calling a sync function from the event-loop thread raises
rather than deadlocking — that guard lives in ``echolib.database``.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

from langchain_core.documents import Document

logger = logging.getLogger(__name__)

# The header levels ``split_markdown`` records on each passage.
_HEADER_KEYS = ("header_1", "header_2", "header_3", "header_4")


# ---------------------------------------------------------------------------
# Shaping
# ---------------------------------------------------------------------------

def _heading_of(document: Document) -> str:
    """The markdown headings this passage sits under, joined into one line."""
    metadata = getattr(document, "metadata", None) or {}
    parts = [str(metadata.get(key)).strip() for key in _HEADER_KEYS if metadata.get(key)]
    return " > ".join(part for part in parts if part)[:1024]


def build_rows(
    documents: Sequence[Document],
    vectors: Optional[Sequence[Sequence[float]]] = None,
    *,
    embedding_model: Optional[str] = None,
    start_index: int = 0,
) -> List[Dict[str, Any]]:
    """
    Turn split documents and their vectors into rows the repository can write.

    WHAT: One dict per passage — text, heading, normalized embedding bytes.
    WHY:  Encoding lives here rather than in the repository so the repository
          stays storage-only, matching ``ApplicationDocumentChunkRepository``.
    INPUT: ``vectors`` positionally aligned with ``documents``, or ``None`` when
           embedding could not run.
    OUTPUT: Rows in document order. Never raises.

    A passage with no vector is still produced. Conversion and embedding fail
    independently, and text that was extracted successfully must not be thrown
    away because a credential was unavailable — it is still readable whole, and
    it becomes searchable the moment the base is embedded again.
    """
    from apps.markitdown.similarity import encode

    rows: List[Dict[str, Any]] = []
    for offset, document in enumerate(documents or []):
        content = (getattr(document, "page_content", "") or "").strip()
        if not content:
            continue

        embedding: Optional[bytes] = None
        dimensions = 0
        if vectors is not None and offset < len(vectors):
            values = vectors[offset]
            if values:
                embedding = encode(values)
                dimensions = len(values)

        rows.append(
            {
                "chunk_index": start_index + offset,
                "content": content,
                "heading": _heading_of(document) or None,
                "embedding": embedding,
                "dimensions": dimensions,
                "embedding_model": (embedding_model or None) if embedding else None,
            }
        )
    return rows


def usable(documents: Sequence[Document]) -> List[Document]:
    """
    Drop passages with no text, once, before anything is aligned against them.

    WHAT: The single place empty passages are removed.
    WHY:  Vectors are matched to passages by position — in ``build_rows``, in
          the FAISS write and in the per-document slicing. Filtering in more
          than one of those would shift the alignment by one and silently store
          each passage against its neighbour's embedding. Filtering here means
          every list downstream is the same length.
    """
    return [
        document
        for document in documents or []
        if (getattr(document, "page_content", "") or "").strip()
    ]


def embed_passages(
    embeddings: Any, documents: Sequence[Document]
) -> Optional[List[List[float]]]:
    """
    Embed every passage in one call, or report that it could not be done.

    ``documents`` must already have been through :func:`usable`, so the result
    lines up with it position for position.

    Returns ``None`` rather than raising: the caller writes the passages either
    way, and an ingest that produced readable text must not be recorded as a
    failure because the embedding endpoint was down.
    """
    if not documents or embeddings is None:
        return None

    texts = [document.page_content for document in documents]
    try:
        return embeddings.embed_documents(texts)
    except Exception:
        logger.warning(
            "Passages could not be embedded; they will be stored as readable "
            "but not searchable",
            exc_info=True,
        )
        return None


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

async def astore_document_chunks(
    kb_id: str,
    document_id: str,
    source_name: str,
    rows: Sequence[Dict[str, Any]],
) -> int:
    """Replace one document's passages. The async entry point, used by ingestion."""
    from echolib.database import get_db_session
    from echolib.repositories.knowledge_chunk_repo import KnowledgeChunkRepository

    if not rows:
        return 0

    try:
        async with get_db_session() as db:
            written = await KnowledgeChunkRepository().replace_for_document(
                db,
                knowledge_base_id=kb_id,
                document_id=document_id,
                source_name=source_name,
                chunks=rows,
            )
        logger.info(
            "Stored %d passage(s) for document '%s' of knowledge base %s",
            written, source_name, kb_id,
        )
        return written
    except Exception:
        # The FAISS write and the markdown column are both still there; losing
        # this one must not fail an ingest that otherwise succeeded.
        logger.error(
            "Passages for document '%s' of knowledge base %s could not be stored",
            source_name, kb_id, exc_info=True,
        )
        return 0


def store_document_chunks(
    kb_id: str,
    document_id: str,
    source_name: str,
    rows: Sequence[Dict[str, Any]],
) -> int:
    """The synchronous entry point, used by the rebuild inside a worker thread."""
    from echolib.database import run_db_coro_sync

    if not rows:
        return 0

    try:
        return run_db_coro_sync(
            lambda: astore_document_chunks(kb_id, document_id, source_name, rows),
            timeout=60.0,
        )
    except Exception:
        logger.error(
            "Passages for document '%s' of knowledge base %s could not be stored",
            source_name, kb_id, exc_info=True,
        )
        return 0


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

async def aload_rows(
    kb_id: str, *, embedding_model: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    One knowledge base's passages, as plain dicts ready for ranking.

    ``embedding_model`` narrows to passages embedded by the same model that will
    embed the query. When that yields nothing — the usual case being a base
    embedded through the platform's fallback credential rather than its
    configured model — the unfiltered set is returned instead and the mismatch
    is left to the dimension check in ``similarity.rank``. Returning nothing
    would be indistinguishable from "the base is empty", which is exactly the
    failure this module exists to remove.
    """
    from echolib.database import get_db_session
    from echolib.repositories.knowledge_chunk_repo import KnowledgeChunkRepository

    repo = KnowledgeChunkRepository()
    async with get_db_session() as db:
        rows: List[Dict[str, Any]] = []
        if embedding_model:
            rows = await repo.load_for_knowledge_base(
                db, knowledge_base_id=kb_id, embedding_model=embedding_model
            )
            if rows:
                return rows
            logger.info(
                "Knowledge base %s has no passages embedded with '%s'; ranking "
                "over every stored passage and letting dimensionality decide",
                kb_id, embedding_model,
            )
        return await repo.load_for_knowledge_base(db, knowledge_base_id=kb_id)


def load_rows(
    kb_id: str, *, embedding_model: Optional[str] = None
) -> List[Dict[str, Any]]:
    """The synchronous entry point for retrieval. Never raises."""
    from echolib.database import run_db_coro_sync

    try:
        return run_db_coro_sync(
            lambda: aload_rows(kb_id, embedding_model=embedding_model),
            timeout=30.0,
        )
    except Exception:
        logger.warning(
            "Stored passages for knowledge base %s could not be read", kb_id,
            exc_info=True,
        )
        return []


async def aload_indexed_models(kb_id: str) -> List[str]:
    """The distinct models this base's stored passages were embedded with."""
    from echolib.database import get_db_session
    from echolib.repositories.knowledge_chunk_repo import KnowledgeChunkRepository

    async with get_db_session() as db:
        return await KnowledgeChunkRepository().embedding_models_for_knowledge_base(
            db, kb_id
        )


def indexed_embedding_model(kb_id: str) -> Optional[str]:
    """
    The model this base's passages were actually embedded with, if unambiguous.

    WHAT: One model name, or ``None`` when the base has no embedded passages or
          holds a mix of models.
    WHY:  ``knowledge_bases.embedding_model`` records intent, and is usually
          ``NULL``. This records what happened. When they differ, the query must
          follow this one -- a vector index is only readable by the model that
          wrote it. A mixed base returns ``None`` rather than picking a winner,
          because guessing between two vector spaces is how the mismatch became
          invisible in the first place.
    """
    from echolib.database import run_db_coro_sync

    try:
        models = run_db_coro_sync(lambda: aload_indexed_models(kb_id), timeout=15.0)
    except Exception:
        logger.debug(
            "Indexed embedding model for knowledge base %s could not be read",
            kb_id, exc_info=True,
        )
        return None

    if len(models) == 1:
        return models[0]
    if len(models) > 1:
        logger.warning(
            "Knowledge base %s holds passages embedded with %d different models "
            "(%s); ranking will only match the ones sharing the query's "
            "dimensionality. Reprocess the base to make it consistent.",
            kb_id, len(models), ", ".join(models),
        )
    return None


async def acount_rows(kb_id: str) -> int:
    """How many passages this knowledge base holds in Postgres."""
    from echolib.database import get_db_session
    from echolib.repositories.knowledge_chunk_repo import KnowledgeChunkRepository

    async with get_db_session() as db:
        return await KnowledgeChunkRepository().count_for_knowledge_base(db, kb_id)


def count_rows(kb_id: str) -> int:
    """The synchronous count. Returns 0 rather than raising."""
    from echolib.database import run_db_coro_sync

    try:
        return run_db_coro_sync(lambda: acount_rows(kb_id), timeout=15.0)
    except Exception:
        logger.warning(
            "Passage count for knowledge base %s could not be read", kb_id,
            exc_info=True,
        )
        return 0


# ---------------------------------------------------------------------------
# Rebuild
# ---------------------------------------------------------------------------

async def aload_rebuild_inputs(kb_id: str) -> Dict[str, Any]:
    """
    The chunking configuration and extracted markdown needed for a rebuild.

    Reads only what already exists in Postgres — no file, no re-conversion, no
    model call. Documents with no markdown are skipped rather than reported:
    they were never extracted, so there is nothing to rebuild from.

    ``processing_status`` is deliberately not part of the filter. Markdown is
    only ever written for a document that converted successfully, so its
    presence is the stronger test — and a base part-way through a reprocess has
    its documents back at ``pending`` while its text is still there.
    """
    from sqlalchemy import select

    from echolib.database import get_db_session
    from echolib.models.knowledge import KnowledgeBase, KnowledgeDocument
    from echolib.repositories.base import safe_uuid

    kb_uuid = safe_uuid(kb_id)
    if kb_uuid is None:
        return {}

    async with get_db_session() as db:
        base = (
            await db.execute(
                select(
                    KnowledgeBase.chunk_size,
                    KnowledgeBase.chunk_overlap,
                    KnowledgeBase.embedding_model,
                ).where(KnowledgeBase.id == kb_uuid)
            )
        ).first()
        if base is None:
            return {}

        rows = (
            await db.execute(
                select(
                    KnowledgeDocument.id,
                    KnowledgeDocument.original_filename,
                    KnowledgeDocument.docling_markdown,
                ).where(KnowledgeDocument.knowledge_base_id == kb_uuid)
            )
        ).all()

    return {
        "chunk_size": int(base.chunk_size or 1000),
        "chunk_overlap": int(base.chunk_overlap or 200),
        "embedding_model": base.embedding_model,
        "documents": [
            {
                "document_id": str(row.id),
                "filename": row.original_filename or "",
                "markdown": row.docling_markdown or "",
            }
            for row in rows
            if (row.docling_markdown or "").strip()
        ],
    }


def rebuild_from_markdown(kb_id: str, embeddings: Any) -> int:
    """
    Rebuild a knowledge base's passages from the markdown already in Postgres.

    WHAT: Re-splits every completed document's ``docling_markdown``, embeds the
          passages and writes them to ``knowledge_document_chunks``.
    WHY:  Every knowledge base created before passages became durable has its
          text in Postgres and its vectors nowhere, because the FAISS index went
          with the container. Asking the user to upload the document again would
          be the only other recovery, and for a base whose original file is also
          gone it would be the *only* recovery.
    INPUT: The base and an embeddings client already resolved for its owner.
           ``embeddings`` may be ``None``: the passages are then stored without
           vectors, which keeps the text readable and keyword-searchable.
    OUTPUT: How many passages were written. ``0`` means there was nothing to
            rebuild from, which is a real answer and not an error.

    Synchronous and called from a worker thread. It runs once: the next search
    finds the passages and never reaches here again.
    """
    from apps.knowledge.vector_store import split_markdown

    from echolib.database import run_db_coro_sync

    try:
        inputs = run_db_coro_sync(lambda: aload_rebuild_inputs(kb_id), timeout=60.0)
    except Exception:
        logger.warning(
            "Rebuild inputs for knowledge base %s could not be read", kb_id,
            exc_info=True,
        )
        return 0

    documents = inputs.get("documents") or []
    if not documents:
        logger.info(
            "Knowledge base %s has no extracted markdown to rebuild passages from",
            kb_id,
        )
        return 0

    # What the client *is*, not what the base was configured with. The
    # configured value is usually NULL, so recording it left every passage
    # claiming no model and made an index/query mismatch undetectable.
    from apps.knowledge.embeddings import model_name_of

    embedding_model = model_name_of(embeddings) or inputs.get("embedding_model")
    total = 0
    unembedded = 0

    if embeddings is None:
        logger.warning(
            "Knowledge base %s is being rebuilt without an embeddings client; "
            "its passages will be stored readable but not vector-searchable",
            kb_id,
        )

    for entry in documents:
        chunks = usable(
            split_markdown(
                entry["markdown"],
                chunk_size=inputs["chunk_size"],
                chunk_overlap=inputs["chunk_overlap"],
                source_metadata={
                    "source_filename": entry["filename"],
                    "document_id": entry["document_id"],
                    "knowledge_base_id": kb_id,
                },
            )
        )
        if not chunks:
            continue

        # ``None`` when the embedding endpoint refused, which is a separate
        # failure from conversion. The passages are still written: this used to
        # ``return`` here, which threw away text that had converted perfectly
        # and left the base reporting "no searchable passages" on every
        # subsequent turn -- so the rebuild that exists to recover a base
        # instead guaranteed it stayed broken. Keyword search reads these rows;
        # only vector ranking needs the vectors.
        vectors = embed_passages(embeddings, chunks)
        if vectors is None:
            unembedded += 1

        rows = build_rows(chunks, vectors, embedding_model=embedding_model)
        total += store_document_chunks(
            kb_id, entry["document_id"], entry["filename"], rows
        )

    if total and unembedded:
        logger.warning(
            "Rebuilt %d passage(s) for knowledge base %s from stored markdown, "
            "but %d document(s) could not be embedded — the base is readable "
            "and keyword-searchable, and becomes vector-searchable once an "
            "embedding model resolves",
            total, kb_id, unembedded,
        )
    elif total:
        logger.info(
            "Rebuilt %d passage(s) for knowledge base %s from stored markdown",
            total, kb_id,
        )
    return total


__all__ = [
    "acount_rows",
    "aload_indexed_models",
    "aload_rows",
    "astore_document_chunks",
    "build_rows",
    "count_rows",
    "embed_passages",
    "indexed_embedding_model",
    "load_rows",
    "rebuild_from_markdown",
    "store_document_chunks",
    "usable",
]
