"""
EchoAI Knowledge Base — Retriever Module

Provides search strategies based on processing_type and search_type:

**processing_type = "vector"**
1. similarity → Pure FAISS vector similarity search with normalized 0-1 scores
2. hybrid → EnsembleRetriever combining FAISS + BM25 (keyword) via RRF

**processing_type = "graph"**
3. any search_type → Neo4j graph-only search (entities + relationships)

**processing_type = "hybrid"**
4. similarity → FAISS vector + Neo4j graph results merged
5. hybrid → FAISS + BM25 + Neo4j graph results merged

All return dicts with content, score (0-1, higher = more relevant), and metadata.
"""

import logging
from typing import Any, Dict, List, Optional

from langchain_community.retrievers import BM25Retriever
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

try:
    from langchain.retrievers import EnsembleRetriever
except ImportError:
    # Fallback for environments using langchain_classic
    from langchain_classic.retrievers import EnsembleRetriever  # type: ignore

from apps.knowledge import durable_search
from apps.knowledge.vector_store import load_faiss_index
from apps.knowledge.graph_store import query_graph

logger = logging.getLogger(__name__)


def _load_bm25_documents(kb_id: str, faiss_store: FAISS) -> List[Document]:
    """
    Extract all documents from the FAISS store's docstore for BM25 indexing.
    This is needed because BM25 operates on the raw text, not embeddings.
    """
    docs: List[Document] = []
    if faiss_store and faiss_store.docstore:
        # FAISS docstore stores documents by internal ID
        for doc_id in faiss_store.index_to_docstore_id.values():
            doc = faiss_store.docstore.search(doc_id)
            if doc and isinstance(doc, Document):
                docs.append(doc)
    return docs


def similarity_search(
    kb_id: str,
    query: str,
    embeddings: Embeddings,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Pure vector similarity search using FAISS with normalized relevance scores.

    Uses ``similarity_search_with_score`` (raw FAISS distances) and converts
    to a 0-1 relevance scale.  Applies reciprocal transformation first, then
    min-max normalizes across the result set so the best result always gets 1.0
    and scores spread across the full 0-1 range.

    This approach works reliably for ANY embedding model regardless of vector
    normalization or distance magnitude.

    Args:
        kb_id: Knowledge base ID.
        query: Search query.
        embeddings: LangChain Embeddings instance.
        top_k: Number of results.

    Returns:
        List of result dicts with content, score (0-1), metadata, source info.
    """
    faiss_store = load_faiss_index(kb_id, embeddings)
    if faiss_store is None:
        # The index lives on this container's own disk, so its absence means
        # "not here", not "not indexed". The passages are in Postgres.
        logger.info(
            "No local FAISS index for KB %s; searching its stored passages",
            kb_id,
        )
        return durable_search.similarity_search(kb_id, query, embeddings, top_k)

    # similarity_search_with_score returns (Document, distance) pairs.
    # For IndexFlatL2: distance = L2² (lower = more similar).
    results = faiss_store.similarity_search_with_score(query, k=top_k)

    if not results:
        return []

    # Log raw distances for diagnostics
    raw_distances = [float(d) for _, d in results]
    logger.info(
        "FAISS raw distances for KB %s (top %d): min=%.6f, max=%.6f, values=%s",
        kb_id, top_k,
        min(raw_distances), max(raw_distances),
        [round(d, 6) for d in raw_distances[:10]],
    )

    # Convert raw distances to relevance scores (0-1, higher = more relevant).
    # Step 1: Reciprocal transform: score_i = 1 / (1 + d_i)
    # Step 2: Min-max normalize across the result set so scores span [0, 1].
    #         - Best result (lowest distance) gets score = 1.0
    #         - Worst result gets a score proportional to its distance gap
    #         - Single result gets 1.0
    reciprocal_scores = [1.0 / (1.0 + d) for d in raw_distances]

    min_rs = min(reciprocal_scores)
    max_rs = max(reciprocal_scores)
    score_range = max_rs - min_rs

    if score_range > 1e-12:
        # Normalize to [0, 1] — best gets 1.0, worst gets 0.0 (but we keep
        # a floor so the worst result still has a visible positive score).
        normalized = [(rs - min_rs) / score_range for rs in reciprocal_scores]
        # Rescale to [0.1, 1.0] so even the worst result has a visible score
        final_scores = [0.1 + 0.9 * n for n in normalized]
    else:
        # All distances identical (or single result) — assign rank-based scores
        n = len(results)
        if n == 1:
            final_scores = [1.0]
        else:
            final_scores = [round(1.0 - (i / n), 4) for i in range(n)]

    output: List[Dict[str, Any]] = []
    for i, (doc, _) in enumerate(results):
        output.append({
            "content": doc.page_content,
            "score": round(final_scores[i], 4),
            "metadata": doc.metadata,
            "source_document": doc.metadata.get("source_filename", ""),
            "chunk_index": doc.metadata.get("chunk_index"),
            "knowledge_base_id": kb_id,
        })

    return output


def hybrid_search(
    kb_id: str,
    query: str,
    embeddings: Embeddings,
    top_k: int = 5,
    vector_weight: float = 0.5,
    keyword_weight: float = 0.5,
) -> List[Dict[str, Any]]:
    """
    Hybrid search combining FAISS similarity + BM25 keyword matching
    via LangChain's EnsembleRetriever.

    Args:
        kb_id: Knowledge base ID.
        query: Search query.
        embeddings: LangChain Embeddings instance.
        top_k: Number of results.
        vector_weight: Weight for vector similarity results.
        keyword_weight: Weight for BM25 keyword results.

    Returns:
        List of result dicts with content, score, metadata, source info.
    """
    faiss_store = load_faiss_index(kb_id, embeddings)
    if faiss_store is None:
        logger.info(
            "No local FAISS index for KB %s; hybrid search over its stored passages",
            kb_id,
        )
        return durable_search.hybrid_search(
            kb_id, query, embeddings, top_k, vector_weight, keyword_weight
        )

    # Build FAISS retriever
    faiss_retriever = faiss_store.as_retriever(search_kwargs={"k": top_k})

    # Build BM25 retriever from the same documents
    docs = _load_bm25_documents(kb_id, faiss_store)
    if not docs:
        logger.warning("No documents for BM25 in KB %s, falling back to similarity only", kb_id)
        return similarity_search(kb_id, query, embeddings, top_k)

    try:
        bm25_retriever = BM25Retriever.from_documents(docs, k=top_k)

        # Combine with EnsembleRetriever
        ensemble_retriever = EnsembleRetriever(
            retrievers=[faiss_retriever, bm25_retriever],
            weights=[vector_weight, keyword_weight],
        )

        results: List[Document] = ensemble_retriever.invoke(query)
    except Exception:
        # BM25 needs ``rank_bm25``. When it is absent the whole hybrid search
        # used to raise, the caller swallowed it, and a base configured for
        # hybrid search returned nothing -- indistinguishable from an empty
        # knowledge base. Half a search is a real answer; none is not.
        logger.warning(
            "Keyword ranking unavailable for KB %s; answering with vector "
            "similarity alone",
            kb_id, exc_info=True,
        )
        return similarity_search(kb_id, query, embeddings, top_k)

    # Limit to top_k
    results = results[:top_k]

    # EnsembleRetriever uses Reciprocal Rank Fusion internally.
    # It returns ranked Documents but no numeric scores, so we
    # derive a synthetic 0-1 score from the rank position.
    n = max(len(results), 1)
    output: List[Dict[str, Any]] = []
    for i, doc in enumerate(results):
        output.append({
            "content": doc.page_content,
            "score": round(1.0 - (i / n), 4),
            "metadata": doc.metadata,
            "source_document": doc.metadata.get("source_filename", ""),
            "chunk_index": doc.metadata.get("chunk_index"),
            "knowledge_base_id": kb_id,
        })

    return output


def graph_search(
    kb_id: str,
    query: str,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Graph-only search using Neo4j knowledge graph.

    Queries the Neo4j graph for entities and relationships matching the query,
    then formats results into the same schema as vector search results for
    consistent downstream handling.

    Scoring uses the keyword-overlap match_score from query_graph — the
    fraction of query keywords that matched each entity.  This produces
    meaningful 0-1 scores that reflect actual relevance.

    Args:
        kb_id: Knowledge base ID.
        query: Search query.
        top_k: Number of results.

    Returns:
        List of result dicts with content, score (0-1), metadata, source info.
    """
    raw_results = query_graph(kb_id=kb_id, query=query, top_k=top_k)

    if not raw_results:
        logger.info("No graph results for KB %s, query=%r", kb_id, query)
        return []

    output: List[Dict[str, Any]] = []
    for i, item in enumerate(raw_results):
        # Build human-readable content from graph triple
        parts = []
        source_node = item.get("source_node", {})
        relationship = item.get("relationship")  # Now a clean string like "CONTAINS"
        target_node = item.get("target_node", {})

        source_label = (
            source_node.get("name") or source_node.get("id") or str(source_node)
        ) if source_node else ""
        target_label = (
            target_node.get("name") or target_node.get("id") or str(target_node)
        ) if target_node else ""

        if source_label:
            parts.append(f"Entity: {source_label}")
            desc = source_node.get("description") if isinstance(source_node, dict) else None
            if desc:
                parts.append(f"Description: {desc}")

        if relationship and target_label:
            parts.append(f"Relationship: {source_label} --[{relationship}]--> {target_label}")
        elif relationship:
            parts.append(f"Relationship: {relationship}")

        if target_label and target_node != source_node:
            parts.append(f"Related Entity: {target_label}")
            desc = target_node.get("description") if isinstance(target_node, dict) else None
            if desc:
                parts.append(f"Description: {desc}")

        content = "\n".join(parts) if parts else str(item)

        # Use keyword-overlap match_score from query_graph (0-1, meaningful).
        # Clamp to [0.1, 1.0] so even partial matches are visible.
        raw_score = item.get("match_score", 0.0)
        score = max(0.1, round(raw_score, 4))

        # Source document metadata from graph traversal
        src_filename = item.get("source_filename", "") or ""
        chunk_idx = item.get("chunk_index")

        output.append({
            "content": content,
            "score": score,
            "metadata": {
                "search_source": "graph",
                "source_node": source_label,
                "target_node": target_label,
                "source_filename": src_filename,
            },
            "source_document": src_filename,
            "chunk_index": chunk_idx,
            "knowledge_base_id": kb_id,
        })

    return output


def search(
    kb_id: str,
    query: str,
    embeddings: Optional[Embeddings] = None,
    search_type: str = "similarity",
    top_k: int = 5,
    vector_weight: float = 0.5,
    keyword_weight: float = 0.5,
    processing_type: str = "vector",
) -> List[Dict[str, Any]]:
    """
    Unified search interface — auto-detects strategy from processing_type and search_type.

    Search behavior matrix:
        processing_type="vector"  + search_type="similarity" → FAISS vector only
        processing_type="vector"  + search_type="hybrid"     → FAISS + BM25
        processing_type="graph"   + any search_type           → Neo4j graph only
        processing_type="hybrid"  + search_type="similarity"  → FAISS vector + Neo4j graph merged
        processing_type="hybrid"  + search_type="hybrid"      → FAISS + BM25 + Neo4j graph merged

    Args:
        kb_id: Knowledge base ID.
        query: Search query.
        embeddings: LangChain Embeddings instance (required for vector/hybrid processing).
        search_type: "similarity" or "hybrid" (controls FAISS search strategy).
        top_k: Number of results.
        vector_weight: Weight for vector similarity (hybrid search only).
        keyword_weight: Weight for BM25 keyword (hybrid search only).
        processing_type: "vector", "graph", or "hybrid" (controls which stores to query).

    Returns:
        List of result dicts.
    """
    # --- Graph-only processing ---
    if processing_type == "graph":
        logger.info("Graph-only search for KB %s", kb_id)
        return graph_search(kb_id, query, top_k)

    # --- Vector-only processing ---
    if processing_type == "vector":
        if not embeddings:
            # Not a dead end. The passages are in Postgres and the keyword half
            # of the durable search needs no model at all. Returning [] here
            # reported the base as empty whenever the user's embedding model was
            # unreachable, and the chat then told them their document held
            # nothing relevant -- which is the reported bug, one layer up.
            logger.warning(
                "No embedding model for KB %s; answering from keyword search "
                "over its stored passages",
                kb_id,
            )
            return durable_search.hybrid_search(
                kb_id, query, None, top_k, vector_weight, keyword_weight
            )
        if search_type == "hybrid":
            return hybrid_search(kb_id, query, embeddings, top_k, vector_weight, keyword_weight)
        else:
            return similarity_search(kb_id, query, embeddings, top_k)

    # --- Hybrid processing (vector + graph merged) ---
    if processing_type == "hybrid":
        vector_results: List[Dict[str, Any]] = []
        graph_results: List[Dict[str, Any]] = []

        # Get vector results if embeddings available
        if embeddings:
            if search_type == "hybrid":
                vector_results = hybrid_search(kb_id, query, embeddings, top_k, vector_weight, keyword_weight)
            else:
                vector_results = similarity_search(kb_id, query, embeddings, top_k)
        else:
            # The graph is not the only thing left: the passages themselves are
            # still searchable by keyword. Dropping to graph-only discarded the
            # document text entirely whenever the embedding model was
            # unreachable.
            logger.warning(
                "No embedding model for KB %s; using keyword search over its "
                "stored passages alongside the graph",
                kb_id,
            )
            vector_results = durable_search.hybrid_search(
                kb_id, query, None, top_k, vector_weight, keyword_weight
            )

        # Get graph results
        graph_results = graph_search(kb_id, query, top_k)

        # Merge with weighted scoring.
        # Graph scores are keyword-overlap based (0-1) which tend to be lower
        # than vector scores.  Apply a configurable discount (graph_weight)
        # to prevent graph results with low relevance from dominating.
        # Default graph_weight=0.7 means graph scores are scaled to 70% of
        # their original value before merging with vector results.
        GRAPH_WEIGHT = 0.7
        for r in graph_results:
            r["score"] = round(r.get("score", 0) * GRAPH_WEIGHT, 4)

        # Tag source type for transparency
        for r in vector_results:
            r.setdefault("metadata", {})["search_source"] = r.get("metadata", {}).get("search_source", "vector")
        for r in graph_results:
            r.setdefault("metadata", {})["search_source"] = "graph"

        merged = vector_results + graph_results
        merged.sort(key=lambda x: x.get("score", 0), reverse=True)
        return merged[:top_k]

    # Fallback: treat unknown processing_type as vector
    logger.warning("Unknown processing_type=%r for KB %s, falling back to vector", processing_type, kb_id)
    if not embeddings:
        return durable_search.hybrid_search(
            kb_id, query, None, top_k, vector_weight, keyword_weight
        )
    if search_type == "hybrid":
        return hybrid_search(kb_id, query, embeddings, top_k, vector_weight, keyword_weight)
    return similarity_search(kb_id, query, embeddings, top_k)
