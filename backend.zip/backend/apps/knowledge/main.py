"""
EchoAI Knowledge Base — FastAPI Sub-Application

Creates the Knowledge Base FastAPI app instance.
Used when running as a standalone micro-service (SERVICE_MODE=micro).
In mono mode, the gateway imports the router directly.
"""

from fastapi import FastAPI

from apps.knowledge import container as _container  # noqa: F401 — triggers DI registration
from apps.knowledge.routes import router

app = FastAPI(
    title="EchoAI Knowledge Base Service",
    description="Knowledge base management — file upload, vector/graph indexing, and retrieval",
    version="1.0.0",
)

app.include_router(router)
