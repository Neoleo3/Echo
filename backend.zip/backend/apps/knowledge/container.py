"""
EchoAI Knowledge Base — DI Container Registration

Registers the KnowledgeService into the global DI container
so it can be resolved from route handlers.
"""

import logging

from echolib.di import container
from echolib.llm_factory import LLMFactory
from apps.knowledge.service import KnowledgeService

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Service instantiation
# ---------------------------------------------------------------------------

_llm_factory = LLMFactory()
_knowledge_service = KnowledgeService(llm_factory=_llm_factory)

# ---------------------------------------------------------------------------
# Container registration
# ---------------------------------------------------------------------------

container.register("knowledge.service", lambda: _knowledge_service)

logger.info("Knowledge Base services registered in DI container")
