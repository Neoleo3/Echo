"""
EchoAI Knowledge Base — MarkItDown Connector

Knowledge extraction is standardized on MarkItDown. This compatibility module
keeps the connector abstraction available while routing extraction through the
shared MarkItDown adapter.
"""

import abc
import asyncio
import os
from typing import Optional

from apps.knowledge.markitdown_adapter import extract_markdown_from_file


class OCRConnector(abc.ABC):
    """Abstract base for extraction connectors."""

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Human-readable backend name."""

    @abc.abstractmethod
    async def extract_text(self, file_path: str, file_ext: str) -> str:
        """Extract text from a file and return markdown."""


class MarkItDownOCR(OCRConnector):
    """Extract markdown through the shared MarkItDown conversion layer."""

    @property
    def name(self) -> str:
        return "MarkItDown"

    async def extract_text(self, file_path: str, file_ext: str) -> str:
        result = await asyncio.to_thread(extract_markdown_from_file, file_path)
        return result.markdown


def get_ocr_connector(method: Optional[str] = None) -> OCRConnector:
    """
    Return the MarkItDown connector.

    `method` is kept for compatibility with existing call signatures.
    """
    effective = (method or "markitdown").strip().lower()
    if effective != "markitdown":
        raise ValueError(
            f"Unknown extraction method '{effective}'. Supported: 'markitdown'"
        )
    return MarkItDownOCR()
