"""
EchoAI Knowledge Base — FAISS Vector Store

Per-knowledge-base FAISS index management using LangChain.
Each KB gets its own index, persisted to disk at:
    {KNOWLEDGE_STORAGE_DIR}/{kb_id}/faiss_index/

Uses MarkdownHeaderTextSplitter → RecursiveCharacterTextSplitter pipeline.
Embeddings are obtained from the LLMFactory.
"""

import logging
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)

logger = logging.getLogger(__name__)

# Resolve storage directory: env var → fallback to backend/uploads/knowledge.
# Treat empty string the same as unset.
_env_storage = os.getenv("KNOWLEDGE_STORAGE_DIR", "").strip()
_BACKEND_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
KNOWLEDGE_STORAGE_DIR = (
    _env_storage
    if _env_storage
    else os.path.join(_BACKEND_ROOT, "uploads", "knowledge")
)


def _index_dir(kb_id: str) -> str:
    """Return the FAISS index directory for a given KB."""
    return os.path.join(KNOWLEDGE_STORAGE_DIR, kb_id, "faiss_index")


def _file_storage_dir(kb_id: str) -> str:
    """Return the file storage directory for a given KB."""
    return os.path.join(KNOWLEDGE_STORAGE_DIR, kb_id, "files")


# ---------------------------------------------------------------------------
# Text splitting
# ---------------------------------------------------------------------------


def split_markdown(
    markdown: str,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    source_metadata: Optional[Dict[str, Any]] = None,
) -> List[Document]:
    """
    Split markdown text using a two-stage pipeline:
    1. MarkdownHeaderTextSplitter — splits by headers (H1-H4)
    2. RecursiveCharacterTextSplitter — further splits large sections

    Args:
        markdown: Raw markdown text from Docling.
        chunk_size: Max characters per chunk.
        chunk_overlap: Overlap between consecutive chunks.
        source_metadata: Extra metadata to attach to every chunk.

    Returns:
        List of LangChain Document objects with metadata.
    """
    headers_to_split_on = [
        ("#", "header_1"),
        ("##", "header_2"),
        ("###", "header_3"),
        ("####", "header_4"),
    ]

    md_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=headers_to_split_on,
        strip_headers=False,
    )

    # Stage 1: split by headers
    header_splits = md_splitter.split_text(markdown)

    # Stage 2: recursive character split for large sections
    recursive_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    final_chunks: List[Document] = []
    for i, doc in enumerate(recursive_splitter.split_documents(header_splits)):
        # Enrich metadata
        meta = doc.metadata.copy()
        meta["chunk_index"] = len(final_chunks)
        if source_metadata:
            meta.update(source_metadata)
        final_chunks.append(Document(page_content=doc.page_content, metadata=meta))

    return final_chunks


# ---------------------------------------------------------------------------
# FAISS index operations
# ---------------------------------------------------------------------------


def create_faiss_index(
    kb_id: str,
    documents: List[Document],
    embeddings: Embeddings,
) -> FAISS:
    """
    Create a new FAISS index from documents and persist to disk.

    Args:
        kb_id: Knowledge base ID.
        documents: LangChain Documents to embed.
        embeddings: LangChain Embeddings instance.

    Returns:
        The FAISS vector store.
    """
    if not documents:
        raise ValueError("No documents provided for indexing")

    index_path = _index_dir(kb_id)
    os.makedirs(index_path, exist_ok=True)

    logger.info("Creating FAISS index for KB %s with %d chunks", kb_id, len(documents))
    vectorstore = FAISS.from_documents(documents, embeddings)
    vectorstore.save_local(index_path)
    logger.info("FAISS index saved to %s", index_path)
    return vectorstore


def add_to_faiss_index(
    kb_id: str,
    documents: List[Document],
    embeddings: Embeddings,
) -> FAISS:
    """
    Add documents to an existing FAISS index.  If no index exists, create one.

    Args:
        kb_id: Knowledge base ID.
        documents: New LangChain Documents to add.
        embeddings: LangChain Embeddings instance.

    Returns:
        The updated FAISS vector store.
    """
    index_path = _index_dir(kb_id)

    if os.path.exists(os.path.join(index_path, "index.faiss")):
        logger.info("Loading existing FAISS index for KB %s", kb_id)
        vectorstore = FAISS.load_local(
            index_path, embeddings, allow_dangerous_deserialization=True
        )
        vectorstore.add_documents(documents)
    else:
        vectorstore = FAISS.from_documents(documents, embeddings)

    vectorstore.save_local(index_path)
    logger.info("FAISS index updated for KB %s (added %d chunks)", kb_id, len(documents))
    return vectorstore


def add_to_faiss_index_from_vectors(
    kb_id: str,
    documents: List[Document],
    vectors: List[List[float]],
    embeddings: Embeddings,
) -> Optional[FAISS]:
    """
    Add already-embedded documents to the index, without embedding them again.

    WHAT: :func:`add_to_faiss_index` with the embedding step lifted out, so the
          caller can pass vectors it has already paid for.
    WHY:  The same passages are now written to ``knowledge_document_chunks`` as
          well, and this platform bills every embedding call to the user's own
          credential. Embedding once and writing both stores costs exactly what
          writing one store cost before.
    INPUT: ``documents`` and ``vectors`` positionally aligned. ``embeddings`` is
           still required -- FAISS keeps it to embed future *queries*, not these
           documents.
    OUTPUT: The store, or ``None`` when the two inputs do not line up.

    Never raises for a length mismatch: FAISS remains the secondary copy here,
    and losing it must not fail an ingest whose durable half succeeded.
    """
    if not documents or len(documents) != len(vectors):
        logger.warning(
            "FAISS index for KB %s not updated: %d documents against %d vectors",
            kb_id, len(documents or []), len(vectors or []),
        )
        return None

    index_path = _index_dir(kb_id)
    os.makedirs(index_path, exist_ok=True)

    pairs = [(doc.page_content, vector) for doc, vector in zip(documents, vectors)]
    metadatas = [doc.metadata for doc in documents]

    if os.path.exists(os.path.join(index_path, "index.faiss")):
        logger.info("Loading existing FAISS index for KB %s", kb_id)
        vectorstore = FAISS.load_local(
            index_path, embeddings, allow_dangerous_deserialization=True
        )
        vectorstore.add_embeddings(pairs, metadatas=metadatas)
    else:
        vectorstore = FAISS.from_embeddings(
            text_embeddings=pairs, embedding=embeddings, metadatas=metadatas
        )

    vectorstore.save_local(index_path)
    logger.info(
        "FAISS index updated for KB %s from pre-computed vectors (%d chunks)",
        kb_id, len(pairs),
    )
    return vectorstore


def faiss_index_exists(kb_id: str) -> bool:
    """
    Whether a FAISS index is on disk **on this replica** for this base.

    WHAT: The same existence test :func:`load_faiss_index` performs, without
          requiring an ``Embeddings`` instance or reading the index.
    WHY:  A knowledge base can be ``status='synced'`` with every document
          extracted and still have no vector index -- ingestion writes the
          extracted markdown and the index in separate steps.

    **This is not the answer to "is this base searchable".** The index lives on
    the container's own disk, which does not survive a restart and is invisible
    to any other replica, so a ``False`` here means only "not on this disk right
    now". Searchability is a property of Postgres -- see
    ``apps.knowledge.chunk_store.knowledge_searchable`` -- and this function is
    now just the fast path that decides whether the local index can be used
    instead of the database.
    """
    return os.path.exists(os.path.join(_index_dir(kb_id), "index.faiss"))


def load_faiss_index(kb_id: str, embeddings: Embeddings) -> Optional[FAISS]:
    """
    Load a persisted FAISS index from disk.

    Returns None if the index doesn't exist.
    """
    index_path = _index_dir(kb_id)
    if not os.path.exists(os.path.join(index_path, "index.faiss")):
        logger.warning("No FAISS index found for KB %s", kb_id)
        return None

    return FAISS.load_local(
        index_path, embeddings, allow_dangerous_deserialization=True
    )


def delete_faiss_index(kb_id: str) -> None:
    """Delete the FAISS index directory for a knowledge base."""
    index_path = _index_dir(kb_id)
    if os.path.exists(index_path):
        shutil.rmtree(index_path)
        logger.info("FAISS index deleted for KB %s", kb_id)


def similarity_search(
    kb_id: str,
    query: str,
    embeddings: Embeddings,
    top_k: int = 5,
) -> List[Tuple[Document, float]]:
    """
    Run similarity search against a KB's FAISS index.

    Returns list of (Document, score) tuples sorted by relevance.
    """
    vectorstore = load_faiss_index(kb_id, embeddings)
    if vectorstore is None:
        return []

    results = vectorstore.similarity_search_with_score(query, k=top_k)
    return results
