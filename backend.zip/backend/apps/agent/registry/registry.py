"""
Agent registry.
Centralized storage and retrieval for agent definitions.

Supports DB-first reads via async methods (get_agent_from_db, etc.)
with automatic fallback to the in-memory filesystem cache.
"""
import json
import logging
import tempfile
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

from echolib.config import settings as _settings
from echolib.database import run_db_coro_sync

logger = logging.getLogger(__name__)


class AgentRegistry:
    """
    Agent registry service.
    Manages agent definitions with persistence.
    """

    def __init__(self, storage_dir: str = None):
        """
        Initialize registry.

        Args:
            storage_dir: Directory for agent storage
        """
        if storage_dir is None:
            storage_dir = Path(__file__).parent.parent.parent / "storage" / "agents"

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Master list file
        self.master_list_file = self.storage_dir / "ai_agents.json"

        # In-memory cache
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._load_all()

    def _agent_filename(self, agent_id: str) -> str:
        """Generate agent filename."""
        return f"{agent_id}.json"

    def _atomic_write_json(self, path: Path, data: Dict[str, Any]) -> None:
        """
        Atomically write JSON to file.

        Args:
            path: Target file path
            data: Data to write
        """
        with tempfile.NamedTemporaryFile(
            mode="w",
            dir=path.parent,
            delete=False,
            suffix=".tmp",
            encoding="utf-8"
        ) as tmp:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
            tmp_path = tmp.name

        os.replace(tmp_path, path)

    def _load_all(self) -> None:
        """Load all agents from storage into cache, skipping soft-deleted ones."""
        for file in self.storage_dir.glob("*.json"):
            # Skip master list file
            if file.name == "ai_agents.json":
                continue

            try:
                with open(file, encoding='utf-8') as f:
                    agent = json.load(f)
                    # Skip soft-deleted agents
                    if agent.get("is_deleted"):
                        continue
                    agent_id = agent.get("agent_id") or agent.get("id")
                    if agent_id:
                        self._cache[agent_id] = agent
            except Exception as e:
                # Skip corrupted files
                print(f"Warning: Failed to load agent from {file}: {e}")

    def _load_master_list(self) -> Dict[str, Any]:
        """Load master agent list."""
        if self.master_list_file.exists():
            try:
                with open(self.master_list_file, encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return {"agents": []}
        return {"agents": []}

    def _save_master_list(self, master_list: Dict[str, Any]) -> None:
        """Save master agent list."""
        self._atomic_write_json(self.master_list_file, master_list)

    def _update_master_list_add(self, agent: Dict[str, Any]) -> None:
        """Add or update agent in master list (upsert)."""
        master_list = self._load_master_list()

        # Create summary entry
        agent_summary = {
            "agent_id": agent.get("agent_id"),
            "name": agent.get("name"),
            "icon": agent.get("icon", "\U0001f916"),
            "role": agent.get("role"),
            "description": agent.get("description", "")
        }

        # Check if already exists and update or add
        agent_id = agent_summary["agent_id"]
        existing_index = None
        for idx, existing_agent in enumerate(master_list["agents"]):
            if existing_agent.get("agent_id") == agent_id:
                existing_index = idx
                break

        if existing_index is not None:
            # UPDATE existing entry (preserves position in list)
            master_list["agents"][existing_index] = agent_summary
        else:
            # ADD new entry
            master_list["agents"].append(agent_summary)

        self._save_master_list(master_list)

    def _update_master_list_remove(self, agent_id: str) -> None:
        """Remove agent from master list."""
        master_list = self._load_master_list()
        master_list["agents"] = [
            a for a in master_list["agents"]
            if a.get("agent_id") != agent_id
        ]
        self._save_master_list(master_list)

    def _update_master_list_soft_delete(self, agent_id: str) -> None:
        """Mark an agent as deleted in the master list without removing it."""
        master_list = self._load_master_list()
        for entry in master_list["agents"]:
            if entry.get("agent_id") == agent_id:
                entry["is_deleted"] = True
                break
        self._save_master_list(master_list)

    def _resolve_cache_key(self, agent_id: str) -> Optional[str]:
        """
        Resolve an agent_id to its corresponding cache key.

        Cache keys are typically prefixed like 'agt_009468864ef64f7e904b07794cf3b804',
        but callers may pass UUIDs like '00946886-4ef6-4f7e-904b-07794cf3b804' or
        bare hex strings.  This method tries multiple formats to find a match.

        Args:
            agent_id: Agent identifier in any format.

        Returns:
            The matching cache key, or None if not found.
        """
        # 1. Direct match
        if agent_id in self._cache:
            return agent_id

        # 2. If no agt_ prefix: try prefixed hex form
        if not agent_id.startswith("agt_"):
            bare_hex = agent_id.replace("-", "")
            prefixed = f"agt_{bare_hex}"
            if prefixed in self._cache:
                return prefixed
        else:
            # 3. Has agt_ prefix: try UUID form (insert hyphens 8-4-4-4-12)
            bare_hex = agent_id[len("agt_"):]
            if len(bare_hex) == 32:
                uuid_form = (
                    f"{bare_hex[:8]}-{bare_hex[8:12]}-{bare_hex[12:16]}"
                    f"-{bare_hex[16:20]}-{bare_hex[20:]}"
                )
                if uuid_form in self._cache:
                    return uuid_form

        # 4. Brute-force: strip both sides to bare hex and compare
        input_bare = agent_id.replace("-", "")
        if input_bare.startswith("agt_"):
            input_bare = input_bare[len("agt_"):]

        for key in self._cache:
            key_bare = key.replace("-", "")
            if key_bare.startswith("agt_"):
                key_bare = key_bare[len("agt_"):]
            if key_bare == input_bare:
                return key

        return None

    def register_agent(self, agent: Dict[str, Any]) -> Dict[str, str]:
        """
        Register or update an agent (upsert logic).

        If agent_id already exists in the registry, the existing agent is updated.
        If agent_id does not exist, a new agent is created.

        This prevents duplicate agent files when re-saving workflows.

        Args:
            agent: Agent definition

        Returns:
            dict with agent_id, path, and action ("created" or "updated")
        """
        agent_id = agent.get("agent_id") or agent.get("id")
        if not agent_id:
            raise ValueError("Agent must have agent_id or id")

        # Check if agent already exists (UPSERT logic) — resolve across ID formats
        resolved_existing = self._resolve_cache_key(agent_id)
        is_update = resolved_existing is not None

        # Add metadata
        if "metadata" not in agent:
            agent["metadata"] = {}

        if is_update:
            # UPDATE existing agent - preserve original registration timestamp
            existing_agent = self._cache[resolved_existing]
            original_registered_at = existing_agent.get("metadata", {}).get("registered_at")
            if original_registered_at:
                agent["metadata"]["registered_at"] = original_registered_at
            agent["metadata"]["updated_at"] = datetime.utcnow().isoformat()
            # Remove old cache entry if the key format differs
            if resolved_existing != agent_id:
                del self._cache[resolved_existing]
                # Remove old file if filename differs
                old_path = self.storage_dir / self._agent_filename(resolved_existing)
                if old_path.exists():
                    os.remove(old_path)
        else:
            # CREATE new agent
            agent["metadata"]["registered_at"] = datetime.utcnow().isoformat()

        # Save to storage (overwrites if exists)
        path = self.storage_dir / self._agent_filename(agent_id)
        self._atomic_write_json(path, agent)

        # Update cache
        self._cache[agent_id] = agent

        # Update master list (handles both new and existing)
        self._update_master_list_add(agent)

        return {
            "agent_id": agent_id,
            "path": str(path),
            "action": "updated" if is_update else "created"
        }

    def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get agent by ID.

        Lookup order:
          1. In-memory FS cache (fastest path).
          2. StorageGateway DB-primary read (Phase 2).
             Only attempted when the gateway is wired and cache misses.

        Args:
            agent_id: Agent identifier (prefixed, UUID, or bare hex)

        Returns:
            Agent definition or None
        """
        # 1. Try cache first
        resolved = self._resolve_cache_key(agent_id)
        if resolved is not None:
            return self._cache.get(resolved)

        # 2. Try DB via StorageGateway (sync bridge)
        if getattr(self, '_storage_gateway', None) is not None:
            try:
                from echolib.repositories.base import DEFAULT_USER_ID

                # Use proper async-to-sync bridge that handles event loop context
                agent_def = run_db_coro_sync(
                    lambda: self._storage_gateway.load_agent(agent_id, DEFAULT_USER_ID),
                    timeout=10.0
                )

                if agent_def:
                    # Populate cache to avoid repeated DB hits
                    cache_key = agent_def.get("agent_id", agent_id)
                    self._cache[cache_key] = agent_def
                    return agent_def
            except Exception as exc:
                logger.debug(
                    "DB lookup via gateway failed for agent '%s': %s",
                    agent_id, exc,
                )

        return None

    def list_agents(self) -> List[Dict[str, Any]]:
        """
        List all registered agents.

        Returns:
            List of agent definitions
        """
        return list(self._cache.values())

    def update_agent(self, agent_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing agent.

        Args:
            agent_id: Agent identifier (prefixed, UUID, or bare hex)
            updates: Fields to update

        Returns:
            Updated agent definition

        Raises:
            ValueError: If agent not found
        """
        resolved_id = self._resolve_cache_key(agent_id)
        if resolved_id is None:
            raise ValueError(f"Agent '{agent_id}' not found")

        agent = self._cache[resolved_id].copy()
        agent.update(updates)

        # Update metadata
        if "metadata" not in agent:
            agent["metadata"] = {}
        agent["metadata"]["updated_at"] = datetime.utcnow().isoformat()

        # Save to storage
        path = self.storage_dir / self._agent_filename(resolved_id)
        self._atomic_write_json(path, agent)

        # Update cache
        self._cache[resolved_id] = agent

        return agent

    def delete_agent(self, agent_id: str, soft_delete: bool = False) -> None:
        """
        Delete an agent.

        Args:
            agent_id: Agent identifier (prefixed, UUID, or bare hex)
            soft_delete: When True, marks the agent as deleted in the JSON
                file and master list instead of removing the file from disk.
                This keeps FS behavior aligned with the DB soft-delete model
                during the migration period.

        Raises:
            ValueError: If agent not found
        """
        resolved_id = self._resolve_cache_key(agent_id)
        if resolved_id is None:
            raise ValueError(f"Agent '{agent_id}' not found")

        path = self.storage_dir / self._agent_filename(resolved_id)

        if soft_delete:
            # Mark the agent definition file as deleted (keep file on disk)
            if path.exists():
                try:
                    with open(path, encoding="utf-8") as f:
                        agent_data = json.load(f)
                    agent_data["is_deleted"] = True
                    self._atomic_write_json(path, agent_data)
                except Exception as e:
                    logger.warning(
                        f"Failed to soft-delete agent file for '{resolved_id}': {e}"
                    )

            # Remove from cache so agent no longer appears in listings
            if resolved_id in self._cache:
                del self._cache[resolved_id]

            # Mark as deleted in master list (keep entry, add flag)
            self._update_master_list_soft_delete(resolved_id)
        else:
            # Legacy hard delete: remove file from disk entirely
            if path.exists():
                os.remove(path)

            # Remove from cache
            del self._cache[resolved_id]

            # Remove entry from master list
            self._update_master_list_remove(resolved_id)

    def get_agents_by_role(self, role: str) -> List[Dict[str, Any]]:
        """
        Get agents by role.

        Args:
            role: Agent role

        Returns:
            List of matching agents
        """
        return [
            agent for agent in self._cache.values()
            if agent.get("role") == role
        ]

    def get_agents_for_workflow(self, agent_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Get multiple agents for a workflow.

        Args:
            agent_ids: List of agent identifiers

        Returns:
            Dict mapping agent_id to agent definition
        """
        result = {}
        for agent_id in agent_ids:
            agent = self.get_agent(agent_id)
            if agent:
                result[agent_id] = agent
        return result

    def validate_agent(self, agent: Dict[str, Any]) -> bool:
        """
        Validate agent definition against schema.

        Args:
            agent: Agent definition

        Returns:
            True if valid

        TODO: Implement actual schema validation
        """
        required_fields = ["agent_id", "name", "role"]
        return all(field in agent for field in required_fields)

    def get_master_list(self) -> Dict[str, Any]:
        """
        Get the master agent list (for workflow builder display).

        Filters out soft-deleted agents so they do not appear in listings.

        Returns:
            Master list with active agent summaries only
        """
        master_list = self._load_master_list()
        master_list["agents"] = [
            a for a in master_list["agents"]
            if not a.get("is_deleted")
        ]
        return master_list

    # ========================================================================
    # DB-first async read methods (Phase 2 migration)
    #
    # These methods read from PostgreSQL first and fall back to the
    # in-memory filesystem cache when the DB lookup fails.  They are
    # designed to be called from async route handlers.
    #
    # When a StorageGateway is available (set via set_storage_gateway()),
    # these methods delegate to the gateway for centralized fallback logic.
    # Otherwise they use the inline implementation (backward compat).
    # ========================================================================

    _storage_gateway = None  # Set by container after construction

    def set_storage_gateway(self, gateway) -> None:
        """
        Inject the StorageGateway after construction.

        Called by the DI container once both the registry and gateway
        are initialized (avoids circular dependencies).
        """
        self._storage_gateway = gateway

    async def get_agent_from_db(
        self, agent_id: str, user_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get agent definition from DB, fall back to filesystem cache.

        Delegates to StorageGateway when available (centralized fallback).
        Otherwise uses inline DB-first + FS-fallback logic.

        Args:
            agent_id: Agent identifier (prefixed or UUID format).
            user_id: Owner user ID for multi-tenant scoping.

        Returns:
            Agent definition dict if found, None otherwise.
        """
        # Prefer centralized gateway when available
        if self._storage_gateway is not None:
            return await self._storage_gateway.load_agent(agent_id, user_id)

        # Inline fallback (backward compat if gateway not wired)
        from echolib.repositories.agent_repo import AgentRepository
        from echolib.id_utils import normalize_to_uuid
        from echolib.database import get_db_session

        # Strategy 1: DB lookup by normalized UUID
        try:
            uuid_id = normalize_to_uuid(agent_id)
            repo = AgentRepository()
            async with get_db_session() as db:
                row = await repo.get_by_id(db, uuid_id, user_id)
                if row and row.definition:
                    return row.definition
        except Exception as exc:
            logger.debug(f"DB lookup by UUID failed for agent '{agent_id}': {exc}")

        # Strategy 2: DB lookup by fs_id in definition JSONB
        try:
            repo = AgentRepository()
            async with get_db_session() as db:
                row = await repo.get_by_fs_id(db, agent_id, user_id)
                if row and row.definition:
                    return row.definition
        except Exception as exc:
            logger.debug(f"DB lookup by fs_id failed for agent '{agent_id}': {exc}")

        # Strategy 3: Filesystem cache fallback (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            logger.warning(
                "LEGACY_FS_FALLBACK: Loading agent '%s' from filesystem "
                "cache (DB miss for user '%s').",
                agent_id, user_id,
            )
            return self._cache.get(agent_id)
        logger.info(f"Filesystem fallback read skipped for agent '{agent_id}' (LEGACY_FILE_READ_ENABLED=false)")
        return None

    async def list_agents_from_db(
        self, user_id: str
    ) -> List[Dict[str, Any]]:
        """
        List all agent definitions from DB, fall back to filesystem cache.

        Args:
            user_id: Owner user ID for multi-tenant scoping.

        Returns:
            List of agent definition dicts.
        """
        # Prefer centralized gateway when available
        if self._storage_gateway is not None:
            return await self._storage_gateway.list_agents(user_id)

        from echolib.repositories.agent_repo import AgentRepository
        from echolib.database import get_db_session

        try:
            repo = AgentRepository()
            async with get_db_session() as db:
                rows = await repo.list_by_user(db, user_id, limit=500)
                if rows:
                    result = []
                    for row in rows:
                        if row.definition:
                            result.append(row.definition)
                        else:
                            result.append({
                                "agent_id": str(row.agent_id),
                                "name": row.name,
                            })
                    return result
        except Exception as exc:
            logger.debug(f"DB list_agents failed for user '{user_id}': {exc}")

        # Fallback: filesystem cache (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            logger.warning(
                "LEGACY_FS_FALLBACK: Listing agents from filesystem "
                "cache (DB returned empty for user '%s').",
                user_id,
            )
            return list(self._cache.values())
        logger.info("Filesystem fallback read skipped for agent list (LEGACY_FILE_READ_ENABLED=false)")
        return []

    async def get_agents_by_role_from_db(
        self, role: str, user_id: str
    ) -> List[Dict[str, Any]]:
        """
        Get agents by role from DB, fall back to filesystem cache.

        Args:
            role: Agent role string to match.
            user_id: Owner user ID for multi-tenant scoping.

        Returns:
            List of matching agent definition dicts.
        """
        from echolib.repositories.agent_repo import AgentRepository
        from echolib.database import get_db_session

        try:
            repo = AgentRepository()
            async with get_db_session() as db:
                rows = await repo.get_by_role(db, user_id, role)
                if rows:
                    return [
                        row.definition for row in rows
                        if row.definition
                    ]
        except Exception as exc:
            logger.debug(f"DB get_by_role failed for role '{role}': {exc}")

        # Fallback: filesystem cache (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            logger.warning(
                "LEGACY_FS_FALLBACK: Loading agents by role '%s' from "
                "filesystem cache.",
                role,
            )
            return [
                agent for agent in self._cache.values()
                if agent.get("role") == role
            ]
        logger.info(f"Filesystem fallback read skipped for agents by role '{role}' (LEGACY_FILE_READ_ENABLED=false)")
        return []

    async def get_master_list_from_db(
        self, user_id: str
    ) -> Dict[str, Any]:
        """
        Get master agent list from DB, fall back to filesystem.

        Delegates to StorageGateway when available.

        Args:
            user_id: Owner user ID for multi-tenant scoping.

        Returns:
            Dict with "agents" key containing list of agent summaries.
        """
        # Prefer centralized gateway
        if self._storage_gateway is not None:
            return await self._storage_gateway.get_agent_master_list(user_id)

        try:
            agents = await self.list_agents_from_db(user_id)
            if agents:
                summaries = []
                for agent in agents:
                    summaries.append({
                        "agent_id": agent.get("agent_id"),
                        "name": agent.get("name"),
                        "icon": agent.get("icon", "\U0001f916"),
                        "role": agent.get("role"),
                        "description": agent.get("description", ""),
                    })
                return {"agents": summaries}
        except Exception as exc:
            logger.debug(f"DB get_master_list failed for user '{user_id}': {exc}")

        # Fallback: filesystem master list (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            logger.warning(
                "LEGACY_FS_FALLBACK: Loading master agent list from "
                "filesystem (DB miss for user '%s').",
                user_id,
            )
            return self._load_master_list()
        logger.info("Filesystem fallback read skipped for master list (LEGACY_FILE_READ_ENABLED=false)")
        return {"agents": []}

    async def get_agents_for_workflow_from_db(
        self, agent_ids: List[str], user_id: str
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get multiple agents by ID from DB, fall back to filesystem cache.

        Delegates to StorageGateway when available.

        Args:
            agent_ids: List of agent identifiers.
            user_id: Owner user ID for multi-tenant scoping.

        Returns:
            Dict mapping agent_id to agent definition.
        """
        # Prefer centralized gateway
        if self._storage_gateway is not None:
            return await self._storage_gateway.get_agents_for_workflow(
                agent_ids, user_id
            )

        result: Dict[str, Dict[str, Any]] = {}

        for agent_id in agent_ids:
            agent_def = await self.get_agent_from_db(agent_id, user_id)
            if agent_def:
                # Use the agent_id from the definition (preserves prefixed format)
                key = agent_def.get("agent_id", agent_id)
                result[key] = agent_def

        return result
