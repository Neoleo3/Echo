"""
Attaching connectors to an agent.

WHAT: The read/attach/detach/toggle operations behind the agent connector
      endpoints, including the server-side Connector Settings gate.
WHY:  Before phase 5b the only way to change ``definition.connectors`` was the
      generic ``PUT /agents/{id}`` update, which accepts an arbitrary dict: no
      ownership check on the connector, no kind inference, and no gate. Spec
      section 6.1 requires the gate to be re-validated on the server, so it
      cannot live in the route body of a generic updater.

Writes go through ``apps.agent.definition_store``, which persists to the same
two stores every other agent write uses -- the filesystem registry (unless
``AGENT_DB_WRITE_ONLY``) and ``AgentRepository``, which normalizes through the
phase 1 contract. That module also owns the Connector Settings gate, because
Phase 6 gates document uploads with the same switch.
"""
from __future__ import annotations

import copy
import logging
from typing import Any, Dict, List, Optional

from apps.agent.definition_store import (
    GATE_MESSAGE,
    AgentNotFound,
    AgentSettingsDisabled,
    load_definition,
    save_definition,
)
from apps.connector.middleware.operations import (
    DEFAULT_ACCESS_LEVEL,
    InvalidAccessLevelError,
    InvalidOperationsError,
    preview_access_levels,
    validate_access_level,
    validate_allowed_operations,
)
from echolib.agent_contract import CONNECTOR_KIND_ALIASES, connectors_enabled

logger = logging.getLogger(__name__)


class ConnectorNotFound(LookupError):
    """The connector does not exist, or is not owned by this user."""


# The gate is not connector-specific -- it governs uploads too -- so it lives in
# ``definition_store``. This alias preserves the name every existing caller
# imports (``apps/agent/routes.py``).
ConnectorSettingsDisabled = AgentSettingsDisabled


# ---------------------------------------------------------------------------
# Available connectors
# ---------------------------------------------------------------------------

def _api_summary(record: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "connector_id": record.get("connector_id"),
        "kind": "api",
        "name": record.get("name") or record.get("connector_id"),
        "description": record.get("description") or "",
        "status": record.get("status"),
        "enabled": bool(record.get("enabled", True)),
        "detail": f"{str(record.get('method', 'GET')).upper()} {record.get('endpoint_url', '')}".strip(),
    }


def _mcp_summary(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Summarize an MCP connector, with its tools split by access.

    ``operations_detail`` carries each tool's read/write classification so a
    picker can present the split production MCP clients present, rather than
    one flat list where a delete sits beside a search.
    """
    from apps.connector.middleware.operations import ACCESS_READ, describe_mcp_operations

    tools = ((record.get("discovery") or {}).get("tools")) or []
    detail = describe_mcp_operations([t for t in tools if isinstance(t, dict)])

    return {
        "connector_id": record.get("connector_id"),
        "kind": "mcp",
        "name": record.get("connector_name") or record.get("connector_id"),
        "description": record.get("description") or "",
        "status": record.get("validation_status"),
        "enabled": bool(record.get("connected", False)),
        "detail": f"{len(tools)} tool(s) discovered",
        "operations": [entry["name"] for entry in detail],
        "operations_detail": detail,
        "default_enabled_operations": [
            entry["name"] for entry in detail if entry["access"] == ACCESS_READ
        ],
        # What each level would permit on this server today, so the picker can
        # show the consequence of a choice instead of describing it in prose.
        "access_level_preview": preview_access_levels(
            "mcp",
            [t for t in tools if isinstance(t, dict)],
            has_resources=bool((record.get("discovery") or {}).get("resources")),
        ),
    }


def _db_summary(record: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "connector_id": record.get("id"),
        "kind": "database",
        "name": record.get("name") or record.get("id"),
        "description": record.get("uploaded_file_name") or "",
        "status": record.get("db_type"),
        "enabled": True,
        "detail": f"{record.get('db_type', 'unknown')} · {record.get('tables_count', 0)} table(s)",
        "access_level_preview": preview_access_levels("database"),
    }


async def list_available(user_id: str) -> Dict[str, Any]:
    """
    List every connector this user could attach, across all three kinds.

    One list, already grouped, so the picker does not have to call three
    different connector APIs and reconcile their shapes. Nothing another user
    owns is ever included -- each service scopes its own query.
    """
    import asyncio

    from apps.connector.db_connector import DatabaseConnectorService
    from echolib.connectors.api_service import APIConnectorService
    from echolib.mcp.service import MCPConnectorService

    async def _api() -> List[Dict[str, Any]]:
        try:
            return [_api_summary(r) for r in await APIConnectorService().list_for_user(user_id=user_id)]
        except Exception:
            logger.warning("Listing API connectors failed", exc_info=True)
            return []

    async def _mcp() -> List[Dict[str, Any]]:
        try:
            result = await MCPConnectorService().list_async(user_id=user_id)
            return [_mcp_summary(r) for r in (result or {}).get("connectors", [])]
        except Exception:
            logger.warning("Listing MCP connectors failed", exc_info=True)
            return []

    async def _db() -> List[Dict[str, Any]]:
        try:
            records = await asyncio.to_thread(
                DatabaseConnectorService().list_connections, user_id=user_id
            )
            return [_db_summary(r) for r in records]
        except Exception:
            logger.warning("Listing database connectors failed", exc_info=True)
            return []

    api, mcp, database = await asyncio.gather(_api(), _mcp(), _db())
    return {
        "api": api,
        "mcp": mcp,
        "database": database,
        "total": len(api) + len(mcp) + len(database),
    }


async def _find_available(user_id: str, connector_id: str, kind: str = "") -> Dict[str, Any]:
    """Locate one connector the user owns, inferring its kind when unstated."""
    available = await list_available(user_id)
    kinds = [kind] if kind in ("api", "mcp", "database") else ["api", "mcp", "database"]

    for candidate_kind in kinds:
        for entry in available.get(candidate_kind, []):
            if str(entry.get("connector_id")) == connector_id:
                return entry

    raise ConnectorNotFound(f"Connector '{connector_id}' was not found for this user")


# ---------------------------------------------------------------------------
# Attachment operations
# ---------------------------------------------------------------------------

async def _describe_attachment(entry: Dict[str, Any], user_id: str) -> Dict[str, Any]:
    """
    Report an attachment together with whether it currently resolves.

    Resolution is synchronous and bridges to the event loop internally, so it
    is run off-thread here: calling it directly from a coroutine would block
    the loop it is waiting on.
    """
    import asyncio

    from apps.connector.middleware.refs import resolve_connector

    resolved = await asyncio.to_thread(resolve_connector, entry, user_id)
    return {
        "connector_id": entry.get("connector_id"),
        "kind": entry.get("kind"),
        "alias": entry.get("alias"),
        "access_level": resolved.access_level,
        "allowed_operations": entry.get("allowed_operations", []),
        # What the level actually produced against this connector's current
        # capabilities, so a user sees the consequence rather than the label.
        "effective_operations": resolved.permitted_operations() if resolved.resolved else [],
        "enabled": entry.get("enabled", True),
        "resolved": resolved.resolved,
        "name": resolved.name,
        "error": resolved.error,
    }


async def list_attachments(agent_id: str, user_id: str) -> Dict[str, Any]:
    """List an agent's attachments and whether each one resolves today."""
    import asyncio

    definition = await load_definition(agent_id, user_id)
    entries = definition.get("connectors") or []
    described = await asyncio.gather(
        *[_describe_attachment(entry, user_id) for entry in entries]
    )

    return {
        "agent_id": definition.get("agent_id"),
        "connector_settings": definition.get("connector_settings", {"enabled": False}),
        "connectors": list(described),
        "count": len(entries),
    }


async def attach(
    agent_id: str,
    user_id: str,
    *,
    connector_id: str,
    kind: str = "",
    alias: str = "",
    access_level: Optional[str] = None,
    allowed_operations: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Attach one connector to an agent.

    WHAT: Validates the gate and the user's ownership of the connector, then
          writes the attachment into ``definition.connectors``.
    WHY:  Spec section 6.1: attachment is a manual, gated, user action, and the
          gate is re-validated here because a client's disabled state is not
          an enforcement point.
    RAISES: ``ConnectorSettingsDisabled`` when the toggle is off,
            ``ConnectorNotFound`` when the connector is not the user's,
            ``AgentNotFound`` when the agent is not the user's,
            ``InvalidAccessLevelError`` / ``InvalidOperationsError`` when the
            requested permissions are not valid for this connector kind.

    Permission model: ``access_level`` is what a user chooses and defaults to
    ``read_only``. ``allowed_operations`` is the advanced override and, when
    given, is the permission set outright -- a level never quietly adds to a
    list the user named.
    """
    connector_id = str(connector_id or "").strip()
    if not connector_id:
        raise ValueError("connector_id is required")

    definition = await load_definition(agent_id, user_id)
    if not connectors_enabled(definition):
        raise ConnectorSettingsDisabled(GATE_MESSAGE)

    normalized_kind = CONNECTOR_KIND_ALIASES.get(str(kind or "").lower(), "")
    available = await _find_available(user_id, connector_id, normalized_kind)

    # Validated here, against the live connector, so a wrong value is a 422 the
    # caller can act on rather than a call refused later at run time. The agent
    # contract re-validates on every write path regardless.
    level = validate_access_level(access_level)
    operations = validate_allowed_operations(
        available["kind"],
        allowed_operations,
        mcp_tool_names=available.get("operations") if available["kind"] == "mcp" else None,
    )

    entry = {
        "connector_id": connector_id,
        "kind": available["kind"],
        "alias": str(alias or "").strip() or str(available.get("name") or connector_id),
        "access_level": level,
        "allowed_operations": operations,
        "enabled": True,
    }

    updated = copy.deepcopy(definition)
    existing = [c for c in (updated.get("connectors") or []) if c.get("connector_id") != connector_id]
    updated["connectors"] = existing + [entry]

    await save_definition(agent_id, user_id, updated)
    logger.info(
        "Attached %s connector '%s' to agent '%s'", entry["kind"], connector_id, agent_id
    )
    return await _describe_attachment(entry, user_id)


async def detach(agent_id: str, user_id: str, connector_id: str) -> Dict[str, Any]:
    """
    Remove one attachment.

    Detaching is permitted while the gate is off: turning the capability off
    must never trap an attachment the user wants gone.
    """
    definition = await load_definition(agent_id, user_id)
    entries = definition.get("connectors") or []
    remaining = [c for c in entries if c.get("connector_id") != connector_id]

    if len(remaining) == len(entries):
        raise ConnectorNotFound(f"Connector '{connector_id}' is not attached to this agent")

    updated = copy.deepcopy(definition)
    updated["connectors"] = remaining
    await save_definition(agent_id, user_id, updated)

    logger.info("Detached connector '%s' from agent '%s'", connector_id, agent_id)
    return {"agent_id": definition.get("agent_id"), "connector_id": connector_id, "detached": True}


async def set_connector_settings(agent_id: str, user_id: str, *, enabled: bool) -> Dict[str, Any]:
    """
    Turn Connector Settings on or off for one agent.

    Turning it off keeps existing attachments in the definition but makes them
    invisible to the runtime -- ``attached_connectors`` returns nothing while
    the gate is closed. Deleting them on toggle-off would destroy user
    configuration on what is meant to be a reversible switch.
    """
    definition = await load_definition(agent_id, user_id)

    updated = copy.deepcopy(definition)
    settings = dict(updated.get("connector_settings") or {})
    settings["enabled"] = bool(enabled)
    updated["connector_settings"] = settings

    await save_definition(agent_id, user_id, updated)
    logger.info("Connector Settings for agent '%s' set to %s", agent_id, bool(enabled))

    return {
        "agent_id": definition.get("agent_id"),
        "connector_settings": settings,
        "attached_count": len(updated.get("connectors") or []),
    }


__all__ = [
    "AgentNotFound",
    "ConnectorNotFound",
    "ConnectorSettingsDisabled",
    "GATE_MESSAGE",
    "InvalidAccessLevelError",
    "InvalidOperationsError",
    "attach",
    "detach",
    "list_attachments",
    "list_available",
    "set_connector_settings",
]
