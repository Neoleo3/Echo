"""
Step (b) -- LLM sufficiency grading. Opt-in, and its own call.

WHAT: One structured-output call asking whether the available evidence is
      actually sufficient for the specific request.
WHY:  Spec section 4.3, second step: "A separate grading call -- **not** the
      same call doing routing/intent detection -- checks whether available
      evidence is actually sufficient and relevant for the specific request
      (CRAG/Self-RAG-style grading)."

The separation is the point, and the spec says why: "One call doing both 'what
does the user want' (fuzzy, persuadable) and 'is there enough evidence' (binary,
safety-critical) reintroduces the same confidence bias described above, one
layer up." Phase 4's ``_analyze_intent`` is a different call in a different
module and is not touched by this one.

**Three verdicts, not two.** Current CRAG production guidance is explicitly
against binary gating: a hard yes/no discards partially useful context, where a
middle band can run the agent and require it to state what it could not verify.
``partial`` is that band, and its handling is what makes the difference
actionable -- ``report.prompt_note`` turns it into an instruction rather than
letting it pass silently.

**Fails open.** A grader that times out, errors, or returns something
unparseable produces no verdict and no finding, logged at WARNING. A grading
outage must not take down every agent on the platform; the deterministic
pre-check and the zero-LLM heuristics have already run and are the safety that
does not depend on a second model being reachable.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .config import insufficient_threshold, sufficient_threshold
from .report import (
    SEVERITY_WARN,
    STAGE_GRADING,
    VERDICT_INSUFFICIENT,
    VERDICT_PARTIAL,
    VERDICT_SUFFICIENT,
    Finding,
)

logger = logging.getLogger(__name__)

MAX_EVIDENCE_CHARS = 4000
MAX_REQUEST_CHARS = 2000

SYSTEM_PROMPT = """You are an evidence sufficiency grader for an AI agent platform.

You are NOT answering the user's request. You are judging one thing only:
does the evidence listed below contain what is needed to answer it?

Judge the evidence as described. Do not assume a source contains something
merely because its name suggests it might. Do not use your own knowledge of the
subject to fill a gap -- if the answer would have to come from you rather than
from the evidence, the evidence is insufficient.

Verdicts:
- "sufficient"   the evidence covers the request; the agent can answer from it
- "partial"      the evidence covers part of the request; some of the answer
                 would have to be assumed or come from outside it
- "insufficient" the evidence does not cover the request in any meaningful way

Return confidence as your certainty in the verdict, from 0.0 to 1.0.
List in "missing" what specific evidence is absent. Keep "reason" to one
sentence, written for the person who configured the agent.

An agent with no attached evidence that was asked a general question is
"sufficient" -- it was never meant to answer from documents. Only judge
evidence to be missing when the request actually needs it."""


def _truncate(text: str, limit: int) -> str:
    body = (text or "").strip()
    if len(body) <= limit:
        return body
    return body[:limit].rstrip() + " …"


def describe_evidence(
    context: Optional[Any] = None,
    connectors: Optional[Sequence[Any]] = None,
) -> str:
    """
    List what the agent can actually reach, for the grader to judge against.

    Names, kinds and sizes only. Document *text* is deliberately not included:
    the grader decides whether the evidence is the right shape, and sending
    every attached document to a second model would double the cost of every
    run to answer a question about structure.
    """
    lines: List[str] = []

    for source in (context.files if context else []):
        if not source.resolved:
            continue
        kind = "web page" if source.source_type == "url" else (source.format or "document")
        if source.is_inline:
            extent = f"{source.char_count:,} characters, fully available"
        else:
            extent = f"{source.chunk_count} searchable passage(s)"
        lines.append(f"- Document '{source.name}' ({kind}; {extent})")

    for base in (context.knowledge_bases if context else []):
        if base.resolved:
            lines.append(
                f"- Knowledge base '{base.name}' ({base.document_count} document(s), searchable)"
            )

    for connector in connectors or []:
        if connector.resolved:
            lines.append(f"- Live {connector.kind} connector '{connector.name}'")

    if not lines:
        return "(no documents, knowledge bases or connectors are attached)"

    return _truncate("\n".join(lines), MAX_EVIDENCE_CHARS)


def _parse(payload: Any) -> Optional[Tuple[str, float, List[str], str]]:
    """Read a grader response into ``(verdict, confidence, missing, reason)``."""
    data: Any = payload

    if isinstance(payload, str):
        text = payload.strip()
        # Providers without structured output wrap JSON in a fence.
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:]
        try:
            data = json.loads(text.strip())
        except (ValueError, TypeError):
            return None

    if not isinstance(data, dict):
        return None

    verdict = str(data.get("verdict") or "").strip().lower()
    if verdict not in (VERDICT_SUFFICIENT, VERDICT_PARTIAL, VERDICT_INSUFFICIENT):
        return None

    try:
        confidence = min(1.0, max(0.0, float(data.get("confidence", 0.5))))
    except (TypeError, ValueError):
        confidence = 0.5

    missing = [str(m).strip() for m in (data.get("missing") or []) if str(m).strip()]
    reason = str(data.get("reason") or "").strip()

    return verdict, confidence, missing, reason


def _apply_bands(verdict: str, confidence: float) -> str:
    """
    Reconcile the stated verdict with its confidence.

    A "sufficient" returned with low confidence is not a pass -- it is the
    grader hedging, and treating it as a pass is how a binary gate lets
    unsupported answers through. Bands rather than the raw label, per current
    CRAG production guidance.
    """
    if verdict == VERDICT_SUFFICIENT and confidence < sufficient_threshold():
        return VERDICT_PARTIAL
    if verdict == VERDICT_PARTIAL and confidence < insufficient_threshold():
        return VERDICT_INSUFFICIENT
    return verdict


def _findings_for(verdict: str, missing: Sequence[str], reason: str) -> List[Finding]:
    """
    Turn a verdict into findings.

    Never blocking. A model's judgement about sufficiency is an inference, and
    inferences inform the agent rather than stopping it -- only the
    deterministic pre-check, which checks facts the user declared, can block. An
    ``insufficient`` verdict therefore produces a strongly-worded instruction,
    which is what the spec's "may loop back to retrieval or refuse" means at
    this layer.
    """
    if verdict == VERDICT_SUFFICIENT:
        return []

    detail = reason or "the available evidence does not cover this request"
    gaps = f" Missing: {', '.join(missing)}." if missing else ""

    if verdict == VERDICT_INSUFFICIENT:
        message = (
            f"Evidence check: {detail}.{gaps} Say plainly that you do not have "
            "what you need, and do not answer from assumption."
        )
    else:
        message = (
            f"Evidence check: {detail}.{gaps} Answer only the part the evidence "
            "supports, and state which part you could not verify."
        )

    return [
        Finding(
            code=f"evidence_{verdict}",
            message=message,
            severity=SEVERITY_WARN,
            stage=STAGE_GRADING,
        )
    ]


def grade(
    request: str,
    *,
    agent_config: Optional[Dict[str, Any]] = None,
    user_id: Optional[str] = None,
    context: Optional[Any] = None,
    connectors: Optional[Sequence[Any]] = None,
) -> Tuple[Optional[str], Optional[float], List[Finding]]:
    """
    Ask a model whether the evidence is sufficient for this request.

    WHAT: One structured-output call, resolved through the agent's own model and
          credential so grading obeys the same per-agent LLM binding as
          execution.
    WHY:  Spec section 4.3 step 2, kept as its own call.
    INPUT: The user's request, the agent definition, and the already-resolved
           evidence surfaces.
    OUTPUT: ``(verdict, confidence, findings)``. ``(None, None, [])`` when the
            grader could not be reached or its answer could not be read --
            failing open, because a grading outage must not stop the platform.
    """
    prompt = (request or "").strip()
    if not prompt:
        return None, None, []

    try:
        from apps.agent.factory.llm_binding import resolve_agent_llm

        llm = resolve_agent_llm(
            agent_config or {}, user_id=user_id, component="readiness_grader"
        )
        model = llm.client
    except Exception:
        logger.warning("Readiness grader could not resolve a model; skipping", exc_info=True)
        return None, None, []

    user_message = (
        f"REQUEST\n{_truncate(prompt, MAX_REQUEST_CHARS)}\n\n"
        f"AVAILABLE EVIDENCE\n{describe_evidence(context, connectors)}\n\n"
        'Return JSON: {"verdict": "sufficient|partial|insufficient", '
        '"confidence": 0.0, "missing": ["..."], "reason": "..."}'
    )

    parsed = None
    try:
        # Structured output when the provider supports it; JSON mode is the
        # fallback, matching how Phase 4's generator degrades.
        try:
            structured = model.with_structured_output(_schema(), method="json_mode")
            parsed = _parse(structured.invoke(
                [("system", SYSTEM_PROMPT), ("human", user_message)]
            ))
        except Exception:
            response = model.invoke([("system", SYSTEM_PROMPT), ("human", user_message)])
            parsed = _parse(getattr(response, "content", response))
    except Exception:
        logger.warning("Readiness grading call failed; failing open", exc_info=True)
        return None, None, []

    if parsed is None:
        logger.warning("Readiness grader returned an unreadable verdict; failing open")
        return None, None, []

    verdict, confidence, missing, reason = parsed
    banded = _apply_bands(verdict, confidence)

    logger.info(
        "Readiness grading: verdict=%s (stated %s, confidence %.2f)",
        banded, verdict, confidence,
    )
    return banded, confidence, _findings_for(banded, missing, reason)


def _schema() -> Dict[str, Any]:
    """The JSON schema the grader is constrained to."""
    return {
        "title": "SufficiencyVerdict",
        "type": "object",
        "properties": {
            "verdict": {
                "type": "string",
                "enum": [VERDICT_SUFFICIENT, VERDICT_PARTIAL, VERDICT_INSUFFICIENT],
            },
            "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
            "missing": {"type": "array", "items": {"type": "string"}},
            "reason": {"type": "string"},
        },
        "required": ["verdict", "confidence"],
    }


__all__ = ["SYSTEM_PROMPT", "describe_evidence", "grade"]
