"""
Step (a2) -- zero-LLM sufficiency signals. Always on, even when grading is off.

WHAT: The cheap half of "is there enough evidence here", derived from counts
      the build already has.
WHY:  Step (b) is one model round trip per agent per run, so it ships off by
      default -- which would otherwise leave *nothing* checking sufficiency on
      almost every deployment. These checks close that gap for free. They run
      whenever the gate is not ``off``, whether or not grading is enabled, and
      only after the deterministic pre-check has passed.

The distinction from ``precheck`` is presence versus usefulness. The pre-check
asks "does the agent have what it declared it needs". This asks "is what it has
capable of answering anything at all" -- the case where an agent looks properly
configured, carries three attached documents, and every one of them is empty,
unreadable or still converting. That agent will answer confidently from the
model's own memory while appearing grounded, which is precisely the failure
arXiv 2411.06037 measures: given partial context a model becomes *less* likely
to abstain, not more.

Deliberately not done here: reading the agent's instructions and guessing what
it promised. Phase 4 removed ~700 lines of keyword tables for good reason, and
a heuristic that greps a prompt for the word "database" would be the same
mistake in a new place. Every signal below is a count, not an inference.
"""
from __future__ import annotations

import logging
from typing import Any, List, Optional, Sequence

from .report import SEVERITY_WARN, STAGE_HEURISTIC, Finding

logger = logging.getLogger(__name__)


def _readable_files(context: Optional[Any]) -> List[Any]:
    return [f for f in (context.files if context else []) if f.resolved]


def _evidence_volume(context: Optional[Any]) -> int:
    """
    How much text the agent's readable sources hold, in characters.

    Counts ``char_count`` for every readable source regardless of mode. A
    retrieval-mode document that produced no passages still *has* text -- it is
    simply not searchable, which ``_check_unsearchable`` reports separately.
    Counting passages here instead would make this claim a document contains no
    text when it contains ninety thousand characters of it.
    """
    return sum(max(0, f.char_count) for f in _readable_files(context))


def _check_all_sources_unusable(context: Optional[Any]) -> List[Finding]:
    """An agent with documents attached and not one of them readable."""
    attached = list(context.files if context else [])
    if not attached:
        return []

    readable = _readable_files(context)
    if readable:
        return []

    return [
        Finding(
            code="no_readable_source",
            message=(
                f"None of the {len(attached)} attached document(s) can be read "
                "right now, so there is no document evidence for this answer. "
                "Do not describe their contents."
            ),
            severity=SEVERITY_WARN,
            stage=STAGE_HEURISTIC,
        )
    ]


def _check_empty_evidence(context: Optional[Any]) -> List[Finding]:
    """Readable sources that nonetheless contain nothing."""
    readable = _readable_files(context)
    if not readable or _evidence_volume(context) > 0:
        return []

    return [
        Finding(
            code="empty_evidence",
            message=(
                "The attached document(s) contain no readable text, so nothing "
                "can be retrieved from them."
            ),
            severity=SEVERITY_WARN,
            stage=STAGE_HEURISTIC,
        )
    ]


def _check_unsearchable(context: Optional[Any]) -> List[Finding]:
    """
    Retrieval-mode sources that produced no passages.

    A document large enough to be chunked but holding zero passages means the
    search tool the agent was told about will always come back empty -- worth
    saying, because "I searched and found nothing" reads to a model as "the
    document does not mention it" rather than "the document was never indexed".
    """
    readable = _readable_files(context)
    retrieval = [f for f in readable if not f.is_inline]
    if not retrieval:
        return []

    if any(f.chunk_count > 0 for f in retrieval):
        return []

    names = ", ".join(f"'{f.name}'" for f in retrieval[:5])
    return [
        Finding(
            code="no_indexed_passages",
            message=(
                f"{names} produced no searchable passages, so a search of the "
                "attached documents will return nothing. Treat an empty result "
                "as 'not indexed', not as 'not mentioned'."
            ),
            severity=SEVERITY_WARN,
            stage=STAGE_HEURISTIC,
        )
    ]


def _check_unread_images(context: Optional[Any]) -> List[Finding]:
    """
    Every readable source had its images skipped.

    A scanned document whose pages were never transcribed converts to almost
    nothing and looks like an empty file. Naming the reason is what turns "this
    document seems blank" into "no vision model is configured".
    """
    readable = _readable_files(context)
    if not readable:
        return []

    skipped = [f for f in readable if f.ocr_skipped_reason]
    if len(skipped) < len(readable):
        return []

    reasons = {f.ocr_skipped_reason for f in skipped}
    return [
        Finding(
            code="images_unread",
            message=(
                "Images in every attached document were not read "
                f"({', '.join(sorted(reasons))}), so anything shown only as a "
                "picture, chart or scan is not available to you."
            ),
            severity=SEVERITY_WARN,
            stage=STAGE_HEURISTIC,
        )
    ]


def _check_no_reachable_source(
    context: Optional[Any], connectors: Optional[Sequence[Any]]
) -> List[Finding]:
    """
    An agent configured to work from sources, with none of them reachable.

    Only fires when the agent has *something* attached -- an agent that is meant
    to answer from the model alone is a legitimate design and must never be
    flagged for it.
    """
    attached_anything = bool(
        (context.files if context else [])
        or (context.knowledge_bases if context else [])
        or (connectors or [])
    )
    if not attached_anything:
        return []

    usable = (
        _readable_files(context)
        or [k for k in (context.knowledge_bases if context else []) if k.resolved]
        or [c for c in (connectors or []) if c.resolved]
    )
    if usable:
        return []

    return [
        Finding(
            code="no_reachable_source",
            message=(
                "This agent is configured to work from attached sources, and "
                "none of them are reachable for this run. Answer only from the "
                "conversation, and say that the sources were unavailable."
            ),
            severity=SEVERITY_WARN,
            stage=STAGE_HEURISTIC,
        )
    ]


def run_heuristics(
    *,
    context: Optional[Any] = None,
    connectors: Optional[Sequence[Any]] = None,
) -> List[Finding]:
    """
    Run every zero-LLM sufficiency signal.

    WHAT: Counts-based checks on whether the agent's evidence can answer
          anything, as opposed to whether it is present.
    WHY:  Grading is off by default, so without this nothing would examine
          sufficiency at all on a typical deployment. These cost nothing and
          run in both ``warn`` and ``block`` mode.
    OUTPUT: Findings, all ``warn`` severity. **Nothing here ever blocks** --
            these are inferences about usefulness, and inferences should
            inform the model, not stop the run. Only the deterministic
            pre-check, which checks facts the user declared, can block.
    """
    findings: List[Finding] = []

    try:
        for check in (
            _check_no_reachable_source(context, connectors),
            _check_all_sources_unusable(context),
            _check_empty_evidence(context),
            _check_unsearchable(context),
            _check_unread_images(context),
        ):
            findings.extend(check)
    except Exception:
        logger.warning("Readiness heuristics failed; skipping them", exc_info=True)
        return []

    # The first four overlap by design -- an agent with no reachable source also
    # has no readable one. Reporting all of them would say the same thing four
    # times to the model, so the broadest finding wins.
    if any(f.code == "no_reachable_source" for f in findings):
        return [f for f in findings if f.code == "no_reachable_source"]
    if any(f.code == "no_readable_source" for f in findings):
        return [f for f in findings if f.code == "no_readable_source"]

    return findings


__all__ = ["run_heuristics"]
