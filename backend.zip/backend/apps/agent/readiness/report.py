"""
What the readiness gate produces, and how it is said to a user.

WHAT: ``Finding``, ``ReadinessReport``, the outcome vocabulary, and the
      user-facing message.
WHY:  Three consumers need the same answer in three shapes -- the runtime needs
      "may this run", the execution record needs a persistable summary, and the
      user needs a sentence explaining what to do. Deriving all three from one
      object is what stops them drifting apart.

Nothing here decides anything. ``precheck`` and ``grading`` produce findings;
this module only carries and renders them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .config import MODE_BLOCK, MODE_OFF, MODE_WARN

# Severity of a single finding.
SEVERITY_BLOCK = "block"
SEVERITY_WARN = "warn"

# Which step produced it.
STAGE_PRECHECK = "precheck"
STAGE_HEURISTIC = "heuristic"
STAGE_GRADING = "grading"

# Grading verdicts. Three, not two: current CRAG production guidance is against
# binary gating, because a hard yes/no throws away partially useful evidence
# where a middle band can run the agent and require it to state its limits.
VERDICT_SUFFICIENT = "sufficient"
VERDICT_PARTIAL = "partial"
VERDICT_INSUFFICIENT = "insufficient"


@dataclass(frozen=True)
class Finding:
    """One thing the gate noticed."""

    code: str
    message: str
    severity: str = SEVERITY_WARN
    stage: str = STAGE_PRECHECK
    subject: str = ""

    @property
    def blocking(self) -> bool:
        return self.severity == SEVERITY_BLOCK

    def to_dict(self) -> Dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "severity": self.severity,
            "stage": self.stage,
            "subject": self.subject,
        }


@dataclass(frozen=True)
class ReadinessReport:
    """
    The gate's answer for one execution.

    ``mode`` decides what the caller does with it, not this object: the same
    findings block in ``block`` mode and merely annotate in ``warn``.
    """

    mode: str = MODE_WARN
    findings: List[Finding] = field(default_factory=list)
    verdict: Optional[str] = None
    confidence: Optional[float] = None
    graded: bool = False
    checked: int = 0

    # ------------------------------------------------------------------
    # Outcome
    # ------------------------------------------------------------------

    @property
    def blocking_findings(self) -> List[Finding]:
        return [f for f in self.findings if f.blocking]

    @property
    def warnings(self) -> List[Finding]:
        return [f for f in self.findings if not f.blocking]

    @property
    def ready(self) -> bool:
        """True when nothing blocking was found. Independent of mode."""
        return not self.blocking_findings

    @property
    def should_block(self) -> bool:
        """
        True when this execution must not reach the model.

        Only ``block`` mode ever stops an execution. ``warn`` records the same
        findings and lets the agent run; ``off`` produces no findings at all.
        """
        return self.mode == MODE_BLOCK and bool(self.blocking_findings)

    @property
    def has_content(self) -> bool:
        return bool(self.findings) or self.verdict is not None

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def user_message(self, agent_name: str = "This agent") -> str:
        """
        What the user is told when the gate stops an execution.

        Written as a plain explanation with the remedy in it. A user who is told
        "not ready" and nothing else has no way to act; the whole point of a
        deterministic gate is that it knows exactly what is missing.
        """
        blocking = self.blocking_findings
        if not blocking:
            return ""

        lines = [f"{agent_name} cannot run yet because it is missing something it needs:"]
        lines.extend(f"- {f.message}" for f in blocking)

        extra = self.warnings
        if extra:
            lines.append("")
            lines.append("Also worth knowing:")
            lines.extend(f"- {f.message}" for f in extra)

        return "\n".join(lines)

    def prompt_note(self) -> str:
        """
        The note appended to the agent's system prompt in ``warn`` mode.

        This is *not* the safeguard -- spec section 4.3 is explicit that
        instruction text is not a substitute for control flow, and arXiv
        2411.06037 measures why: given partial context a model becomes *less*
        likely to abstain, not more. It is the backstop that runs when the
        platform has chosen not to block, and it is what makes a ``partial``
        grading verdict actionable rather than silent.
        """
        if not self.has_content:
            return ""

        lines: List[str] = []

        blocking = self.blocking_findings
        if blocking:
            lines.append(
                "Context readiness: the following are missing or unusable for "
                "this run. Do not work around them, do not assume their "
                "contents, and do not claim to have used them. Say plainly what "
                "is missing and stop:"
            )
            lines.extend(f"- {f.message}" for f in blocking)

        warnings = self.warnings
        if warnings:
            if lines:
                lines.append("")
            lines.append(
                "Context readiness: these may limit what you can answer. State "
                "the limitation rather than filling the gap with an assumption:"
            )
            lines.extend(f"- {f.message}" for f in warnings)

        if self.verdict == VERDICT_PARTIAL:
            if lines:
                lines.append("")
            lines.append(
                "Evidence check: the available evidence only partly covers this "
                "request. Answer the part it supports, and state explicitly "
                "which part you could not verify."
            )

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def to_metadata(self) -> Dict[str, Any]:
        """
        The summary written to ``execution_steps.step_metadata.readiness``.

        Codes, severities and subjects only -- no document text, no user
        message, no credential. Safe to persist beside the Phase 3 LLM record
        and the Phase 5b connector record.
        """
        return {
            "mode": self.mode,
            "ready": self.ready,
            "blocked": self.should_block,
            "checked": self.checked,
            "graded": self.graded,
            "verdict": self.verdict,
            "confidence": self.confidence,
            "findings": [f.to_dict() for f in self.findings],
        }

    def to_response(
        self,
        agent_name: str = "This agent",
        *,
        settings: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        The shape the readiness endpoint returns.

        ``settings`` carries the gate's *configuration* -- see
        ``config.describe_settings``. It is separate from every other key here
        because everything else describes the run that just happened, and a
        control that has to render the user's stored choice cannot be driven
        from a run outcome. ``graded`` says the grading stage executed on this
        request; ``settings.grading_enabled`` says the agent is configured to
        run it. Binding the Evidence Check control to the former is why
        switching it on appeared to do nothing.
        """
        payload = self.to_metadata()
        payload["message"] = self.user_message(agent_name)
        payload["settings"] = dict(settings or {})
        return payload


def skipped(mode: str = MODE_OFF) -> ReadinessReport:
    """An empty report, for when the gate did not run."""
    return ReadinessReport(mode=mode)


__all__ = [
    "MODE_BLOCK",
    "MODE_OFF",
    "MODE_WARN",
    "SEVERITY_BLOCK",
    "SEVERITY_WARN",
    "STAGE_GRADING",
    "STAGE_HEURISTIC",
    "STAGE_PRECHECK",
    "VERDICT_INSUFFICIENT",
    "VERDICT_PARTIAL",
    "VERDICT_SUFFICIENT",
    "Finding",
    "ReadinessReport",
    "skipped",
]
