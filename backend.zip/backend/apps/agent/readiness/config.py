"""
How the readiness gate is configured, and which mode an agent runs in.

WHAT: The three modes, their resolution order, and the tuning knobs.
WHY:  Spec section 4.3 makes the gate mandatory, but turning it on hard would
      break agents that work today -- an agent attached to a connector that was
      never explicitly tested has ``status='untested'``, the column default, and
      runs perfectly well. The mode is what lets the mechanism ship without the
      regression.

**The three modes.**

``off``
    The gate does not run at all. No pre-check, no heuristics, no grading, zero
    cost. For an operator who has decided the platform should never gate, or
    for a debugging session where the gate is in the way.

``warn`` -- the default
    Everything runs and nothing blocks. The report is recorded on the execution
    step and its findings are appended to the agent's prompt, so the model is
    told what is missing and can say so. This is what makes the gate
    deployable: it surfaces exactly which agents ``block`` would stop, before
    anyone turns ``block`` on.

``block``
    A blocking failure stops execution before the model is ever called. The
    user is told what is missing instead of receiving an invented answer. This
    is spec section 4.3 in full, and it is opt-in.

Resolution order, most specific first::

    definition.readiness.mode        per agent, set by the builder
    AGENT_READINESS_MODE             per deployment
    "warn"                           the default

**The legacy guard.** ``Plan_1.md`` Phase 7 requires ``block`` to be "keyed on
``config_version``". An agent authored before ``required_inputs`` existed never
declared any, so blocking it is judging it against a contract it predates.
``AGENT_READINESS_MIN_CONFIG_VERSION`` demotes such an agent to ``warn`` even
when the deployment says ``block`` -- unless its own definition asks for
``block`` explicitly, which is a decision someone made on purpose.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

MODE_OFF = "off"
MODE_WARN = "warn"
MODE_BLOCK = "block"

MODES = (MODE_OFF, MODE_WARN, MODE_BLOCK)

DEFAULT_MODE = MODE_WARN


def _clean(value: Any) -> str:
    return str(value or "").strip().lower()


def _int_env(name: str, default: int, minimum: int = 0) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def _bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def platform_mode() -> str:
    """The deployment-wide default mode."""
    configured = _clean(os.getenv("AGENT_READINESS_MODE"))
    return configured if configured in MODES else DEFAULT_MODE


def min_config_version_for_block() -> int:
    """
    Lowest ``config_version`` at which platform-wide ``block`` applies.

    ``0`` disables the guard and blocks every agent the deployment covers.
    """
    return _int_env("AGENT_READINESS_MIN_CONFIG_VERSION", 1, minimum=0)


def connector_freshness_days() -> int:
    """
    How recently an API connector must have been tested to count as fresh.

    A stale test is a *warning*, never a block: a connector can be entirely
    healthy and simply never have been re-tested since it was created.
    """
    return _int_env("AGENT_READINESS_CONNECTOR_FRESHNESS_DAYS", 30, minimum=1)


def grading_enabled_by_default() -> bool:
    """
    Whether LLM sufficiency grading runs when an agent does not say either way.

    Off. Grading is one extra model round trip per agent per run -- on a
    six-agent workflow that is six extra calls and real latency. The
    deterministic pre-check and the zero-LLM heuristics already deliver most of
    the safety at no cost.
    """
    return _bool_env("AGENT_READINESS_GRADING", False)


def grading_timeout_seconds() -> int:
    """Ceiling on the grading call. Past it the gate fails open."""
    return _int_env("AGENT_READINESS_GRADING_TIMEOUT", 20, minimum=1)


def sufficient_threshold() -> float:
    """
    Confidence at or above which graded evidence counts as sufficient.

    Bands rather than a boolean, following current CRAG production guidance:
    a hard yes/no discards partially useful context, where a middle band can
    run the agent and require it to state what it could not verify.
    """
    return _float_env("AGENT_READINESS_SUFFICIENT_THRESHOLD", 0.7)


def insufficient_threshold() -> float:
    """Confidence below which graded evidence counts as insufficient."""
    return _float_env("AGENT_READINESS_INSUFFICIENT_THRESHOLD", 0.3)


def _float_env(name: str, default: float) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, value))


# ---------------------------------------------------------------------------
# Per-agent resolution
# ---------------------------------------------------------------------------

def agent_settings(definition: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Read the agent's own readiness block, normalized by the contract."""
    settings = (definition or {}).get("readiness")
    return dict(settings) if isinstance(settings, dict) else {}


def resolve_mode(definition: Optional[Dict[str, Any]]) -> str:
    """
    Decide which of ``off`` / ``warn`` / ``block`` this agent runs under.

    WHAT: Agent setting, else deployment setting, else ``warn``.
    WHY:  A per-agent override is what makes ``block`` adoptable one agent at a
          time rather than as a platform-wide switch nobody dares throw.
    OUTPUT: One of :data:`MODES`. Never raises.
    """
    settings = agent_settings(definition)

    declared = _clean(settings.get("mode"))
    if declared in MODES:
        # Explicit on the agent: honoured as-is, including block on a legacy
        # agent. Someone chose that deliberately.
        return declared

    mode = platform_mode()
    if mode != MODE_BLOCK:
        return mode

    # Platform-wide block, with the legacy guard applied.
    floor = min_config_version_for_block()
    if floor <= 0:
        return MODE_BLOCK

    try:
        version = int((definition or {}).get("config_version") or 0)
    except (TypeError, ValueError):
        version = 0

    if version < floor:
        logger.info(
            "Agent '%s' is at config_version %d, below the block floor of %d; "
            "running the readiness gate in warn mode instead.",
            (definition or {}).get("agent_id", "unknown"), version, floor,
        )
        return MODE_WARN

    return MODE_BLOCK


def grading_enabled(definition: Optional[Dict[str, Any]]) -> bool:
    """
    Whether the LLM grading step runs for this agent.

    Never runs in ``off`` mode, and never runs unless the deterministic
    pre-check has already passed -- spec section 4.3 sequences the two.
    """
    settings = agent_settings(definition)
    declared = settings.get("grading_enabled")
    if isinstance(declared, bool):
        return declared
    return grading_enabled_by_default()


def freshness_days(definition: Optional[Dict[str, Any]]) -> int:
    """Per-agent connector freshness window, falling back to the platform one."""
    settings = agent_settings(definition)
    try:
        declared = int(settings.get("freshness_days") or 0)
    except (TypeError, ValueError):
        declared = 0
    return declared if declared > 0 else connector_freshness_days()


def describe_settings(definition: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    The gate's *configuration* for this agent, as opposed to its outcome.

    WHAT: The effective mode and grading flag, each tagged with whether the
          agent stated it or inherited the deployment default.
    WHY:  A report describes one run. ``graded`` means "the grading stage ran
          just now", and ``mode`` is whatever ``resolve_mode`` returned -- and
          the builder was reading both as if they were the stored settings. The
          grading checkbox in particular was bound to ``graded``, which the
          preview endpoint never sets (it defaults to ``allow_grading=False``),
          so switching Evidence Check on wrote the setting correctly and then
          rendered as off. There was no field on the response that carried the
          stored value at all.
    OUTPUT: A plain dict, safe to serialize. Never raises.

    ``mode_source`` matters to the user, not just to us: "warn because the
    platform says so" and "warn because I chose it" look identical on a radio
    group, and the difference decides whether changing the deployment default
    will move this agent.
    """
    declared = agent_settings(definition)

    declared_mode = _clean(declared.get("mode"))
    declared_grading = declared.get("grading_enabled")

    return {
        "mode": resolve_mode(definition),
        "mode_source": "agent" if declared_mode in MODES else "platform",
        "platform_mode": platform_mode(),
        "grading_enabled": grading_enabled(definition),
        "grading_source": "agent" if isinstance(declared_grading, bool) else "platform",
        "freshness_days": freshness_days(definition),
    }


__all__ = [
    "DEFAULT_MODE",
    "MODES",
    "MODE_BLOCK",
    "MODE_OFF",
    "MODE_WARN",
    "agent_settings",
    "connector_freshness_days",
    "describe_settings",
    "freshness_days",
    "grading_enabled",
    "grading_enabled_by_default",
    "grading_timeout_seconds",
    "insufficient_threshold",
    "min_config_version_for_block",
    "platform_mode",
    "resolve_mode",
    "sufficient_threshold",
]
