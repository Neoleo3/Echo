"""
Context Readiness Gate -- what stops an agent answering from nothing.

WHAT: One call, ``check_readiness()``, returning a ``ReadinessReport`` that says
      whether this agent may run and what is missing if it may not.
WHY:  Spec section 3, requirement 3: "No hallucinated task execution. Every
      agent runs a Context Readiness check before generation, deterministic
      where possible -- not left to the model's own judgment inside its
      instructions."

Until now the only guard was a sentence in the system prompt
(``factory/prompt.py``, ``TOOL_EXECUTION_RULES``), which is exactly what spec
section 4.3 forbids relying on. ``definition.required_inputs`` has been
generated since Phase 4 and persisted since Phase 1 and was read by nothing.

**Three stages, in order. Later stages only run if the earlier ones allow.**

    (a) precheck    deterministic, zero LLM calls. Always runs unless mode is off.
                    Checks facts the user declared: required inputs present,
                    documents readable, connectors reachable. Only this stage
                    can produce a blocking finding.

    (a2) heuristics zero LLM calls. Always runs when (a) is clear -- including
                    when grading is switched off, which is the default. Counts
                    the evidence and reports when it cannot answer anything:
                    every source unreadable, nothing indexed, all images
                    skipped. Never blocks; it informs the model.

    (b) grading     one structured-output call. Opt-in per agent. Runs only when
                    (a) is clear, never merged with intent or routing per spec
                    section 4.3. Three verdicts, not two. Fails open.

**Three modes. The mode decides what happens to the findings, not whether they
are gathered.**

    off     nothing runs. Zero cost.
    warn    everything runs, nothing blocks. Findings go into the agent's prompt
            and onto the execution step. This is the default, and it is what
            makes the gate deployable: an agent attached to a connector nobody
            pressed Test on has status 'untested' and works fine today, so
            shipping block on would break it. warn shows an operator exactly
            which agents block would stop, before they turn it on.
    block   a blocking finding stops the run before the model is called. The
            user is told what is missing instead of getting an invented answer.
            Opt-in, per agent or per deployment, and demoted to warn for agents
            older than AGENT_READINESS_MIN_CONFIG_VERSION -- an agent authored
            before required_inputs existed never declared any, and judging it
            against a contract it predates is not a safety improvement.

Callers: ``AgentRuntime.chat`` for standalone chat, the workflow node in
``langchain_adapter``, and the compiler's HITL branch. Application components
inherit it by routing through ``AgentFactory`` (Phase 2). One function, three
sites, identical verdict for the same agent -- which is the parity spec section
3 requirement 1 demands.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Mapping, Optional, Sequence

from .config import (
    MODE_BLOCK,
    MODE_OFF,
    MODE_WARN,
    MODES,
    grading_enabled,
    resolve_mode,
)
from .grading import grade
from .heuristics import run_heuristics
from .precheck import count_checks, run_precheck
from .report import (
    SEVERITY_BLOCK,
    SEVERITY_WARN,
    STAGE_GRADING,
    STAGE_HEURISTIC,
    STAGE_PRECHECK,
    VERDICT_INSUFFICIENT,
    VERDICT_PARTIAL,
    VERDICT_SUFFICIENT,
    Finding,
    ReadinessReport,
    skipped,
)

logger = logging.getLogger(__name__)


def check_readiness(
    agent_config: Optional[Dict[str, Any]],
    *,
    request: str = "",
    user_id: Optional[str] = None,
    context: Optional[Any] = None,
    connectors: Optional[Sequence[Any]] = None,
    state: Optional[Mapping[str, Any]] = None,
    allow_grading: bool = True,
) -> ReadinessReport:
    """
    Decide whether this agent has what it needs, before the model is called.

    WHAT: Runs the deterministic pre-check, then the zero-LLM heuristics, then
          -- only if enabled and only if the pre-check was clear -- the grading
          call.
    WHY:  Spec section 4.3. The ordering is the safety property: a model given
          partial context is measurably *less* likely to abstain than one given
          none (arXiv 2411.06037), so the deterministic step has to come first
          and has to be the only one that can block.
    INPUT: The agent definition, the user's request, and the surfaces the build
           already resolved -- ``AgentContext`` from Phase 6 and the connector
           list from Phase 5b. Passing them in is what keeps this free: nothing
           here re-reads the database.
    OUTPUT: A ``ReadinessReport``. Never raises -- a gate that throws is worse
            than no gate, so every stage catches its own failures and a broken
            check reports clear rather than stopping the platform.

    Args:
        agent_config: The agent definition.
        request: The user's message, used only by the grading stage.
        user_id: Acting user, for the grader's credential resolution.
        context: Resolved ``AgentContext`` (Phase 6), or None.
        connectors: Resolved connectors (Phase 5b), or None.
        state: Run state, where required variables are looked up.
        allow_grading: False suppresses stage (b) regardless of configuration.
            Used by the preview endpoint's default, so opening the builder does
            not spend a model call.
    """
    mode = resolve_mode(agent_config)

    if mode == MODE_OFF:
        return skipped(MODE_OFF)

    findings = list(
        run_precheck(
            agent_config, context=context, connectors=connectors, state=state
        )
    )
    checked = count_checks(agent_config, context=context, connectors=connectors)

    blocking = [f for f in findings if f.blocking]
    if blocking:
        # Spec section 4.3: "If a blocking required input is missing, stop here.
        # Do not call the model to decide this." Nothing further runs -- neither
        # the heuristics nor the grader -- because the answer is already known
        # and asking a model would only add cost and doubt.
        logger.info(
            "Readiness pre-check blocked agent '%s' in %s mode: %s",
            (agent_config or {}).get("agent_id", "unknown"),
            mode,
            ", ".join(f.code for f in blocking),
        )
        return ReadinessReport(mode=mode, findings=findings, checked=checked)

    # (a2) Always, even when grading is off -- which is the default, so without
    # this nothing would examine sufficiency at all on a typical deployment.
    findings.extend(run_heuristics(context=context, connectors=connectors))

    # (b) Opt-in, and only now that (a) is clear.
    verdict: Optional[str] = None
    confidence: Optional[float] = None
    graded = False

    if allow_grading and request and grading_enabled(agent_config):
        verdict, confidence, graded_findings = grade(
            request,
            agent_config=agent_config,
            user_id=user_id,
            context=context,
            connectors=connectors,
        )
        graded = verdict is not None
        findings.extend(graded_findings)

    report = ReadinessReport(
        mode=mode,
        findings=findings,
        verdict=verdict,
        confidence=confidence,
        graded=graded,
        checked=checked,
    )

    if findings:
        logger.info(
            "Readiness for agent '%s' in %s mode: %d finding(s), verdict=%s",
            (agent_config or {}).get("agent_id", "unknown"),
            mode, len(findings), verdict or "not graded",
        )

    return report


def check_build(
    agent_config: Optional[Dict[str, Any]],
    build: Any,
    *,
    request: str = "",
    user_id: Optional[str] = None,
    state: Optional[Mapping[str, Any]] = None,
    allow_grading: bool = True,
) -> ReadinessReport:
    """
    Run the gate against an ``AgentBuild``, reusing what the build resolved.

    The convenience form every runtime call site uses: the build already holds
    the resolved context and connector surfaces, so this adds no I/O at all to
    an execution.
    """
    connectors = getattr(getattr(build, "connectors", None), "connectors", None)
    context = getattr(getattr(build, "context", None), "context", None)

    return check_readiness(
        agent_config,
        request=request,
        user_id=user_id,
        context=context,
        connectors=connectors,
        state=state,
        allow_grading=allow_grading,
    )


__all__ = [
    "MODES",
    "MODE_BLOCK",
    "MODE_OFF",
    "MODE_WARN",
    "SEVERITY_BLOCK",
    "SEVERITY_WARN",
    "STAGE_GRADING",
    "STAGE_HEURISTIC",
    "STAGE_PRECHECK",
    "VERDICT_INSUFFICIENT",
    "VERDICT_PARTIAL",
    "VERDICT_SUFFICIENT",
    "Finding",
    "ReadinessReport",
    "check_build",
    "check_readiness",
    "resolve_mode",
    "skipped",
]
