from fastapi import APIRouter, Body, Depends, File, HTTPException, UploadFile, Query
from typing import Optional
from echolib.di import container
from echolib.security import user_context, get_current_user, require_user, require_admin_or_above, resolve_user_id
from echolib.types import *
from echolib.services import AgentService
from echolib.types import AgentTemplate, Agent, UserContext
from echolib.id_utils import normalize_to_uuid
from echolib.config import settings as _settings
from apps.analytics.token_limit import TokenLimitExceededException
from apps.analytics.token_governance_handler import handle_token_limit_exception
from apps.agent.designer.builder_contract import (
    build_event_envelope,
    is_legal_transition,
    normalize_step_to_state,
    result_to_target_state,
)
from apps.agent import connector_attachments as _connector_attachments
from apps.agent import definition_store as _definition_store
from apps.agent import file_attachments as _file_attachments
from echolib.agent_contract import (
    looks_like_agent_draft as _adapter_looks_like_agent_draft,
    draft_to_definition as _adapter_map_agent_draft_to_saved_agent,
    to_workflow_reference as _adapter_map_saved_agent_to_workflow_agent_reference,
    missing_required_fields as _adapter_missing_required_draft_fields,
    validate as _adapter_validate_saved_agent_runtime_compatibility,
)
from typing import AsyncGenerator, Dict, Any, List, Optional
import asyncio
import copy
import json
import inspect
import logging
import re
import jsonschema
from echolib.utils import new_id as _new_id

_db_logger = logging.getLogger(__name__)

# Pattern matching frontend canvas ephemeral IDs like 'agent-1', 'agent-10'.
# These are NOT valid for DB persistence and must be replaced with proper
# 'agt_<32hex>' IDs before any database operation.
_FRONTEND_ID_PATTERN = re.compile(r'^agent-\d+$')


def _ensure_backend_agent_id(agent: dict) -> str:
    """
    Ensure agent has a proper backend ID suitable for DB persistence.

    Frontend canvas nodes use ephemeral IDs like 'agent-1'. These must
    be replaced with proper 'agt_<hex>' IDs before DB persistence.

    Returns the (possibly replaced) agent_id.
    """
    agent_id = agent.get("agent_id", "")
    if agent_id and _FRONTEND_ID_PATTERN.match(str(agent_id)):
        replacement_id = _new_id("agt_")
        _db_logger.info(
            f"Replaced frontend ID '{agent_id}' with '{replacement_id}' for DB persistence"
        )
        agent["agent_id"] = replacement_id
        return replacement_id
    return agent_id


# Actions that modify agent state and require DB persistence.
_PERSIST_ACTIONS = frozenset({
    "AGENT_DESIGNED",
    # A clarification turn carries the generated agent and the config chat that
    # produced it; not persisting it would lose both if the builder navigates
    # away mid-question.
    "CLARIFICATION_NEEDED",
    "TOOLS_ADDED",
    "TOOL_AUTO_CREATED",
    "TOOLS_REMOVED",
    "INSTRUCTIONS_UPDATED",
})


def _missing_required_draft_fields(draft: Dict[str, Any]) -> List[str]:
    """Compatibility wrapper for centralized draft save-gating policy."""
    return _adapter_missing_required_draft_fields(draft)


def _looks_like_agent_draft(payload: Dict[str, Any]) -> bool:
    """Compatibility wrapper for centralized draft detection."""
    return _adapter_looks_like_agent_draft(payload)


def _join_instruction_blocks(instructions: Any, output_format: Any, prompt: str) -> str:
    """Normalize draft instructions/output_format into a runtime prompt string."""
    blocks: List[str] = []
    if isinstance(instructions, str) and instructions.strip():
        blocks.append(instructions.strip())
    elif isinstance(instructions, list):
        lines = [str(x).strip() for x in instructions if str(x).strip()]
        if lines:
            blocks.append("\n".join(f"- {x}" for x in lines))

    if isinstance(output_format, str) and output_format.strip():
        blocks.append("Output Format:\n" + output_format.strip())
    elif isinstance(output_format, list):
        lines = [str(x).strip() for x in output_format if str(x).strip()]
        if lines:
            blocks.append("Output Format:\n" + "\n".join(f"{i+1}. {x}" for i, x in enumerate(lines)))

    if prompt and prompt.strip():
        blocks.insert(0, prompt.strip())
    return "\n\n".join(b for b in blocks if b).strip()


def _extract_selected_tools(tools: Any) -> List[str]:
    """Normalize selected tools from either draft buckets or flat list."""
    if isinstance(tools, dict):
        selected = tools.get("selected") or []
    elif isinstance(tools, list):
        selected = tools
    else:
        selected = []

    normalized = [str(t).strip() for t in selected if str(t).strip()]
    # Idempotency: deduplicate while preserving order.
    return list(dict.fromkeys(normalized))


def map_agent_draft_to_saved_agent(draft: Dict[str, Any]) -> Dict[str, Any]:
    """Compatibility wrapper for centralized Draft -> Saved adapter."""
    return _adapter_map_agent_draft_to_saved_agent(draft)


def map_saved_agent_to_workflow_agent_node(saved_agent: Dict[str, Any], node_id: str) -> Dict[str, Any]:
    """Compatibility wrapper for centralized Saved -> Workflow adapter."""
    return _adapter_map_saved_agent_to_workflow_agent_reference(saved_agent, node_id)


def _validate_saved_agent_schema(saved_agent: Dict[str, Any]) -> None:
    """Compatibility wrapper for centralized runtime schema validator."""
    _adapter_validate_saved_agent_runtime_compatibility(saved_agent)


def _normalize_v2_draft(draft: Dict[str, Any], action: str) -> Dict[str, Any]:
    """Create a stable AgentDraft-like payload for deterministic v2 clients."""
    normalized = copy.deepcopy(draft or {})
    draft_id = str(normalized.get("agent_id") or normalized.get("id") or "")
    normalized["draftId"] = draft_id
    normalized.setdefault("status", "draft")

    normalized.setdefault("name", "")
    normalized.setdefault("role", "")
    normalized.setdefault("goal", "")
    normalized.setdefault("domain", "")
    normalized.setdefault("skills", normalized.get("skills") or [])

    tools = normalized.get("tools")
    if isinstance(tools, list):
        normalized["tools"] = {
            "selected": tools,
            "recommended": [],
            "optional": [],
            "rejected": [],
        }
    elif isinstance(tools, dict):
        tools.setdefault("selected", [])
        tools.setdefault("recommended", [])
        tools.setdefault("optional", [])
        tools.setdefault("rejected", [])
        normalized["tools"] = tools
    else:
        normalized["tools"] = {
            "selected": [],
            "recommended": [],
            "optional": [],
            "rejected": [],
        }

    normalized.setdefault("variables", [])
    normalized.setdefault("collaboration", {"allowDelegation": False, "maxIterations": 3})
    normalized.setdefault(
        "llmConfig",
        {"model": "gpt-4o-mini", "temperature": 0.2, "maxTokens": 1000, "topP": 1.0},
    )
    normalized.setdefault("similarAgents", [])

    metadata = normalized.get("metadata") if isinstance(normalized.get("metadata"), dict) else {}
    metadata.setdefault("createdFrom", "describe_tab")
    metadata.setdefault("sourcePrompt", normalized.get("prompt", "") or "")
    metadata.setdefault("extractionConfidence", 0.0)
    metadata.setdefault("featureFlagVersion", "agent_builder_v2")
    metadata.setdefault("lastUpdatedAt", None)
    normalized["metadata"] = metadata

    fields = normalized.get("fields") if isinstance(normalized.get("fields"), dict) else {}
    user_actions = {"NAME_UPDATED", "INSTRUCTIONS_UPDATED", "TOOLS_ADDED", "TOOLS_REMOVED", "TOOL_AUTO_CREATED"}
    source = "user" if action in user_actions else "fallback"
    for key in ("name", "role", "goal", "domain", "prompt"):
        if key not in fields:
            fields[key] = {
                "value": normalized.get(key),
                "source": source,
                "userEdited": source == "user",
            }
        else:
            existing = fields.get(key) or {}
            existing.setdefault("value", normalized.get(key))
            existing.setdefault("source", source)
            existing.setdefault("userEdited", source == "user")
            fields[key] = existing
    normalized["fields"] = fields

    return normalized


async def _persist_agent_state(
    agent_state: Dict[str, Any],
    user_id: str,
    *,
    write_filesystem: bool = True,
) -> bool:
    """
    Persist agent state to filesystem registry and PostgreSQL database.

    WHAT: Saves a snapshot of agent_state to both FS and DB.
    WHY: Tool modification actions (TOOLS_ADDED, TOOLS_REMOVED, etc.) must
         be persisted so they survive server restarts.
    INPUT: agent_state dict, user_id string, optional filesystem flag.
    OUTPUT: True if at least one write succeeded, False otherwise.

    Strips internal transient keys (prefixed with '_') before DB write.
    Skips persistence entirely if agent_state has no agent_id.

    Args:
        agent_state: Current agent definition dict.
        user_id: Owner user ID for DB persistence.
        write_filesystem: Whether to write to filesystem registry.

    Returns:
        True if persistence succeeded (at least partially), False otherwise.
    """
    agent_id = agent_state.get("agent_id")
    if not agent_id:
        _db_logger.debug("Skipping persistence — no agent_id in state")
        return False

    success = False

    # Filesystem write (skipped when AGENT_DB_WRITE_ONLY)
    if write_filesystem and not _settings.AGENT_DB_WRITE_ONLY:
        try:
            registry = container.resolve('agent.registry')
            registry.register_agent(agent_state)
            success = True
        except Exception as e:
            _db_logger.warning(f"Agent registry save failed: {e}")
    elif _settings.AGENT_DB_WRITE_ONLY:
        _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")

    # DB write — strip internal transient keys before persisting
    try:
        from echolib.database import get_db_session
        from echolib.repositories.agent_repo import AgentRepository

        agent_repo = AgentRepository()
        db_agent_data = {
            k: v for k, v in copy.deepcopy(agent_state).items()
            if not k.startswith("_")
        }
        _ensure_backend_agent_id(db_agent_data)
        if "agent_id" in db_agent_data:
            try:
                db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
            except (ValueError, Exception):
                _db_logger.warning(
                    f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                    "cannot be converted to a valid UUID"
                )
                return success
        async with get_db_session() as db:
            await agent_repo.upsert(db, user_id, db_agent_data)
        _db_logger.info(f"Agent {agent_id} saved to database")
        success = True
    except Exception as db_err:
        _db_logger.warning(f"Database save failed for agent: {db_err}")

    return success


router = APIRouter(prefix='/agents', tags=['AgentApi'])

def svc() -> AgentService:
    return container.resolve('agent.service')


# ==================== EXISTING ROUTES (UNCHANGED) ====================

@router.post('/create/prompt')
async def create_prompt(
    request: dict,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Create or update agent from prompt with template matching.
    Accepts a JSON body with:
    - prompt (str, required): Natural language description of the desired agent.
    - agent_id (str, optional): If provided, treats this as an UPDATE request.
    - name (str, optional): Override agent name.
    - icon (str, optional): Override icon.
    - role (str, optional): Override role.
    - description (str, optional): Override description.
    - tools (list, optional): Override tools list.
    - variables (list, optional): Override variables.
    - settings (dict, optional): Override settings.

    Response includes "action" field indicating what happened:
    - "CREATE_AGENT": New agent was created
    - "UPDATE_AGENT": Existing agent was updated (when agent_id provided)
    - "AGENT_EXISTS": Similar agent already exists (can be configured/modified)

    The service will:
    1. If agent_id provided: Update existing agent, preserving name/ID
    2. Analyze intent from the prompt.
    3. Check for existing similar agents (returns AGENT_EXISTS if found).
    4. Match against predefined templates.
    5. Build from template if matched, else use LLM generation.
    6. Register the agent in the registry.
    7. Return the full agent definition with action type.
    """
    try:
        prompt = request.get("prompt", "")
        if not prompt:
            raise HTTPException(status_code=400, detail="Prompt cannot be empty")

        agent_id = request.get("agent_id")
        service = svc()
        effective_user_id = resolve_user_id(user)

        # UPDATE MODE: If agent_id is provided, treat as update request
        if agent_id:
            try:
                # DB-first: use async version that reads from DB
                result = await service.updateFromPrompt_db(
                    agent_id, prompt, effective_user_id
                )
                return result
            except TokenLimitExceededException as ex:
                handle_token_limit_exception(ex, "AGENT_CREATE_PROMPT", effective_user_id)
            except ValueError as e:
                raise HTTPException(status_code=404, detail=str(e))

        # CREATE MODE: Check for existing similar agents first
        try:
            intent = await asyncio.to_thread(service._analyze_intent, prompt, user_id=effective_user_id)
            # DB-first: use async version that queries DB
            existing_match = await service._check_existing_agents_db(
                intent, prompt, effective_user_id
            )
            if existing_match:
                # Return existing agent info without creating new one
                return existing_match
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "AGENT_CREATE_PROMPT", effective_user_id)
        except AttributeError:
            # Methods not yet implemented on AgentService; skip similarity check
            pass

        # Build AgentTemplate from request overrides
        template = AgentTemplate(
            name=request.get("name", ""),
            icon=request.get("icon"),
            role=request.get("role"),
            description=request.get("description"),
            prompt=request.get("system_prompt"),
            tools=request.get("tools"),
            variables=request.get("variables"),
            settings=request.get("settings"),
        )
        try:
            agent = service.createFromPrompt(prompt, template, user_id=effective_user_id)
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "AGENT_CREATE_PROMPT", effective_user_id)

        # Persist agent to filesystem registry and database
        agent_dict = agent.model_dump()
        agent_dict["agent_id"] = agent_dict.pop("id")

        # 1) Save to filesystem registry (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            try:
                registry = container.resolve('agent.registry')
                registry.register_agent(agent_dict)
            except Exception as e:
                _db_logger.warning(f"Filesystem registry save failed for agent: {e}")
        else:
            _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")

        # 2) Save to PostgreSQL database (graceful degradation)
        db_saved = False
        try:
            from echolib.database import get_db_session
            from echolib.repositories.agent_repo import AgentRepository

            effective_user_id = resolve_user_id(user)
            agent_repo = AgentRepository()

            db_agent_data = copy.deepcopy(agent_dict)
            _ensure_backend_agent_id(db_agent_data)
            try:
                db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
            except (ValueError, Exception):
                _db_logger.warning(
                    f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                    "cannot be converted to a valid UUID (create/prompt)"
                )
                raise  # re-raise so the outer except block catches it

            async with get_db_session() as db:
                await agent_repo.upsert(db, effective_user_id, db_agent_data, source_workflow_id=None)
            db_saved = True
            _db_logger.info(f"Agent {agent_dict['agent_id']} saved to database")
        except Exception as e:
            _db_logger.warning(f"Database save failed for agent {agent_dict.get('agent_id')}: {e}")

        # Return with action field
        response = agent.model_dump()
        response["action"] = "CREATE_AGENT"
        response["db_saved"] = db_saved
        return response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/create/card')
async def create_card(cardJSON: dict, template: AgentTemplate, user: UserContext = Depends(require_admin_or_above)):
    """Canvas-based agent creation (existing API)."""
    agent = svc().createFromCanvasCard(cardJSON, template)
    agent_dict = agent.model_dump()
    agent_dict["agent_id"] = agent_dict.get("agent_id") or agent_dict.pop("id", None)

    # 1) Save to filesystem registry (skipped when AGENT_DB_WRITE_ONLY)
    if not _settings.AGENT_DB_WRITE_ONLY:
        try:
            registry = container.resolve('agent.registry')
            registry.register_agent(agent_dict)
        except Exception as e:
            _db_logger.warning(f"Filesystem registry save failed for card agent: {e}")
    else:
        _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")

    # 2) Persist to PostgreSQL database (graceful degradation)
    try:
        from echolib.database import get_db_session
        from echolib.repositories.agent_repo import AgentRepository
        effective_user_id = resolve_user_id(user)
        agent_repo = AgentRepository()
        db_agent_data = copy.deepcopy(agent_dict)
        _ensure_backend_agent_id(db_agent_data)
        if "agent_id" in db_agent_data:
            try:
                db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
            except (ValueError, Exception):
                _db_logger.warning(
                    f"Skipping DB upsert for card agent — ID '{db_agent_data.get('agent_id')}' "
                    "cannot be converted to a valid UUID (create/card)"
                )
                raise  # re-raise so the outer except block catches it
        async with get_db_session() as db:
            await agent_repo.upsert(db, effective_user_id, db_agent_data)
        _db_logger.info(f"Card agent {agent_dict.get('agent_id')} saved to database")
    except Exception as db_err:
        _db_logger.warning(f"Database save failed for card agent: {db_err}")

    return agent_dict


@router.post('/validate')
async def validate(agent: Agent, user: UserContext = Depends(require_admin_or_above)):
    """Simple agent validation (existing API)."""
    return svc().validateA2A(agent).model_dump()


@router.get('/list')
async def list_agents(
    page: int = Query(1, ge=1, description="Page number (1-based)"),
    page_size: int = Query(20, ge=1, le=1000, description="Items per page"),
    search: Optional[str] = Query(None, description="Search term for agent name"),
    user: UserContext = Depends(require_user),
):
    """List agents with pagination and optional search."""
    from echolib.schemas.pagination import PaginatedResponse

    try:
        effective_user_id = resolve_user_id(user)
        registry = container.resolve('agent.registry')

        # Preserve legacy visibility: DB-primary reads with filesystem fallback
        # when enabled by the registry/storage gateway.
        agents = await registry.list_agents_from_db(effective_user_id)

        if search:
            needle = search.strip().lower()
            if needle:
                agents = [
                    a for a in agents
                    if needle in str((a or {}).get("name", "")).lower()
                ]

        total = len(agents)
        start = (page - 1) * page_size
        end = start + page_size
        page_items = agents[start:end]

        return PaginatedResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=page_items,
        )
    except Exception as _db_err:
        _db_logger.debug(f"Paginated list fallback: {_db_err}")
        # Fallback for backwards compatibility
        return {
            "page": page,
            "page_size": page_size,
            "total": 0,
            "items": [],
        }


# ==================== NEW ORCHESTRATOR ROUTES ====================

# Agent Design
@router.post('/design/prompt')
async def design_agent_from_prompt(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Design agent from natural language prompt.

    Accepts a JSON body with:
    - prompt (str, required): Natural language description
    - agent_id (str, optional): If provided, updates existing agent
    - model (str, optional): LLM model to use
    - icon (str, optional): Agent icon
    - tools (list, optional): Tools list
    - variables (list, optional): Variables list

    Response includes "action" field:
    - "CREATE_AGENT": New agent was designed
    - "UPDATE_AGENT": Existing agent was updated
    - "AGENT_EXISTS": Similar agent/template already exists (can be configured/modified)
    """
    try:
        designer = container.resolve('agent.designer')
        registry = container.resolve('agent.registry')

        # Extract request fields
        user_prompt = request.get("prompt", "")
        if not user_prompt:
            raise HTTPException(status_code=400, detail="Prompt cannot be empty")

        agent_id = request.get("agent_id")
        effective_user_id = resolve_user_id(user)

        # UPDATE MODE: If agent_id provided, update existing agent
        if agent_id:
            # DB-first agent lookup for design/prompt update
            existing_agent = await registry.get_agent_from_db(agent_id, effective_user_id)
            if not existing_agent:
                raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

            # Use update method that preserves name/ID
            updated_agent = await asyncio.to_thread(
                designer.update_from_prompt,
                existing_agent=existing_agent,
                user_prompt=user_prompt,
                user_id=effective_user_id,
            )

            # Save updates to registry (skipped when AGENT_DB_WRITE_ONLY)
            if not _settings.AGENT_DB_WRITE_ONLY:
                registry.update_agent(agent_id, updated_agent)
            else:
                _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")
            return {
                "action": "UPDATE_AGENT",
                "agent_id": agent_id,
                "agent_name": updated_agent.get("name"),
                "agent": updated_agent
            }

        # CREATE MODE: Check for existing similar agents/templates first (DB-first)
        service = container.resolve('agent.service')
        intent = await asyncio.to_thread(service._analyze_intent, user_prompt, user_id=effective_user_id)
        existing_match = await service._check_existing_agents_db(
            intent, user_prompt, effective_user_id
        )
        if existing_match:
            # Return existing agent/template info without creating new one
            return existing_match

        # No existing match found - proceed to design new agent
        default_model = request.get("model") or "gpt-4o-mini"
        icon = request.get("icon", "")
        tools = request.get("tools", [])
        variables = request.get("variables", [])

        # Design agent
        try:
            agent, design_meta = await asyncio.to_thread(
                designer.design_from_prompt_with_diagnostics,
                user_prompt=user_prompt,
                default_model=default_model,
                icon=icon,
                tools=tools,
                variables=variables,
                user_id=effective_user_id,
            )
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "AGENT_DESIGN_PROMPT", effective_user_id)

        if design_meta.get("fallback_used"):
            _db_logger.warning(
                "Prompt-based agent design degraded for user %s (%s)",
                effective_user_id,
                design_meta.get("fallback_reason"),
            )
            return {
                "action": "DESIGN_FALLBACK",
                "agent": agent,
                "db_saved": False,
                "fallback_used": True,
                "fallback_reason": design_meta.get("fallback_reason"),
                "fallback_detail": design_meta.get("fallback_detail"),
                "message": design_meta.get("message"),
                "design_meta": design_meta,
            }

        # Register agent automatically (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            registry.register_agent(agent)
        else:
            _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")

        # Persist to PostgreSQL database (graceful degradation)
        db_saved = False
        try:
            from echolib.database import get_db_session
            from echolib.repositories.agent_repo import AgentRepository
            agent_repo = AgentRepository()
            db_agent_data = copy.deepcopy(agent)
            _ensure_backend_agent_id(db_agent_data)
            if "agent_id" in db_agent_data:
                try:
                    db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
                except (ValueError, Exception):
                    _db_logger.warning(
                        f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                        "cannot be converted to a valid UUID (design/prompt)"
                    )
                    raise  # re-raise so the outer except block catches it
            async with get_db_session() as db:
                await agent_repo.upsert(db, effective_user_id, db_agent_data)
            db_saved = True
            _db_logger.info(f"Agent {agent.get('agent_id')} saved to database")
        except Exception as e:
            _db_logger.warning(f"Database save failed for agent: {e}")

        return {
            "action": "CREATE_AGENT",
            "agent": agent,
            "db_saved": db_saved,
            "fallback_used": False,
            "design_meta": design_meta,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Agent Registry
@router.post('/register')
async def register_agent(agent: dict, user: UserContext = Depends(require_admin_or_above)):
    """Register a new agent in the registry."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # Boundary rule: AgentDraft is not runtime. Convert before persistence.
        saved_agent = map_agent_draft_to_saved_agent(agent) if _looks_like_agent_draft(agent) else copy.deepcopy(agent)
        _validate_saved_agent_schema(saved_agent)

        # Filesystem write (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            result = registry.register_agent(saved_agent)
        else:
            _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")
            result = {"agent_id": saved_agent.get("agent_id"), "status": "db_only", "action": "skipped_fs"}

        # Persist to PostgreSQL database (graceful degradation)
        try:
            from echolib.database import get_db_session
            from echolib.repositories.agent_repo import AgentRepository

            agent_repo = AgentRepository()
            db_agent_data = copy.deepcopy(saved_agent)
            _ensure_backend_agent_id(db_agent_data)
            if "agent_id" in db_agent_data:
                try:
                    db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
                except (ValueError, Exception):
                    _db_logger.warning(
                        f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                        "cannot be converted to a valid UUID (register)"
                    )
                    raise  # re-raise so the outer except block catches it
            async with get_db_session() as db:
                await agent_repo.upsert(db, effective_user_id, db_agent_data)
            _db_logger.info(f"Agent {saved_agent.get('agent_id')} saved to database")
        except Exception as e:
            _db_logger.warning(f"Database save failed for agent: {e}")

        return {
            **result,
            "agent_id": saved_agent.get("agent_id"),
            "saved_agent": saved_agent,
            "schema_version": "saved_agent_v1",
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post('/save')
async def save_agent_from_draft(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """Convert AgentDraft to SavedAgent, validate compatibility, and persist."""
    try:
        draft = request.get("draft") if isinstance(request.get("draft"), dict) else request
        workflow_node_id = str(request.get("node_id") or "").strip() if isinstance(request, dict) else ""
        if not isinstance(draft, dict):
            raise HTTPException(status_code=400, detail="draft payload must be an object")

        missing = _missing_required_draft_fields(draft)
        if missing:
            return {
                "action": "SAVE_BLOCKED",
                "status": "save_blocked",
                "missing_fields": missing,
                "validation": {
                    "compatibility_gate_passed": False,
                    "missing_fields": missing,
                    "warnings": [],
                },
                "message": "Draft is incomplete. Please complete required fields before saving.",
            }

        saved_agent = map_agent_draft_to_saved_agent(draft)
        _validate_saved_agent_schema(saved_agent)

        # Reuse canonical runtime persistence path.
        result = await register_agent(saved_agent, user)
        workflow_reference = (
            map_saved_agent_to_workflow_agent_node(saved_agent, workflow_node_id)
            if workflow_node_id else None
        )
        return {
            "action": "SAVED",
            "status": "saved",
            "agent_id": saved_agent.get("agent_id"),
            "saved_agent_id": saved_agent.get("agent_id"),
            "saved_agent": saved_agent,
            "workflow_agent_reference": workflow_reference,
            "result": result,
            "schema_version": "saved_agent_v1",
            "builder_schema_version": "agent_builder_v2",
            "validation": {
                "compatibility_gate_passed": True,
                "missing_fields": [],
                "warnings": [],
            },
        }
    except HTTPException:
        raise
    except jsonschema.ValidationError as schema_err:
        raise HTTPException(
            status_code=400,
            detail=f"SavedAgent schema validation failed: {schema_err.message}",
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ==================== BACKEND-DRIVEN CONVERSATION ==================
# NOTE: These routes MUST be defined before the /{agent_id} catch-all
# route so FastAPI matches the specific path first.

@router.post('/design/chat')
async def design_chat(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Single endpoint that drives the entire agent-builder conversation.

    The frontend sends the user message, current step, and agent state.
    The backend classifies intent, performs the action, and returns a
    structured response.  The frontend is a thin renderer — no business
    logic required.

    Request body:
    {
      "message": "user's message",
      "step": "initial" | "name" | "refine" | "done",
      "agent_state": { ... },       // current agent definition (empty on initial)
      "model": "gpt-4o-mini" // optional LLM model override
    }

    Response:
    {
      "reply": "chat bubble text",
      "step": "name" | "refine" | "done",
      "action": "AGENT_DESIGNED" | "NAME_CONFIRMED" | ... ,
      "agent_state": { ... },
      "tools_available": [ ... ]     // present on tool-related actions
    }
    """
    try:
        designer = container.resolve('agent.designer')

        message = request.get("message", "").strip()
        step = request.get("step", "initial")
        agent_state = request.get("agent_state", {})
        model = request.get("model", "gpt-4o-mini")

        if not message:
            raise HTTPException(status_code=400, detail="message is required")

        effective_user_id = resolve_user_id(user)

        # Run in a worker thread: handle_chat_step is synchronous and reaches
        # resolve_and_build_llm_sync, which schedules its coroutine back onto
        # this event loop.  Called inline the loop would be blocked waiting on
        # work only the loop can run — a deadlock that expires as an empty
        # 30s timeout and degrades every design to the basic template.
        # Same reason as /design/prompt above and convobi's /invoke.
        try:
            result = await asyncio.to_thread(
                designer.handle_chat_step,
                message=message,
                step=step,
                agent_state=agent_state,
                model=model,
                user_id=effective_user_id,
            )
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "AGENT_DESIGN_CHAT", effective_user_id)

        # Deterministic guardrail: tool mutations must not advance to done/finalized.
        action = (result.get("action") or "").upper()
        if action in {
            "TOOLS_ADDED",
            "TOOLS_REMOVED",
            "TOOL_AUTO_CREATED",
            "TOOL_ALREADY_SELECTED",
            "TOOL_NOT_SELECTED",
            "TOOL_NOT_FOUND",
        } and str(result.get("step", "")).lower() == "done":
            result["step"] = "refine"
            result["reply"] = (
                "Tool updates were applied. Please review additional refinements or finalize explicitly when ready."
            )

        # Persist agent state on actions that modify agent definition.
        # In deterministic v2 mode, this endpoint handles AgentDraft only;
        # runtime agent persistence must happen through /agents/save.
        action = result.get("action", "")
        if action in _PERSIST_ACTIONS and not _settings.AGENT_BUILDER_V2_DETERMINISTIC:
            agent = result.get("agent_state", {})
            await _persist_agent_state(
                agent_state=agent,
                user_id=effective_user_id,
                write_filesystem=(action == "AGENT_DESIGNED"),
            )

        # Feature-flagged deterministic v2 contract.
        if _settings.AGENT_BUILDER_V2_DETERMINISTIC:
            draft = _normalize_v2_draft(result.get("agent_state") or {}, action)

            # Explicit save-gate: finalize cannot proceed when required fields are missing.
            if (result.get("action") or "").upper() == "FINALIZED":
                missing = _missing_required_draft_fields(draft)
                if missing:
                    result["action"] = "SAVE_BLOCKED"
                    result["step"] = "refine"
                    result["reply"] = (
                        "Agent cannot be finalized yet. Missing required fields: "
                        + ", ".join(missing)
                        + ". Please update them before saving."
                    )

            draft_id = str(draft.get("agent_id") or draft.get("id") or "")
            event = build_event_envelope(result=result, from_step=step, draft_id=draft_id)

            # Hard stop for illegal transitions under deterministic mode.
            from_state = normalize_step_to_state(step)
            to_state = result_to_target_state(result)
            if not is_legal_transition(from_state, to_state, result.get("action", "")):
                result["step"] = "refine"
                event["state_to"] = "CLARIFICATION_REQUIRED"
                event["legal_transition"] = False
                event["warnings"].append("Illegal transition was blocked and rerouted to refine")

            return {
                "schema_version": "agent_builder_v2",
                "envelope_version": "1.0",
                "legacy_compatible": True,
                "event": event,
                "draft": draft,
                "legacy": result,
            }

        return result

    except HTTPException:
        raise
    except Exception as e:
        _db_logger.error(f"design/chat failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== DYNAMIC TOOL SELECTION ====================

@router.get('/available-tools')
async def get_available_tools(user: UserContext = Depends(require_user)):
    """
    Return all available tools (built-in + connector-synced) for the
    frontend tool picker.

    Response:
    {
      "tools": [
        {
          "tool_id": "tool_web_search",
          "name": "Web Search",
          "description": "Search the web for information",
          "tool_type": "local",
          "tags": [],
          "source": "builtin",
          "status": "active",
          "version": "1.0"
        },
        ...
      ],
      "builtin_count": 5,
      "connector_count": 3,
      "total": 8
    }
    """
    try:
        designer = container.resolve('agent.designer')
        effective_user_id = resolve_user_id(user)
        result = designer.get_available_tools(user_id=effective_user_id)
        return result
    except Exception as e:
        _db_logger.error(f"Failed to get available tools: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ``POST /agents/create-tool-from-connector`` was removed in Phase 10. Phase 5a
# deleted connector-to-tool synthesis and left the route returning 410 Gone for
# one release so existing clients got an explanation rather than a 404. A
# connector is attached to an agent as an entry in ``definition.connectors`` and
# invoked through the connector middleware.


@router.get('/{agent_id}/connectors/available')
async def list_available_connectors(agent_id: str, user: UserContext = Depends(require_user)):
    """
    List every connector this user owns, for the agent's connector picker.

    Grouped by kind (api / mcp / database). Attachment itself is gated by
    Connector Settings; listing is not, so the picker can render the options
    behind a disabled control.
    """
    try:
        return await _connector_attachments.list_available(resolve_user_id(user))
    except Exception as e:
        _db_logger.error(f"Failed to list available connectors: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/{agent_id}/connectors')
async def list_agent_connectors(agent_id: str, user: UserContext = Depends(require_user)):
    """List the connectors attached to an agent and whether each resolves."""
    try:
        return await _connector_attachments.list_attachments(agent_id, resolve_user_id(user))
    except _connector_attachments.AgentNotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        _db_logger.error(f"Failed to list agent connectors: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/{agent_id}/connectors')
async def attach_agent_connector(
    agent_id: str,
    request: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Attach a connector to an agent.

    Body: ``{connector_id, kind?, alias?, access_level?, allowed_operations?}``.
    The kind is inferred when omitted. Refused with 409 while Connector Settings
    is off — the client's disabled state is never the enforcement point
    (spec 6.1).

    **Permissions.** ``access_level`` is the user-facing control and is one of
    ``read_only`` (default), ``read_write``, ``full_access``. The backend
    expands it against the connector's current capabilities: reads for every
    level, ordinary writes from ``read_write``, destructive operations only at
    ``full_access``. An API connector is one endpoint and one action, so the
    level does not apply to it. A database never reaches DDL at any level.

    ``allowed_operations`` is the advanced override. When present it *is* the
    permission set and the level is not consulted. It is validated against the
    connector kind and rejected with 422 otherwise: ``invoke`` for an API
    connector, ``read`` / ``write`` for a database, advertised tool names or
    ``read_resource`` for an MCP server.

    The response reports ``effective_operations`` — what the choice actually
    produced against this connector today.
    """
    try:
        return await _connector_attachments.attach(
            agent_id,
            resolve_user_id(user),
            connector_id=str(request.get("connector_id") or ""),
            kind=str(request.get("kind") or ""),
            alias=str(request.get("alias") or ""),
            access_level=request.get("access_level"),
            allowed_operations=request.get("allowed_operations") or [],
        )
    except _connector_attachments.ConnectorSettingsDisabled as e:
        raise HTTPException(status_code=409, detail=str(e))
    except _connector_attachments.AgentNotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except _connector_attachments.ConnectorNotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except (
        _connector_attachments.InvalidAccessLevelError,
        _connector_attachments.InvalidOperationsError,
    ) as e:
        raise HTTPException(status_code=422, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        _db_logger.error(f"Failed to attach connector to agent {agent_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete('/{agent_id}/connectors/{connector_id}')
async def detach_agent_connector(
    agent_id: str,
    connector_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Detach a connector from an agent. Permitted whether or not the gate is on."""
    try:
        return await _connector_attachments.detach(agent_id, resolve_user_id(user), connector_id)
    except (_connector_attachments.AgentNotFound, _connector_attachments.ConnectorNotFound) as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        _db_logger.error(f"Failed to detach connector from agent {agent_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put('/{agent_id}/connector-settings')
async def update_agent_connector_settings(
    agent_id: str,
    request: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Turn Connector Settings on or off for an agent.

    Body: ``{"enabled": bool}``. Off is the default for every agent. Turning it
    off keeps existing attachments but stops the runtime exposing them.
    """
    try:
        return await _connector_attachments.set_connector_settings(
            agent_id, resolve_user_id(user), enabled=bool(request.get("enabled", False))
        )
    except _connector_attachments.AgentNotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        _db_logger.error(f"Failed to update connector settings for agent {agent_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Agent context -- attached files, URLs and knowledge bases (Phase 6)
# ---------------------------------------------------------------------------
#
# Files and URLs attached here become part of the agent's persistent context:
# they are described in its system prompt and readable through its retrieval
# tools on *every* execution -- standalone chat, a workflow node, an application
# component -- not only in the conversation that uploaded them.
#
# Gated by the same Connector Settings switch as connectors (spec 6.1).
# Conversion, OCR and indexing are owned by apps/markitdown.


async def _read_upload(upload) -> bytes:
    """
    Read an upload into memory, stopping the moment it exceeds the ceiling.

    Read in chunks rather than with ``.read()`` so an oversized file is refused
    after one megabyte instead of after the whole payload is resident.
    """
    from apps.markitdown import config as _md_config

    ceiling = _md_config.max_file_bytes()
    buffer = bytearray()
    while True:
        chunk = await upload.read(1024 * 1024)
        if not chunk:
            break
        buffer.extend(chunk)
        if len(buffer) > ceiling:
            await upload.close()
            raise HTTPException(
                status_code=413,
                detail=(
                    f"'{upload.filename}' is larger than the "
                    f"{ceiling // (1024 * 1024)} MB limit."
                ),
            )
    await upload.close()
    return bytes(buffer)


def _context_http_error(exc: Exception) -> HTTPException:
    """Map a document-layer failure onto the status code that describes it."""
    from apps.markitdown import (
        BlockedUrlError,
        MarkItDownUnavailable,
        SourceTooLargeError,
        UnsupportedSourceError,
    )

    if isinstance(exc, _file_attachments.AgentSettingsDisabled):
        return HTTPException(status_code=409, detail=str(exc))
    if isinstance(
        exc,
        (
            _file_attachments.AgentNotFound,
            _file_attachments.AttachmentNotFound,
            _file_attachments.KnowledgeBaseNotFound,
        ),
    ):
        return HTTPException(status_code=404, detail=str(exc))
    if isinstance(exc, SourceTooLargeError):
        return HTTPException(status_code=413, detail=str(exc))
    if isinstance(exc, UnsupportedSourceError):
        return HTTPException(status_code=415, detail=str(exc))
    if isinstance(exc, BlockedUrlError):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, MarkItDownUnavailable):
        return HTTPException(status_code=503, detail=str(exc))
    return HTTPException(status_code=500, detail=str(exc))


@router.get('/markitdown/status')
async def get_document_backend_status(user: UserContext = Depends(require_user)):
    """
    Report what the document layer can do on this server right now.

    Whether MarkItDown is installed, whether page rendering is available, and
    which model resolved for reading images -- including the reason when none
    did. A wrong environment should be a visible answer, not a mystery.
    """
    try:
        return await _file_attachments.backend_status(resolve_user_id(user))
    except Exception as e:
        _db_logger.error(f"Failed to read document backend status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Ceiling on the stand-in request built from an agent's own configuration. The
# grader reads it as a user request; a whole system prompt would swamp that.
_READINESS_PROBE_CHARS = 600


def _readiness_probe_request(definition: Dict[str, Any]) -> str:
    """
    A representative request for an agent that was given none.

    The builder previews readiness before anyone has asked the agent anything,
    so the grading stage has no request to grade sufficiency against. Its own
    description -- failing that, the opening of its instructions -- is the
    closest honest statement of what it will be asked to do.
    """
    for key in ("description", "instructions", "prompt"):
        value = definition.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()[:_READINESS_PROBE_CHARS]
    return str(definition.get("name") or "").strip()


@router.get('/{agent_id}/readiness')
async def check_agent_readiness(
    agent_id: str,
    request_text: str = "",
    grade: bool = False,
    user: UserContext = Depends(require_user),
):
    """
    Report whether this agent has everything it needs to run (spec 4.3).

    Answers "why won't my agent run?" in the builder, before a user discovers
    it mid-conversation. Runs the same gate the runtime does, against the same
    resolved connector and document surfaces.

    Query parameters:

    - ``request_text`` — an example request. Only used by the grading stage.
    - ``grade`` — run the LLM sufficiency step too. **Off by default**: it is
      one model call, and opening the builder should not spend one. The
      deterministic pre-check and the zero-LLM heuristics always run.

    The response reports ``mode`` (``off`` / ``warn`` / ``block``), ``ready``,
    whether this run ``blocked``, and every finding with its severity. In
    ``warn`` mode ``ready`` can be false while ``blocked`` is true only in
    ``block`` mode — which is exactly what makes this endpoint useful before
    switching an agent over.
    """
    import asyncio

    from apps.agent.context import build_agent_context_middleware
    from apps.agent.readiness import check_readiness
    from apps.agent.readiness import config as readiness_config
    from apps.connector.middleware import build_connector_middleware

    user_id = resolve_user_id(user)

    try:
        definition = await _definition_store.load_definition(agent_id, user_id)
    except _file_attachments.AgentNotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        _db_logger.error(f"Failed to load agent {agent_id} for readiness: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    # ``check_readiness`` gates the grading stage on a truthy ``request``:
    # grading asks "is the available evidence sufficient *for this request*",
    # and there is nothing to ask about without one. The builder has no request
    # to offer -- it is configuring the agent, not using it -- so asking for
    # ``grade=true`` from there ran nothing at all and the Evidence Check
    # control could never show a result. The agent's own statement of what it
    # is for is the honest stand-in.
    effective_request = (request_text or "").strip()
    if grade and not effective_request:
        effective_request = _readiness_probe_request(definition)

    def _run():
        # Off the event loop: connector and document resolution both bridge to
        # async services, and awaiting them from the loop thread would stall
        # (the rule Phase 5b.1 established).
        connectors = build_connector_middleware(definition, user_id=user_id)
        # No ``request``: this is a preview of the agent's configuration, and
        # pre-retrieval would spend an embedding call per source every time the
        # builder is opened. The gate reads which sources resolved, not what
        # they contain.
        context = build_agent_context_middleware(definition, user_id=user_id)
        return check_readiness(
            definition,
            request=effective_request,
            user_id=user_id,
            context=context.context if context else None,
            connectors=connectors.connectors if connectors else None,
            allow_grading=bool(grade),
        )

    try:
        report = await asyncio.to_thread(_run)
    except Exception as e:
        _db_logger.error(f"Readiness check failed for agent {agent_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "agent_id": definition.get("agent_id", agent_id),
        **report.to_response(
            definition.get("name") or "This agent",
            settings=readiness_config.describe_settings(definition),
        ),
    }


@router.get('/{agent_id}/files')
async def list_agent_files(agent_id: str, user: UserContext = Depends(require_user)):
    """
    List the files and URLs attached to an agent.

    Each entry carries its ``status`` (``pending`` / ``processing`` / ``ready``
    / ``failed``), how it reaches the model (``ingest_mode``), which backend
    converted it, and — when image text could not be read — why not.
    """
    try:
        return await _file_attachments.list_attachments(agent_id, resolve_user_id(user))
    except Exception as e:
        raise _context_http_error(e)


@router.post('/{agent_id}/files')
async def attach_agent_files(
    agent_id: str,
    files: List[UploadFile] = File(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Attach one or more files to an agent as persistent context.

    Multipart upload. Any format MarkItDown converts is accepted — PDF, Word,
    Excel, PowerPoint, CSV, HTML, Markdown, text, EPUB, Outlook messages,
    images and audio. Archives are refused.

    Conversion runs in the background, so this returns immediately with each
    file's ``file_id`` and a ``pending`` status; poll ``GET /{agent_id}/files``
    for progress. Uploading content already attached to this agent returns the
    existing entry marked ``deduplicated`` rather than converting it twice.

    ``409`` while Connector Settings is off — the client's disabled state is
    never the enforcement point (spec 6.1). ``413`` over the size limit,
    ``415`` for a type that cannot be converted.
    """
    try:
        uploads = [
            (f.filename or "upload", await _read_upload(f), f.content_type)
            for f in files
        ]
        return await _file_attachments.attach_files(
            agent_id, resolve_user_id(user), uploads
        )
    except HTTPException:
        raise
    except Exception as e:
        _db_logger.error(f"Failed to attach files to agent {agent_id}: {e}")
        raise _context_http_error(e)


@router.post('/{agent_id}/files/url')
async def attach_agent_url(
    agent_id: str,
    request: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Attach a web address to an agent as persistent context.

    Body: ``{url, name?}``. The page is fetched server-side under an address
    guard — private, loopback, link-local and cloud-metadata addresses are
    refused, and every redirect hop is re-checked — then converted to markdown
    and indexed like an uploaded file.

    ``422`` for an address that is malformed or not publicly reachable,
    ``409`` while Connector Settings is off.
    """
    try:
        return await _file_attachments.attach_url(
            agent_id,
            resolve_user_id(user),
            url=str(request.get("url") or ""),
            name=str(request.get("name") or "") or None,
        )
    except Exception as e:
        raise _context_http_error(e)


@router.delete('/{agent_id}/files/{file_id}')
async def detach_agent_file(
    agent_id: str,
    file_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Detach one file or URL from an agent.

    Permitted whether or not Connector Settings is on, so closing the gate
    never traps an attachment. The stored copy is deleted and the source stops
    being retrievable from the next execution onward.
    """
    try:
        return await _file_attachments.detach(agent_id, resolve_user_id(user), file_id)
    except Exception as e:
        raise _context_http_error(e)


@router.post('/{agent_id}/files/{file_id}/refresh')
async def refresh_agent_file(
    agent_id: str,
    file_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Convert and index one attachment again.

    A URL is re-fetched, so a changed page is picked up. A file is re-read from
    its stored copy, so a newly-configured vision model is applied without
    re-uploading. Runs in the background; the entry returns to ``pending``.
    """
    try:
        return await _file_attachments.refresh(agent_id, resolve_user_id(user), file_id)
    except Exception as e:
        raise _context_http_error(e)


@router.get('/{agent_id}/knowledge-bases/available')
async def list_available_knowledge_bases(
    agent_id: str, user: UserContext = Depends(require_user)
):
    """
    List every knowledge base this user could link to an agent.

    Not gated — the options can render behind a disabled control, matching the
    connector picker.
    """
    try:
        return await _file_attachments.list_available_knowledge_bases(resolve_user_id(user))
    except Exception as e:
        raise _context_http_error(e)


@router.get('/{agent_id}/knowledge-bases')
async def list_agent_knowledge_bases(
    agent_id: str, user: UserContext = Depends(require_user)
):
    """List the knowledge bases linked to an agent."""
    try:
        return await _file_attachments.list_knowledge_bases(agent_id, resolve_user_id(user))
    except Exception as e:
        raise _context_http_error(e)


@router.post('/{agent_id}/knowledge-bases')
async def link_agent_knowledge_base(
    agent_id: str,
    request: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Link an existing knowledge base to an agent.

    Body: ``{knowledge_base_id, alias?}``. Read-only from the agent's side —
    linking exposes the base for retrieval and never modifies it. Idempotent:
    re-linking updates the alias rather than duplicating.

    ``404`` for a knowledge base the caller does not own, ``409`` while
    Connector Settings is off.
    """
    try:
        return await _file_attachments.link_knowledge_base(
            agent_id,
            resolve_user_id(user),
            knowledge_base_id=str(request.get("knowledge_base_id") or ""),
            alias=str(request.get("alias") or "") or None,
        )
    except Exception as e:
        raise _context_http_error(e)


@router.delete('/{agent_id}/knowledge-bases/{knowledge_base_id}')
async def unlink_agent_knowledge_base(
    agent_id: str,
    knowledge_base_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Unlink a knowledge base from an agent. Permitted while the gate is off."""
    try:
        return await _file_attachments.unlink_knowledge_base(
            agent_id, resolve_user_id(user), knowledge_base_id
        )
    except Exception as e:
        raise _context_http_error(e)


@router.get('/{agent_id}')
async def get_agent(agent_id: str, user: UserContext = Depends(require_user)):
    """Get agent by ID from registry (DB-first, filesystem fallback)."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # DB-first lookup
        agent = await registry.get_agent_from_db(agent_id, effective_user_id)
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")
        return agent
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get('/registry/list')
async def list_registered_agents(user: UserContext = Depends(require_user)):
    """List all agents in registry (DB-first, filesystem fallback)."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # DB-first
        agents = await registry.list_agents_from_db(effective_user_id)
        return {"agents": agents, "count": len(agents)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get('/registry/master-list')
async def get_master_agent_list(user: UserContext = Depends(require_user)):
    """Get master agent list for workflow builder display (DB-first)."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # DB-first
        return await registry.get_master_list_from_db(effective_user_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put('/{agent_id}')
async def update_agent(agent_id: str, updates: dict, user: UserContext = Depends(require_admin_or_above)):
    """Update an existing agent."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # 1) Update filesystem registry + in-memory cache (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            updated = registry.update_agent(agent_id, updates)
        else:
            _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")
            # Build the updated dict for DB persistence without touching filesystem
            updated = {**updates, "agent_id": agent_id}

        # 2) Persist to PostgreSQL database (graceful degradation)
        try:
            from echolib.database import get_db_session
            from echolib.repositories.agent_repo import AgentRepository

            agent_repo = AgentRepository()
            db_agent_data = copy.deepcopy(updated)
            _ensure_backend_agent_id(db_agent_data)

            # Normalize prefixed agent_id to UUID for database
            if "agent_id" in db_agent_data:
                try:
                    db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
                except (ValueError, Exception):
                    _db_logger.warning(
                        f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                        "cannot be converted to a valid UUID (update)"
                    )
                    raise  # re-raise so the outer except block catches it

            async with get_db_session() as db:
                await agent_repo.upsert(db, effective_user_id, db_agent_data)
            _db_logger.info(f"Agent {agent_id} updated in database")
        except Exception as db_err:
            _db_logger.warning(f"Database update failed for agent {agent_id}: {db_err}")

        return updated
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch('/{agent_id}/schema')
async def update_agent_io_schema(agent_id: str, request: dict, user: UserContext = Depends(require_admin_or_above)):
    """Update agent's input/output schema (for workflow integration)."""
    try:
        registry = container.resolve('agent.registry')
        input_schema = request.get("input_schema")
        output_schema = request.get("output_schema")

        updates = {}
        if input_schema is not None:
            updates["input_schema"] = input_schema
        if output_schema is not None:
            updates["output_schema"] = output_schema
        if not updates:
            raise HTTPException(status_code=400, detail="Provide input_schema or output_schema")

        # Filesystem write (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            updated = registry.update_agent(agent_id, updates)
        else:
            _db_logger.info("Filesystem write skipped for agent (AGENT_DB_WRITE_ONLY=true)")
            updated = {**updates, "agent_id": agent_id}

        # Persist to PostgreSQL database (graceful degradation)
        try:
            from echolib.database import get_db_session
            from echolib.repositories.agent_repo import AgentRepository

            effective_user_id = resolve_user_id(user)
            agent_repo = AgentRepository()
            db_agent_data = copy.deepcopy(updated)
            _ensure_backend_agent_id(db_agent_data)

            # Normalize prefixed agent_id to UUID for database
            if "agent_id" in db_agent_data:
                try:
                    db_agent_data["agent_id"] = normalize_to_uuid(db_agent_data["agent_id"])
                except (ValueError, Exception):
                    _db_logger.warning(
                        f"Skipping DB upsert for agent — ID '{db_agent_data.get('agent_id')}' "
                        "cannot be converted to a valid UUID (patch/schema)"
                    )
                    raise  # re-raise so the outer except block catches it

            async with get_db_session() as db:
                await agent_repo.upsert(db, effective_user_id, db_agent_data)
            _db_logger.info(f"Agent {agent_id} schema updated in database")
        except Exception as db_err:
            _db_logger.warning(f"Database schema update failed for agent {agent_id}: {db_err}")

        return {
            "agent_id": agent_id,
            "input_schema": updated.get("input_schema", []),
            "output_schema": updated.get("output_schema", [])
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete('/{agent_id}')
async def delete_agent(agent_id: str, user: UserContext = Depends(require_admin_or_above)):
    """Delete an agent from registry and database.

    Ordering: DB soft-delete first (authoritative store), then FS soft-delete.
    If DB fails, FS is NOT modified and an error is returned.
    If DB succeeds but FS fails, the deletion is still considered successful
    because the database is the source of truth.
    """
    effective_user_id = resolve_user_id(user)

    # ------------------------------------------------------------------
    # Step 1: DB soft-delete FIRST (authoritative store)
    # ------------------------------------------------------------------
    try:
        from echolib.database import get_db_session
        from echolib.repositories.agent_repo import AgentRepository

        db_agent_id = normalize_to_uuid(agent_id)
        agent_repo = AgentRepository()
        async with get_db_session() as db:
            db_deleted = await agent_repo.delete(db, db_agent_id, effective_user_id)

        if db_deleted:
            _db_logger.info(f"Agent {agent_id} soft-deleted from database")
        else:
            _db_logger.info(
                f"Agent {agent_id} not found in database (may be FS-only agent)"
            )
    except (ValueError, Exception) as db_err:
        # DB delete failed — do NOT touch the filesystem.
        _db_logger.error(
            f"Database delete failed for agent {agent_id}: {db_err}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail=(
                f"Failed to delete agent {agent_id}: database operation failed. "
                "Filesystem was not modified. Please retry."
            ),
        )

    # ------------------------------------------------------------------
    # Step 2: FS soft-delete (best-effort; DB is already authoritative)
    #         Skipped when AGENT_DB_WRITE_ONLY is enabled.
    # ------------------------------------------------------------------
    if not _settings.AGENT_DB_WRITE_ONLY:
        try:
            registry = container.resolve('agent.registry')
            registry.delete_agent(agent_id, soft_delete=True)
        except ValueError:
            # Agent not found in filesystem registry — acceptable when the
            # agent only exists in the database.
            _db_logger.info(
                f"Agent {agent_id} not found in filesystem registry (DB-only agent)"
            )
        except Exception as fs_err:
            # FS soft-delete failed but DB already succeeded — log and continue.
            _db_logger.warning(
                f"Filesystem soft-delete failed for agent {agent_id} after "
                f"successful DB delete: {fs_err}. DB is authoritative; "
                "the FS file will be cleaned up later.",
                exc_info=True,
            )
    else:
        _db_logger.info("Filesystem delete skipped for agent (AGENT_DB_WRITE_ONLY=true)")

    return {"message": "Agent deleted", "agent_id": agent_id}


@router.get('/role/{role}')
async def get_agents_by_role(role: str, user: UserContext = Depends(require_user)):
    """Get agents by role (DB-first, filesystem fallback)."""
    try:
        registry = container.resolve('agent.registry')
        effective_user_id = resolve_user_id(user)

        # DB-first
        agents = await registry.get_agents_by_role_from_db(role, effective_user_id)
        return {"role": role, "agents": agents, "count": len(agents)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Agent Factory
@router.post('/instantiate/{agent_id}')
async def instantiate_agent(agent_id: str, bind_tools: bool = True, user: UserContext = Depends(require_user)):
    """Create runtime agent instance from definition (DB-first)."""
    try:
        registry = container.resolve('agent.registry')
        factory = container.resolve('agent.factory')
        effective_user_id = resolve_user_id(user)

        # DB-first agent lookup
        agent_def = await registry.get_agent_from_db(agent_id, effective_user_id)
        if not agent_def:
            raise HTTPException(status_code=404, detail="Agent not found")
        instance = factory.create_agent(agent_def, bind_tools=bind_tools, user_id=effective_user_id)
        return instance
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post('/instantiate/batch')
async def instantiate_agents_batch(agent_ids: list, user: UserContext = Depends(require_user)):
    """Create multiple runtime agent instances (DB-first)."""
    try:
        registry = container.resolve('agent.registry')
        factory = container.resolve('agent.factory')
        effective_user_id = resolve_user_id(user)

        # DB-first batch lookup
        agent_defs = await registry.get_agents_for_workflow_from_db(
            agent_ids, effective_user_id
        )
        instances = factory.create_agents_for_workflow(agent_defs, user_id=effective_user_id)
        return {"instances": instances, "count": len(instances)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Agent Permissions
@router.post('/permissions/check')
async def check_permission(
    caller_id: str,
    target_id: str,
    workflow: dict,
    agents: dict,
    user: UserContext = Depends(require_user),
):
    """Check if caller can communicate with target agent."""
    try:
        permissions = container.resolve('agent.permissions')
        allowed = permissions.can_call_agent(
            caller_id=caller_id,
            target_id=target_id,
            workflow=workflow,
            agent_registry=agents
        )
        return {
            "caller_id": caller_id,
            "target_id": target_id,
            "allowed": allowed
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post('/permissions/validate')
async def validate_permissions(workflow: dict, agents: dict, user: UserContext = Depends(require_user)):
    """Validate all permissions in a workflow."""
    try:
        permissions = container.resolve('agent.permissions')
        errors = permissions.validate_workflow_permissions(workflow, agents)
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get('/permissions/targets/{agent_id}')
async def get_allowed_targets(agent_id: str, workflow: dict, agents: dict, user: UserContext = Depends(require_user)):
    """Get list of agents that the given agent can call."""
    try:
        permissions = container.resolve('agent.permissions')
        targets = permissions.get_allowed_targets(
            agent_id=agent_id,
            workflow=workflow,
            agent_registry=agents
        )
        return {
            "agent_id": agent_id,
            "allowed_targets": targets
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ==================== AGENT TEMPLATES ====================

@router.get('/templates/all')
async def get_all_agent_templates(user: UserContext = Depends(require_user)):
    """
    Get all agent templates (static + created agents).
    Combines static templates from JSON file with agents from registry.
    """
    try:
        from pathlib import Path
        registry = container.resolve('agent.registry')

        # Load static templates
        templates_path = Path(__file__).parent.parent / "storage" / "agent_templates.json"
        static_templates = []
        if templates_path.exists():
            with open(templates_path, encoding='utf-8') as f:
                data = json.load(f)
                static_templates = data.get("templates", [])

        # Get created agents from registry (DB-first)
        effective_user_id = resolve_user_id(user)
        master_list = await registry.get_master_list_from_db(effective_user_id)
        created_agents = master_list.get("agents", [])

        # Format created agents as templates
        created_templates = []
        for agent in created_agents:
            created_templates.append({
                "name": agent.get("name", "Unnamed Agent"),
                "icon": agent.get("icon", "🤖"),
                "description": agent.get("description", ""),
                "role": agent.get("role", ""),
                "agent_id": agent.get("agent_id"),
                "source": "created"
            })

        return {
            "templates": static_templates,
            "created": created_templates,
            "total_templates": len(static_templates),
            "total_created": len(created_templates),
            "total": len(static_templates) + len(created_templates)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/templates/static')
async def get_static_templates(user: UserContext = Depends(require_user)):
    """Get only static agent templates from JSON file."""
    try:
        from pathlib import Path
        templates_path = Path(__file__).parent.parent / "storage" / "agent_templates.json"
        if not templates_path.exists():
            return {"templates": [], "count": 0}
        with open(templates_path, encoding='utf-8') as f:
            data = json.load(f)
            templates = data.get("templates", [])
        return {
            "templates": templates,
            "count": len(templates)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== INTENT CLASSIFICATION (LLM-based) ====================

@router.post('/classify-intent')
async def classify_user_intent(request: dict, user: UserContext = Depends(require_user)):
    """
    Classify user intent using LLM reasoning.
    This endpoint enables natural language understanding for conversational flows.
    Instead of pattern matching, it uses LLM to understand user intent.

    Request body:
    {
      "context": "name_confirmation" | "refinement" | "tool_selection" | "general",
      "suggested_value": "FinGenius Pro",
      "user_message": "oh yes this name is great",
      "conversation_history": [...] // Optional: previous messages for context
    }

    Response:
    {
      "intent": "CONFIRMATION" | "MODIFICATION" | "REJECTION" | "CLARIFICATION",
      "confidence": 0.95,
      "reasoning": "...",
      "extracted_value": null | "new value if modification"
    }
    """
    try:
        service = container.resolve('agent.service')
        context = request.get("context", "general")
        suggested_value = request.get("suggested_value", "")
        user_message = request.get("user_message", "")
        conversation_history = request.get("conversation_history", [])
        if not user_message:
            raise HTTPException(status_code=400, detail="user_message is required")

        effective_user_id = resolve_user_id(user)

        result = service.classify_user_intent(
            context=context,
            suggested_value=suggested_value,
            user_message=user_message,
            conversation_history=conversation_history,
            user_id=effective_user_id
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== AGENT CHAT (ADDED) ====================

def _get_registry():
    return container.resolve('agent.registry')

def _get_factory():
    return container.resolve('agent.factory')

def _get_chat_store():
    """
    Optional conversation store registered as 'agent.chat_store' in the container.
    Expected interface:
      - new_session(agent_id: str) -> str
      - append(session_id: str, role: str, content: str) -> None
      - history(session_id: str) -> List[Dict[str, str]]
    """
    try:
        return container.resolve('agent.chat_store')
    except Exception:
        return None

async def _run_agent_chat(runtime, **kwargs):
    """
    Run a synchronous agent chat without blocking the event loop.

    ``AgentRuntime.chat`` compiles the agent and drives the whole model round
    trip synchronously. Calling it directly from a route held the loop for the
    duration of the request, and — since phase 5b — also deadlocked connector
    resolution, which awaits the API and MCP services on that same loop.
    ``asyncio.to_thread`` copies the current context, so the authenticated user
    context vars are preserved.
    """
    chat = getattr(runtime, "chat")
    if inspect.iscoroutinefunction(chat):
        return await chat(**kwargs)
    return await asyncio.to_thread(lambda: chat(**kwargs))

@router.post('/{agent_id}/session')
async def create_session(agent_id: str, user: UserContext = Depends(require_user)):
    """
    Create a new chat session id for multi-turn conversations.
    Falls back to a random UUID if no chat_store is available.
    """
    try:
        chat_store = _get_chat_store()
        if chat_store:
            session_id = chat_store.new_session(agent_id)
        else:
            import uuid
            session_id = str(uuid.uuid4())
        return {"agent_id": agent_id, "session_id": session_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/{agent_id}/chat')
async def chat_with_agent(agent_id: str, payload: dict = Body(...), user: UserContext = Depends(require_user)):
    """
    Non-streaming chat with an agent.
    Body:
      {
        "message": "text",                # required
        "session_id": "uuid",             # optional
        "context": {...},                 # optional
        "metadata": {...},                # optional
        "tools": [ { "name": "...", "args": {...} } ]  # optional
      }
    """
    try:
        registry = _get_registry()
        factory = _get_factory()
        effective_user_id = resolve_user_id(user)

        # DB-first agent lookup
        agent_def = await registry.get_agent_from_db(agent_id, effective_user_id)
        if not agent_def:
            raise HTTPException(status_code=404, detail="Agent not found")

        runtime = factory.create_agent(agent_def, bind_tools=True, user_id=effective_user_id)

        user_message = (payload.get("message") or "").strip()
        if not user_message:
            raise HTTPException(status_code=400, detail="`message` is required")

        session_id: Optional[str] = payload.get("session_id")
        context: Dict[str, Any] = payload.get("context") or {}
        metadata: Dict[str, Any] = payload.get("metadata") or {}
        tool_overrides: List[Dict[str, Any]] = payload.get("tools") or []

        chat_store = _get_chat_store()
        history = []
        if session_id and chat_store:
            history = chat_store.history(session_id)
        if chat_store:
            if not session_id:
                session_id = chat_store.new_session(agent_id)
            chat_store.append(session_id, "user", user_message)

        # Call into runtime; support both sync and async runtimes.
        reply = await _run_agent_chat(
            runtime,
            message=user_message,
            history=history,
            context=context,
            tools=tool_overrides,
            metadata=metadata,
            user_id=effective_user_id,
        )

        # Persist assistant turn if we have text content
        if chat_store:
            content = reply.get("content") if isinstance(reply, dict) else str(reply)
            if content:
                chat_store.append(session_id, "assistant", content)

        return {
            "agent_id": agent_id,
            "session_id": session_id,
            "reply": reply
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post('/{agent_id}/chat/stream')
async def chat_with_agent_stream(agent_id: str, payload: dict = Body(...), user: UserContext = Depends(require_user)):
    """
    Stream an agent's reply as Server-Sent Events.

    WHAT: Emits one SSE frame per ``AgentEvent`` -- ``token`` fragments as the
          model writes them, ``tool_start`` / ``tool_end`` as it works, then a
          single terminal ``final`` or ``error``.
    WHY:  This endpoint advertised streaming and never streamed. It probed the
          runtime for a ``stream_chat`` attribute that has never existed on
          ``AgentRuntime``, so every request took the fallback branch, ran the
          whole model round trip to completion and emitted the entire reply as
          one ``token`` frame. It also served ``application/json`` rather than
          ``text/event-stream``, so a browser ``EventSource`` could not consume
          it at all.

    ``EventSourceResponse`` rather than a hand-rolled ``StreamingResponse``: it
    supplies the ping comment that keeps proxies from closing an idle
    connection during a long tool call, correct frame separation, and
    cancellation of this generator when the reader disconnects. The dependency
    is already installed.

    Wire format change: line-delimited JSON becomes SSE. No frontend consumes
    this endpoint today; it is recorded as a Phase 9 frontend TODO.
    """
    from sse_starlette.sse import EventSourceResponse

    from apps.agent.streaming import EVENT_ERROR, EVENT_FINAL

    # Resolve the definition here, not inside the generator: the lookup is
    # user-scoped and a 404 must be an HTTP status, not an event in a stream
    # whose headers have already been sent.
    effective_user_id = resolve_user_id(user)
    registry = _get_registry()
    agent_def = await registry.get_agent_from_db(agent_id, effective_user_id)
    if not agent_def:
        raise HTTPException(status_code=404, detail="Agent not found")

    user_message = (payload.get("message") or "").strip()
    if not user_message:
        raise HTTPException(status_code=400, detail="`message` is required")

    context: Dict[str, Any] = payload.get("context") or {}
    session_id: Optional[str] = payload.get("session_id")

    chat_store = _get_chat_store()
    history: List[Any] = []
    if chat_store:
        if session_id:
            history = chat_store.history(session_id)
        else:
            session_id = chat_store.new_session(agent_id)
        chat_store.append(session_id, "user", user_message)

    from echolib.di import container

    runner = container.resolve("agent.standalone")

    async def event_stream() -> AsyncGenerator[Dict[str, Any], None]:
        yield {"event": "start", "data": json.dumps({"session_id": session_id})}

        final_text = ""
        async for event in runner.astream(
            agent_id=agent_id,
            user_input=user_message,
            definition=agent_def,
            user_id=effective_user_id,
            context=context,
            history=history,
        ):
            if event.type == EVENT_FINAL:
                final_text = event.text
            yield {"event": event.type, "data": json.dumps(event.to_dict())}

        # Persisted after the stream so an aborted turn is not stored as if it
        # completed. The reply is committed once, on the terminal event.
        if chat_store and final_text:
            chat_store.append(session_id, "assistant", final_text)

        yield {"event": "end", "data": json.dumps({"session_id": session_id})}

    return EventSourceResponse(
        event_stream(),
        # A tool call can run for tens of seconds with nothing to say. Without a
        # periodic comment frame an idle connection is closed by intermediate
        # proxies and the reader sees a truncated answer.
        ping=15,
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )

@router.get('/{agent_id}/history/{session_id}')
async def get_history(agent_id: str, session_id: str, user: UserContext = Depends(require_user)):
    """
    Return full conversation history for a session (requires agent.chat_store).
    """
    chat_store = _get_chat_store()
    if not chat_store:
        raise HTTPException(status_code=404, detail="No chat history backend configured")
    try:
        history = chat_store.history(session_id)
        return {"agent_id": agent_id, "session_id": session_id, "messages": history, "count": len(history)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))