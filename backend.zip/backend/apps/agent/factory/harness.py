"""
Agent harness selection.

WHAT: Chooses the graph builder that compiles an Echo agent -- Deep Agents when
      the package is installed *and* the deployment opts in, LangChain's
      ``create_agent`` otherwise.
WHY:  Plan phase 2 adopts Deep Agents for planning and subagent delegation, but
      ``deepagents`` is not a hard dependency of this deployment. Making the
      choice explicit and isolated keeps the rest of the factory identical under
      both harnesses instead of scattering optional imports through it.

Security -- read before changing the default.

``create_deep_agent`` is a batteries-included harness: on top of the tools it is
given it attaches its own. Measured against deepagents 0.4.12, compiling an Echo
agent with ``tools=[]`` produced nine tools the platform never granted::

    execute      shell commands in a sandbox
    read_file  write_file  edit_file  ls  glob  grep      a full filesystem
    task         spawns subagents
    write_todos  the planner

Only the last one is what this platform adopted Deep Agents for today, and it is
equally available as ``TodoListMiddleware`` on plain ``create_agent``. The rest
are a capability grant, and they are invisible to every control Echo has: the
readiness gate does not know about them, the connector permission model does not
cover them, ``ToolCallLimitMiddleware``'s ceiling is computed from Echo's own
tool counts, and the per-tool approval surface (``interrupt_on``) is built from
the agent's configuration. A citizen developer who attached no tools would get a
shell.

There is no ``builtin_tools`` switch on ``create_deep_agent`` in this release --
the tools come from its default middleware stack -- so the surface cannot be
narrowed at the call site. The harness therefore defaults to ``create_agent``,
where every tool an agent has is one Echo put there, and Deep Agents is opt-in
via ``ECHO_AGENT_HARNESS=deepagents`` for a deployment that wants that surface
and has decided to accept it.

Nothing else about the Deep Agents decision changes: ``provides_planner`` still
reports correctly, the factory still passes the same arguments, and switching
the variable switches the harness with no code change.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Callable, List, Optional, Tuple

logger = logging.getLogger(__name__)

HARNESS_DEEPAGENTS = "deepagents"
HARNESS_LANGCHAIN = "langchain"

# Deep Agents attached ``TodoListMiddleware`` itself up to and including 0.6.
# From 0.7 planning is opt-in and the harness attaches nothing, so the caller
# has to supply the planner or the agent runs without one.
_DEEPAGENTS_AUTO_PLANNER_BELOW = (0, 7)

HARNESS_ENV_VAR = "ECHO_AGENT_HARNESS"

_resolved: Optional[Tuple[Callable[..., Any], str]] = None


def _requested_harness() -> str:
    """Harness named by the deployment, lowercased; empty when unset."""
    return (os.getenv(HARNESS_ENV_VAR) or "").strip().lower()


def _resolve_harness() -> Tuple[Callable[..., Any], str]:
    """
    Resolve the graph builder once per process.

    Deep Agents is used only when explicitly requested. See the module docstring
    for why installation alone is not treated as consent.
    """
    global _resolved
    if _resolved is not None:
        return _resolved

    from langchain.agents import create_agent

    requested = _requested_harness()

    if requested == HARNESS_DEEPAGENTS:
        try:
            from deepagents import create_deep_agent

            _resolved = (create_deep_agent, HARNESS_DEEPAGENTS)
            logger.warning(
                "Agent harness: deepagents (%s=%s). This harness attaches its own "
                "filesystem, shell ('execute') and subagent tools to every agent, "
                "in addition to the tools Echo binds.",
                HARNESS_ENV_VAR,
                requested,
            )
            return _resolved
        except ImportError:
            logger.warning(
                "%s=deepagents but the 'deepagents' package is not installed; "
                "falling back to langchain create_agent.",
                HARNESS_ENV_VAR,
            )

    _resolved = (create_agent, HARNESS_LANGCHAIN)
    logger.info(
        "Agent harness: langchain create_agent (planning provided by "
        "TodoListMiddleware; set %s=deepagents to opt into the Deep Agents "
        "harness and its built-in tool surface)",
        HARNESS_ENV_VAR,
    )
    return _resolved


def reset_harness() -> None:
    """Drop the cached resolution. For process-level reconfiguration only."""
    global _resolved
    _resolved = None


def harness_name() -> str:
    """Return the active harness identifier."""
    return _resolve_harness()[1]


def _deepagents_version() -> Tuple[int, ...]:
    """Installed ``deepagents`` version as a comparable tuple, ``()`` if absent."""
    try:
        from importlib.metadata import version

        raw = version("deepagents")
    except Exception:
        return ()

    parts: List[int] = []
    for chunk in raw.split(".")[:3]:
        digits = "".join(c for c in chunk if c.isdigit())
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def provides_planner() -> bool:
    """
    True when the harness attaches its own planning middleware.

    WHAT: Version-aware, not a flat "is this deepagents" answer.
    WHY:  Deep Agents attached ``TodoListMiddleware`` by default through 0.6, so
          adding a second instance registered ``write_todos`` twice. Release 0.7
          made planning opt-in and attaches nothing. Answering ``True`` there
          would suppress Echo's own planner and leave the agent with no planning
          at all -- a silent capability loss on a dependency upgrade, which is
          worse than a duplicate tool because nothing errors.
    OUTPUT: True only for a Deep Agents release that still auto-attaches one.
    """
    if harness_name() != HARNESS_DEEPAGENTS:
        return False

    version = _deepagents_version()
    if not version:
        # Importable but unversioned: assume it does not plan for us and let the
        # factory attach the planner. A duplicate tool is recoverable; a missing
        # planner is invisible.
        return False
    return version < _DEEPAGENTS_AUTO_PLANNER_BELOW


def create_harness_agent(
    *,
    model: Any,
    tools: List[Any],
    middleware: List[Any],
    checkpointer: Any = None,
    name: Optional[str] = None,
) -> Any:
    """
    Compile an agent graph on the active harness.

    WHAT: Calls ``create_deep_agent`` or ``create_agent`` with an identical
          argument set.
    WHY:  Both accept the same core signature, so the factory never branches.
    INPUT: Chat model, bound tools, middleware stack, optional checkpointer/name.
    OUTPUT: A compiled LangGraph state graph.

    The system prompt is intentionally not passed here: it is supplied by the
    ``dynamic_prompt`` middleware inside ``middleware`` so it can react to
    runtime state.
    """
    builder, _ = _resolve_harness()

    return builder(
        model=model,
        tools=tools,
        middleware=middleware,
        checkpointer=checkpointer,
        name=name,
    )


__all__ = [
    "HARNESS_DEEPAGENTS",
    "HARNESS_ENV_VAR",
    "HARNESS_LANGCHAIN",
    "create_harness_agent",
    "harness_name",
    "provides_planner",
    "reset_harness",
]
