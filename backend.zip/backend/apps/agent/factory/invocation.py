"""
Invocation helpers for compiled agent graphs.

WHAT: Builds the message payload, applies the recursion limit and extracts the
      final assistant text from a compiled agent's result.
WHY:  Standalone chat and workflow nodes both invoke the same compiled graph;
      without a shared extractor they disagree on how to read content blocks and
      on what recursion limit to apply.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

from .completion import last_truncation_reason, note_truncation

logger = logging.getLogger(__name__)

DEFAULT_RECURSION_LIMIT = 12

TOOL_CEILING_ATTRIBUTE = "_echo_tool_ceiling"
"""Where the factory records a compiled graph's total tool allowance.

Stamped on the graph rather than threaded through ``run`` because all four
invocation entry points receive only the compiled graph, and the callers in
between (``standalone``, the workflow nodes, the application executor) have no
reason to know about a recursion limit.
"""

STEP_COST_ATTRIBUTE = "_echo_steps_per_cycle"
"""Where the factory records super-steps consumed per model-plus-tool cycle."""

BARE_CYCLE_STEPS = 2
"""A model turn plus a tool turn: the cost with no middleware attached."""

DEFAULT_CYCLE_STEPS = 6
"""Fallback per-cycle cost when the built stack could not be measured.

Matches the standard stack -- ``ModelCallLimitMiddleware`` (before + after),
``ToolCallLimitMiddleware`` (after) and ``TodoListMiddleware`` (after) are four
nodes, plus the model and tool nodes. Verified against measurement: at a limit
of 6n+1 an agent completes exactly n tool calls.
"""

RECURSION_MARGIN_STEPS = 6
"""Headroom above the computed requirement.

The tool budget is what should stop a run; this ceiling only has to be
comfortably clear of it so it never becomes the operative limit. One cycle of
slack absorbs the wind-down turn plus any hook that appears mid-run.
"""


def graph_tool_ceiling(agent: Any) -> int:
    """
    The total tool allowance a compiled graph was built with, or 0.

    0 for any graph built before this was stamped, which resolves the recursion
    limit to exactly the previous constant.
    """
    try:
        return max(0, int(getattr(agent, TOOL_CEILING_ATTRIBUTE, 0) or 0))
    except (TypeError, ValueError):
        return 0


def graph_cycle_steps(agent: Any) -> int:
    """Super-steps one cycle costs on this graph, or the measured default."""
    try:
        recorded = int(getattr(agent, STEP_COST_ATTRIBUTE, 0) or 0)
    except (TypeError, ValueError):
        return DEFAULT_CYCLE_STEPS
    return recorded if recorded >= BARE_CYCLE_STEPS else DEFAULT_CYCLE_STEPS


def record_tool_ceiling(
    agent: Any, tool_call_limit: int, cycle_steps: int = 0
) -> None:
    """Record the tool allowance and per-cycle step cost on a compiled graph."""
    try:
        setattr(agent, TOOL_CEILING_ATTRIBUTE, max(0, int(tool_call_limit)))
        if cycle_steps >= BARE_CYCLE_STEPS:
            setattr(agent, STEP_COST_ATTRIBUTE, int(cycle_steps))
    except Exception:  # noqa: BLE001 -- some compiled objects are frozen
        logger.debug("Could not record the tool ceiling on the compiled graph")


def resolve_recursion_limit(tool_call_limit: int = 0, cycle_steps: int = 0) -> int:
    """
    Resolve the LangGraph recursion limit for one run.

    LangGraph counts **super-steps**, and one model-plus-tool cycle costs far
    more than the two nodes a bare ReAct loop would suggest: **every**
    ``before_model`` / ``after_model`` hook in the middleware stack compiles to
    its own node, and therefore its own super-step. The standard stack adds four
    such nodes, so a cycle costs six steps, not two.

    That distinction is the whole defect this parameter exists to prevent. Sized
    at ``2n + 1`` an agent with an eight-call budget aborted with
    ``GraphRecursionError`` after **two** tool calls -- the graph safety net
    firing long before the tool budget it was supposed to sit behind. Measured:

    ======================  ====================
    ``recursion_limit``     tool calls completed
    ======================  ====================
    13                      2
    17                      2
    19                      3
    25                      4
    31                      5
    49                      8
    ======================  ====================

    So the requirement is ``cycle_steps * n + margin``. ``ToolCallLimitMiddleware``
    (``exit_behavior="end"``) is what actually stops the run; this only has to
    stay clear of it, and remains a backstop against a genuinely
    non-terminating graph.

    Both arguments default to 0 so a caller that passes nothing gets the
    configured value unchanged -- the previous behaviour exactly. An explicit
    ``AGENT_RECURSION_LIMIT`` still applies and still wins whenever it is the
    larger, so an operator can raise the ceiling but never silently lower it
    below what the agent's own budget requires.
    """
    try:
        configured = max(1, int(os.getenv("AGENT_RECURSION_LIMIT", str(DEFAULT_RECURSION_LIMIT))))
    except ValueError:
        configured = DEFAULT_RECURSION_LIMIT

    calls = max(0, tool_call_limit)
    if calls <= 0:
        return configured

    per_cycle = cycle_steps if cycle_steps >= BARE_CYCLE_STEPS else DEFAULT_CYCLE_STEPS
    required = per_cycle * calls + RECURSION_MARGIN_STEPS
    return max(configured, required)


def build_messages(task: str, history: Optional[List[Any]] = None) -> List[Any]:
    """
    Convert a task plus optional prior turns into LangChain messages.

    The system prompt is deliberately absent: it is supplied by the agent's
    ``dynamic_prompt`` middleware, so callers must never prepend their own.
    """
    from langchain_core.messages import AIMessage, HumanMessage

    messages: List[Any] = []

    for turn in history or []:
        if isinstance(turn, dict):
            role = turn.get("role", "user")
            content = turn.get("content", "")
        else:
            role = "user"
            content = str(turn)

        if not content:
            continue
        messages.append(AIMessage(content=content) if role == "assistant" else HumanMessage(content=content))

    messages.append(HumanMessage(content=task))
    return messages


def extract_final_text(result: Any) -> str:
    """
    Read the final assistant text out of a compiled agent's result.

    Handles the content-block list form that Anthropic and Gemini return, which
    would otherwise be stringified as a Python list into the workflow state.

    Appends the truncation note when the provider says the run stopped at the
    output ceiling. Both streaming paths have done this since they were
    written; this path did not, so an answer cut off mid-sentence was returned
    as though it were finished. The check covers messages carrying tool calls
    too -- a document generator's payload is a tool call, and that is exactly
    where a silent cut-off does the most damage.
    """
    messages = result.get("messages", []) if isinstance(result, dict) else []
    if not messages:
        return ""

    content = getattr(messages[-1], "content", messages[-1])

    if isinstance(content, list):
        text = " ".join(
            str(block.get("text", block) if isinstance(block, dict) else block)
            for block in content
        )
    else:
        text = content if isinstance(content, str) else str(content)

    return note_truncation(text, last_truncation_reason(messages), where="invoke_agent")


def invoke_agent(
    agent: Any,
    task: str,
    *,
    history: Optional[List[Any]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Invoke a compiled agent graph and return its final text.

    WHAT: One invocation shape for every execution path.
    WHY:  Retry and budget enforcement now live in middleware, so callers must
          not wrap this in their own loops.
    INPUT: Compiled graph, task text, optional history and LangGraph config.
    OUTPUT: Final assistant text.
    RAISES: Propagates model and graph errors for the caller to report.
    """
    invoke_config: Dict[str, Any] = {
        "recursion_limit": resolve_recursion_limit(
            graph_tool_ceiling(agent), graph_cycle_steps(agent)
        )
    }
    if config:
        invoke_config.update(config)

    result = agent.invoke({"messages": build_messages(task, history)}, config=invoke_config)
    return extract_final_text(result)


async def ainvoke_agent(
    agent: Any,
    task: str,
    *,
    history: Optional[List[Any]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Await a compiled agent graph and return its final text.

    WHAT: The async twin of ``invoke_agent``, identical in every other respect.
    WHY:  Callers already on the event loop -- the application orchestrator and
          the agent HTTP routes -- previously had to push the synchronous call
          into a worker thread, which held a thread for the whole model round
          trip. The compiled graph is natively async, so awaiting it is both
          correct and cheaper. ``invoke_agent`` stays for the workflow nodes,
          which LangGraph invokes synchronously.
    INPUT: Compiled graph, task text, optional history and LangGraph config.
    OUTPUT: Final assistant text.
    RAISES: Propagates model and graph errors for the caller to report.
    """
    invoke_config: Dict[str, Any] = {
        "recursion_limit": resolve_recursion_limit(
            graph_tool_ceiling(agent), graph_cycle_steps(agent)
        )
    }
    if config:
        invoke_config.update(config)

    result = await agent.ainvoke(
        {"messages": build_messages(task, history)}, config=invoke_config
    )
    return extract_final_text(result)
