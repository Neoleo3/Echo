"""
Dict-like runtime facade over an agent definition.

WHAT: Keeps the historical ``AgentRuntime`` surface -- attribute access, dict
      access and ``.chat()`` -- while delegating all execution to
      ``AgentFactory.build``.
WHY:  ``/agents/instantiate/{id}`` returns this object straight to the HTTP
      layer and ``/agents/{id}/chat`` calls ``.chat()`` on it, so the shape is
      part of the public API. Only the execution underneath changes: the
      hand-rolled ReAct loop is gone.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from .invocation import invoke_agent

logger = logging.getLogger(__name__)

# OTel tracing -- soft import
try:
    from echolib.otel import get_metrics_collector, get_tracer

    _tracer = get_tracer("agent.factory")
except ImportError:
    _tracer = None
    get_metrics_collector = None


class AgentRuntime:
    """
    Runtime wrapper around an agent definition that exposes a ``.chat()`` method.

    Stores the original agent definition dict and makes its keys accessible as
    attributes so existing code that reads agent_id, name, tools, etc. continues
    to work unchanged.
    """

    def __init__(
        self,
        agent_def: Dict[str, Any],
        factory: Any,
        tools: Optional[List[Any]] = None,
        tool_defs: Optional[List[Any]] = None,
    ):
        self._agent_def = agent_def
        self._factory = factory
        self._tools = tools or []
        self._tool_defs: List[Any] = tool_defs or []

        # Expose dict keys as direct attributes
        for key, value in agent_def.items():
            setattr(self, key, value)

        # Ensure common fields exist even if missing from agent_def
        if not hasattr(self, "agent_id"):
            self.agent_id = agent_def.get("agent_id") or agent_def.get("id")
        if not hasattr(self, "runtime_ready"):
            self.runtime_ready = True

    # ---- dict-like access for backward compatibility ----

    def get(self, key: str, default=None):
        return self._agent_def.get(key, default)

    def __getitem__(self, key: str):
        return self._agent_def[key]

    def __contains__(self, key: str):
        return key in self._agent_def

    def keys(self):
        return self._agent_def.keys()

    def values(self):
        return self._agent_def.values()

    def items(self):
        return self._agent_def.items()

    # ---- core chat method ----

    def chat(
        self,
        message: str,
        history: Optional[list] = None,
        context: Optional[dict] = None,
        tools: Optional[list] = None,
        metadata: Optional[dict] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, str]:
        """
        Send a message to the agent and return its response.

        WHAT: Builds the agent through the single instantiation path and invokes
              the compiled graph.
        WHY:  Standalone chat must behave exactly like the same agent inside a
              workflow, which is only true if both compile the same graph.
        INPUT: User message plus optional history/context/metadata.
        OUTPUT: Dict with 'content' (str) and 'role' ('assistant').

        The agent is rebuilt on every call so credentials are re-resolved from
        Key Vault each time and are never cached on this object.

        Args:
            message: User's message text.
            history: Prior conversation turns (dicts with role/content).
            context: Optional execution context passed to tools.
            tools: Accepted for API compatibility; tool selection comes from the
                agent definition.
            metadata: Optional metadata dict, unused by execution.
            user_id: Authenticated user UUID for credential resolution.

        Returns:
            Dict with keys "content" and "role".
        """
        effective_user_id = user_id or self._agent_def.get("_runtime_user_id")
        agent_id = self._agent_def.get("agent_id", "unknown")

        build = self._factory.build_with_context(
            self._agent_def,
            user_id=effective_user_id,
            tool_specs=self._agent_def.get("_runtime_tool_refs"),
            exec_context=context or {},
            bind_tools=bool(self._agent_def.get("_runtime_bind_tools", True)),
            component="agent_runtime",
            request=message,
            readiness_state=context or {},
        )

        # Context Readiness Gate (spec 4.3). Only ``block`` mode reaches this:
        # ``warn`` -- the default -- has already put the same findings in the
        # system prompt, and ``off`` produced none. The message is returned as
        # the assistant's turn rather than raised, because the user asked a
        # question and is owed an answer about why it cannot be answered.
        if build.blocked:
            message_out = build.readiness_message(self._agent_def.get("name", ""))
            logger.info("Readiness gate blocked chat with agent '%s'", agent_id)
            self._record_metrics(agent_id, build, time.time(), status="blocked")
            return {"content": message_out, "role": "assistant"}

        started = time.time()
        span_ctx = (
            _tracer.start_as_current_span(
                "agent.chat",
                attributes={
                    "agent.id": agent_id,
                    "agent.model": build.binding.model_name,
                    "agent.provider": build.binding.provider or "",
                    "agent.harness": build.harness,
                },
            )
            if _tracer
            else None
        )

        try:
            if span_ctx:
                with span_ctx:
                    content = invoke_agent(build.agent, message, history=history)
            else:
                content = invoke_agent(build.agent, message, history=history)
        except Exception:
            self._record_metrics(agent_id, build, started, status="error")
            raise

        self._record_metrics(agent_id, build, started, status="success")
        return {"content": content, "role": "assistant"}

    @staticmethod
    def _record_metrics(agent_id: str, build: Any, started: float, *, status: str) -> None:
        """Emit chat metrics, never letting telemetry failures surface to callers."""
        if not get_metrics_collector:
            return
        try:
            get_metrics_collector().record_agent_chat(
                agent_id=agent_id,
                model=build.binding.model_name or "unknown",
                duration_ms=(time.time() - started) * 1000,
                iterations=0,
                status=status,
            )
        except Exception:
            logger.debug("Failed to record agent chat metrics", exc_info=True)
