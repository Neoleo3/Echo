"""
Agent factory module.

The single instantiation path: ``AgentFactory.build`` compiles an agent
definition into a runnable LangGraph agent. Every execution path -- standalone
chat, workflow nodes, application components -- goes through it.
"""
from .factory import AgentBuild, AgentFactory
from .invocation import build_messages, extract_final_text, invoke_agent
from .llm_binding import (
    AgentLLM,
    ModelBinding,
    binding_metadata,
    resolve_agent_llm,
    resolve_model_binding,
)
from .runtime import AgentRuntime

__all__ = [
    "AgentBuild",
    "AgentFactory",
    "AgentLLM",
    "AgentRuntime",
    "ModelBinding",
    "binding_metadata",
    "build_messages",
    "extract_final_text",
    "invoke_agent",
    "resolve_agent_llm",
    "resolve_model_binding",
]
