"""
The fixed middleware stack every Echo agent runs with.

WHAT: Assembles the LangChain middleware list applied to every agent built by
      ``AgentFactory.build``.
WHY:  Loop control used to be re-implemented per path -- a hand-rolled ReAct
      loop with ``MAX_TOOL_ITERATIONS`` in the standalone factory, a monkey
      patched ``model.invoke`` counter plus a manual retry loop in the workflow
      adapter. Both are now declarative middleware, so every agent gets the same
      budget, retry and planning behaviour.

Never enabled here: ``ShellToolMiddleware``. Echo agents must not obtain shell
access as a side effect of the harness.
"""
from __future__ import annotations

import logging
import os
from collections.abc import Mapping
from typing import Any, Dict, List, Optional

from langchain.agents.middleware import (
    AgentMiddleware,
    HumanInTheLoopMiddleware,
    ModelCallLimitMiddleware,
    ModelRetryMiddleware,
    SummarizationMiddleware,
    TodoListMiddleware,
    ToolCallLimitMiddleware,
    dynamic_prompt,
)

from echolib.llm_errors import is_retryable_invoke_error

logger = logging.getLogger(__name__)

# Fallbacks for the model-call budget, used when ``echolib.config`` cannot be
# read. The live values are ``settings.agent_model_call_limit`` and
# ``settings.agent_model_call_limit_cap``.
#
# These were 3 and 6, carried over from the workflow adapter and sized for an
# agent that answers in one pass. An agent that has to read its sources before
# it writes spends calls doing so, and at three it ran out of turns and
# returned whatever it had -- ``exit_behavior="end"`` means the ceiling ends
# the run rather than failing it, so a shallow answer looked like a complete
# one.
DEFAULT_MODEL_CALL_LIMIT = 3
MAX_MODEL_CALL_LIMIT = 6

# Fallbacks only; the live values are in ``echolib.config``.
#
# These were 1 retry over 0.5s-8s, which cannot survive an Azure token throttle:
# the service routinely asks for a full 60s refill window, and by the time this
# layer is reached the SDK has already retried and given up. Retrying for eight
# seconds against a sixty-second throttle simply burns quota -- a refused
# request still counts against it -- and then fails the step anyway.
MAX_MODEL_RETRIES = 2
RETRY_INITIAL_DELAY_SECONDS = 2.0
RETRY_MAX_DELAY_SECONDS = 60.0

# Summarize once the conversation reaches this share of the model's input
# window, and keep this share afterwards. 0.8 leaves room for the system
# prompt, which is applied by ``dynamic_prompt`` and is therefore not part of
# the message list the middleware measures.
SUMMARIZATION_TRIGGER_FRACTION = 0.8
SUMMARIZATION_KEEP_FRACTION = 0.3

BUDGET_EXHAUSTED_NOTE = (
    "Tool budget note: the tool call allowance for this run is spent. "
    "Answer now from what you already have, and state clearly which parts could "
    "not be verified."
)


def _float_setting(name: str, default: float) -> float:
    """Read a float tuning value from ``echolib.config``."""
    try:
        from echolib.config import settings

        return float(getattr(settings, name, default))
    except Exception:  # noqa: BLE001 -- tuning must never fail a build
        return default


def _setting(name: str, default: int) -> int:
    """Read a tuning value from ``echolib.config``, degrading to *default*."""
    try:
        from echolib.config import settings

        return int(getattr(settings, name, default))
    except Exception:  # noqa: BLE001 -- tuning must never fail a build
        return default


def resolve_model_call_limit(tool_call_limit: int = 0) -> int:
    """
    Resolve the per-run model call ceiling.

    The floor of ``tool_call_limit + 1`` guarantees the agent always has one
    model call left to write a final answer after spending its whole tool
    budget; without it a tool-heavy agent would be cut off mid-loop.

    Both the default and the cap are tuned in ``echolib.config``. The existing
    ``WORKFLOW_MAX_LLM_CALLS_PER_AGENT`` environment variable still overrides
    the default, so a deployment that already sets it keeps working.
    """
    default_limit = _setting("agent_model_call_limit", DEFAULT_MODEL_CALL_LIMIT)
    cap = _setting("agent_model_call_limit_cap", MAX_MODEL_CALL_LIMIT)

    try:
        configured = int(os.getenv("WORKFLOW_MAX_LLM_CALLS_PER_AGENT", str(default_limit)))
    except ValueError:
        configured = default_limit

    configured = max(1, min(configured, max(1, cap)))
    return max(configured, max(0, tool_call_limit) + 1)


def _context_limit(model: Any) -> Optional[int]:
    """
    The model's input window in tokens, or None when it is not known.

    Read from LangChain's ``ModelProfile``, which is populated from two places:
    the registry LangChain ships for recognised model names, and the context
    window a registrar states against a credential -- the only source for a
    self-hosted endpoint LangChain has never heard of.

    None is the important return. It means the platform does not know the
    limit, and a limit that is not known must not be guessed: summarizing at an
    invented threshold would discard context the model could have held.
    """
    profile = getattr(model, "profile", None)
    if not isinstance(profile, Mapping):
        return None

    try:
        limit = int(profile.get("max_input_tokens") or 0)
    except (TypeError, ValueError):
        return None

    return limit if limit > 0 else None


def build_summarization_middleware(model: Any) -> Optional[Any]:
    """
    Compact the conversation before it overruns the model's input window.

    WHAT: Attaches ``SummarizationMiddleware`` when -- and only when -- the
          model's context window is actually known.
    WHY:  A run that exceeds the window does not fail the same way everywhere.
          A cloud provider returns ``context_length_exceeded`` and the run
          stops with something to read. Ollama, which this platform reaches
          over its OpenAI-compatible ``/v1`` endpoint, silently drops the
          oldest tokens instead: the agent loses its system prompt -- its
          instructions, its readiness findings, its evidence notes -- and
          answers anyway. A confident answer produced without instructions is
          worse than an error, because nothing in the run says it happened.
    INPUT: The constructed chat model.
    OUTPUT: A middleware instance, or None when it must not be attached.

    Returns None, rather than attaching with a guessed limit, in two cases: the
    model profile states no input window, or construction failed. Either way
    the agent behaves exactly as it did before this middleware existed, which
    is why there is no switch to turn it off -- the condition that makes it
    useless already turns it off.

    The agent's own model does the summarizing. The platform supplies no model
    of its own, so there is nothing else it could use.
    """
    limit = _context_limit(model)
    if limit is None:
        # No stated window. For a recognised model LangChain fills this in
        # itself; for a custom endpoint it is the registered Context Window
        # that supplies it, and without either the honest action is nothing.
        logger.debug(
            "Context summarization not attached: the model states no input "
            "window. Register a Context Window against the credential to "
            "enable it for this model."
        )
        return None

    try:
        middleware = SummarizationMiddleware(
            model=model,
            trigger=("fraction", SUMMARIZATION_TRIGGER_FRACTION),
            keep=("fraction", SUMMARIZATION_KEEP_FRACTION),
        )
    except Exception:
        # Fractional thresholds require profile data, which was just checked --
        # but a future LangChain release may validate more. Failing to build an
        # agent because its optional safety net could not be attached would
        # trade a rare degradation for a total outage.
        logger.warning(
            "Context summarization could not be attached; continuing without it.",
            exc_info=True,
        )
        return None

    logger.info(
        "Context summarization active: window=%d tokens, summarize at %.0f%%, "
        "keep %.0f%%.",
        limit,
        SUMMARIZATION_TRIGGER_FRACTION * 100,
        SUMMARIZATION_KEEP_FRACTION * 100,
    )
    return middleware


def _build_prompt_middleware(base_system_prompt: str, budget_state: Optional[Dict[str, Any]]) -> Any:
    """
    Wrap the system prompt so it can react to runtime execution state.

    The only runtime signal today is the tool budget: once ``execution_policy``
    has blocked further calls, telling the model so is what stops it looping
    against a wall of refusal messages.
    """

    @dynamic_prompt
    def agent_prompt(request: Any) -> str:  # noqa: ARG001 - request unused today
        if not budget_state:
            return base_system_prompt

        try:
            spent = int(budget_state.get("calls", 0)) >= int(budget_state.get("max_calls", 0))
        except (TypeError, ValueError):
            return base_system_prompt

        if not spent:
            return base_system_prompt
        return f"{base_system_prompt}\n\n{BUDGET_EXHAUSTED_NOTE}"

    return agent_prompt


def _build_tool_limit_middleware(tool_call_limit: int) -> Any:
    """
    The per-run tool ceiling, built so that reaching it **ends the run**.

    WHY ``end`` AND NOT ``continue``:
    ``continue`` blocks the over-budget tool and hands control back to the
    model -- LangChain's own words are "Model decides when to end". A model that
    keeps asking for the tool it has just been refused loops the graph until
    LangGraph's recursion limit fires, which surfaces as ``GraphRecursionError``
    and fails the whole step instead of returning what the agent already had.
    Measured directly: with a six-call budget and ample recursion headroom,
    ``continue`` aborted on recursion while ``end`` finished cleanly having made
    exactly its six calls.

    A budget whose enforcement depends on the model choosing to stop is not a
    budget. ``ModelCallLimitMiddleware`` on the line above already uses ``end``
    for this reason; this brings the tool ceiling into line with it, so the
    agent returns its answer rather than colliding with a graph safety net.

    ``end`` is documented as raising ``NotImplementedError`` when several tool
    calls are pending in parallel and the limit is crossed mid-batch. That did
    not reproduce on the pinned version, but the construction is guarded so an
    unsupported edge case degrades to the previous behaviour instead of becoming
    a new crash.
    """
    try:
        return ToolCallLimitMiddleware(run_limit=tool_call_limit, exit_behavior="end")
    except (TypeError, ValueError):
        logger.warning(
            "ToolCallLimitMiddleware does not accept exit_behavior='end' on this "
            "version; falling back to 'continue'. The tool budget will not "
            "terminate the run on its own and the recursion limit remains the "
            "backstop."
        )
        return ToolCallLimitMiddleware(
            run_limit=tool_call_limit, exit_behavior="continue"
        )


# Hooks that LangChain compiles into their own graph node, and therefore their
# own LangGraph super-step. ``wrap_model_call`` / ``wrap_tool_call`` are
# in-process wrappers and add no node.
_NODE_HOOKS = ("before_model", "after_model", "before_agent", "after_agent")


def count_middleware_nodes(middleware: Optional[List[Any]]) -> int:
    """
    How many extra graph nodes a middleware stack contributes.

    WHAT: Counts the ``before_*``/``after_*`` hooks actually overridden across
          the stack.
    WHY:  LangGraph's recursion limit counts super-steps, and each of these
          hooks is a node. One model-plus-tool cycle therefore costs
          ``2 + this`` super-steps, not 2 -- which is what made a recursion
          limit sized for a bare ReAct loop abort a run after two tool calls.
          Deriving it from the built stack means adding middleware cannot
          silently re-introduce that.
    OUTPUT: 0 when the stack is empty or nothing could be inspected.
    """
    total = 0
    for entry in middleware or []:
        entry_type = type(entry)
        for hook in _NODE_HOOKS:
            try:
                if getattr(entry_type, hook, None) is not getattr(
                    AgentMiddleware, hook, None
                ):
                    total += 1
            except Exception:  # noqa: BLE001 -- inspection must never fail a build
                continue
    return total


def build_middleware_stack(
    *,
    base_system_prompt: str,
    tool_call_limit: int,
    include_planner: bool = True,
    interrupt_on: Optional[Dict[str, Any]] = None,
    budget_state: Optional[Dict[str, Any]] = None,
    extra_middleware: Optional[List[Any]] = None,
    model: Any = None,
) -> List[Any]:
    """
    Build the middleware stack for one agent.

    WHAT: Model call ceiling, tool call ceiling, model retry, optional tool
          approval, planning, capability middleware, then the dynamic system
          prompt.
    WHY:  A declarative stack replaces three divergent hand-rolled loops.
    INPUT: Base system prompt, resolved tool budget, harness capabilities, an
           optional per-tool approval map and any capability middleware.
    OUTPUT: Ordered list of middleware instances.

    Args:
        base_system_prompt: Prompt assembled by ``factory.prompt``.
        tool_call_limit: Per-run tool call ceiling covering every bound tool,
            classic and connector-backed.
        include_planner: False when the harness already attaches a planner.
        interrupt_on: Tool-name to approval-config map for human approval.
        budget_state: Shared ``execution_policy`` budget dict, read by the prompt.
        extra_middleware: Capability middleware (connectors today, agent files
            in phase 6). Placed after the limits so their tools are still
            counted, and before the prompt so the prompt stays last.
        model: The constructed chat model. Supplied only so context
            summarization can read its stated input window and do the
            summarizing; omitting it simply leaves that middleware off.

    Returns:
        List of middleware instances in application order.
    """
    middleware: List[Any] = [
        # 'end' rather than 'error': the agent returns what it has instead of
        # collapsing the whole workflow node with an exception.
        ModelCallLimitMiddleware(
            run_limit=resolve_model_call_limit(tool_call_limit),
            exit_behavior="end",
        )
    ]

    if tool_call_limit >= 1:
        # Loop-level ceiling only. Dedupe by input signature and the single
        # corrective retry after a validation failure stay in execution_policy,
        # inside the tool wrapper, because no middleware models those.
        middleware.append(_build_tool_limit_middleware(tool_call_limit))

    middleware.append(
        ModelRetryMiddleware(
            max_retries=_setting("agent_model_retry_attempts", MAX_MODEL_RETRIES),
            retry_on=is_retryable_invoke_error,
            on_failure="error",
            initial_delay=_float_setting(
                "agent_model_retry_initial_delay_seconds",
                RETRY_INITIAL_DELAY_SECONDS,
            ),
            max_delay=_float_setting(
                "agent_model_retry_max_delay_seconds", RETRY_MAX_DELAY_SECONDS
            ),
            # Spreads retries that were throttled together. Without it the whole
            # superstep retries in the same instant and reproduces the burst.
            jitter=True,
        )
    )

    if interrupt_on:
        middleware.append(HumanInTheLoopMiddleware(interrupt_on=interrupt_on))

    if include_planner:
        middleware.append(TodoListMiddleware())

    middleware.extend(extra_middleware or [])

    # Last before the prompt, so it measures the message list every other
    # middleware has finished contributing to. The system prompt itself is not
    # in that list -- ``dynamic_prompt`` applies it separately -- which is why
    # the trigger fraction leaves headroom rather than filling the window.
    if model is not None:
        summarization = build_summarization_middleware(model)
        if summarization is not None:
            middleware.append(summarization)

    middleware.append(_build_prompt_middleware(base_system_prompt, budget_state))

    return middleware
