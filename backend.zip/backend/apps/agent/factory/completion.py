"""
Why a model stopped generating, read the same way on every path.

WHAT: Normalises the provider's stop reason and says whether it means "I ran
      into the output ceiling".
WHY:  This used to live inside ``apps/agent/streaming.py``, so only the two
      streaming paths could see it. ``invoke_agent`` -- the path
      ``AgentRuntime.chat`` uses -- read nothing, and a truncated answer was
      returned as though it were complete. That is the single hardest class of
      LLM bug to diagnose from the outside, because the text looks plausible
      right up to where it stops.

The module carries no LangGraph or streaming concepts, so the factory, the
streaming layer and the workflow adapter can all import it without pulling one
another in.
"""
from __future__ import annotations

import logging
from typing import Any, Optional, Sequence

logger = logging.getLogger(__name__)

# What each provider calls "I stopped because I hit the output limit".
# OpenAI/Azure/Ollama report ``finish_reason``; Anthropic reports ``stop_reason``;
# Ollama's native API reports ``done_reason``.
TRUNCATION_REASONS = frozenset({"length", "max_tokens", "max_output_tokens"})

TRUNCATION_NOTE = (
    "\n\n_(This response reached the agent's maximum output length and stopped "
    "here. Raise **Max Tokens** in the agent's model settings, or ask it to "
    "continue.)_"
)
"""Appended when the provider says it stopped at the output limit.

The note names the setting that caused it, because the cause is a configuration
value the reader can change -- not a model failure."""


def finish_reason(message: Any) -> str:
    """
    The provider's stop reason for one message, normalised, or ``""``.

    LangChain surfaces it on ``response_metadata`` for every provider it wraps,
    but under different keys, and some providers repeat it in
    ``additional_kwargs``. All the shapes are checked rather than assuming one,
    because guessing wrong here fails silently -- which is the defect this
    exists to end.
    """
    for container in (
        getattr(message, "response_metadata", None),
        getattr(message, "additional_kwargs", None),
    ):
        if not isinstance(container, dict):
            continue
        for key in ("finish_reason", "stop_reason", "done_reason"):
            value = container.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip().lower()
    return ""


def was_truncated(reason: str) -> bool:
    """True when a stop reason means the output ran into its token ceiling."""
    return reason in TRUNCATION_REASONS


def last_truncation_reason(messages: Optional[Sequence[Any]]) -> str:
    """
    The stop reason of the newest assistant message that hit the output ceiling.

    **Messages carrying tool calls are included, and that is the point.** The
    reason traversal used to skip them, which excluded the one case where
    truncation does the most damage: a document generator's arguments are a
    tool call, so a report cut off mid-JSON was invisible to the only check
    that could have reported it. A normal tool call stops with reason
    ``tool_calls``, which is not a truncation reason, so including them adds no
    false positives.
    """
    reason = ""
    for message in messages or []:
        if getattr(message, "type", "") != "ai":
            continue
        found = finish_reason(message)
        if found and was_truncated(found):
            reason = found
        elif found and not reason:
            # Remember the newest reason so a caller can report a non-truncating
            # stop too, but never let it displace a truncation already seen.
            reason = found if not was_truncated(reason) else reason
    return reason


def note_truncation(text: str, reason: str, *, where: str = "") -> str:
    """
    Append the truncation note to *text* when the reason says it was cut off.

    Returns *text* unchanged otherwise, so a normal completion is byte-identical
    to what the caller produced.
    """
    if not was_truncated(reason):
        return text

    logger.warning(
        "Output hit the model's token ceiling%s (stop_reason=%r, %d characters "
        "produced). The answer is incomplete; raise the agent's Max Tokens.",
        f" in {where}" if where else "",
        reason,
        len(text or ""),
    )
    return f"{text}{TRUNCATION_NOTE}"


__all__ = [
    "TRUNCATION_NOTE",
    "TRUNCATION_REASONS",
    "finish_reason",
    "last_truncation_reason",
    "note_truncation",
    "was_truncated",
]
