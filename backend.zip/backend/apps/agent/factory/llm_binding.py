"""
Model resolution for the single agent instantiation path.

WHAT: Turns a canonical agent definition's ``model_config`` into a concrete
      LangChain chat model via the centralized 4-tier credential resolver.
WHY:  The standalone path hand-rolled per-provider construction and the workflow
      path called the resolver but never forwarded ``credential_id``, so an
      agent pinned to a specific user credential silently ran on a different
      one inside workflows. One binding module removes both defects.

Key Vault behaviour is untouched: every credential is still resolved by
``echolib.llm_resolver`` on each build, and nothing is cached here.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from echolib.llm_resolver import describe_resolution, resolve_and_build_llm_sync

logger = logging.getLogger(__name__)

DEFAULT_COMPONENT = "agent_executor"

_PROVIDER_CATALOGUE = (
    Path(__file__).resolve().parents[3]
    / "echolib"
    / "LLM_Details"
    / "Providers"
    / "llm_provider.json"
)


@dataclass(frozen=True)
class ModelBinding:
    """Everything needed to construct a chat model for one agent."""

    model_id: str
    model_name: str
    provider: Optional[str]
    temperature: float
    # None means the agent's author stated no limit. It is not a missing value
    # to be filled in here: only ``llm_resolver`` knows which credential and
    # which provider the build will land on, and the right ceiling differs per
    # provider. See ``_effective_max_tokens``.
    max_tokens: Optional[int]
    top_p: float
    credential_id: Optional[str]
    # The account whose credentials are searched for this agent's model, when
    # it is not the caller: the agent's owner, or the application's owner when
    # the agent inherits the application's LLM. None searches the caller's own
    # credentials, which is what every build did before shared applications.
    credential_owner_id: Optional[str] = None


@dataclass(frozen=True)
class AgentLLM:
    """A built chat model together with how it was resolved."""

    client: Any
    binding: ModelBinding
    resolution: Dict[str, Any]


def _load_llm_providers() -> Dict[str, Dict[str, Any]]:
    """Load the model-ID-to-provider mapping from llm_provider.json.

    Supports the legacy flat format (``{"models": [...]}``). The newer
    provider-grouped format carries no model-ID mapping, so it yields nothing
    and resolution falls through to ConfigLoader.
    """
    if not _PROVIDER_CATALOGUE.exists():
        return {}

    try:
        with open(_PROVIDER_CATALOGUE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        logger.warning("Unable to read the LLM provider catalogue", exc_info=True)
        return {}

    if "models" in data:
        return {m["id"]: m for m in data.get("models", []) if m.get("id")}
    return {}


def _lookup_custom_model(model_id: str) -> Optional[Dict[str, Any]]:
    """Look up a user-added model that lives in ConfigLoader, not in the JSON file."""
    try:
        from echolib.LLM_Details.Core.config_loader import ConfigLoader

        for entry in ConfigLoader().get_all_models():
            if entry.get("id") == model_id:
                return entry
    except Exception:
        logger.debug("ConfigLoader lookup failed for model '%s'", model_id, exc_info=True)
    return None


def _resolve_model_identity(model_id: str, configured_provider: str) -> tuple[str, Optional[str]]:
    """
    Map a catalogue model ID to (model_name, provider).

    Agents store the catalogue ID (for example ``azure-gpt-4o``), not the
    provider-specific deployment name the SDK needs.
    """
    if not model_id:
        return "", (configured_provider or None)

    entry = _load_llm_providers().get(model_id) or _lookup_custom_model(model_id)
    if not entry:
        # Already a provider-native model name, or a model the catalogue lost.
        return model_id, (configured_provider or None)

    model_name = entry.get("model_name") or entry.get("name") or model_id
    provider = configured_provider or entry.get("provider") or ""
    return model_name, (provider or None)


def resolve_model_binding(agent_config: Dict[str, Any]) -> ModelBinding:
    """
    Derive a ModelBinding from an agent definition of any historical shape.

    WHAT: Reads ``model_config`` through the canonical contract, then maps the
          catalogue model ID to the provider-native model name.
    WHY:  ``echolib.agent_contract`` already owns every legacy shape
          (``settings{}``, ``llm{}``, ``metadata.settings``); duplicating that
          precedence here is how the two paths drifted apart in the first place.
    INPUT: Agent definition dict.
    OUTPUT: ModelBinding.

    ``provider`` stays None unless it was explicitly configured, so the
    credential cascade in ``llm_resolver`` decides the provider from the
    resolved credential instead of being forced to a default.
    """
    from echolib.agent_contract import (
        LLM_OWNER_USER_ID_KEY,
        OWNER_USER_ID_KEY,
        normalize_agent_definition,
    )

    definition = normalize_agent_definition(agent_config)
    model_config = definition.get("model_config") or {}

    model_id = str(model_config.get("model") or "").strip()
    model_name, provider = _resolve_model_identity(
        model_id,
        str(model_config.get("provider") or "").strip(),
    )

    return ModelBinding(
        model_id=model_id,
        model_name=model_name,
        provider=provider,
        temperature=float(model_config.get("temperature", 0.7)),
        # None when the author never set one. This second ``2000`` was
        # independent of the contract's, so removing only the contract's would
        # have left the ceiling in place for every agent anyway. ``build_model``
        # forwards None, and ``llm_resolver._effective_max_tokens`` resolves it
        # against the credential and then the provider.
        max_tokens=(
            int(model_config["max_tokens"])
            if model_config.get("max_tokens") is not None
            else None
        ),
        top_p=float(model_config.get("top_p", 0.9)),
        credential_id=definition.get("credential_id") or None,
        # Read from the raw config: both keys are run-scoped and stamped by a
        # loader from a stored ownership column, never by a request.
        credential_owner_id=_credential_owner(
            agent_config, LLM_OWNER_USER_ID_KEY, OWNER_USER_ID_KEY
        ),
    )


def _credential_owner(agent_config: Dict[str, Any], *keys: str) -> Optional[str]:
    """
    The account this agent's LLM credential belongs to, or None.

    WHAT: The first of ``keys`` carrying a value.
    WHY:  An agent run inside a shared application must run on the model its
          author chose. That credential lives in the author's account, so it is
          looked up there -- the same principal its knowledge bases and
          connectors are already read under.
    """
    for key in keys:
        value = str(agent_config.get(key) or "").strip()
        if value:
            return value
    return None


def binding_metadata(binding: ModelBinding) -> Dict[str, Any]:
    """
    Describe a binding for execution records.

    Configuration only -- what the agent asked for, before any credential
    resolution. Carries no secret material.
    """
    return {
        "model_id": binding.model_id or None,
        "model": binding.model_name or None,
        "provider": binding.provider,
        "temperature": binding.temperature,
        "max_tokens": binding.max_tokens,
        "top_p": binding.top_p,
        "credential_id": binding.credential_id,
        "credential_owner_id": binding.credential_owner_id,
    }


def build_model(
    binding: ModelBinding,
    *,
    user_id: Optional[str] = None,
    component: str = DEFAULT_COMPONENT,
    framework: str = "langchain",
    expects_tools: bool = False,
) -> Any:
    """
    Construct a chat model for this binding.

    WHAT: Delegates to the 4-tier resolver (user credential -> app credential ->
          Azure env -> Ollama), forwarding the agent's pinned ``credential_id``.
    WHY:  Provider construction and secret retrieval must stay out of agent
          business logic.
    INPUT: ModelBinding, authenticated user id, component label for telemetry,
           target framework.
    OUTPUT: A chat model for the requested framework.
    RAISES: Whatever the resolver raises when no credential tier resolves.

    ``top_p`` is forwarded. It was read from the definition, carried on the
    binding and reported in ``binding_metadata`` — and then dropped here, so
    the Top P control on the agent form has never affected a single request.
    It now reaches the provider on classic models and is withheld from
    reasoning ones, which reject it exactly as they reject ``temperature``.
    """
    return resolve_and_build_llm_sync(
        user_id=user_id,
        credential_id=binding.credential_id,
        component=component,
        temperature=binding.temperature,
        allow_platform_fallback=True,
        framework=framework,
        model=binding.model_name or None,
        provider=binding.provider,
        max_tokens=binding.max_tokens,
        model_id=binding.model_id or None,
        top_p=binding.top_p,
        # The platform floor for agent output, applied by the resolver rather
        # than here because only the resolver can see the credential -- and the
        # floor must never exceed the ``max_output_tokens`` an administrator
        # registered against it. Passed only on this path: the same resolver
        # also serves intent extraction, variable extraction and self-review,
        # which ask for a few hundred tokens *deliberately*.
        min_output_tokens=_configured_output_floor(),
        # Whether this agent may be given tools. A reasoning model that carries
        # tools cannot also carry a reasoning effort on Chat Completions, so
        # this decides the API surface. Known before the tools themselves are
        # built, which is why it is a "may bind" rather than a count.
        expects_tools=expects_tools,
        # Whose credentials are searched. The caller is still ``user_id`` and is
        # what token governance bills.
        credential_owner_id=binding.credential_owner_id,
    )


def _configured_output_floor() -> Optional[int]:
    """
    The platform's minimum output allowance for an agent, or ``None``.

    WHY a floor exists at all: two code paths wrote an output ceiling into
    agents nobody configured, and those rows are already persisted.
    ``agent_designer`` wrote ``max_tokens: 2000`` into every prompt-built
    agent's ``model_config``, and the canvas mapper defaulted a dragged node to
    4,000. An agent asked to write the final report of a fifteen-agent workflow
    therefore stopped after a page or two, and nothing in the run said why. A
    floor lifts all of them without a migration and without guessing which
    stored numbers were deliberate, because it only ever raises.

    It is a ceiling, not a target: a model is billed for the tokens it
    generates, not for the headroom it was allowed, so this costs nothing on a
    short answer.
    """
    try:
        from echolib.config import settings

        floor = int(getattr(settings, "agent_min_output_tokens", 0) or 0)
    except Exception:  # noqa: BLE001 -- tuning must never fail a build
        return None
    return floor if floor > 0 else None


def resolve_agent_llm(
    agent_config: Dict[str, Any],
    *,
    user_id: Optional[str] = None,
    framework: str = "langchain",
    component: str = DEFAULT_COMPONENT,
    expects_tools: bool = False,
) -> AgentLLM:
    """
    Resolve and build the model for one agent, in one call.

    WHAT: Reads the agent's LLM parameters from the canonical contract, builds
          the client through the 4-tier credential cascade, and returns both
          together with how the credential actually resolved.
    WHY:  LLM parameter extraction used to be reimplemented at every
          instantiation site, and the workflow site simply never included
          ``credential_id`` -- so an agent pinned to a credential ran on the
          user's default inside a workflow and on its own credential outside
          one. This is the single place those parameters are read.
    INPUT: An agent definition of any historical shape, the authenticated user
           id, the target framework and a component label for telemetry.
    OUTPUT: ``AgentLLM`` -- client, binding, and resolution metadata.
    RAISES: Propagates resolver failures. An agent with no usable model must
            fail loudly rather than answer from nothing.

    ``credential_id`` is a per-agent field with no workflow-level override: six
    agents may carry six different credentials, or all six may share one.
    """
    binding = resolve_model_binding(agent_config)
    client = build_model(
        binding,
        user_id=user_id,
        component=component,
        framework=framework,
        expects_tools=expects_tools,
    )

    resolution = describe_resolution(client)
    if binding.credential_id and not resolution.get("credential_honoured", True):
        logger.warning(
            "Agent '%s' is configured for credential %s but resolved to %s "
            "(tier=%s). Its output is attributed to the resolved credential.",
            agent_config.get("agent_id") or agent_config.get("name") or "unknown",
            binding.credential_id,
            resolution.get("credential_id") or "platform-fallback",
            resolution.get("resolution_tier"),
        )

    return AgentLLM(client=client, binding=binding, resolution=resolution)
