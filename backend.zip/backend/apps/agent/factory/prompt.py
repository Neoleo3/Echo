"""
System prompt assembly for the single agent instantiation path.

WHAT: Builds one system prompt from a canonical agent definition.
WHY:  Three prompt builders existed -- ``AgentRuntime._build_system_prompt``
      (read ``prompt``, fell back to "You are {role}"), the workflow adapter's
      ``_build_system_prompt`` (read ``role`` first, then ``instructions``) and
      the orphaned ``langgraph_agent._build_system_prompt`` (the only one that
      carried anti-hallucination rules). Agents behaved differently depending on
      which path executed them, which is exactly the parity the spec forbids.

``instructions`` is authoritative. The removed concepts (role, goal, backstory,
persona) are never read, per the Phase 1 contract.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

DEFAULT_AGENT_NAME = "Assistant"

# Ported from apps/workflow/runtime/langgraph_agent.py, previously the only
# place in the codebase that instructed an agent not to fabricate tool output.
# Spec section 3: "no hallucinated execution".
# These rules are about *truthfulness*, not about length.
#
# Both used to end with "Be structured, concise, and accurate." -- a platform
# instruction to be brief, appended to every agent ever built. On a workflow
# whose purpose is a thorough analysis, the last thing the model read was the
# opposite of the requirement, and it applied to all fifteen agents at once.
#
# Length is the agent author's decision. It is expressed through the agent's own
# instructions and, when it needs to be explicit, through ``response_depth``
# below. The platform states accuracy and grounding, and says nothing about how
# long an answer should be.
TOOL_EXECUTION_RULES = (
    "Operating rules:\n"
    "- Use your tools to obtain REAL data before answering; never fabricate tool "
    "output, results, or citations.\n"
    "- If a required input, connector, or knowledge source is missing, say so "
    "plainly and stop. Do not simulate the work.\n"
    "- Be structured and accurate.\n"
    "- When you have enough information, give your final answer directly."
)

NO_TOOL_RULES = (
    "Operating rules:\n"
    "- You have no tools available. Answer only from this conversation and the "
    "context you are given.\n"
    "- Never claim to have executed an action, retrieved live data, or accessed "
    "an external system.\n"
    "- If you cannot answer from the available context, say so plainly.\n"
    "- Be structured and accurate."
)

DEPTH_STANDARD = "standard"
DEPTH_DETAILED = "detailed"

DETAILED_DEPTH_RULE = (
    "Depth of response:\n"
    "- Produce a complete, in-depth answer. Cover every point the request and "
    "the context in front of you raise, and carry each one through to a "
    "conclusion rather than naming it and moving on.\n"
    "- Where upstream results are supplied, use all of them. Each one is work "
    "that was done for this task, and omitting any of it silently loses it.\n"
    "- Support findings with the specifics they came from -- the section, the "
    "value, the source -- rather than summarising them away.\n"
    "- Do not shorten for brevity's sake. Stop when the subject is covered, "
    "not when the answer feels long enough."
)
"""Applied when an agent asks for it. Never applied on the platform's own
initiative -- a request for depth on an agent that should answer in a sentence
is as wrong as an instruction to be brief on one writing a report."""


def _resolve_instructions(agent_config: Dict[str, Any]) -> str:
    """Read the authoritative instruction block, tolerating the Tier-3 mirror."""
    for key in ("instructions", "prompt", "system_prompt"):
        value = agent_config.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _resolve_skills(agent_config: Dict[str, Any]) -> List[str]:
    """Read assigned skill ids from either the canonical field or legacy metadata."""
    skills = agent_config.get("skills")
    if not skills:
        skills = (agent_config.get("metadata") or {}).get("skills")

    if not isinstance(skills, list):
        return []
    return [str(s).strip() for s in skills if str(s).strip()]


def _skill_methodology(agent_config: Dict[str, Any]) -> str:
    """
    Resolve skill methodology text at execution time.

    Reading skills here rather than baking them into a stored prompt means
    skills added or removed in the editor take effect on the next run.
    """
    skills = _resolve_skills(agent_config)
    if not skills:
        return ""

    try:
        from apps.workflow.aura_pipeline.skills import get_skill_methodology

        return get_skill_methodology(skills) or ""
    except Exception:
        logger.debug("Skill methodology unavailable; continuing without it", exc_info=True)
        return ""


def build_system_prompt(
    agent_config: Dict[str, Any],
    *,
    has_tools: bool = False,
    connector_context: str = "",
    attached_context: str = "",
    readiness_note: str = "",
) -> str:
    """
    Assemble the system prompt for an agent.

    WHAT: Identity, then user-authored instructions, then skill methodology,
          then attached connector descriptors, then attached documents, then
          the non-negotiable execution rules.
    WHY:  One prompt shape for standalone chat, workflow nodes and application
          components, so the same agent answers the same way everywhere.
    INPUT: A canonical (or legacy) agent definition, whether tools are bound,
           and the connector and attached-document blocks for this build.
    OUTPUT: The system prompt string.

    Both descriptor blocks sit before the execution rules deliberately: the
    rules end with "never fabricate tool output", which is the sentence that
    has to apply to the data sources and documents just described.

    Documents come after connectors so that an inlined document -- which can be
    thousands of characters -- does not push the connector descriptors away
    from the instructions they qualify.

    The readiness note comes **last**, after the execution rules, because it is
    about this run rather than about the agent: it names what is missing right
    now. It is the ``warn``-mode backstop, not the safeguard -- spec section 4.3
    is explicit that instruction text does not substitute for control flow, and
    ``block`` mode is what actually stops a run. In ``off`` mode it is empty.

    Args:
        agent_config: Agent definition dict.
        has_tools: True when at least one tool was successfully bound.
        connector_context: Descriptor block from the Connector Middleware.
        attached_context: Descriptor block from the Agent Context Middleware,
            including the full text of short attached documents.
        readiness_note: Findings from the Context Readiness Gate for this run.

    Returns:
        System prompt text. Never empty.
    """
    name = str(agent_config.get("name") or "").strip() or DEFAULT_AGENT_NAME
    description = str(agent_config.get("description") or "").strip()
    instructions = _resolve_instructions(agent_config)

    parts: List[str] = [f"You are {name}."]
    if description:
        parts.append(description)
    if instructions:
        parts.append(instructions)

    methodology = _skill_methodology(agent_config)
    if methodology:
        parts.append(methodology)

    if connector_context.strip():
        parts.append(connector_context.strip())

    if attached_context.strip():
        parts.append(attached_context.strip())

    parts.append(TOOL_EXECUTION_RULES if has_tools else NO_TOOL_RULES)

    if _resolve_depth(agent_config) == DEPTH_DETAILED:
        parts.append(DETAILED_DEPTH_RULE)

    if readiness_note.strip():
        parts.append(readiness_note.strip())

    return "\n\n".join(parts)


def _resolve_depth(agent_config: Dict[str, Any]) -> str:
    """
    How much detail this agent was asked for.

    WHAT: Reads ``response_depth`` from the definition or its settings block.
    WHY:  Verbosity is a property of the job an agent does, not of the platform
          it runs on. A triage agent that answers in a sentence and a writer
          agent that produces a twenty-page report are both correct, and no
          single platform default can serve both -- which is why the previous
          blanket "be concise" was wrong for one of them every time.
    INPUT: An agent definition of any historical shape.
    OUTPUT: ``standard`` (the default, and byte-identical to the prompt this
            function produced before ``response_depth`` existed) or ``detailed``.

    Unset means ``standard``, so every agent that predates this field is
    unaffected.
    """
    for source in (
        agent_config,
        agent_config.get("settings") if isinstance(agent_config.get("settings"), dict) else {},
        agent_config.get("metadata") if isinstance(agent_config.get("metadata"), dict) else {},
    ):
        value = (source or {}).get("response_depth")
        if isinstance(value, str) and value.strip().lower() == DEPTH_DETAILED:
            return DEPTH_DETAILED
    return DEPTH_STANDARD
