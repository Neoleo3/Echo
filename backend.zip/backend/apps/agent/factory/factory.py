"""
Agent factory -- the single instantiation path.

WHAT: ``AgentFactory.build(agent_config)`` compiles an agent definition into a
      runnable LangGraph agent: model, tools, middleware, harness.
WHY:  Spec section 4.1 makes this the only way an agent comes into existence.
      Before Phase 2 there were three: a hand-rolled ReAct loop here, the
      deprecated ``langgraph.prebuilt.create_react_agent`` in the workflow
      adapter, and an inline LLM call in the compiler's HITL branch. They
      disagreed on prompts, tool schemas, budgets and -- critically --
      credential resolution, so the same agent answered differently depending on
      where it ran.

Everything path-specific is a parameter (tool specs, execution context,
observability hooks, checkpointer); nothing about the agent itself is.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from apps.agent.context import build_agent_context_middleware
from apps.agent.context.session_docs import build_session_document_middleware
from apps.agent.readiness import ReadinessReport, check_readiness
from apps.connector.middleware import build_connector_middleware
from apps.markitdown import config as context_config
from apps.tool.execution_policy import ensure_tool_budget_state, resolve_tool_call_limit
from apps.tool.langchain_tools import build_langchain_tools
from echolib.agent_contract import (
    LLM_OWNER_USER_ID_KEY,
    ORIGIN_APPLICATION,
    OWNER_USER_ID_KEY,
    attached_connectors,
    attached_files,
    attached_knowledge_sources,
    merge_application_sources,
)

from .harness import create_harness_agent, harness_name, provides_planner
from .invocation import BARE_CYCLE_STEPS, invoke_agent, record_tool_ceiling
from .llm_binding import ModelBinding, binding_metadata, resolve_agent_llm, resolve_model_binding
from .middleware import build_middleware_stack, count_middleware_nodes
from .prompt import build_system_prompt
from .runtime import AgentRuntime

logger = logging.getLogger(__name__)

# LangGraph names appear in traces and checkpoints; keep them identifier-safe.
_UNSAFE_NAME_CHARS = re.compile(r"[^0-9A-Za-z_-]+")
_MAX_GRAPH_NAME_LENGTH = 60

DEFAULT_COMPONENT = "agent_executor"

# Descriptor budgeting. Connector and attached-document descriptors share one
# prompt allowance, because context exhaustion is a property of the prompt and
# not of either source. Connectors render first and take up to this share;
# attached documents take whatever is left, never below the floor -- otherwise a
# wide database schema would crowd a user's uploaded report out entirely.
CONNECTOR_DESCRIPTOR_SHARE = 0.6
MIN_DESCRIPTOR_TOKENS = 200

# Above this many bound grounding tools, a build is reported rather than capped.
# Models pick worse from a long tool list well before any limit is hit, and the
# union of an application's sources and an agent's own reaches this honestly.
MANY_TOOLS_WARNING_THRESHOLD = 20

# Rough conversion, matching the descriptor modules. Exact tokenization varies
# per model and is not worth a tokenizer dependency for a budget whose purpose
# is to bound growth.
CHARS_PER_TOKEN = 4


@dataclass(frozen=True)
class AgentBuild:
    """A compiled agent plus everything the caller needs to observe it."""

    agent: Any
    binding: ModelBinding
    tools: List[Any]
    budget_state: Dict[str, Any]
    system_prompt: str
    harness: str
    resolution: Dict[str, Any]
    connectors: Optional[Any] = None
    context: Optional[Any] = None
    readiness: Optional[ReadinessReport] = None

    @property
    def blocked(self) -> bool:
        """
        True when the readiness gate says this agent must not be invoked.

        Only ever true in ``block`` mode. In ``warn`` -- the default -- the same
        findings are in the prompt and this stays False; in ``off`` there are no
        findings at all.
        """
        return bool(self.readiness and self.readiness.should_block)

    def readiness_message(self, agent_name: str = "") -> str:
        """What to return to the user in place of an answer when blocked."""
        if not self.readiness:
            return ""
        return self.readiness.user_message(agent_name or "This agent")

    def llm_metadata(self) -> Dict[str, Any]:
        """
        Describe this build's LLM for an execution record.

        Configured parameters plus how the credential actually resolved, by
        reference only. Never contains secret material.
        """
        return {"configured": binding_metadata(self.binding), "resolved": dict(self.resolution)}

    def connector_metadata(self) -> Dict[str, Any]:
        """
        Describe this build's connector surface for an execution record.

        Identifiers, kinds and resolution outcomes only. Empty when the agent
        has no attachments or Connector Settings is off.
        """
        if self.connectors is None:
            return {}
        return self.connectors.describe()

    def context_metadata(self) -> Dict[str, Any]:
        """
        Describe this build's attached-document surface for an execution record.

        Names, statuses and counts only -- never document text -- so retrieval
        is traceable per step without copying a user's file into the execution
        log. Empty when the agent has nothing attached or Connector Settings is
        off.
        """
        if self.context is None:
            return {}
        return self.context.describe()

    def readiness_metadata(self) -> Dict[str, Any]:
        """
        Describe this build's readiness outcome for an execution record.

        Codes, severities and counts only — no document text, no user message.
        Empty when the gate is off.
        """
        if self.readiness is None or not self.readiness.has_content:
            return {}
        return self.readiness.to_metadata()


def _graph_name(agent_config: Dict[str, Any]) -> str:
    """Derive a stable, identifier-safe graph name from an agent definition."""
    raw = str(
        agent_config.get("name")
        or agent_config.get("agent_id")
        or agent_config.get("id")
        or "agent"
    ).strip()
    cleaned = _UNSAFE_NAME_CHARS.sub("_", raw).strip("_")
    return (cleaned or "agent")[:_MAX_GRAPH_NAME_LENGTH]


def _combined_tool_call_limit(tool_call_limit: int, *capability_middleware: Any) -> int:
    """
    Ceiling for ``ToolCallLimitMiddleware`` across every kind of tool.

    The budgets are separate by design -- ``execution_policy`` allows three
    calls and blocks a repeat of the same tool, which is right for one-shot
    enrichment tools and wrong for a database conversation or for reading a
    document section by section -- but the loop-level middleware counts every
    call, so its ceiling is the sum of all of them.
    """
    total = max(0, tool_call_limit)
    for middleware in capability_middleware:
        if middleware is None or not middleware.tools:
            continue
        total += max(0, int(middleware.budget_state.get("max_calls", 0)))
    return total


def _descriptor_budgets(agent_config: Dict[str, Any]) -> Tuple[Optional[int], int]:
    """
    Split the shared descriptor allowance between connectors and documents.

    Returns ``(connector_budget, total)``. The connector budget is ``None``
    when the agent has nothing attached, which leaves the connector middleware
    on its own default rather than imposing a split that has no second party.

    The split follows how many sources each side actually has rather than a
    fixed ratio. An agent running inside an application carries the union of its
    own attachments and the application's, so one side is routinely several
    times the size of the other; a fixed 60/40 then truncated the larger side's
    descriptors — and a source missing from the descriptor is a tool the model
    is never told exists, which is indistinguishable from not having it. Both
    sides keep a floor, so the smaller one is never squeezed out entirely.
    """
    total = context_config.context_token_budget()

    connectors = len(attached_connectors(agent_config))
    context_sources = len(attached_files(agent_config)) + len(
        attached_knowledge_sources(agent_config)
    )

    if not context_sources:
        return None, total
    if not connectors:
        return MIN_DESCRIPTOR_TOKENS, total

    # Proportional, then clamped so neither side can starve the other.
    share = connectors / float(connectors + context_sources)
    connector_budget = int(total * share)
    ceiling = max(MIN_DESCRIPTOR_TOKENS, total - MIN_DESCRIPTOR_TOKENS)
    return max(MIN_DESCRIPTOR_TOKENS, min(connector_budget, ceiling)), total


APPLICATION_CONTEXT_KEY = "application_context"


def _resource_principal(
    agent_config: Dict[str, Any], user_id: Optional[str]
) -> Optional[str]:
    """
    The identity an attachment's stored row is read under.

    WHAT: The agent's owner when one is recorded, otherwise the caller.
    WHY:  Attachment rows -- ``agent_files``, ``knowledge_bases``, and every
          connector service's table -- are scoped by user. Reading them as the
          *caller* meant a published agent lost every attachment for everyone
          but its author: the row was there, the query filtered it out, and the
          agent reported it had no knowledge. Scope has to follow whoever
          configured the attachment, which is fixed at configuration time and
          cannot be influenced by the request.
    OUTPUT: The principal, or ``None`` when neither is known -- in which case
            resolution reports "no user context" exactly as before.

    The LLM credential follows the same owner (see ``llm_binding``), so a
    shared application runs on the model its author chose. The caller is still
    what token governance bills, which is what a caller identity is for.
    """
    owner = str(agent_config.get(OWNER_USER_ID_KEY) or "").strip()
    return owner or user_id


def _inherit_application_llm(
    agent_config: Dict[str, Any], contribution: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Let an agent with no model of its own run on the application's.

    WHAT: When the agent carries no ``credential_id``, adopts the application's
          selected LLM for this build.
    WHY:  On a bring-your-own-LLM platform, an agent that never chose a model
          and is running inside an application should follow that application's
          choice -- not the personal default of whoever happens to be chatting,
          which makes the same application answer differently for two users.
    OUTPUT: The config unchanged when the agent has its own credential, or when
            the application has no usable selection. Never mutates its input.

    **An explicit per-agent ``credential_id`` always wins.** ``Plan_1.md``
    Phase 3 exists to make per-agent binding real, and Finding 5 is the defect
    of it being silently dropped; this must never re-create that.

    When the application's choice *is* adopted, the agent's model name is
    cleared alongside it. An agent that stated no credential is carrying the
    contract's default model (`gpt-4o`, written by Phase 1) rather than a
    considered choice, and keeping that name while switching to a different
    provider's credential would ask, say, Anthropic for an OpenAI model. The
    credential supplies both halves or neither.
    """
    llm = contribution.get("llm")
    if not isinstance(llm, dict) or not llm:
        return agent_config
    if agent_config.get("credential_id"):
        return agent_config

    merged = dict(agent_config)
    model_config = dict(merged.get("model_config") or {})

    if llm.get("credential_id"):
        merged["credential_id"] = llm["credential_id"]
        # Let the credential's own model and provider apply.
        model_config["model"] = ""
        model_config["provider"] = ""
    elif llm.get("model_id"):
        # A model-id slug resolves its credential through Tier 1b, and the
        # slug *is* the model identity, so it is set rather than cleared.
        model_config["model"] = llm["model_id"]
        model_config["provider"] = ""
    else:
        return agent_config

    merged["model_config"] = model_config
    # The adopted credential is the application owner's choice and lives in
    # that owner's account, which need not be the agent's owner. A contribution
    # serialized before the owner travelled with it leaves the key unset, and
    # the credential then resolves under the agent's owner.
    app_llm_owner = str(llm.get("owner_user_id") or "").strip()
    if app_llm_owner:
        merged[LLM_OWNER_USER_ID_KEY] = app_llm_owner
    logger.info(
        "Agent '%s' has no LLM of its own; inheriting the application's (%s)",
        agent_config.get("name") or agent_config.get("agent_id") or "unknown",
        llm.get("credential_id") or llm.get("model_id"),
    )
    return merged


def _merge_application_context(
    agent_config: Dict[str, Any], exec_context: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Fold an application's lent datasources into this build's definition.

    WHAT: Reads the contribution an application put on the execution context
          and returns a definition that also carries its connectors, knowledge
          bases and session documents.
    WHY:  An application's datasources used to reach the planner and stop --
          agents and workflows could not call them at all, and a database
          reached nothing. The execution context is the one channel every
          instantiation path already carries, so reading it here gives
          standalone chat, workflow nodes and HITL nodes the same answer
          without a new parameter on any of them.
    OUTPUT: The original config when there is no contribution -- identity, so
            an agent outside an application is completely unaffected -- and a
            new merged dict when there is one. Never mutates its input.
    """
    if not isinstance(exec_context, dict):
        return agent_config

    contribution = exec_context.get(APPLICATION_CONTEXT_KEY)
    if not isinstance(contribution, dict) or not contribution:
        return agent_config

    merged = merge_application_sources(agent_config, contribution)
    merged = _inherit_application_llm(merged, contribution)
    logger.debug(
        "Agent '%s' gained %d application connector(s) and %d knowledge base(s)",
        agent_config.get("name") or agent_config.get("agent_id") or "unknown",
        len(contribution.get("connectors") or []),
        len(contribution.get("knowledge_sources") or []),
    )
    return merged


def _log_grounding_surface(
    agent_config: Dict[str, Any],
    *,
    connector_middleware: Optional[Any],
    context_middleware: Optional[Any],
    user_id: Optional[str],
    owner_user_id: Optional[str],
) -> None:
    """
    State, in one line, what this agent can actually ground an answer in.

    WHAT: Own vs application-lent knowledge and connectors, how many of each
          resolved, and how many became callable tools.
    WHY:  Diagnosing "the agent says it has no context" previously meant
          correlating three log lines across two subsystems -- the application's
          ledger, the application's contribution, and the agent's two
          middlewares -- and none of them stated the union. Every one could look
          correct while the agent still had nothing. This is the single
          assertion that is true or false on its own.

    Never raises: this is observability, and a build must not fail because a
    count could not be rendered.
    """
    try:
        connectors = list(getattr(connector_middleware, "connectors", None) or [])
        context = getattr(context_middleware, "context", None)
        knowledge = list(getattr(context, "knowledge_bases", None) or [])
        files = list(getattr(context, "files", None) or [])

        def _split(items: Any) -> tuple:
            own = [i for i in items if getattr(i, "origin", "") != ORIGIN_APPLICATION]
            lent = [i for i in items if getattr(i, "origin", "") == ORIGIN_APPLICATION]
            return own, lent

        own_conn, lent_conn = _split(connectors)
        own_kb, lent_kb = _split(knowledge)

        logger.info(
            "Grounding surface for agent '%s' (caller=%s principal=%s): "
            "knowledge own %d/%d + app %d/%d | connectors own %d/%d + app %d/%d | "
            "documents %d/%d | tools kb+files=%d connector=%d",
            agent_config.get("agent_id") or agent_config.get("id") or "unknown",
            user_id or "-",
            owner_user_id or "-",
            sum(1 for k in own_kb if k.resolved), len(own_kb),
            sum(1 for k in lent_kb if k.resolved), len(lent_kb),
            sum(1 for c in own_conn if c.resolved), len(own_conn),
            sum(1 for c in lent_conn if c.resolved), len(lent_conn),
            sum(1 for f in files if f.resolved), len(files),
            len(getattr(context_middleware, "tools", None) or []),
            len(getattr(connector_middleware, "tools", None) or []),
        )

        # An agent configured with sources that produced no capability is the
        # exact failure this line exists to catch. Said plainly rather than left
        # to be inferred from a row of zeros.
        # The union is deliberately not capped: an application's connectors and
        # the agent's own are both capability the user asked for, and silently
        # dropping either is the failure this whole change set exists to remove.
        # A large surface is reported instead, because tool-selection accuracy
        # degrades well before anything errors.
        bound_tools = len(getattr(connector_middleware, "tools", None) or []) + len(
            getattr(context_middleware, "tools", None) or []
        )
        if bound_tools > MANY_TOOLS_WARNING_THRESHOLD:
            logger.warning(
                "Agent '%s' is bound to %d grounding tools (%d own + %d "
                "application connectors, %d knowledge bases). Nothing was "
                "dropped, but tool selection gets less reliable past roughly "
                "%d — consider narrowing what this agent or its application "
                "attaches.",
                agent_config.get("agent_id") or "unknown",
                bound_tools, len(own_conn), len(lent_conn), len(knowledge),
                MANY_TOOLS_WARNING_THRESHOLD,
            )

        configured = len(knowledge) + len(connectors) + len(files)
        usable = (
            sum(1 for k in knowledge if k.resolved)
            + sum(1 for c in connectors if c.resolved)
            + sum(1 for f in files if f.resolved)
        )
        if configured and not usable:
            logger.error(
                "Agent '%s' has %d configured source(s) and not one resolved. It "
                "will answer ungrounded. Check that the principal (%s) owns them "
                "and that Connector Settings is on for this agent.",
                agent_config.get("agent_id") or "unknown",
                configured,
                owner_user_id or "unknown",
            )
    except Exception:  # noqa: BLE001 -- telemetry must never fail a build
        logger.debug("Could not log the grounding surface", exc_info=True)


def _interrupt_on_from_config(agent_config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Read config-declared per-tool approval requirements.

    This is the tool-call approval surface. It is deliberately separate from
    Echo's node-level HITL gate (``HITLManager``), which pauses a workflow
    before an agent runs rather than before a tool call.
    """
    metadata = agent_config.get("metadata")
    approvals = metadata.get("tool_approvals") if isinstance(metadata, dict) else None
    return approvals if isinstance(approvals, dict) and approvals else None


class AgentFactory:
    """
    Agent factory service.

    Instantiates agents with model, tool and middleware bindings.
    """

    def __init__(self, tool_registry=None):
        """
        Initialize factory.

        Args:
            tool_registry: Tool registry used for the descriptive tool metadata
                attached to ``AgentRuntime``. Executable tool binding goes
                through ``apps.tool.langchain_tools``.
        """
        self.tool_registry = tool_registry or {}

    # ------------------------------------------------------------------
    # The single instantiation path
    # ------------------------------------------------------------------

    def build_with_context(
        self,
        agent_config: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
        tool_specs: Optional[Any] = None,
        exec_context: Optional[Dict[str, Any]] = None,
        run_id: Optional[str] = None,
        on_tool_start: Optional[Any] = None,
        on_tool_end: Optional[Any] = None,
        interrupt_on: Optional[Dict[str, Any]] = None,
        checkpointer: Any = None,
        tool_budget_state: Optional[Dict[str, Any]] = None,
        bind_tools: bool = True,
        component: str = DEFAULT_COMPONENT,
        request: str = "",
        readiness_state: Optional[Dict[str, Any]] = None,
    ) -> AgentBuild:
        """
        Compile an agent and return it together with its build context.

        WHAT: Resolves the model, binds tools, assembles the middleware stack and
              compiles the graph on the active harness.
        WHY:  Callers that need telemetry or the shared budget state (standalone
              chat, workflow nodes) should not have to re-derive them.
        INPUT: An agent definition of any historical shape plus per-call context.
        OUTPUT: An ``AgentBuild``.
        RAISES: Propagates credential resolution failures; an agent without a
                usable model must fail loudly rather than answer from nothing.

        Args:
            agent_config: Agent definition dict.
            user_id: Authenticated user UUID for credential resolution.
            tool_specs: Explicit tool references; defaults to the definition's.
            exec_context: Execution context forwarded to tools.
            run_id: Run identifier used for observability correlation.
            on_tool_start: Hook called before each tool call.
            on_tool_end: Hook called after each tool call.
            interrupt_on: Per-tool approval map; falls back to the definition's.
            checkpointer: LangGraph checkpointer for resumable executions.
            tool_budget_state: Shared budget dict for this agent execution.
            bind_tools: False to compile an agent with no tools at all.
            component: Component label passed to the credential resolver.
            request: The user's message. Read only by the Context Readiness
                Gate's grading stage, which is off by default.
            readiness_state: Run state the gate looks required variables up in.
        """
        # An agent running inside an application also gets that application's
        # datasources. The contribution rides in the execution context because
        # that is the one channel every path already carries -- standalone chat
        # builds it, and a workflow node reads it out of the graph state, so
        # workflow and HITL agents are covered without threading a new
        # parameter through the engine. Merging here rather than at each call
        # site is what makes the four paths agree.
        agent_config = _merge_application_context(agent_config, exec_context)

        # Resolved after the merge so an application-lent entry is already
        # present and carrying its own owner; the principal below governs only
        # the agent's *own* attachments.
        owner_user_id = _resource_principal(agent_config, user_id)

        # ``bind_tools`` is the only tool signal available this early -- the
        # tools themselves are built below, and the middleware stack adds more
        # of its own. It is passed so a reasoning model can select the API
        # surface that accepts tools alongside a reasoning effort.
        llm = resolve_agent_llm(
            agent_config,
            user_id=user_id,
            component=component,
            expects_tools=bool(bind_tools),
        )
        binding = llm.binding
        model = llm.client

        budget_state = ensure_tool_budget_state(tool_budget_state)
        tool_call_limit = int(budget_state.get("max_calls", resolve_tool_call_limit()))

        tools: List[Any] = []
        if bind_tools and tool_call_limit >= 1:
            specs = tool_specs if tool_specs is not None else agent_config.get("tools")
            tools = build_langchain_tools(
                specs,
                exec_context or {},
                user_id,
                run_id,
                budget_state,
                on_tool_start=on_tool_start,
                on_tool_end=on_tool_end,
            )

        # Connectors and attached documents belong to the agent, not to a
        # request, so both are resolved on every build and reach every
        # execution path -- standalone chat, a workflow node, an application
        # component. This is what makes an uploaded file part of the agent
        # rather than of the conversation that uploaded it.
        connector_budget, total_budget = _descriptor_budgets(agent_config)

        connector_middleware = None
        context_middleware = None
        if bind_tools:
            connector_middleware = build_connector_middleware(
                agent_config,
                user_id=user_id,
                owner_user_id=owner_user_id,
                on_tool_start=on_tool_start,
                on_tool_end=on_tool_end,
                token_budget=connector_budget,
            )

        connector_tools = list(connector_middleware.tools) if connector_middleware else []
        connector_context = connector_middleware.context_block if connector_middleware else ""

        if bind_tools:
            # Whatever the connectors did not use is available here, so a small
            # API descriptor leaves more room for the user's documents.
            spent = len(connector_context) // CHARS_PER_TOKEN
            context_middleware = build_agent_context_middleware(
                agent_config,
                user_id=user_id,
                owner_user_id=owner_user_id,
                on_tool_start=on_tool_start,
                on_tool_end=on_tool_end,
                token_budget=max(MIN_DESCRIPTOR_TOKENS, total_budget - spent),
                # Drives the pre-retrieval pass, which is what makes an
                # attached knowledge base or document reach the model whether
                # or not it chooses to call a search tool. Already supplied by
                # every runtime call site for the readiness gate below, so no
                # caller changes.
                request=request,
            )

        context_tools = list(context_middleware.tools) if context_middleware else []
        attached_context = context_middleware.context_block if context_middleware else ""

        # Documents uploaded into this conversation are searched, not pasted.
        # Only ever present when an application merged them in, so an agent
        # outside an application chat builds exactly as it did before.
        session_doc_middleware = None
        if bind_tools:
            session_doc_middleware = build_session_document_middleware(
                agent_config,
                user_id=user_id,
                on_tool_start=on_tool_start,
                on_tool_end=on_tool_end,
            )
        session_doc_tools = (
            list(session_doc_middleware.tools) if session_doc_middleware else []
        )
        if session_doc_middleware and session_doc_middleware.context_block:
            attached_context = "\n\n".join(
                part
                for part in (attached_context, session_doc_middleware.context_block)
                if part
            )

        has_tools = bool(tools or connector_tools or context_tools or session_doc_tools)

        # Context Readiness Gate (spec 4.3). Runs here because it needs what the
        # two capability middlewares just resolved, and because its findings
        # have to reach the prompt below -- which is only true in warn mode. In
        # block mode the caller reads ``build.readiness.should_block`` and
        # returns the message instead of invoking; in off mode nothing runs.
        # No model call is made here unless grading is explicitly enabled.
        readiness = check_readiness(
            agent_config,
            request=request,
            user_id=user_id,
            context=context_middleware.context if context_middleware else None,
            connectors=connector_middleware.connectors if connector_middleware else None,
            state=readiness_state,
        )

        system_prompt = build_system_prompt(
            agent_config,
            has_tools=has_tools,
            connector_context=connector_context,
            attached_context=attached_context,
            readiness_note=readiness.prompt_note(),
        )

        # ToolCallLimitMiddleware counts every bound tool, so the ceiling has to
        # cover the connector allowance as well. Without this a database agent
        # would be cut off after three calls -- list tables, read schema, one
        # query -- with nothing left to answer with.
        combined_tool_call_limit = _combined_tool_call_limit(
            tool_call_limit if tools else 0,
            connector_middleware,
            context_middleware,
            session_doc_middleware,
        )

        middleware = build_middleware_stack(
            base_system_prompt=system_prompt,
            tool_call_limit=combined_tool_call_limit,
            # The planner contributes a `write_todos` tool, which forces tool
            # binding on the model. An agent with no tools must stay on plain
            # generation so providers without function calling still work.
            include_planner=has_tools and not provides_planner(),
            interrupt_on=interrupt_on or _interrupt_on_from_config(agent_config),
            budget_state=budget_state,
            extra_middleware=[
                middleware
                for middleware in (
                    connector_middleware, context_middleware, session_doc_middleware
                )
                if middleware is not None
            ] or None,
            # Carries the model's stated input window. Context summarization
            # attaches only when that window is actually known, so an agent on
            # a model of unknown size behaves exactly as it did before.
            model=model,
        )

        agent = create_harness_agent(
            model=model,
            tools=tools,
            middleware=middleware,
            checkpointer=checkpointer,
            name=_graph_name(agent_config),
        )

        # The graph's recursion limit is resolved from these at invocation time.
        # Every before_model/after_model hook in the stack is its own graph node
        # and therefore its own super-step, so one model-plus-tool cycle costs
        # `2 + middleware nodes`, not 2. Measuring the stack that was actually
        # built is what stops a ceiling sized for a bare ReAct loop from
        # aborting the run with GraphRecursionError long before the tool budget
        # -- the limit meant to stop it -- is reached.
        cycle_steps = BARE_CYCLE_STEPS + count_middleware_nodes(middleware)
        record_tool_ceiling(agent, combined_tool_call_limit, cycle_steps)

        logger.info(
            "Built agent '%s' on %s harness: model=%s provider=%s credential=%s "
            "tools=%d connector_tools=%d context_tools=%d session_doc_tools=%d",
            agent_config.get("agent_id") or agent_config.get("id") or "unknown",
            harness_name(),
            llm.resolution.get("model") or binding.model_name,
            llm.resolution.get("provider") or binding.provider or "resolver-default",
            llm.resolution.get("credential_id") or "platform-fallback",
            len(tools),
            len(connector_tools),
            len(context_tools),
            len(session_doc_tools),
        )

        _log_grounding_surface(
            agent_config,
            connector_middleware=connector_middleware,
            context_middleware=context_middleware,
            user_id=user_id,
            owner_user_id=owner_user_id,
        )

        return AgentBuild(
            agent=agent,
            binding=binding,
            tools=tools + connector_tools + context_tools + session_doc_tools,
            budget_state=budget_state,
            system_prompt=system_prompt,
            harness=harness_name(),
            resolution=llm.resolution,
            connectors=connector_middleware,
            context=context_middleware,
            readiness=readiness,
        )

    def build(self, agent_config: Dict[str, Any], **kwargs: Any) -> Any:
        """
        Compile an agent definition into a runnable LangGraph agent.

        This is the spec section 4.1 entry point. See ``build_with_context`` for
        the full parameter list.
        """
        return self.build_with_context(agent_config, **kwargs).agent

    # ------------------------------------------------------------------
    # Runtime facade (standalone chat and application components)
    # ------------------------------------------------------------------

    def create_agent(
        self,
        agent_def: Dict[str, Any],
        bind_tools: bool = True,
        user_id: Optional[str] = None,
    ) -> AgentRuntime:
        """
        Create a runtime agent instance from a definition.

        WHAT: Wraps the definition in the dict-like ``AgentRuntime`` facade whose
              ``.chat()`` compiles through ``build()``.
        WHY:  ``/agents/instantiate/{id}`` serializes this object directly and
              ``/agents/{id}/chat`` calls ``.chat()``, so the shape is public API.
        INPUT: Agent definition, tool binding flag, authenticated user UUID.
        OUTPUT: ``AgentRuntime``.

        No model is constructed here. Compilation happens per ``.chat()`` call so
        credentials are re-resolved from Key Vault every time.
        """
        agent_id = agent_def.get("agent_id") or agent_def.get("id")
        binding = resolve_model_binding(agent_def)

        tool_refs = agent_def.get("tools") or []
        tools: List[Dict[str, Any]] = []
        tool_defs: List[Any] = []
        if bind_tools:
            tools, tool_defs = self._describe_tools(tool_refs)

        runtime_def = dict(agent_def)
        runtime_def["agent_id"] = agent_id
        runtime_def["provider"] = binding.provider or ""
        runtime_def["tools"] = tools
        runtime_def["constraints"] = agent_def.get("constraints", {})
        runtime_def["runtime_ready"] = True
        # Descriptive metadata replaces ``tools`` in the serialized response, so
        # the executable references are preserved separately for build().
        runtime_def["_runtime_tool_refs"] = tool_refs
        runtime_def["_runtime_bind_tools"] = bool(bind_tools)
        if user_id:
            runtime_def["_runtime_user_id"] = user_id

        return AgentRuntime(
            agent_def=runtime_def,
            factory=self,
            tools=tools,
            tool_defs=tool_defs,
        )

    def create_agents_for_workflow(
        self,
        agent_definitions: Dict[str, Dict[str, Any]],
        user_id: Optional[str] = None,
    ) -> Dict[str, AgentRuntime]:
        """
        Create multiple runtime agent instances.

        Args:
            agent_definitions: Dict of agent_id -> agent_def.
            user_id: Authenticated user UUID for credential resolution.

        Returns:
            Dict of agent_id -> AgentRuntime.
        """
        return {
            agent_id: self.create_agent(agent_def, user_id=user_id)
            for agent_id, agent_def in agent_definitions.items()
        }

    def _describe_tools(self, tool_refs: Any) -> Tuple[List[Dict[str, Any]], List[Any]]:
        """
        Resolve descriptive tool metadata for the serialized runtime.

        WHAT: Looks each reference up in the registry and returns display
              metadata plus the raw ToolDef objects.
        WHY:  The instantiate endpoint exposes which tools an agent carries.
              Executable binding is a separate concern owned by
              ``apps.tool.langchain_tools``.
        INPUT: Tool ids or tool spec dicts.
        OUTPUT: Tuple of (metadata list, ToolDef list).
        """
        metadata: List[Dict[str, Any]] = []
        tool_defs: List[Any] = []

        for ref in tool_refs or []:
            if isinstance(ref, str):
                tool_id = ref
            elif isinstance(ref, dict):
                tool_id = ref.get("tool_id") or ref.get("id")
            else:
                continue
            if not tool_id:
                continue

            tool_def = self.tool_registry.get(tool_id) if self.tool_registry else None
            if tool_def is None:
                continue

            name = (
                tool_def.name
                if hasattr(tool_def, "name")
                else (tool_def.get("name") if isinstance(tool_def, dict) else str(tool_def))
            )
            metadata.append({"tool_id": tool_id, "name": name, "bound": True})
            if hasattr(tool_def, "tool_id"):
                tool_defs.append(tool_def)

        return metadata, tool_defs

    def validate_agent_config(self, agent_def: Dict[str, Any]) -> bool:
        """
        Validate an agent configuration before instantiation.

        Mirrors the Phase 1 contract, whose required fields are ``agent_id`` and
        ``name``. The model no longer needs to be present: ``model_config`` is
        defaulted by the contract and the credential cascade resolves the rest.

        Args:
            agent_def: Agent definition.

        Returns:
            True if valid.
        """
        if not isinstance(agent_def, dict):
            return False
        if not (agent_def.get("agent_id") or agent_def.get("id")):
            return False
        return bool(str(agent_def.get("name") or "").strip())


__all__ = ["AgentBuild", "AgentFactory", "AgentRuntime", "invoke_agent"]
