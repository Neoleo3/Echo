"""
One streaming contract for every agent execution path.

WHAT: Turns a compiled agent's LangGraph stream into a flat sequence of typed
      ``AgentEvent`` objects -- tokens, tool lifecycle, progress notes, the
      final answer.
WHY:  Before this module nothing in the platform called ``.stream()`` or
      ``.astream()``: every path went through ``agent.invoke()``
      (``factory/invocation.py``), so the application SSE channel could only
      deliver one finished string and the workflow WebSocket channel could only
      deliver step lifecycle. Real-time output had no producer. Both transports
      now consume this one producer, so the app stream and the canvas stream
      cannot drift apart.

Stream shape, and why it is normalised here rather than at each consumer:
LangGraph changed the multi-mode envelope between 1.0 and 1.1. On 1.0 a
multi-mode ``astream`` yields ``(mode, payload)`` tuples; on 1.1 with
``version="v2"`` it yields a ``StreamPart`` mapping ``{type, ns, data}``. The
pinned requirement is 1.1.2 and the installed runtime may still be 1.0.x until
Phase 0 lands, so ``_unpack`` accepts both and every consumer sees one shape.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, Iterable, List, Optional, Tuple

# Stop-reason handling lives in ``factory/completion.py`` so that every
# invocation path reads one implementation -- the streaming paths here, and
# ``invoke_agent``, which used to read none at all.
from .factory.completion import (
    TRUNCATION_NOTE,
    finish_reason as _finish_reason,
    was_truncated,
)
from .factory.invocation import (
    build_messages,
    graph_cycle_steps,
    graph_tool_ceiling,
    resolve_recursion_limit,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Event vocabulary
# ---------------------------------------------------------------------------

EVENT_TOKEN = "token"
"""An incremental fragment of the assistant's answer."""

EVENT_TOOL_START = "tool_start"
"""The model has decided to call a tool. Carries the tool name."""

EVENT_TOOL_END = "tool_end"
"""A tool returned. Carries the tool name and a truncated result preview."""

EVENT_PROGRESS = "progress"
"""A note pushed from inside a tool or middleware via ``get_stream_writer``."""

EVENT_INTERRUPT = "interrupt"
"""The graph paused (tool-level approval). Carries the interrupt payload."""

EVENT_FINAL = "final"
"""Terminal event. Carries the complete answer text."""

EVENT_ERROR = "error"
"""Terminal event. Carries the failure message."""

# The modes requested from LangGraph, and the only ones ``_unpack`` will treat
# as an envelope tag. Kept as a tuple so the request is identical everywhere.
STREAM_MODES: Tuple[str, ...] = ("updates", "messages", "custom")

_MODE_TAGS = frozenset(STREAM_MODES)

# The tool node never produces answer text -- it produces ToolMessages. Tokens
# tagged with it are the tool-call arguments being assembled, which are noise to
# a reader and would appear as raw JSON in the middle of a sentence.
_NON_ANSWER_NODES = frozenset({"tools", "tool_node"})

# Tool results are echoed to the reader as a short confirmation, not as data.
# The model receives the full result; the reader does not need it, and a large
# payload on a WebSocket frame is the hazard ``ws_manager`` already guards
# against elsewhere.
TOOL_PREVIEW_CHARS = 240

RECURSION_NOTE = (
    "\n\n_(This response was cut short after the agent reached its step limit. "
    "It may be incomplete.)_"
)
"""Appended to salvaged output so partial work is never presented as complete."""

def _last_ai_finish_reason(chunk: Any) -> str:
    """
    The stop reason of the newest assistant message in an update chunk.

    **Messages carrying tool calls are included.** This traversal used to skip
    them, mirroring ``_last_ai_text`` -- which is right for *text*, because a
    tool call's arguments are not an answer, but wrong for the *reason*. A
    document generator's whole payload is a tool call, so a report cut off
    mid-JSON produced no warning anywhere: the one case where truncation does
    the most damage was the one case this was written to ignore.

    A normal tool call stops with ``tool_calls``, which ``was_truncated``
    rejects, so including them adds no false positives.
    """
    mode, payload = _unpack(chunk)
    if mode not in ("updates", "") or not isinstance(payload, dict):
        return ""

    reason = ""
    for node, update in payload.items():
        if node in _NON_ANSWER_NODES:
            continue
        for message in channel_messages(update):
            if getattr(message, "type", "") != "ai":
                continue
            found = _finish_reason(message)
            if not found:
                continue
            # A truncation already seen is never displaced by a later ordinary
            # stop: the run was cut short, and the newest message being clean
            # does not undo that.
            if was_truncated(found) or not was_truncated(reason):
                reason = found
    return reason


def _is_recursion_abort(exc: BaseException) -> bool:
    """
    True when a failure is LangGraph's recursion guard rather than a real error.

    Matched by type where the exception class is importable, and by message as a
    fallback so a version that moves or renames it still degrades gracefully
    rather than turning a salvageable turn into a failed one.
    """
    try:
        from langgraph.errors import GraphRecursionError

        if isinstance(exc, GraphRecursionError):
            return True
    except Exception:  # noqa: BLE001 -- fall through to the message check
        pass
    return "recursion limit" in str(exc).lower()


@dataclass(frozen=True)
class AgentEvent:
    """
    One thing that happened while an agent was answering.

    Deliberately flat and JSON-safe: both transports serialise it directly, so a
    nested LangChain object here would become an unserialisable frame at the
    edge rather than a caught error here.
    """

    type: str
    text: str = ""
    name: str = ""
    node: str = ""
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialise for a transport frame, omitting empty fields."""
        payload: Dict[str, Any] = {"event": self.type}
        if self.text:
            payload["text"] = self.text
        if self.name:
            payload["name"] = self.name
        if self.node:
            payload["node"] = self.node
        if self.data:
            payload["data"] = self.data
        return payload


# ---------------------------------------------------------------------------
# Envelope and content normalisation
# ---------------------------------------------------------------------------


def _unpack(chunk: Any) -> Tuple[str, Any]:
    """
    Read ``(mode, payload)`` out of either multi-mode envelope shape.

    LangGraph 1.1's ``StreamPart`` is a mapping carrying ``type``/``ns``/``data``;
    1.0's multi-mode yield is a two-tuple. A ``custom`` payload could itself be a
    dict with a ``type`` key, so the mapping branch additionally requires the tag
    to be one of the modes actually requested -- otherwise a user's own
    ``{"type": ...}`` progress dict would be mistaken for an envelope.
    """
    if isinstance(chunk, dict) and "data" in chunk and chunk.get("type") in _MODE_TAGS:
        return str(chunk["type"]), chunk["data"]
    if isinstance(chunk, tuple) and len(chunk) == 2 and chunk[0] in _MODE_TAGS:
        return str(chunk[0]), chunk[1]
    return "", chunk


def content_text(content: Any) -> str:
    """
    Flatten a message's content into text.

    Anthropic and Gemini return a list of content blocks; concatenating the
    ``text`` blocks is what keeps a streamed answer from arriving as a
    stringified Python list. Reasoning blocks are dropped: they are the model's
    private deliberation, not its answer, and Copilot-style UIs surface them on a
    separate channel rather than inline.
    """
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        parts: List[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                if block.get("type") in ("reasoning", "thinking"):
                    continue
                value = block.get("text")
                if isinstance(value, str):
                    parts.append(value)
        return "".join(parts)

    return "" if content is None else str(content)


def _is_answer_token(message: Any, metadata: Any) -> bool:
    """
    True when a streamed chunk belongs in the reader's answer.

    Three exclusions, each for a different reason: the tool node emits
    ToolMessages rather than prose; a chunk carrying ``tool_calls`` is the
    arguments being assembled token by token; and an empty chunk is the
    end-of-stream marker most providers send.
    """
    node = ""
    if isinstance(metadata, dict):
        node = str(metadata.get("langgraph_node") or "")
    if node in _NON_ANSWER_NODES:
        return False

    if getattr(message, "tool_calls", None):
        return False
    if getattr(message, "tool_call_chunks", None):
        return False

    return bool(content_text(getattr(message, "content", "")))


def channel_messages(update: Any) -> List[Any]:
    """
    Read the message list out of one node's state update.

    WHAT: Returns the messages a node wrote, or an empty list for anything that
          is not a message write.
    WHY:  A node does not always write a plain list. LangGraph lets middleware
          replace a reducer-managed channel outright rather than append to it,
          and it signals that by wrapping the new value -- ``Overwrite(value=[
          ...])``. Deep Agents' ``PatchToolCallsMiddleware`` does exactly this on
          ``before_agent``, so it is the *first* updates chunk of every run on
          that harness. Iterating the wrapper raised ``TypeError``, which
          ``astream_agent`` converted into a terminal ``error`` event -- so with
          Deep Agents installed, every streaming surface returned an error
          instead of the answer while ``invoke()`` kept working.
    INPUT: Whatever a node placed under its state key.
    OUTPUT: A list of messages, never ``None``.

    Unwrapping by attribute rather than by importing the wrapper type keeps this
    working across LangGraph releases that rename or relocate it, and covers any
    other single-value wrapper that follows the same convention.
    """
    if update is None:
        return []

    value = update.get("messages") if isinstance(update, dict) else None
    if value is None:
        return []

    # Unwrap a channel-write wrapper: an object that is not itself a sequence
    # but carries the written value on ``.value``.
    if not isinstance(value, (list, tuple)) and hasattr(value, "value"):
        value = value.value

    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _messages_events(payload: Any) -> Iterable[AgentEvent]:
    """Translate one ``messages`` payload -- an ``(AIMessageChunk, metadata)`` pair."""
    if not isinstance(payload, tuple) or len(payload) != 2:
        return

    message, metadata = payload
    if not _is_answer_token(message, metadata):
        return

    node = str(metadata.get("langgraph_node") or "") if isinstance(metadata, dict) else ""
    yield AgentEvent(
        type=EVENT_TOKEN,
        text=content_text(getattr(message, "content", "")),
        node=node,
    )


def _updates_events(payload: Any) -> Iterable[AgentEvent]:
    """
    Translate one ``updates`` payload -- ``{node_name: state_update}``.

    This is where tool lifecycle comes from. ``messages`` mode cannot supply it:
    a tool call arrives there as argument fragments with no completion signal,
    and a tool result arrives as a ToolMessage on the excluded tool node.
    """
    if not isinstance(payload, dict):
        return

    for node, update in payload.items():
        if node == "__interrupt__":
            yield AgentEvent(type=EVENT_INTERRUPT, data={"interrupt": _describe(update)})
            continue

        for message in channel_messages(update):
            kind = getattr(message, "type", "")

            if kind == "tool":
                yield AgentEvent(
                    type=EVENT_TOOL_END,
                    name=str(getattr(message, "name", "") or ""),
                    node=str(node),
                    text=content_text(getattr(message, "content", ""))[:TOOL_PREVIEW_CHARS],
                    data={"status": getattr(message, "status", "success")},
                )
                continue

            for call in getattr(message, "tool_calls", None) or []:
                name = call.get("name") if isinstance(call, dict) else getattr(call, "name", "")
                yield AgentEvent(
                    type=EVENT_TOOL_START,
                    name=str(name or ""),
                    node=str(node),
                )


def _custom_events(payload: Any) -> Iterable[AgentEvent]:
    """
    Translate one ``custom`` payload.

    Anything a tool or middleware pushed through ``langgraph.config``'s stream
    writer. A plain string is a human-readable note; a mapping is passed through
    so a caller can carry structure without this module inventing a schema.
    """
    if isinstance(payload, str):
        yield AgentEvent(type=EVENT_PROGRESS, text=payload)
    elif isinstance(payload, dict):
        yield AgentEvent(
            type=EVENT_PROGRESS,
            text=str(payload.get("message") or payload.get("text") or ""),
            data={k: v for k, v in payload.items() if k not in ("message", "text")},
        )
    elif payload is not None:
        yield AgentEvent(type=EVENT_PROGRESS, text=str(payload))


def _describe(value: Any) -> Any:
    """Reduce an arbitrary LangGraph payload to something JSON-serialisable."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _describe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_describe(v) for v in value]
    return str(value)


def translate_chunk(chunk: Any) -> List[AgentEvent]:
    """
    Translate one raw stream chunk into zero or more events.

    Separate from the generator so a consumer can normalise a chunk it obtained
    some other way, and so this can be exercised without a live model.
    """
    mode, payload = _unpack(chunk)

    if mode == "messages":
        return list(_messages_events(payload))
    if mode == "updates":
        return list(_updates_events(payload))
    if mode == "custom":
        return list(_custom_events(payload))

    # A single-mode stream yields bare chunks. Nothing in this codebase requests
    # one, but an untagged chunk must not be silently dropped, so fall back to
    # the two shapes that can be recognised without a tag.
    if isinstance(payload, tuple) and len(payload) == 2:
        return list(_messages_events(payload))
    if isinstance(payload, dict):
        return list(_updates_events(payload))
    return []


# ---------------------------------------------------------------------------
# The generator
# ---------------------------------------------------------------------------


def _last_ai_text(chunk: Any) -> str:
    """
    Read the newest complete assistant message out of an ``updates`` chunk.

    The fallback for a provider that does not stream: ``messages`` mode yields
    nothing, but the finished message still lands in a state update, so the
    reader gets one late block instead of silence. Without this a non-streaming
    provider would return an empty answer through the streaming path while
    ``invoke()`` returned the real one.
    """
    mode, payload = _unpack(chunk)
    if mode not in ("updates", "") or not isinstance(payload, dict):
        return ""

    text = ""
    for node, update in payload.items():
        if node in _NON_ANSWER_NODES:
            continue
        for message in channel_messages(update):
            if getattr(message, "type", "") == "ai" and not getattr(message, "tool_calls", None):
                candidate = content_text(getattr(message, "content", ""))
                if candidate:
                    text = candidate
    return text


async def astream_agent(
    agent: Any,
    task: str,
    *,
    history: Optional[List[Any]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> AsyncIterator[AgentEvent]:
    """
    Stream a compiled agent's execution as typed events.

    WHAT: Requests ``updates``, ``messages`` and ``custom`` together and emits
          one flat event sequence, always terminated by exactly one ``final`` or
          one ``error``.
    WHY:  A reader needs three different things at once -- what the agent is
          doing (tool lifecycle, from ``updates``), what it is saying (tokens,
          from ``messages``) and any note a tool wanted to surface (``custom``).
          Requesting them in one pass is what makes the Copilot-style
          "steps first, answer after" sequence a property of the stream rather
          than something each transport reassembles.
    INPUT: Compiled graph, task text, optional prior turns and LangGraph config.
    OUTPUT: Async iterator of ``AgentEvent``.

    Never raises: a model or graph failure becomes a terminal ``error`` event, so
    a transport that has already sent headers can report the failure in-band
    instead of dropping the connection.
    """
    invoke_config: Dict[str, Any] = {
        "recursion_limit": resolve_recursion_limit(
            graph_tool_ceiling(agent), graph_cycle_steps(agent)
        )
    }
    if config:
        invoke_config.update(config)

    collected: List[str] = []
    fallback = ""
    stop_reason = ""

    try:
        stream = agent.astream(
            {"messages": build_messages(task, history)},
            config=invoke_config,
            stream_mode=list(STREAM_MODES),
        )
        async for chunk in stream:
            fallback = _last_ai_text(chunk) or fallback
            stop_reason = _last_ai_finish_reason(chunk) or stop_reason
            for event in translate_chunk(chunk):
                if event.type == EVENT_TOKEN:
                    collected.append(event.text)
                yield event
    except Exception as exc:  # noqa: BLE001 -- terminal event, not a swallow
        if _is_recursion_abort(exc):
            # The graph safety net fired. With the tool budget ending the run
            # (``exit_behavior="end"``) and the limit sized to the real
            # per-cycle step cost this should be unreachable -- but if it ever
            # is reached, whatever the agent produced is worth more to the user
            # than a failed step, and the application's step bookkeeping treats
            # an error event as a hard failure.
            partial = "".join(collected) or fallback
            logger.error(
                "Agent stream hit the graph recursion limit; returning %d "
                "character(s) of partial output instead of failing the step: %s",
                len(partial), exc,
            )
            if partial:
                yield AgentEvent(type=EVENT_FINAL, text=partial + RECURSION_NOTE)
            else:
                # Nothing to salvage, so the caller must still hear about it.
                yield AgentEvent(type=EVENT_ERROR, text=str(exc))
            return

        logger.exception("Agent stream failed: %s", exc)
        yield AgentEvent(type=EVENT_ERROR, text=str(exc))
        return

    answer = "".join(collected)
    if not answer and fallback:
        # The provider did not stream. Emit the whole answer as one token so a
        # reader that only handles tokens still shows something before ``final``.
        logger.info("Agent produced no streamed tokens; emitting the complete message")
        yield AgentEvent(type=EVENT_TOKEN, text=fallback)
        answer = fallback

    if was_truncated(stop_reason):
        # Said out loud rather than logged only. A ceiling that binds invisibly
        # is indistinguishable from a model that stopped early, which is why
        # this was so hard to attribute.
        logger.warning(
            "Agent output stopped at its token ceiling (stop reason %r) after "
            "%d character(s). The answer is incomplete.",
            stop_reason, len(answer),
        )
        answer = answer + TRUNCATION_NOTE

    yield AgentEvent(type=EVENT_FINAL, text=answer)


def stream_agent_sync(
    agent: Any,
    task: str,
    *,
    history: Optional[List[Any]] = None,
    config: Optional[Dict[str, Any]] = None,
    on_event: Optional[Any] = None,
) -> str:
    """
    Synchronous twin of ``astream_agent``, returning the final text.

    WHAT: Drives ``agent.stream`` and hands each translated event to ``on_event``,
          then returns the complete answer.
    WHY:  LangGraph invokes workflow nodes synchronously, so a workflow agent
          node cannot await. Without this the canvas could only ever show step
          lifecycle, while the application chat showed live output -- the same
          agent, two different levels of transparency.
    INPUT: Compiled graph, task text, optional history, config and consumer.
    OUTPUT: Final assistant text.
    RAISES: Propagates model and graph errors, matching ``invoke_agent`` -- the
            node has its own error handling and turns a failure into a step
            failure, which an in-band error event would hide.
    """
    invoke_config: Dict[str, Any] = {
        "recursion_limit": resolve_recursion_limit(
            graph_tool_ceiling(agent), graph_cycle_steps(agent)
        )
    }
    if config:
        invoke_config.update(config)

    collected: List[str] = []
    fallback = ""
    stop_reason = ""

    def _deliver(event: AgentEvent) -> None:
        if on_event is None:
            return
        try:
            on_event(event)
        except Exception:
            logger.debug("Agent event consumer failed", exc_info=True)

    for chunk in agent.stream(
        {"messages": build_messages(task, history)},
        config=invoke_config,
        stream_mode=list(STREAM_MODES),
    ):
        fallback = _last_ai_text(chunk) or fallback
        stop_reason = _last_ai_finish_reason(chunk) or stop_reason
        for event in translate_chunk(chunk):
            if event.type == EVENT_TOKEN:
                collected.append(event.text)
            _deliver(event)

    answer = "".join(collected) or fallback

    if was_truncated(stop_reason):
        # Same treatment as the async twin. A workflow node that returns a
        # truncated answer feeds it to the next node as though it were whole,
        # so the note has to travel with the text rather than only be logged.
        logger.warning(
            "Agent output stopped at its token ceiling (stop reason %r) after "
            "%d character(s). The answer is incomplete.",
            stop_reason, len(answer),
        )
        answer = answer + TRUNCATION_NOTE

    _deliver(AgentEvent(type=EVENT_FINAL, text=answer))
    return answer


# ---------------------------------------------------------------------------
# Coalescing
# ---------------------------------------------------------------------------

FLUSH_CHARS = 48
"""Emit once this many characters have accumulated."""

FLUSH_SECONDS = 0.12
"""...or once this long has passed since the last emission, whichever is first."""


class TokenCoalescer:
    """
    Batches token fragments into readable chunks before they hit a transport.

    WHY: A model emits one frame per token. Forwarding each one produces
         thousands of frames per answer, which is wasted bandwidth on SSE and an
         outright hazard on the workflow WebSocket, where every event is also
         buffered for replay (``ws_manager``). Production chat UIs batch for the
         same reason: below roughly 100 ms the reader cannot tell the difference.

    Time **and** size, not either alone: size alone stalls on a slow model that
    trickles a few characters, and time alone still floods on a fast one.
    """

    def __init__(self, *, flush_chars: int = FLUSH_CHARS, flush_seconds: float = FLUSH_SECONDS):
        self._flush_chars = max(1, flush_chars)
        self._flush_seconds = max(0.0, flush_seconds)
        self._buffer: List[str] = []
        self._pending = 0
        self._last = 0.0
        self.seq = 0

    def add(self, text: str) -> Optional[str]:
        """Accept a fragment; return a batch when one is due, otherwise ``None``."""
        if not text:
            return None

        self._buffer.append(text)
        self._pending += len(text)

        now = time.monotonic()
        if self._last == 0.0:
            self._last = now

        if self._pending >= self._flush_chars or (now - self._last) >= self._flush_seconds:
            self._last = now
            return self._drain()
        return None

    def flush(self) -> Optional[str]:
        """Return whatever is left, or ``None`` when nothing is pending."""
        return self._drain() if self._buffer else None

    def _drain(self) -> str:
        batch = "".join(self._buffer)
        self._buffer.clear()
        self._pending = 0
        self.seq += 1
        return batch


__all__ = [
    "AgentEvent",
    "FLUSH_CHARS",
    "FLUSH_SECONDS",
    "TokenCoalescer",
    "EVENT_ERROR",
    "EVENT_FINAL",
    "EVENT_INTERRUPT",
    "EVENT_PROGRESS",
    "EVENT_TOKEN",
    "EVENT_TOOL_END",
    "EVENT_TOOL_START",
    "STREAM_MODES",
    "TOOL_PREVIEW_CHARS",
    "TRUNCATION_NOTE",
    "astream_agent",
    "channel_messages",
    "content_text",
    "stream_agent_sync",
    "translate_chunk",
    "was_truncated",
]
