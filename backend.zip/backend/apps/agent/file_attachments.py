"""
Attaching files, URLs and knowledge bases to an agent.

WHAT: The read/attach/detach/refresh operations behind the agent context
      endpoints, including the server-side Connector Settings gate.
WHY:  A document attached while configuring an agent has to become part of that
      agent, not of the request that uploaded it. That means three things have
      to happen together and stay consistent: a registry row, an entry in
      ``definition.files[]``, and converted content in the store. Doing any of
      them in a route body is how they drift apart.

Conversion, chunking and embedding are owned by ``apps.markitdown``; this module
decides *when* they run and writes the outcome to Postgres. Nothing is written
to local disk: the platform runs on cloud containers with more than one replica
and no shared filesystem, so a file written by one replica would be invisible to
the next and gone after a restart.

Ingestion is dispatched as a background task because converting a scanned
fifty-page PDF means one vision call per page -- a user should not hold an HTTP
connection open for that.
"""
from __future__ import annotations

import asyncio
import copy
import logging
import os
from typing import Any, Dict, List, Optional, Sequence, Tuple

from apps.agent.definition_store import (
    GATE_MESSAGE,
    AgentNotFound,
    AgentSettingsDisabled,
    load_definition,
    save_definition,
)
from echolib.agent_contract import connectors_enabled
from echolib.database import get_db_session
from echolib.models.agent_file import (
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_PROCESSING,
    STATUS_READY,
)
from echolib.repositories.agent_file_repo import (
    AgentFileChunkRepository,
    AgentFileRepository,
    AgentKnowledgeBaseLinkRepository,
)

logger = logging.getLogger(__name__)

_files = AgentFileRepository()
_chunks = AgentFileChunkRepository()
_links = AgentKnowledgeBaseLinkRepository()


class AttachmentNotFound(LookupError):
    """The attachment does not exist for this user."""


class KnowledgeBaseNotFound(LookupError):
    """The knowledge base does not exist, or is not owned by this user."""


# ---------------------------------------------------------------------------
# Definition mirror
# ---------------------------------------------------------------------------

async def _mirror_into_definition(
    agent_id: str, user_id: str, entry: Dict[str, Any]
) -> None:
    """
    Record an attachment's identity in ``definition.files[]``.

    Only identity is mirrored. Status, counts and errors stay in the registry
    row, so a background ingest finishing never rewrites the agent definition
    and never inflates ``config_version``.
    """
    definition = await load_definition(agent_id, user_id)
    updated = copy.deepcopy(definition)
    existing = [
        f for f in (updated.get("files") or []) if f.get("file_id") != entry["file_id"]
    ]
    updated["files"] = existing + [entry]
    await save_definition(agent_id, user_id, updated)


async def _remove_from_definition(agent_id: str, user_id: str, file_id: str) -> None:
    definition = await load_definition(agent_id, user_id)
    updated = copy.deepcopy(definition)
    updated["files"] = [
        f for f in (updated.get("files") or []) if f.get("file_id") != file_id
    ]
    await save_definition(agent_id, user_id, updated)


async def _mirror_knowledge_sources(agent_id: str, user_id: str) -> None:
    """Rewrite ``definition.knowledge_sources[]`` from the link table."""
    async with get_db_session() as db:
        rows = await _links.list_for_agent(db, agent_id)
        entries = [
            {
                "knowledge_base_id": str(row.knowledge_base_id),
                "name": row.alias or str(row.knowledge_base_id),
                "alias": row.alias or "",
                "enabled": True,
            }
            for row in rows
        ]

    definition = await load_definition(agent_id, user_id)
    updated = copy.deepcopy(definition)

    # Generation-time suggestions carry no id (spec Rule 4) and are preserved:
    # they record what the user described, which is not the same as a link.
    suggestions = [
        s for s in (updated.get("knowledge_sources") or [])
        if not s.get("knowledge_base_id")
    ]
    updated["knowledge_sources"] = suggestions + entries
    await save_definition(agent_id, user_id, updated)


async def _require_gate(agent_id: str, user_id: str) -> Dict[str, Any]:
    """Load the agent and refuse when Connector Settings is off."""
    definition = await load_definition(agent_id, user_id)
    if not connectors_enabled(definition):
        raise AgentSettingsDisabled(GATE_MESSAGE)
    return definition


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------

async def _persist(agent_id: str, file_id: str, result: Any) -> None:
    """
    Write one ingest outcome — the row and its passages — in a single transaction.

    Together, deliberately: a row marked ``ready`` whose passages failed to
    write would be described to the agent as searchable and would match
    nothing. Both succeed or the session rolls back and the attachment stays in
    its previous state for the refresh path to retry.
    """
    async with get_db_session() as db:
        await _files.update_fields(db, file_id, result.row())
        await _chunks.replace_for_file(
            db, agent_id=agent_id, agent_file_id=file_id, chunks=result.chunks
        )


async def _run_ingest(
    *,
    agent_id: str,
    user_id: str,
    file_id: str,
    credential_id: Optional[str],
    payload: Optional[bytes] = None,
    filename: Optional[str] = None,
    mime_type: Optional[str] = None,
    url: Optional[str] = None,
    display_name: Optional[str] = None,
) -> None:
    """
    Convert and embed one source, then store the outcome in Postgres.

    Runs as a background task. Every failure is written to the row rather than
    raised: an attachment that failed must say so on the agent's descriptor,
    not disappear or leave the row stuck on ``pending`` forever.
    """
    from apps.markitdown import config as md_config
    from apps.markitdown import ingest_file, ingest_url

    async with get_db_session() as db:
        await _files.update_fields(db, file_id, {"status": STATUS_PROCESSING})

    try:
        if url:
            result = await asyncio.to_thread(
                ingest_url,
                url=url,
                name=display_name,
                user_id=user_id,
                credential_id=credential_id,
                source_id=file_id,
            )
        else:
            result = await asyncio.to_thread(
                ingest_file,
                data=payload or b"",
                filename=filename or "upload",
                user_id=user_id,
                credential_id=credential_id,
                source_id=file_id,
                mime_type=mime_type,
                keep_original=md_config.keep_originals(),
            )
        await _persist(agent_id, file_id, result)
        status = result.status
    except Exception as exc:
        logger.error("Ingest failed for attachment '%s'", file_id, exc_info=True)
        status = STATUS_FAILED
        async with get_db_session() as db:
            await _files.update_fields(
                db,
                file_id,
                {
                    "status": STATUS_FAILED,
                    "error_message": f"This source could not be processed: {exc}",
                },
            )

    logger.info("Attachment '%s' finished with status '%s'", file_id, status)


def _dispatch(coro: Any) -> None:
    """Fire an ingest without waiting for it, matching the knowledge pipeline."""
    asyncio.create_task(coro)


# An attachment younger than this may simply still be converting. A fifty-page
# scanned PDF is one vision call per page, so the window has to clear the
# slowest legitimate ingest rather than the average one.
STALE_INGEST_SECONDS = int(os.getenv("AGENT_FILE_STALE_INGEST_SECONDS", "900"))
STALE_INGEST_BATCH = int(os.getenv("AGENT_FILE_STALE_INGEST_BATCH", "50"))


async def recover_interrupted_ingests(
    *,
    older_than_seconds: Optional[int] = None,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Finish attachments whose conversion was killed by a restart.

    WHAT: Claims rows left ``pending`` or ``processing`` past the cutoff and
          re-runs the ingest from what Postgres already holds — the stored
          original for a file, the address for a URL.
    WHY:  Conversion runs in this process, so a redeploy mid-ingest stranded
          the row permanently and the user's only recourse was to upload the
          document again. Attaching a document must survive a restart, which
          is the whole reason the platform keeps documents in Postgres.
    OUTPUT: Counts, for the startup log. Never raises — a sweep that cannot run
            must not stop the application from starting.

    Safe on more than one replica: the claim is atomic and skips locked rows,
    so replicas divide the work rather than repeating it.
    """
    cutoff = STALE_INGEST_SECONDS if older_than_seconds is None else older_than_seconds
    batch = STALE_INGEST_BATCH if limit is None else limit

    summary: Dict[str, Any] = {"claimed": 0, "resumed": 0, "unrecoverable": 0}

    try:
        async with get_db_session() as db:
            claimed = await _files.claim_stale(
                db, older_than_seconds=cutoff, limit=batch
            )
    except Exception:
        logger.exception("Could not sweep for interrupted attachments")
        return summary

    summary["claimed"] = len(claimed)
    if not claimed:
        return summary

    for record in claimed:
        file_id = record.get("source_id") or ""
        has_source = bool(record.get("content_bytes")) or bool(record.get("url"))

        if not has_source:
            # Nothing to convert from: the upload was held in the process that
            # died. Say so on the row instead of leaving it turning forever.
            summary["unrecoverable"] += 1
            try:
                async with get_db_session() as db:
                    await _files.update_fields(
                        db,
                        file_id,
                        {
                            "status": STATUS_FAILED,
                            "error_message": (
                                "Processing was interrupted before this file was "
                                "stored. Please attach it again."
                            ),
                        },
                    )
            except Exception:
                logger.exception("Could not fail interrupted attachment '%s'", file_id)
            continue

        credential_id = None
        try:
            definition = await load_definition(
                record.get("agent_id") or "", record.get("user_id") or ""
            )
            credential_id = definition.get("credential_id")
        except Exception:
            # The agent may have been deleted or renamed. Re-ingesting on the
            # user's default credential is better than not re-ingesting.
            logger.debug("Could not read the agent for '%s'", file_id, exc_info=True)

        summary["resumed"] += 1
        _dispatch(
            _reingest(
                agent_id=record.get("agent_id") or "",
                user_id=record.get("user_id") or "",
                file_id=file_id,
                credential_id=credential_id,
                record=record,
            )
        )

    logger.info(
        "Interrupted attachment sweep: %d claimed, %d resumed, %d unrecoverable",
        summary["claimed"], summary["resumed"], summary["unrecoverable"],
    )
    return summary


# ---------------------------------------------------------------------------
# Files and URLs
# ---------------------------------------------------------------------------

async def list_attachments(agent_id: str, user_id: str) -> Dict[str, Any]:
    """List an agent's attached files and URLs with their current state."""
    definition = await load_definition(agent_id, user_id)

    async with get_db_session() as db:
        rows = await _files.list_for_agent(db, agent_id, user_id)

    return {
        "agent_id": definition.get("agent_id"),
        "connector_settings": definition.get("connector_settings", {"enabled": False}),
        "files": [row.to_dict() for row in rows],
        "count": len(rows),
    }


async def attach_files(
    agent_id: str,
    user_id: str,
    uploads: Sequence[Tuple[str, bytes, Optional[str]]],
) -> Dict[str, Any]:
    """
    Attach one or more uploaded files to an agent.

    WHAT: Validates the gate, deduplicates by content, creates a pending row per
          file, mirrors identity into the definition, and dispatches conversion.
    WHY:  Spec section 6.1: uploading is a manual, gated, user action, and the
          gate is re-validated here because a client's disabled state is not an
          enforcement point.
    OUTPUT: One entry per upload with its ``file_id`` and starting status, so a
            client can poll. Identical content already attached is returned as
            it stands rather than converted twice.
    RAISES: ``AgentSettingsDisabled`` when the toggle is off, ``AgentNotFound``
            when the agent is not the user's.
    """
    definition = await _require_gate(agent_id, user_id)
    credential_id = definition.get("credential_id")

    from apps.markitdown import config as md_config
    from apps.markitdown import guards as markitdown_guards

    # The original is written with the row, before conversion starts, not with
    # the conversion result. Conversion runs in this process; a restart between
    # the two would otherwise leave a row that can never be completed and whose
    # bytes exist nowhere, so the only recovery would be asking the user to
    # upload the same file again.
    keep_original = md_config.keep_originals()

    accepted: List[Dict[str, Any]] = []
    pending: List[Any] = []

    for filename, payload, mime_type in uploads:
        name = markitdown_guards.safe_filename(filename)
        content_hash = markitdown_guards.content_hash(payload)

        async with get_db_session() as db:
            duplicate = await _files.find_by_hash(db, agent_id, content_hash)
            if duplicate is not None:
                logger.info("'%s' is already attached to agent '%s'", name, agent_id)
                accepted.append({**duplicate.to_dict(), "deduplicated": True})
                continue

            row = await _files.create(
                db,
                agent_id,
                user_id,
                {
                    "name": name,
                    "source_type": "file",
                    "format": markitdown_guards.extension_of(name).lstrip("."),
                    "mime_type": mime_type,
                    "size_bytes": len(payload),
                    "content_hash": content_hash,
                    "status": STATUS_PENDING,
                    "content_bytes": payload if keep_original else None,
                },
            )

        if row is None:
            continue

        entry = row.to_definition_entry()
        await _mirror_into_definition(agent_id, user_id, entry)
        accepted.append(row.to_dict())
        pending.append(
            _run_ingest(
                agent_id=agent_id,
                user_id=user_id,
                file_id=str(row.id),
                credential_id=credential_id,
                payload=payload,
                filename=name,
                mime_type=mime_type,
            )
        )

    for coro in pending:
        _dispatch(coro)

    return {"agent_id": agent_id, "files": accepted, "count": len(accepted)}


async def attach_url(
    agent_id: str,
    user_id: str,
    *,
    url: str,
    name: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Attach a web address to an agent.

    The address is validated before anything is stored, so a blocked or
    malformed URL is refused immediately rather than as a failed attachment the
    user has to clean up. Fetching itself happens in the background.
    """
    from apps.markitdown.fetcher import validate_url

    definition = await _require_gate(agent_id, user_id)
    credential_id = definition.get("credential_id")

    # Raises BlockedUrlError, which the route maps to 422.
    normalized = validate_url(url)

    async with get_db_session() as db:
        rows = await _files.list_for_agent(db, agent_id, user_id)
        for row in rows:
            if row.url and row.url == normalized:
                logger.info("URL already attached to agent '%s'", agent_id)
                return {**row.to_dict(), "deduplicated": True}

        row = await _files.create(
            db,
            agent_id,
            user_id,
            {
                "name": (name or normalized)[:512],
                "source_type": "url",
                "url": normalized,
                "format": "url",
                "status": STATUS_PENDING,
            },
        )

    if row is None:
        raise AgentNotFound(f"Agent '{agent_id}' not found")

    await _mirror_into_definition(agent_id, user_id, row.to_definition_entry())
    _dispatch(
        _run_ingest(
            agent_id=agent_id,
            user_id=user_id,
            file_id=str(row.id),
            credential_id=credential_id,
            url=normalized,
            display_name=name,
        )
    )

    return row.to_dict()


async def detach(agent_id: str, user_id: str, file_id: str) -> Dict[str, Any]:
    """
    Remove one attachment.

    Permitted while the gate is off: turning the capability off must never trap
    an attachment the user wants gone. The row goes, and its passages go with it
    through the foreign key cascade — nothing is left to be filtered out later.
    """
    async with get_db_session() as db:
        row = await _files.get(db, file_id, user_id)
        # Scoped by user at the query and by agent here: an attachment id from
        # one agent must not be removable through another agent's URL.
        if row is None or str(row.agent_id) != str(agent_id):
            raise AttachmentNotFound(f"Attachment '{file_id}' is not attached to this agent")

        await _files.delete(db, file_id, user_id)

    await _remove_from_definition(agent_id, user_id, file_id)

    logger.info("Detached attachment '%s' from agent '%s'", file_id, agent_id)
    return {"agent_id": agent_id, "file_id": file_id, "detached": True}


async def refresh(agent_id: str, user_id: str, file_id: str) -> Dict[str, Any]:
    """
    Convert and embed one attachment again.

    A URL is re-fetched, so a changed page is picked up. A file is re-read from
    the bytes stored on its row, so a newly-configured vision model is applied
    without asking the user to upload it again — which is why the original is
    kept at all.
    """
    definition = await _require_gate(agent_id, user_id)

    async with get_db_session() as db:
        row = await _files.get(db, file_id, user_id)
        if row is None or str(row.agent_id) != str(agent_id):
            raise AttachmentNotFound(f"Attachment '{file_id}' is not attached to this agent")
        record = await _files.get_content(db, file_id, user_id)
        await _files.update_fields(
            db, file_id, {"status": STATUS_PENDING, "error_message": None}
        )

    _dispatch(
        _reingest(
            agent_id=agent_id,
            user_id=user_id,
            file_id=file_id,
            credential_id=definition.get("credential_id"),
            record=record,
        )
    )

    return {"agent_id": agent_id, "file_id": file_id, "status": STATUS_PENDING}


async def _reingest(
    *,
    agent_id: str,
    user_id: str,
    file_id: str,
    credential_id: Optional[str],
    record: Dict[str, Any],
) -> None:
    """Background half of :func:`refresh`."""
    from apps.markitdown import reingest

    async with get_db_session() as db:
        await _files.update_fields(db, file_id, {"status": STATUS_PROCESSING})

    try:
        result = await asyncio.to_thread(
            reingest,
            record=record or {},
            user_id=user_id,
            credential_id=credential_id,
        )
        await _persist(agent_id, file_id, result)
    except Exception as exc:
        logger.error("Refresh failed for attachment '%s'", file_id, exc_info=True)
        async with get_db_session() as db:
            await _files.update_fields(
                db,
                file_id,
                {
                    "status": STATUS_FAILED,
                    "error_message": f"This source could not be refreshed: {exc}",
                },
            )


# ---------------------------------------------------------------------------
# Knowledge bases
# ---------------------------------------------------------------------------

async def list_available_knowledge_bases(user_id: str) -> Dict[str, Any]:
    """Every knowledge base this user could link, for the picker."""
    from echolib.repositories.knowledge_repo import KnowledgeBaseRepository

    async with get_db_session() as db:
        bases = await KnowledgeBaseRepository().list_by_user(db, user_id, limit=200)
        return {
            "knowledge_bases": [
                {
                    "knowledge_base_id": str(kb.id),
                    "name": kb.name,
                    "description": kb.description or "",
                    "status": kb.status,
                    "document_count": len(kb.documents) if kb.documents else 0,
                    "processing_type": kb.processing_type,
                }
                for kb in bases
            ]
        }


async def list_knowledge_bases(agent_id: str, user_id: str) -> Dict[str, Any]:
    """The knowledge bases linked to an agent."""
    definition = await load_definition(agent_id, user_id)

    async with get_db_session() as db:
        rows = await _links.list_for_agent(db, agent_id)

    return {
        "agent_id": definition.get("agent_id"),
        "connector_settings": definition.get("connector_settings", {"enabled": False}),
        "knowledge_bases": [row.to_dict() for row in rows],
        "count": len(rows),
    }


async def link_knowledge_base(
    agent_id: str,
    user_id: str,
    *,
    knowledge_base_id: str,
    alias: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Link an existing knowledge base to an agent, idempotently.

    Read-only from the agent's side: linking exposes the base for retrieval and
    never modifies it. Ownership is checked against the user, so an agent cannot
    be pointed at another tenant's knowledge.
    """
    from echolib.repositories.knowledge_repo import KnowledgeBaseRepository

    await _require_gate(agent_id, user_id)

    async with get_db_session() as db:
        kb = await KnowledgeBaseRepository().get_by_id(db, knowledge_base_id, user_id)
        if kb is None:
            raise KnowledgeBaseNotFound(
                f"Knowledge base '{knowledge_base_id}' was not found for this user"
            )
        await _links.link(db, agent_id, knowledge_base_id, alias or kb.name)

    await _mirror_knowledge_sources(agent_id, user_id)
    logger.info("Linked knowledge base '%s' to agent '%s'", knowledge_base_id, agent_id)

    return {
        "agent_id": agent_id,
        "knowledge_base_id": knowledge_base_id,
        "alias": alias or kb.name,
        "linked": True,
    }


async def unlink_knowledge_base(
    agent_id: str, user_id: str, knowledge_base_id: str
) -> Dict[str, Any]:
    """Remove one knowledge base link. Permitted while the gate is off."""
    await load_definition(agent_id, user_id)

    async with get_db_session() as db:
        removed = await _links.unlink(db, agent_id, knowledge_base_id)

    if not removed:
        raise KnowledgeBaseNotFound(
            f"Knowledge base '{knowledge_base_id}' is not linked to this agent"
        )

    await _mirror_knowledge_sources(agent_id, user_id)
    return {
        "agent_id": agent_id,
        "knowledge_base_id": knowledge_base_id,
        "unlinked": True,
    }


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------
#
# Deleting an agent is a soft delete (``agents.is_deleted``), and the name
# collision path in ``agent_repo.upsert`` revives a soft-deleted row, so an
# agent can come back. Its attachments are therefore *not* purged on delete --
# a restored agent keeps the documents it was configured with, which is the
# behaviour a user expects.
#
# Because everything is in Postgres, a hard delete needs no cleanup code at all:
# ``agent_files`` and ``agent_file_chunks`` both cascade from
# ``agents.agent_id``, so removing the agent row removes its documents and
# their passages in the same statement. Nothing is left on any disk.


async def backend_status(user_id: Optional[str] = None) -> Dict[str, Any]:
    """What the document layer can do on this instance right now."""
    from apps.markitdown import backend_status as status

    return await asyncio.to_thread(status, user_id)


__all__ = [
    "STATUS_FAILED",
    "STATUS_PENDING",
    "STATUS_PROCESSING",
    "STATUS_READY",
    "AgentNotFound",
    "AgentSettingsDisabled",
    "AttachmentNotFound",
    "GATE_MESSAGE",
    "KnowledgeBaseNotFound",
    "attach_files",
    "attach_url",
    "backend_status",
    "detach",
    "link_knowledge_base",
    "list_attachments",
    "list_available_knowledge_bases",
    "list_knowledge_bases",
    "recover_interrupted_ingests",
    "refresh",
    "unlink_knowledge_base",
]
