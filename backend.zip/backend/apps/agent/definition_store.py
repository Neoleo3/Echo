"""
Reading and writing one agent's definition, for the attachment endpoints.

WHAT: ``load_definition`` / ``save_definition`` plus the two errors every
      attachment surface raises, and the Connector Settings gate message.
WHY:  Connectors (Phase 5b) and attached documents (Phase 6) both need to read
      an agent, modify one field and write it back through the Phase 1
      contract. Without a shared home the second one would either duplicate the
      dual-store write or import it from the connector module, where it does
      not belong.

Writes go through the same two stores every other agent write uses -- the
filesystem registry (unless ``AGENT_DB_WRITE_ONLY``) and ``AgentRepository``,
which normalizes through the contract.
"""
from __future__ import annotations

import copy
import logging
from typing import Any, Dict

from echolib.agent_contract import normalize_agent_definition
from echolib.config import settings as _settings
from echolib.di import container

logger = logging.getLogger(__name__)


class AgentNotFound(LookupError):
    """The agent does not exist for this user."""


class AgentSettingsDisabled(PermissionError):
    """
    Connector Settings is off for this agent, so nothing may be attached.

    One switch governs both connectors and uploads. Spec section 6.1: "a user
    can only upload a file or attach a connector after explicitly toggling
    Connector Settings on for that specific agent."
    """


GATE_MESSAGE = (
    "Connector Settings is off for this agent. Turn it on before attaching a "
    "connector or uploading a document."
)


async def load_definition(agent_id: str, user_id: str) -> Dict[str, Any]:
    """Read an agent definition, DB-first, raising when it does not exist."""
    registry = container.resolve("agent.registry")
    definition = await registry.get_agent_from_db(agent_id, user_id)
    if not definition:
        raise AgentNotFound(f"Agent '{agent_id}' not found")
    return normalize_agent_definition(definition)


async def save_definition(
    agent_id: str, user_id: str, definition: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Persist a modified definition to both stores.

    The database write is authoritative and is allowed to raise: an attachment
    that is not persisted must not be reported as successful. The filesystem
    write mirrors the existing update path and is skipped under
    ``AGENT_DB_WRITE_ONLY``.
    """
    from echolib.database import get_db_session
    from echolib.id_utils import normalize_to_uuid
    from echolib.repositories.agent_repo import AgentRepository

    if not _settings.AGENT_DB_WRITE_ONLY:
        try:
            registry = container.resolve("agent.registry")
            registry.update_agent(agent_id, definition)
        except Exception:
            logger.warning(
                "Filesystem registry update failed for agent '%s'", agent_id, exc_info=True
            )

    payload = copy.deepcopy(definition)
    payload["agent_id"] = normalize_to_uuid(payload.get("agent_id") or agent_id)

    async with get_db_session() as db:
        await AgentRepository().upsert(db, user_id, payload)

    return definition


__all__ = [
    "GATE_MESSAGE",
    "AgentNotFound",
    "AgentSettingsDisabled",
    "load_definition",
    "save_definition",
]
