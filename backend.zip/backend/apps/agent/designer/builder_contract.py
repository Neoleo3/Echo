"""
Deterministic Agent Builder v2 event contract and transition guards.

This module is intentionally framework-agnostic so routes and services can
reuse the same transition logic during rollout.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple


BUILDER_EVENT_TYPES = (
    "agent_draft_created",
    "agent_draft_updated",
    "similar_agent_suggested",
    "tool_added",
    "tool_removed",
    "tool_already_selected",
    "tool_not_selected",
    "tool_not_found",
    "clarification_requested",
    "no_tools_confirmed",
    "save_blocked",
    "agent_saved",
    "error_recoverable",
)

BUILDER_STATES = (
    "EMPTY",
    "DRAFT_CREATED",
    "DRAFT_REVIEW",
    "TOOL_SELECTION",
    "READY_TO_SAVE",
    "SAVED",
    "SIMILAR_AGENT_SUGGESTED",
    "CLARIFICATION_REQUIRED",
    "SAVE_BLOCKED",
    "ERROR_RECOVERABLE",
)

# Mandatory transition policy for deterministic builder flow.
LEGAL_TRANSITIONS: Dict[str, Tuple[str, ...]] = {
    # Generation may ask a question on the very first turn: the draft exists
    # and is complete, and the question refines it rather than gating it.
    "EMPTY": ("DRAFT_CREATED", "CLARIFICATION_REQUIRED", "ERROR_RECOVERABLE"),
    "DRAFT_CREATED": (
        "DRAFT_REVIEW",
        "TOOL_SELECTION",
        "CLARIFICATION_REQUIRED",
        "SIMILAR_AGENT_SUGGESTED",
        "ERROR_RECOVERABLE",
    ),
    "DRAFT_REVIEW": (
        "DRAFT_REVIEW",
        "TOOL_SELECTION",
        "CLARIFICATION_REQUIRED",
        "SIMILAR_AGENT_SUGGESTED",
        "READY_TO_SAVE",
        "SAVE_BLOCKED",
        "ERROR_RECOVERABLE",
    ),
    "TOOL_SELECTION": (
        "TOOL_SELECTION",
        "DRAFT_REVIEW",
        "CLARIFICATION_REQUIRED",
        "READY_TO_SAVE",
        "SAVE_BLOCKED",
        "ERROR_RECOVERABLE",
    ),
    "CLARIFICATION_REQUIRED": (
        # Answering a clarification re-designs the draft, which lands back on
        # DRAFT_CREATED before name confirmation.
        "DRAFT_CREATED",
        "DRAFT_REVIEW",
        "TOOL_SELECTION",
        "CLARIFICATION_REQUIRED",
        "ERROR_RECOVERABLE",
    ),
    "SIMILAR_AGENT_SUGGESTED": (
        "SIMILAR_AGENT_SUGGESTED",
        "DRAFT_REVIEW",
        "TOOL_SELECTION",
        "ERROR_RECOVERABLE",
    ),
    "READY_TO_SAVE": ("READY_TO_SAVE", "SAVED", "SAVE_BLOCKED", "ERROR_RECOVERABLE"),
    "SAVE_BLOCKED": ("DRAFT_REVIEW", "TOOL_SELECTION", "READY_TO_SAVE", "ERROR_RECOVERABLE"),
    "SAVED": ("SAVED", "DRAFT_REVIEW", "TOOL_SELECTION", "ERROR_RECOVERABLE"),
    "ERROR_RECOVERABLE": (
        "DRAFT_CREATED",
        "DRAFT_REVIEW",
        "TOOL_SELECTION",
        "CLARIFICATION_REQUIRED",
        "SIMILAR_AGENT_SUGGESTED",
        "READY_TO_SAVE",
        "SAVE_BLOCKED",
        "ERROR_RECOVERABLE",
    ),
}

# Tool mutations must never auto-transition to ready/saved.
_FORBIDDEN_TOOL_TARGET_STATES = {"READY_TO_SAVE", "SAVED"}
_TOOL_MUTATION_ACTIONS = {
    "TOOLS_ADDED",
    "TOOLS_REMOVED",
    "TOOL_AUTO_CREATED",
    "TOOL_ALREADY_SELECTED",
    "TOOL_NOT_SELECTED",
    "TOOL_NOT_FOUND",
}


def normalize_step_to_state(step: str) -> str:
    s = (step or "").lower().strip()
    if s == "initial":
        return "EMPTY"
    if s == "clarify":
        return "CLARIFICATION_REQUIRED"
    if s == "name":
        return "DRAFT_CREATED"
    if s == "refine":
        return "DRAFT_REVIEW"
    if s == "done":
        return "READY_TO_SAVE"
    return "ERROR_RECOVERABLE"


def action_to_event_type(action: str) -> str:
    action_u = (action or "").upper().strip()
    if action_u == "AGENT_DESIGNED":
        return "agent_draft_created"
    if action_u in {"TOOLS_ADDED", "TOOL_AUTO_CREATED"}:
        return "tool_added"
    if action_u == "TOOLS_REMOVED":
        return "tool_removed"
    if action_u == "TOOL_ALREADY_SELECTED":
        return "tool_already_selected"
    if action_u == "TOOL_NOT_SELECTED":
        return "tool_not_selected"
    if action_u == "TOOL_NOT_FOUND":
        return "tool_not_found"
    if action_u == "CONFIRM_NO_TOOLS_REQUIRED":
        return "no_tools_confirmed"
    if action_u in {
        "CLARIFICATION",
        "CLARIFICATION_NEEDED",
        "TOOLS_PROMPT",
        "TOOLS_LISTED",
        "TOOL_SELECT_PROMPT",
        "TOOL_CREATE_GUIDANCE",
        "NO_TOOLS_CONFIRMATION_REQUIRED",
    }:
        return "clarification_requested"
    if action_u == "AGENT_EXISTS":
        return "similar_agent_suggested"
    if action_u == "FINALIZED":
        return "agent_draft_updated"
    if action_u == "SAVE_BLOCKED":
        return "save_blocked"
    if action_u in {"ERROR", "DESIGN_FALLBACK"}:
        return "error_recoverable"
    if action_u == "SAVED":
        return "agent_saved"
    return "agent_draft_updated"


def result_to_target_state(result: Dict[str, Any]) -> str:
    action_u = (result.get("action") or "").upper().strip()
    step = (result.get("step") or "").lower().strip()

    if action_u == "AGENT_DESIGNED":
        return "DRAFT_CREATED"
    if action_u in {"NAME_CONFIRMED", "NAME_UPDATED", "INSTRUCTIONS_UPDATED", "REOPEN_REFINE"}:
        return "DRAFT_REVIEW"
    if action_u in {
        "TOOLS_ADDED",
        "TOOLS_REMOVED",
        "TOOL_AUTO_CREATED",
        "TOOL_ALREADY_SELECTED",
        "TOOL_NOT_SELECTED",
        "TOOL_NOT_FOUND",
        "TOOLS_LISTED",
        "TOOLS_PROMPT",
        "TOOL_SELECT_PROMPT",
        "TOOL_CREATE_GUIDANCE",
    }:
        return "TOOL_SELECTION"
    if action_u in {"CONFIRM_NO_TOOLS_REQUIRED", "NO_TOOLS_CONFIRMATION_REQUIRED"}:
        return "DRAFT_REVIEW"
    if action_u == "FINALIZED" or step == "done":
        return "READY_TO_SAVE"
    if action_u == "SAVE_BLOCKED":
        return "SAVE_BLOCKED"
    if action_u == "AGENT_EXISTS":
        return "SIMILAR_AGENT_SUGGESTED"
    if action_u in {"CLARIFICATION", "CLARIFICATION_NEEDED"}:
        return "CLARIFICATION_REQUIRED"
    if action_u in {"ERROR", "DESIGN_FALLBACK"}:
        return "ERROR_RECOVERABLE"
    return normalize_step_to_state(step)


def is_legal_transition(from_state: str, to_state: str, action: str) -> bool:
    if from_state not in LEGAL_TRANSITIONS:
        return False

    action_u = (action or "").upper().strip()
    if action_u in _TOOL_MUTATION_ACTIONS and to_state in _FORBIDDEN_TOOL_TARGET_STATES:
        return False

    return to_state in LEGAL_TRANSITIONS[from_state]


def illegal_transition_reason(from_state: str, to_state: str, action: str) -> str:
    action_u = (action or "").upper().strip()
    if action_u in _TOOL_MUTATION_ACTIONS and to_state in _FORBIDDEN_TOOL_TARGET_STATES:
        return "Tool mutation events cannot transition to READY_TO_SAVE or SAVED"
    if from_state not in LEGAL_TRANSITIONS:
        return f"Unknown source state: {from_state}"
    return f"Transition {from_state} -> {to_state} is not allowed"


def build_event_envelope(
    *,
    result: Dict[str, Any],
    from_step: str,
    draft_id: str,
) -> Dict[str, Any]:
    from_state = normalize_step_to_state(from_step)
    to_state = result_to_target_state(result)
    action = result.get("action", "")
    legal = is_legal_transition(from_state, to_state, action)

    event = {
        "event_type": action_to_event_type(action),
        "draft_id": draft_id,
        "state_from": from_state,
        "state_to": to_state,
        "legal_transition": legal,
        "action": action,
        "message": result.get("reply", ""),
        "next_actions": _derive_next_actions(to_state),
        "warnings": [],
    }

    if not legal:
        event["warnings"].append(illegal_transition_reason(from_state, to_state, action))

    return event


def _derive_next_actions(state: str) -> List[str]:
    if state == "DRAFT_CREATED":
        return ["confirm_name", "rename_agent", "refine_agent"]
    if state in {"DRAFT_REVIEW", "TOOL_SELECTION", "CLARIFICATION_REQUIRED", "SIMILAR_AGENT_SUGGESTED"}:
        return [
            "refine_agent",
            "add_tool",
            "remove_tool",
            "ask_clarification",
            "confirm_no_tools_required",
            "finalize",
        ]
    if state == "READY_TO_SAVE":
        return ["review_configure_tab", "save_agent", "reopen_refine"]
    if state == "SAVE_BLOCKED":
        return ["fill_required_fields", "revalidate", "reopen_refine"]
    if state == "SAVED":
        return ["open_agent", "reopen_refine"]
    if state == "ERROR_RECOVERABLE":
        return ["retry", "reopen_refine", "restart"]
    return ["restart"]


def sample_event_payloads() -> Dict[str, Dict[str, Any]]:
    base = {
        "draft_id": "draft_123",
        "state_from": "DRAFT_REVIEW",
        "state_to": "DRAFT_REVIEW",
        "legal_transition": True,
        "action": "INSTRUCTIONS_UPDATED",
        "message": "Sample message",
        "next_actions": ["refine_agent"],
        "warnings": [],
    }

    return {
        "agent_draft_created": {
            **base,
            "event_type": "agent_draft_created",
            "state_from": "EMPTY",
            "state_to": "DRAFT_CREATED",
            "action": "AGENT_DESIGNED",
        },
        "agent_draft_updated": {
            **base,
            "event_type": "agent_draft_updated",
        },
        "similar_agent_suggested": {
            **base,
            "event_type": "similar_agent_suggested",
            "state_to": "SIMILAR_AGENT_SUGGESTED",
            "action": "AGENT_EXISTS",
        },
        "tool_added": {
            **base,
            "event_type": "tool_added",
            "state_to": "TOOL_SELECTION",
            "action": "TOOLS_ADDED",
        },
        "tool_removed": {
            **base,
            "event_type": "tool_removed",
            "state_to": "TOOL_SELECTION",
            "action": "TOOLS_REMOVED",
        },
        "clarification_requested": {
            **base,
            "event_type": "clarification_requested",
            "state_to": "CLARIFICATION_REQUIRED",
            "action": "CLARIFICATION",
        },
        "save_blocked": {
            **base,
            "event_type": "save_blocked",
            "state_to": "SAVE_BLOCKED",
            "action": "SAVE_BLOCKED",
            "message": "Please complete required fields before saving.",
            "next_actions": ["fill_required_fields", "revalidate"],
        },
        "agent_saved": {
            **base,
            "event_type": "agent_saved",
            "state_from": "READY_TO_SAVE",
            "state_to": "SAVED",
            "action": "SAVED",
        },
        "error_recoverable": {
            **base,
            "event_type": "error_recoverable",
            "state_to": "ERROR_RECOVERABLE",
            "action": "ERROR",
            "warnings": ["Recoverable error detected"],
            "next_actions": ["retry", "restart"],
        },
    }
