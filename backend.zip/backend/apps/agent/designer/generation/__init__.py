"""
Prompt-based agent generation — specification section 7.

Replaces freeform-completion-then-scrape with a schema-constrained call:

    schema.py          the generation payload (section 7.5)
    system_prompt.py   the generation rules (section 7.4) plus enterprise
                       agent-designer behaviour
    generator.py       the constrained invocation, with a JSON-mode fallback
    mapper.py          projection onto what the platform persists (section 7.3)
"""

from .generator import AgentGenerationError, generate_agent_config
from .mapper import (
    config_to_spec,
    design_metadata,
    format_clarifying_questions,
    resolve_catalog_tools,
)
from .schema import GeneratedAgentConfig
from .system_prompt import CREATE_MODE, UPDATE_MODE

__all__ = [
    "CREATE_MODE",
    "UPDATE_MODE",
    "AgentGenerationError",
    "GeneratedAgentConfig",
    "config_to_spec",
    "design_metadata",
    "format_clarifying_questions",
    "generate_agent_config",
    "resolve_catalog_tools",
]
