"""
Projection of the generation payload onto what the platform persists.

Specification section 7.3: the generation payload is not what is persisted and
not what is rendered. This module performs the translation — the eight-plus
instruction parts collapse into the single ``instructions`` string, capability
suggestions resolve against the real action catalog, and everything that
describes the agent rather than instructing it moves to ``metadata``.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from echolib.agent_contract import concat_instructions
from echolib.agent_naming import derive_fallback_name, normalize_agent_name

from .schema import GeneratedAgentConfig

# The designer has always capped auto-selection at three tools; unchanged here.
MAX_SUGGESTED_TOOLS = 3

MAX_DESCRIPTION_CHARS = 500


def _first_sentence(text: str, limit: int = MAX_DESCRIPTION_CHARS) -> str:
    """Return the first sentence of a block, bounded by ``limit``."""
    cleaned = " ".join((text or "").split())
    if not cleaned:
        return ""
    for terminator in (". ", "! ", "? "):
        head, sep, _ = cleaned.partition(terminator)
        if sep:
            return (head + terminator.strip())[:limit]
    return cleaned[:limit]


def config_to_spec(
    config: GeneratedAgentConfig,
    *,
    user_prompt: str,
) -> Dict[str, Any]:
    """
    Convert a generation payload into the designer's agent spec.

    Args:
        config: Validated generation payload.
        user_prompt: The builder's original description, used only for
            deterministic fallbacks when the model left a field empty.

    Returns:
        Spec dict consumed by ``AgentDesigner.design_from_prompt_with_diagnostics``.
    """
    instructions = concat_instructions(config.instructions.model_dump())

    description = " ".join((config.description or "").split())
    if not description:
        description = _first_sentence(config.instructions.purpose) or user_prompt[:200]

    name = normalize_agent_name(
        config.agent_name,
        fallback=derive_fallback_name(user_prompt),
    )

    return {
        "name": name,
        "description": description[:MAX_DESCRIPTION_CHARS],
        "instructions": instructions,
        "required_inputs": [item.model_dump() for item in config.required_inputs],
        "input_schema": list(config.input_schema),
        "output_schema": list(config.output_schema),
        "suggested_tools": [item.model_dump() for item in config.suggested_tools],
        "suggested_knowledge_sources": [
            item.model_dump() for item in config.suggested_knowledge_sources
        ],
        "clarifying_questions": [
            item.model_dump() for item in config.clarifying_questions
        ],
        "assumptions": [item.model_dump() for item in config.assumptions],
        "changed_fields": [item.model_dump() for item in config.changed_fields],
        "low_confidence_fields": list(config.low_confidence_fields),
        "trigger_conditions": list(config.trigger_conditions),
        "success_criteria": list(config.success_criteria),
        "example_requests": list(config.example_requests),
        "example_responses": list(config.example_responses),
        "future_extensibility": list(config.future_extensibility),
    }


def design_metadata(spec: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build the design-time metadata block for a generated agent.

    These describe the agent rather than instruct it, so they stay out of the
    runtime system prompt and out of the user-facing surface (section 6).

    Args:
        spec: Output of :func:`config_to_spec`.

    Returns:
        Metadata keys to merge onto the agent definition's ``metadata``.
    """
    metadata: Dict[str, Any] = {}

    for source_key, target_key in (
        ("example_requests", "starter_prompts"),
        ("example_responses", "example_responses"),
        ("future_extensibility", "future_extensibility"),
        ("trigger_conditions", "trigger_conditions"),
        ("success_criteria", "success_criteria"),
        ("assumptions", "assumptions"),
        ("low_confidence_fields", "low_confidence_fields"),
        ("suggested_knowledge_sources", "suggested_knowledge_sources"),
        ("suggested_tools", "suggested_tools"),
    ):
        value = spec.get(source_key)
        if value:
            metadata[target_key] = value

    return metadata


def resolve_catalog_tools(
    spec: Dict[str, Any],
    catalog: Optional[Sequence[Dict[str, Any]]],
    *,
    limit: int = MAX_SUGGESTED_TOOLS,
) -> List[str]:
    """
    Resolve suggested capabilities to real tool ids.

    Rule 5: a suggestion is a capability, not an invented integration name. Any
    id the model produced that is not in the catalog is discarded rather than
    trusted, and a suggestion whose label matches a catalog entry is honoured
    even when the model declined to guess an id.

    Args:
        spec: Output of :func:`config_to_spec`.
        catalog: Tools from ``AgentDesigner.get_available_tools()["tools"]``.
        limit: Maximum tools to return.

    Returns:
        Catalog tool ids, order preserved, de-duplicated.
    """
    suggestions = spec.get("suggested_tools") or []
    if not suggestions or not catalog:
        return []

    by_id: Dict[str, str] = {}
    by_name: Dict[str, str] = {}
    for tool in catalog:
        if not isinstance(tool, dict):
            continue
        tool_id = str(tool.get("tool_id") or "").strip()
        if not tool_id:
            continue
        by_id[tool_id] = tool_id
        name = str(tool.get("name") or "").strip().lower()
        if name:
            by_name.setdefault(name, tool_id)

    resolved: List[str] = []
    for suggestion in suggestions:
        if not isinstance(suggestion, dict):
            continue

        candidate = str(suggestion.get("matched_catalog_action_id") or "").strip()
        tool_id = by_id.get(candidate)

        if not tool_id:
            label = str(suggestion.get("label") or "").strip().lower()
            tool_id = by_name.get(label) or by_id.get(label)

        if tool_id and tool_id not in resolved:
            resolved.append(tool_id)
        if len(resolved) >= limit:
            break

    return resolved


def format_clarifying_questions(spec: Dict[str, Any]) -> str:
    """
    Render clarifying questions as chat text.

    One question is the norm. When two survive the schema cap they are
    numbered, because a builder answering a wall of questions is the failure
    mode this whole flow exists to avoid.

    Args:
        spec: Output of :func:`config_to_spec`.

    Returns:
        Chat-ready text, or an empty string when nothing needs asking.
    """
    questions = spec.get("clarifying_questions") or []
    if not questions:
        return ""

    lines: List[str] = []
    numbered = len(questions) > 1

    for index, item in enumerate(questions, start=1):
        if not isinstance(item, dict):
            continue
        question = str(item.get("question") or "").strip()
        if not question:
            continue

        prefix = f"{index}. " if numbered else ""
        lines.append(f"{prefix}{question}")

        options = [str(o).strip() for o in (item.get("options") or []) if str(o).strip()]
        if options:
            lines.append(f"   Options: {', '.join(options)}")

    return "\n".join(lines)


__all__ = [
    "config_to_spec",
    "design_metadata",
    "format_clarifying_questions",
    "resolve_catalog_tools",
]
