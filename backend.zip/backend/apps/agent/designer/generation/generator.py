"""
Schema-constrained invocation of the agent generation model.

Specification section 7.1 identifies freeform-completion-then-regex-scrape as
the root cause of the naming defect ("give name sales insight" producing "Name
Sales Inside"). This module replaces it: the model is called with a JSON schema
it must satisfy, so no parsing step exists on the primary path.

Provider coverage for structured output is not universal, so a JSON-mode
fallback is retained. It is a fallback, never the default, and it validates
against the same schema before returning.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional, Sequence

from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import ValidationError

from .schema import GeneratedAgentConfig
from .system_prompt import (
    CREATE_MODE,
    build_system_prompt,
    build_user_message,
)

logger = logging.getLogger(__name__)


class AgentGenerationError(RuntimeError):
    """Raised when the generation model returns nothing schema-conformant."""


# Fallback path only. The primary path hands the model the real JSON schema.
_JSON_MODE_INSTRUCTION = """
Return ONLY a JSON object with exactly this shape. No markdown, no prose.

{
  "agent_name": "string",
  "description": "string",
  "instructions": {
    "purpose": "string", "business_objective": "string",
    "responsibilities": "string", "behavior": "string",
    "decision_logic": "string", "response_style": "string",
    "reasoning_guidelines": "string", "tool_usage_rules": "string",
    "knowledge_usage_rules": "string", "output_format": "string",
    "limitations": "string", "restrictions": "string",
    "guardrails": "string", "examples": "string"
  },
  "suggested_knowledge_sources": [{"type": "file", "label": "string"}],
  "suggested_tools": [{"label": "string", "matched_catalog_action_id": null}],
  "required_inputs": [{"type": "file", "label": "string", "blocking": true}],
  "input_schema": ["string"], "output_schema": ["string"],
  "trigger_conditions": ["string"], "success_criteria": ["string"],
  "example_requests": ["string"], "example_responses": ["string"],
  "future_extensibility": ["string"],
  "assumptions": [{"field": "string", "assumption": "string"}],
  "clarifying_questions": [{"question": "string", "why_it_matters": "string", "options": ["string"]}],
  "changed_fields": [{"path": "string", "reason": "string"}],
  "low_confidence_fields": ["string"]
}
"""


def _extract_json_object(content: str) -> Dict[str, Any]:
    """
    Recover a JSON object from a text completion.

    Fallback path only — reached when the provider cannot constrain its own
    output. Raises rather than guessing when nothing parses.
    """
    candidate = (content or "").strip()

    if "```json" in candidate:
        candidate = candidate.split("```json", 1)[1].split("```", 1)[0].strip()
    elif "```" in candidate:
        candidate = candidate.split("```", 1)[1].split("```", 1)[0].strip()
    else:
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start != -1 and end > start:
            candidate = candidate[start : end + 1]

    try:
        payload = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise AgentGenerationError(
            "Generation model response was not valid JSON"
        ) from exc

    if not isinstance(payload, dict):
        raise AgentGenerationError(
            "Generation model response JSON was not an object"
        )

    return payload


def _invoke(llm, messages, invoke_config: Optional[Dict[str, Any]]):
    """Invoke a model with the optional tracing config attached."""
    if invoke_config:
        return llm.invoke(messages, config=invoke_config)
    return llm.invoke(messages)


def _coerce_result(result: Any) -> GeneratedAgentConfig:
    """Normalize whatever ``with_structured_output`` returned into the model."""
    if isinstance(result, GeneratedAgentConfig):
        return result
    if isinstance(result, dict):
        return GeneratedAgentConfig.model_validate(result)
    if hasattr(result, "model_dump"):
        return GeneratedAgentConfig.model_validate(result.model_dump())
    raise AgentGenerationError(
        f"Generation model returned an unusable result type: {type(result).__name__}"
    )


def generate_agent_config(
    llm,
    *,
    user_prompt: str,
    mode: str = CREATE_MODE,
    existing_config: Optional[Dict[str, Any]] = None,
    history: str = "",
    tool_catalog: Optional[Sequence[Dict[str, Any]]] = None,
    invoke_config: Optional[Dict[str, Any]] = None,
) -> GeneratedAgentConfig:
    """
    Generate or revise an agent configuration under schema constraint.

    Args:
        llm: A LangChain chat model from ``llm_resolver``.
        user_prompt: What the builder just said.
        mode: ``CREATE`` or ``UPDATE``.
        existing_config: Current configuration in UPDATE mode.
        history: Rendered config-chat transcript (specification section 7.2).
        tool_catalog: Platform action catalog for Rule 5 matching.
        invoke_config: Optional tracing config.

    Returns:
        A validated ``GeneratedAgentConfig``.

    Raises:
        AgentGenerationError: When no schema-conformant object could be
            obtained on either the structured or the JSON-mode path.
    """
    system_text = build_system_prompt(mode=mode, tool_catalog=tool_catalog)
    user_text = build_user_message(
        user_prompt=user_prompt,
        existing_config=existing_config,
        history=history,
    )
    messages = [SystemMessage(content=system_text), HumanMessage(content=user_text)]

    try:
        structured_llm = llm.with_structured_output(GeneratedAgentConfig)
        return _coerce_result(_invoke(structured_llm, messages, invoke_config))
    except (NotImplementedError, AttributeError, TypeError) as exc:
        # Provider or wrapper does not support constrained output.
        logger.info(
            "Structured output unavailable for agent generation (%s); "
            "falling back to JSON mode",
            type(exc).__name__,
        )
    except ValidationError as exc:
        raise AgentGenerationError(
            f"Generation model output failed schema validation: {exc}"
        ) from exc

    fallback_messages = [
        SystemMessage(content=f"{system_text}\n{_JSON_MODE_INSTRUCTION}"),
        HumanMessage(content=user_text),
    ]
    response = _invoke(llm, fallback_messages, invoke_config)
    content = response.content if hasattr(response, "content") else str(response)

    try:
        return GeneratedAgentConfig.model_validate(_extract_json_object(content))
    except ValidationError as exc:
        raise AgentGenerationError(
            f"Generation model output failed schema validation: {exc}"
        ) from exc


__all__ = ["AgentGenerationError", "generate_agent_config"]
