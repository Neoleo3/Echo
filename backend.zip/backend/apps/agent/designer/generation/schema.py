"""
Generation-time payload for prompt-based agent creation.

Specification section 7.5 defines this schema. It is the *generation* payload,
not the persisted one:

    - Not persisted as-is. The backend concatenates ``instructions.*`` into the
      single ``instructions`` string of the canonical contract (section 5.1).
    - Not rendered as-is. The user only ever sees Description plus one
      Instructions text box (section 6).
    - Only an internal scaffold that makes the model produce complete,
      well-organized instructions.

Field descriptions are part of the contract with the model: they are emitted
into the JSON schema handed to ``with_structured_output``, so they carry the
per-field rules rather than repeating them all in the system prompt.
"""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

# Copilot-style discipline: ask at most one question per turn, two only when a
# second is genuinely blocking. The model is told this; the schema enforces it.
MAX_CLARIFYING_QUESTIONS = 2

KnowledgeSourceType = Literal[
    "file",
    "website",
    "sharepoint",
    "onedrive",
    "database",
    "confluence",
    "jira",
    "custom_connector",
    "vector_store",
]

RequiredInputType = Literal["file", "knowledge_source", "variable"]


class AgentInstructions(BaseModel):
    """
    The instructions scaffold — internal only, never shown section by section.

    Each part is 1-4 sentences and must read correctly both standalone and
    concatenated into one block, because concatenation is exactly what happens
    before anything reaches the user or the database.
    """

    purpose: str = Field(
        default="",
        description="What this agent is for, in one or two sentences.",
    )
    business_objective: str = Field(
        default="",
        description=(
            "The business outcome the agent exists to produce. Derived from "
            "what the user described — never invent a business requirement."
        ),
    )
    responsibilities: str = Field(
        default="",
        description="The agent's primary responsibilities, as a short list.",
    )
    behavior: str = Field(
        default="",
        description="How the agent works through a request, step by step.",
    )
    decision_logic: str = Field(
        default="",
        description=(
            "How the agent decides between options: when to use a tool, when "
            "to consult knowledge, when to ask the user, when to stop."
        ),
    )
    response_style: str = Field(
        default="",
        description="Tone, level of detail, and formatting of replies.",
    )
    reasoning_guidelines: str = Field(
        default="",
        description=(
            "How the agent reasons. MUST include a context-readiness "
            "instruction: recognize when required information is missing and "
            "say so rather than proceeding on assumptions."
        ),
    )
    tool_usage_rules: str = Field(
        default="",
        description=(
            "When and how to call tools. Never reference a tool that is not "
            "in suggested_tools."
        ),
    )
    knowledge_usage_rules: str = Field(
        default="",
        description=(
            "How to use attached knowledge, cite it, and behave when it is "
            "empty or irrelevant."
        ),
    )
    output_format: str = Field(
        default="",
        description="The shape of the agent's output.",
    )
    limitations: str = Field(
        default="",
        description="What this agent is not able to do, stated plainly.",
    )
    restrictions: str = Field(
        default="",
        description=(
            "What the agent must not do. MUST include refusing to proceed "
            "without the information a task requires."
        ),
    )
    guardrails: str = Field(
        default="",
        description=(
            "Safety, privacy, compliance and escalation rules appropriate to "
            "the described work."
        ),
    )
    examples: str = Field(
        default="",
        description=(
            "One or two short worked examples of a request and the shape of "
            "the expected answer."
        ),
    )


class SuggestedKnowledgeSource(BaseModel):
    """A knowledge source the user is advised to attach — never attached here."""

    type: KnowledgeSourceType = Field(default="file")
    label: str = Field(description="Plain-language name of the source.")


class SuggestedTool(BaseModel):
    """A capability the agent needs, matched to the catalog where possible."""

    label: str = Field(
        description="Capability description, e.g. 'Query CRM', 'Send Email'.",
    )
    matched_catalog_action_id: Optional[str] = Field(
        default=None,
        description=(
            "Exact tool_id from the provided catalog when one clearly matches. "
            "Null when nothing matches — never invent an id."
        ),
    )


class RequiredInput(BaseModel):
    """An input without which the agent's task is meaningless."""

    type: RequiredInputType = Field(default="variable")
    label: str = Field(description="What the user must supply.")
    blocking: bool = Field(
        default=True,
        description="True when execution must not proceed without it.",
    )


class Assumption(BaseModel):
    """A default the generator chose because the user did not specify it."""

    field: str = Field(description="Field path the assumption applies to.")
    assumption: str = Field(description="What was assumed, in one line.")


class ClarifyingQuestion(BaseModel):
    """A question asked only when the answer materially changes the agent."""

    question: str = Field(description="One concise question for the builder.")
    why_it_matters: str = Field(
        default="",
        description="One line on what the answer changes.",
    )
    options: List[str] = Field(
        default_factory=list,
        description="Concrete choices when the answer is a selection.",
    )


class ChangedField(BaseModel):
    """One field changed by an UPDATE, with its reason."""

    path: str = Field(description="Field path that differs from the input config.")
    reason: str = Field(description="One-line plain-language reason.")


class GeneratedAgentConfig(BaseModel):
    """The complete generation payload (specification section 7.5)."""

    agent_name: str = Field(
        description=(
            "Title Case, 2-5 words, no trailing punctuation, no quotes. "
            "Plainly descriptive of what the agent does. Never contains the "
            "words 'agent', 'AI' or 'bot' unless the user asked for them, and "
            "never contains the user's command wording."
        ),
    )
    description: str = Field(
        default="",
        description=(
            "One sentence in plain language stating what the agent does for "
            "the user, not how it is built."
        ),
    )
    instructions: AgentInstructions = Field(default_factory=AgentInstructions)

    suggested_knowledge_sources: List[SuggestedKnowledgeSource] = Field(
        default_factory=list,
        description=(
            "Knowledge the agent would need. Suggestions only — this flow "
            "never attaches anything."
        ),
    )
    suggested_tools: List[SuggestedTool] = Field(default_factory=list)
    required_inputs: List[RequiredInput] = Field(
        default_factory=list,
        description=(
            "Inputs without which the task is meaningless. Empty when the "
            "agent can produce a reasonable generic response unaided."
        ),
    )

    # Echo extension beyond section 7.5: the workflow node contract maps an
    # agent's result onto these keys, so a prompt-created agent that omits them
    # loses its output mapping when placed on a canvas.
    input_schema: List[str] = Field(
        default_factory=list,
        description="snake_case keys the agent expects as input.",
    )
    output_schema: List[str] = Field(
        default_factory=list,
        description="snake_case keys the agent produces as output.",
    )

    trigger_conditions: List[str] = Field(
        default_factory=list,
        description="Situations in which this agent should run.",
    )
    success_criteria: List[str] = Field(
        default_factory=list,
        description="Observable conditions that mean the agent did its job.",
    )
    example_requests: List[str] = Field(
        default_factory=list,
        description="Example user requests, usable as starter prompts.",
    )
    example_responses: List[str] = Field(
        default_factory=list,
        description="Short illustrations of the expected answer shape.",
    )
    future_extensibility: List[str] = Field(
        default_factory=list,
        description="Capabilities a builder could add later.",
    )

    assumptions: List[Assumption] = Field(
        default_factory=list,
        description=(
            "Every default chosen in place of information the user did not "
            "give. Nothing may be inferred silently."
        ),
    )
    clarifying_questions: List[ClarifyingQuestion] = Field(
        default_factory=list,
        description=(
            "Only questions whose answers materially change the agent. Empty "
            "whenever a reasonable default exists."
        ),
    )

    changed_fields: List[ChangedField] = Field(
        default_factory=list,
        description="UPDATE mode only: exactly the fields that differ.",
    )
    low_confidence_fields: List[str] = Field(
        default_factory=list,
        description="Field paths the UI should flag for review.",
    )

    @field_validator("clarifying_questions", mode="after")
    @classmethod
    def _cap_questions(
        cls, value: List[ClarifyingQuestion]
    ) -> List[ClarifyingQuestion]:
        """Never overwhelm the builder — the most important question wins."""
        return value[:MAX_CLARIFYING_QUESTIONS]


__all__ = [
    "MAX_CLARIFYING_QUESTIONS",
    "AgentInstructions",
    "Assumption",
    "ChangedField",
    "ClarifyingQuestion",
    "GeneratedAgentConfig",
    "RequiredInput",
    "SuggestedKnowledgeSource",
    "SuggestedTool",
]
