"""
Agent designer service.
Generates agent definitions from natural language prompts using LLM.

LLM Provider Configuration:
---------------------------
This module supports multiple LLM providers. Configure via .env file:
- OPTION 1: Ollama (On-Premise) - Set USE_OLLAMA=true
- OPTION 2: Azure OpenAI (Default) - Set USE_AZURE=true
- OPTION 3: OpenAI Direct - Set USE_OPENAI=true

See .env file for detailed configuration options.
"""

import copy
import json
import logging
import os
import re
from typing import Dict, Any, List, Optional, Sequence, Tuple
from echolib.utils import new_id
from datetime import datetime

from echolib.agent_contract import (
    DEFAULT_MAX_ITERATION,
    DEFAULT_TEMPERATURE,
    DEFAULT_TOP_P,
    append_config_chat,
    get_config_chat,
    render_config_chat,
)
from echolib.agent_naming import derive_fallback_name, normalize_agent_name

from .generation import (
    CREATE_MODE,
    UPDATE_MODE,
    AgentGenerationError,
    config_to_spec,
    design_metadata,
    format_clarifying_questions,
    generate_agent_config,
    resolve_catalog_tools,
)

logger = logging.getLogger(__name__)

# Copilot-style clarification is bounded: after this many question turns the
# builder proceeds on defaults rather than interrogating the user further.
MAX_CLARIFICATION_TURNS = 2

# A change report is a confirmation, not an audit log. Beyond a handful of
# lines the builder stops reading it.
MAX_REPORTED_CHANGES = 4

# Below this, a message that mentions changing something carries no change to
# apply -- "change" alone is a request to be asked what, not an instruction.
MIN_ACTIONABLE_CHANGE_WORDS = 4


# ``AgentDesignResponseParseError`` was removed in Phase 10. It became a
# deprecated alias of ``AgentGenerationError`` in Phase 4 when generation became
# schema-constrained, and nothing has raised it since.


class AgentDesigner:
    """
    Agent designer service.
    Uses LLM to generate agent definitions from natural language prompts.
    """

    # Available tools for auto-selection (must match actual backend tool IDs)
    AVAILABLE_TOOLS = ["tool_web_search", "tool_file_reader", "tool_code_generator", "tool_code_reviewer", "tool_calculator", "tool_convo_bi"]

    # Tool selection rules: keyword patterns -> tool IDs
    # IMPORTANT: Keys must match actual backend tool IDs in apps/storage/tools/
    TOOL_SELECTION_RULES = {
        "tool_web_search": [
            # Research & Information
            "research", "analyze", "analysis", "search", "web", "explore", "investigate",
            "find", "lookup", "browse", "internet", "online", "query", "discover",
            "information", "info", "data", "facts", "knowledge", "learn", "learning",
            # News & Updates
            "news", "trends", "trending", "latest", "current", "today", "recent", "update", "updates",
            # Finance & Business
            "financial", "finance", "stock", "stocks", "market", "markets", "trading", "invest", "investment",
            "report", "reports", "analyst", "advisor", "business", "company", "companies", "startup",
            "crypto", "bitcoin", "cryptocurrency", "forex", "currency", "exchange",
            # Travel & Booking
            "travel", "trip", "trips", "vacation", "holiday", "booking", "book", "reserve",
            "flight", "flights", "airline", "airlines", "airport",
            "hotel", "hotels", "accommodation", "stay", "airbnb", "hostel",
            "reservation", "reservations", "destination", "destinations",
            "tour", "tours", "tourism", "tourist", "sightseeing",
            "itinerary", "ticket", "tickets", "pass", "visa",
            "train", "trains", "railway", "bus", "buses", "car", "cars", "rental", "rentals",
            "transport", "transportation", "commute", "route", "routes", "directions",
            # Shopping & Products
            "shop", "shopping", "buy", "purchase", "price", "prices", "cost", "compare", "comparison",
            "product", "products", "item", "items", "store", "stores", "amazon", "ebay", "deal", "deals",
            "review", "reviews", "rating", "ratings", "recommendation", "recommendations",
            # Food & Dining
            "restaurant", "restaurants", "food", "foods", "menu", "dining", "eat", "eating",
            "recipe", "recipes", "cook", "cooking", "cuisine", "delivery", "takeout",
            # Entertainment
            "movie", "movies", "film", "films", "show", "shows", "tv", "television", "netflix", "stream",
            "music", "song", "songs", "artist", "artists", "album", "concert", "concerts",
            "event", "events", "sports", "game", "games", "match", "score", "scores",
            "video", "videos", "youtube", "watch",
            # Location & Maps
            "location", "locations", "address", "map", "maps", "place", "places", "nearby", "local",
            "weather", "forecast", "temperature", "climate",
            # Health & Medical
            "health", "medical", "doctor", "doctors", "hospital", "hospitals", "clinic",
            "medicine", "medication", "symptom", "symptoms", "treatment", "pharmacy",
            # Education
            "education", "school", "schools", "university", "college", "course", "courses",
            "tutorial", "tutorials", "guide", "guides", "how to", "howto", "learn",
            # Jobs & Career
            "job", "jobs", "career", "careers", "employment", "hire", "hiring", "salary", "salaries",
            "resume", "interview", "work", "remote", "freelance",
            # Real Estate
            "real estate", "property", "properties", "house", "houses", "apartment", "apartments",
            "rent", "renting", "lease", "mortgage", "realtor",
            # Social & Communication
            "social media", "twitter", "facebook", "instagram", "linkedin", "tiktok",
            "people", "person", "contact", "email", "phone",
            # Reference & Knowledge
            "wikipedia", "definition", "meaning", "translate", "translation", "language",
            "book", "books", "author", "article", "articles", "blog", "publication"
        ],
        "tool_file_reader": [
            # Document Types
            "file", "files", "document", "documents", "doc", "docs",
            "pdf", "pdfs", "word", "docx", "txt", "text",
            "markdown", "md", "html", "htm", "rtf",
            # Data Files
            "csv", "excel", "xlsx", "xls", "spreadsheet", "spreadsheets",
            "json", "xml", "yaml", "yml", "ini", "config", "configuration",
            # Actions
            "read", "reading", "parse", "parsing", "extract", "extraction",
            "load", "loading", "import", "importing", "open", "opening",
            "analyze", "scan", "scanning",
            # Content Types
            "content", "contents", "data", "table", "tables", "sheet", "sheets",
            "report", "reports", "invoice", "invoices", "receipt", "receipts",
            "contract", "contracts", "agreement", "agreements",
            "resume", "cv", "letter", "letters", "form", "forms",
            # File Operations
            "attachment", "attachments", "upload", "uploaded", "download",
            "log", "logs", "readme", "license", "changelog",
            # Media (text extraction)
            "image", "images", "photo", "photos", "screenshot", "screenshots",
            "scanned", "ocr", "transcript", "transcription"
        ],
        "tool_code_generator": [
            # Languages
            "code", "coding", "program", "programming", "script", "scripting",
            "python", "javascript", "typescript", "java", "csharp", "c#",
            "cpp", "c++", "golang", "go", "rust", "ruby", "php", "swift", "kotlin",
            "scala", "perl", "bash", "shell", "powershell", "sql",
            "html", "css", "react", "angular", "vue", "node", "nodejs",
            # Actions
            "develop", "developer", "development", "build", "building",
            "create", "creating", "generate", "generating", "write", "writing",
            "implement", "implementation", "execute", "execution", "run", "running",
            "compile", "compiling", "debug", "debugging", "fix", "fixing",
            "refactor", "refactoring", "optimize", "optimization",
            # Concepts
            "software", "application", "app", "apps", "api", "apis",
            "backend", "frontend", "fullstack", "full-stack",
            "function", "functions", "method", "methods", "class", "classes",
            "algorithm", "algorithms", "logic", "module", "modules",
            "library", "libraries", "framework", "frameworks", "sdk",
            "package", "packages", "dependency", "dependencies",
            # Testing
            "test", "tests", "testing", "unittest", "unit test", "pytest", "jest",
            "selenium", "automation", "automate", "automated",
            # Web & API
            "rest", "restful", "graphql", "websocket", "http", "https",
            "endpoint", "endpoints", "route", "routes", "request", "response",
            "authentication", "authorization", "oauth", "jwt", "token",
            # Database
            "database", "databases", "db", "query", "queries",
            "mysql", "postgresql", "postgres", "mongodb", "redis", "sqlite",
            # DevOps & Cloud
            "docker", "kubernetes", "k8s", "container", "containers",
            "aws", "azure", "gcp", "cloud", "serverless", "lambda",
            "deploy", "deployment", "ci", "cd", "pipeline", "jenkins", "github actions",
            "git", "github", "gitlab", "bitbucket", "version control",
            # Data & AI
            "scrape", "scraping", "crawler", "crawling", "bot", "bots",
            "parse", "parser", "parsing", "regex", "regular expression",
            "machine learning", "ml", "ai", "artificial intelligence",
            "data science", "pandas", "numpy", "tensorflow", "pytorch"
        ],
        "tool_code_reviewer": [
            # Core Review
            "review", "reviewer", "reviewing", "code review", "peer review",
            "check", "checking", "inspect", "inspection", "examine", "audit", "auditing",
            # Quality
            "quality", "code quality", "clean code", "best practices", "standards",
            "maintainability", "readability", "documentation", "comments",
            "style", "convention", "conventions", "formatting", "lint", "linting", "linter",
            # Analysis
            "static analysis", "analyze", "analysis", "complexity", "metrics",
            "coverage", "test coverage", "code coverage",
            # Issues
            "bug", "bugs", "issue", "issues", "error", "errors", "problem", "problems",
            "smell", "code smell", "anti-pattern", "antipattern",
            "vulnerability", "vulnerabilities", "flaw", "flaws",
            # Security
            "security", "secure", "insecure", "vulnerability", "exploit",
            "injection", "sql injection", "xss", "csrf", "sanitization", "validation",
            "encryption", "authentication", "authorization",
            # Improvement
            "improve", "improvement", "optimize", "optimization", "refactor", "refactoring",
            "suggestion", "suggestions", "feedback", "recommend", "recommendation",
            # Principles
            "solid", "dry", "kiss", "yagni", "separation of concerns",
            "design pattern", "design patterns", "architecture",
            "technical debt", "legacy", "deprecated", "upgrade", "modernize"
        ],
        "tool_calculator": [
            # Basic Math
            "calculate", "calculation", "calculations", "calculator",
            "math", "mathematics", "mathematical", "compute", "computation",
            "add", "addition", "subtract", "subtraction", "multiply", "multiplication",
            "divide", "division", "sum", "total", "difference", "product", "quotient",
            # Statistics
            "average", "mean", "median", "mode", "statistics", "statistical",
            "percentage", "percent", "ratio", "proportion", "fraction", "decimal",
            "probability", "random", "distribution", "variance", "deviation",
            "min", "minimum", "max", "maximum", "range", "count",
            # Financial
            "financial", "finance", "money", "budget", "budgeting",
            "accounting", "accountant", "bookkeeping",
            "interest", "compound interest", "simple interest", "apr", "apy",
            "loan", "loans", "mortgage", "payment", "payments", "amortization",
            "tax", "taxes", "taxation", "income", "expense", "expenses",
            "profit", "loss", "margin", "markup", "discount",
            "roi", "return", "investment", "yield", "dividend",
            "depreciation", "inflation", "gdp", "growth rate",
            "salary", "wage", "hourly", "annual", "monthly",
            "tip", "gratuity", "split", "bill",
            # Conversions
            "convert", "conversion", "unit", "units", "measurement",
            "distance", "length", "weight", "mass", "volume", "area",
            "temperature", "celsius", "fahrenheit", "kelvin",
            "speed", "velocity", "time", "duration", "age",
            "currency", "exchange rate", "forex",
            # Advanced Math
            "equation", "equations", "formula", "formulas", "solve", "solution",
            "algebra", "geometry", "trigonometry", "calculus",
            "derivative", "integral", "limit",
            "exponent", "power", "logarithm", "log", "root", "square root", "sqrt",
            "factorial", "permutation", "combination",
            "matrix", "vector", "linear algebra",
            "graph", "plot", "chart", "function",
            # Numbers
            "number", "numbers", "numeric", "numerical", "digit", "digits",
            "integer", "float", "round", "rounding", "floor", "ceil", "ceiling",
            "absolute", "abs", "positive", "negative", "sign",
            "prime", "even", "odd", "factor", "factors", "multiple", "gcd", "lcm",
            # Body/Health Calculations
            "bmi", "body mass", "calories", "calorie", "nutrition",
            "heart rate", "pace", "distance", "steps"
        ],
        # ConvoBI Database Query (NLP-to-SQL for any loaded database)
        "tool_convo_bi": [
            # Core Database
            "database", "databases", "db", "query", "queries", "sql",
            "data", "dataset", "datasets", "records", "rows", "columns",
            "table", "tables", "view", "views", "schema",
            # NLP / Natural Language
            "ask", "question", "questions", "natural language", "nlp",
            "convobi", "convo bi", "convo", "bi",
            # Database Actions
            "fetch", "retrieve", "select", "count", "sum", "average",
            "aggregate", "filter", "sort", "group", "join",
            "list", "show", "display", "get",
            # Database Types
            "mssql", "mysql", "postgresql", "postgres", "oracle",
            "sqlite", "bigquery", "snowflake", "clickhouse", "redshift",
            "sql server", "microsoft sql",
            # ITSM / Ticketing (common use case)
            "itsm", "incident", "incidents", "ticket", "tickets",
            "service request", "service requests", "change request",
            "problem", "problems", "sla", "priority", "severity",
            "open tickets", "closed tickets", "pending tickets",
            "summitai", "servicenow", "jira",
            # Business Intelligence
            "report", "reports", "reporting", "analytics", "insight",
            "insights", "dashboard", "metrics", "kpi", "kpis",
            "trend", "trends", "statistics", "stats",
            # Data Exploration
            "how many", "total", "breakdown", "distribution",
            "top", "bottom", "highest", "lowest", "most", "least",
            "compare", "comparison", "over time", "by month", "by year",
            "last week", "last month", "this year",
            # Connection / Configuration
            "connection", "connections", "connect", "database connection",
            "available databases", "list databases",
        ]
    }

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize designer.

        Args:
            api_key: OpenAI API key (optional, reads from env if not provided)
        """
        self._llm_client = None
        self._llm_providers = self._load_llm_providers()

    def _load_llm_providers(self) -> Dict[str, Any]:
        """Load LLM provider configurations from llm_provider.json.

        Supports both legacy flat format (``{"models": [...]}``) and the
        new provider-grouped format (``{"providers": [...]}``).

        For the new format, synthesises a lookup from model name to
        provider slug so that ``design_from_prompt`` can resolve which
        provider a model belongs to.
        """
        provider_file = os.path.join(
            os.path.dirname(__file__), "..", "..", "..", "echolib",
            "LLM_Details", "Providers", "llm_provider.json"
        )
        if os.path.exists(provider_file):
            with open(provider_file, 'r') as f:
                data = json.load(f)
            # Legacy flat format
            if "models" in data:
                return {model["id"]: model for model in data.get("models", [])}
            # New provider-grouped format -- synthesize model-name-to-provider map
            result = {}
            for provider in data.get("providers", []):
                pid = provider.get("id", "")
                for model_name in provider.get("known_models", []):
                    # Use the model name itself as the key (agents now store
                    # actual model names, not synthetic IDs).
                    result[model_name] = {
                        "id": model_name,
                        "provider": pid,
                        "model_name": model_name,
                    }
                    # Also register with provider-prefixed key for back-compat
                    prefixed = f"{pid}-{model_name}"
                    result[prefixed] = {
                        "id": prefixed,
                        "provider": pid,
                        "model_name": model_name,
                    }
            return result
        return {}

    def _get_llm_client(self, model_id: str = None, user_id: Optional[str] = None):
        """
        Get LLM client using centralized LLM Manager.

        When ``user_id`` is provided, the LLM Manager resolves credentials
        from the user's stored configuration before falling back to
        platform-level secrets.

        Args:
            model_id: Optional model ID (ignored, kept for backward compatibility)
            user_id: Optional user UUID for credential resolution

        Returns:
            LLM client instance
        """
        from echolib.llm_resolver import resolve_and_build_llm_sync

        resolved_model = model_id or None
        resolved_provider = None
        if model_id and model_id in self._llm_providers:
            provider_entry = self._llm_providers[model_id]
            resolved_model = provider_entry.get("model_name") or model_id
            resolved_provider = provider_entry.get("provider")

        # Get LLM from centralized resolver
        try:
            return resolve_and_build_llm_sync(
                user_id=user_id,
                component="agent_designer",
                temperature=0.3,
                max_tokens=4000,
                allow_platform_fallback=True,
                framework="langchain",
                model=resolved_model,
                provider=resolved_provider,
            )
        except Exception as e:
            raise RuntimeError(f"Failed to get LLM from llm_resolver: {e}")

    def _get_trace_config(
        self,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Stub — Langfuse removed. Returns None (tracing handled by OTel)."""
        return None

    def _select_tools_for_agent(self, user_prompt: str, intent: Dict[str, Any] = None) -> list:
        """
        Auto-select appropriate tools based on agent purpose and intent keywords.

        Scores built-in tools by static keyword matching (TOOL_SELECTION_RULES).
        Connectors are never selected here: they attach to the agent as
        ``definition.connectors`` through an explicit user action, never by
        inference from the prompt (specification section 6.1, Rule 4).

        Maximum of 3 tools will be selected.

        Args:
            user_prompt: The user's natural language prompt
            intent: Optional pre-analyzed intent dict with keywords

        Returns:
            List of tool IDs (max 3), empty list if no clear match
        """
        # Build keyword set from prompt and intent
        prompt_lower = user_prompt.lower()

        keywords = set()
        # Add words from prompt
        words = [w.strip(".,!?;:()[]{}\"'") for w in prompt_lower.split()]
        keywords.update(w for w in words if len(w) > 2)

        # Add keywords from intent if available
        if intent:
            keywords.update(kw.lower() for kw in intent.get("keywords", []))
            domain = intent.get("domain", "")
            if domain:
                keywords.add(domain.lower())

        if not keywords:
            return []

        # Score built-in tools via static keyword rules
        tool_scores = {}

        for tool_id, tool_keywords in self.TOOL_SELECTION_RULES.items():
            score = 0
            for keyword in tool_keywords:
                if keyword in prompt_lower:
                    score += 2  # Higher score for direct prompt match
                elif keyword in keywords:
                    score += 1

            if score > 0:
                tool_scores[tool_id] = score

        if not tool_scores:
            return []

        # Sort by score and take top 3
        sorted_tools = sorted(tool_scores.items(), key=lambda x: x[1], reverse=True)
        selected_tools = [tool_id for tool_id, score in sorted_tools[:3]]

        return selected_tools

    @staticmethod
    def _get_scoped_tool_user_id(explicit_user_id: Optional[str] = None) -> Optional[str]:
        """Resolve user ID for user-scoped tool queries."""
        if explicit_user_id:
            return explicit_user_id

        try:
            from echolib.security import get_current_user_id
            return get_current_user_id()
        except Exception:
            return None

    def get_available_tools(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Return all available tools (built-in + connector-synced) with metadata.

        Queries the ToolRegistry for the full tool catalogue. Each tool is
        categorized as "builtin" (LOCAL) or "connector" (API/MCP) so
        the frontend can render appropriate UI controls.

        Falls back to the static AVAILABLE_TOOLS list when the ToolRegistry
        is unavailable (e.g. DI container not yet initialized).

        Args:
            user_id: Optional user ID for user-scoped connector visibility.

        Returns:
            Dict with:
                tools: List of tool dicts with tool_id, name, description,
                       tool_type, tags, source, status
                builtin_count: Number of builtin tools
                connector_count: Number of connector tools
                total: Total tool count
        """
        try:
            from echolib.di import container
            tool_registry = container.resolve('tool.registry')
        except (KeyError, ImportError):
            try:
                from apps.tool.container import container as tool_container
                tool_registry = tool_container.resolve('tool.registry')
            except Exception:
                tool_registry = None

        if tool_registry is not None:
            try:
                return self._build_tools_response_from_registry(tool_registry, user_id=user_id)
            except Exception as e:
                logger.warning(
                    f"ToolRegistry query failed, falling back to static list: {e}"
                )

        # Fallback: build a minimal response from the static AVAILABLE_TOOLS list
        return self._build_tools_response_from_static()

    def _build_tools_response_from_registry(
        self,
        tool_registry,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Build the available-tools response from ToolRegistry data.

        Args:
            tool_registry: ToolRegistry instance
            user_id: Optional user ID for user-scoped connector visibility.

        Returns:
            Dict with tools list and counts
        """
        from echolib.types import ToolType

        scoped_user_id = self._get_scoped_tool_user_id(user_id)
        if scoped_user_id and hasattr(tool_registry, "list_all_for_user"):
            all_tools = tool_registry.list_all_for_user(scoped_user_id)
        else:
            all_tools = tool_registry.list_all()
        # ``ToolType.CREWAI`` was part of this set until Phase 9. It dispatched
        # to the local executor, so the two were the same kind of tool under two
        # labels; migration ``064`` rewrites the stored rows to ``local``.
        builtin_types = {ToolType.LOCAL}

        tools_list: List[Dict[str, Any]] = []
        builtin_count = 0
        connector_count = 0

        for tool in all_tools:
            source = "builtin" if tool.tool_type in builtin_types else "connector"
            if source == "builtin":
                builtin_count += 1
            else:
                connector_count += 1

            tools_list.append({
                "tool_id": tool.tool_id,
                "name": tool.name,
                "description": tool.description,
                "tool_type": tool.tool_type.value if hasattr(tool.tool_type, 'value') else str(tool.tool_type),
                "tags": tool.tags or [],
                "source": source,
                "status": tool.status or "active",
                "version": tool.version or "1.0",
            })

        return {
            "tools": tools_list,
            "builtin_count": builtin_count,
            "connector_count": connector_count,
            "total": len(tools_list),
        }

    def _build_tools_response_from_static(self) -> Dict[str, Any]:
        """
        Build a fallback available-tools response from the static AVAILABLE_TOOLS list.

        Returns:
            Dict with tools list (all marked as builtin) and counts
        """
        # Provide human-readable descriptions for the static tool IDs
        static_descriptions = {
            "tool_web_search": "Search the web for information",
            "tool_file_reader": "Read and parse files (PDF, CSV, JSON, etc.)",
            "tool_code_generator": "Generate code from natural language",
            "tool_code_reviewer": "Review code for quality, bugs, and security",
            "tool_calculator": "Mathematical calculations and conversions",
        }

        tools_list: List[Dict[str, Any]] = []
        for tool_id in self.AVAILABLE_TOOLS:
            name = tool_id.replace("tool_", "").replace("_", " ").title()
            tools_list.append({
                "tool_id": tool_id,
                "name": name,
                "description": static_descriptions.get(tool_id, ""),
                "tool_type": "local",
                "tags": [],
                "source": "builtin",
                "status": "active",
                "version": "1.0",
            })

        return {
            "tools": tools_list,
            "builtin_count": len(tools_list),
            "connector_count": 0,
            "total": len(tools_list),
        }

    @staticmethod
    def _infer_json_type(value: Any) -> str:
        """Infer a JSON Schema type string from a Python value."""
        if isinstance(value, bool):
            return "boolean"
        elif isinstance(value, int):
            return "integer"
        elif isinstance(value, float):
            return "number"
        elif isinstance(value, str):
            return "string"
        elif isinstance(value, list):
            return "array"
        elif isinstance(value, dict):
            return "object"
        else:
            return "string"

    @staticmethod
    def _classify_design_failure(error: Exception) -> str:
        """Map design-time exceptions to a stable fallback reason."""
        if isinstance(error, AgentGenerationError):
            return "invalid_llm_response"
        return "llm_generation_failed"

    @staticmethod
    def _build_design_fallback_message(fallback_reason: str) -> str:
        """Create a user-facing message for degraded agent design responses."""
        if fallback_reason == "invalid_llm_response":
            return (
                "I couldn't generate a tailored agent because the design model "
                "returned an invalid response. Please retry."
            )
        return (
            "I couldn't generate a tailored agent because the design model is "
            "currently unavailable. Please check the configured LLM credentials "
            "or retry in a moment."
        )

    def design_from_prompt_with_diagnostics(
        self,
        user_prompt: str,
        default_model: str = "gpt-4o-mini",
        icon: str = "",
        tools: list = None,
        variables: list = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        existing_agent: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Design or revise an agent, returning diagnostics alongside it.

        Generation is schema-constrained (specification section 7): the model
        returns a validated configuration object rather than text that is
        scraped afterwards.

        Args:
            user_prompt: The builder's description or change request.
            default_model: Model the designed agent will run on.
            icon: Emoji or icon reference for the agent.
            tools: Explicit tool ids. Auto-resolved when empty.
            variables: Legacy builder variables, passed through untouched.
            user_id: Owner, for credential and tool scoping.
            session_id: Optional tracing session.
            existing_agent: Current agent state. Present means UPDATE mode,
                so the configuration and its config chat are handed to the
                model and only the requested change is applied (Rule 7).

        Returns:
            ``(agent_definition, design_meta)``. ``design_meta`` carries any
            clarifying questions, assumptions and changed fields.
        """
        if variables is None:
            variables = []

        mode = UPDATE_MODE if existing_agent else CREATE_MODE

        design_meta: Dict[str, Any] = {
            "fallback_used": False,
            "fallback_reason": None,
            "fallback_detail": None,
            "requested_model": default_model,
            "design_source": "llm",
            "mode": mode,
            "message": None,
            "clarifying_questions": [],
            "assumptions": [],
            "changed_fields": [],
            "low_confidence_fields": [],
        }

        try:
            agent_spec = self._design_with_llm(
                user_prompt,
                default_model,
                user_id=user_id,
                session_id=session_id,
                mode=mode,
                existing_agent=existing_agent,
            )
        except Exception as e:
            fallback_reason = self._classify_design_failure(e)
            fallback_detail = str(e) or e.__class__.__name__
            logger.warning(
                "Prompt-based agent design degraded to basic template (%s): %s",
                fallback_reason,
                fallback_detail,
            )
            agent_spec = self._design_basic(user_prompt)
            design_meta.update(
                {
                    "fallback_used": True,
                    "fallback_reason": fallback_reason,
                    "fallback_detail": fallback_detail,
                    "design_source": "basic",
                    "message": self._build_design_fallback_message(
                        fallback_reason
                    ),
                }
            )

        for key in (
            "clarifying_questions",
            "assumptions",
            "changed_fields",
            "low_confidence_fields",
        ):
            design_meta[key] = agent_spec.get(key) or []

        existing_agent = existing_agent or {}

        # Instructions are authoritative; ``prompt`` is tolerated so that a
        # caller or test supplying a legacy spec still produces a usable agent.
        instructions = (
            agent_spec.get("instructions")
            or agent_spec.get("prompt")
            or user_prompt
        )

        # Explicit selection wins, then catalog-matched suggestions (Rule 5),
        # then the keyword rules. Suggestions are resolved after generation
        # because they are part of what the model produces.
        selected_tools = list(tools) if tools else []
        if not selected_tools:
            selected_tools = resolve_catalog_tools(
                agent_spec, self._safe_tool_catalog(user_id)
            )
        if not selected_tools:
            selected_tools = self._select_tools_for_agent(user_prompt)

        agent_id = existing_agent.get("agent_id") or new_id("agt_")
        timestamp = datetime.utcnow().isoformat()

        model_config: Dict[str, Any] = {
            "model": default_model,
            "temperature": DEFAULT_TEMPERATURE,
            "top_p": DEFAULT_TOP_P,
            # ``max_tokens`` is deliberately absent, for exactly the reason the
            # ``settings`` block below already states: the generator did not
            # choose it, and ``normalize_agent_definition`` reads this key as an
            # authored value. Writing DEFAULT_MAX_TOKENS here hard-capped every
            # AI-designed agent at 2,000 output tokens as though its author had
            # asked for that -- and it took precedence over the omission below,
            # because ``model_config`` is the first source that function reads.
            # Absent, the allowance resolves per credential and provider at
            # build time, under the platform floor in ``llm_binding``.
        }

        # Provider is resolved from the catalogue when the model is known and
        # left unset otherwise, so the resolver cascade decides.
        resolved_provider = None
        if default_model and default_model in self._llm_providers:
            resolved_provider = self._llm_providers[default_model].get("provider")
        if resolved_provider:
            model_config["provider"] = resolved_provider

        # Auto-assign user's default credential_id when creating from prompt.
        # This ensures prompt-generated agents link to the user's configured
        # credential so runtime resolution works correctly.
        credential_id = existing_agent.get("credential_id")
        if not credential_id and user_id:
            credential_id = self._resolve_default_credential_id(user_id)

        metadata: Dict[str, Any] = {
            **(existing_agent.get("metadata") or {}),
            **design_metadata(agent_spec),
            "created_by": "agent_designer",
            "source_prompt": user_prompt,
        }
        metadata.setdefault("created_at", timestamp)
        metadata.setdefault("tags", ["auto-generated"])
        metadata["updated_at"] = timestamp

        agent = {
            "agent_id": agent_id,
            "name": agent_spec.get("name") or "Agent",
            "icon": icon or existing_agent.get("icon", ""),
            # Legacy display key. It is never generated and never persisted —
            # the contract strips removed concepts at the write boundary — but
            # the current builder UI still reads it, and changing that needs
            # coordinated frontend work.
            "role": existing_agent.get("role") or "Processing",
            "description": agent_spec.get("description") or user_prompt[:200],
            "instructions": instructions,
            # Tier-3 mirror, kept until Phase 10 rewires the legacy readers.
            "prompt": instructions,
            "model": default_model,
            "model_config": model_config,
            "tools": selected_tools,
            "variables": variables,
            # ``max_token`` is deliberately not written here. The generator did
            # not choose it, and ``normalize_agent_definition`` reads this key
            # as an authored value -- so stating a default would hard-cap every
            # AI-designed agent at 2000 output tokens as though its author had
            # asked for that. Left absent, it resolves per credential and
            # provider at build time.
            "settings": {
                "temperature": DEFAULT_TEMPERATURE,
                "top_p": DEFAULT_TOP_P,
                "max_iteration": DEFAULT_MAX_ITERATION,
            },
            # Rule 4: generation suggests, it never attaches.
            "knowledge_sources": existing_agent.get("knowledge_sources", []),
            "connectors": existing_agent.get("connectors", []),
            "required_inputs": agent_spec.get("required_inputs", []),
            "input_schema": agent_spec.get("input_schema", []),
            "output_schema": agent_spec.get("output_schema", []),
            "constraints": {
                "max_steps": DEFAULT_MAX_ITERATION,
                "timeout_seconds": 60,
            },
            "permissions": {
                "can_call_agents": False,
                "allowed_agents": [],
            },
            "metadata": metadata,
        }

        if resolved_provider:
            agent["provider"] = resolved_provider

        # Attach credential_id if resolved (may be None for users without credentials)
        if credential_id:
            agent["credential_id"] = credential_id

        return agent, design_meta

    def design_from_prompt(
        self,
        user_prompt: str,
        default_model: str = "gpt-4o-mini",
        icon: str = "",
        tools: list = None,
        variables: list = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Design agent from user prompt using LLM.

        Args:
            user_prompt: Natural language description of agent
            default_model: Model ID to use for agent
            icon: Emoji icon for agent
            tools: List of tool names (if None or empty, auto-selects based on purpose)
            variables: List of variable definitions

        Returns:
            Agent definition dict
        """
        agent, _ = self.design_from_prompt_with_diagnostics(
            user_prompt=user_prompt,
            default_model=default_model,
            icon=icon,
            tools=tools,
            variables=variables,
            user_id=user_id,
            session_id=session_id,
        )
        return agent

    def _safe_tool_catalog(self, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Return the platform action catalog, or an empty list when unavailable.

        Rule 5 matches suggested capabilities against real tool ids. A missing
        registry degrades tool matching, never agent generation.
        """
        try:
            return self.get_available_tools(user_id=user_id).get("tools", [])
        except Exception as e:
            logger.debug("Tool catalog unavailable for agent generation: %s", e)
            return []

    @staticmethod
    def _existing_config_for_generation(
        existing_agent: Optional[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """
        Project an agent onto the surface the generation model may edit.

        Specification section 7.2 requires the full current configuration on
        every UPDATE call. Only the user-authored surface is sent: identifiers,
        credentials and runtime bookkeeping are not the model's to change.
        """
        if not isinstance(existing_agent, dict):
            return None

        return {
            "agent_name": existing_agent.get("name", ""),
            "description": existing_agent.get("description", ""),
            "instructions": existing_agent.get("instructions")
            or existing_agent.get("prompt", ""),
            "tools": existing_agent.get("tools", []),
            "required_inputs": existing_agent.get("required_inputs", []),
            "input_schema": existing_agent.get("input_schema", []),
            "output_schema": existing_agent.get("output_schema", []),
        }

    def _design_with_llm(
        self,
        user_prompt: str,
        model_id: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        mode: str = CREATE_MODE,
        existing_agent: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Generate an agent specification under schema constraint.

        Args:
            user_prompt: The builder's description or change request.
            model_id: Model used for generation itself.
            user_id: Owner, for credential resolution and tool scoping.
            session_id: Optional tracing session.
            mode: ``CREATE`` or ``UPDATE``.
            existing_agent: Current agent state in UPDATE mode.

        Returns:
            The generation spec dict (see ``generation.mapper.config_to_spec``).

        Raises:
            AgentGenerationError: When no schema-conformant object was returned.
        """
        llm = self._get_llm_client(model_id, user_id=user_id)

        invoke_config = self._get_trace_config(
            user_id=user_id,
            session_id=session_id,
            tags=["agent:design", f"operation:{mode.lower()}_agent"],
        )

        config = generate_agent_config(
            llm,
            user_prompt=user_prompt,
            mode=mode,
            existing_config=self._existing_config_for_generation(existing_agent),
            history=render_config_chat(get_config_chat(existing_agent)),
            tool_catalog=self._safe_tool_catalog(user_id),
            invoke_config=invoke_config,
        )

        return config_to_spec(config, user_prompt=user_prompt)

    def _design_basic(self, user_prompt: str) -> Dict[str, Any]:
        """
        Build a minimal specification without an LLM.

        Reached only when generation is unavailable. The name is derived
        deterministically from the prompt rather than being the literal string
        "Custom Agent" for every agent created during an outage.
        """
        return {
            "name": derive_fallback_name(user_prompt),
            "description": user_prompt[:200],
            "instructions": user_prompt,
            "required_inputs": [],
            "input_schema": [],
            "output_schema": [],
        }

    @staticmethod
    def _resolve_default_credential_id(user_id: str) -> Optional[str]:
        """
        Resolve the user's global default credential_id.

        Returns the credential_id string, or None if the user has no
        credentials configured.  This is used to auto-assign a credential
        to prompt-generated agents.
        """
        import asyncio

        try:
            from echolib.credential_resolver import resolve_llm_credential, LLMCredentialNotConfiguredError
            from echolib.database import get_db_session
            from echolib.llm_resolver import _main_loop

            async def _resolve():
                async with get_db_session() as db:
                    result = await resolve_llm_credential(db_session=db, user_id=user_id)
                    return result.get("credential_id")

            # Schedule on the main event loop so asyncpg connections
            # (bound to that loop) work correctly.  This function is
            # always called from a worker thread (via asyncio.to_thread
            # in the route handler), so the main loop is free.
            if _main_loop is not None and _main_loop.is_running():
                future = asyncio.run_coroutine_threadsafe(_resolve(), _main_loop)
                return future.result(timeout=10)

            # Fallback for dev/testing where _main_loop is not set.
            return asyncio.run(_resolve())
        except Exception as e:
            logger.debug("Could not resolve default credential_id for user %s: %s", user_id, e)
            return None

    def update_from_prompt(
        self,
        existing_agent: Dict[str, Any],
        user_prompt: str,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing agent based on user prompt while preserving identity.

        This method detects what fields the user wants to update and only
        modifies those fields, preserving the agent's name, ID, and other
        unchanged attributes.

        Args:
            existing_agent: The current agent definition dict
            user_prompt: User's natural language update request
            user_id: Optional user UUID for credential resolution

        Returns:
            Updated agent definition dict with preserved identity
        """
        # The config chat is threaded into the call before the new turn is
        # recorded, so the model sees the dialogue that led here without seeing
        # the current message twice.
        model = (
            (existing_agent.get("model_config") or {}).get("model")
            or existing_agent.get("model")
            or "gpt-4o-mini"
        )

        try:
            updated_agent, design_meta = self.design_from_prompt_with_diagnostics(
                user_prompt=user_prompt,
                default_model=model,
                icon=existing_agent.get("icon", ""),
                tools=existing_agent.get("tools") or None,
                variables=existing_agent.get("variables") or [],
                user_id=user_id,
                existing_agent=existing_agent,
            )
            if design_meta.get("fallback_used"):
                raise AgentGenerationError(
                    design_meta.get("fallback_detail") or "generation unavailable"
                )
        except Exception as e:
            logger.warning("Structured agent update failed, applying basic updates: %s", e)
            return self._apply_legacy_updates(existing_agent, user_prompt)

        updated_agent = append_config_chat(updated_agent, "user", user_prompt)

        metadata = updated_agent.setdefault("metadata", {})
        metadata["updated_at"] = datetime.utcnow().isoformat()
        metadata["update_prompt"] = user_prompt
        if design_meta.get("changed_fields"):
            metadata["changed_fields"] = design_meta["changed_fields"]

        return updated_agent

    def _apply_legacy_updates(
        self, existing_agent: Dict[str, Any], user_prompt: str
    ) -> Dict[str, Any]:
        """
        Apply a keyword-driven update without an LLM.

        Degraded path only, reached when generation is unavailable. It cannot
        interpret the request, so it appends the instruction rather than
        rewriting the agent — visibly partial instead of silently wrong.
        """
        update_intent = self._detect_update_fields(user_prompt)
        updates = self._apply_basic_updates(existing_agent, user_prompt, update_intent)

        updated_agent = copy.deepcopy(existing_agent)
        for key, value in updates.items():
            if key not in ("agent_id", "name"):
                updated_agent[key] = value

        metadata = updated_agent.setdefault("metadata", {})
        metadata["updated_at"] = datetime.utcnow().isoformat()
        metadata["update_prompt"] = user_prompt

        return updated_agent

    def _detect_update_fields(self, user_prompt: str) -> Dict[str, Any]:
        """
        Detect which fields the user wants to update based on prompt keywords.

        Args:
            user_prompt: User's update request

        Returns:
            Dict with fields_to_update list and detected intent
        """
        prompt_lower = user_prompt.lower()

        fields_to_update = []

        # Tool-related keywords (includes connector/integration triggers)
        tool_keywords = ["tool", "tools", "add tool", "remove tool", "change tool",
                         "web search", "file reader", "code executor",
                         "connector", "integration", "api", "mcp"]
        if any(kw in prompt_lower for kw in tool_keywords):
            fields_to_update.append("tools")

        # Description/purpose keywords
        desc_keywords = ["description", "purpose", "what it does", "goal", "objective"]
        if any(kw in prompt_lower for kw in desc_keywords):
            fields_to_update.append("description")

        # Role keywords
        role_keywords = ["role", "position", "job", "title"]
        if any(kw in prompt_lower for kw in role_keywords):
            fields_to_update.append("role")

        # Prompt/behavior keywords
        behavior_keywords = ["prompt", "behavior", "instruction", "system prompt",
                            "how it works", "act", "behave"]
        if any(kw in prompt_lower for kw in behavior_keywords):
            fields_to_update.append("prompt")

        # Settings keywords
        settings_keywords = ["temperature", "max_token", "setting", "configure",
                            "parameter", "iteration"]
        if any(kw in prompt_lower for kw in settings_keywords):
            fields_to_update.append("settings")

        # Name keywords (only if explicitly mentioned)
        name_keywords = ["rename", "change name", "new name", "call it", "named"]
        if any(kw in prompt_lower for kw in name_keywords):
            fields_to_update.append("name")

        # If no specific fields detected, assume description and prompt update
        if not fields_to_update:
            fields_to_update = ["description", "prompt"]

        return {
            "fields_to_update": fields_to_update,
            "original_prompt": user_prompt
        }

    def _apply_basic_updates(
        self,
        existing_agent: Dict[str, Any],
        user_prompt: str,
        update_intent: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Apply basic updates without LLM (fallback).

        Args:
            existing_agent: Current agent definition
            user_prompt: User's update request
            update_intent: Dict with fields_to_update

        Returns:
            Dict with basic updated values
        """
        fields_to_update = update_intent.get("fields_to_update", [])
        updates: Dict[str, Any] = {}

        if "description" in fields_to_update:
            # Append update context to description
            current_desc = existing_agent.get("description", "")
            updates["description"] = f"{current_desc} (Updated: {user_prompt[:100]})"

        if "prompt" in fields_to_update:
            # Append to instructions; ``prompt`` mirrors them until Phase 10.
            current = (
                existing_agent.get("instructions")
                or existing_agent.get("prompt", "")
            )
            appended = f"{current}\n\nAdditional instructions: {user_prompt}".strip()
            updates["instructions"] = appended
            updates["prompt"] = appended

        return updates

    # ================================================================
    # Backend-driven conversational flow
    # ================================================================

    def handle_chat_step(
        self,
        message: str,
        step: str,
        agent_state: Dict[str, Any],
        model: str = "gpt-4o-mini",
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Handle one turn of the agent-builder conversation.

        The frontend sends the user message, the current step, and the
        current agent_state.  This method classifies intent, performs
        the appropriate action (design / name confirm / tool ops /
        instruction update / finalize), and returns a structured
        response that the frontend renders without any business logic.

        Steps: initial -> [clarify] -> name -> refine -> done

        ``clarify`` is entered only when generation asked something whose answer
        materially changes the agent, and is bounded by
        :data:`MAX_CLARIFICATION_TURNS`.

        Every turn is appended to the agent's config chat
        (``definition.metadata.config_chat``) so the next generation call sees
        the whole dialogue. Context is therefore held by the agent, not by the
        request, and survives a page reload or a later editing session.

        Args:
            message:     User's natural-language message
            step:        Current conversation step
            agent_state: Current agent definition dict (may be empty on 'initial')
            model:       LLM model id for agent design
            user_id:     Optional user UUID for credential resolution

        Returns:
            Dict with keys:
                reply        – chat bubble text
                step         – next conversation step
                action       – machine-readable action tag
                agent_state  – (possibly updated) agent definition
                tools_available – list of tool dicts (only on tool-related actions)
        """
        message_lower = message.lower().strip()

        if step == "initial":
            result = self._chat_step_initial(message, agent_state, model, user_id=user_id)
        elif step == "clarify":
            result = self._chat_step_clarify(message, agent_state, model, user_id=user_id)
        elif step == "name":
            result = self._chat_step_name(
                message, message_lower, agent_state, user_id=user_id
            )
        elif step == "refine":
            result = self._chat_step_refine(
                message, message_lower, agent_state, user_id=user_id
            )
        elif step == "done":
            result = self._chat_step_done(
                message, message_lower, agent_state, user_id=user_id
            )
        else:
            result = {
                "reply": "Something went wrong. Let's start over — describe the agent you'd like to create.",
                "step": "initial",
                "action": "ERROR",
                "agent_state": {},
            }

        # B4: Sanitize reply text to prevent raw Markdown leaking to frontend
        if "reply" in result and isinstance(result["reply"], str):
            result = {**result, "reply": self._sanitize_reply(result["reply"])}

        return self._record_chat_turn(result, message)

    @staticmethod
    def _record_chat_turn(result: Dict[str, Any], message: str) -> Dict[str, Any]:
        """
        Append this turn to the agent's config chat.

        Specification section 7.2: the transcript is keyed to the agent so a
        builder can leave and resume refining it later. Turns are only recorded
        once an agent exists — there is nothing to key them to before that.
        """
        agent_state = result.get("agent_state")
        if not isinstance(agent_state, dict) or not agent_state.get("agent_id"):
            return result

        updated = append_config_chat(agent_state, "user", message)
        updated = append_config_chat(updated, "assistant", result.get("reply", ""))

        return {**result, "agent_state": updated}

    # ---- initial step ---------------------------------------------------

    def _chat_step_initial(
        self, message: str, agent_state: Dict[str, Any], model: str,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Design a new agent from the user's first prompt."""
        try:
            agent, design_meta = self.design_from_prompt_with_diagnostics(
                user_prompt=message,
                default_model=model,
                icon=agent_state.get("icon", ""),
                tools=agent_state.get("tools"),
                variables=agent_state.get("variables"),
                user_id=user_id,
            )
        except Exception as e:
            logger.error(f"Agent design failed: {e}")
            return {
                "reply": f"Sorry, I couldn't design the agent: {e}\nPlease try rephrasing your request.",
                "step": "initial",
                "action": "ERROR",
                "agent_state": agent_state,
            }

        if design_meta.get("fallback_used"):
            return {
                "reply": design_meta.get("message")
                or "I couldn't generate a tailored agent right now. Please retry.",
                "step": "initial",
                "action": "DESIGN_FALLBACK",
                "agent_state": agent_state,
                "design_meta": design_meta,
            }

        return self._after_design_result(agent, message, design_meta)

    # ---- clarify step ---------------------------------------------------

    def _chat_step_clarify(
        self, message: str, agent_state: Dict[str, Any], model: str,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Fold the builder's answer back into the agent.

        The answer is applied as an UPDATE over the current configuration, so
        everything already agreed survives and only what the answer implies
        changes. After :data:`MAX_CLARIFICATION_TURNS` the flow proceeds on
        defaults rather than continuing to ask.
        """
        try:
            agent, design_meta = self.design_from_prompt_with_diagnostics(
                user_prompt=message,
                default_model=model,
                icon=agent_state.get("icon", ""),
                tools=agent_state.get("tools") or None,
                variables=agent_state.get("variables"),
                user_id=user_id,
                existing_agent=agent_state,
            )
        except Exception as e:
            logger.error(f"Agent clarification update failed: {e}")
            return {
                "reply": (
                    "Sorry, I couldn't apply that. Let's continue — "
                    f"the current name is \"{agent_state.get('name', 'Agent')}\". "
                    "Would you like to use it?"
                ),
                "step": "name",
                "action": "ERROR",
                "agent_state": agent_state,
            }

        if design_meta.get("fallback_used"):
            # Generation is unavailable; keep what we have rather than losing it.
            return self._name_confirmation_result(agent_state, message)

        agent["_clarification_turns"] = agent_state.get("_clarification_turns", 0)
        return self._after_design_result(agent, message, design_meta)

    # ---- shared design replies ------------------------------------------

    @staticmethod
    def _design_summary(agent: Dict[str, Any], design_meta: Dict[str, Any]) -> str:
        """Summarize a freshly designed agent, including any defaults chosen."""
        lines = [
            f'Your agent "{agent.get("name", "Agent")}" is ready.',
            "",
            f"Description: {agent.get('description', '')}",
        ]

        assumptions = design_meta.get("assumptions") or []
        if assumptions:
            lines.append("")
            lines.append("I assumed the following — tell me if any is wrong:")
            for item in assumptions[:3]:
                if isinstance(item, dict) and item.get("assumption"):
                    lines.append(f"• {item['assumption']}")

        return "\n".join(lines)

    def _after_design_result(
        self,
        agent: Dict[str, Any],
        message: str,
        design_meta: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Decide what to say after a successful design.

        Either one focused question, when generation flagged something whose
        answer materially changes the agent, or the name confirmation. A
        question never blocks the result: the agent is complete and usable
        either way.
        """
        summary = self._design_summary(agent, design_meta)
        questions = format_clarifying_questions(design_meta)
        asked = agent.get("_clarification_turns", 0)

        if questions and asked < MAX_CLARIFICATION_TURNS:
            agent["_clarification_turns"] = asked + 1
            return {
                "reply": (
                    f"{summary}\n\n"
                    f"One thing that would make it fit better:\n{questions}\n\n"
                    "Answer it, or say \"skip\" and I'll use sensible defaults."
                ),
                "step": "clarify",
                "action": "CLARIFICATION_NEEDED",
                "agent_state": agent,
                "design_meta": design_meta,
            }

        return self._name_confirmation_result(agent, message, prefix=summary)

    @staticmethod
    def _name_confirmation_result(
        agent: Dict[str, Any],
        message: str,
        *,
        prefix: str = "",
    ) -> Dict[str, Any]:
        """Move the conversation to name confirmation."""
        name = agent.get("name", "Agent")
        blocks = [block for block in (prefix,) if block]
        blocks.append(
            f"Next, let's confirm the name. I suggest: {name}.\n\n"
            "Would you like to use this name, or do you have another name in mind?"
        )
        return {
            "reply": "\n\n".join(blocks),
            "step": "name",
            "action": "AGENT_DESIGNED",
            "agent_state": agent,
        }

    # ---- name step ------------------------------------------------------

    def _chat_step_name(
        self,
        message: str,
        message_lower: str,
        agent_state: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Handle name confirmation / modification."""
        intent = self._classify_intent_safe(
            "name_confirmation", agent_state.get("name", ""), message
        )
        current_name = agent_state.get("name", "Agent")

        if intent["intent"] == "CONFIRMATION":
            # If the same message already asks for tool/connector action,
            # process it immediately instead of asking another question.
            if self._looks_like_tool_or_connector_request(message_lower):
                mod_result = self._handle_modification(
                    message, message_lower, agent_state, user_id=user_id
                )
                mod_result["reply"] = (
                    f'The agent\'s name is set to "{current_name}".\n\n'
                    f"{mod_result.get('reply', '')}"
                )
                mod_result["step"] = "refine"
                return mod_result

            reply = (
                f'The agent\'s name is set to "{current_name}".\n\n'
                "Would you like to add any tools, update instructions, "
                "or are we ready to finalize?"
            )
            return {
                "reply": reply,
                "step": "refine",
                "action": "NAME_CONFIRMED",
                "agent_state": agent_state,
            }

        elif intent["intent"] == "MODIFICATION":
            # The classifier already extracts meaning rather than phrasing
            # (Rule 1), and its no-LLM fallback does the subtractive strip
            # itself. Re-scraping the result here would be the transcribe-then-
            # scrape pattern specification section 7.1 rules out; only Rule 2
            # formatting is applied.
            raw_name = intent.get("extracted_value") or message.strip()
            new_name = normalize_agent_name(
                raw_name, fallback=agent_state.get("name") or "Agent"
            )
            agent_state["name"] = new_name

            # If user changed name and also asked for tools/connectors,
            # execute both in the same turn.
            if self._looks_like_tool_or_connector_request(message_lower):
                mod_result = self._handle_modification(
                    message, message_lower, agent_state, user_id=user_id
                )
                mod_result["reply"] = (
                    f'I\'ve updated the name to "{new_name}".\n\n'
                    f"{mod_result.get('reply', '')}"
                )
                mod_result["step"] = "refine"
                return mod_result

            reply = (
                f'I\'ve updated the name to "{new_name}".\n\n'
                "Would you like to add any tools, update instructions, "
                "or are we ready to finalize?"
            )
            return {
                "reply": reply,
                "step": "refine",
                "action": "NAME_UPDATED",
                "agent_state": agent_state,
            }

        elif intent["intent"] == "REJECTION":
            reply = (
                "No problem! What would you like to name this agent instead?"
            )
            return {
                "reply": reply,
                "step": "name",
                "action": "NAME_REJECTED",
                "agent_state": agent_state,
            }

        else:  # CLARIFICATION
            reply = (
                f'The current suggested name is "{current_name}". '
                "You can accept it, or tell me a different name you'd prefer."
            )
            return {
                "reply": reply,
                "step": "name",
                "action": "CLARIFICATION",
                "agent_state": agent_state,
            }

    # ---- refine step ----------------------------------------------------

    def _chat_step_refine(
        self,
        message: str,
        message_lower: str,
        agent_state: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Handle refinements: tools, instructions, and finalization."""

        # Deterministic safety: tool-like requests must be processed as
        # modifications before any confirmation/finalization handling.
        if self._looks_like_tool_or_connector_request(message_lower):
            return self._handle_modification(
                message, message_lower, agent_state, user_id=user_id
            )

        if self._is_explicit_no_tools_confirmation_message(message_lower):
            self._set_no_tools_confirmation(agent_state, True)
            return {
                "reply": (
                    "Confirmed. I will save this agent without tools. "
                    "You can finalize now or continue refining."
                ),
                "step": "refine",
                "action": "CONFIRM_NO_TOOLS_REQUIRED",
                "agent_state": agent_state,
            }

        intent = self._classify_intent_safe(
            "refinement", "finalize agent", message
        )

        # --- CONFIRMATION → finalize ---
        if intent["intent"] == "CONFIRMATION":
            if not self._has_selected_tools(agent_state) and not self._is_no_tools_confirmed(agent_state):
                return {
                    "reply": (
                        "Before finalizing, please either add at least one tool or explicitly confirm "
                        "save without tools by saying 'save without tools'."
                    ),
                    "step": "refine",
                    "action": "NO_TOOLS_CONFIRMATION_REQUIRED",
                    "agent_state": agent_state,
                }

            reply = (
                "Great! Your agent is ready. You can now:\n\n"
                '• Click "Configure" tab to add tools, variables, and fine-tune settings\n'
                '• Or click "Save Agent" to save as-is and start using it'
            )
            return {
                "reply": reply,
                "step": "done",
                "action": "FINALIZED",
                "agent_state": agent_state,
            }

        # --- CLARIFICATION → informational response ---
        if intent["intent"] == "CLARIFICATION":
            return self._handle_clarification(message_lower, agent_state)

        # --- MODIFICATION (or REJECTION treated as modification) ---
        return self._handle_modification(
            message, message_lower, agent_state, user_id=user_id
        )

    def _handle_clarification(
        self, message_lower: str, agent_state: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Respond to informational questions during refinement."""
        tool_words = {"tool", "tools", "available", "list", "show", "what"}
        if tool_words & set(message_lower.split()):
            all_tools = self._get_all_tools_for_chat()
            current_ids = agent_state.get("tools", [])

            lines = ["Here are the available tools:\n"]
            for t in all_tools:
                badge = " [Connector]" if t["source"] == "connector" else ""
                lines.append(f'• **{t["name"]}**{badge} — {t["description"]}')

            if current_ids:
                selected_names = self._tool_ids_to_names(current_ids, all_tools)
                lines.append(f"\n**Currently selected:** {', '.join(selected_names)}")

            lines.append(
                '\nTo add tools, say something like "add calculator and web search".'
                '\nTo create a tool from a connector, say "create a [connector name] tool".'
            )
            return {
                "reply": "\n".join(lines),
                "step": "refine",
                "action": "TOOLS_LISTED",
                "agent_state": agent_state,
                "tools_available": all_tools,
            }

        # Generic clarification
        return {
            "reply": (
                "You can:\n\n"
                '• Add or remove tools (say "add web search")\n'
                "• Update the agent's behavior or instructions\n"
                "• Change the agent's role or description\n\n"
                'Or say "looks good" to finalize the agent.'
            ),
            "step": "refine",
            "action": "CLARIFICATION",
            "agent_state": agent_state,
        }

    def _handle_modification(
        self,
        message: str,
        message_lower: str,
        agent_state: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Handle modification requests (tools or instructions)."""

        # Build dynamic tool keywords
        all_tools = self._get_all_tools_for_chat()
        tool_keywords = {"tool", "tools", "add tool", "remove tool",
                         "connector", "integration", "create tool",
                         "new tool", "generate tool"}
        for t in all_tools:
            tool_keywords.add(t["name"].lower())
            tid = t["tool_id"]
            if tid.startswith("tool_"):
                tool_keywords.add(tid[5:].replace("_", " "))

        is_tool_request = any(kw in message_lower for kw in tool_keywords)

        if is_tool_request:
            return self._handle_tool_modification(message_lower, agent_state, all_tools)

        # Everything that is not a tool operation is a change to the agent
        # itself, and is applied as a structured UPDATE.
        return self._refine_agent(message, agent_state, user_id=user_id)

    def _refine_agent(
        self,
        message: str,
        agent_state: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Apply one conversational change through structured UPDATE generation.

        WHAT: Hands the model the complete current configuration and the config
              chat, and takes back a complete configuration plus the list of
              fields that changed (specification section 7, Rule 7).
        WHY:  This path previously appended the builder's literal sentence to
              ``prompt`` — the transcribe-then-store pattern section 7.1 rules
              out. It wrote the *request* into the agent's runtime instructions
              instead of its *meaning*, left the fourteen-part scaffold
              unmaintained, and never reached the generator that exists for
              exactly this. A production agent builder regenerates the whole
              configuration on every turn; this is that turn.
        OUTPUT: The updated definition and a reply naming what changed, so the
                builder can see the effect of what they asked for.

        Generation being unavailable degrades to the keyword updater rather
        than failing the turn: a builder mid-conversation must not lose their
        agent because a model endpoint is down.
        """
        changed_fields: List[Any] = []

        try:
            updated = self.update_from_prompt(
                existing_agent=agent_state,
                user_prompt=message,
                user_id=user_id,
            )
            changed_fields = (updated.get("metadata") or {}).get("changed_fields") or []
        except Exception as exc:  # noqa: BLE001 -- degraded, never fatal
            logger.warning(
                "Structured refinement unavailable, applying basic update: %s", exc
            )
            updated = self._apply_legacy_updates(agent_state, message)

        return {
            "reply": self._refinement_summary(changed_fields),
            "step": "refine",
            "action": "INSTRUCTIONS_UPDATED",
            "draft_changed": True,
            "agent_state": updated,
        }

    @staticmethod
    def _refinement_summary(changed_fields: Sequence[Any]) -> str:
        """
        Say what actually changed, not what was asked for.

        Naming the changed fields is what lets a builder trust an update they
        did not watch happen, and it is the same feedback a production agent
        builder gives after each turn.
        """
        lines = ["I've applied that to the agent."]

        rendered: List[str] = []
        for item in changed_fields:
            if isinstance(item, dict):
                path = str(item.get("path") or "").strip()
                reason = str(item.get("reason") or "").strip()
                if path:
                    rendered.append(f"• {path} — {reason}" if reason else f"• {path}")
            elif isinstance(item, str) and item.strip():
                rendered.append(f"• {item.strip()}")

        if rendered:
            lines.append("")
            lines.append("What changed:")
            lines.extend(rendered[:MAX_REPORTED_CHANGES])

        lines.append("")
        lines.append(
            "Anything else — instructions, description, or tools — "
            "or shall we finalize?"
        )
        return "\n".join(lines)

    def _handle_tool_modification(
        self,
        message_lower: str,
        agent_state: Dict[str, Any],
        all_tools: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Parse tool add/remove/create requests and update agent_state."""
        current_tools: list = agent_state.get("tools", [])

        # Build name→id lookup
        tool_map: Dict[str, str] = {}
        for t in all_tools:
            name_l = t["name"].lower()
            tool_map[name_l] = t["tool_id"]
            tool_map[name_l.replace(" ", "_")] = t["tool_id"]
            tool_map[t["tool_id"]] = t["tool_id"]
            if t["tool_id"].startswith("tool_"):
                short = t["tool_id"][5:]
                tool_map[short] = t["tool_id"]
                tool_map[short.replace("_", " ")] = t["tool_id"]

        is_remove = "remove" in message_lower
        is_add = any(k in message_lower for k in ("add", "include", "attach", "use"))
        matched_ids = []
        for alias, tid in tool_map.items():
            if self._contains_alias(message_lower, alias):
                matched_ids.append(tid)
        matched_ids = list(dict.fromkeys(matched_ids))  # dedupe, preserve order

        if is_remove and matched_ids:
            removable = [t for t in matched_ids if t in current_tools]
            if not removable:
                requested = ", ".join(self._tool_ids_to_names(matched_ids, all_tools))
                current = ", ".join(self._tool_ids_to_names(current_tools, all_tools)) or "None"
                return {
                    "reply": (
                        f"None of the requested tools were currently selected: {requested}\n\n"
                        f"Current tools: {current}"
                    ),
                    "step": "refine",
                    "action": "TOOL_NOT_SELECTED",
                    "draft_changed": False,
                    "agent_state": agent_state,
                    "tools_available": all_tools,
                }

            new_tools = [t for t in current_tools if t not in removable]
            agent_state["tools"] = new_tools
            self._set_no_tools_confirmation(agent_state, False)
            removed = ", ".join(self._tool_ids_to_names(removable, all_tools))
            current = ", ".join(self._tool_ids_to_names(new_tools, all_tools)) or "None"
            return {
                "reply": (
                    f"I've removed the following tools: {removed}\n\n"
                    f"Current tools: {current}\n\n"
                    "Would you like to make any other changes?"
                ),
                "step": "refine",
                "action": "TOOLS_REMOVED",
                "draft_changed": True,
                "agent_state": agent_state,
                "tools_available": all_tools,
            }

        if not is_remove and matched_ids:
            addable = [t for t in matched_ids if t not in current_tools]
            if not addable:
                already = ", ".join(self._tool_ids_to_names(matched_ids, all_tools))
                current = ", ".join(self._tool_ids_to_names(current_tools, all_tools)) or "None"
                return {
                    "reply": (
                        f"These tools are already selected: {already}\n\n"
                        f"Current tools: {current}"
                    ),
                    "step": "refine",
                    "action": "TOOL_ALREADY_SELECTED",
                    "draft_changed": False,
                    "agent_state": agent_state,
                    "tools_available": all_tools,
                }

            new_tools = list(dict.fromkeys(current_tools + addable))
            agent_state["tools"] = new_tools
            self._set_no_tools_confirmation(agent_state, False)
            added = ", ".join(self._tool_ids_to_names(addable, all_tools))
            current = ", ".join(self._tool_ids_to_names(new_tools, all_tools))
            return {
                "reply": (
                    f"I've added the following tools: {added}\n\n"
                    f"Current tools: {current}\n\n"
                    "Would you like to make any other changes, or are we ready to finalize?"
                ),
                "step": "refine",
                "action": "TOOLS_ADDED",
                "draft_changed": True,
                "agent_state": agent_state,
                "tools_available": all_tools,
            }

        if (is_add or is_remove) and not matched_ids:
            return {
                "reply": (
                    "I could not find the requested tool. Please use an available tool name "
                    "or ask me to list available tools."
                ),
                "step": "refine",
                "action": "TOOL_NOT_FOUND",
                "draft_changed": False,
                "agent_state": agent_state,
                "tools_available": all_tools,
            }

        # No specific tool matched. A connector request is not a tool request:
        # connectors attach to the agent directly (specification section 6.1),
        # so point the builder at that surface instead of synthesising a tool.
        if self._mentions_connector(message_lower):
            return {
                "reply": (
                    "Connectors are not added as tools. Open Connector Settings "
                    "on this agent and attach the connector there — it stays part "
                    "of the agent and is available on every run.\n\n"
                    "I can still add any of these tools:\n\n"
                    + "\n".join(f'* {t["name"]}' for t in all_tools)
                ),
                "step": "refine",
                "action": "TOOL_CREATE_GUIDANCE",
                "agent_state": agent_state,
                "tools_available": all_tools,
            }

        # Fallback: show tool list
        tool_lines = "\n".join(
            f'• {t["name"]}{" [Connector]" if t["source"] == "connector" else ""}'
            for t in all_tools
        )
        example = all_tools[0]["name"].lower() if all_tools else "tool name"
        return {
            "reply": (
                "Please specify which tools to add or remove:\n\n"
                f"{tool_lines}\n\n"
                f'Example: "add {example}"'
            ),
            "step": "refine",
            "action": "TOOLS_PROMPT",
            "agent_state": agent_state,
            "tools_available": all_tools,
        }

    @staticmethod
    def _normalize_text(value: str) -> str:
        """Lowercase and normalize text to alnum tokens separated by spaces."""
        if not value:
            return ""
        return " ".join(re.sub(r"[^a-z0-9]+", " ", value.lower()).split())

    @staticmethod
    def _sanitize_reply(text: str) -> str:
        """
        Remove Markdown bold markers from reply text.

        WHAT: Strips '**' from text to prevent raw Markdown leaking to frontend.
        WHY: The frontend renders plain text; Markdown bold markers appear as
             literal '**' characters in the UI.
        INPUT: Text string possibly containing '**'.
        OUTPUT: Clean text without '**'.

        Args:
            text: Reply text string.

        Returns:
            Text with all '**' removed.
        """
        return text.replace("**", "")

    @staticmethod
    def _looks_like_tool_or_connector_request(message_lower: str) -> bool:
        """Detect whether message likely asks for tool/connector operations."""
        trigger_words = {
            "tool", "tools", "connector", "connect", "integration",
            "add", "remove", "create", "generate", "attach",
        }
        return any(word in message_lower for word in trigger_words)

    @staticmethod
    def _mentions_connector(message_lower: str) -> bool:
        """
        Detect a connector request so it can be routed to the right surface.

        WHAT: Matches connector vocabulary in the builder message.
        WHY:  Connectors are attached to the agent explicitly and are never
              converted into tools, so a connector request must produce
              guidance rather than a synthesised tool.
        INPUT: Lowercased builder message.
        OUTPUT: True when the message refers to a connector or integration.
        """
        return any(
            word in message_lower
            for word in ("connector", "connectors", "integration", "integrations")
        )

    @staticmethod
    def _contains_alias(message_lower: str, alias: str) -> bool:
        """
        Robust alias match with normalization and word boundaries.
        Prevents accidental partial matches when many similarly named tools exist.
        """
        if not alias:
            return False

        msg_norm = AgentDesigner._normalize_text(message_lower)
        alias_norm = AgentDesigner._normalize_text(alias)
        if not alias_norm:
            return False

        # Avoid matching ultra-short aliases that produce noisy hits.
        if len(alias_norm) < 3:
            return False

        # Token boundary match in normalized space-delimited text
        pattern = rf"(^| ){re.escape(alias_norm)}( |$)"
        return re.search(pattern, msg_norm) is not None

    # ---- done step ------------------------------------------------------

    def _chat_step_done(
        self,
        message: str,
        message_lower: str,
        agent_state: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Handle messages after the agent is finalized.

        A finalized agent is still editable — that is the point of a config
        chat that outlives the session. A message that already carries the
        change is applied on this turn rather than answered with "what would
        you like to change?", which would make the builder say it twice.
        """
        change_words = {"change", "update", "modify", "add", "remove", "edit"}
        if change_words & set(message_lower.split()):
            words = [w for w in message_lower.split() if w]
            if len(words) >= MIN_ACTIONABLE_CHANGE_WORDS:
                return self._chat_step_refine(
                    message, message_lower, agent_state, user_id=user_id
                )
            return {
                "reply": "Sure! What would you like to change?",
                "step": "refine",
                "action": "REOPEN_REFINE",
                "agent_state": agent_state,
            }

        return {
            "reply": (
                "Your agent is ready! Switch to the \"Configure\" tab to "
                "add tools and customize further, or save the agent to start using it."
            ),
            "step": "done",
            "action": "FINALIZED",
            "agent_state": agent_state,
        }

    @staticmethod
    def _has_selected_tools(agent_state: Dict[str, Any]) -> bool:
        tools = agent_state.get("tools")
        if isinstance(tools, dict):
            selected = tools.get("selected") or []
            return len(selected) > 0
        if isinstance(tools, list):
            return len(tools) > 0
        return False

    @staticmethod
    def _is_no_tools_confirmed(agent_state: Dict[str, Any]) -> bool:
        if bool(agent_state.get("no_tools_confirmed")):
            return True
        metadata = agent_state.get("metadata")
        if isinstance(metadata, dict) and bool(metadata.get("no_tools_confirmed")):
            return True
        return False

    @staticmethod
    def _set_no_tools_confirmation(agent_state: Dict[str, Any], value: bool) -> None:
        agent_state["no_tools_confirmed"] = bool(value)
        metadata = agent_state.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
            agent_state["metadata"] = metadata
        metadata["no_tools_confirmed"] = bool(value)

    @staticmethod
    def _is_explicit_no_tools_confirmation_message(message_lower: str) -> bool:
        explicit_patterns = (
            "confirm_no_tools_required",
            "save without tools",
            "this agent does not need tools",
            "no tools required",
            "without any tools",
        )
        return any(p in message_lower for p in explicit_patterns)

    # ---- helpers --------------------------------------------------------

    # Patterns used by the rule-based intent fallback classifier.
    _CONFIRMATION_PATTERNS = frozenset({
        "yes", "yeah", "yep", "yup", "sure", "ok", "okay",
        "looks good", "looks great", "lgtm", "done", "perfect",
        "great", "good", "fine", "confirm", "confirmed", "correct",
        "that works", "go ahead", "proceed", "finalize", "ship it",
    })
    _NEGATION_TOKENS = frozenset({
        "no", "not", "don't", "dont", "change", "update", "modify",
        "wrong", "different", "instead", "but",
    })
    _QUESTION_INDICATORS = frozenset({
        "?", "what", "how", "which", "can you", "could you",
        "tell me", "explain", "show", "why", "where",
    })

    @staticmethod
    def _rule_based_intent_fallback(user_message: str) -> Dict[str, Any]:
        """
        Classify intent using keyword heuristics when LLM classification fails.

        WHAT: Rule-based fallback that maps common phrases to intent categories.
        WHY: When the LLM is unavailable, blindly defaulting to MODIFICATION
             causes unintended side effects (e.g., 'yes' treated as a modification).
        INPUT: User message string.
        OUTPUT: Dict with intent, confidence (0.5), and reasoning.

        Args:
            user_message: Raw user message text.

        Returns:
            Dict with 'intent', 'confidence', and 'reasoning' keys.
        """
        msg = user_message.strip().lower()
        msg_tokens = set(msg.split())

        # Selection: message is a number (1-9) or ordinal
        stripped = msg.strip()
        if stripped.isdigit() and 1 <= int(stripped) <= 9:
            return {
                "intent": "SELECTION",
                "confidence": 0.5,
                "reasoning": "rule-based fallback: numeric selection",
            }
        ordinals = {"first", "second", "third", "fourth", "fifth"}
        if msg_tokens & ordinals:
            return {
                "intent": "SELECTION",
                "confidence": 0.5,
                "reasoning": "rule-based fallback: ordinal selection",
            }

        # Confirmation: positive signals without negation
        has_negation = bool(msg_tokens & AgentDesigner._NEGATION_TOKENS)
        if not has_negation:
            for pattern in AgentDesigner._CONFIRMATION_PATTERNS:
                if pattern in msg:
                    return {
                        "intent": "CONFIRMATION",
                        "confidence": 0.5,
                        "reasoning": "rule-based fallback: confirmation pattern",
                    }

        # Clarification: question-like patterns
        for indicator in AgentDesigner._QUESTION_INDICATORS:
            if indicator in msg:
                return {
                    "intent": "CLARIFICATION",
                    "confidence": 0.5,
                    "reasoning": "rule-based fallback: question indicator",
                }

        # Default: MODIFICATION (preserves existing behavior)
        return {
            "intent": "MODIFICATION",
            "confidence": 0.5,
            "reasoning": "rule-based fallback: default",
            "extracted_value": None,
        }

    def _classify_intent_safe(
        self, context: str, suggested_value: str, user_message: str
    ) -> Dict[str, Any]:
        """
        Classify intent via AgentService.classify_user_intent, with
        rule-based fallback on LLM failure.

        WHAT: Attempts LLM-based intent classification, falls back to rules.
        WHY: LLM failures should not cause wrong actions (e.g., treating
             'yes' as a modification request).
        INPUT: Context string, suggested value, user message.
        OUTPUT: Dict with intent, confidence, reasoning.

        Args:
            context: Conversation context label.
            suggested_value: The suggested/current value being confirmed.
            user_message: Raw user message.

        Returns:
            Classification result dict.
        """
        try:
            from echolib.di import container
            service = container.resolve("agent.service")
            result = service.classify_user_intent(
                context=context,
                suggested_value=suggested_value,
                user_message=user_message,
            )
            return result
        except Exception as e:
            logger.warning(f"Intent classification failed: {e}")
            # Delegate to service fallback which has context-aware logic;
            # fall back to rule-based only if service is unavailable.
            try:
                from echolib.di import container
                service = container.resolve("agent.service")
                return service._fallback_intent_classification(
                    user_message, suggested_value, context
                )
            except Exception:
                return self._rule_based_intent_fallback(user_message)

    def _get_all_tools_for_chat(self) -> List[Dict[str, Any]]:
        """
        Return the available tools list for chat responses.
        Reuses get_available_tools() and returns just the tools array.
        """
        result = self.get_available_tools()
        return result.get("tools", [])

    @staticmethod
    def _tool_ids_to_names(
        ids: list, all_tools: List[Dict[str, Any]]
    ) -> List[str]:
        """Resolve a list of tool IDs to display names."""
        lookup = {t["tool_id"]: t["name"] for t in all_tools}
        return [lookup.get(tid, tid.replace("_", " ")) for tid in ids]