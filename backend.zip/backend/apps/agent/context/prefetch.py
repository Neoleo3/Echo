"""
The retrieval that happens before the model's first turn.

WHAT: One query-scoped search across the agent's indexed files and every linked
      knowledge base, rendered as an evidence block for the system prompt.
WHY:  Everything else in this package makes retrieval *possible*. Nothing made
      it *happen*. An agent was handed ``files__search``, ``files__read`` and
      one ``kb__<alias>`` per base, plus a descriptor naming them, and then
      instructed to use them by ``factory/prompt.TOOL_EXECUTION_RULES``. Whether
      any of it was read was the model's decision.

      Inside a workflow node that decision goes the wrong way almost every
      time: ``build_agent_task`` hands the model a complete, self-contained task
      assembled from upstream output, and a model with a complete task answers
      it. The knowledge base resolved, the tool was bound, the descriptor was in
      the prompt -- and the run record shows zero calls against it. From the
      outside that is indistinguishable from "the connector is not wired up",
      which is how it was reported.

      Spec section 3 requirement 3 is that grounding must be deterministic
      "where possible -- not left to the model's own judgment inside its
      instructions". A tool the model may decline to call is exactly that
      judgment. This module is the deterministic half.

**Why here and not in a ``before_agent`` hook.** The request is already
available at build time: ``AgentFactory.build_with_context`` takes ``request``
and threads it to the readiness gate, and every runtime call site supplies it
(``AgentRuntime.chat``, ``StandaloneAgentRunner.prepare``, the workflow node in
``langchain_adapter``). Retrieving here puts the passages in the system prompt
that ``dynamic_prompt`` already builds, with no graph node, no state plumbing
and no second model round trip -- which is also what LangChain recommends over
forcing a tool call, since v1 ``create_agent`` no longer accepts a pre-bound
model with ``tool_choice``.

**What this is not.** It does not replace the tools. One pass on the opening
query cannot anticipate a follow-up, so the agent keeps ``files__search``,
``files__read`` and its ``kb__*`` tools and is told in the block below that it
may use them. Iterative retrieval stays available; only the floor is new.

Connectors are deliberately out of scope. An API, MCP server or database cannot
be pre-called without arguments, and their context already reaches the prompt
deterministically as descriptors -- ``connector/middleware/descriptors.py``
renders live table/column schemas and MCP manifests at build time.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from apps.markitdown import config as markitdown_config

from . import retrieval
from .naming import FILES_SEARCH_TOOL, kb_tool_name
from .refs import AgentContext

logger = logging.getLogger(__name__)

# A request shorter than this is not a query. Workflow nodes occasionally pass a
# bare marker ("ok", "run") as the task; embedding it retrieves noise and spends
# the budget that the real follow-up search would need.
MIN_QUERY_CHARS = 12

# Ceiling on the query handed to the embedder. Upstream workflow output can run
# to thousands of characters; the leading section carries the intent.
MAX_QUERY_CHARS = 2000

HEADER = (
    "Retrieved evidence. These passages were pulled from your attached sources "
    "for this specific request, before you were asked it. Ground your answer in "
    "them and cite the source name. They are a starting point, not the whole "
    "source: search again with the tools listed above if you need more, and if "
    "they do not cover the request, say so rather than filling the gap."
)

EMPTY_NOTE = (
    "Retrieved evidence: nothing in your attached sources matched this request "
    "on a first pass. Search again with different wording using the tools above "
    "before concluding the sources do not cover it. Do not answer from "
    "assumption and do not claim to have used a source you did not read."
)


def _query(request: str) -> str:
    """The text the pre-retrieval pass searches on, or empty when unusable."""
    text = (request or "").strip()
    if len(text) < MIN_QUERY_CHARS:
        return ""
    return text[:MAX_QUERY_CHARS]


def _render(sections: List[Tuple[str, List[Dict[str, Any]]]], budget: int) -> str:
    """
    Render the retrieved passages, newest source first, under one budget.

    Sources share the allowance rather than each claiming their own, for the
    same reason the descriptors do: context exhaustion is a property of the
    prompt. A source whose passages do not fit is named with the tool that
    reads it, so the model knows it exists and how to reach it.
    """
    blocks: List[str] = []
    deferred: List[str] = []
    used = 0

    for label, results in sections:
        if not results:
            continue

        lines = [f"### From {label}"]
        for index, entry in enumerate(results, start=1):
            lines.append(
                f"[{index}] {entry['source']} (relevance {entry['score']})\n"
                f"{entry['content']}"
            )
        block = "\n\n".join(lines)

        if used + len(block) > budget:
            deferred.append(label)
            continue

        blocks.append(block)
        used += len(block)

    if not blocks:
        return ""

    if deferred:
        blocks.append(
            f"Matching passages from {', '.join(deferred)} did not fit here. "
            f"Retrieve them with `{FILES_SEARCH_TOOL}` or the source's own "
            "search tool."
        )

    return "\n\n".join([HEADER, *blocks])


def prefetch_evidence(
    context: Optional[AgentContext],
    request: str,
    *,
    max_chars: Optional[int] = None,
    top_k: Optional[int] = None,
) -> Tuple[str, Dict[str, Any]]:
    """
    Retrieve from the agent's own sources for this request.

    WHAT: One ``files__search`` equivalent over the agent's indexed passages,
          plus one search per resolved knowledge base, rendered for the prompt.
    WHY:  See the module docstring -- this is the deterministic floor under
          model-elective retrieval.
    INPUT: The context resolved for this build and the user's request. Both
           must be present; neither is re-read from the database.
    OUTPUT: ``(block, stats)``. ``block`` is ``""`` when the pass did not run at
            all, the explicit :data:`EMPTY_NOTE` when it ran and matched
            nothing, and the rendered evidence otherwise. ``stats`` is
            identifiers and counts only, for the execution record.

    Never raises. A source that fails to search is logged and skipped: a
    retrieval that cannot run must degrade to the elective path, not fail the
    turn. Runs on the build thread, which ``AgentFactory`` already guarantees is
    not the event loop.
    """
    stats: Dict[str, Any] = {"ran": False}

    if context is None or context.empty:
        return "", stats

    if not markitdown_config.context_prefetch_enabled():
        stats["skipped"] = "disabled"
        return "", stats

    query = _query(request)
    if not query:
        # A preview build (the readiness endpoint) or a marker task. Nothing to
        # search on, and inventing a query would spend an embedding call to
        # retrieve noise.
        stats["skipped"] = "no_query"
        return "", stats

    searchable_files = context.searchable_file_ids()
    knowledge_bases = [kb for kb in context.knowledge_bases if kb.resolved]
    if not searchable_files and not knowledge_bases:
        # Everything attached is inline, still converting, or unavailable. The
        # descriptor already states which; there is nothing to retrieve from.
        stats["skipped"] = "no_searchable_source"
        return "", stats

    limit = int(top_k or markitdown_config.context_prefetch_top_k())
    sections: List[Tuple[str, List[Dict[str, Any]]]] = []
    matched = 0

    if searchable_files:
        try:
            results = retrieval.search_files(context, query, top_k=limit)
        except Exception:  # noqa: BLE001 -- degrade to the elective path
            logger.warning(
                "Pre-retrieval over attached files failed for agent '%s'; the "
                "agent keeps its search tools and can retrieve on its own.",
                context.agent_id, exc_info=True,
            )
            results = []
        if results:
            sections.append(("your attached documents", results))
            matched += len(results)

    for knowledge_base in knowledge_bases:
        label = knowledge_base.alias or knowledge_base.name
        try:
            results = retrieval.search_knowledge_base(
                context, knowledge_base, query, top_k=limit
            )
        except Exception:  # noqa: BLE001 -- one bad base cannot stop the rest
            logger.warning(
                "Pre-retrieval over knowledge base '%s' failed; the agent keeps "
                "`%s` and can retrieve on its own.",
                knowledge_base.knowledge_base_id,
                kb_tool_name(label),
                exc_info=True,
            )
            continue
        if results:
            sections.append((f"knowledge base '{label}'", results))
            matched += len(results)

    budget = int(max_chars or markitdown_config.context_prefetch_chars())
    block = _render(sections, budget)

    stats.update(
        {
            "ran": True,
            "files_searched": len(searchable_files),
            "knowledge_bases_searched": len(knowledge_bases),
            "passages": matched,
            "chars": len(block),
        }
    )

    if not block:
        # Stated, not silent. An agent that reads no evidence block as "there
        # was nothing to read" is the hallucination this whole package exists to
        # prevent -- the same reasoning as ``retrieval.render``'s empty note.
        logger.info(
            "Pre-retrieval for agent '%s' matched nothing across %d file "
            "source(s) and %d knowledge base(s)",
            context.agent_id, len(searchable_files), len(knowledge_bases),
        )
        return EMPTY_NOTE, stats

    logger.info(
        "Pre-retrieval for agent '%s': %d passage(s) from %d source group(s), "
        "%d chars",
        context.agent_id, matched, len(sections), len(block),
    )
    return block, stats


__all__ = ["EMPTY_NOTE", "prefetch_evidence"]
