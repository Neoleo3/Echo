"""
Resolve an agent's attached files, URLs and knowledge bases into live records.

WHAT: Turns ``definition.files[]`` and ``definition.knowledge_sources[]`` into
      ``ResolvedFile`` and ``ResolvedKnowledgeBase`` objects carrying current
      state from the registry.
WHY:  The definition holds stable identity only. Whether a document finished
      converting, how many chunks it produced, and whether image text could be
      read all live in ``agent_files`` and change after the definition was
      written. Descriptor rendering and retrieval both need the same joined
      view, resolved once per build — doing it twice is how a document ends up
      described but not searchable.

Every lookup is user-scoped, so an attachment naming another user's row
resolves to nothing and is reported as unavailable rather than silently read.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence

from apps.tool.async_bridge import run_async
from echolib.agent_contract import attached_files, attached_knowledge_sources

logger = logging.getLogger(__name__)

RESOLUTION_TIMEOUT_SECONDS = 30

STATUS_READY = "ready"
STATUS_FAILED = "failed"

MODE_INLINE = "inline"


@dataclass(frozen=True)
class ResolvedFile:
    """One attached file or URL, joined against its registry row."""

    file_id: str
    name: str
    source_type: str = "file"
    format: str = ""
    ingest_mode: str = "retrieval"
    status: str = "pending"
    url: Optional[str] = None
    content_md: Optional[str] = None
    char_count: int = 0
    chunk_count: int = 0
    converted_by: Optional[str] = None
    ocr_skipped_reason: Optional[str] = None
    error: Optional[str] = None

    @property
    def resolved(self) -> bool:
        """True when this source is usable by the model right now."""
        return self.error is None and self.status == STATUS_READY

    @property
    def is_inline(self) -> bool:
        return self.ingest_mode == MODE_INLINE

    @property
    def searchable(self) -> bool:
        """True when this source contributed passages to the agent's vector store."""
        return self.resolved and not self.is_inline and self.chunk_count > 0

    def record(self) -> Dict[str, Any]:
        """The dict shape ``apps.markitdown.read_text`` expects."""
        return {
            "source_id": self.file_id,
            "name": self.name,
            "source_type": self.source_type,
            "url": self.url,
            "content_md": self.content_md,
        }


@dataclass(frozen=True)
class ResolvedKnowledgeBase:
    """One knowledge base linked to the agent, joined against its row."""

    knowledge_base_id: str
    name: str
    alias: str = ""
    status: str = ""
    document_count: int = 0
    processing_type: str = "vector"
    search_type: str = "similarity"
    top_k: int = 5
    vector_weight: float = 0.5
    keyword_weight: float = 0.5
    embedding_model: Optional[str] = None
    error: Optional[str] = None
    # ``"application"`` when lent by an application for this turn, empty when it
    # is the agent's own link. Carried so a build can report which half
    # contributed what rather than one undifferentiated count.
    origin: str = ""
    # The account that owns the base. Its passages were embedded with that
    # account's embedding credential, so a query must be embedded there too --
    # under anyone else's credentials it lands in a different vector space, or
    # finds no embedding model at all.
    owner_user_id: Optional[str] = None

    @property
    def resolved(self) -> bool:
        return self.error is None


@dataclass(frozen=True)
class AgentContext:
    """Everything an agent has attached, resolved for one build."""

    files: List[ResolvedFile] = field(default_factory=list)
    knowledge_bases: List[ResolvedKnowledgeBase] = field(default_factory=list)
    agent_id: str = ""
    user_id: Optional[str] = None
    credential_id: Optional[str] = None
    # The resource principal the agent's own files were read under -- the
    # agent's owner. Their passages were embedded in that account, so a search
    # over them embeds its query there. ``None`` means the caller.
    owner_user_id: Optional[str] = None

    @property
    def empty(self) -> bool:
        return not self.files and not self.knowledge_bases

    def searchable_file_ids(self) -> List[str]:
        """Ids whose passages may be returned by a search on this build."""
        return [f.file_id for f in self.files if f.searchable]

    def inline_files(self) -> List[ResolvedFile]:
        return [f for f in self.files if f.resolved and f.is_inline]

    def by_name(self, name: str) -> Optional[ResolvedFile]:
        """Look a source up the way the model refers to it — by name."""
        wanted = str(name or "").strip().lower()
        if not wanted:
            return None
        for candidate in self.files:
            if candidate.name.lower() == wanted or candidate.file_id == name:
                return candidate
        for candidate in self.files:
            if wanted in candidate.name.lower():
                return candidate
        return None

    def describe(self) -> Dict[str, Any]:
        """
        Summarize this build's context surface for logs and step metadata.

        Identifiers, counts and outcomes only — never document text, so it is
        safe to persist alongside an execution record.
        """
        return {
            "files": len(self.files),
            "files_ready": sum(1 for f in self.files if f.resolved),
            "inline": sum(1 for f in self.files if f.resolved and f.is_inline),
            "indexed_chunks": sum(f.chunk_count for f in self.files if f.searchable),
            "knowledge_bases": len(self.knowledge_bases),
            "knowledge_resolved": sum(1 for k in self.knowledge_bases if k.resolved),
            "knowledge_detail": [
                {
                    "knowledge_base_id": k.knowledge_base_id,
                    "name": k.name,
                    "origin": k.origin or "agent",
                    "resolved": k.resolved,
                    "documents": k.document_count,
                    "error": k.error,
                }
                for k in self.knowledge_bases
            ],
            "sources": [
                {
                    "file_id": f.file_id,
                    "name": f.name,
                    "source_type": f.source_type,
                    "status": f.status,
                    "ingest_mode": f.ingest_mode,
                    "converted_by": f.converted_by,
                    "ocr_skipped_reason": f.ocr_skipped_reason,
                }
                for f in self.files
            ],
        }


# ---------------------------------------------------------------------------
# Registry reads
# ---------------------------------------------------------------------------

async def _load_file_rows(agent_id: str, user_id: str) -> Dict[str, Any]:
    """
    Read this agent's attachment rows, detached from the session.

    ``content_md`` is included because inline sources are injected into the
    prompt from it and ``files__read`` pages through it. ``content_bytes`` is
    not: the original is only needed to convert the source again, which the
    refresh path reads separately.
    """
    from echolib.database import get_db_session
    from echolib.repositories.agent_file_repo import AgentFileRepository

    async with get_db_session() as db:
        rows = await AgentFileRepository().list_for_agent(db, agent_id, user_id)
        # Detached before the session closes: the build path is synchronous and
        # would otherwise touch expired attributes.
        return {
            str(row.id): {
                "name": row.name,
                "source_type": row.source_type,
                "format": row.format or "",
                "ingest_mode": row.ingest_mode,
                "status": row.status,
                "url": row.url,
                "content_md": row.content_md,
                "char_count": row.char_count or 0,
                "chunk_count": row.chunk_count or 0,
                "converted_by": row.converted_by,
                "ocr_skipped_reason": row.ocr_skipped_reason,
                "error_message": row.error_message,
                "enabled": bool(row.enabled),
            }
            for row in rows
        }


async def _load_knowledge_rows(
    kb_ids: Sequence[str],
    principal_by_id: Mapping[str, Optional[str]],
) -> Dict[str, Any]:
    """
    Read the linked knowledge bases, each under the principal that authorised it.

    WHAT: Joins each linked id against ``knowledge_bases``, scoped to that
          entry's *resource principal* rather than to whoever is chatting.
    WHY:  Two different people can authorise a knowledge base, and the scope
          has to follow the one who did — never the caller. A base the *agent
          author* attached is read under the agent's owner; a base the
          *application owner* lent is read under the application's owner. The
          caller's identity governs which LLM credential resolves and what is
          billed, and nothing else.

    This is the defect that made an agent's own knowledge silently vanish. The
    read used to be scoped to the calling user, so a published application
    chatted by anyone other than the agent's author found no row, reported
    "this knowledge base is no longer available", and built no ``kb__<alias>``
    tool. The agent then truthfully answered that it had no knowledge, while
    the same base attached at *application* level worked — because that half
    was exempted and this half was not. Scope now derives from configuration
    time for both halves.

    ``principal_by_id`` maps each id to the user whose ownership authorises it.
    A ``None`` principal means "read without a user filter" and exists only as
    a compatibility path for an application contribution serialized before the
    owner travelled with it (a checkpointed workflow mid-run). It is never the
    scope chosen for a fresh resolution.
    """
    from echolib.database import get_db_session
    from echolib.models.knowledge import KnowledgeBase
    from echolib.repositories.base import safe_uuid
    from echolib.repositories.knowledge_repo import KnowledgeBaseRepository
    from sqlalchemy import select

    repo = KnowledgeBaseRepository()
    loaded: Dict[str, Any] = {}

    def _record(kb: Any) -> Dict[str, Any]:
        return {
            "name": kb.name,
            "status": kb.status,
            "document_count": len(kb.documents) if kb.documents else 0,
            "processing_type": kb.processing_type,
            "search_type": kb.search_type,
            "top_k": kb.top_k,
            "vector_weight": kb.vector_weight,
            "keyword_weight": kb.keyword_weight,
            "embedding_model": kb.embedding_model,
            "owner_user_id": str(kb.user_id) if kb.user_id else None,
        }

    async with get_db_session() as db:
        for kb_id in kb_ids:
            principal = principal_by_id.get(str(kb_id))
            try:
                if principal:
                    kb = await repo.get_by_id(db, kb_id, principal)
                else:
                    kb_uuid = safe_uuid(kb_id)
                    if kb_uuid is None:
                        continue
                    result = await db.execute(
                        select(KnowledgeBase).where(
                            KnowledgeBase.id == kb_uuid,
                            KnowledgeBase.is_deleted == False,  # noqa: E712
                        )
                    )
                    kb = result.scalar_one_or_none()
            except Exception:
                logger.warning("Knowledge base '%s' could not be read", kb_id, exc_info=True)
                kb = None
            if kb is None:
                continue
            loaded[str(kb.id)] = _record(kb)

    return loaded


def _on_event_loop() -> bool:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True


def _unresolved_context(
    entries: Sequence[Mapping[str, Any]],
    kb_entries: Sequence[Mapping[str, Any]],
    agent_id: str,
    reason: str,
) -> AgentContext:
    """Build a context where nothing resolved, so the model is told rather than left guessing."""
    return AgentContext(
        files=[
            ResolvedFile(
                file_id=str(entry.get("file_id") or ""),
                name=str(entry.get("name") or entry.get("file_id") or ""),
                source_type=str(entry.get("source_type") or "file"),
                format=str(entry.get("format") or ""),
                ingest_mode=str(entry.get("ingest_mode") or "retrieval"),
                error=reason,
            )
            for entry in entries
        ],
        knowledge_bases=[
            ResolvedKnowledgeBase(
                knowledge_base_id=str(entry.get("knowledge_base_id") or ""),
                name=str(entry.get("name") or ""),
                error=reason,
            )
            for entry in kb_entries
        ],
        agent_id=agent_id,
    )


def resolve_agent_context(
    agent_config: Optional[Mapping[str, Any]],
    user_id: Optional[str],
    *,
    owner_user_id: Optional[str] = None,
) -> Optional[AgentContext]:
    """
    Resolve everything attached to an agent, or ``None`` when nothing is.

    WHAT: Joins the definition's attachments against ``agent_files`` and
          ``knowledge_bases``.

    ``user_id`` is the **caller** — who is chatting. ``owner_user_id`` is the
    **resource principal** — who configured the attachment, and therefore whose
    ownership authorises reading it. They differ whenever a published agent is
    used by anyone but its author, which is every published application. Rows
    are read under the principal; the caller still governs credential
    resolution and billing, which is what it is actually for. Omitting
    ``owner_user_id`` falls back to the caller, preserving the behaviour of
    every path where the two are the same (the agent builder, standalone chat
    with one's own agent).
    WHY:  A descriptor built from the definition alone would describe a
          document that failed to convert, is still indexing, or was deleted.
    OUTPUT: An ``AgentContext``, or ``None`` when the agent has no attachments
            or Connector Settings is off. Failures are values on the resolved
            objects, never exceptions — one bad attachment cannot fail a build.

    Must not be called from a thread running an event loop: the registry reads
    are async and awaiting them from the loop thread would block the loop they
    need. That case fails immediately with the reason on every entry, so a
    mis-wired call site is a log line and a visible "unavailable" descriptor
    rather than a stalled request. Phase 5b.1 established the same rule for
    connectors; every agent build already runs in ``asyncio.to_thread``.
    """
    definition = dict(agent_config or {})
    entries = attached_files(definition)
    kb_entries = attached_knowledge_sources(definition)
    if not entries and not kb_entries:
        return None

    agent_id = str(definition.get("agent_id") or definition.get("id") or "")

    if not user_id:
        return _unresolved_context(
            entries, kb_entries, agent_id, "no user context available for this execution"
        )

    if _on_event_loop():
        logger.error(
            "Agent context resolution was called on the event loop thread. Build "
            "the agent inside asyncio.to_thread() -- the agent build is "
            "synchronous and blocks the loop for the whole model round trip "
            "regardless."
        )
        return _unresolved_context(
            entries, kb_entries, agent_id,
            "attachments are unavailable on this execution path",
        )

    # Files belong to the agent, so they are read under the agent's owner. Under
    # the caller they were invisible to everyone but the author — the same
    # defect as the knowledge bases below.
    principal = str(owner_user_id or user_id)

    try:
        rows = run_async(
            _load_file_rows(agent_id, principal), timeout=RESOLUTION_TIMEOUT_SECONDS
        )
    except Exception:
        logger.warning("Attached files could not be read for agent '%s'", agent_id, exc_info=True)
        rows = {}

    files: List[ResolvedFile] = []
    for entry in entries:
        file_id = str(entry.get("file_id") or "")
        row = rows.get(file_id)
        if row is None:
            files.append(
                ResolvedFile(
                    file_id=file_id,
                    name=str(entry.get("name") or file_id),
                    source_type=str(entry.get("source_type") or "file"),
                    format=str(entry.get("format") or ""),
                    ingest_mode=str(entry.get("ingest_mode") or "retrieval"),
                    error="this document is no longer available",
                )
            )
            continue

        status = str(row.get("status") or "pending")
        files.append(
            ResolvedFile(
                file_id=file_id,
                name=str(row.get("name") or entry.get("name") or file_id),
                source_type=str(row.get("source_type") or "file"),
                format=str(row.get("format") or ""),
                ingest_mode=str(row.get("ingest_mode") or "retrieval"),
                status=status,
                url=row.get("url"),
                content_md=row.get("content_md"),
                char_count=int(row.get("char_count") or 0),
                chunk_count=int(row.get("chunk_count") or 0),
                converted_by=row.get("converted_by"),
                ocr_skipped_reason=row.get("ocr_skipped_reason"),
                error=row.get("error_message") if status == STATUS_FAILED else None,
            )
        )

    knowledge_bases = _resolve_knowledge_bases(kb_entries, principal)

    unresolved = [f for f in files if not f.resolved]
    if unresolved:
        logger.warning(
            "%d of %d attached sources are not usable: %s",
            len(unresolved), len(files),
            ", ".join(f"{f.name}({f.error or f.status})" for f in unresolved),
        )

    return AgentContext(
        files=files,
        knowledge_bases=knowledge_bases,
        agent_id=agent_id,
        user_id=str(user_id),
        credential_id=str(definition.get("credential_id") or "") or None,
        owner_user_id=principal,
    )


def _resolve_knowledge_bases(
    entries: Sequence[Mapping[str, Any]], owner_user_id: str
) -> List[ResolvedKnowledgeBase]:
    """
    Join linked knowledge bases against their rows, each under its own principal.

    An entry the agent author attached is read under the agent's owner. An entry
    the application lent carries its own ``owner_user_id`` and is read under the
    application's owner — which is tighter than the unscoped read this replaces,
    not looser. A lent entry with no owner recorded is a contribution
    serialized before the owner travelled with it; it keeps the unscoped read so
    a workflow already mid-run is not broken by a deploy.
    """
    if not entries:
        return []

    from echolib.agent_contract import ORIGIN_APPLICATION

    kb_ids: List[str] = []
    principal_by_id: Dict[str, Optional[str]] = {}
    legacy_unscoped: List[str] = []

    for entry in entries:
        kb_id = str(entry.get("knowledge_base_id") or "")
        kb_ids.append(kb_id)
        if str(entry.get("origin") or "").lower() == ORIGIN_APPLICATION:
            lent_owner = str(entry.get("owner_user_id") or "").strip()
            principal_by_id[kb_id] = lent_owner or None
            if not lent_owner:
                legacy_unscoped.append(kb_id)
        else:
            principal_by_id[kb_id] = owner_user_id or None

    if legacy_unscoped:
        logger.info(
            "%d application knowledge base(s) carry no owner and are read "
            "unscoped for compatibility: %s",
            len(legacy_unscoped), ", ".join(legacy_unscoped),
        )

    try:
        rows = run_async(
            _load_knowledge_rows(kb_ids, principal_by_id),
            timeout=RESOLUTION_TIMEOUT_SECONDS,
        )
    except Exception:
        logger.warning("Linked knowledge bases could not be read", exc_info=True)
        rows = {}

    resolved: List[ResolvedKnowledgeBase] = []
    for entry in entries:
        kb_id = str(entry.get("knowledge_base_id") or "")
        origin = str(entry.get("origin") or "").lower()
        row = rows.get(kb_id)
        if row is None:
            resolved.append(
                ResolvedKnowledgeBase(
                    knowledge_base_id=kb_id,
                    name=str(entry.get("name") or kb_id),
                    error="this knowledge base is no longer available",
                    origin=origin,
                )
            )
            continue

        resolved.append(
            ResolvedKnowledgeBase(
                knowledge_base_id=kb_id,
                name=str(row.get("name") or kb_id),
                alias=str(entry.get("alias") or row.get("name") or kb_id),
                status=str(row.get("status") or ""),
                document_count=int(row.get("document_count") or 0),
                processing_type=str(row.get("processing_type") or "vector"),
                search_type=str(row.get("search_type") or "similarity"),
                top_k=int(row.get("top_k") or 5),
                vector_weight=float(row.get("vector_weight") or 0.5),
                keyword_weight=float(row.get("keyword_weight") or 0.5),
                embedding_model=row.get("embedding_model"),
                origin=origin,
                owner_user_id=row.get("owner_user_id"),
            )
        )

    return resolved


__all__ = [
    "AgentContext",
    "ResolvedFile",
    "ResolvedKnowledgeBase",
    "resolve_agent_context",
]
