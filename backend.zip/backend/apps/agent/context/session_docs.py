"""
Documents uploaded into a conversation, reachable as a tool.

WHAT: One ``AgentMiddleware`` that lets an agent *search* the files a user
      uploaded during this chat, instead of receiving them pre-pasted onto the
      front of its prompt.
WHY:  ``app-plan.md`` Cause 2c. The application pipeline retrieved document
      excerpts once per turn against the *user's* question and concatenated up
      to a hundred thousand characters onto every step's input. Two things go
      wrong with that. A sixty-page RFP arrives truncated, so the agent answers
      from the part that fitted. And the retrieval happened before the agent
      knew what it needed — an agent asked to "check the payment terms" gets
      whatever matched the user's opening sentence, and cannot go back for
      more.

This is the pattern production assistants use. Copilot Studio indexes uploaded
files into chunks and has the orchestrator *query* them when a request needs
grounding, rather than pushing them into the prompt; tools and knowledge are
selected at runtime from their descriptions. The agent here gets a short
descriptor naming the documents and one tool to search them, and decides for
itself when and how often to look.

**No new index.** The upload already built a session-scoped vector index
(``rag.session_manager``); this exposes it. Nothing is re-ingested, no table is
written, and an application that never uploads a file never constructs this
middleware.

**Resolved from the DI container, not passed in.** The middleware receives the
session id and the document names — plain strings, so a checkpointed workflow
can serialize the state that carries them — and looks the retrieval service up
by name at call time.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Callable, Dict, List, Optional, Sequence

from langchain.agents.middleware import AgentMiddleware

logger = logging.getLogger(__name__)

TOOL_NAME = "documents__search"
READ_TOOL_NAME = "documents__read"

DEFAULT_TOP_K = 10
DEFAULT_MAX_CALLS = 6
DEFAULT_RESULT_CHARS = 8000

# One paged read. Mirrors the equivalent ceiling on ``files__read`` so an
# uploaded document and an attached document page identically.
DEFAULT_READ_CHARS = 6000
MAX_READ_CHARS = 20000


def _int_env(name: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def new_session_doc_budget_state(max_calls: Optional[int] = None) -> Dict[str, Any]:
    """
    Create the shared per-run document-search budget.

    WHAT: The dict the search tool counts against and the middleware exposes as
          ``budget_state``.
    WHY:  ``AgentFactory._combined_tool_call_limit`` sums ``max_calls`` across
          every capability middleware, because the loop-level
          ``ToolCallLimitMiddleware`` counts *every* bound tool. A budget that
          lived only inside the tool's closure could not be read there.

    Mirrors ``new_budget_state`` in ``apps/agent/context/tools.py`` and
    ``apps/connector/middleware/tools.py``. ``seen`` holds query signatures
    already answered, which is this tool's own de-duplication and is not read
    by anything outside it.
    """
    return {
        "calls": 0,
        "max_calls": int(
            max_calls
            if max_calls is not None
            else _int_env("AGENT_SESSION_DOC_CALLS", DEFAULT_MAX_CALLS)
        ),
        "seen": set(),
    }


def _resolve_session_rag() -> Optional[Any]:
    """The session RAG manager, or ``None`` when it is not registered."""
    try:
        from echolib.di import container

        return container.resolve("rag.session_manager")
    except Exception:
        logger.debug("rag.session_manager is not registered", exc_info=True)
        return None


class SessionDocumentMiddleware(AgentMiddleware):
    """Carries the session-document search tool and its descriptor."""

    def __init__(
        self,
        chat_session_id: str,
        documents: Sequence[Dict[str, Any]],
        tools: Sequence[Any],
        *,
        budget_state: Optional[Dict[str, Any]] = None,
        context_block: str = "",
    ) -> None:
        self.chat_session_id = chat_session_id
        self.documents = list(documents)
        self.tools = list(tools)
        # The *same* dict the search tool counts against, never a copy: the
        # factory reads ``max_calls`` from here to size the loop-level tool
        # ceiling, and a duplicate would report a budget nothing enforces.
        self.budget_state = (
            budget_state if budget_state is not None else new_session_doc_budget_state()
        )
        self.context_block = context_block

    @property
    def name(self) -> str:
        return "SessionDocumentMiddleware"

    def describe(self) -> Dict[str, Any]:
        """Counts and filenames only — safe to persist on a run record."""
        return {
            "chat_session_id": self.chat_session_id,
            "documents": [d.get("name") for d in self.documents],
            "tools": len(self.tools),
        }


def _describe(documents: Sequence[Dict[str, Any]], *, can_read: bool = False) -> str:
    """Tell the model what it can reach, how, and that it must."""
    names = [str(d.get("name") or "").strip() for d in documents]
    names = [n for n in names if n]
    if not names:
        return ""

    listed = "\n".join(f"- {name}" for name in names)

    how = (
        f"Call `{TOOL_NAME}` to find specific passages. Search whenever a claim "
        "should come from these documents, and search again with different "
        "wording if the first result is not enough."
    )
    if can_read:
        # Naming which tool suits which task is what stops an agent trying to
        # summarize a sixty-page document out of three retrieved passages.
        how += (
            f"\n\nCall `{READ_TOOL_NAME}` instead when you need a document as a "
            "whole — to summarize it, review it end to end, or check it against "
            "a template or standard. It returns the text in order and can be "
            "called again with an offset to continue."
        )

    return (
        "## Documents in this conversation\n\n"
        "The user uploaded the following documents. Their full text is NOT in "
        "this prompt.\n\n"
        f"{listed}\n\n"
        f"{how}\n\n"
        "Never state a fact as coming from these documents unless a search or "
        "read returned it."
    )


def _build_tool(
    chat_session_id: str,
    *,
    budget_state: Dict[str, Any],
    on_tool_start: Optional[Callable[..., Optional[str]]],
    on_tool_end: Optional[Callable[..., None]],
    user_id: Optional[str] = None,
    application_id: Optional[str] = None,
) -> Optional[Any]:
    """
    Build the search tool, or ``None`` when the retrieval service is absent.

    ``budget_state`` is supplied by the caller and shared with the middleware,
    so the allowance this tool enforces is the same one the factory reads when
    it sizes the loop-level tool ceiling.

    ``user_id`` is what makes the search able to run at all: the query has to be
    embedded by the same model that embedded the passages, and every embedding
    model here is a user's own credential. Without it the retrieval returned
    nothing and looked exactly like a document that did not match.
    """
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field

    top_k = _int_env("AGENT_SESSION_DOC_TOP_K", DEFAULT_TOP_K)
    max_chars = _int_env("AGENT_SESSION_DOC_RESULT_CHARS", DEFAULT_RESULT_CHARS)

    state: Dict[str, Any] = budget_state

    class _Args(BaseModel):
        query: str = Field(
            description=(
                "What to look for, in the words you expect to find in the "
                "document. Be specific."
            )
        )

    def _search(query: str) -> str:
        cleaned = (query or "").strip()
        if not cleaned:
            return "Provide a query describing what to look for."

        # Read from the shared state rather than a captured local, so the
        # ceiling the factory published and the one enforced here cannot drift.
        max_calls = int(state.get("max_calls") or DEFAULT_MAX_CALLS)

        signature = cleaned.lower()
        if signature in state["seen"]:
            # Counted, not free. ToolCallLimitMiddleware has already charged the
            # graph for this call, so returning without charging it here let the
            # two counters diverge -- a model repeating one query could keep the
            # document budget at zero while consuming the graph's whole step
            # allowance, which is the loop that used to end in a recursion abort.
            state["calls"] += 1
            return (
                "That search was already run and returned what is above. "
                "Try different wording, or answer from what you have."
            )

        if state["calls"] >= max_calls:
            return (
                f"The document search budget of {max_calls} calls is used up. "
                "Answer from what you have retrieved, and say plainly what you "
                "could not verify."
            )

        manager = _resolve_session_rag()
        if manager is None:
            return "Document search is unavailable in this environment."

        state["calls"] += 1
        state["seen"].add(signature)

        if on_tool_start:
            try:
                on_tool_start(tool_name=TOOL_NAME, tool_input={"query": cleaned})
            except Exception:
                logger.debug("Document search start hook failed", exc_info=True)

        try:
            result = manager.retrieve(
                chat_session_id,
                cleaned,
                top_k=top_k,
                user_id=user_id,
                application_id=application_id,
            )
        except Exception as exc:  # noqa: BLE001 -- reported to the model
            logger.warning("Session document search failed: %s", exc, exc_info=True)
            result = ""
            output = f"The document search failed: {exc}"
        else:
            if result and str(result).strip():
                output = str(result)[:max_chars]
            else:
                output = (
                    "No passage in the uploaded documents matched that query. "
                    "The documents may not cover it — say so rather than "
                    "assuming."
                )

        if on_tool_end:
            try:
                on_tool_end(tool_name=TOOL_NAME, output=output)
            except Exception:
                logger.debug("Document search end hook failed", exc_info=True)

        return output

    return StructuredTool.from_function(
        func=_search,
        name=TOOL_NAME,
        description=(
            "Search the documents the user uploaded in this conversation and "
            "return the passages that match. Use this before answering any "
            "question about those documents."
        ),
        args_schema=_Args,
    )


def _build_read_tool(
    documents: Sequence[Dict[str, Any]],
    *,
    budget_state: Dict[str, Any],
    on_tool_start: Optional[Callable[..., Optional[str]]],
    on_tool_end: Optional[Callable[..., None]],
) -> Optional[Any]:
    """
    Build the whole-document read tool, or ``None`` when nothing can be read.

    WHAT: Pages through the markdown stored for an uploaded document, by name.
    WHY:  Similarity search is the wrong retrieval for "summarize this document"
          or "check this against the template" — the agent needs the text in
          order, not the passages nearest a query it had to invent. Attached
          agent files have had ``files__read`` for exactly this reason; a
          document uploaded into a conversation had only search, so a whole-
          document task could never be done properly.
    OUTPUT: ``None`` when no document carries an id to read by, which is every
            session that predates stored markdown.

    Reads are charged against the same budget as searches. They are the same
    resource from the model's side — one look at the documents — and two
    independent allowances would let a stuck agent alternate between them.
    """
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field

    readable = [
        d for d in documents
        if isinstance(d, dict) and d.get("document_id") and d.get("name")
    ]
    if not readable:
        return None

    by_name = {str(d["name"]).strip().lower(): str(d["document_id"]) for d in readable}
    names = [str(d["name"]) for d in readable]
    max_chars = _int_env("AGENT_SESSION_DOC_READ_CHARS", DEFAULT_READ_CHARS)
    state: Dict[str, Any] = budget_state

    class _ReadArgs(BaseModel):
        name: str = Field(
            description="The document's filename, exactly as listed in your context."
        )
        offset: Optional[int] = Field(
            default=None,
            description="Character position to start from. Use to read a long document in order.",
        )
        limit: Optional[int] = Field(
            default=None,
            description=f"How many characters to return. Default {max_chars}.",
        )

    def _resolve(name: str) -> Optional[str]:
        wanted = (name or "").strip().lower()
        if not wanted:
            return None
        if wanted in by_name:
            return by_name[wanted]
        # The model refers to documents the way a person does, so an exact match
        # is the common case but not the only one worth honouring.
        for candidate, document_id in by_name.items():
            if wanted in candidate or candidate in wanted:
                return document_id
        return None

    def _read(name: str, offset: Optional[int] = None, limit: Optional[int] = None) -> str:
        max_calls = int(state.get("max_calls") or DEFAULT_MAX_CALLS)
        if state["calls"] >= max_calls:
            return (
                f"The document budget of {max_calls} calls is used up. Answer "
                "from what you have read, and say plainly what you could not check."
            )

        document_id = _resolve(name)
        if document_id is None:
            listed = ", ".join(f"'{n}'" for n in names) or "none"
            return f"No uploaded document is named '{name}'. Available: {listed}."

        state["calls"] += 1

        if on_tool_start:
            try:
                on_tool_start(tool_name=READ_TOOL_NAME, tool_input={"name": name, "offset": offset})
            except Exception:
                logger.debug("Document read start hook failed", exc_info=True)

        span = max(1, min(int(limit or max_chars), MAX_READ_CHARS))
        start_at = max(0, int(offset or 0))

        try:
            stored = _load_document_markdown(document_id)
        except Exception as exc:  # noqa: BLE001 -- reported to the model
            logger.warning("Document read failed: %s", exc, exc_info=True)
            stored = None

        if not stored or not stored.get("content_md"):
            output = (
                f"'{name}' has no stored text to read. It may have been uploaded "
                "before documents were kept, or it could not be converted. "
                f"Try `{TOOL_NAME}` instead, and do not describe its contents "
                "unless something is returned."
            )
        else:
            body = str(stored["content_md"])[start_at:start_at + span]
            if not body:
                output = f"'{name}' has no readable text at that position."
            else:
                total = int(stored.get("char_count") or len(stored["content_md"]))
                end_at = start_at + len(body)
                more = ""
                if end_at < total:
                    more = (
                        f"\n\n… {total - end_at:,} more characters. Call "
                        f"`{READ_TOOL_NAME}` again with offset={end_at} to continue."
                    )
                output = f"{name} (characters {start_at:,}–{end_at:,}):\n\n{body}{more}"

        if on_tool_end:
            try:
                on_tool_end(tool_name=READ_TOOL_NAME, output=output)
            except Exception:
                logger.debug("Document read end hook failed", exc_info=True)

        return output

    listed = ", ".join(f"'{n}'" for n in names[:10])
    return StructuredTool.from_function(
        func=_read,
        name=READ_TOOL_NAME,
        description=(
            "Read an uploaded document in order, from the start or from a "
            "character offset. Use this to summarize, review or compare a whole "
            f"document rather than searching it. Available: {listed}."
        ),
        args_schema=_ReadArgs,
    )


def _load_document_markdown(document_id: str) -> Optional[Dict[str, Any]]:
    """Read one document's stored markdown, bridging to the database."""
    from echolib.database import get_db_session, run_db_coro_sync
    from echolib.repositories.application_chat_repo import ApplicationChatRepository

    async def _read() -> Optional[Dict[str, Any]]:
        async with get_db_session() as db:
            return await ApplicationChatRepository().get_document_markdown(
                db, document_id
            )

    return run_db_coro_sync(_read)


def build_session_document_middleware(
    agent_config: Optional[Dict[str, Any]],
    *,
    user_id: Optional[str] = None,
    on_tool_start: Optional[Callable[..., Optional[str]]] = None,
    on_tool_end: Optional[Callable[..., None]] = None,
) -> Optional[SessionDocumentMiddleware]:
    """
    Build the session-document middleware, or ``None`` when there is nothing.

    WHAT: Reads ``session_documents`` and ``_chat_session_id`` — written into
          the definition by the application's context merge — and returns a
          middleware carrying one search tool.
    WHY:  ``AgentFactory`` needs a single call that yields a middleware or
          nothing, so it never grows document-specific branching.
    OUTPUT: ``None`` for any agent with no session documents, which is every
            agent outside an application chat. Never raises.
    """
    config = agent_config or {}
    documents = config.get("session_documents")
    chat_session_id = str(config.get("_chat_session_id") or "").strip()
    application_id = str(config.get("_application_id") or "").strip() or None

    if not isinstance(documents, list) or not documents or not chat_session_id:
        return None

    entries = [d for d in documents if isinstance(d, dict) and d.get("name")]
    if not entries:
        return None

    budget = new_session_doc_budget_state()
    tools: List[Any] = []

    search_tool = _build_tool(
        chat_session_id,
        budget_state=budget,
        on_tool_start=on_tool_start,
        on_tool_end=on_tool_end,
        user_id=user_id,
        application_id=application_id,
    )
    if search_tool is not None:
        tools.append(search_tool)

    read_tool = _build_read_tool(
        entries,
        budget_state=budget,
        on_tool_start=on_tool_start,
        on_tool_end=on_tool_end,
    )
    if read_tool is not None:
        tools.append(read_tool)

    logger.info(
        "Session document middleware: %d document(s) for session %s, %d tool(s) "
        "(budget %d calls)",
        len(entries), chat_session_id, len(tools), budget["max_calls"],
    )
    return SessionDocumentMiddleware(
        chat_session_id,
        entries,
        tools,
        budget_state=budget,
        context_block=_describe(entries, can_read=read_tool is not None),
    )


__all__ = [
    "READ_TOOL_NAME",
    "TOOL_NAME",
    "SessionDocumentMiddleware",
    "build_session_document_middleware",
    "new_session_doc_budget_state",
]
