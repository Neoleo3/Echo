"""
The tools that let an agent read its attached context.

WHAT: ``files__search``, ``files__read`` and one ``kb__<alias>`` per linked
      knowledge base.
WHY:  A descriptor tells the model a document exists; these are what let it
      read the actual content instead of reasoning from the description. Spec
      section 3 — "no hallucinated execution" — is only satisfied when the two
      exist together.

Why these calls do not share the ``execution_policy`` tool budget: that policy
allows three tool calls per run and blocks a second call to the same tool,
which suits one-shot enrichment tools. Reading a document is iterative — search,
read the section that matched, search again with better terms — so it gets its
own allowance with duplicate-input suppression instead of once-per-tool
suppression. The same reasoning the connector middleware applies, for the same
reason.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Callable, Dict, List, Mapping, Optional

from apps.markitdown import config as markitdown_config

from . import retrieval
from .naming import FILES_READ_TOOL, FILES_SEARCH_TOOL, kb_tool_name
from .refs import AgentContext, ResolvedKnowledgeBase

logger = logging.getLogger(__name__)

DEFAULT_READ_CHARS = 6000
MAX_READ_CHARS = 20000

NO_MATCH_NOTE = (
    "No passage in the attached documents matched that query. Do not answer "
    "from assumption: say the documents do not cover it, or try a different "
    "wording."
)


def new_budget_state(max_calls: Optional[int] = None) -> Dict[str, Any]:
    """Create the shared per-run context-call budget."""
    return {
        "calls": 0,
        "max_calls": int(max_calls or markitdown_config.context_call_limit()),
        "signatures": set(),
        "failures": 0,
    }


def _signature(name: str, kwargs: Mapping[str, Any]) -> str:
    try:
        return f"{name}:{json.dumps(kwargs, sort_keys=True, default=str)}"
    except (TypeError, ValueError):
        return f"{name}:{kwargs}"


def _reserve(state: Dict[str, Any], name: str, kwargs: Mapping[str, Any]) -> Optional[str]:
    """
    Take one unit of budget, or explain why the call is refused.

    Duplicate suppression is by exact input signature: the same query over the
    same documents cannot return something different within one run, and
    repeating it is the shape a stuck agent loops in.
    """
    if state["calls"] >= state["max_calls"]:
        return (
            f"Document read budget exhausted for this run ({state['max_calls']} "
            "calls). Answer from what you already retrieved and state clearly "
            "what you could not check."
        )

    signature = _signature(name, kwargs)
    if signature in state["signatures"]:
        return (
            "This exact search was already made in this run and returned the "
            "same result. Use the earlier result, or search for something else."
        )

    state["calls"] += 1
    state["signatures"].add(signature)
    return None


def _hooks(
    name: str,
    label: str,
    on_tool_start: Optional[Callable[..., Optional[str]]],
    on_tool_end: Optional[Callable[..., None]],
):
    """Wrap the observability hooks so a broken hook never fails a read."""

    def start(kwargs: Dict[str, Any]) -> Optional[str]:
        if on_tool_start is None:
            return None
        try:
            return on_tool_start(name, label, kwargs)
        except Exception:
            logger.debug("on_tool_start hook failed for '%s'", name, exc_info=True)
            return None

    def end(step_id: Optional[str], payload: Any) -> None:
        if on_tool_end is None or step_id is None:
            return
        try:
            on_tool_end(step_id, payload)
        except Exception:
            logger.debug("on_tool_end hook failed for '%s'", name, exc_info=True)

    return start, end


# ---------------------------------------------------------------------------
# Argument schemas
# ---------------------------------------------------------------------------

def _model(model_name: str, /, **fields: Any) -> Any:
    """
    Build a pydantic args model from ``field=(type, Field(...))`` pairs.

    The first parameter is positional-only: one of the tool arguments below is
    itself called ``name``, which would otherwise collide with it.
    """
    from pydantic import create_model

    return create_model(model_name, **fields)


def _search_args(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        query=(str, Field(..., description="What to look for, in your own words.")),
        top_k=(
            Optional[int],
            Field(None, description="How many passages to return. Default 5."),
        ),
    )


def _read_args(name: str) -> Any:
    from pydantic import Field

    return _model(
        f"{name}_Args",
        name=(str, Field(..., description="The document's name, exactly as listed in your attached context.")),
        offset=(
            Optional[int],
            Field(None, description="Character position to start from. Use to read a long document in order."),
        ),
        limit=(
            Optional[int],
            Field(None, description=f"How many characters to return. Default {DEFAULT_READ_CHARS}."),
        ),
    )


def _structured_tool(name: str, description: str, func: Callable[..., str], args_schema: Any) -> Any:
    from langchain_core.tools import StructuredTool

    return StructuredTool.from_function(
        func=func, name=name, description=description, args_schema=args_schema
    )


# ---------------------------------------------------------------------------
# Tool bodies
# ---------------------------------------------------------------------------

def _make_search_files(context: AgentContext, budget: Dict[str, Any], start, end) -> Callable[..., str]:
    def _call(query: str, top_k: Optional[int] = None) -> str:
        step_id = start({"query": query, "top_k": top_k})

        refusal = _reserve(budget, FILES_SEARCH_TOOL, {"query": query, "top_k": top_k})
        if refusal:
            end(step_id, refusal)
            return refusal

        results = retrieval.search_files(context, query, top_k=top_k)
        text = retrieval.render(results, empty_note=NO_MATCH_NOTE)
        end(step_id, text)
        logger.info("files__search returned %d passage(s)", len(results))
        return text

    _call.__name__ = FILES_SEARCH_TOOL
    return _call


def _make_read_file(context: AgentContext, budget: Dict[str, Any], start, end) -> Callable[..., str]:
    def _call(name: str, offset: Optional[int] = None, limit: Optional[int] = None) -> str:
        step_id = start({"name": name, "offset": offset})

        refusal = _reserve(budget, FILES_READ_TOOL, {"name": name, "offset": offset, "limit": limit})
        if refusal:
            end(step_id, refusal)
            return refusal

        source = context.by_name(name)
        if source is None:
            available = ", ".join(f.name for f in context.files) or "none"
            message = (
                f"No attached document is named '{name}'. Attached documents: {available}."
            )
            end(step_id, message)
            return message

        if not source.resolved:
            message = (
                f"'{source.name}' cannot be read: {source.error or source.status}. "
                "Do not describe its contents."
            )
            end(step_id, message)
            return message

        from apps.markitdown import read_text

        span = max(1, min(int(limit or DEFAULT_READ_CHARS), MAX_READ_CHARS))
        start_at = max(0, int(offset or 0))
        body = read_text(source.record(), offset=start_at, limit=span)

        if not body:
            message = f"'{source.name}' has no readable text at that position."
            end(step_id, message)
            return message

        end_at = start_at + len(body)
        more = ""
        if source.char_count and end_at < source.char_count:
            more = (
                f"\n\n… {source.char_count - end_at:,} more characters. "
                f"Call `{FILES_READ_TOOL}` again with offset={end_at} to continue."
            )

        text = f"{source.name} (characters {start_at:,}–{end_at:,}):\n\n{body}{more}"
        end(step_id, text)
        return text

    _call.__name__ = FILES_READ_TOOL
    return _call


def _make_search_kb(
    context: AgentContext,
    knowledge_base: ResolvedKnowledgeBase,
    name: str,
    budget: Dict[str, Any],
    start,
    end,
) -> Callable[..., str]:
    def _call(query: str, top_k: Optional[int] = None) -> str:
        step_id = start({"query": query, "top_k": top_k})

        refusal = _reserve(budget, name, {"query": query, "top_k": top_k})
        if refusal:
            end(step_id, refusal)
            return refusal

        results = retrieval.search_knowledge_base(context, knowledge_base, query, top_k=top_k)
        text = retrieval.render(
            results,
            empty_note=(
                f"Nothing in '{knowledge_base.name}' matched that query. Say so "
                "rather than answering from assumption."
            ),
        )
        end(step_id, text)
        return text

    _call.__name__ = name
    return _call


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

def _unique_tool_name(base: str, taken: set, *, limit: int = 20) -> Optional[str]:
    """
    A tool name no other tool on this build is using.

    WHAT: ``base`` when it is free, otherwise ``base_2``, ``base_3``, ...
    WHY:  An agent inside an application carries its own knowledge bases and the
          application's, and two differently-named bases can slugify to the same
          alias. Dropping the loser meant one of them silently had no search
          tool at all while still being described — the model was told it could
          search something it could not. Suffixing keeps both reachable.
    OUTPUT: The name, or ``None`` when even the suffixed forms are exhausted,
            which the caller reports rather than papering over.
    """
    if base not in taken:
        return base
    for index in range(2, limit + 2):
        candidate = f"{base}_{index}"
        if candidate not in taken:
            return candidate
    return None


def build_context_tools(
    context: Optional[AgentContext],
    *,
    budget_state: Optional[Dict[str, Any]] = None,
    on_tool_start: Optional[Callable[..., Optional[str]]] = None,
    on_tool_end: Optional[Callable[..., None]] = None,
) -> List[Any]:
    """
    Build every tool for the agent's attached context.

    WHAT: A search tool when anything is indexed, a read tool when any source
          resolved, and one search tool per linked knowledge base.
    WHY:  ``create_agent`` collects ``middleware.tools`` at compile time, so
          this is what puts documents in front of the model.
    OUTPUT: A flat list. Sources that failed contribute nothing — they are
            described as unavailable instead, so the model is told rather than
            left to guess why it cannot read them.
    """
    if context is None or context.empty:
        return []

    budget = budget_state if budget_state is not None else new_budget_state()
    tools: List[Any] = []

    readable = [f for f in context.files if f.resolved]

    if context.searchable_file_ids():
        start, end = _hooks(
            FILES_SEARCH_TOOL, "attached documents · search", on_tool_start, on_tool_end
        )
        tools.append(
            _structured_tool(
                FILES_SEARCH_TOOL,
                "Search the documents and web pages attached to you and return "
                "the passages that match. Use this before answering anything the "
                "attached documents could cover.",
                _make_search_files(context, budget, start, end),
                _search_args(FILES_SEARCH_TOOL),
            )
        )

    if readable:
        names = ", ".join(f"'{f.name}'" for f in readable[:10])
        start, end = _hooks(
            FILES_READ_TOOL, "attached documents · read", on_tool_start, on_tool_end
        )
        tools.append(
            _structured_tool(
                FILES_READ_TOOL,
                "Read an attached document in order, from the start or from a "
                "character offset. Use this to summarize or review a whole "
                f"document. Attached: {names}.",
                _make_read_file(context, budget, start, end),
                _read_args(FILES_READ_TOOL),
            )
        )

    seen = {tool.name for tool in tools}
    for knowledge_base in context.knowledge_bases:
        if not knowledge_base.resolved:
            continue
        name = _unique_tool_name(
            kb_tool_name(knowledge_base.alias or knowledge_base.name), seen
        )
        if name is None:
            logger.warning(
                "Knowledge base '%s' could not be given a distinct tool name; "
                "it is described but not searchable this build.",
                knowledge_base.name,
            )
            continue
        seen.add(name)

        start, end = _hooks(
            name, f"{knowledge_base.name} · search", on_tool_start, on_tool_end
        )
        tools.append(
            _structured_tool(
                name,
                f"Search the '{knowledge_base.name}' knowledge base and return "
                "the passages that match.",
                _make_search_kb(context, knowledge_base, name, budget, start, end),
                _search_args(name),
            )
        )

    logger.info(
        "Built %d context tool(s) from %d source(s) and %d knowledge base(s)",
        len(tools), len(context.files), len(context.knowledge_bases),
    )
    return tools


__all__ = ["build_context_tools", "new_budget_state"]
