"""
Tool names for the agent's attached context.

WHAT: The fixed names of the file tools, and the derived name of a linked
      knowledge base's search tool.
WHY:  Descriptors reference these names and the tool layer registers them.
      Deriving both from one module is what guarantees a descriptor can never
      point the model at a tool that was not registered — the same rule the
      connector middleware follows.
"""
from __future__ import annotations

import re

FILES_SEARCH_TOOL = "files__search"
FILES_READ_TOOL = "files__read"

KB_PREFIX = "kb"

MAX_SLUG_LENGTH = 24
MAX_TOOL_NAME_LENGTH = 64

_UNSAFE = re.compile(r"[^0-9A-Za-z]+")


def slugify(value: str, *, max_length: int = MAX_SLUG_LENGTH) -> str:
    """Reduce arbitrary text to a lower-case identifier fragment."""
    cleaned = _UNSAFE.sub("_", str(value or "")).strip("_").lower()
    cleaned = re.sub(r"_+", "_", cleaned)
    return cleaned[:max_length].strip("_") or "source"


def kb_tool_name(alias: str) -> str:
    """Search tool name for one linked knowledge base: ``kb__sales``."""
    return f"{KB_PREFIX}__{slugify(alias)}"[:MAX_TOOL_NAME_LENGTH]


__all__ = [
    "FILES_READ_TOOL",
    "FILES_SEARCH_TOOL",
    "KB_PREFIX",
    "MAX_TOOL_NAME_LENGTH",
    "kb_tool_name",
    "slugify",
]
