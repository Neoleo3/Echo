"""
Agent Context Middleware -- how an agent reaches its attached documents.

WHAT: One ``AgentMiddleware`` carrying the retrieval tools for an agent's
      attached files, URLs and linked knowledge bases, plus the descriptor
      block that names them.
WHY:  Before Phase 6 an agent could not see a file at all. Files existed in
      four disconnected surfaces -- Convobi's ``uploaded_files``, Agentic
      Applications' ``agentic_uploaded_files``, application chat's
      ``application_documents`` and the knowledge pipeline's
      ``knowledge_documents`` -- and none of them reached the agent layer. A
      document was context for the request that uploaded it, never for the
      agent.

Attachment now lives on the agent (``definition.files[]`` and
``definition.knowledge_sources[]``) and this is the only path from there to
readable content. Because ``AgentFactory.build`` is the single instantiation
path, registering the middleware there is what makes an attached document part
of *every* execution -- standalone chat, a workflow node, a HITL node, an
application component -- with no per-caller work.

Two responsibilities, mirroring the Connector Middleware:

1. **Context exposure at build time** -- ``descriptors`` renders what each
   source is and how to read it, and inlines the text of short ones.
2. **Runtime retrieval** -- ``tools`` registers ``files__search``,
   ``files__read`` and one search tool per linked knowledge base.

Gating: Connector Settings is off by default per agent (spec section 6.1,
"a user can only upload a file or attach a connector after explicitly toggling
Connector Settings on"). The contract's ``attached_files`` returns nothing while
it is off, so an agent whose toggle is off gets no descriptors and no tools
whatever its definition contains.

Conversion, chunking and embedding are owned by ``apps/markitdown``. Nothing
here parses a document. Storage is Postgres — ``agent_files`` and
``agent_file_chunks`` — because the platform runs on cloud containers with more
than one replica and no shared disk.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Sequence

from langchain.agents.middleware import AgentMiddleware

from .descriptors import describe_context
from .prefetch import prefetch_evidence
from .refs import AgentContext, ResolvedFile, ResolvedKnowledgeBase, resolve_agent_context
from .tools import build_context_tools, new_budget_state

logger = logging.getLogger(__name__)


class AgentContextMiddleware(AgentMiddleware):
    """
    Registers the agent's context tools and reports their descriptor.

    Resolved once per build. ``AgentFactory.build`` runs per invocation, so
    "once per build" is also "once per turn" -- a document attached a moment ago
    is readable on the next message, with no cache to invalidate.
    """

    def __init__(
        self,
        context: AgentContext,
        tools: Sequence[Any],
        *,
        budget_state: Optional[Dict[str, Any]] = None,
        context_block: str = "",
        prefetch: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.context = context
        self.tools = list(tools)
        self.budget_state = budget_state if budget_state is not None else new_budget_state()
        self.context_block = context_block
        # Outcome of the pre-retrieval pass. Counts only; the passages
        # themselves are in the prompt, never in the execution record.
        self.prefetch = dict(prefetch or {"ran": False})

    @property
    def name(self) -> str:
        return "AgentContextMiddleware"

    def describe(self) -> Dict[str, Any]:
        """
        Summarize this build's context surface for logs and step metadata.

        Identifiers, counts and outcomes only -- never document text -- so it is
        safe to persist alongside an execution record.
        """
        summary = self.context.describe()
        summary["tools"] = len(self.tools)
        summary["prefetch"] = dict(self.prefetch)
        return summary


def build_agent_context_middleware(
    agent_config: Optional[Dict[str, Any]],
    *,
    user_id: Optional[str] = None,
    owner_user_id: Optional[str] = None,
    budget_state: Optional[Dict[str, Any]] = None,
    on_tool_start: Optional[Callable[..., Optional[str]]] = None,
    on_tool_end: Optional[Callable[..., None]] = None,
    token_budget: Optional[int] = None,
    request: str = "",
) -> Optional[AgentContextMiddleware]:
    """
    Build the context middleware for one agent, or ``None`` when it has none.

    WHAT: Resolves attachments, renders descriptors, retrieves for this request,
          builds retrieval tools.
    WHY:  ``AgentFactory`` needs one call that either yields a middleware or
          nothing, so the factory never grows document-specific branching.
    INPUT: An agent definition, the acting user, the owner whose ownership
           authorises the agent's own attachments, the shared context budget,
           the observability hooks, this build's share of the descriptor
           budget, and the request being answered. ``owner_user_id`` defaults
           to the caller, which is correct wherever the agent is being run by
           its author.
    OUTPUT: ``AgentContextMiddleware`` or ``None``. ``None`` when the agent has
            nothing attached or Connector Settings is off; a middleware with
            zero tools when attachments exist but none resolved, because the
            descriptor still has to tell the model those sources are
            unavailable rather than leaving it to guess.

    ``request`` drives the pre-retrieval pass (see :mod:`.prefetch`), which is
    what makes an attached source contribute without the model having to choose
    to call a tool. Omitting it -- as the readiness preview endpoint does --
    yields descriptors and tools exactly as before, and spends nothing.
    """
    context = resolve_agent_context(
        agent_config, user_id, owner_user_id=owner_user_id
    )
    if context is None:
        return None

    budget = budget_state if budget_state is not None else new_budget_state()
    tools = build_context_tools(
        context,
        budget_state=budget,
        on_tool_start=on_tool_start,
        on_tool_end=on_tool_end,
    )
    block = describe_context(context, token_budget=token_budget)

    # Deterministic grounding. Appended after the descriptors so the model reads
    # what each source *is* before it reads what was pulled from them, and
    # before the execution rules, which the factory's prompt builder places
    # after the whole attached-context block.
    evidence, prefetch_stats = prefetch_evidence(context, request)
    if evidence:
        block = "\n\n".join(part for part in (block, evidence) if part)

    # Knowledge is split by origin for the same reason connectors are: a bare
    # "0 knowledge bases" cannot distinguish an agent that lost its own link
    # from an application that lent none, and those have different fixes.
    from echolib.agent_contract import ORIGIN_APPLICATION

    own_kb = [k for k in context.knowledge_bases if k.origin != ORIGIN_APPLICATION]
    lent_kb = [k for k in context.knowledge_bases if k.origin == ORIGIN_APPLICATION]

    logger.info(
        "Agent context middleware: %d source(s), %d ready, knowledge own %d/%d "
        "resolved + application %d/%d resolved, %d tool(s), %d descriptor chars, "
        "prefetch=%s",
        len(context.files),
        sum(1 for f in context.files if f.resolved),
        sum(1 for k in own_kb if k.resolved), len(own_kb),
        sum(1 for k in lent_kb if k.resolved), len(lent_kb),
        len(tools),
        len(block),
        prefetch_stats.get("skipped") or ("%d passage(s)" % prefetch_stats.get("passages", 0)
                                          if prefetch_stats.get("ran") else "not run"),
    )

    # An attachment that exists and did not resolve is the failure this whole
    # surface is built to make visible. Named individually, with the reason, so
    # a silent empty context is never mistaken for an agent that was configured
    # with nothing.
    unresolved = [k for k in context.knowledge_bases if not k.resolved]
    if unresolved:
        logger.warning(
            "%d of %d linked knowledge base(s) did not resolve: %s",
            len(unresolved), len(context.knowledge_bases),
            ", ".join(
                f"{k.name}[{k.origin or 'agent'}]({k.error})" for k in unresolved
            ),
        )

    return AgentContextMiddleware(
        context,
        tools,
        budget_state=budget,
        context_block=block,
        prefetch=prefetch_stats,
    )


from .session_docs import (
    SessionDocumentMiddleware,
    build_session_document_middleware,
    new_session_doc_budget_state,
)

__all__ = [
    "AgentContext",
    "AgentContextMiddleware",
    "ResolvedFile",
    "ResolvedKnowledgeBase",
    "SessionDocumentMiddleware",
    "build_agent_context_middleware",
    "build_context_tools",
    "build_session_document_middleware",
    "describe_context",
    "new_session_doc_budget_state",
    "prefetch_evidence",
    "resolve_agent_context",
]
