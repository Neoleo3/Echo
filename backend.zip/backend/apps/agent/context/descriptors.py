"""
What the model is told about the agent's attached documents.

WHAT: Renders one block naming every attached file, URL and knowledge base,
      how to read each one, and — for short sources — the text itself.
WHY:  A tool name alone tells a model nothing about which document answers
      which question. Without a descriptor it either guesses or invents. This
      is also where an unusable source is stated as unusable, which is what
      stops an agent citing a document it could never read.

Two budgets, deliberately separate:

* **Descriptors** share one allowance with connector descriptors, because
  context exhaustion is a property of the whole prompt. What does not fit is
  reported as an explicit omission, never dropped silently.
* **Inline document text** has its own allowance. A descriptor is metadata the
  platform generates and may trim freely; inline content is a document the user
  deliberately attached, and quietly halving it would have the agent answer
  from part of a memo without knowing it. Sources that do not fit stay attached
  and stay readable through ``files__read``.
"""
from __future__ import annotations

import logging
from typing import List, Optional, Sequence

from apps.markitdown import config as markitdown_config

from .naming import FILES_READ_TOOL, FILES_SEARCH_TOOL, kb_tool_name
from .refs import AgentContext, ResolvedFile, ResolvedKnowledgeBase

logger = logging.getLogger(__name__)

CHARS_PER_TOKEN = 4
DEFAULT_TOKEN_BUDGET = 900
MIN_CHARS_PER_SOURCE = 120

HEADER = (
    "Attached context. The documents and sources below are attached to you and "
    "are part of every conversation you have. Read them before answering "
    "anything they could cover. Never state or imply that you have read a "
    "source listed here as unavailable, and never invent its contents."
)

OCR_REASONS = {
    "model_not_vision_capable": (
        "images in this document were not read, because the configured model "
        "cannot read images"
    ),
    "no_llm_credential_configured": (
        "images in this document were not read, because no model is configured "
        "for it"
    ),
    "provider_not_openai_compatible": (
        "images in this document were not read, because the configured provider "
        "does not support image input"
    ),
    "ocr_disabled_by_configuration": "image reading is switched off on this server",
    "vision_client_could_not_be_built": "images in this document could not be read",
    "pdf_unreadable": "the page images in this document could not be rendered",
}


def _truncate(text: str, max_chars: int, *, marker: str = "\n… description truncated") -> str:
    if len(text) <= max_chars:
        return text
    keep = max(0, max_chars - len(marker))
    return text[:keep].rstrip() + marker


def _status_note(source: ResolvedFile) -> Optional[str]:
    """Say plainly why a source cannot be used, when it cannot."""
    if source.error:
        return f"Unavailable: {source.error}."
    if source.status == "pending":
        return "Still being processed. It is not readable yet — say so rather than guessing at its contents."
    if source.status == "processing":
        return "Being processed right now. It is not readable yet — say so rather than guessing at its contents."
    if source.status != "ready":
        return f"Not ready ({source.status})."
    return None


def _describe_file(source: ResolvedFile) -> List[str]:
    """One source's descriptor lines, without its inline body."""
    kind = "web page" if source.source_type == "url" else (source.format or "file")
    lines = [f"### {source.name} ({kind})"]

    note = _status_note(source)
    if note:
        lines.append(f"- {note} Do not claim to have used it.")
        return lines

    if source.url:
        lines.append(f"- Address: {source.url}")

    if source.is_inline:
        lines.append("- Full text is included below.")
    elif source.chunk_count:
        lines.append(
            f"- Indexed in {source.chunk_count} passage(s). Search it with "
            f"`{FILES_SEARCH_TOOL}`, or read it in order with `{FILES_READ_TOOL}`."
        )
    else:
        lines.append(
            f"- Read it with `{FILES_READ_TOOL}` using the name above."
        )

    if source.char_count:
        lines.append(f"- Length: about {source.char_count:,} characters.")

    reason = OCR_REASONS.get(source.ocr_skipped_reason or "")
    if reason:
        # Named rather than hidden: an agent that knows a chart was not read
        # says so; one that does not, describes the chart it cannot see.
        lines.append(f"- Note: {reason}.")

    return lines


def _describe_knowledge_base(kb: ResolvedKnowledgeBase) -> List[str]:
    lines = [f"### {kb.alias or kb.name} (knowledge base)"]

    if not kb.resolved:
        lines.append(f"- Unavailable: {kb.error}. Do not claim to have used it.")
        return lines

    lines.append(f"- Search it with `{kb_tool_name(kb.alias or kb.name)}`.")
    if kb.document_count:
        lines.append(f"- Contains {kb.document_count} document(s).")
    if kb.status and kb.status not in ("synced", "ready"):
        lines.append(f"- Status: {kb.status}. Results may be incomplete.")

    return lines


def _inline_section(sources: Sequence[ResolvedFile]) -> List[str]:
    """
    Render the full text of short sources, under the inline allowance.

    Sources that do not fit are named with the tool that reads them, so the
    agent still knows they exist and how to reach them.
    """
    if not sources:
        return []

    budget = markitdown_config.inline_content_chars()
    blocks: List[str] = []
    deferred: List[str] = []
    used = 0

    for source in sources:
        body = (source.content_md or "").strip()
        if not body:
            continue
        if used + len(body) > budget:
            deferred.append(source.name)
            continue
        blocks.append(f"#### {source.name}\n\n{body}")
        used += len(body)

    if not blocks and not deferred:
        return []

    section = ["## Attached document contents"]
    section.extend(blocks)
    if deferred:
        section.append(
            f"The full text of {', '.join(deferred)} is not included here to "
            f"keep this message a workable length. Read any of them with "
            f"`{FILES_READ_TOOL}`."
        )
    return section


def resolve_token_budget() -> int:
    """Descriptor allowance for attached context, before the shared split."""
    return DEFAULT_TOKEN_BUDGET


def describe_context(
    context: Optional[AgentContext],
    *,
    token_budget: Optional[int] = None,
) -> str:
    """
    Render the attached-context block for an agent's system prompt.

    WHAT: Source descriptors under a shared budget, then the inline text of
          short sources under their own.
    WHY:  This is what makes an attached document part of every execution of
          the agent rather than of the request that uploaded it.
    INPUT: A resolved context and an optional descriptor budget override.
    OUTPUT: A markdown block, or an empty string when nothing is attached.
    """
    if context is None or context.empty:
        return ""

    budget_chars = (token_budget or resolve_token_budget()) * CHARS_PER_TOKEN
    entries: List[List[str]] = [_describe_file(f) for f in context.files]
    entries.extend(_describe_knowledge_base(kb) for kb in context.knowledge_bases)

    blocks: List[str] = []
    omitted = 0
    remaining = budget_chars

    for index, lines in enumerate(entries):
        left = len(entries) - index
        if remaining < MIN_CHARS_PER_SOURCE:
            omitted = left
            break
        share = max(MIN_CHARS_PER_SOURCE, remaining // left)
        block = _truncate("\n".join(lines), min(share, remaining))
        blocks.append(block)
        remaining -= len(block)

    if omitted:
        blocks.append(
            f"### {omitted} further source(s) not described here\n"
            f"- They are still attached and still readable with "
            f"`{FILES_SEARCH_TOOL}`; ask the user which one to use if the "
            "choice is unclear."
        )

    parts = [HEADER, *blocks]
    parts.extend(_inline_section(context.inline_files()))

    rendered = "\n\n".join(parts)
    logger.info(
        "Context descriptors: %d source(s) described, %d omitted, %d chars",
        len(blocks) - (1 if omitted else 0), omitted, len(rendered),
    )
    return rendered


__all__ = [
    "CHARS_PER_TOKEN",
    "DEFAULT_TOKEN_BUDGET",
    "describe_context",
    "resolve_token_budget",
]
