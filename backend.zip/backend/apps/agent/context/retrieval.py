"""
Running a retrieval against an agent's attached context.

WHAT: The two searches an agent can perform — over its own uploaded files and
      URLs, and over a knowledge base it has been linked to.
WHY:  The tool layer should describe and budget calls, not know how each store
      is queried. Keeping execution here means one place decides how a result
      is shaped for the model, so a passage from a PDF and a passage from a
      knowledge base read the same way.

Attached documents are stored in Postgres — text and embedding per passage —
because the platform runs on cloud containers with no shared disk. A search
embeds the query through the same credential cascade that embedded the
passages, loads this agent's passages, and ranks them in memory. That is sound
because the corpus is one agent's own attachments; ``MARKITDOWN_MAX_SEARCH_CHUNKS``
caps it and warns when the assumption stops holding.

Linked knowledge bases are searched through the knowledge app's existing
retriever — read-only, honouring each base's own configured strategy (vector,
hybrid, graph). Nothing in the knowledge app is modified by this phase; it is
called, not changed.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from apps.markitdown import config as markitdown_config
from apps.tool.async_bridge import run_async

from .refs import AgentContext, ResolvedKnowledgeBase

logger = logging.getLogger(__name__)

MAX_PASSAGE_CHARS = 2000
MAX_RENDERED_CHARS = 6000

SEARCH_TIMEOUT_SECONDS = 30


def _clip(text: str, limit: int = MAX_PASSAGE_CHARS) -> str:
    body = (text or "").strip()
    if len(body) <= limit:
        return body
    return body[:limit].rstrip() + "\n… passage truncated"


def _embedding_principal(
    context: AgentContext, knowledge_base: Optional[ResolvedKnowledgeBase] = None
) -> Optional[str]:
    """
    The account a search query is embedded under.

    WHAT: The owner of the source being searched -- the knowledge base's owner,
          or the agent's owner for its own files -- falling back to the caller.
    WHY:  Passages were embedded with their owner's embedding credential when
          they were indexed. A shared application's user holds none of the
          owner's credentials, so embedding the query under the caller either
          found no model or used a different one, and retrieval ranked on noise.
    """
    if knowledge_base is not None and knowledge_base.owner_user_id:
        return knowledge_base.owner_user_id
    return context.owner_user_id or context.user_id


async def _load_chunks(
    agent_id: str, source_ids: List[str], limit: int
) -> List[Dict[str, Any]]:
    from echolib.database import get_db_session
    from echolib.repositories.agent_file_repo import AgentFileChunkRepository

    async with get_db_session() as db:
        return await AgentFileChunkRepository().load_for_search(
            db, agent_id=agent_id, source_ids=source_ids, limit=limit
        )


def search_files(
    context: AgentContext,
    query: str,
    *,
    top_k: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Search the agent's own uploaded files and URLs.

    Restricted to sources still attached and successfully processed on this
    build, so a detached or failed document stops being retrievable in the same
    request rather than after a rebuild.
    """
    from apps.markitdown import embed_query, search_chunks

    source_ids = context.searchable_file_ids()
    if not source_ids:
        return []

    query_vector = embed_query(
        query,
        user_id=_embedding_principal(context),
        credential_id=context.credential_id,
    )
    if not query_vector:
        # No embedding model resolved. Reported as no match rather than as an
        # error: the turn must not fail, and the caller's empty note already
        # tells the agent not to answer from assumption.
        return []

    cap = markitdown_config.max_search_chunks()
    try:
        rows = run_async(
            _load_chunks(context.agent_id, source_ids, cap),
            timeout=SEARCH_TIMEOUT_SECONDS,
        )
    except Exception:
        logger.warning(
            "Passages could not be loaded for agent '%s'", context.agent_id, exc_info=True
        )
        return []

    if len(rows) >= cap:
        logger.warning(
            "Agent '%s' has at least %d passages; the search was capped. "
            "Consider a dedicated vector index for this workload.",
            context.agent_id, cap,
        )

    return [
        {
            "content": _clip(chunk.content),
            "source": chunk.source_name or chunk.source_id,
            "score": round(float(chunk.score), 4),
        }
        for chunk in search_chunks(query_vector, rows, top_k=top_k)
    ]


def _knowledge_base_embeddings(
    context: AgentContext, knowledge_base: ResolvedKnowledgeBase
) -> Optional[Any]:
    """
    The embeddings client this knowledge base's index was written with.

    WHAT: Resolves through ``KnowledgeService``, the same path ingestion uses.
    WHY:  A FAISS index can only be searched by the model that built it. This
          resolved through ``apps.markitdown.embeddings`` instead, which honours
          only an explicit ``embedding_model`` key on the credential dict — and
          ``credential_resolver`` never sets one, so it fell through to the
          ``embedding_text`` constant on *every* call. The index had
          been built with the credential's real embedding deployment, so the
          query landed in a different vector space, or 404'd on a deployment
          that does not exist, and the tool reported "nothing matched".
    OUTPUT: The client, or ``None`` when none could be resolved — which the
            caller reports as no match rather than as an error, because a turn
            must not fail on a knowledge base being misconfigured.

    Falls back to the previous resolver when the knowledge app is not mounted,
    so an agent-only deployment keeps working rather than losing the tool.
    """
    kb_id = knowledge_base.knowledge_base_id

    try:
        from echolib.di import container as di_container

        knowledge_service = di_container.resolve("knowledge.service")
    except Exception:
        logger.debug(
            "knowledge.service is not registered; resolving embeddings for '%s' "
            "through the local cascade instead",
            kb_id,
        )
        return _fallback_embeddings(context, knowledge_base)

    try:
        from apps.knowledge import chunk_store

        return knowledge_service.embeddings_for_knowledge_base(
            knowledge_base.embedding_model,
            user_id=_embedding_principal(context, knowledge_base),
            # A vector index is only readable by the model that wrote it, so
            # what the passages were indexed with outranks what the base was
            # configured with -- the configured value is usually unset.
            indexed_model=chunk_store.indexed_embedding_model(kb_id),
        )
    except Exception:
        logger.warning(
            "Embeddings could not be resolved for knowledge base '%s' "
            "(configured embedding_model=%r). It will be searched by keyword "
            "over its stored passages instead.",
            kb_id, knowledge_base.embedding_model, exc_info=True,
        )
        return None


def _fallback_embeddings(
    context: AgentContext, knowledge_base: ResolvedKnowledgeBase
) -> Optional[Any]:
    """
    The pre-existing resolver, kept for deployments without the knowledge app.

    Retained rather than deleted because it is the only path available when
    ``knowledge.service`` is absent. It carries the model-versus-credential
    distinction the column requires; what it cannot do is guarantee parity with
    whatever wrote the index, which is why it is no longer the first choice.
    """
    try:
        from apps.markitdown.embeddings import is_credential_id, resolve_embeddings

        configured = knowledge_base.embedding_model
        pinned_credential = configured if is_credential_id(configured) else None
        pinned_model = None if pinned_credential else configured

        return resolve_embeddings(
            _embedding_principal(context, knowledge_base),
            pinned_credential or context.credential_id,
            model=pinned_model,
        )
    except Exception:
        logger.warning(
            "Embeddings unavailable for knowledge base '%s'",
            knowledge_base.knowledge_base_id, exc_info=True,
        )
        return None


def search_knowledge_base(
    context: AgentContext,
    knowledge_base: ResolvedKnowledgeBase,
    query: str,
    *,
    top_k: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Search one linked knowledge base with its own configured strategy.

    Each base decides its own retrieval — vector, hybrid or graph, with its own
    weights and depth — so a base tuned for keyword-heavy documents keeps that
    tuning when an agent reads it.
    """
    from apps.knowledge import retriever

    embeddings = None
    if knowledge_base.processing_type in ("vector", "hybrid"):
        embeddings = _knowledge_base_embeddings(context, knowledge_base)
        if embeddings is None:
            # Not a dead end any more. ``retriever.search`` falls back to
            # keyword ranking over the passages Postgres already holds, so a
            # base whose embedding model is unreachable still answers from its
            # own text. Returning [] here made the agent report that a document
            # it had been given contained nothing relevant.
            logger.warning(
                "No embedding model resolved for knowledge base '%s'; "
                "searching its stored passages by keyword instead",
                knowledge_base.knowledge_base_id,
            )

    try:
        results = retriever.search(
            kb_id=knowledge_base.knowledge_base_id,
            query=query,
            embeddings=embeddings,
            search_type=knowledge_base.search_type,
            top_k=int(top_k or knowledge_base.top_k),
            vector_weight=knowledge_base.vector_weight,
            keyword_weight=knowledge_base.keyword_weight,
            processing_type=knowledge_base.processing_type,
        )
    except Exception:
        logger.warning(
            "Knowledge base search failed for '%s'",
            knowledge_base.knowledge_base_id, exc_info=True,
        )
        return []

    return [
        {
            "content": _clip(str(entry.get("content") or "")),
            "source": str(entry.get("source_document") or knowledge_base.name),
            "score": round(float(entry.get("score") or 0.0), 4),
        }
        for entry in (results or [])
    ]


def render(results: List[Dict[str, Any]], *, empty_note: str) -> str:
    """
    Render retrieved passages as the text the model reads.

    Each passage names its source so the agent can cite it, and an empty result
    says so plainly. "No matching passage" has to be unambiguous: an agent that
    reads silence as permission is exactly the hallucination this phase exists
    to prevent.
    """
    if not results:
        return empty_note

    parts: List[str] = []
    used = 0
    for index, entry in enumerate(results, start=1):
        block = (
            f"[{index}] {entry['source']} (relevance {entry['score']})\n{entry['content']}"
        )
        if used + len(block) > MAX_RENDERED_CHARS:
            parts.append(
                f"… {len(results) - index + 1} further passage(s) omitted. "
                "Narrow the query if you need them."
            )
            break
        parts.append(block)
        used += len(block)

    return "\n\n".join(parts)


__all__ = ["render", "search_files", "search_knowledge_base"]
