from echolib.di import container
from echolib.adapters import OTelLogger, KeyVaultClient
from echolib.services import TemplateRepository, ToolService, AgentService

# Import new orchestrator services
from .registry.registry import AgentRegistry
from .factory.factory import AgentFactory
from .permissions.permissions import AgentPermissions
from .designer.agent_designer import AgentDesigner

# Import real ToolRegistry from the tool container
from apps.tool.container import get_registry as get_tool_registry

# Existing services (keep for backward compatibility)
_tpl = TemplateRepository()
_tool = ToolService()

# New orchestrator services
_registry = AgentRegistry()
_factory = AgentFactory(tool_registry=get_tool_registry())
_permissions = AgentPermissions()
_designer = AgentDesigner()

# AgentService with registry and designer for template matching and update detection
_agentsvc = AgentService(
    tpl_repo=_tpl,
    registry=_registry,
    designer=_designer
)

# Register existing services
container.register('agent.service', lambda: _agentsvc)
container.register('tool.service', lambda: _tool)
container.register('cred.store', lambda: KeyVaultClient())
container.register('logger', lambda: OTelLogger())

# Register new orchestrator services
container.register('agent.registry', lambda: _registry)
container.register('agent.factory', lambda: _factory)
container.register('agent.permissions', lambda: _permissions)
container.register('agent.designer', lambda: _designer)

# Agent context attachments (files, URLs, linked knowledge bases).
# Registered as the module rather than a class: the surface is a set of
# coroutines over the repositories, matching how the routes consume it, and
# importing it lazily keeps the document stack out of every container import.
def _file_attachments():
    from apps.agent import file_attachments

    return file_attachments


container.register('agent.files', _file_attachments)


# Standalone agent execution -- one agent, no graph around it. Registered so the
# application orchestrator reaches it by DI key instead of importing across app
# boundaries (Finding 13). Constructed lazily: it holds no state, and importing
# it eagerly would pull the streaming stack into every container import.
def _standalone_runner():
    from apps.agent.standalone import StandaloneAgentRunner

    return StandaloneAgentRunner(factory=_factory, registry=_registry)


container.register('agent.standalone', _standalone_runner)
