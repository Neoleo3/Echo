"""
Standalone agent execution — one agent, no graph around it.

WHAT: Runs a single stored agent for a caller that is not a workflow: the
      application orchestrator's ``agent`` plan steps, and anything else that
      needs "this one agent, this one question".
WHY:  This replaced ``apps/appmgr/orchestrator/agent_executor.py``, a
      self-declared "100% INDEPENDENT" CrewAI implementation that was the fourth
      instantiation path Phase 2 was supposed to remove. It sat behind the appmgr
      orchestrator rather than behind the ``agent.factory`` DI key, so the Phase 2
      sweep never reached it. Everything it got wrong followed from that:

      - it never forwarded ``credential_id`` or ``model``, and hardcoded
        ``temperature=0.7``, so per-agent LLM selection was silently ignored
        (Finding 5, in a third location);
      - it described the agent to the model with ``role`` / ``goal`` /
        ``backstory``, which the Phase 1 contract stopped writing — so every
        agent created since Phase 1 ran as a generic "Assistant";
      - it had no connectors, no attached documents, no knowledge bases and no
        readiness gate, because Phases 5b, 6 and 7 attached to
        ``build_with_context`` and nothing else;
      - it started a second event loop at import and forked tool binding, so
        tool budgets, dedupe, the correction retry and the observability hooks
        did not apply.

      The same agent therefore answered correctly in standalone chat and inside
      a workflow, and ungrounded inside an application. It now compiles through
      ``AgentFactory.build_with_context`` like every other path.

This module lives under ``apps/agent`` and is reached by DI key
(``agent.standalone``), not by an ``apps.appmgr`` → ``apps.agent`` import:
``PROJECT_OVERVIEW.md`` requires applications to orchestrate existing modules
rather than duplicate them, and Finding 13 is about exactly this direction of
dependency.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional

from echolib.agent_contract import OWNER_USER_ID_KEY

from .streaming import (
    EVENT_ERROR,
    EVENT_FINAL,
    AgentEvent,
    astream_agent,
)

logger = logging.getLogger(__name__)

DEFAULT_COMPONENT = "agent_executor"
"""
Credential component label, deliberately unchanged from the deleted executor.

``llm_resolver._COMPONENT_TO_ROLE`` maps ``agent_executor`` to the ``general``
role, which is the Key Vault key an application's per-app credential is stored
under (``app_{app_id}-general``). Renaming this to match the new module would
have silently skipped the application credential tier for every app.
"""

# Generation tools write the file and return this marker in their output text;
# the application replaces it with a real download URL further downstream
# (``skill_executor._register_generated_files``). Collected here as a backstop
# for the case the model drops the marker from its own reply -- the behaviour the
# deleted CrewAI executor got from a shared closure list.
_GENERATED_FILE_MARKER_RE = re.compile(r"\[GENERATED_FILE:[^\]]+\]")

# Presentation rules for an application answer. These were part of the CrewAI
# executor's task description, not of the agent, and they stay per-run for the
# same reason: they describe how an application chat surface renders an answer,
# and a workflow node feeding a downstream agent must not be told to summarise
# its structured output into prose.
#
# The last rule is load-bearing rather than cosmetic: a fabricated ``sandbox:``
# link is what ``skill_executor._SANDBOX_LINK_RE`` exists to strip, and a
# fabricated path defeats the generated-file registration entirely.
PRESENTATION_RULES = (
    "RESPONSE FORMATTING RULES:\n"
    "- Never include raw JSON, code blocks, or unformatted data in your response.\n"
    "- When a tool returns a list of items, present only the relevant fields as a "
    "clean numbered or bulleted list.\n"
    "- Do not include URLs, metadata, connection status, or internal fields unless "
    "the user explicitly asked for them.\n"
    "- Summarize and present all information in clear, natural language.\n"
    "- NEVER fabricate download links, file paths, or sandbox: URLs. If a tool "
    "creates a file, the system delivers it automatically."
)


class AgentNotFound(RuntimeError):
    """Raised when the requested agent row does not exist or is soft-deleted."""


@dataclass
class PreparedAgent:
    """A compiled agent plus the run-scoped state its caller needs afterwards."""

    build: Any
    definition: Dict[str, Any]
    agent_id: str
    agent_name: str
    task: str
    markers: List[str] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        """True when the Context Readiness Gate says this run must not proceed."""
        return bool(self.build.blocked)

    def blocked_message(self) -> str:
        """The explanation to return in place of an answer."""
        return self.build.readiness_message(self.agent_name)

    def metadata(self) -> Dict[str, Any]:
        """Execution-record metadata for this run. References only, no secrets."""
        record: Dict[str, Any] = {"llm": self.build.llm_metadata()}
        for key, value in (
            ("connectors", self.build.connector_metadata()),
            ("context", self.build.context_metadata()),
            ("readiness", self.build.readiness_metadata()),
        ):
            if value:
                record[key] = value
        return record

    def finalise(self, text: str) -> str:
        """Re-append any generated-file marker the model dropped from its reply."""
        result = text or ""
        for marker in self.markers:
            if marker not in result:
                result = result.rstrip() + "\n\n" + marker
        return result


class StandaloneAgentRunner:
    """
    Runs one stored agent through the single instantiation path.

    Stateless: every call re-loads the definition and re-compiles, so credentials
    are re-resolved from Key Vault and connector, document and knowledge
    attachments are re-resolved on every run. Nothing is cached on the instance.
    """

    def __init__(self, factory: Any = None, registry: Any = None) -> None:
        """
        Args:
            factory: ``AgentFactory``. Resolved from DI when omitted.
            registry: ``AgentRegistry``. Currently unused for loading (see
                ``_load_definition``) and accepted so a caller can inject one
                without a signature change.
        """
        self._factory = factory
        self._registry = registry

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    async def run(
        self,
        *,
        agent_id: str,
        user_input: str,
        db: Any = None,
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        history: Optional[List[Any]] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        chat_session_id: Optional[str] = None,
        run_id: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
        on_event: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Execute the agent and return its complete answer.

        WHAT: Loads, compiles, streams and aggregates.
        WHY:  Callers that only want the text should not have to consume events,
              but the answer must be produced by the same code path that produces
              the stream -- otherwise the streamed answer and the returned answer
              can differ, which is the classic streaming defect.
        INPUT: Agent id, the user's request, and the run-scoped context below.
        OUTPUT: ``{result, agent_id, agent_name, metadata}``.
        RAISES: ``AgentNotFound`` when the agent row is missing.

        Args:
            agent_id: Agent UUID or prefixed id.
            user_input: The request for this run.
            db: Optional open ``AsyncSession``; one is opened when omitted.
            user_id: Authenticated user UUID. Drives credential resolution and
                ownership of connectors and attached documents.
            app_id: Application id, for the application credential tier.
            context: Extra context; ``previous_output`` is carried into the task.
            history: Prior conversation turns.
            tabular_files: Session-scoped spreadsheet list for the data tools.
            chat_session_id: Chat session, forwarded to tools as context.
            run_id: Run identifier for observability correlation.
            definition: An already-loaded agent definition. Supplied by callers
                that resolved it under their own access rules -- the agent HTTP
                routes scope the lookup to the authenticated owner, which
                ``_load_definition`` deliberately does not.
            on_event: Optional coroutine called with each ``AgentEvent``. This is
                how a transport receives tokens while ``run`` still returns text.
        """
        prepared = await self.prepare(
            agent_id=agent_id,
            user_input=user_input,
            db=db,
            user_id=user_id,
            app_id=app_id,
            context=context,
            tabular_files=tabular_files,
            chat_session_id=chat_session_id,
            run_id=run_id,
            definition=definition,
        )

        if prepared.blocked:
            message = prepared.blocked_message()
            logger.info("Readiness gate blocked standalone agent '%s'", prepared.agent_id)
            await _emit(on_event, AgentEvent(type=EVENT_FINAL, text=message))
            return self._result(prepared, message, status="blocked")

        answer = ""
        error: Optional[str] = None

        async for event in astream_agent(prepared.build.agent, prepared.task, history=history):
            await _emit(on_event, event)
            if event.type == EVENT_FINAL:
                answer = event.text
            elif event.type == EVENT_ERROR:
                error = event.text

        if error:
            # Raised, not returned: the application's own step bookkeeping marks
            # the step failed and reports it, which a silent empty answer would
            # not do.
            raise RuntimeError(f"Agent '{prepared.agent_name}' failed: {error}")

        return self._result(prepared, prepared.finalise(answer))

    async def astream(
        self,
        *,
        agent_id: str,
        user_input: str,
        db: Any = None,
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        history: Optional[List[Any]] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        chat_session_id: Optional[str] = None,
        run_id: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> AsyncIterator[AgentEvent]:
        """
        Execute the agent and yield its events as they happen.

        Terminated by exactly one ``final`` or one ``error``, including when the
        readiness gate blocks the run or the agent cannot be loaded — a transport
        that has already sent headers needs the reason in-band.
        """
        try:
            prepared = await self.prepare(
                agent_id=agent_id,
                user_input=user_input,
                db=db,
                user_id=user_id,
                app_id=app_id,
                context=context,
                tabular_files=tabular_files,
                chat_session_id=chat_session_id,
                run_id=run_id,
                definition=definition,
            )
        except Exception as exc:  # noqa: BLE001 -- terminal event, not a swallow
            logger.exception("Standalone agent '%s' could not be prepared", agent_id)
            yield AgentEvent(type=EVENT_ERROR, text=str(exc))
            return

        if prepared.blocked:
            logger.info("Readiness gate blocked standalone agent '%s'", prepared.agent_id)
            yield AgentEvent(type=EVENT_FINAL, text=prepared.blocked_message())
            return

        async for event in astream_agent(prepared.build.agent, prepared.task, history=history):
            if event.type == EVENT_FINAL:
                yield AgentEvent(type=EVENT_FINAL, text=prepared.finalise(event.text))
            else:
                yield event

    # ------------------------------------------------------------------
    # Preparation
    # ------------------------------------------------------------------

    async def prepare(
        self,
        *,
        agent_id: str,
        user_input: str,
        db: Any = None,
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        chat_session_id: Optional[str] = None,
        run_id: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> PreparedAgent:
        """
        Load the definition and compile the agent.

        The compile runs in a worker thread. ``build_with_context`` is
        synchronous and does blocking work — Key Vault reads, the provider
        catalogue, and connector resolution through the sync-to-async bridge.
        Awaiting the loop from the loop is the deadlock Phase 5b.1 found at three
        call sites; ``resolve_agent_connectors`` now refuses outright when it
        detects the loop thread, so this is not optional.
        """
        definition = definition or await self._load_definition(agent_id, db)
        agent_name = str(definition.get("name") or "Agent")
        resolved_id = str(definition.get("agent_id") or agent_id)

        markers: List[str] = []
        exec_context = self._exec_context(
            user_id=user_id,
            app_id=app_id,
            chat_session_id=chat_session_id,
            tabular_files=tabular_files,
            extra=context,
        )
        task = self._build_task(user_input, context)

        build = await asyncio.to_thread(
            self._factory_instance().build_with_context,
            definition,
            user_id=user_id,
            exec_context=exec_context,
            run_id=run_id,
            component=DEFAULT_COMPONENT,
            request=user_input,
            readiness_state=exec_context,
            on_tool_end=_marker_collector(markers),
        )

        return PreparedAgent(
            build=build,
            definition=definition,
            agent_id=resolved_id,
            agent_name=agent_name,
            task=task,
            markers=markers,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _factory_instance(self) -> Any:
        """Resolve the agent factory, preferring an injected one."""
        if self._factory is not None:
            return self._factory

        from echolib.di import container

        return container.resolve("agent.factory")

    @staticmethod
    async def _load_definition(agent_id: str, db: Any = None) -> Dict[str, Any]:
        """
        Read the agent's definition out of the ``agents`` table.

        Deliberately **not** scoped to the calling user, which preserves the
        deleted executor's behaviour exactly. A published application is chatted
        with by users who do not own its linked agents; the authorisation
        boundary is ``application_skill_links`` — the app owner decided which
        agents the application may invoke — and re-checking ownership here would
        break every published application for everyone but its author.

        ``user_id`` still governs which LLM credential resolves and what token
        governance bills. It no longer governs which attachments are reachable:
        the agent's owner is stamped on the definition below and the build reads
        stored attachment rows under *that* identity. Scoping them to the caller
        was the reason a published agent lost its knowledge and connectors for
        everyone but its author -- the rows existed and the query filtered them
        out -- while the same sources attached at application level worked,
        because that half was already exempt.
        """
        from sqlalchemy import select

        from echolib.models.agent import Agent as AgentModel
        from echolib.repositories.base import safe_uuid

        agent_uuid = safe_uuid(agent_id)
        if agent_uuid is None:
            raise AgentNotFound(f"Agent '{agent_id}' is not a valid agent identifier")

        async def _query(session: Any) -> Optional[Any]:
            stmt = select(AgentModel).where(
                AgentModel.agent_id == agent_uuid,
                AgentModel.is_deleted == False,  # noqa: E712
            )
            return (await session.execute(stmt)).scalar_one_or_none()

        if db is not None:
            row = await _query(db)
        else:
            from echolib.database import get_db_session

            async with get_db_session() as session:
                row = await _query(session)

        if row is None:
            raise AgentNotFound(f"Agent '{agent_id}' not found in database")

        # ``to_dict`` normalises through the Phase 1 contract, so a legacy row
        # reads back canonical without a backfill. Copied because the caller
        # adds runtime keys and the ORM object must not be mutated.
        definition = dict(row.definition or {})
        definition.setdefault("agent_id", str(row.agent_id))
        definition.setdefault("name", row.name)
        # The owner lives on the column, not in the definition JSONB, so it has
        # to be carried explicitly. ``AgentFactory`` reads it as the principal
        # for the agent's own attachments.
        definition[OWNER_USER_ID_KEY] = str(row.user_id)
        return definition

    @staticmethod
    def _exec_context(
        *,
        user_id: Optional[str],
        app_id: Optional[str],
        chat_session_id: Optional[str],
        tabular_files: Optional[List[Dict[str, Any]]],
        extra: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Assemble the context forwarded to every tool call.

        ``tabular_files`` is the one entry that carries data rather than
        identity. The deleted executor injected the session's spreadsheets into a
        tool closure; the replacement passes them through the context the tool
        executor already threads, so the registry tool receives exactly this
        session's files instead of discovering whatever happens to be on the
        shared upload path.
        """
        context: Dict[str, Any] = {}
        if isinstance(extra, dict):
            context.update({k: v for k, v in extra.items() if v is not None})

        if user_id:
            context["user_id"] = user_id
        if app_id:
            context["app_id"] = app_id
        if chat_session_id:
            context["chat_session_id"] = chat_session_id
        if tabular_files:
            context["tabular_files"] = list(tabular_files)

        return context

    @staticmethod
    def _build_task(user_input: str, context: Optional[Dict[str, Any]]) -> str:
        """
        Build the task text for this run.

        Instructions are **not** included: they are the agent's system prompt,
        assembled once by ``factory.prompt.build_system_prompt``. The deleted
        executor pasted them into the task description because CrewAI's ``Task``
        was the only channel it had, which meant the same text arrived twice on
        any path that also set a system prompt.
        """
        parts = [f"USER REQUEST: {user_input}"]

        previous = (context or {}).get("previous_output")
        if isinstance(previous, str) and previous.strip():
            parts.append(f"PREVIOUS STEP OUTPUT:\n{previous.strip()}")

        parts.append(PRESENTATION_RULES)
        return "\n\n".join(parts)

    @staticmethod
    def _result(prepared: PreparedAgent, text: str, *, status: str = "completed") -> Dict[str, Any]:
        """Shape the return value. Keys match the deleted executor's contract."""
        return {
            "result": text,
            "agent_id": prepared.agent_id,
            "agent_name": prepared.agent_name,
            "status": status,
            "metadata": prepared.metadata(),
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _marker_collector(markers: List[str]) -> Any:
    """
    Build an ``on_tool_end`` hook that records generated-file markers.

    ``build_langchain_tools`` already accepts this hook, so the backstop needs no
    fork of the tool wrapper — which is what the deleted executor's duplicated
    ``_create_tool_wrapper`` existed to provide.
    """

    def on_tool_end(step_id: Optional[str], payload: Any) -> None:
        try:
            text = payload if isinstance(payload, str) else str(getattr(payload, "output", payload))
            for marker in _GENERATED_FILE_MARKER_RE.findall(text):
                if marker not in markers:
                    markers.append(marker)
        except Exception:
            logger.debug("Generated-file marker scan failed", exc_info=True)

    return on_tool_end


async def _emit(on_event: Optional[Any], event: AgentEvent) -> None:
    """Deliver one event to an optional consumer, never failing the run for it."""
    if on_event is None:
        return
    try:
        result = on_event(event)
        if asyncio.iscoroutine(result):
            await result
    except Exception:
        logger.debug("Agent event consumer failed", exc_info=True)


__all__ = [
    "AgentNotFound",
    "PreparedAgent",
    "PRESENTATION_RULES",
    "StandaloneAgentRunner",
]
