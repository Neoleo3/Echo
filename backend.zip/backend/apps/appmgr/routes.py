"""
EchoAI Application Orchestrator -- API Routes (Phases 2 + 4)

Async CRUD and Chat endpoints backed by PostgreSQL via SQLAlchemy 2.0 + asyncpg.
Replaces the previous SQLite/SQLModel sync implementation.

Route groups:
    /api/applications/...            -- Application CRUD, publish, logo
    /api/applications/{id}/chat/...  -- Chat (pipeline, history, upload)
    /api/llms, /api/data-sources,
    /api/designations, etc.          -- Lookup / catalog endpoints
    /api/skills                      -- Aggregated workflows + agents

Authentication:
    Uses ``get_current_user`` from ``echolib.security`` (optional/required
    mode is controlled by the ``AUTH_ENFORCEMENT`` setting).
    Falls back to ``DEFAULT_USER_ID`` for anonymous callers.

Database:
    Uses ``get_db_session()`` async context manager from ``echolib.database``.
    All mutations flush inside the session; the context manager commits or
    rolls back automatically.
"""
import socket
import asyncio
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    Response,
    UploadFile,
)
from fastapi.responses import FileResponse
from numpy import record
from starlette.responses import StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.database import get_db_session
from echolib.models import (
    AppBusinessUnit,
    AppDataSource,
    AppDesignation,
    AppGuardrailCategory,
    AppLlm,
    AppPersona,
    AppTag,
    Application,
)
from echolib.models.user import User
from echolib.models.user_links import UserDesignationLink, UserBusinessUnitLink
from echolib.models.workflow import Workflow
from echolib.models.agent import Agent
from echolib.repositories.application_repo import ApplicationRepository
from echolib.repositories.base import DEFAULT_USER_ID
from echolib.security import get_current_user, require_user, require_admin_or_above, require_super_admin, resolve_user_id
from echolib.types import UserContext, UserRole

from echolib.repositories.application_chat_repo import ApplicationChatRepository
from echolib.repositories.generated_file_repo import GeneratedFileRepository
from echolib.generated_files import validate_generated_file_path
from echolib.repositories.approval_audit_repo import ApprovalAuditRepository
from echolib.repositories.notification_repo import NotificationRepository
from echolib.service.pdf_export import generate_chat_pdf
from echolib.upload_validation import validate_upload

from .schemas import (
    ApplicationAccessUpdate,
    ApplicationCard,
    ApplicationChatConfigUpdate,
    ApplicationContextUpdate,
    ApplicationCreate,
    ApplicationDetail,
    ApplicationFullUpdate,
    ApplicationListResponse,
    ApplicationSetupUpdate,
    ApplicationStats,
    ApprovalQueueItem,
    AuditLogEntry,
    ChatMessageRequest,
    ChatMessageResponse,
    ChatResponse,
    ChatSessionMetadata,
    ChatSessionResponse,
    BatchDocumentUploadResponse,
    DocumentUploadResponse,
    FileUploadResumeResponse,
    HITLDecisionRequest,
    HITLDecisionResponse,
    LlmLinkResponse,
    LookupResponse,
    RejectPayload,
    SkillLinkResponse,
    SkillResponse,
    TitleUpdateRequest,
    UploadResponse,
)


logger = logging.getLogger(__name__)


def _sse_setting(name: str, default: float) -> float:
    """Read an SSE timing value from ``echolib.config``, degrading to *default*."""
    try:
        from echolib.config import settings

        return float(getattr(settings, name, default))
    except Exception:  # noqa: BLE001 -- transport timing must never fail a request
        return default


# How often a silent stream emits a keep-alive comment frame.
#
# Well under Azure's fixed 230s TCP idle timeout, and under the tighter windows
# reverse proxies and CDNs commonly apply -- guidance is to heartbeat at well
# below half the shortest timeout in the chain, and a real data frame resets the
# clock anyway, so this only ever fires when nothing else is flowing.
_SSE_HEARTBEAT_SECONDS = _sse_setting("sse_heartbeat_seconds", 15.0)

# How often a quiet-but-working stream records that it is still alive.
#
# There is deliberately NO fixed idle timeout any more. The previous
# ``_SSE_IDLE_TIMEOUT_SECONDS = 180`` closed healthy streams: how long a run
# stays quiet depends on agent count, rate-limit pacing, model and quota, so any
# constant is wrong for somebody. The generator now asks whether the pipeline
# task is alive, which is a fact rather than a guess.
_SSE_QUIET_LOG_SECONDS = _sse_setting("sse_quiet_log_seconds", 60.0)

# ---------------------------------------------------------------------------
# Directories for file uploads
# ---------------------------------------------------------------------------
LOGOS_DIR = os.getenv("APP_LOGOS_DIR", os.path.join("static", "logos"))
Path(LOGOS_DIR).mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Directories for file uploads -- chat documents
# ---------------------------------------------------------------------------
UPLOADS_DIR = os.getenv("APP_UPLOADS_DIR", os.path.join("apps", "appmgr", "uploads"))
Path(UPLOADS_DIR).mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Repository singletons (stateless, safe to reuse)
# ---------------------------------------------------------------------------
_app_repo = ApplicationRepository()
_chat_repo = ApplicationChatRepository()
_gen_file_repo = GeneratedFileRepository()
_audit_repo = ApprovalAuditRepository()
_notif_repo = NotificationRepository()


# _resolve_user_id() has been removed. Use resolve_user_id() from echolib.security
# which validates UUIDs and falls back to DEFAULT_USER_ID for anonymous users.


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _app_to_card(app: Application) -> ApplicationCard:
    """Convert an Application ORM instance to an ApplicationCard schema."""
    return ApplicationCard(
        application_id=str(app.application_id),
        name=app.name,
        status=app.status,
        description=app.description,
        logo_url=app.logo_url,
        llm_count=len(app.llm_links) if app.llm_links else 0,
        data_source_count=len(app.data_source_links) if app.data_source_links else 0,
        skill_count=len(app.skill_links) if app.skill_links else 0,
        error_message=app.error_message,
        approval_status=app.approval_status,
        approved_by=str(app.approved_by) if app.approved_by else None,
        rejection_reason=app.rejection_reason,
        created_at=app.created_at,
        updated_at=app.updated_at,
    )


async def _build_app_detail(db: AsyncSession, app: Application) -> ApplicationDetail:
    """Convert an Application ORM instance to an ApplicationDetail schema.

    Resolves LLM names via the eager-loaded relationship and resolves
    designation, business unit, and tag names from their lookup tables.
    """
    from echolib.repositories.base import safe_uuid

    # Resolve designation names
    designation_names: List[str] = []
    designation_ids_list = [
        str(link.designation_id) for link in (app.designation_links or [])
    ]
    if designation_ids_list:
        _d_uuids = [safe_uuid(did) for did in designation_ids_list]
        _d_uuids = [u for u in _d_uuids if u is not None]
        if _d_uuids:
            _d_result = await db.execute(
                select(AppDesignation).where(AppDesignation.designation_id.in_(_d_uuids))
            )
            designation_names = [d.name for d in _d_result.scalars().all()]

    # Resolve business unit names
    business_unit_names: List[str] = []
    business_unit_ids_list = [
        str(link.business_unit_id) for link in (app.business_unit_links or [])
    ]
    if business_unit_ids_list:
        _bu_uuids = [safe_uuid(buid) for buid in business_unit_ids_list]
        _bu_uuids = [u for u in _bu_uuids if u is not None]
        if _bu_uuids:
            _bu_result = await db.execute(
                select(AppBusinessUnit).where(AppBusinessUnit.business_unit_id.in_(_bu_uuids))
            )
            business_unit_names = [bu.name for bu in _bu_result.scalars().all()]

    # Resolve tag names
    tag_names: List[str] = []
    tag_ids_list = [str(link.tag_id) for link in (app.tag_links or [])]
    if tag_ids_list:
        _t_uuids = [safe_uuid(tid) for tid in tag_ids_list]
        _t_uuids = [u for u in _t_uuids if u is not None]
        if _t_uuids:
            _t_result = await db.execute(
                select(AppTag).where(AppTag.tag_id.in_(_t_uuids))
            )
            tag_names = [t.name for t in _t_result.scalars().all()]

    return ApplicationDetail(
        application_id=str(app.application_id),
        user_id=str(app.user_id),
        name=app.name,
        description=app.description,
        status=app.status,
        error_message=app.error_message,
        available_for_all_users=app.available_for_all_users,
        upload_enabled=app.upload_enabled,
        welcome_prompt=app.welcome_prompt,
        disclaimer=app.disclaimer,
        sorry_message=app.sorry_message,
        starter_questions=app.starter_questions or [],
        persona_id=str(app.persona_id) if app.persona_id else None,
        persona_text=app.persona_text,
        guardrail_text=app.guardrail_text,
        logo_url=app.logo_url,
        created_at=app.created_at,
        updated_at=app.updated_at,
        llm_links=[
            LlmLinkResponse(
                llm_id=link.llm_id,
                role=link.role,
                name=link.name,
            )
            for link in (app.llm_links or [])
        ],
        skill_links=[
            SkillLinkResponse(
                skill_id=link.skill_id,
                skill_type=link.skill_type,
                skill_name=link.skill_name,
                skill_description=link.skill_description,
            )
            for link in (app.skill_links or [])
        ],
        data_source_ids=[
            link.data_source_id for link in (app.data_source_links or [])
        ],
        designation_ids=designation_ids_list,
        business_unit_ids=business_unit_ids_list,
        tag_ids=tag_ids_list,
        guardrail_category_ids=[
            str(link.guardrail_category_id)
            for link in (app.guardrail_links or [])
        ],
        designation_names=designation_names,
        business_unit_names=business_unit_names,
        tag_names=tag_names,
        approval_status=app.approval_status,
        approved_by=str(app.approved_by) if app.approved_by else None,
        rejection_reason=app.rejection_reason,
    )


# ===================================================================
# Application CRUD Router
# ===================================================================

router = APIRouter(prefix="/api/applications", tags=["Applications"])


# -------------------------------------------------------------------
# POST /api/applications -- Create
# -------------------------------------------------------------------
@router.post("", response_model=ApplicationDetail, status_code=201)
async def create_application(
    payload: ApplicationCreate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Create a new application in DRAFT status. Only ``name`` is required.

    An application created by a super_admin is approved on the spot -- see the
    ``self_approved`` branch below. Every other creator's application starts
    ``pending`` and the matching super_admins are notified.
    """
    from echolib.repositories.base import safe_uuid

    user_id = resolve_user_id(user)

    # Build optional kwargs from payload
    kwargs = {}
    if payload.description is not None:
        kwargs["description"] = payload.description
    if payload.logo_url is not None:
        kwargs["logo_url"] = payload.logo_url
    if payload.welcome_prompt is not None:
        kwargs["welcome_prompt"] = payload.welcome_prompt
    if payload.disclaimer is not None:
        kwargs["disclaimer"] = payload.disclaimer
    if payload.sorry_message is not None:
        kwargs["sorry_message"] = payload.sorry_message
    if payload.starter_questions is not None:
        kwargs["starter_questions"] = payload.starter_questions
    if payload.persona_id is not None:
        kwargs["persona_id"] = payload.persona_id
    if payload.persona_text is not None:
        kwargs["persona_text"] = payload.persona_text
    if payload.guardrail_text is not None:
        kwargs["guardrail_text"] = payload.guardrail_text
    if payload.available_for_all_users is not None:
        kwargs["available_for_all_users"] = payload.available_for_all_users
    if payload.upload_enabled is not None:
        kwargs["upload_enabled"] = payload.upload_enabled

    # A super_admin IS the approving authority. Requiring one to be approved
    # by a super_admin is circular, and it left their own apps unpublishable.
    # Record the approval against the creator so the audit trail still names
    # who approved it, and keep the app out of everyone's approval queue.
    self_approved = user.role == UserRole.super_admin.value
    if self_approved:
        kwargs["approval_status"] = "approved"
        kwargs["approved_by"] = safe_uuid(user_id)

    async with get_db_session() as db:
        app = await _app_repo.create_application(
            db, user_id=user_id, name=payload.name.strip(), **kwargs
        )

        app_id_str = str(app.application_id)

        # Sync link tables if provided at creation time
        if payload.llm_links is not None:
            await _app_repo.sync_llm_links(db, app_id_str, payload.llm_links)
        if payload.skill_links is not None:
            await _app_repo.sync_skill_links(db, app_id_str, payload.skill_links)
        if payload.data_source_ids is not None:
            await _app_repo.sync_data_source_links(db, app_id_str, payload.data_source_ids)
            from apps.appmgr.context import invalidate_application

            invalidate_application(app_id_str)
        if payload.designation_ids is not None:
            await _app_repo.sync_designation_links(db, app_id_str, payload.designation_ids)
        if payload.business_unit_ids is not None:
            await _app_repo.sync_business_unit_links(db, app_id_str, payload.business_unit_ids)
        if payload.tag_ids is not None:
            await _app_repo.sync_tag_links(db, app_id_str, payload.tag_ids)
        if payload.guardrail_category_ids is not None:
            await _app_repo.sync_guardrail_links(db, app_id_str, payload.guardrail_category_ids)

        # Expire cached objects so relationships reload from DB
        db.expire_all()

        # Rebuild config JSONB from fresh link data (dual-write)
        await _app_repo.sync_config_jsonb(
            db, app_id_str, user_id, user.role
        )
        app = await _app_repo.get_application(
            db, app_id_str, user_id
        )

        # Audit log: app submitted for approval
        await _audit_repo.log_action(
            db,
            application_id=app_id_str,
            action="submitted",
            performed_by=user_id,
        )

        if self_approved:
            # The creator is the approving authority, so the approval is
            # recorded rather than requested. No notification: there is
            # nothing for a super_admin to act on.
            await _audit_repo.log_action(
                db,
                application_id=app_id_str,
                action="approved",
                performed_by=user_id,
                comment="Auto-approved: created by a Super Admin.",
            )
            logger.info(
                "Application %s auto-approved on creation by super_admin %s",
                app_id_str,
                user_id,
            )
        else:
            # Notify super_admins with matching BU/designation
            await _notify_super_admins_for_app(
                db, app,
                notif_type="approval_pending",
                title=f"New application '{app.name}' pending approval",
                message=f"A new application '{app.name}' has been submitted for approval.",
            )

        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# GET /api/applications -- List (paginated, with stats)
# -------------------------------------------------------------------
@router.get("", response_model=ApplicationListResponse)
async def list_applications(
    status: Optional[str] = Query(None, description="Filter: draft|published|error"),
    q: Optional[str] = Query(None, description="Search by name (ILIKE)"),
    sort: Optional[str] = Query(None, description="Sort mode: recently_updated"),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    user: UserContext = Depends(require_user),
):
    """List applications as paginated cards with dashboard stats."""
    user_id = resolve_user_id(user)

    if status and status not in {"draft", "published", "error"}:
        raise HTTPException(400, "Invalid status filter. Use: draft, published, error")

    async with get_db_session() as db:
        items, total = await _app_repo.list_applications(
            db,
            user_id=user_id,
            status=status,
            q=q,
            sort=sort,
            page=page,
            page_size=pageSize,
        )
        stats_dict = await _app_repo.get_application_stats(db, user_id=user_id)

        return ApplicationListResponse(
            page=page,
            page_size=pageSize,
            total=total,
            stats=ApplicationStats(**stats_dict),
            items=[_app_to_card(app) for app in items],
        )


# -------------------------------------------------------------------
# GET /api/applications/visible -- Published apps visible to current user
# -------------------------------------------------------------------
@router.get("/visible", response_model=ApplicationListResponse)
async def list_visible_applications(
    q: Optional[str] = Query(None, description="Search by name (ILIKE)"),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    user: UserContext = Depends(require_user),
):
    """
    List published applications visible to the current user.

    - super_admin/admin: see all published apps.
    - user: see apps matching their designation AND business_unit,
      plus apps marked available_for_all_users.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        items, total = await _app_repo.list_visible_applications(
            db,
            user_id=user_id,
            user_role=user.role,
            q=q,
            page=page,
            page_size=pageSize,
        )
        return ApplicationListResponse(
            page=page,
            page_size=pageSize,
            total=total,
            stats=ApplicationStats(total=total, draft=0, published=total, error=0),
            items=[_app_to_card(app) for app in items],
        )


# -------------------------------------------------------------------
# GET /api/applications/approval-queue
# (MUST be above /{application_id} to avoid wildcard capture)
# -------------------------------------------------------------------
@router.get("/approval-queue", response_model=List[ApprovalQueueItem])
async def get_approval_queue(
    user: UserContext = Depends(require_super_admin),
):
    """List applications pending approval (ABAC-filtered for super_admin)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        apps = await _app_repo.list_pending_approvals(db, user_id, user.role)
        return [
            ApprovalQueueItem(
                application_id=str(app.application_id),
                app_type="classic",
                name=app.name,
                description=app.description,
                status=app.status,
                approval_status=app.approval_status,
                approved_by=str(app.approved_by) if app.approved_by else None,
                rejection_reason=app.rejection_reason,
                logo_url=app.logo_url,
                llm_count=len(app.llm_links) if app.llm_links else 0,
                skill_count=len(app.skill_links) if app.skill_links else 0,
                data_source_count=len(app.data_source_links) if app.data_source_links else 0,
                user_id=str(app.user_id),
                created_at=app.created_at,
                updated_at=app.updated_at,
            )
            for app in apps
        ]


# -------------------------------------------------------------------
# GET /api/applications/{application_id} -- Detail
# -------------------------------------------------------------------
@router.get("/{application_id}", response_model=ApplicationDetail)
async def get_application(
    application_id: str,
    user: UserContext = Depends(require_user),
):
    """Get a single application with all relationships.

    A super_admin may read any application. Approving one without being able
    to see what it was configured with is not a review, and the approval queue
    carries counts only. This widens **read** access alone -- update, delete
    and publish stay owner-scoped through ``get_accessible_application``.
    """
    user_id = resolve_user_id(user)
    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None and user.role == UserRole.super_admin.value:
            app = await _app_repo.get_application_by_id(db, application_id)
        if app is None:
            raise HTTPException(404, "Application not found")
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# PUT /api/applications/{application_id} -- Full Update
# -------------------------------------------------------------------
@router.put("/{application_id}", response_model=ApplicationDetail)
async def update_application(
    application_id: str,
    payload: ApplicationFullUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Full update of an application (all sections at once).

    EDIT BEHAVIOR: If the app is PUBLISHED, it stays PUBLISHED after save.
    The status does NOT revert to DRAFT on edit.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        # Collect scalar updates (only provided fields)
        scalar_kwargs = {}
        if payload.name is not None:
            scalar_kwargs["name"] = payload.name.strip()
        if payload.description is not None:
            scalar_kwargs["description"] = payload.description
        if payload.logo_url is not None:
            scalar_kwargs["logo_url"] = payload.logo_url
        if payload.available_for_all_users is not None:
            scalar_kwargs["available_for_all_users"] = payload.available_for_all_users
        if payload.upload_enabled is not None:
            scalar_kwargs["upload_enabled"] = payload.upload_enabled
        if payload.welcome_prompt is not None:
            scalar_kwargs["welcome_prompt"] = payload.welcome_prompt
        if payload.disclaimer is not None:
            scalar_kwargs["disclaimer"] = payload.disclaimer
        if payload.sorry_message is not None:
            scalar_kwargs["sorry_message"] = payload.sorry_message
        if payload.starter_questions is not None:
            scalar_kwargs["starter_questions"] = payload.starter_questions
        if payload.persona_id is not None:
            scalar_kwargs["persona_id"] = payload.persona_id
        if payload.persona_text is not None:
            scalar_kwargs["persona_text"] = payload.persona_text
        if payload.guardrail_text is not None:
            scalar_kwargs["guardrail_text"] = payload.guardrail_text

        # Apply scalar updates
        if scalar_kwargs:
            app = await _app_repo.update_application(
                db, application_id, user_id, user.role, **scalar_kwargs
            )
            if app is None:
                raise HTTPException(404, "Application not found after update")

        # Sync link tables (only if provided in payload)
        app_id_str = application_id
        if payload.llm_links is not None:
            await _app_repo.sync_llm_links(db, app_id_str, payload.llm_links)
        if payload.skill_links is not None:
            await _app_repo.sync_skill_links(db, app_id_str, payload.skill_links)
        if payload.data_source_ids is not None:
            await _app_repo.sync_data_source_links(
                db, app_id_str, payload.data_source_ids
            )
            from apps.appmgr.context import invalidate_application

            invalidate_application(app_id_str)
        if payload.designation_ids is not None:
            await _app_repo.sync_designation_links(
                db, app_id_str, payload.designation_ids
            )
        if payload.business_unit_ids is not None:
            await _app_repo.sync_business_unit_links(
                db, app_id_str, payload.business_unit_ids
            )
        if payload.tag_ids is not None:
            await _app_repo.sync_tag_links(db, app_id_str, payload.tag_ids)
        if payload.guardrail_category_ids is not None:
            await _app_repo.sync_guardrail_links(
                db, app_id_str, payload.guardrail_category_ids
            )

        # Expire cached objects so relationships reload from DB
        db.expire_all()

        # Rebuild config JSONB after link and scalar changes (dual-write)
        await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

        # Re-fetch with refreshed relationships
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found after update")
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# PATCH /api/applications/{application_id}/setup
# -------------------------------------------------------------------
@router.patch("/{application_id}/setup", response_model=ApplicationDetail)
async def patch_setup(
    application_id: str,
    payload: ApplicationSetupUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update the App Setup section (Step 1): LLMs, Skills, Data Sources."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        if payload.llm_links is not None:
            await _app_repo.sync_llm_links(db, application_id, payload.llm_links)
        if payload.skill_links is not None:
            await _app_repo.sync_skill_links(db, application_id, payload.skill_links)
        if payload.data_source_ids is not None:
            await _app_repo.sync_data_source_links(
                db, application_id, payload.data_source_ids
            )
            # The application's evidence changed. A cached ledger would keep
            # reporting the old set of sources to every live chat session.
            from apps.appmgr.context import invalidate_application

            invalidate_application(application_id)

        # Expire cached objects so relationships reload from DB
        db.expire_all()

        # Rebuild config JSONB after link changes (dual-write)
        await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# PATCH /api/applications/{application_id}/access
# -------------------------------------------------------------------
@router.patch("/{application_id}/access", response_model=ApplicationDetail)
async def patch_access(
    application_id: str,
    payload: ApplicationAccessUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update the Access Permission section (Step 2)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        # Scalar access fields
        scalar_kwargs = {}
        if payload.available_for_all_users is not None:
            scalar_kwargs["available_for_all_users"] = payload.available_for_all_users
        if payload.upload_enabled is not None:
            scalar_kwargs["upload_enabled"] = payload.upload_enabled
        if scalar_kwargs:
            await _app_repo.update_application(
                db, application_id, user_id, user.role, **scalar_kwargs
            )

        # Link tables
        await _app_repo.sync_designation_links(
            db, application_id, payload.designation_ids
        )
        await _app_repo.sync_business_unit_links(
            db, application_id, payload.business_unit_ids
        )
        await _app_repo.sync_tag_links(db, application_id, payload.tag_ids)

        # Expire cached objects so relationships reload from DB
        db.expire_all()

        # Rebuild config JSONB after link changes (dual-write)
        await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# PATCH /api/applications/{application_id}/context
# -------------------------------------------------------------------
@router.patch("/{application_id}/context", response_model=ApplicationDetail)
async def patch_context(
    application_id: str,
    payload: ApplicationContextUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update the Context section (Step 3)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        kwargs = {}
        if payload.welcome_prompt is not None:
            kwargs["welcome_prompt"] = payload.welcome_prompt
        if payload.disclaimer is not None:
            kwargs["disclaimer"] = payload.disclaimer
        if payload.sorry_message is not None:
            kwargs["sorry_message"] = payload.sorry_message
        if payload.starter_questions is not None:
            kwargs["starter_questions"] = payload.starter_questions

        if kwargs:
            await _app_repo.update_application(
                db, application_id, user_id, user.role, **kwargs
            )

        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# PATCH /api/applications/{application_id}/chat-config
# -------------------------------------------------------------------
@router.patch("/{application_id}/chat-config", response_model=ApplicationDetail)
async def patch_chat_config(
    application_id: str,
    payload: ApplicationChatConfigUpdate,
    user: UserContext = Depends(require_admin_or_above),
):
    """Update the Chat Configuration section (Step 4)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        kwargs = {}
        if payload.persona_id is not None:
            kwargs["persona_id"] = payload.persona_id
        if payload.persona_text is not None:
            kwargs["persona_text"] = payload.persona_text
        if payload.guardrail_text is not None:
            kwargs["guardrail_text"] = payload.guardrail_text

        if kwargs:
            await _app_repo.update_application(
                db, application_id, user_id, user.role, **kwargs
            )

        # Sync guardrail category links
        await _app_repo.sync_guardrail_links(
            db, application_id, payload.guardrail_category_ids
        )

        # Expire cached objects so relationships reload from DB
        db.expire_all()

        # Rebuild config JSONB after link and scalar changes (dual-write)
        await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# DELETE /api/applications/{application_id} -- Soft Delete
# -------------------------------------------------------------------
@router.delete("/{application_id}", status_code=204)
async def delete_application(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Soft-delete an application (sets is_deleted = TRUE)."""
    user_id = resolve_user_id(user)
    async with get_db_session() as db:
        deleted = await _app_repo.soft_delete_application(
            db, application_id, user_id, user.role
        )
        if not deleted:
            raise HTTPException(404, "Application not found")
    return Response(status_code=204)


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/publish
# -------------------------------------------------------------------
@router.post("/{application_id}/publish", response_model=ApplicationDetail)
async def publish_application(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Validate required fields and transition DRAFT -> PUBLISHED.

    Returns 400 with a list of missing fields if validation fails.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        if app.status == "published":
            raise HTTPException(400, "Application is already published")

        # Approval gate: must be approved before publishing
        if app.approval_status != "approved":
            raise HTTPException(
                400,
                "Application must be approved by a Super Admin before publishing",
            )

        # Validate required fields for publish
        errors: List[str] = []
        warnings: List[str] = []

        # Required — block publish if missing
        if not app.llm_links:
            errors.append("An LLM must be selected")
        if not app.skill_links:
            errors.append("At least 1 skill (workflow or agent) must be linked")

        # Optional — warn but don't block
        if not app.welcome_prompt:
            warnings.append("welcome_prompt is not set — a default greeting will be used")
        if not app.sorry_message:
            warnings.append("sorry_message is not set — a default fallback will be used")

        starters = app.starter_questions or []
        if not starters or not any(
            s.strip() for s in starters if isinstance(s, str)
        ):
            warnings.append("No starter questions set — chat UI will show no suggestions")

        has_persona = bool(app.persona_id) or bool(
            app.persona_text and app.persona_text.strip()
        )
        if not has_persona:
            warnings.append("No persona set — a default persona will be used")

        if warnings:
            logger.warning(f"Publish warnings for app {application_id}: {warnings}")

        if errors:
            raise HTTPException(
                status_code=400,
                detail={"message": "Publish validation failed", "errors": errors},
            )

        app = await _app_repo.publish_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(500, "Failed to publish application")

        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/unpublish
# -------------------------------------------------------------------
@router.post("/{application_id}/unpublish", response_model=ApplicationDetail)
async def unpublish_application(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Transition PUBLISHED -> DRAFT."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.status != "published":
            raise HTTPException(400, "Application is not currently published")

        app = await _app_repo.unpublish_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(500, "Failed to unpublish application")

        return await _build_app_detail(db, app)


# ===================================================================
# APPROVAL QUEUE ENDPOINTS
# ===================================================================


async def _notify_super_admins_for_app(
    db: AsyncSession,
    app: Application,
    notif_type: str,
    title: str,
    message: str,
) -> None:
    """
    Create notifications for super_admins with matching BU/designation.

    Finds all super_admin users whose BU and designation overlap with
    the application's BU/designation links, then creates a notification
    for each.
    """
    from echolib.models.application import (
        ApplicationDesignationLink,
        ApplicationBusinessUnitLink,
    )

    app_uuid = app.application_id

    # Get super_admin user IDs with matching designation
    desig_users_stmt = (
        select(UserDesignationLink.user_id).where(
            UserDesignationLink.designation_id.in_(
                select(ApplicationDesignationLink.designation_id).where(
                    ApplicationDesignationLink.application_id == app_uuid
                )
            )
        )
    )
    # Get super_admin user IDs with matching BU
    bu_users_stmt = (
        select(UserBusinessUnitLink.user_id).where(
            UserBusinessUnitLink.business_unit_id.in_(
                select(ApplicationBusinessUnitLink.business_unit_id).where(
                    ApplicationBusinessUnitLink.application_id == app_uuid
                )
            )
        )
    )
    # Super admins who match both
    super_admins_stmt = (
        select(User.user_id).where(
            User.role == "super_admin",
            User.is_active == True,  # noqa: E712
            User.user_id.in_(desig_users_stmt),
            User.user_id.in_(bu_users_stmt),
        )
    )
    result = await db.execute(super_admins_stmt)
    sa_ids = [str(uid) for uid in result.scalars().all()]

    if not sa_ids:
        # Fallback: notify all super_admins if none match ABAC
        fallback = await db.execute(
            select(User.user_id).where(
                User.role == "super_admin",
                User.is_active == True,  # noqa: E712
            )
        )
        sa_ids = [str(uid) for uid in fallback.scalars().all()]

    if sa_ids:
        await _notif_repo.create_bulk_notifications(
            db,
            user_ids=sa_ids,
            type=notif_type,
            title=title,
            message=message,
            reference_id=str(app_uuid),
            reference_type="application",
        )


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/approve
# -------------------------------------------------------------------
@router.post("/{application_id}/approve", response_model=ApplicationDetail)
async def approve_application(
    application_id: str,
    user: UserContext = Depends(require_super_admin),
):
    """Approve an application (super_admin only)."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_application_by_id(db, application_id)
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.approval_status != "pending":
            raise HTTPException(400, f"Application is not pending approval (current: {app.approval_status})")

        app = await _app_repo.approve_application(db, application_id, user_id)
        if app is None:
            raise HTTPException(500, "Failed to approve application")

        # Audit log
        await _audit_repo.log_action(
            db,
            application_id=application_id,
            action="approved",
            performed_by=user_id,
        )

        # Notify app owner
        await _notif_repo.create_notification(
            db,
            user_id=str(app.user_id),
            type="approval_approved",
            title=f"Application '{app.name}' approved",
            message=f"Your application '{app.name}' has been approved. You can now publish it.",
            reference_id=str(app.application_id),
            reference_type="application",
        )

        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/reject
# -------------------------------------------------------------------
@router.post("/{application_id}/reject", response_model=ApplicationDetail)
async def reject_application(
    application_id: str,
    payload: RejectPayload = None,
    user: UserContext = Depends(require_super_admin),
):
    """Reject an application with optional comment (super_admin only)."""
    user_id = resolve_user_id(user)
    comment = payload.comment if payload else None

    async with get_db_session() as db:
        app = await _app_repo.get_application_by_id(db, application_id)
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.approval_status != "pending":
            raise HTTPException(400, f"Application is not pending approval (current: {app.approval_status})")

        app = await _app_repo.reject_application(db, application_id, user_id, comment)
        if app is None:
            raise HTTPException(500, "Failed to reject application")

        # Audit log
        await _audit_repo.log_action(
            db,
            application_id=application_id,
            action="rejected",
            performed_by=user_id,
            comment=comment,
        )

        # Notify app owner
        msg = f"Your application '{app.name}' was rejected."
        if comment:
            msg += f" Reason: {comment}"
        await _notif_repo.create_notification(
            db,
            user_id=str(app.user_id),
            type="approval_rejected",
            title=f"Application '{app.name}' rejected",
            message=msg,
            reference_id=str(app.application_id),
            reference_type="application",
        )

        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/resubmit-approval
# -------------------------------------------------------------------
@router.post("/{application_id}/resubmit-approval", response_model=ApplicationDetail)
async def resubmit_for_approval(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Resubmit a rejected application for approval."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_application(db, application_id, user_id)
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.approval_status != "rejected":
            raise HTTPException(400, "Only rejected applications can be resubmitted")

        app = await _app_repo.resubmit_for_approval(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(500, "Failed to resubmit application")

        # Audit log
        await _audit_repo.log_action(
            db,
            application_id=application_id,
            action="resubmitted",
            performed_by=user_id,
        )

        # Notify super_admins
        await _notify_super_admins_for_app(
            db, app,
            notif_type="approval_pending",
            title=f"Application '{app.name}' resubmitted",
            message=f"Application '{app.name}' has been resubmitted for approval.",
        )

        return await _build_app_detail(db, app)


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/audit-trail
# -------------------------------------------------------------------
@router.get("/{application_id}/audit-trail", response_model=List[AuditLogEntry])
async def get_audit_trail(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Get the approval audit trail for an application."""
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Verify caller owns the app or is super_admin
        app = await _app_repo.get_application_by_id(db, application_id)
        if app is None:
            raise HTTPException(404, "Application not found")
        if str(app.user_id) != user_id and getattr(user, "role", "") != "super_admin":
            raise HTTPException(403, "You can only view audit trails for your own applications")

        entries = await _audit_repo.get_audit_trail(db, application_id=application_id)
        return [
            AuditLogEntry(
                audit_id=str(e.audit_id),
                action=e.action,
                performed_by=str(e.performed_by),
                comment=e.comment,
                created_at=e.created_at,
            )
            for e in entries
        ]


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/context-ledger -- Datasource health
#
# NOT "/context": that path is already taken by PATCH, which edits the
# application's welcome prompt, disclaimer and starter questions. Two
# unrelated meanings on one path would be a trap for the frontend, so the
# ledger gets its own name. (app-plan.md §10.4 names "/context"; this is the
# deviation, recorded here.)
# -------------------------------------------------------------------
@router.get("/{application_id}/context-ledger")
async def get_application_context(
    application_id: str,
    session_id: Optional[str] = Query(
        None,
        description=(
            "Optional chat session UUID. When given, the response also reports "
            "the documents uploaded into that session."
        ),
    ),
    refresh: bool = Query(
        False, description="Re-resolve every source instead of serving the cache."
    ),
    user: UserContext = Depends(require_user),
):
    """
    Report what evidence this application can actually draw on.

    WHAT: Every linked datasource and knowledge base with its resolved kind,
          whether it is reachable, and how much is in it — plus the documents
          uploaded into ``session_id`` when one is supplied.
    WHY:  Today a database that is attached but unreachable, or a knowledge
          base with zero indexed documents, fails silently: the application
          simply answers worse and nothing says why. This is the surface that
          makes that visible, and it is the same ledger the chat pipeline runs
          on, so what it reports is what actually happens.

    Never returns a credential, a connection string, or any source content —
    identity, health and counts only. ``200`` even when sources are unhealthy:
    being unhealthy is an answer, not an error.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(
            db, application_id, user_id, user.role
        )
        if app is None:
            raise HTTPException(404, "Application not found")

        from apps.appmgr.context import get_or_build_ledger
        from echolib.repositories.application_chat_repo import (
            ApplicationChatRepository,
        )

        ledger = await get_or_build_ledger(
            app,
            user_id=user_id,
            chat_session_id=session_id,
            chat_repo=ApplicationChatRepository() if session_id else None,
            db=db if session_id else None,
            force=refresh,
        )
        return ledger.describe()


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/logo -- Upload Logo
# -------------------------------------------------------------------
@router.post("/{application_id}/logo", response_model=ApplicationDetail)
async def upload_logo(
    application_id: str,
    file: UploadFile = File(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """Upload an application logo (PNG/JPEG/WEBP, resized to 250x250 max)."""
    user_id = resolve_user_id(user)

    if file.content_type not in {"image/png", "image/jpeg", "image/webp"}:
        raise HTTPException(400, "Only PNG, JPEG, or WEBP images are allowed")

    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
        if app is None:
            raise HTTPException(404, "Application not found")

        filename = f"{application_id}_{uuid.uuid4().hex}.png"
        path = os.path.join(LOGOS_DIR, filename)

        try:
            from PIL import Image

            img = Image.open(file.file).convert("RGBA")
        except Exception:
            raise HTTPException(400, "Invalid image file")

        max_dim = 250
        if img.width > max_dim or img.height > max_dim:
            img.thumbnail((max_dim, max_dim), Image.LANCZOS)

        img.save(path, format="PNG")

        logo_url = f"/static/logos/{filename}"
        app = await _app_repo.update_application(
            db, application_id, user_id, user.role, logo_url=logo_url
        )
        if app is None:
            raise HTTPException(500, "Failed to update logo")

        return await _build_app_detail(db, app)


# ===================================================================
# Chat Endpoints (Phase 4)
# ===================================================================


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/chat -- Full Pipeline
# -------------------------------------------------------------------
@router.post("/{application_id}/chat", response_model=ChatResponse)
async def chat_with_application(
    application_id: str,
    payload: ChatMessageRequest,
    user: UserContext = Depends(require_user),
):
    """
    Send a chat message to a published application.

    Runs the full orchestration pipeline: pre-guardrails, prompt enhancement,
    orchestrator LLM, skill execution, post-guardrails, persona formatting.

    If ``session_id`` is omitted from the request, a new chat session is
    created automatically. The response includes the session_id for
    subsequent messages.
    """
    user_id = resolve_user_id(user)

    # Validate application exists and user has access
    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(
            db, application_id, user_id, user.role
        )
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.status != "published":
            raise HTTPException(
                400,
                "Application is not published. Only published applications can be used for chat.",
            )

    # Run the full orchestration pipeline in its own DB session
    # (pipeline manages its own session lifecycle internally for
    # multi-step operations that may need partial commits)
    from .orchestrator.pipeline import OrchestrationPipeline

    pipeline = OrchestrationPipeline()

    async with get_db_session() as db:
        result = await pipeline.run(
            db=db,
            application_id=application_id,
            chat_session_id=payload.session_id,
            user_message=payload.message,
            user_id=user_id,
        )

    # Build the ChatMessageResponse for the assistant reply
    assistant_message = ChatMessageResponse(
        message_id=result.get("execution_trace", {}).get("message_id", ""),
        role="assistant",
        content=result.get("response", ""),
        enhanced_prompt=result.get("execution_trace", {}).get("enhanced_prompt"),
        execution_trace=result.get("execution_trace"),
        guardrail_flags=result.get("execution_trace", {}).get("guardrail_output"),
        created_at=datetime.now(timezone.utc),
    )

    # Build session metadata if this was a new session
    session_meta = None
    raw_meta = result.get("session_metadata")
    if raw_meta:
        session_meta = ChatSessionMetadata(
            app_name=raw_meta.get("app_name", ""),
            app_description=raw_meta.get("app_description"),
            app_logo_url=raw_meta.get("app_logo_url"),
            welcome_prompt=raw_meta.get("welcome_prompt"),
            disclaimer=raw_meta.get("disclaimer"),
            starter_questions=raw_meta.get("starter_questions", []),
        )

    return ChatResponse(
        session_id=result.get("session_id", ""),
        message=assistant_message,
        conversation_state=result.get("conversation_state", "awaiting_input"),
        session_metadata=session_meta,
    )


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/chat/stream -- A2UI SSE
# -------------------------------------------------------------------
@router.post("/{application_id}/chat/stream")
async def chat_stream(
    application_id: str,
    payload: ChatMessageRequest,
    user: UserContext = Depends(require_user),
):
    """
    Streaming version of chat that emits A2UI v0.8 JSONL events via SSE.

    The client receives real-time execution step updates as the pipeline
    runs.  Each SSE event ``data:`` field contains a single A2UI JSONL
    message (surfaceUpdate, dataModelUpdate, or beginRendering).

    The stream terminates after the pipeline completes and the final
    output has been sent.
    """
    import json as _json

    user_id = resolve_user_id(user)

    # Validate application exists and user has access
    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(
            db, application_id, user_id, user.role
        )
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.status != "published":
            raise HTTPException(
                400,
                "Application is not published. Only published applications can be used for chat.",
            )

    # Use run_ prefix so the run_id matches the format that
    # WorkflowExecutor uses for ws_manager queue subscription routing.
    run_id = f"run_{uuid.uuid4().hex}"

    sse_queue: asyncio.Queue = asyncio.Queue(maxsize=500)

    # Assigned just below, before the response is iterated. The generator
    # reads it to decide whether a quiet stream is a working run or a dead
    # one -- which is a fact, not a timeout.
    pipeline_task: Optional[asyncio.Task] = None

    async def sse_generator():
        """Yield A2UI JSONL lines from sse_queue as SSE data frames.

        The pipeline's run_stream() manages its own ws_manager queue
        subscriptions and translator task lifecycle.  This generator
        only reads from sse_queue until it receives a None sentinel.

        WHY THE HEARTBEAT: this stream used to yield only when the pipeline
        pushed something, and a workflow can legitimately go minutes without
        producing an event -- an agent waiting on a rate-limit window, a model
        retrying with backoff, a long generation in flight. Azure's load
        balancer closes a TCP connection that has carried no bytes for 230
        seconds, and that limit "is not configurable and cannot be changed".

        So the browser's ``fetch`` was being severed mid-run while the backend
        carried on: ``_run_pipeline`` is a detached task and never knew the
        client had gone. The user saw a step start, freeze, and finally fail
        with a network error, while the logs showed the run completing. The
        previous ``timeout=300.0`` guard could never help -- it sits *above*
        the platform's own 230s ceiling, so the connection was always killed
        first.

        A comment frame (``:``) is the SSE spec's own keep-alive. It carries no
        event, and this codebase's client already skips any line that does not
        begin with ``data: ``, so nothing downstream changes.

        Transport-level and therefore provider-agnostic: Azure, OpenAI,
        Anthropic, Gemini and Ollama runs are all held open by the same frame.
        """
        idle_seconds = 0.0
        try:
            while True:
                try:
                    item = await asyncio.wait_for(
                        sse_queue.get(), timeout=_SSE_HEARTBEAT_SECONDS
                    )
                except asyncio.TimeoutError:
                    idle_seconds += _SSE_HEARTBEAT_SECONDS

                    # LIVENESS, NOT ELAPSED SILENCE.
                    #
                    # This used to close the stream after a fixed 180 seconds of
                    # quiet, and that number was wrong by construction: how long
                    # a healthy run stays quiet depends on agent count, rate-limit
                    # pacing, model, quota and reasoning effort -- none of which
                    # are knowable when a constant is written. A fourteen-agent
                    # run with two agents paced tens of seconds apart exceeded it
                    # and a perfectly healthy stream was killed.
                    #
                    # The backend already knows the answer without guessing: the
                    # task running the pipeline is either alive or it is not. A
                    # live task is progressing even when it is deliberately
                    # sleeping out a rate-limit window, so the stream stays open
                    # for exactly as long as there is work, and closes the moment
                    # there is not.
                    if pipeline_task is not None and pipeline_task.done():
                        # The run finished (or failed) without a sentinel. Drain
                        # anything already queued before closing, so a final
                        # message is never lost to this check.
                        if not sse_queue.empty():
                            continue
                        failure = pipeline_task.exception() if not pipeline_task.cancelled() else None
                        if failure is not None:
                            logger.error(
                                "SSE stream for run %s: the pipeline failed after "
                                "%.0fs of quiet -- %s: %s",
                                run_id, idle_seconds,
                                type(failure).__name__, failure,
                            )
                            yield (
                                "data: "
                                + _json.dumps({
                                    "type": "error",
                                    "message": (
                                        "The run could not be completed. "
                                        f"{failure}"
                                    ),
                                })
                                + "\n\n"
                            )
                        else:
                            logger.info(
                                "SSE stream for run %s: pipeline finished; "
                                "closing the stream.", run_id,
                            )
                        break

                    # Still working. Log sparingly so a long run leaves a trail
                    # without flooding, and keep the connection alive.
                    if idle_seconds % _SSE_QUIET_LOG_SECONDS < _SSE_HEARTBEAT_SECONDS:
                        logger.info(
                            "SSE stream for run %s: quiet for %.0fs, pipeline "
                            "still running (agents may be paced or generating).",
                            run_id, idle_seconds,
                        )
                    yield ": keepalive\n\n"
                    continue

                idle_seconds = 0.0
                if item is None:  # sentinel -- stream ended
                    break
                # Ensure item is a string for the SSE data field
                if isinstance(item, dict):
                    data = _json.dumps(item, separators=(",", ":"))
                else:
                    data = str(item)
                yield f"data: {data}\n\n"
        except asyncio.CancelledError:
            # The client went away. Expected on navigation; not an error.
            logger.info("SSE stream for run %s was closed by the client", run_id)
            raise

    from .orchestrator.pipeline import OrchestrationPipeline

    pipeline = OrchestrationPipeline()

    async def _run_pipeline():
        async with get_db_session() as db:
            await pipeline.run_stream(
                sse_queue=sse_queue,
                run_id=run_id,
                db=db,
                app_id=application_id,
                user_input=payload.message,
                session_id=payload.session_id,
                user_id=user_id,
                uploaded_file_ids=payload.attachment_ids,
            )

    pipeline_task = asyncio.create_task(_run_pipeline())

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# -------------------------------------------------------------------
# Shared helper: resume a workflow from HITL interrupt, handle result
# -------------------------------------------------------------------
async def _resume_workflow_and_finalize(
    db: AsyncSession,
    session_id: str,
    app,
    hitl_state: dict,
    action: str,
    resume_payload: dict,
    user_id: str,
) -> HITLDecisionResponse:
    """
    Shared logic: resume a workflow from HITL interrupt, handle result.

    Used by both the hitl-decide endpoint (approve/edit/skip) and the
    upload endpoint (file_upload interrupt resume).
    """
    from .orchestrator.skill_executor import SkillExecutor

    executor = SkillExecutor._resolve_workflow_executor()

    run_id = hitl_state.get("run_id", "")
    workflow_id = hitl_state.get("workflow_id", "")
    fs_workflow_id = hitl_state.get("fs_workflow_id", "")

    # Pre-load workflow definition in the current async context
    _effective_wf_id = fs_workflow_id or workflow_id
    workflow_def = None
    try:
        from echolib.di import container as di_container
        gateway = di_container.resolve('workflow.storage_gateway')
        workflow_def = await gateway.load_workflow(
            _effective_wf_id, user_id or DEFAULT_USER_ID, state="draft",
        )
    except Exception as _preload_err:
        logger.warning(
            f"[HITL-RESUME] Could not pre-load workflow "
            f"'{_effective_wf_id}': {_preload_err}. "
            f"Falling back to executor._load_workflow()."
        )

    # resume_workflow is synchronous (LangGraph invoke)
    resume_result = await asyncio.to_thread(
        executor.resume_workflow,
        workflow_id=_effective_wf_id,
        run_id=run_id,
        action=action,
        payload=resume_payload,
        execution_mode="draft",
        user_id=user_id,
        workflow_def=workflow_def,
    )

    if resume_result.get("status") == "failed":
        error_msg = (
            f"Workflow resume failed: {resume_result.get('error', 'unknown')}"
        )
        await _chat_repo.add_message(
            db, session_id, "assistant", error_msg,
            execution_trace={"type": "hitl_resume_failed", "run_id": run_id},
            user_id=user_id,
            application_id=str(app.application_id),
        )
        await _chat_repo.update_session_state(
            db,
            session_id,
            conversation_state="awaiting_input",
            context_data={},
            user_id=user_id,
            application_id=str(app.application_id),
        )
        return HITLDecisionResponse(
            status="failed",
            message=error_msg,
            session_id=session_id,
            conversation_state="awaiting_input",
            execution_trace={
                "action": action,
                "run_id": run_id,
                "error": resume_result.get("error"),
            },
        )

    # Check if we hit ANOTHER interrupt (chained HITL nodes)
    if resume_result.get("status") == "interrupted":
        new_interrupt = resume_result.get("interrupt", {})
        new_allowed = new_interrupt.get(
            "allowed_decisions", new_interrupt.get("allowed_actions", ["approve", "reject"])
        )

        new_hitl_state = {
            "hitl_state": {
                "run_id": resume_result.get("run_id", run_id),
                "workflow_id": workflow_id,
                "fs_workflow_id": fs_workflow_id,
                "interrupt_payload": new_interrupt,
                "interrupt_type": new_interrupt.get("interrupt_type", "hitl"),
                "completed_steps": hitl_state.get("completed_steps", []),
                "remaining_plan": hitl_state.get("remaining_plan", []),
                "execution_plan": hitl_state.get("execution_plan", []),
                "execution_strategy": hitl_state.get("execution_strategy", "single"),
                "enhanced_prompt": hitl_state.get("enhanced_prompt", ""),
            }
        }

        re_interrupt_msg = (
            "Workflow paused again for human review."
            f"\n\n**{new_interrupt.get('title', 'Review Required')}**: "
            f"{new_interrupt.get('message', 'Please review and decide.')}"
        )

        await _chat_repo.add_message(
            db, session_id, "assistant", re_interrupt_msg,
            execution_trace={
                "type": "hitl_interrupt",
                "hitl_context": {
                    "title": new_interrupt.get("title"),
                    "message": new_interrupt.get("message"),
                    "priority": new_interrupt.get("priority"),
                    "allowed_decisions": new_allowed,
                    "run_id": resume_result.get("run_id", run_id),
                    "node_outputs": new_interrupt.get("node_outputs"),
                },
            },
            user_id=user_id,
            application_id=str(app.application_id),
        )

        await _chat_repo.update_session_state(
            db,
            session_id,
            conversation_state="awaiting_clarification",
            context_data=new_hitl_state,
            user_id=user_id,
            application_id=str(app.application_id),
        )

        return HITLDecisionResponse(
            status="interrupted",
            message=re_interrupt_msg,
            session_id=session_id,
            conversation_state="awaiting_hitl_review",
            execution_trace={
                "action": action,
                "hitl_context": {
                    "title": new_interrupt.get("title"),
                    "message": new_interrupt.get("message"),
                    "priority": new_interrupt.get("priority"),
                    "allowed_decisions": new_allowed,
                    "run_id": resume_result.get("run_id", run_id),
                },
            },
        )

    # ----- COMPLETED -----
    output = resume_result.get("output", {})
    resumed_output_text = SkillExecutor._extract_output_text(output)

    all_completed_outputs = []
    for cs in hitl_state.get("completed_steps", []):
        all_completed_outputs.append(cs.get("output", ""))
    all_completed_outputs.append(resumed_output_text)

    # Execute remaining plan steps (if any)
    remaining_plan = hitl_state.get("remaining_plan", [])
    remaining_execution_log: List[Dict[str, Any]] = []

    if remaining_plan:
        skill_executor = SkillExecutor()
        enhanced_prompt = hitl_state.get("enhanced_prompt", "")

        remaining_result = await skill_executor.execute_plan(
            db=db,
            execution_plan=remaining_plan,
            execution_strategy="sequential",
            user_input=resumed_output_text,
            app_id=str(app.application_id),
            user_id=user_id,
            chat_session_id=session_id,
            application_id=str(app.application_id),
        )

        if remaining_result.get("hitl_interrupted"):
            remaining_interrupt = remaining_result.get("interrupt_payload", {})
            remaining_int_ctx = remaining_interrupt.get("interrupt", {})

            for cs in remaining_result.get("completed_steps", []):
                all_completed_outputs.append(cs.get("output", ""))

            new_hitl_state = {
                "hitl_state": {
                    "run_id": remaining_result.get("run_id", ""),
                    "workflow_id": remaining_result.get("workflow_id", ""),
                    "fs_workflow_id": remaining_interrupt.get("fs_workflow_id", ""),
                    "interrupt_payload": remaining_int_ctx,
                    "interrupt_type": remaining_int_ctx.get("interrupt_type", "hitl"),
                    "completed_steps": (
                        hitl_state.get("completed_steps", [])
                        + [{"step": "resumed", "skill_name": "resumed_workflow", "output": resumed_output_text}]
                        + remaining_result.get("completed_steps", [])
                    ),
                    "remaining_plan": remaining_result.get("remaining_plan", []),
                    "execution_plan": hitl_state.get("execution_plan", []),
                    "execution_strategy": hitl_state.get("execution_strategy", "sequential"),
                    "enhanced_prompt": enhanced_prompt,
                }
            }

            new_allowed = remaining_int_ctx.get(
                "allowed_decisions", ["approve", "reject"]
            )
            re_interrupt_msg = (
                "Workflow paused again for human review."
                f"\n\n**{remaining_int_ctx.get('title', 'Review Required')}**: "
                f"{remaining_int_ctx.get('message', 'Please review and decide.')}"
            )

            await _chat_repo.add_message(
                db, session_id, "assistant", re_interrupt_msg,
                execution_trace={
                    "type": "hitl_interrupt",
                    "hitl_context": {
                        "title": remaining_int_ctx.get("title"),
                        "message": remaining_int_ctx.get("message"),
                        "priority": remaining_int_ctx.get("priority"),
                        "allowed_decisions": new_allowed,
                        "run_id": remaining_result.get("run_id", ""),
                    },
                },
                user_id=user_id,
                application_id=str(app.application_id),
            )
            await _chat_repo.update_session_state(
                db, session_id,
                conversation_state="awaiting_clarification",
                context_data=new_hitl_state,
                user_id=user_id,
                application_id=str(app.application_id),
            )

            return HITLDecisionResponse(
                status="interrupted",
                message=re_interrupt_msg,
                session_id=session_id,
                conversation_state="awaiting_hitl_review",
                execution_trace={
                    "action": action,
                    "hitl_context": {
                        "title": remaining_int_ctx.get("title"),
                        "message": remaining_int_ctx.get("message"),
                        "priority": remaining_int_ctx.get("priority"),
                        "allowed_decisions": new_allowed,
                        "run_id": remaining_result.get("run_id", ""),
                    },
                },
            )

        remaining_final = remaining_result.get("final_output", "")
        if remaining_final:
            all_completed_outputs.append(remaining_final)
        remaining_execution_log = remaining_result.get("execution_log", [])

    final_output = all_completed_outputs[-1] if all_completed_outputs else resumed_output_text

    # Post-guardrails on the final output
    from .orchestrator.guardrails import GuardrailsEngine

    guardrails_engine = GuardrailsEngine()
    guardrail_categories: List[str] = []
    if app.guardrail_links:
        from echolib.models.application_lookups import AppGuardrailCategory
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select as _select

        cat_ids = []
        for link in app.guardrail_links:
            uid = safe_uuid(str(link.guardrail_category_id))
            if uid:
                cat_ids.append(uid)
        if cat_ids:
            cat_result = await db.execute(
                _select(AppGuardrailCategory).where(
                    AppGuardrailCategory.guardrail_category_id.in_(cat_ids)
                )
            )
            guardrail_categories = [
                c.name for c in cat_result.scalars().all()
            ]

    post_guard = guardrails_engine.post_process(
        final_output,
        guardrail_categories=guardrail_categories,
        guardrail_text=app.guardrail_text,
    )
    final_output = post_guard.sanitized_text

    # Save the final assistant message
    await _chat_repo.add_message(
        db, session_id, "assistant", final_output,
        execution_trace={
            "type": "hitl_resumed_completion",
            "run_id": run_id,
            "action": action,
            "remaining_steps_executed": len(remaining_plan),
            "remaining_execution_log": remaining_execution_log,
            "guardrail_output": {
                "is_safe": post_guard.is_safe,
                "violations": post_guard.violations,
            },
        },
        user_id=user_id,
        application_id=str(app.application_id),
    )

    # Clear HITL state and return to normal
    await _chat_repo.update_session_state(
        db,
        session_id,
        conversation_state="awaiting_input",
        context_data={},
        user_id=user_id,
        application_id=str(app.application_id),
    )

    return HITLDecisionResponse(
        status="completed",
        message=final_output,
        session_id=session_id,
        conversation_state="awaiting_input",
        execution_trace={
            "action": action,
            "run_id": run_id,
            "status": "completed",
            "remaining_steps_executed": len(remaining_plan),
        },
    )


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/chat/hitl-decide
# -- Human-in-the-Loop Decision
# -------------------------------------------------------------------
@router.post(
    "/{application_id}/chat/hitl-decide",
    response_model=HITLDecisionResponse,
)
async def hitl_decide(
    application_id: str,
    payload: HITLDecisionRequest,
    user: UserContext = Depends(require_user),
):
    """
    Submit a human decision for a workflow paused at a HITL node.

    The chat session must be in ``awaiting_clarification`` state with
    a valid ``hitl_state`` stored in ``context_data``.  The action must
    be one of the ``allowed_decisions`` defined by the HITL node.

    Supported actions:
        - **approve**: Resume the workflow from the interrupt point.
        - **reject**: Terminate the workflow and return to normal chat.
        - **edit**: Resume with modified payload.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # 1. Validate application exists and user has access
        app = await _app_repo.get_accessible_application(
            db, application_id, user_id, user.role
        )
        if app is None:
            raise HTTPException(404, "Application not found")
        if app.status != "published":
            raise HTTPException(
                400,
                "Application is not published.",
            )

        # 2. Validate session exists and is in HITL review state
        session = await _chat_repo.get_session(db, payload.session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application")

        # HITL uses 'awaiting_clarification' as DB state with hitl_state
        # in context_data to distinguish from regular clarification.
        context_data = session.context_data or {}
        hitl_state = context_data.get("hitl_state")

        if session.conversation_state != "awaiting_clarification" or not hitl_state:
            raise HTTPException(
                400,
                "Session is not awaiting HITL review. "
                "Current state does not have a pending HITL interrupt.",
            )

        # 3. Validate action is allowed
        interrupt_payload = hitl_state.get("interrupt_payload", {})
        allowed_decisions = (
            interrupt_payload.get("allowed_decisions")
            or interrupt_payload.get("allowed_actions")
            or ["approve", "reject"]
        )

        # Also try to derive from the HITL config if available
        try:
            from apps.workflow.runtime.hitl import derive_allowed_decisions
            hitl_config = interrupt_payload.get("hitl_config")
            if hitl_config:
                allowed_decisions = derive_allowed_decisions(hitl_config)
        except ImportError:
            pass

        if payload.action not in allowed_decisions:
            raise HTTPException(
                400,
                f"Action '{payload.action}' is not allowed. "
                f"Allowed decisions: {allowed_decisions}",
            )

        run_id = hitl_state.get("run_id", "")
        workflow_id = hitl_state.get("workflow_id", "")
        fs_workflow_id = hitl_state.get("fs_workflow_id", "")

        # ----- REJECT -----
        if payload.action == "reject":
            reject_msg = "Workflow execution was rejected by human reviewer."
            if payload.rationale:
                reject_msg += f"\n\nRationale: {payload.rationale}"

            await _chat_repo.add_message(
                db, payload.session_id, "assistant", reject_msg,
                execution_trace={"type": "hitl_reject", "run_id": run_id},
            )

            # Clear HITL state and return to normal
            await _chat_repo.update_session_state(
                db,
                payload.session_id,
                conversation_state="awaiting_input",
                context_data={},
            )

            return HITLDecisionResponse(
                status="rejected",
                message=reject_msg,
                session_id=payload.session_id,
                conversation_state="awaiting_input",
                execution_trace={"action": "reject", "run_id": run_id},
            )

        # ----- SKIP (file_upload interrupt only) -----
        if payload.action == "skip":
            if hitl_state.get("interrupt_type") != "file_upload":
                raise HTTPException(
                    400,
                    "Skip action is only allowed for file_upload interrupts.",
                )
            return await _resume_workflow_and_finalize(
                db, payload.session_id, app, hitl_state,
                action="skip",
                resume_payload={"document_context": "", "document_metadata": {"skipped": True}},
                user_id=user_id,
            )

        # ----- APPROVE or EDIT -----
        # Both require resuming the workflow via WorkflowExecutor
        resume_payload = payload.payload or {}
        if payload.rationale:
            resume_payload["rationale"] = payload.rationale

        return await _resume_workflow_and_finalize(
            db, payload.session_id, app, hitl_state,
            action=payload.action,
            resume_payload=resume_payload,
            user_id=user_id,
        )


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/chat/history -- List Sessions
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/chat/history",
    response_model=List[ChatSessionResponse],
)
async def list_chat_sessions(
    application_id: str,
    user: UserContext = Depends(require_user),
):
    """
    List all chat sessions for an application, scoped to the current user.

    Returns sessions ordered by ``updated_at`` descending (most recent first).
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Validate application exists and user has access
        app = await _app_repo.get_accessible_application(
            db, application_id, user_id, user.role
        )
        if app is None:
            raise HTTPException(404, "Application not found")

        sessions = await _chat_repo.list_sessions(db, application_id, user_id)

        return [
            ChatSessionResponse(
                chat_session_id=str(s.chat_session_id),
                application_id=str(s.application_id),
                title=s.title,
                conversation_state=s.conversation_state,
                started_at=s.started_at,
                updated_at=s.updated_at,
                message_count=len(s.messages) if s.messages else 0,
            )
            for s in sessions
        ]


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/chat/sessions/{session_id}
# -- Get Messages for a Session
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/chat/sessions/{session_id}",
    response_model=List[ChatMessageResponse],
)
async def get_chat_messages(
    application_id: str,
    session_id: str,
    user: UserContext = Depends(require_user),
):
    """
    Get all messages for a specific chat session.

    Validates that the session belongs to the current user and the
    specified application before returning messages.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Verify session exists and is owned by user AND belongs to this application
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application")

        messages = await _chat_repo.get_messages(db, session_id)

        return [
            ChatMessageResponse(
                message_id=str(msg.message_id),
                role=msg.role,
                content=msg.content,
                enhanced_prompt=msg.enhanced_prompt,
                execution_trace=msg.execution_trace,
                guardrail_flags=msg.guardrail_flags,
                created_at=msg.created_at,
            )
            for msg in messages
        ]


# -------------------------------------------------------------------
# DELETE /api/applications/{application_id}/chat/sessions/{session_id}
# -- Close a Chat Session
# -------------------------------------------------------------------
@router.delete(
    "/{application_id}/chat/sessions/{session_id}",
    status_code=204,
)
async def close_chat_session(
    application_id: str,
    session_id: str,
    user: UserContext = Depends(require_user),
):
    """
    Close (soft-delete) a chat session.

    The session is marked as closed and will no longer accept new messages.
    Existing messages are preserved for audit purposes.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Verify session exists and is owned by user AND belongs to this application
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application")

        await _chat_repo.close_session(db, session_id, user_id, application_id)

    return Response(status_code=204)


# -------------------------------------------------------------------
# PATCH /api/applications/{application_id}/chat/sessions/{session_id}/title
# -- Rename a Chat Session
# -------------------------------------------------------------------
@router.patch(
    "/{application_id}/chat/sessions/{session_id}/title",
    response_model=ChatSessionResponse,
)
async def rename_chat_session(
    application_id: str,
    session_id: str,
    payload: TitleUpdateRequest,
    user: UserContext = Depends(require_user),
):
    """
    Rename a chat session by updating its title.

    The title is stripped of leading/trailing whitespace and must be
    between 1 and 200 characters.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Verify session exists and is owned by user AND belongs to this application
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application")

        # Update the title
        updated = await _chat_repo.update_session_title(
            db, session_id, payload.title, user_id, application_id
        )
        if updated == 0:
            raise HTTPException(404, "Chat session not found")

        # Re-fetch the session to return updated metadata
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found after update")

        return ChatSessionResponse(
            chat_session_id=str(session.chat_session_id),
            application_id=str(session.application_id),
            title=session.title,
            conversation_state=session.conversation_state,
            started_at=session.started_at,
            updated_at=session.updated_at,
            message_count=len(session.messages) if hasattr(session, 'messages') and session.messages else 0,
        )


# -------------------------------------------------------------------
# GET /api/applications/{id}/chat/sessions/{id}/export/pdf
# -- Export Chat Session as PDF
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/chat/sessions/{session_id}/export/pdf",
)
async def export_chat_session_pdf(
    application_id: str,
    session_id: str,
    user: UserContext = Depends(require_user),
):
    """
    Export all messages for a chat session as a downloadable PDF.

    Validates that the session belongs to the current user and the
    specified application before generating the export.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application")

        messages = await _chat_repo.get_messages(db, session_id, limit=10000)

        title = session.title or "Untitled Session"
        date_str = (
            session.started_at.strftime("%Y-%m-%d")
            if session.started_at
            else ""
        )
        msg_dicts = [
            {
                "role": msg.role,
                "content": msg.content,
                "created_at": msg.created_at,
            }
            for msg in messages
        ]

    buf = generate_chat_pdf(
        title=title,
        date=date_str,
        message_count=len(msg_dicts),
        messages=msg_dicts,
    )

    return StreamingResponse(
        buf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f'attachment; filename="chat_export_{session_id}.pdf"'
            ),
        },
    )


# -------------------------------------------------------------------
# How much of an interrupt document is handed to the resuming workflow node
# inline. The document is also indexed and searchable, so this is a head start
# rather than the only access -- which is why it is bounded rather than whole.
HITL_DOCUMENT_CONTEXT_CHARS = 24000


def _hitl_document_context_chars() -> int:
    """Inline budget for a document uploaded into a file_upload interrupt."""
    try:
        return max(
            1000,
            int(os.getenv("APP_HITL_DOCUMENT_CONTEXT_CHARS", str(HITL_DOCUMENT_CONTEXT_CHARS))),
        )
    except (TypeError, ValueError):
        return HITL_DOCUMENT_CONTEXT_CHARS


def _format_upload_event_text(filename: str, status: str, size_bytes: Optional[int]) -> str:
    """Build a human-readable upload event line for the chat timeline."""
    normalized_status = (status or "unknown").lower()
    if size_bytes and size_bytes > 0:
        size_mb = size_bytes / (1024 * 1024)
        return f"Uploaded file: {filename} ({normalized_status}, {size_mb:.2f} MB)"
    return f"Uploaded file: {filename} ({normalized_status})"


async def _record_upload_history_event(
    db: AsyncSession,
    application_id: str,
    session_id: str,
    user_id: str,
    upload: DocumentUploadResponse,
) -> None:
    """
    Persist one timeline event per uploaded file.

    WHY: upload rows are durable in ``application_documents`` but the chat
    timeline is sourced from ``application_chat_messages``. Without writing
    an explicit message event, uploads disappear from session history reloads.
    """
    try:
        content = _format_upload_event_text(
            filename=upload.filename,
            status=upload.processing_status,
            size_bytes=upload.size_bytes,
        )
        await _chat_repo.add_message(
            db,
            session_id,
            "user",
            content,
            execution_trace={
                "type": "file_upload_event",
                "file_upload": {
                    "document_id": upload.document_id,
                    "session_id": upload.session_id,
                    "filename": upload.filename,
                    "processing_status": upload.processing_status,
                    "mime_type": upload.mime_type,
                    "size_bytes": upload.size_bytes,
                    "chunk_count": upload.chunk_count,
                },
            },
            user_id=user_id,
            application_id=application_id,
        )
    except Exception:
        logger.exception(
            "Failed to persist upload history event: app=%s session=%s file=%s",
            application_id,
            session_id,
            upload.filename,
        )


# -------------------------------------------------------------------
# Shared helper: save, index, and record a single uploaded file
# -------------------------------------------------------------------
async def _process_single_upload(
    db: AsyncSession,
    application_id: str,
    session_id: str,
    file: UploadFile,
    rag_manager,
    user_id: Optional[str] = None,
) -> DocumentUploadResponse:
    """
    Save one uploaded file to disk, create the DB record, chunk + embed
    into the session-scoped FAISS index, and return a response model.

    This is the canonical single-file processing logic.  Both the
    existing ``/chat/upload`` endpoint (single file, backward-compatible)
    and the new ``/chat/upload-batch`` endpoint (multiple files) delegate
    here so there is exactly ONE code path for file ingestion.

    CRITICAL STATE MANAGEMENT: The document is marked 'ready' only after
    PostgreSQL successfully commits the stored chunks. If storage fails
    (e.g., timeout, connection loss), the document status is 'failed' and
    the HTTP response reflects that, rather than returning 201 Created
    for an unusable document.

    Args:
        db: Active async DB session (caller manages commit/rollback).
        application_id: Application UUID string.
        session_id: Chat session UUID string (must already exist).
        file: Validated UploadFile (caller must call validate_upload first).
        rag_manager: SessionRAGManager instance, or None if unavailable.
        user_id: The uploading user. Required for OCR and embeddings: every
            model on this platform is a user's own credential, so without it
            the vision client and the embeddings client both resolve to
            nothing, the OCR pass is skipped, and no passage can be embedded.

    Returns:
        DocumentUploadResponse with processing results and session_id.

    A document is 'ready' when its text could be read. Indexing is reported
    separately through ``chunk_count``: conversion needs no model and embedding
    needs a resolvable credential, so a file that converted perfectly used to be
    recorded as 'failed' the moment embeddings were unavailable -- and the
    extracted text was discarded with it. 'failed' now means the file could not
    be read at all.
    """
    from apps.appmgr import document_store

    original_filename = file.filename or "unnamed"
    stored_filename = f"{application_id}_{uuid.uuid4().hex}_{original_filename}"
    file_path = document_store.local_path(stored_filename)

    # Create DB record first (DB-first pattern: no orphaned files on DB failure).
    # size_bytes is set to 0 initially and updated after streaming completes.
    doc = await _chat_repo.create_document(
        db,
        application_id=application_id,
        chat_session_id=session_id,
        original_filename=original_filename,
        stored_filename=stored_filename,
        mime_type=file.content_type,
        size_bytes=0,
    )
    doc_id = str(doc.document_id)

    # Read in 1MB chunks. The size ceiling is already enforced by
    # ``validate_upload`` before this runs, so the payload is bounded.
    size_bytes = 0
    try:
        buffer = bytearray()
        while chunk := await file.read(1024 * 1024):
            buffer.extend(chunk)
            size_bytes += len(chunk)
        payload = bytes(buffer)
    except Exception:
        logger.exception("Failed to read uploaded file: %s", original_filename)
        await _chat_repo.update_document_status(db, doc_id, "failed")
        return DocumentUploadResponse(
            document_id=doc_id,
            session_id=session_id,
            filename=original_filename,
            processing_status="failed",
            mime_type=file.content_type,
            size_bytes=0,
            chunk_count=0,
        )

    # Postgres is the record. This is what makes an uploaded document survive a
    # restart, a redeploy, or a request landing on a different replica —
    # previously the bytes existed only under APP_UPLOADS_DIR and were lost
    # with the container, while this row went on claiming the document existed.
    if document_store.KEEP_ORIGINALS:
        await _chat_repo.update_document_content(db, doc_id, payload)

    # The local copy is a cache of that record, for the tools that still take a
    # path (tabular analysis, image analysis). Failing to write it is not fatal:
    # ``document_store.materialize`` writes it back from Postgres on demand.
    document_store.write_local_copy(stored_filename, payload)

    # Mark as "processing" and update actual file size
    await _chat_repo.update_document_status(
        db, doc_id, "processing", size_bytes=size_bytes
    )

    # Commit the document row before indexing begins.
    #
    # Passage storage runs on its own connection: ``session_documents._store``
    # bridges to a thread and opens a fresh ``get_db_session()``, because an
    # AsyncSession cannot be shared across threads. That connection is a
    # separate transaction, so under READ COMMITTED it cannot see a row this
    # one has not committed -- and every chunk insert fails the foreign key on
    # ``application_document_chunks.document_id``, leaving a document with no
    # searchable content.
    #
    # Committing here is consistent with the DB-first intent above: the row is
    # meant to outlive a failure, and the RAG branch below already records
    # failure by setting the status rather than by rolling the row back.
    await db.commit()

    # Image files (PNG, JPG, etc.) are consumed directly from disk by tools
    # like document_analysis and file_reader. They cannot be chunked/embedded
    # into a FAISS index — skip RAG processing and mark ready immediately.
    _IMAGE_MIME_PREFIXES = ("image/",)
    is_image = (file.content_type or "").startswith(_IMAGE_MIME_PREFIXES)

    # Process RAG indexing SYNCHRONOUSLY so documents are ready for
    # retrieval when the user sends the next message (no race condition).
    # CRITICAL: Only mark 'ready' after chunks are successfully stored.
    chunk_count = 0
    if is_image:
        # Images don't need text chunking — the file on disk is the source.
        await _chat_repo.update_document_status(
            db, doc_id, "ready", chunk_count=0, size_bytes=size_bytes,
        )
    elif rag_manager is not None:
        try:
            rag_result = await rag_manager.process_document(
                session_id=session_id,
                file_path=file_path,
                filename=original_filename,
                data=payload,
                application_id=application_id,
                document_id=doc_id,
                mime_type=file.content_type,
                user_id=user_id,
            )
            chunk_count = rag_result.get("chunk_count", 0)
            content_md = rag_result.get("content_md") or ""

            # The converted text is stored before anything is judged, so a
            # document that was read but could not be indexed stays readable
            # instead of being discarded. This is what makes 'ready' mean
            # "we can read this" rather than "we happened to have an
            # embedding model at the moment you uploaded it".
            if content_md:
                await _chat_repo.update_document_markdown(
                    db,
                    doc_id,
                    content_md=content_md,
                    char_count=rag_result.get("char_count"),
                    converted_by=rag_result.get("converted_by"),
                    ocr_skipped_reason=rag_result.get("ocr_skipped_reason"),
                )

            if not content_md:
                # Nothing readable came out. This is the real failure: an
                # empty, corrupt or password-protected file, or a scan with no
                # vision model available to transcribe it.
                reason = rag_result.get("error") or "No text could be read from this file."
                logger.error(
                    "Nothing could be extracted: doc=%s file=%s -- %s",
                    doc_id, original_filename, reason,
                )
                await _chat_repo.update_document_status(db, doc_id, "failed")
                return DocumentUploadResponse(
                    document_id=doc_id,
                    session_id=session_id,
                    filename=original_filename,
                    processing_status="failed",
                    mime_type=file.content_type,
                    size_bytes=size_bytes,
                    chunk_count=0,
                )

            if chunk_count == 0:
                # Readable but not searchable. Named explicitly, because the
                # cause is almost always a missing or misconfigured embedding
                # credential and that is actionable -- unlike the silent
                # "failed" this used to produce.
                logger.warning(
                    "Document read but not indexed: doc=%s file=%s (%d chars). "
                    "No embedding model resolved for user %s, so it can be read "
                    "whole but not searched.",
                    doc_id, original_filename, len(content_md), user_id or "<none>",
                )

            await _chat_repo.update_document_status(
                db, doc_id, "ready", chunk_count=chunk_count, size_bytes=size_bytes,
            )
        except Exception as exc:
            logger.exception(
                "RAG processing failed for doc=%s file=%s: %s",
                doc_id, original_filename, exc,
            )
            await _chat_repo.update_document_status(db, doc_id, "failed")
            return DocumentUploadResponse(
                document_id=doc_id,
                session_id=session_id,
                filename=original_filename,
                processing_status="failed",
                mime_type=file.content_type,
                size_bytes=size_bytes,
                chunk_count=0,
            )
    else:
        # No RAG manager — mark ready immediately (file saved, just not indexed)
        await _chat_repo.update_document_status(db, doc_id, "ready", size_bytes=size_bytes)

    return DocumentUploadResponse(
        document_id=doc_id,
        session_id=session_id,
        filename=original_filename,
        processing_status="ready",
        mime_type=file.content_type,
        size_bytes=size_bytes,
        chunk_count=chunk_count,
    )


async def _background_rag_process(
    doc_id: str,
    session_id: str,
    file_path: str,
    filename: str,
    rag_manager,
) -> None:
    """
    Background task: run RAG processing and update document status in DB.

    WHY: Runs as an asyncio background task so the upload HTTP response
    returns immediately. Opens its own DB session (cannot reuse the request
    session which is closed when the endpoint returns).

    Args:
        doc_id: Document UUID string to update in DB.
        session_id: Chat session UUID string.
        file_path: Absolute path to the file on disk.
        filename: Original filename for metadata.
        rag_manager: Initialized SessionRAGManager instance.
    """
    from echolib.database import get_db_session as _get_db

    try:
        result = await rag_manager.process_document(
            session_id=session_id,
            file_path=file_path,
            filename=filename,
        )
        chunk_count = result.get("chunk_count", 0)
        async with _get_db() as db:
            await _chat_repo.update_document_status(
                db, doc_id, "ready", chunk_count=chunk_count
            )
        logger.info(
            "Background RAG processing complete: doc=%s, chunks=%d",
            doc_id, chunk_count,
        )
    except Exception as exc:
        logger.exception(
            "Background RAG processing failed for doc=%s file=%s: %s",
            doc_id, filename, exc,
        )
        try:
            from echolib.database import get_db_session as _get_db2
            async with _get_db2() as db:
                await _chat_repo.update_document_status(db, doc_id, "failed")
        except Exception:
            logger.exception(
                "Failed to update document status to 'failed' for doc=%s", doc_id
            )


async def _ensure_upload_session(
    db: AsyncSession,
    application_id: str,
    session_id: Optional[str],
    user_id: str,
    user_role: str = "user",
):
    """
    Validate or create a chat session for document upload.

    Returns (session, session_id) tuple.  Raises HTTPException on
    invalid input.
    """
    if session_id is not None:
        try:
            uuid.UUID(session_id)
        except (ValueError, TypeError):
            raise HTTPException(
                400,
                f"Invalid session_id format: '{session_id}' is not a valid UUID.",
            )

    app = await _app_repo.get_accessible_application(db, application_id, user_id, user_role)
    if app is None:
        raise HTTPException(404, "Application not found")
    if not app.upload_enabled:
        raise HTTPException(400, "Document upload is not enabled for this application.")

    if session_id:
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application.")
    else:
        session = await _chat_repo.create_session(
            db, application_id, user_id,
            title="Document Upload Session",
        )
        session_id = str(session.chat_session_id)

    return app, session, session_id


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/chat/upload -- Single-file Upload
# (Backward-compatible: keeps form field name "file", same response shape + session_id)
# -------------------------------------------------------------------
@router.post(
    "/{application_id}/chat/upload",
    status_code=201,
)
async def upload_chat_document(
    application_id: str,
    file: List[UploadFile] = File(...),
    session_id: Optional[str] = Query(
        None, description="Optional chat session UUID to bind the document to."
    ),
    user_input: Optional[str] = Query(
        None, description="Optional user query for RAG processing (used during file_upload interrupt)."
    ),
    user: UserContext = Depends(require_user),
):
    """
    Upload one or more documents for RAG processing within an application.

    WHY changed from single to List[UploadFile]: aligns the /chat/upload endpoint
    with the withoutKV codebase pattern and allows multi-file upload from the
    same form field name "file", preserving backward compatibility.

    The application must have ``upload_enabled == True``. Each file is
    saved to disk, an ``ApplicationDocument`` record is created, and the
    document is chunked, embedded, and indexed into a session-scoped FAISS
    index for retrieval at query time.

    When the session is in a ``file_upload`` interrupt state (from a Start node
    with file upload config) AND exactly one file is sent, the document is
    ingested through the shared upload path and the workflow is automatically
    resumed with the document's own text.

    The response always includes ``session_id`` so the frontend can reuse it for
    subsequent uploads or chat messages. If ``session_id`` is omitted, a new
    session is auto-created.

    Individual file failures are recorded per-document
    (``processing_status == "failed"``) without aborting remaining files.
    """
    MAX_FILES_PER_UPLOAD = 20
    if len(file) > MAX_FILES_PER_UPLOAD:
        raise HTTPException(
            status_code=400,
            detail=f"Maximum {MAX_FILES_PER_UPLOAD} files per upload request.",
        )
    if not file:
        raise HTTPException(status_code=400, detail="No files provided.")

    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        app, session, session_id = await _ensure_upload_session(
            db, application_id, session_id, user_id, user.role,
        )

        # ------------------------------------------------------------------
        # Detect file_upload interrupt state
        # ------------------------------------------------------------------
        context_data = session.context_data or {}
        hitl_state = context_data.get("hitl_state")
        is_file_upload_interrupt = (
            session.conversation_state == "awaiting_clarification"
            and hitl_state
            and hitl_state.get("interrupt_type") == "file_upload"
        )

        # ------------------------------------------------------------------
        # HITL interrupt path: single-file upload into a file_upload
        # interrupt state is ingested normally, then resumes the workflow.
        # ------------------------------------------------------------------
        if is_file_upload_interrupt and len(file) == 1:
            single_file = file[0]

            await validate_upload(
                single_file,
                allowed_extensions=[".pdf", ".docx", ".txt", ".csv", ".md"],
                max_size_bytes=50 * 1024 * 1024,
            )

            # The same ingestion every other upload gets.
            #
            # This branch used to run ``TraditionalRAGService``: PyMuPDF page
            # extraction, a hardcoded ``gpt-4o-mini`` / ``text-embedding-ada-002``
            # pair, and platform Azure secrets that a bring-your-own-LLM
            # deployment does not set. It was a fourth document path with no
            # OCR, and it wrote nothing to ``application_document_chunks`` -- so
            # the file the workflow had just asked for was unfindable the moment
            # the interrupt resumed. Routing it through the one path means a
            # document uploaded into an interrupt is exactly as readable as one
            # uploaded into ordinary chat.
            from echolib.di import container as di_container

            try:
                rag_manager = di_container.resolve("rag.session_manager")
            except KeyError:
                rag_manager = None
                logger.warning(
                    "rag.session_manager not registered; the interrupt document "
                    "will be stored but not indexed"
                )

            upload = await _process_single_upload(
                db, application_id, session_id, single_file, rag_manager, user_id,
            )
            doc_id = upload.document_id
            original_filename = upload.filename
            chunk_count = upload.chunk_count
            processing_status = upload.processing_status

            await _record_upload_history_event(
                db,
                application_id=application_id,
                session_id=session_id,
                user_id=user_id,
                upload=upload,
            )

            # The evidence changed. Without this the cached ledger keeps
            # reporting "no documents" and the resumed workflow can ask for the
            # file the user just handed it.
            from apps.appmgr.context import invalidate_session

            invalidate_session(application_id, session_id)

            # What the resuming node receives is now the document itself rather
            # than an answer generated about it. A node that wanted a summary
            # can produce one from the text; a node that wanted the text could
            # never have recovered it from a summary.
            document_context = ""
            stored = await _chat_repo.get_document_markdown(db, doc_id)
            if stored and stored.get("content_md"):
                budget = _hitl_document_context_chars()
                body = stored["content_md"]
                document_context = (
                    body
                    if len(body) <= budget
                    else body[:budget] + "\n\n... [truncated; search the document for the rest]"
                )

            hitl_result = await _resume_workflow_and_finalize(
                db, session_id, app, hitl_state,
                action="upload_file",
                resume_payload={
                    "document_context": document_context,
                    "document_metadata": {
                        "filename": original_filename,
                        "size": upload.size_bytes or 0,
                        "chunk_count": chunk_count,
                        "document_id": doc_id,
                    },
                },
                user_id=user_id,
            )

            return FileUploadResumeResponse(
                document_id=doc_id,
                filename=original_filename,
                processing_status=processing_status,
                chunk_count=chunk_count,
                workflow_status=hitl_result.status,
                workflow_output=hitl_result.message if hitl_result.status == "completed" else None,
                conversation_state=hitl_result.conversation_state,
            )

        # ------------------------------------------------------------------
        # Normal upload path (1 or N files): session-scoped RAG index
        # ------------------------------------------------------------------
        from echolib.di import container as di_container

        try:
            rag_manager = di_container.resolve('rag.session_manager')
        except KeyError:
            rag_manager = None
            logger.warning(
                "rag.session_manager not registered; files will be saved but not indexed"
            )

        doc_responses: List[DocumentUploadResponse] = []
        total_chunks = 0

        for f in file:
            # Per-file isolation: one file failing must NOT abort remaining files
            try:
                await validate_upload(
                    f,
                    allowed_extensions=[
                        ".pdf", ".docx", ".xlsx", ".xls", ".csv",
                        ".txt", ".md", ".pptx", ".png", ".jpg",
                    ],
                    max_size_bytes=50 * 1024 * 1024,
                )
                resp = await _process_single_upload(
                    db, application_id, session_id, f, rag_manager, user_id,
                )
            except Exception as exc:
                logger.exception(
                    "Failed to process uploaded file '%s': %s",
                    f.filename, exc,
                )
                resp = DocumentUploadResponse(
                    document_id=str(uuid.uuid4()),
                    session_id=session_id,
                    filename=f.filename or "unknown",
                    processing_status="failed",
                    mime_type=f.content_type,
                    size_bytes=0,
                    chunk_count=0,
                )

            doc_responses.append(resp)
            total_chunks += resp.chunk_count

            await _record_upload_history_event(
                db,
                application_id=application_id,
                session_id=session_id,
                user_id=user_id,
                upload=resp,
            )

        # The session's evidence changed. Without this the cached ledger would
        # keep reporting "no documents" and the application could ask the user
        # for a file they just uploaded.
        from apps.appmgr.context import invalidate_session

        invalidate_session(application_id, session_id)

        return UploadResponse(
            session_id=session_id,
            documents=doc_responses,
            total_chunk_count=total_chunks,
        )


# -------------------------------------------------------------------
# POST /api/applications/{application_id}/chat/upload-batch -- Multi-file Upload
# -------------------------------------------------------------------
@router.post(
    "/{application_id}/chat/upload-batch",
    status_code=201,
    response_model=BatchDocumentUploadResponse,
)
async def upload_chat_documents_batch(
    application_id: str,
    files: List[UploadFile] = File(..., description="One or more files to upload and index."),
    session_id: Optional[str] = Query(
        None, description="Optional chat session UUID to bind the documents to."
    ),
    user: UserContext = Depends(require_user),
):
    """
    Upload multiple documents for RAG processing within an application.

    All files are saved, chunked, embedded, and indexed into the **same**
    session-scoped FAISS index so that subsequent chat queries retrieve
    context from every uploaded file.

    The response always includes ``session_id``.  Pass this value back
    to ``/chat`` or subsequent upload calls to keep all files in the
    same retrieval context.

    Individual file failures are recorded per-document (``processing_status
    == "failed"``) without aborting the remaining files.
    """
    user_id = resolve_user_id(user)

    if not files:
        raise HTTPException(400, "At least one file is required.")

    async with get_db_session() as db:
        _app, _session, session_id = await _ensure_upload_session(
            db, application_id, session_id, user_id, user.role,
        )

        from echolib.di import container as di_container

        try:
            rag_manager = di_container.resolve('rag.session_manager')
        except KeyError:
            rag_manager = None
            logger.warning("rag.session_manager not registered; files will be saved but not indexed")

        doc_responses: List[DocumentUploadResponse] = []
        total_chunk_count = 0

        for file in files:
            # Per-file isolation: one file failing must NOT abort remaining files
            try:
                await validate_upload(
                    file,
                    allowed_extensions=[
                        ".pdf", ".docx", ".xlsx", ".xls", ".csv",
                        ".txt", ".md", ".pptx", ".png", ".jpg",
                    ],
                    max_size_bytes=50 * 1024 * 1024,
                )
                resp = await _process_single_upload(
                    db, application_id, session_id, file, rag_manager, user_id,
                )
            except Exception as exc:
                logger.exception(
                    "Failed to process uploaded file '%s': %s",
                    file.filename, exc,
                )
                resp = DocumentUploadResponse(
                    document_id=str(uuid.uuid4()),
                    session_id=session_id,
                    filename=file.filename or "unknown",
                    processing_status="failed",
                    mime_type=file.content_type,
                    size_bytes=0,
                    chunk_count=0,
                )

            doc_responses.append(resp)
            total_chunk_count += resp.chunk_count

            await _record_upload_history_event(
                db,
                application_id=application_id,
                session_id=session_id,
                user_id=user_id,
                upload=resp,
            )

        # Same reason as the single-file path: the ledger must see the upload
        # on the very next message, not when its TTL happens to expire.
        from apps.appmgr.context import invalidate_session

        invalidate_session(application_id, session_id)

        return BatchDocumentUploadResponse(
            session_id=session_id,
            documents=doc_responses,
            total_chunk_count=total_chunk_count,
        )


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/chat/sessions/{session_id}/documents
# Returns all documents in a session with their current processing status.
# Frontend polls this until all documents reach status="ready".
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/chat/sessions/{session_id}/documents",
    response_model=None,
)
async def get_session_documents(
    application_id: str,
    session_id: str,
    user: UserContext = Depends(require_user),
):
    """
    Return all documents in a session with their current processing status.

    WHY: Background processing (Task 2.2) means files are no longer immediately
    ready on upload. The frontend polls this endpoint until all documents show
    status="ready". Provides a consistent view of per-file processing progress.

    Args:
        application_id: Application UUID string (path param).
        session_id: Chat session UUID string (path param).

    Returns:
        Dict with session_id, documents list, and all_ready bool.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        # Verify session ownership and application membership
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(404, "Chat session not found for this application.")

        docs = await _chat_repo.get_session_documents(db, session_id)

    return {
        "session_id": session_id,
        "documents": [
            {
                "document_id": str(doc.document_id),
                "original_filename": doc.original_filename,
                "processing_status": doc.processing_status,
                "chunk_count": doc.chunk_count,
                "size_bytes": doc.size_bytes,
                "mime_type": doc.mime_type,
            }
            for doc in docs
        ],
        "all_ready": all(d.processing_status == "ready" for d in docs),
    }


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/chat/sessions/{session_id}/generated-files
#     List generated files for a session
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/chat/sessions/{session_id}/generated-files",
    response_model=None,
)
async def list_generated_files(
    application_id: str,
    session_id: str,
    user: UserContext = Depends(require_user),
):
    """
    List all generated files (PPT, Excel, charts) for a chat session.

    WHY: The frontend downloads panel calls this endpoint to render a list
    of downloadable files produced by agent tools during the session.

    Args:
        application_id: Application UUID string (path param).
        session_id: Chat session UUID string (path param).

    Returns:
        Dict with session_id and list of file metadata dicts including
        download URLs.
    """
    user_id = resolve_user_id(user)

    async with get_db_session() as db:
        session = await _chat_repo.get_session(db, session_id, user_id, application_id)
        if session is None:
            raise HTTPException(status_code=404, detail="Chat session not found.")

        files = await _gen_file_repo.list_by_session(db, session_id)

    now = datetime.now(timezone.utc)
    available_files = []
    for file_record in files:
        if file_record.expires_at and file_record.expires_at < now:
            continue
        is_valid_path, _reason, _normalized_path, _size_bytes = validate_generated_file_path(
            file_record.file_path,
            require_exists=True,
            require_non_empty=False,
        )
        if not is_valid_path:
            continue
        available_files.append(file_record)

    base_url = f"/api/applications/{application_id}/generated-files"
    return {
        "session_id": session_id,
        "files": [
            {
                "generated_file_id": str(f.generated_file_id),
                "original_filename": f.original_filename,
                "mime_type": f.mime_type,
                "size_bytes": f.size_bytes,
                "download_url": f"{base_url}/{f.download_key}",
                "expires_at": f.expires_at.isoformat() if f.expires_at else None,
                "created_at": f.created_at.isoformat() if f.created_at else None,
            }
            for f in available_files
        ],
    }


# -------------------------------------------------------------------
# GET /api/applications/{application_id}/generated-files/{download_key}
#     Download a generated file by its URL-safe key
# -------------------------------------------------------------------
@router.get(
    "/{application_id}/generated-files/{download_key}",
)
async def download_generated_file(
    application_id: str,
    download_key: str,
    user: UserContext = Depends(require_user),
):
    """
    Stream a generated file (PPT, Excel, chart) to the client.

    WHY: Agent tools write files to disk and embed a [GENERATED_FILE:...]
    marker in their output. skill_executor registers each file in the DB
    with a URL-safe download_key. The frontend constructs the download URL
    from the key and calls this endpoint to trigger the file download.

    Security: Caller must be authenticated and have access to the target
    application. The download_key is then resolved within that access scope.

    Args:
        application_id: Application UUID string (path param, for validation).
        download_key: 32-char hex token from the GeneratedFile record.

    Returns:
        FileResponse with Content-Disposition: attachment.

    Raises:
        404: If the key is not found, expired, or deleted.
        410: If the file no longer exists on disk.
    """
    user_id = resolve_user_id(user)

    logger.info(
        "generated_file_download_attempt",
        extra={
            "application_id": application_id,
            "download_key": download_key,
            "user_id": user_id,
        },
    )

    owner_app_id: Optional[str] = None
    async with get_db_session() as db:
        app = await _app_repo.get_accessible_application(
            db,
            application_id,
            user_id,
            user.role,
        )
        if app is None:
            logger.warning(
                "generated_file_download_denied_application_access",
                extra={
                    "application_id": application_id,
                    "download_key": download_key,
                    "user_id": user_id,
                },
            )
            raise HTTPException(status_code=404, detail="Generated file not found.")

        record = await _gen_file_repo.get_by_download_key(db, download_key)

        if record and record.application_id is None and record.chat_session_id is not None:
            session_owner = await _chat_repo.get_session(
                db,
                str(record.chat_session_id),
                user_id,
            )
            owner_app_id = (
                str(session_owner.application_id)
                if session_owner and getattr(session_owner, "application_id", None)
                else None
            )

    if record is None:
        logger.warning(
            "generated_file_download_missing_record",
            extra={
                "application_id": application_id,
                "download_key": download_key,
                "user_id": user_id,
            },
        )
        raise HTTPException(status_code=404, detail="Generated file not found.")

    record_app_id = str(record.application_id) if record.application_id else None
    if record_app_id != application_id:
        # Backward-compatible ownership resolution for legacy rows where
        # application_id is NULL but chat_session_id is set correctly.
        if record.application_id is None and record.chat_session_id is not None:
            if owner_app_id == application_id:
                logger.info(
                    "generated_file_download_owner_resolved_via_session",
                    extra={
                        "application_id": application_id,
                        "download_key": download_key,
                        "chat_session_id": str(record.chat_session_id),
                        "user_id": user_id,
                    },
                )
            else:
                logger.warning(
                    "generated_file_download_application_mismatch",
                    extra={
                        "application_id": application_id,
                        "download_key": download_key,
                        "record_application_id": record_app_id,
                        "record_chat_session_id": str(record.chat_session_id),
                        "resolved_session_application_id": owner_app_id,
                        "user_id": user_id,
                    },
                )
                raise HTTPException(status_code=404, detail="Generated file not found.")
        else:
            logger.warning(
                "generated_file_download_application_mismatch",
                extra={
                    "application_id": application_id,
                    "download_key": download_key,
                    "record_application_id": record_app_id,
                    "user_id": user_id,
                },
            )
            raise HTTPException(status_code=404, detail="Generated file not found.")

    if record.expires_at and record.expires_at < datetime.now(timezone.utc):
        logger.info(
            "generated_file_download_expired",
            extra={
                "application_id": application_id,
                "download_key": download_key,
                "user_id": user_id,
            },
        )
        raise HTTPException(
            status_code=410,
            detail="This file has expired and is no longer available.",
        )

    logger.info(
        f"DOWNLOAD_HOST={socket.gethostname()}"
    )

    logger.info(
        f"DOWNLOAD_DB_PATH={record.file_path}"
    )

    logger.info(
        f"DOWNLOAD_DB_PATH_EXISTS={os.path.exists(record.file_path)}"
    )

    is_valid_path, path_reason, normalized_path, _size_bytes = validate_generated_file_path(
        record.file_path,
        require_exists=True,
        require_non_empty=False,
    )
    if not is_valid_path:
        logger.error(
            f"VALIDATION_REASON={path_reason}"
        )

        logger.error(
            f"NORMALIZED_PATH={normalized_path}"
        )

        logger.error(
            f"NORMALIZED_PATH_EXISTS={os.path.exists(normalized_path) if normalized_path else False}"
        )
        logger.warning(
            "generated_file_download_missing_disk_file",
            extra={
                "application_id": application_id,
                "download_key": download_key,
                "file_path": record.file_path,
                "resolved_file_path": normalized_path,
                "validation_reason": path_reason,
                "file_path_is_absolute": os.path.isabs(record.file_path),
                "cwd": os.getcwd(),
                "app_uploads_dir": os.getenv("APP_UPLOADS_DIR"),
                "record_expires_at": record.expires_at.isoformat() if record.expires_at else None,
                "user_id": user_id,
            },
        )
        raise HTTPException(
            status_code=410,
            detail="The generated file is no longer available on disk.",
        )

    logger.info(
        "generated_file_download_success",
        extra={
            "application_id": application_id,
            "download_key": download_key,
            "file_path": record.file_path,
            "user_id": user_id,
        },
    )

    media_type = record.mime_type or "application/octet-stream"
    return FileResponse(
        path=normalized_path,
        media_type=media_type,
        filename=record.original_filename,
    )


# ===================================================================
# Lookup / Catalog Router
# ===================================================================

lookup_router = APIRouter(tags=["Application Lookups"])


@lookup_router.get("/api/llms", response_model=List[LookupResponse])
async def list_llms(user: UserContext = Depends(require_user)):
    """List all available LLMs for the application wizard."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppLlm).order_by(AppLlm.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=str(row.llm_id), name=row.name)
            for row in rows
        ]


@lookup_router.get("/api/data-sources", response_model=List[LookupResponse])
async def list_data_sources(user: UserContext = Depends(require_user)):
    """List all available data sources."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppDataSource).order_by(AppDataSource.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=row.data_source_id, name=row.name)
            for row in rows
        ]


@lookup_router.get("/api/designations", response_model=List[LookupResponse])
async def list_designations(user: UserContext = Depends(require_user)):
    """List all available designations."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppDesignation).order_by(AppDesignation.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=str(row.designation_id), name=row.name)
            for row in rows
        ]


@lookup_router.get("/api/business-units", response_model=List[LookupResponse])
async def list_business_units(user: UserContext = Depends(require_user)):
    """List all available business units."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppBusinessUnit).order_by(AppBusinessUnit.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=str(row.business_unit_id), name=row.name)
            for row in rows
        ]


@lookup_router.get("/api/tags", response_model=List[LookupResponse])
async def list_tags(user: UserContext = Depends(require_user)):
    """List all available tags."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppTag).order_by(AppTag.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=str(row.tag_id), name=row.name)
            for row in rows
        ]


@lookup_router.get("/api/personas", response_model=List[LookupResponse])
async def list_personas(user: UserContext = Depends(require_user)):
    """List all available personas."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppPersona).order_by(AppPersona.name.asc())
        )
        rows = result.scalars().all()
        return [
            LookupResponse(id=str(row.persona_id), name=row.name)
            for row in rows
        ]


@lookup_router.get(
    "/api/guardrail-categories", response_model=List[LookupResponse]
)
async def list_guardrail_categories(user: UserContext = Depends(require_user)):
    """List all available guardrail categories."""
    async with get_db_session() as db:
        result = await db.execute(
            select(AppGuardrailCategory).order_by(
                AppGuardrailCategory.name.asc()
            )
        )
        rows = result.scalars().all()
        return [
            LookupResponse(
                id=str(row.guardrail_category_id), name=row.name
            )
            for row in rows
        ]


# -------------------------------------------------------------------
# POST /api/llms/seed -- Seed default LLMs if table is empty
# -------------------------------------------------------------------
@lookup_router.post("/api/llms/seed", response_model=List[LookupResponse])
async def seed_llms(user: UserContext = Depends(require_user)):
    """Seed the app_llms table with default LLMs if empty."""
    async with get_db_session() as db:
        existing = await db.execute(select(func.count()).select_from(AppLlm))
        count = existing.scalar() or 0
        if count > 0:
            result = await db.execute(select(AppLlm).order_by(AppLlm.name.asc()))
            rows = result.scalars().all()
            return [LookupResponse(id=str(row.llm_id), name=row.name) for row in rows]

        defaults = [
            AppLlm(name="GPT-4o", provider="openai", model_name="gpt-4o", base_url="https://api.openai.com/v1", api_key_env="OPENAI_API_KEY", is_default=False),
            AppLlm(name="GPT-4o Mini", provider="openai", model_name="gpt-4o-mini", base_url="https://api.openai.com/v1", api_key_env="OPENAI_API_KEY", is_default=False),
            AppLlm(name="Claude Sonnet", provider="anthropic", model_name="claude-sonnet-4-20250514", base_url="https://api.anthropic.com", api_key_env="ANTHROPIC_API_KEY", is_default=False),
            AppLlm(name="Azure GPT-4o Mini", provider="azure", model_name="gpt-4o-mini", base_url="", api_key_env="AZURE_OPENAI_API_KEY", is_default=True),
            AppLlm(name="Ollama Local", provider="ollama", model_name="llama3", base_url="http://localhost:11434/v1", api_key_env=None, is_default=False),
        ]
        db.add_all(defaults)
        await db.flush()

        result = await db.execute(select(AppLlm).order_by(AppLlm.name.asc()))
        rows = result.scalars().all()
        return [LookupResponse(id=str(row.llm_id), name=row.name) for row in rows]


# -------------------------------------------------------------------
# POST /api/data-sources/seed -- Seed default data sources if empty
# -------------------------------------------------------------------
@lookup_router.post("/api/data-sources/seed", response_model=List[LookupResponse])
async def seed_data_sources(user: UserContext = Depends(require_user)):
    """Seed the app_data_sources table with defaults if empty."""
    async with get_db_session() as db:
        existing = await db.execute(select(func.count()).select_from(AppDataSource))
        count = existing.scalar() or 0
        if count > 0:
            result = await db.execute(select(AppDataSource).order_by(AppDataSource.name.asc()))
            rows = result.scalars().all()
            return [LookupResponse(id=row.data_source_id, name=row.name) for row in rows]

        defaults = [
            AppDataSource(data_source_id="mcp_filesystem", name="Local Filesystem", kind="mcp", source_metadata={"description": "Access local files"}),
            AppDataSource(data_source_id="mcp_web_search", name="Web Search", kind="mcp", source_metadata={"description": "Search the web"}),
            AppDataSource(data_source_id="api_rest", name="REST API", kind="api", source_metadata={"description": "Connect to REST APIs"}),
        ]
        db.add_all(defaults)
        await db.flush()

        result = await db.execute(select(AppDataSource).order_by(AppDataSource.name.asc()))
        rows = result.scalars().all()
        return [LookupResponse(id=row.data_source_id, name=row.name) for row in rows]


# ===================================================================
# Skills Router
# ===================================================================

skills_router = APIRouter(tags=["Application Skills"])


@skills_router.get("/api/skills", response_model=List[SkillResponse])
async def list_skills(
    user: UserContext = Depends(require_user),
):
    """
    List all workflows and agents for the current user.

    Queries both the ``workflows`` and ``agents`` PostgreSQL tables
    and returns a unified list labeled by skill_type.

    Falls back to include DEFAULT_USER_ID data when the authenticated
    user has no data (dev/test convenience).
    """
    user_id = resolve_user_id(user)

    # Include DEFAULT_USER_ID as fallback so dev/test users always
    # see shared data even if their JWT creates a new user identity.
    user_ids = [
        func.cast(user_id, Workflow.user_id.type),
        func.cast(DEFAULT_USER_ID, Workflow.user_id.type),
    ]

    async with get_db_session() as db:
        skills: List[SkillResponse] = []

        # ---- Workflows ----
        wf_stmt = (
            select(Workflow)
            .where(
                or_(*(Workflow.user_id == uid for uid in user_ids)),
                Workflow.status != "archived",
                Workflow.is_deleted == False,  # noqa: E712
            )
            .order_by(Workflow.name.asc())
        )
        wf_result = await db.execute(wf_stmt)
        seen_wf_names = set()
        for wf in wf_result.scalars().all():
            # Deduplicate by name (prefer user's own copy over default)
            if wf.name in seen_wf_names:
                continue
            seen_wf_names.add(wf.name)
            description = None
            if wf.definition and isinstance(wf.definition, dict):
                description = wf.definition.get("description")
            skills.append(
                SkillResponse(
                    skill_id=str(wf.workflow_id),
                    skill_type="workflow",
                    name=wf.name,
                    description=description,
                )
            )

        # ---- Agents ----
        agt_stmt = (
            select(Agent)
            .where(
                or_(*(Agent.user_id == uid for uid in user_ids)),
                Agent.is_deleted == False,  # noqa: E712
            )
            .order_by(Agent.name.asc())
        )
        agt_result = await db.execute(agt_stmt)
        seen_agt_names = set()
        for agt in agt_result.scalars().all():
            # Deduplicate by name
            if agt.name in seen_agt_names:
                continue
            seen_agt_names.add(agt.name)
            name = agt.name
            description = None
            if agt.definition and isinstance(agt.definition, dict):
                name = agt.definition.get("name") or agt.name
                # description is authoritative; role is a legacy fallback only.
                description = agt.definition.get("description") or agt.definition.get("role")
            skills.append(
                SkillResponse(
                    skill_id=str(agt.agent_id),
                    skill_type="agent",
                    name=name,
                    description=description,
                )
            )

        return skills



# """
# EchoAI Application Orchestrator -- API Routes (Phases 2 + 4)

# Async CRUD and Chat endpoints backed by PostgreSQL via SQLAlchemy 2.0 + asyncpg.
# Replaces the previous SQLite/SQLModel sync implementation.

# Route groups:
#     /api/applications/...            -- Application CRUD, publish, logo
#     /api/applications/{id}/chat/...  -- Chat (pipeline, history, upload)
#     /api/llms, /api/data-sources,
#     /api/designations, etc.          -- Lookup / catalog endpoints
#     /api/skills                      -- Aggregated workflows + agents

# Authentication:
#     Uses ``get_current_user`` from ``echolib.security`` (optional/required
#     mode is controlled by the ``AUTH_ENFORCEMENT`` setting).
#     Falls back to ``DEFAULT_USER_ID`` for anonymous callers.

# Database:
#     Uses ``get_db_session()`` async context manager from ``echolib.database``.
#     All mutations flush inside the session; the context manager commits or
#     rolls back automatically.
# """
# import socket
# import asyncio
# import logging
# import os
# import uuid
# from datetime import datetime, timezone
# from pathlib import Path
# from typing import Any, Dict, List, Optional, Union

# from fastapi import (
#     APIRouter,
#     Depends,
#     File,
#     HTTPException,
#     Query,
#     Response,
#     UploadFile,
# )
# from fastapi.responses import FileResponse
# from numpy import record
# from starlette.responses import StreamingResponse
# from sqlalchemy import func, or_, select
# from sqlalchemy.ext.asyncio import AsyncSession

# from echolib.database import get_db_session
# from echolib.models import (
#     AppBusinessUnit,
#     AppDataSource,
#     AppDesignation,
#     AppGuardrailCategory,
#     AppLlm,
#     AppPersona,
#     AppTag,
#     Application,
# )
# from echolib.models.user import User
# from echolib.models.user_links import UserDesignationLink, UserBusinessUnitLink
# from echolib.models.workflow import Workflow
# from echolib.models.agent import Agent
# from echolib.repositories.application_repo import ApplicationRepository
# from echolib.repositories.base import DEFAULT_USER_ID
# from echolib.security import get_current_user, require_user, require_admin_or_above, require_super_admin, resolve_user_id
# from echolib.types import UserContext, UserRole

# from echolib.repositories.application_chat_repo import ApplicationChatRepository
# from echolib.repositories.generated_file_repo import GeneratedFileRepository
# from echolib.generated_files import validate_generated_file_path
# from echolib.repositories.approval_audit_repo import ApprovalAuditRepository
# from echolib.repositories.notification_repo import NotificationRepository
# from echolib.service.pdf_export import generate_chat_pdf
# from echolib.upload_validation import validate_upload

# from .schemas import (
#     ApplicationAccessUpdate,
#     ApplicationCard,
#     ApplicationChatConfigUpdate,
#     ApplicationContextUpdate,
#     ApplicationCreate,
#     ApplicationDetail,
#     ApplicationFullUpdate,
#     ApplicationListResponse,
#     ApplicationSetupUpdate,
#     ApplicationStats,
#     ApprovalQueueItem,
#     AuditLogEntry,
#     ChatMessageRequest,
#     ChatMessageResponse,
#     ChatResponse,
#     ChatSessionMetadata,
#     ChatSessionResponse,
#     BatchDocumentUploadResponse,
#     DocumentUploadResponse,
#     FileUploadResumeResponse,
#     HITLDecisionRequest,
#     HITLDecisionResponse,
#     LlmLinkResponse,
#     LookupResponse,
#     RejectPayload,
#     SkillLinkResponse,
#     SkillResponse,
#     TitleUpdateRequest,
#     UploadResponse,
# )


# logger = logging.getLogger(__name__)


# def _sse_setting(name: str, default: float) -> float:
#     """Read an SSE timing value from ``echolib.config``, degrading to *default*."""
#     try:
#         from echolib.config import settings

#         return float(getattr(settings, name, default))
#     except Exception:  # noqa: BLE001 -- transport timing must never fail a request
#         return default


# # How often a silent stream emits a keep-alive comment frame.
# #
# # Well under Azure's fixed 230s TCP idle timeout, and under the tighter windows
# # reverse proxies and CDNs commonly apply -- guidance is to heartbeat at well
# # below half the shortest timeout in the chain, and a real data frame resets the
# # clock anyway, so this only ever fires when nothing else is flowing.
# _SSE_HEARTBEAT_SECONDS = _sse_setting("sse_heartbeat_seconds", 15.0)

# # How often a quiet-but-working stream records that it is still alive.
# #
# # There is deliberately NO fixed idle timeout any more. The previous
# # ``_SSE_IDLE_TIMEOUT_SECONDS = 180`` closed healthy streams: how long a run
# # stays quiet depends on agent count, rate-limit pacing, model and quota, so any
# # constant is wrong for somebody. The generator now asks whether the pipeline
# # task is alive, which is a fact rather than a guess.
# _SSE_QUIET_LOG_SECONDS = _sse_setting("sse_quiet_log_seconds", 60.0)

# # ---------------------------------------------------------------------------
# # Directories for file uploads
# # ---------------------------------------------------------------------------
# LOGOS_DIR = os.getenv("APP_LOGOS_DIR", os.path.join("static", "logos"))
# Path(LOGOS_DIR).mkdir(parents=True, exist_ok=True)

# # ---------------------------------------------------------------------------
# # Directories for file uploads -- chat documents
# # ---------------------------------------------------------------------------
# UPLOADS_DIR = os.getenv("APP_UPLOADS_DIR", os.path.join("apps", "appmgr", "uploads"))
# Path(UPLOADS_DIR).mkdir(parents=True, exist_ok=True)

# # ---------------------------------------------------------------------------
# # Repository singletons (stateless, safe to reuse)
# # ---------------------------------------------------------------------------
# _app_repo = ApplicationRepository()
# _chat_repo = ApplicationChatRepository()
# _gen_file_repo = GeneratedFileRepository()
# _audit_repo = ApprovalAuditRepository()
# _notif_repo = NotificationRepository()


# # _resolve_user_id() has been removed. Use resolve_user_id() from echolib.security
# # which validates UUIDs and falls back to DEFAULT_USER_ID for anonymous users.


# # ---------------------------------------------------------------------------
# # Serialisation helpers
# # ---------------------------------------------------------------------------

# def _app_to_card(app: Application) -> ApplicationCard:
#     """Convert an Application ORM instance to an ApplicationCard schema."""
#     return ApplicationCard(
#         application_id=str(app.application_id),
#         name=app.name,
#         status=app.status,
#         description=app.description,
#         logo_url=app.logo_url,
#         llm_count=len(app.llm_links) if app.llm_links else 0,
#         data_source_count=len(app.data_source_links) if app.data_source_links else 0,
#         skill_count=len(app.skill_links) if app.skill_links else 0,
#         error_message=app.error_message,
#         approval_status=app.approval_status,
#         approved_by=str(app.approved_by) if app.approved_by else None,
#         rejection_reason=app.rejection_reason,
#         created_at=app.created_at,
#         updated_at=app.updated_at,
#     )


# async def _build_app_detail(db: AsyncSession, app: Application) -> ApplicationDetail:
#     """Convert an Application ORM instance to an ApplicationDetail schema.

#     Resolves LLM names via the eager-loaded relationship and resolves
#     designation, business unit, and tag names from their lookup tables.
#     """
#     from echolib.repositories.base import safe_uuid

#     # Resolve designation names
#     designation_names: List[str] = []
#     designation_ids_list = [
#         str(link.designation_id) for link in (app.designation_links or [])
#     ]
#     if designation_ids_list:
#         _d_uuids = [safe_uuid(did) for did in designation_ids_list]
#         _d_uuids = [u for u in _d_uuids if u is not None]
#         if _d_uuids:
#             _d_result = await db.execute(
#                 select(AppDesignation).where(AppDesignation.designation_id.in_(_d_uuids))
#             )
#             designation_names = [d.name for d in _d_result.scalars().all()]

#     # Resolve business unit names
#     business_unit_names: List[str] = []
#     business_unit_ids_list = [
#         str(link.business_unit_id) for link in (app.business_unit_links or [])
#     ]
#     if business_unit_ids_list:
#         _bu_uuids = [safe_uuid(buid) for buid in business_unit_ids_list]
#         _bu_uuids = [u for u in _bu_uuids if u is not None]
#         if _bu_uuids:
#             _bu_result = await db.execute(
#                 select(AppBusinessUnit).where(AppBusinessUnit.business_unit_id.in_(_bu_uuids))
#             )
#             business_unit_names = [bu.name for bu in _bu_result.scalars().all()]

#     # Resolve tag names
#     tag_names: List[str] = []
#     tag_ids_list = [str(link.tag_id) for link in (app.tag_links or [])]
#     if tag_ids_list:
#         _t_uuids = [safe_uuid(tid) for tid in tag_ids_list]
#         _t_uuids = [u for u in _t_uuids if u is not None]
#         if _t_uuids:
#             _t_result = await db.execute(
#                 select(AppTag).where(AppTag.tag_id.in_(_t_uuids))
#             )
#             tag_names = [t.name for t in _t_result.scalars().all()]

#     return ApplicationDetail(
#         application_id=str(app.application_id),
#         user_id=str(app.user_id),
#         name=app.name,
#         description=app.description,
#         status=app.status,
#         error_message=app.error_message,
#         available_for_all_users=app.available_for_all_users,
#         upload_enabled=app.upload_enabled,
#         welcome_prompt=app.welcome_prompt,
#         disclaimer=app.disclaimer,
#         sorry_message=app.sorry_message,
#         starter_questions=app.starter_questions or [],
#         persona_id=str(app.persona_id) if app.persona_id else None,
#         persona_text=app.persona_text,
#         guardrail_text=app.guardrail_text,
#         logo_url=app.logo_url,
#         created_at=app.created_at,
#         updated_at=app.updated_at,
#         llm_links=[
#             LlmLinkResponse(
#                 llm_id=link.llm_id,
#                 role=link.role,
#                 name=link.name,
#             )
#             for link in (app.llm_links or [])
#         ],
#         skill_links=[
#             SkillLinkResponse(
#                 skill_id=link.skill_id,
#                 skill_type=link.skill_type,
#                 skill_name=link.skill_name,
#                 skill_description=link.skill_description,
#             )
#             for link in (app.skill_links or [])
#         ],
#         data_source_ids=[
#             link.data_source_id for link in (app.data_source_links or [])
#         ],
#         designation_ids=designation_ids_list,
#         business_unit_ids=business_unit_ids_list,
#         tag_ids=tag_ids_list,
#         guardrail_category_ids=[
#             str(link.guardrail_category_id)
#             for link in (app.guardrail_links or [])
#         ],
#         designation_names=designation_names,
#         business_unit_names=business_unit_names,
#         tag_names=tag_names,
#         approval_status=app.approval_status,
#         approved_by=str(app.approved_by) if app.approved_by else None,
#         rejection_reason=app.rejection_reason,
#     )


# # ===================================================================
# # Application CRUD Router
# # ===================================================================

# router = APIRouter(prefix="/api/applications", tags=["Applications"])


# # -------------------------------------------------------------------
# # POST /api/applications -- Create
# # -------------------------------------------------------------------
# @router.post("", response_model=ApplicationDetail, status_code=201)
# async def create_application(
#     payload: ApplicationCreate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Create a new application in DRAFT status. Only ``name`` is required.

#     An application created by a super_admin is approved on the spot -- see the
#     ``self_approved`` branch below. Every other creator's application starts
#     ``pending`` and the matching super_admins are notified.
#     """
#     from echolib.repositories.base import safe_uuid

#     user_id = resolve_user_id(user)

#     # Build optional kwargs from payload
#     kwargs = {}
#     if payload.description is not None:
#         kwargs["description"] = payload.description
#     if payload.logo_url is not None:
#         kwargs["logo_url"] = payload.logo_url
#     if payload.welcome_prompt is not None:
#         kwargs["welcome_prompt"] = payload.welcome_prompt
#     if payload.disclaimer is not None:
#         kwargs["disclaimer"] = payload.disclaimer
#     if payload.sorry_message is not None:
#         kwargs["sorry_message"] = payload.sorry_message
#     if payload.starter_questions is not None:
#         kwargs["starter_questions"] = payload.starter_questions
#     if payload.persona_id is not None:
#         kwargs["persona_id"] = payload.persona_id
#     if payload.persona_text is not None:
#         kwargs["persona_text"] = payload.persona_text
#     if payload.guardrail_text is not None:
#         kwargs["guardrail_text"] = payload.guardrail_text
#     if payload.available_for_all_users is not None:
#         kwargs["available_for_all_users"] = payload.available_for_all_users
#     if payload.upload_enabled is not None:
#         kwargs["upload_enabled"] = payload.upload_enabled

#     # A super_admin IS the approving authority. Requiring one to be approved
#     # by a super_admin is circular, and it left their own apps unpublishable.
#     # Record the approval against the creator so the audit trail still names
#     # who approved it, and keep the app out of everyone's approval queue.
#     self_approved = user.role == UserRole.super_admin.value
#     if self_approved:
#         kwargs["approval_status"] = "approved"
#         kwargs["approved_by"] = safe_uuid(user_id)

#     async with get_db_session() as db:
#         app = await _app_repo.create_application(
#             db, user_id=user_id, name=payload.name.strip(), **kwargs
#         )

#         app_id_str = str(app.application_id)

#         # Sync link tables if provided at creation time
#         if payload.llm_links is not None:
#             await _app_repo.sync_llm_links(db, app_id_str, payload.llm_links)
#         if payload.skill_links is not None:
#             await _app_repo.sync_skill_links(db, app_id_str, payload.skill_links)
#         if payload.data_source_ids is not None:
#             await _app_repo.sync_data_source_links(db, app_id_str, payload.data_source_ids)
#             from apps.appmgr.context import invalidate_application

#             invalidate_application(app_id_str)
#         if payload.designation_ids is not None:
#             await _app_repo.sync_designation_links(db, app_id_str, payload.designation_ids)
#         if payload.business_unit_ids is not None:
#             await _app_repo.sync_business_unit_links(db, app_id_str, payload.business_unit_ids)
#         if payload.tag_ids is not None:
#             await _app_repo.sync_tag_links(db, app_id_str, payload.tag_ids)
#         if payload.guardrail_category_ids is not None:
#             await _app_repo.sync_guardrail_links(db, app_id_str, payload.guardrail_category_ids)

#         # Expire cached objects so relationships reload from DB
#         db.expire_all()

#         # Rebuild config JSONB from fresh link data (dual-write)
#         await _app_repo.sync_config_jsonb(
#             db, app_id_str, user_id, user.role
#         )
#         app = await _app_repo.get_application(
#             db, app_id_str, user_id
#         )

#         # Audit log: app submitted for approval
#         await _audit_repo.log_action(
#             db,
#             application_id=app_id_str,
#             action="submitted",
#             performed_by=user_id,
#         )

#         if self_approved:
#             # The creator is the approving authority, so the approval is
#             # recorded rather than requested. No notification: there is
#             # nothing for a super_admin to act on.
#             await _audit_repo.log_action(
#                 db,
#                 application_id=app_id_str,
#                 action="approved",
#                 performed_by=user_id,
#                 comment="Auto-approved: created by a Super Admin.",
#             )
#             logger.info(
#                 "Application %s auto-approved on creation by super_admin %s",
#                 app_id_str,
#                 user_id,
#             )
#         else:
#             # Notify super_admins with matching BU/designation
#             await _notify_super_admins_for_app(
#                 db, app,
#                 notif_type="approval_pending",
#                 title=f"New application '{app.name}' pending approval",
#                 message=f"A new application '{app.name}' has been submitted for approval.",
#             )

#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # GET /api/applications -- List (paginated, with stats)
# # -------------------------------------------------------------------
# @router.get("", response_model=ApplicationListResponse)
# async def list_applications(
#     status: Optional[str] = Query(None, description="Filter: draft|published|error"),
#     q: Optional[str] = Query(None, description="Search by name (ILIKE)"),
#     sort: Optional[str] = Query(None, description="Sort mode: recently_updated"),
#     page: int = Query(1, ge=1),
#     pageSize: int = Query(20, ge=1, le=100),
#     user: UserContext = Depends(require_user),
# ):
#     """List applications as paginated cards with dashboard stats."""
#     user_id = resolve_user_id(user)

#     if status and status not in {"draft", "published", "error"}:
#         raise HTTPException(400, "Invalid status filter. Use: draft, published, error")

#     async with get_db_session() as db:
#         items, total = await _app_repo.list_applications(
#             db,
#             user_id=user_id,
#             status=status,
#             q=q,
#             sort=sort,
#             page=page,
#             page_size=pageSize,
#         )
#         stats_dict = await _app_repo.get_application_stats(db, user_id=user_id)

#         return ApplicationListResponse(
#             page=page,
#             page_size=pageSize,
#             total=total,
#             stats=ApplicationStats(**stats_dict),
#             items=[_app_to_card(app) for app in items],
#         )


# # -------------------------------------------------------------------
# # GET /api/applications/visible -- Published apps visible to current user
# # -------------------------------------------------------------------
# @router.get("/visible", response_model=ApplicationListResponse)
# async def list_visible_applications(
#     q: Optional[str] = Query(None, description="Search by name (ILIKE)"),
#     page: int = Query(1, ge=1),
#     pageSize: int = Query(20, ge=1, le=100),
#     user: UserContext = Depends(require_user),
# ):
#     """
#     List published applications visible to the current user.

#     - super_admin/admin: see all published apps.
#     - user: see apps matching their designation AND business_unit,
#       plus apps marked available_for_all_users.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         items, total = await _app_repo.list_visible_applications(
#             db,
#             user_id=user_id,
#             user_role=user.role,
#             q=q,
#             page=page,
#             page_size=pageSize,
#         )
#         return ApplicationListResponse(
#             page=page,
#             page_size=pageSize,
#             total=total,
#             stats=ApplicationStats(total=total, draft=0, published=total, error=0),
#             items=[_app_to_card(app) for app in items],
#         )


# # -------------------------------------------------------------------
# # GET /api/applications/approval-queue
# # (MUST be above /{application_id} to avoid wildcard capture)
# # -------------------------------------------------------------------
# @router.get("/approval-queue", response_model=List[ApprovalQueueItem])
# async def get_approval_queue(
#     user: UserContext = Depends(require_super_admin),
# ):
#     """List applications pending approval (ABAC-filtered for super_admin)."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         apps = await _app_repo.list_pending_approvals(db, user_id, user.role)
#         return [
#             ApprovalQueueItem(
#                 application_id=str(app.application_id),
#                 app_type="classic",
#                 name=app.name,
#                 description=app.description,
#                 status=app.status,
#                 approval_status=app.approval_status,
#                 approved_by=str(app.approved_by) if app.approved_by else None,
#                 rejection_reason=app.rejection_reason,
#                 logo_url=app.logo_url,
#                 llm_count=len(app.llm_links) if app.llm_links else 0,
#                 skill_count=len(app.skill_links) if app.skill_links else 0,
#                 data_source_count=len(app.data_source_links) if app.data_source_links else 0,
#                 user_id=str(app.user_id),
#                 created_at=app.created_at,
#                 updated_at=app.updated_at,
#             )
#             for app in apps
#         ]


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id} -- Detail
# # -------------------------------------------------------------------
# @router.get("/{application_id}", response_model=ApplicationDetail)
# async def get_application(
#     application_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """Get a single application with all relationships.

#     A super_admin may read any application. Approving one without being able
#     to see what it was configured with is not a review, and the approval queue
#     carries counts only. This widens **read** access alone -- update, delete
#     and publish stay owner-scoped through ``get_accessible_application``.
#     """
#     user_id = resolve_user_id(user)
#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None and user.role == UserRole.super_admin.value:
#             app = await _app_repo.get_application_by_id(db, application_id)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # PUT /api/applications/{application_id} -- Full Update
# # -------------------------------------------------------------------
# @router.put("/{application_id}", response_model=ApplicationDetail)
# async def update_application(
#     application_id: str,
#     payload: ApplicationFullUpdate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """
#     Full update of an application (all sections at once).

#     EDIT BEHAVIOR: If the app is PUBLISHED, it stays PUBLISHED after save.
#     The status does NOT revert to DRAFT on edit.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         # Collect scalar updates (only provided fields)
#         scalar_kwargs = {}
#         if payload.name is not None:
#             scalar_kwargs["name"] = payload.name.strip()
#         if payload.description is not None:
#             scalar_kwargs["description"] = payload.description
#         if payload.logo_url is not None:
#             scalar_kwargs["logo_url"] = payload.logo_url
#         if payload.available_for_all_users is not None:
#             scalar_kwargs["available_for_all_users"] = payload.available_for_all_users
#         if payload.upload_enabled is not None:
#             scalar_kwargs["upload_enabled"] = payload.upload_enabled
#         if payload.welcome_prompt is not None:
#             scalar_kwargs["welcome_prompt"] = payload.welcome_prompt
#         if payload.disclaimer is not None:
#             scalar_kwargs["disclaimer"] = payload.disclaimer
#         if payload.sorry_message is not None:
#             scalar_kwargs["sorry_message"] = payload.sorry_message
#         if payload.starter_questions is not None:
#             scalar_kwargs["starter_questions"] = payload.starter_questions
#         if payload.persona_id is not None:
#             scalar_kwargs["persona_id"] = payload.persona_id
#         if payload.persona_text is not None:
#             scalar_kwargs["persona_text"] = payload.persona_text
#         if payload.guardrail_text is not None:
#             scalar_kwargs["guardrail_text"] = payload.guardrail_text

#         # Apply scalar updates
#         if scalar_kwargs:
#             app = await _app_repo.update_application(
#                 db, application_id, user_id, user.role, **scalar_kwargs
#             )
#             if app is None:
#                 raise HTTPException(404, "Application not found after update")

#         # Sync link tables (only if provided in payload)
#         app_id_str = application_id
#         if payload.llm_links is not None:
#             await _app_repo.sync_llm_links(db, app_id_str, payload.llm_links)
#         if payload.skill_links is not None:
#             await _app_repo.sync_skill_links(db, app_id_str, payload.skill_links)
#         if payload.data_source_ids is not None:
#             await _app_repo.sync_data_source_links(
#                 db, app_id_str, payload.data_source_ids
#             )
#             from apps.appmgr.context import invalidate_application

#             invalidate_application(app_id_str)
#         if payload.designation_ids is not None:
#             await _app_repo.sync_designation_links(
#                 db, app_id_str, payload.designation_ids
#             )
#         if payload.business_unit_ids is not None:
#             await _app_repo.sync_business_unit_links(
#                 db, app_id_str, payload.business_unit_ids
#             )
#         if payload.tag_ids is not None:
#             await _app_repo.sync_tag_links(db, app_id_str, payload.tag_ids)
#         if payload.guardrail_category_ids is not None:
#             await _app_repo.sync_guardrail_links(
#                 db, app_id_str, payload.guardrail_category_ids
#             )

#         # Expire cached objects so relationships reload from DB
#         db.expire_all()

#         # Rebuild config JSONB after link and scalar changes (dual-write)
#         await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

#         # Re-fetch with refreshed relationships
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found after update")
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # PATCH /api/applications/{application_id}/setup
# # -------------------------------------------------------------------
# @router.patch("/{application_id}/setup", response_model=ApplicationDetail)
# async def patch_setup(
#     application_id: str,
#     payload: ApplicationSetupUpdate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Update the App Setup section (Step 1): LLMs, Skills, Data Sources."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         if payload.llm_links is not None:
#             await _app_repo.sync_llm_links(db, application_id, payload.llm_links)
#         if payload.skill_links is not None:
#             await _app_repo.sync_skill_links(db, application_id, payload.skill_links)
#         if payload.data_source_ids is not None:
#             await _app_repo.sync_data_source_links(
#                 db, application_id, payload.data_source_ids
#             )
#             # The application's evidence changed. A cached ledger would keep
#             # reporting the old set of sources to every live chat session.
#             from apps.appmgr.context import invalidate_application

#             invalidate_application(application_id)

#         # Expire cached objects so relationships reload from DB
#         db.expire_all()

#         # Rebuild config JSONB after link changes (dual-write)
#         await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # PATCH /api/applications/{application_id}/access
# # -------------------------------------------------------------------
# @router.patch("/{application_id}/access", response_model=ApplicationDetail)
# async def patch_access(
#     application_id: str,
#     payload: ApplicationAccessUpdate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Update the Access Permission section (Step 2)."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         # Scalar access fields
#         scalar_kwargs = {}
#         if payload.available_for_all_users is not None:
#             scalar_kwargs["available_for_all_users"] = payload.available_for_all_users
#         if payload.upload_enabled is not None:
#             scalar_kwargs["upload_enabled"] = payload.upload_enabled
#         if scalar_kwargs:
#             await _app_repo.update_application(
#                 db, application_id, user_id, user.role, **scalar_kwargs
#             )

#         # Link tables
#         await _app_repo.sync_designation_links(
#             db, application_id, payload.designation_ids
#         )
#         await _app_repo.sync_business_unit_links(
#             db, application_id, payload.business_unit_ids
#         )
#         await _app_repo.sync_tag_links(db, application_id, payload.tag_ids)

#         # Expire cached objects so relationships reload from DB
#         db.expire_all()

#         # Rebuild config JSONB after link changes (dual-write)
#         await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # PATCH /api/applications/{application_id}/context
# # -------------------------------------------------------------------
# @router.patch("/{application_id}/context", response_model=ApplicationDetail)
# async def patch_context(
#     application_id: str,
#     payload: ApplicationContextUpdate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Update the Context section (Step 3)."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         kwargs = {}
#         if payload.welcome_prompt is not None:
#             kwargs["welcome_prompt"] = payload.welcome_prompt
#         if payload.disclaimer is not None:
#             kwargs["disclaimer"] = payload.disclaimer
#         if payload.sorry_message is not None:
#             kwargs["sorry_message"] = payload.sorry_message
#         if payload.starter_questions is not None:
#             kwargs["starter_questions"] = payload.starter_questions

#         if kwargs:
#             await _app_repo.update_application(
#                 db, application_id, user_id, user.role, **kwargs
#             )

#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # PATCH /api/applications/{application_id}/chat-config
# # -------------------------------------------------------------------
# @router.patch("/{application_id}/chat-config", response_model=ApplicationDetail)
# async def patch_chat_config(
#     application_id: str,
#     payload: ApplicationChatConfigUpdate,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Update the Chat Configuration section (Step 4)."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         kwargs = {}
#         if payload.persona_id is not None:
#             kwargs["persona_id"] = payload.persona_id
#         if payload.persona_text is not None:
#             kwargs["persona_text"] = payload.persona_text
#         if payload.guardrail_text is not None:
#             kwargs["guardrail_text"] = payload.guardrail_text

#         if kwargs:
#             await _app_repo.update_application(
#                 db, application_id, user_id, user.role, **kwargs
#             )

#         # Sync guardrail category links
#         await _app_repo.sync_guardrail_links(
#             db, application_id, payload.guardrail_category_ids
#         )

#         # Expire cached objects so relationships reload from DB
#         db.expire_all()

#         # Rebuild config JSONB after link and scalar changes (dual-write)
#         await _app_repo.sync_config_jsonb(db, application_id, user_id, user.role)

#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # DELETE /api/applications/{application_id} -- Soft Delete
# # -------------------------------------------------------------------
# @router.delete("/{application_id}", status_code=204)
# async def delete_application(
#     application_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Soft-delete an application (sets is_deleted = TRUE)."""
#     user_id = resolve_user_id(user)
#     async with get_db_session() as db:
#         deleted = await _app_repo.soft_delete_application(
#             db, application_id, user_id, user.role
#         )
#         if not deleted:
#             raise HTTPException(404, "Application not found")
#     return Response(status_code=204)


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/publish
# # -------------------------------------------------------------------
# @router.post("/{application_id}/publish", response_model=ApplicationDetail)
# async def publish_application(
#     application_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """
#     Validate required fields and transition DRAFT -> PUBLISHED.

#     Returns 400 with a list of missing fields if validation fails.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         if app.status == "published":
#             raise HTTPException(400, "Application is already published")

#         # Approval gate: must be approved before publishing
#         if app.approval_status != "approved":
#             raise HTTPException(
#                 400,
#                 "Application must be approved by a Super Admin before publishing",
#             )

#         # Validate required fields for publish
#         errors: List[str] = []
#         warnings: List[str] = []

#         # Required — block publish if missing
#         if not app.llm_links:
#             errors.append("An LLM must be selected")
#         if not app.skill_links:
#             errors.append("At least 1 skill (workflow or agent) must be linked")

#         # Optional — warn but don't block
#         if not app.welcome_prompt:
#             warnings.append("welcome_prompt is not set — a default greeting will be used")
#         if not app.sorry_message:
#             warnings.append("sorry_message is not set — a default fallback will be used")

#         starters = app.starter_questions or []
#         if not starters or not any(
#             s.strip() for s in starters if isinstance(s, str)
#         ):
#             warnings.append("No starter questions set — chat UI will show no suggestions")

#         has_persona = bool(app.persona_id) or bool(
#             app.persona_text and app.persona_text.strip()
#         )
#         if not has_persona:
#             warnings.append("No persona set — a default persona will be used")

#         if warnings:
#             logger.warning(f"Publish warnings for app {application_id}: {warnings}")

#         if errors:
#             raise HTTPException(
#                 status_code=400,
#                 detail={"message": "Publish validation failed", "errors": errors},
#             )

#         app = await _app_repo.publish_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(500, "Failed to publish application")

#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/unpublish
# # -------------------------------------------------------------------
# @router.post("/{application_id}/unpublish", response_model=ApplicationDetail)
# async def unpublish_application(
#     application_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Transition PUBLISHED -> DRAFT."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.status != "published":
#             raise HTTPException(400, "Application is not currently published")

#         app = await _app_repo.unpublish_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(500, "Failed to unpublish application")

#         return await _build_app_detail(db, app)


# # ===================================================================
# # APPROVAL QUEUE ENDPOINTS
# # ===================================================================


# async def _notify_super_admins_for_app(
#     db: AsyncSession,
#     app: Application,
#     notif_type: str,
#     title: str,
#     message: str,
# ) -> None:
#     """
#     Create notifications for super_admins with matching BU/designation.

#     Finds all super_admin users whose BU and designation overlap with
#     the application's BU/designation links, then creates a notification
#     for each.
#     """
#     from echolib.models.application import (
#         ApplicationDesignationLink,
#         ApplicationBusinessUnitLink,
#     )

#     app_uuid = app.application_id

#     # Get super_admin user IDs with matching designation
#     desig_users_stmt = (
#         select(UserDesignationLink.user_id).where(
#             UserDesignationLink.designation_id.in_(
#                 select(ApplicationDesignationLink.designation_id).where(
#                     ApplicationDesignationLink.application_id == app_uuid
#                 )
#             )
#         )
#     )
#     # Get super_admin user IDs with matching BU
#     bu_users_stmt = (
#         select(UserBusinessUnitLink.user_id).where(
#             UserBusinessUnitLink.business_unit_id.in_(
#                 select(ApplicationBusinessUnitLink.business_unit_id).where(
#                     ApplicationBusinessUnitLink.application_id == app_uuid
#                 )
#             )
#         )
#     )
#     # Super admins who match both
#     super_admins_stmt = (
#         select(User.user_id).where(
#             User.role == "super_admin",
#             User.is_active == True,  # noqa: E712
#             User.user_id.in_(desig_users_stmt),
#             User.user_id.in_(bu_users_stmt),
#         )
#     )
#     result = await db.execute(super_admins_stmt)
#     sa_ids = [str(uid) for uid in result.scalars().all()]

#     if not sa_ids:
#         # Fallback: notify all super_admins if none match ABAC
#         fallback = await db.execute(
#             select(User.user_id).where(
#                 User.role == "super_admin",
#                 User.is_active == True,  # noqa: E712
#             )
#         )
#         sa_ids = [str(uid) for uid in fallback.scalars().all()]

#     if sa_ids:
#         await _notif_repo.create_bulk_notifications(
#             db,
#             user_ids=sa_ids,
#             type=notif_type,
#             title=title,
#             message=message,
#             reference_id=str(app_uuid),
#             reference_type="application",
#         )


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/approve
# # -------------------------------------------------------------------
# @router.post("/{application_id}/approve", response_model=ApplicationDetail)
# async def approve_application(
#     application_id: str,
#     user: UserContext = Depends(require_super_admin),
# ):
#     """Approve an application (super_admin only)."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_application_by_id(db, application_id)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.approval_status != "pending":
#             raise HTTPException(400, f"Application is not pending approval (current: {app.approval_status})")

#         app = await _app_repo.approve_application(db, application_id, user_id)
#         if app is None:
#             raise HTTPException(500, "Failed to approve application")

#         # Audit log
#         await _audit_repo.log_action(
#             db,
#             application_id=application_id,
#             action="approved",
#             performed_by=user_id,
#         )

#         # Notify app owner
#         await _notif_repo.create_notification(
#             db,
#             user_id=str(app.user_id),
#             type="approval_approved",
#             title=f"Application '{app.name}' approved",
#             message=f"Your application '{app.name}' has been approved. You can now publish it.",
#             reference_id=str(app.application_id),
#             reference_type="application",
#         )

#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/reject
# # -------------------------------------------------------------------
# @router.post("/{application_id}/reject", response_model=ApplicationDetail)
# async def reject_application(
#     application_id: str,
#     payload: RejectPayload = None,
#     user: UserContext = Depends(require_super_admin),
# ):
#     """Reject an application with optional comment (super_admin only)."""
#     user_id = resolve_user_id(user)
#     comment = payload.comment if payload else None

#     async with get_db_session() as db:
#         app = await _app_repo.get_application_by_id(db, application_id)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.approval_status != "pending":
#             raise HTTPException(400, f"Application is not pending approval (current: {app.approval_status})")

#         app = await _app_repo.reject_application(db, application_id, user_id, comment)
#         if app is None:
#             raise HTTPException(500, "Failed to reject application")

#         # Audit log
#         await _audit_repo.log_action(
#             db,
#             application_id=application_id,
#             action="rejected",
#             performed_by=user_id,
#             comment=comment,
#         )

#         # Notify app owner
#         msg = f"Your application '{app.name}' was rejected."
#         if comment:
#             msg += f" Reason: {comment}"
#         await _notif_repo.create_notification(
#             db,
#             user_id=str(app.user_id),
#             type="approval_rejected",
#             title=f"Application '{app.name}' rejected",
#             message=msg,
#             reference_id=str(app.application_id),
#             reference_type="application",
#         )

#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/resubmit-approval
# # -------------------------------------------------------------------
# @router.post("/{application_id}/resubmit-approval", response_model=ApplicationDetail)
# async def resubmit_for_approval(
#     application_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Resubmit a rejected application for approval."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_application(db, application_id, user_id)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.approval_status != "rejected":
#             raise HTTPException(400, "Only rejected applications can be resubmitted")

#         app = await _app_repo.resubmit_for_approval(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(500, "Failed to resubmit application")

#         # Audit log
#         await _audit_repo.log_action(
#             db,
#             application_id=application_id,
#             action="resubmitted",
#             performed_by=user_id,
#         )

#         # Notify super_admins
#         await _notify_super_admins_for_app(
#             db, app,
#             notif_type="approval_pending",
#             title=f"Application '{app.name}' resubmitted",
#             message=f"Application '{app.name}' has been resubmitted for approval.",
#         )

#         return await _build_app_detail(db, app)


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/audit-trail
# # -------------------------------------------------------------------
# @router.get("/{application_id}/audit-trail", response_model=List[AuditLogEntry])
# async def get_audit_trail(
#     application_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Get the approval audit trail for an application."""
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Verify caller owns the app or is super_admin
#         app = await _app_repo.get_application_by_id(db, application_id)
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if str(app.user_id) != user_id and getattr(user, "role", "") != "super_admin":
#             raise HTTPException(403, "You can only view audit trails for your own applications")

#         entries = await _audit_repo.get_audit_trail(db, application_id=application_id)
#         return [
#             AuditLogEntry(
#                 audit_id=str(e.audit_id),
#                 action=e.action,
#                 performed_by=str(e.performed_by),
#                 comment=e.comment,
#                 created_at=e.created_at,
#             )
#             for e in entries
#         ]


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/context-ledger -- Datasource health
# #
# # NOT "/context": that path is already taken by PATCH, which edits the
# # application's welcome prompt, disclaimer and starter questions. Two
# # unrelated meanings on one path would be a trap for the frontend, so the
# # ledger gets its own name. (app-plan.md §10.4 names "/context"; this is the
# # deviation, recorded here.)
# # -------------------------------------------------------------------
# @router.get("/{application_id}/context-ledger")
# async def get_application_context(
#     application_id: str,
#     session_id: Optional[str] = Query(
#         None,
#         description=(
#             "Optional chat session UUID. When given, the response also reports "
#             "the documents uploaded into that session."
#         ),
#     ),
#     refresh: bool = Query(
#         False, description="Re-resolve every source instead of serving the cache."
#     ),
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Report what evidence this application can actually draw on.

#     WHAT: Every linked datasource and knowledge base with its resolved kind,
#           whether it is reachable, and how much is in it — plus the documents
#           uploaded into ``session_id`` when one is supplied.
#     WHY:  Today a database that is attached but unreachable, or a knowledge
#           base with zero indexed documents, fails silently: the application
#           simply answers worse and nothing says why. This is the surface that
#           makes that visible, and it is the same ledger the chat pipeline runs
#           on, so what it reports is what actually happens.

#     Never returns a credential, a connection string, or any source content —
#     identity, health and counts only. ``200`` even when sources are unhealthy:
#     being unhealthy is an answer, not an error.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(
#             db, application_id, user_id, user.role
#         )
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         from apps.appmgr.context import get_or_build_ledger
#         from echolib.repositories.application_chat_repo import (
#             ApplicationChatRepository,
#         )

#         ledger = await get_or_build_ledger(
#             app,
#             user_id=user_id,
#             chat_session_id=session_id,
#             chat_repo=ApplicationChatRepository() if session_id else None,
#             db=db if session_id else None,
#             force=refresh,
#         )
#         return ledger.describe()


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/logo -- Upload Logo
# # -------------------------------------------------------------------
# @router.post("/{application_id}/logo", response_model=ApplicationDetail)
# async def upload_logo(
#     application_id: str,
#     file: UploadFile = File(...),
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     """Upload an application logo (PNG/JPEG/WEBP, resized to 250x250 max)."""
#     user_id = resolve_user_id(user)

#     if file.content_type not in {"image/png", "image/jpeg", "image/webp"}:
#         raise HTTPException(400, "Only PNG, JPEG, or WEBP images are allowed")

#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(db, application_id, user_id, user.role)
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         filename = f"{application_id}_{uuid.uuid4().hex}.png"
#         path = os.path.join(LOGOS_DIR, filename)

#         try:
#             from PIL import Image

#             img = Image.open(file.file).convert("RGBA")
#         except Exception:
#             raise HTTPException(400, "Invalid image file")

#         max_dim = 250
#         if img.width > max_dim or img.height > max_dim:
#             img.thumbnail((max_dim, max_dim), Image.LANCZOS)

#         img.save(path, format="PNG")

#         logo_url = f"/static/logos/{filename}"
#         app = await _app_repo.update_application(
#             db, application_id, user_id, user.role, logo_url=logo_url
#         )
#         if app is None:
#             raise HTTPException(500, "Failed to update logo")

#         return await _build_app_detail(db, app)


# # ===================================================================
# # Chat Endpoints (Phase 4)
# # ===================================================================


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/chat -- Full Pipeline
# # -------------------------------------------------------------------
# @router.post("/{application_id}/chat", response_model=ChatResponse)
# async def chat_with_application(
#     application_id: str,
#     payload: ChatMessageRequest,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Send a chat message to a published application.

#     Runs the full orchestration pipeline: pre-guardrails, prompt enhancement,
#     orchestrator LLM, skill execution, post-guardrails, persona formatting.

#     If ``session_id`` is omitted from the request, a new chat session is
#     created automatically. The response includes the session_id for
#     subsequent messages.
#     """
#     user_id = resolve_user_id(user)

#     # Validate application exists and user has access
#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(
#             db, application_id, user_id, user.role
#         )
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.status != "published":
#             raise HTTPException(
#                 400,
#                 "Application is not published. Only published applications can be used for chat.",
#             )

#     # Run the full orchestration pipeline in its own DB session
#     # (pipeline manages its own session lifecycle internally for
#     # multi-step operations that may need partial commits)
#     from .orchestrator.pipeline import OrchestrationPipeline

#     pipeline = OrchestrationPipeline()

#     async with get_db_session() as db:
#         result = await pipeline.run(
#             db=db,
#             application_id=application_id,
#             chat_session_id=payload.session_id,
#             user_message=payload.message,
#             user_id=user_id,
#         )

#     # Build the ChatMessageResponse for the assistant reply
#     assistant_message = ChatMessageResponse(
#         message_id=result.get("execution_trace", {}).get("message_id", ""),
#         role="assistant",
#         content=result.get("response", ""),
#         enhanced_prompt=result.get("execution_trace", {}).get("enhanced_prompt"),
#         execution_trace=result.get("execution_trace"),
#         guardrail_flags=result.get("execution_trace", {}).get("guardrail_output"),
#         created_at=datetime.now(timezone.utc),
#     )

#     # Build session metadata if this was a new session
#     session_meta = None
#     raw_meta = result.get("session_metadata")
#     if raw_meta:
#         session_meta = ChatSessionMetadata(
#             app_name=raw_meta.get("app_name", ""),
#             app_description=raw_meta.get("app_description"),
#             app_logo_url=raw_meta.get("app_logo_url"),
#             welcome_prompt=raw_meta.get("welcome_prompt"),
#             disclaimer=raw_meta.get("disclaimer"),
#             starter_questions=raw_meta.get("starter_questions", []),
#         )

#     return ChatResponse(
#         session_id=result.get("session_id", ""),
#         message=assistant_message,
#         conversation_state=result.get("conversation_state", "awaiting_input"),
#         session_metadata=session_meta,
#     )


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/chat/stream -- A2UI SSE
# # -------------------------------------------------------------------
# @router.post("/{application_id}/chat/stream")
# async def chat_stream(
#     application_id: str,
#     payload: ChatMessageRequest,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Streaming version of chat that emits A2UI v0.8 JSONL events via SSE.

#     The client receives real-time execution step updates as the pipeline
#     runs.  Each SSE event ``data:`` field contains a single A2UI JSONL
#     message (surfaceUpdate, dataModelUpdate, or beginRendering).

#     The stream terminates after the pipeline completes and the final
#     output has been sent.
#     """
#     import json as _json

#     user_id = resolve_user_id(user)

#     # Validate application exists and user has access
#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(
#             db, application_id, user_id, user.role
#         )
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.status != "published":
#             raise HTTPException(
#                 400,
#                 "Application is not published. Only published applications can be used for chat.",
#             )

#     # Use run_ prefix so the run_id matches the format that
#     # WorkflowExecutor uses for ws_manager queue subscription routing.
#     run_id = f"run_{uuid.uuid4().hex}"

#     sse_queue: asyncio.Queue = asyncio.Queue(maxsize=500)

#     # Assigned just below, before the response is iterated. The generator
#     # reads it to decide whether a quiet stream is a working run or a dead
#     # one -- which is a fact, not a timeout.
#     pipeline_task: Optional[asyncio.Task] = None

#     async def sse_generator():
#         """Yield A2UI JSONL lines from sse_queue as SSE data frames.

#         The pipeline's run_stream() manages its own ws_manager queue
#         subscriptions and translator task lifecycle.  This generator
#         only reads from sse_queue until it receives a None sentinel.

#         WHY THE HEARTBEAT: this stream used to yield only when the pipeline
#         pushed something, and a workflow can legitimately go minutes without
#         producing an event -- an agent waiting on a rate-limit window, a model
#         retrying with backoff, a long generation in flight. Azure's load
#         balancer closes a TCP connection that has carried no bytes for 230
#         seconds, and that limit "is not configurable and cannot be changed".

#         So the browser's ``fetch`` was being severed mid-run while the backend
#         carried on: ``_run_pipeline`` is a detached task and never knew the
#         client had gone. The user saw a step start, freeze, and finally fail
#         with a network error, while the logs showed the run completing. The
#         previous ``timeout=300.0`` guard could never help -- it sits *above*
#         the platform's own 230s ceiling, so the connection was always killed
#         first.

#         A comment frame (``:``) is the SSE spec's own keep-alive. It carries no
#         event, and this codebase's client already skips any line that does not
#         begin with ``data: ``, so nothing downstream changes.

#         Transport-level and therefore provider-agnostic: Azure, OpenAI,
#         Anthropic, Gemini and Ollama runs are all held open by the same frame.
#         """
#         idle_seconds = 0.0
#         try:
#             while True:
#                 try:
#                     item = await asyncio.wait_for(
#                         sse_queue.get(), timeout=_SSE_HEARTBEAT_SECONDS
#                     )
#                 except asyncio.TimeoutError:
#                     idle_seconds += _SSE_HEARTBEAT_SECONDS

#                     # LIVENESS, NOT ELAPSED SILENCE.
#                     #
#                     # This used to close the stream after a fixed 180 seconds of
#                     # quiet, and that number was wrong by construction: how long
#                     # a healthy run stays quiet depends on agent count, rate-limit
#                     # pacing, model, quota and reasoning effort -- none of which
#                     # are knowable when a constant is written. A fourteen-agent
#                     # run with two agents paced tens of seconds apart exceeded it
#                     # and a perfectly healthy stream was killed.
#                     #
#                     # The backend already knows the answer without guessing: the
#                     # task running the pipeline is either alive or it is not. A
#                     # live task is progressing even when it is deliberately
#                     # sleeping out a rate-limit window, so the stream stays open
#                     # for exactly as long as there is work, and closes the moment
#                     # there is not.
#                     if pipeline_task is not None and pipeline_task.done():
#                         # The run finished (or failed) without a sentinel. Drain
#                         # anything already queued before closing, so a final
#                         # message is never lost to this check.
#                         if not sse_queue.empty():
#                             continue
#                         failure = pipeline_task.exception() if not pipeline_task.cancelled() else None
#                         if failure is not None:
#                             logger.error(
#                                 "SSE stream for run %s: the pipeline failed after "
#                                 "%.0fs of quiet -- %s: %s",
#                                 run_id, idle_seconds,
#                                 type(failure).__name__, failure,
#                             )
#                             yield (
#                                 "data: "
#                                 + _json.dumps({
#                                     "type": "error",
#                                     "message": (
#                                         "The run could not be completed. "
#                                         f"{failure}"
#                                     ),
#                                 })
#                                 + "\n\n"
#                             )
#                         else:
#                             logger.info(
#                                 "SSE stream for run %s: pipeline finished; "
#                                 "closing the stream.", run_id,
#                             )
#                         break

#                     # Still working. Log sparingly so a long run leaves a trail
#                     # without flooding, and keep the connection alive.
#                     if idle_seconds % _SSE_QUIET_LOG_SECONDS < _SSE_HEARTBEAT_SECONDS:
#                         logger.info(
#                             "SSE stream for run %s: quiet for %.0fs, pipeline "
#                             "still running (agents may be paced or generating).",
#                             run_id, idle_seconds,
#                         )
#                     yield ": keepalive\n\n"
#                     continue

#                 idle_seconds = 0.0
#                 if item is None:  # sentinel -- stream ended
#                     break
#                 # Ensure item is a string for the SSE data field
#                 if isinstance(item, dict):
#                     data = _json.dumps(item, separators=(",", ":"))
#                 else:
#                     data = str(item)
#                 yield f"data: {data}\n\n"
#         except asyncio.CancelledError:
#             # The client went away. Expected on navigation; not an error.
#             logger.info("SSE stream for run %s was closed by the client", run_id)
#             raise

#     from .orchestrator.pipeline import OrchestrationPipeline

#     pipeline = OrchestrationPipeline()

#     async def _run_pipeline():
#         async with get_db_session() as db:
#             await pipeline.run_stream(
#                 sse_queue=sse_queue,
#                 run_id=run_id,
#                 db=db,
#                 app_id=application_id,
#                 user_input=payload.message,
#                 session_id=payload.session_id,
#                 user_id=user_id,
#                 uploaded_file_ids=payload.attachment_ids,
#             )

#     pipeline_task = asyncio.create_task(_run_pipeline())

#     return StreamingResponse(
#         sse_generator(),
#         media_type="text/event-stream",
#         headers={
#             "Cache-Control": "no-cache",
#             "Connection": "keep-alive",
#             "X-Accel-Buffering": "no",
#         },
#     )


# # -------------------------------------------------------------------
# # Shared helper: resume a workflow from HITL interrupt, handle result
# # -------------------------------------------------------------------
# async def _resume_workflow_and_finalize(
#     db: AsyncSession,
#     session_id: str,
#     app,
#     hitl_state: dict,
#     action: str,
#     resume_payload: dict,
#     user_id: str,
# ) -> HITLDecisionResponse:
#     """
#     Shared logic: resume a workflow from HITL interrupt, handle result.

#     Used by both the hitl-decide endpoint (approve/edit/skip) and the
#     upload endpoint (file_upload interrupt resume).
#     """
#     from .orchestrator.skill_executor import SkillExecutor

#     executor = SkillExecutor._resolve_workflow_executor()

#     run_id = hitl_state.get("run_id", "")
#     workflow_id = hitl_state.get("workflow_id", "")
#     fs_workflow_id = hitl_state.get("fs_workflow_id", "")

#     # Pre-load workflow definition in the current async context
#     _effective_wf_id = fs_workflow_id or workflow_id
#     workflow_def = None
#     try:
#         from echolib.di import container as di_container
#         gateway = di_container.resolve('workflow.storage_gateway')
#         workflow_def = await gateway.load_workflow(
#             _effective_wf_id, user_id or DEFAULT_USER_ID, state="draft",
#         )
#     except Exception as _preload_err:
#         logger.warning(
#             f"[HITL-RESUME] Could not pre-load workflow "
#             f"'{_effective_wf_id}': {_preload_err}. "
#             f"Falling back to executor._load_workflow()."
#         )

#     # resume_workflow is synchronous (LangGraph invoke)
#     resume_result = await asyncio.to_thread(
#         executor.resume_workflow,
#         workflow_id=_effective_wf_id,
#         run_id=run_id,
#         action=action,
#         payload=resume_payload,
#         execution_mode="draft",
#         user_id=user_id,
#         workflow_def=workflow_def,
#     )

#     if resume_result.get("status") == "failed":
#         error_msg = (
#             f"Workflow resume failed: {resume_result.get('error', 'unknown')}"
#         )
#         await _chat_repo.add_message(
#             db, session_id, "assistant", error_msg,
#             execution_trace={"type": "hitl_resume_failed", "run_id": run_id},
#             user_id=user_id,
#             application_id=str(app.application_id),
#         )
#         await _chat_repo.update_session_state(
#             db,
#             session_id,
#             conversation_state="awaiting_input",
#             context_data={},
#             user_id=user_id,
#             application_id=str(app.application_id),
#         )
#         return HITLDecisionResponse(
#             status="failed",
#             message=error_msg,
#             session_id=session_id,
#             conversation_state="awaiting_input",
#             execution_trace={
#                 "action": action,
#                 "run_id": run_id,
#                 "error": resume_result.get("error"),
#             },
#         )

#     # Check if we hit ANOTHER interrupt (chained HITL nodes)
#     if resume_result.get("status") == "interrupted":
#         new_interrupt = resume_result.get("interrupt", {})
#         new_allowed = new_interrupt.get(
#             "allowed_decisions", new_interrupt.get("allowed_actions", ["approve", "reject"])
#         )

#         new_hitl_state = {
#             "hitl_state": {
#                 "run_id": resume_result.get("run_id", run_id),
#                 "workflow_id": workflow_id,
#                 "fs_workflow_id": fs_workflow_id,
#                 "interrupt_payload": new_interrupt,
#                 "interrupt_type": new_interrupt.get("interrupt_type", "hitl"),
#                 "completed_steps": hitl_state.get("completed_steps", []),
#                 "remaining_plan": hitl_state.get("remaining_plan", []),
#                 "execution_plan": hitl_state.get("execution_plan", []),
#                 "execution_strategy": hitl_state.get("execution_strategy", "single"),
#                 "enhanced_prompt": hitl_state.get("enhanced_prompt", ""),
#             }
#         }

#         re_interrupt_msg = (
#             "Workflow paused again for human review."
#             f"\n\n**{new_interrupt.get('title', 'Review Required')}**: "
#             f"{new_interrupt.get('message', 'Please review and decide.')}"
#         )

#         await _chat_repo.add_message(
#             db, session_id, "assistant", re_interrupt_msg,
#             execution_trace={
#                 "type": "hitl_interrupt",
#                 "hitl_context": {
#                     "title": new_interrupt.get("title"),
#                     "message": new_interrupt.get("message"),
#                     "priority": new_interrupt.get("priority"),
#                     "allowed_decisions": new_allowed,
#                     "run_id": resume_result.get("run_id", run_id),
#                     "node_outputs": new_interrupt.get("node_outputs"),
#                 },
#             },
#             user_id=user_id,
#             application_id=str(app.application_id),
#         )

#         await _chat_repo.update_session_state(
#             db,
#             session_id,
#             conversation_state="awaiting_clarification",
#             context_data=new_hitl_state,
#             user_id=user_id,
#             application_id=str(app.application_id),
#         )

#         return HITLDecisionResponse(
#             status="interrupted",
#             message=re_interrupt_msg,
#             session_id=session_id,
#             conversation_state="awaiting_hitl_review",
#             execution_trace={
#                 "action": action,
#                 "hitl_context": {
#                     "title": new_interrupt.get("title"),
#                     "message": new_interrupt.get("message"),
#                     "priority": new_interrupt.get("priority"),
#                     "allowed_decisions": new_allowed,
#                     "run_id": resume_result.get("run_id", run_id),
#                 },
#             },
#         )

#     # ----- COMPLETED -----
#     output = resume_result.get("output", {})
#     resumed_output_text = SkillExecutor._extract_output_text(output)

#     all_completed_outputs = []
#     for cs in hitl_state.get("completed_steps", []):
#         all_completed_outputs.append(cs.get("output", ""))
#     all_completed_outputs.append(resumed_output_text)

#     # Execute remaining plan steps (if any)
#     remaining_plan = hitl_state.get("remaining_plan", [])
#     remaining_execution_log: List[Dict[str, Any]] = []

#     if remaining_plan:
#         skill_executor = SkillExecutor()
#         enhanced_prompt = hitl_state.get("enhanced_prompt", "")

#         remaining_result = await skill_executor.execute_plan(
#             db=db,
#             execution_plan=remaining_plan,
#             execution_strategy="sequential",
#             user_input=resumed_output_text,
#             app_id=str(app.application_id),
#             user_id=user_id,
#             chat_session_id=session_id,
#             application_id=str(app.application_id),
#         )

#         if remaining_result.get("hitl_interrupted"):
#             remaining_interrupt = remaining_result.get("interrupt_payload", {})
#             remaining_int_ctx = remaining_interrupt.get("interrupt", {})

#             for cs in remaining_result.get("completed_steps", []):
#                 all_completed_outputs.append(cs.get("output", ""))

#             new_hitl_state = {
#                 "hitl_state": {
#                     "run_id": remaining_result.get("run_id", ""),
#                     "workflow_id": remaining_result.get("workflow_id", ""),
#                     "fs_workflow_id": remaining_interrupt.get("fs_workflow_id", ""),
#                     "interrupt_payload": remaining_int_ctx,
#                     "interrupt_type": remaining_int_ctx.get("interrupt_type", "hitl"),
#                     "completed_steps": (
#                         hitl_state.get("completed_steps", [])
#                         + [{"step": "resumed", "skill_name": "resumed_workflow", "output": resumed_output_text}]
#                         + remaining_result.get("completed_steps", [])
#                     ),
#                     "remaining_plan": remaining_result.get("remaining_plan", []),
#                     "execution_plan": hitl_state.get("execution_plan", []),
#                     "execution_strategy": hitl_state.get("execution_strategy", "sequential"),
#                     "enhanced_prompt": enhanced_prompt,
#                 }
#             }

#             new_allowed = remaining_int_ctx.get(
#                 "allowed_decisions", ["approve", "reject"]
#             )
#             re_interrupt_msg = (
#                 "Workflow paused again for human review."
#                 f"\n\n**{remaining_int_ctx.get('title', 'Review Required')}**: "
#                 f"{remaining_int_ctx.get('message', 'Please review and decide.')}"
#             )

#             await _chat_repo.add_message(
#                 db, session_id, "assistant", re_interrupt_msg,
#                 execution_trace={
#                     "type": "hitl_interrupt",
#                     "hitl_context": {
#                         "title": remaining_int_ctx.get("title"),
#                         "message": remaining_int_ctx.get("message"),
#                         "priority": remaining_int_ctx.get("priority"),
#                         "allowed_decisions": new_allowed,
#                         "run_id": remaining_result.get("run_id", ""),
#                     },
#                 },
#                 user_id=user_id,
#                 application_id=str(app.application_id),
#             )
#             await _chat_repo.update_session_state(
#                 db, session_id,
#                 conversation_state="awaiting_clarification",
#                 context_data=new_hitl_state,
#                 user_id=user_id,
#                 application_id=str(app.application_id),
#             )

#             return HITLDecisionResponse(
#                 status="interrupted",
#                 message=re_interrupt_msg,
#                 session_id=session_id,
#                 conversation_state="awaiting_hitl_review",
#                 execution_trace={
#                     "action": action,
#                     "hitl_context": {
#                         "title": remaining_int_ctx.get("title"),
#                         "message": remaining_int_ctx.get("message"),
#                         "priority": remaining_int_ctx.get("priority"),
#                         "allowed_decisions": new_allowed,
#                         "run_id": remaining_result.get("run_id", ""),
#                     },
#                 },
#             )

#         remaining_final = remaining_result.get("final_output", "")
#         if remaining_final:
#             all_completed_outputs.append(remaining_final)
#         remaining_execution_log = remaining_result.get("execution_log", [])

#     final_output = all_completed_outputs[-1] if all_completed_outputs else resumed_output_text

#     # Post-guardrails on the final output
#     from .orchestrator.guardrails import GuardrailsEngine

#     guardrails_engine = GuardrailsEngine()
#     guardrail_categories: List[str] = []
#     if app.guardrail_links:
#         from echolib.models.application_lookups import AppGuardrailCategory
#         from echolib.repositories.base import safe_uuid
#         from sqlalchemy import select as _select

#         cat_ids = []
#         for link in app.guardrail_links:
#             uid = safe_uuid(str(link.guardrail_category_id))
#             if uid:
#                 cat_ids.append(uid)
#         if cat_ids:
#             cat_result = await db.execute(
#                 _select(AppGuardrailCategory).where(
#                     AppGuardrailCategory.guardrail_category_id.in_(cat_ids)
#                 )
#             )
#             guardrail_categories = [
#                 c.name for c in cat_result.scalars().all()
#             ]

#     post_guard = guardrails_engine.post_process(
#         final_output,
#         guardrail_categories=guardrail_categories,
#         guardrail_text=app.guardrail_text,
#     )
#     final_output = post_guard.sanitized_text

#     # Save the final assistant message
#     await _chat_repo.add_message(
#         db, session_id, "assistant", final_output,
#         execution_trace={
#             "type": "hitl_resumed_completion",
#             "run_id": run_id,
#             "action": action,
#             "remaining_steps_executed": len(remaining_plan),
#             "remaining_execution_log": remaining_execution_log,
#             "guardrail_output": {
#                 "is_safe": post_guard.is_safe,
#                 "violations": post_guard.violations,
#             },
#         },
#         user_id=user_id,
#         application_id=str(app.application_id),
#     )

#     # Clear HITL state and return to normal
#     await _chat_repo.update_session_state(
#         db,
#         session_id,
#         conversation_state="awaiting_input",
#         context_data={},
#         user_id=user_id,
#         application_id=str(app.application_id),
#     )

#     return HITLDecisionResponse(
#         status="completed",
#         message=final_output,
#         session_id=session_id,
#         conversation_state="awaiting_input",
#         execution_trace={
#             "action": action,
#             "run_id": run_id,
#             "status": "completed",
#             "remaining_steps_executed": len(remaining_plan),
#         },
#     )


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/chat/hitl-decide
# # -- Human-in-the-Loop Decision
# # -------------------------------------------------------------------
# @router.post(
#     "/{application_id}/chat/hitl-decide",
#     response_model=HITLDecisionResponse,
# )
# async def hitl_decide(
#     application_id: str,
#     payload: HITLDecisionRequest,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Submit a human decision for a workflow paused at a HITL node.

#     The chat session must be in ``awaiting_clarification`` state with
#     a valid ``hitl_state`` stored in ``context_data``.  The action must
#     be one of the ``allowed_decisions`` defined by the HITL node.

#     Supported actions:
#         - **approve**: Resume the workflow from the interrupt point.
#         - **reject**: Terminate the workflow and return to normal chat.
#         - **edit**: Resume with modified payload.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # 1. Validate application exists and user has access
#         app = await _app_repo.get_accessible_application(
#             db, application_id, user_id, user.role
#         )
#         if app is None:
#             raise HTTPException(404, "Application not found")
#         if app.status != "published":
#             raise HTTPException(
#                 400,
#                 "Application is not published.",
#             )

#         # 2. Validate session exists and is in HITL review state
#         session = await _chat_repo.get_session(db, payload.session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application")

#         # HITL uses 'awaiting_clarification' as DB state with hitl_state
#         # in context_data to distinguish from regular clarification.
#         context_data = session.context_data or {}
#         hitl_state = context_data.get("hitl_state")

#         if session.conversation_state != "awaiting_clarification" or not hitl_state:
#             raise HTTPException(
#                 400,
#                 "Session is not awaiting HITL review. "
#                 "Current state does not have a pending HITL interrupt.",
#             )

#         # 3. Validate action is allowed
#         interrupt_payload = hitl_state.get("interrupt_payload", {})
#         allowed_decisions = (
#             interrupt_payload.get("allowed_decisions")
#             or interrupt_payload.get("allowed_actions")
#             or ["approve", "reject"]
#         )

#         # Also try to derive from the HITL config if available
#         try:
#             from apps.workflow.runtime.hitl import derive_allowed_decisions
#             hitl_config = interrupt_payload.get("hitl_config")
#             if hitl_config:
#                 allowed_decisions = derive_allowed_decisions(hitl_config)
#         except ImportError:
#             pass

#         if payload.action not in allowed_decisions:
#             raise HTTPException(
#                 400,
#                 f"Action '{payload.action}' is not allowed. "
#                 f"Allowed decisions: {allowed_decisions}",
#             )

#         run_id = hitl_state.get("run_id", "")
#         workflow_id = hitl_state.get("workflow_id", "")
#         fs_workflow_id = hitl_state.get("fs_workflow_id", "")

#         # ----- REJECT -----
#         if payload.action == "reject":
#             reject_msg = "Workflow execution was rejected by human reviewer."
#             if payload.rationale:
#                 reject_msg += f"\n\nRationale: {payload.rationale}"

#             await _chat_repo.add_message(
#                 db, payload.session_id, "assistant", reject_msg,
#                 execution_trace={"type": "hitl_reject", "run_id": run_id},
#             )

#             # Clear HITL state and return to normal
#             await _chat_repo.update_session_state(
#                 db,
#                 payload.session_id,
#                 conversation_state="awaiting_input",
#                 context_data={},
#             )

#             return HITLDecisionResponse(
#                 status="rejected",
#                 message=reject_msg,
#                 session_id=payload.session_id,
#                 conversation_state="awaiting_input",
#                 execution_trace={"action": "reject", "run_id": run_id},
#             )

#         # ----- SKIP (file_upload interrupt only) -----
#         if payload.action == "skip":
#             if hitl_state.get("interrupt_type") != "file_upload":
#                 raise HTTPException(
#                     400,
#                     "Skip action is only allowed for file_upload interrupts.",
#                 )
#             return await _resume_workflow_and_finalize(
#                 db, payload.session_id, app, hitl_state,
#                 action="skip",
#                 resume_payload={"document_context": "", "document_metadata": {"skipped": True}},
#                 user_id=user_id,
#             )

#         # ----- APPROVE or EDIT -----
#         # Both require resuming the workflow via WorkflowExecutor
#         resume_payload = payload.payload or {}
#         if payload.rationale:
#             resume_payload["rationale"] = payload.rationale

#         return await _resume_workflow_and_finalize(
#             db, payload.session_id, app, hitl_state,
#             action=payload.action,
#             resume_payload=resume_payload,
#             user_id=user_id,
#         )


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/chat/history -- List Sessions
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/chat/history",
#     response_model=List[ChatSessionResponse],
# )
# async def list_chat_sessions(
#     application_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     List all chat sessions for an application, scoped to the current user.

#     Returns sessions ordered by ``updated_at`` descending (most recent first).
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Validate application exists and user has access
#         app = await _app_repo.get_accessible_application(
#             db, application_id, user_id, user.role
#         )
#         if app is None:
#             raise HTTPException(404, "Application not found")

#         sessions = await _chat_repo.list_sessions(db, application_id, user_id)

#         return [
#             ChatSessionResponse(
#                 chat_session_id=str(s.chat_session_id),
#                 application_id=str(s.application_id),
#                 title=s.title,
#                 conversation_state=s.conversation_state,
#                 started_at=s.started_at,
#                 updated_at=s.updated_at,
#                 message_count=len(s.messages) if s.messages else 0,
#             )
#             for s in sessions
#         ]


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/chat/sessions/{session_id}
# # -- Get Messages for a Session
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/chat/sessions/{session_id}",
#     response_model=List[ChatMessageResponse],
# )
# async def get_chat_messages(
#     application_id: str,
#     session_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Get all messages for a specific chat session.

#     Validates that the session belongs to the current user and the
#     specified application before returning messages.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Verify session exists and is owned by user AND belongs to this application
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application")

#         messages = await _chat_repo.get_messages(db, session_id)

#         return [
#             ChatMessageResponse(
#                 message_id=str(msg.message_id),
#                 role=msg.role,
#                 content=msg.content,
#                 enhanced_prompt=msg.enhanced_prompt,
#                 execution_trace=msg.execution_trace,
#                 guardrail_flags=msg.guardrail_flags,
#                 created_at=msg.created_at,
#             )
#             for msg in messages
#         ]


# # -------------------------------------------------------------------
# # DELETE /api/applications/{application_id}/chat/sessions/{session_id}
# # -- Close a Chat Session
# # -------------------------------------------------------------------
# @router.delete(
#     "/{application_id}/chat/sessions/{session_id}",
#     status_code=204,
# )
# async def close_chat_session(
#     application_id: str,
#     session_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Close (soft-delete) a chat session.

#     The session is marked as closed and will no longer accept new messages.
#     Existing messages are preserved for audit purposes.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Verify session exists and is owned by user AND belongs to this application
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application")

#         await _chat_repo.close_session(db, session_id, user_id, application_id)

#     return Response(status_code=204)


# # -------------------------------------------------------------------
# # PATCH /api/applications/{application_id}/chat/sessions/{session_id}/title
# # -- Rename a Chat Session
# # -------------------------------------------------------------------
# @router.patch(
#     "/{application_id}/chat/sessions/{session_id}/title",
#     response_model=ChatSessionResponse,
# )
# async def rename_chat_session(
#     application_id: str,
#     session_id: str,
#     payload: TitleUpdateRequest,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Rename a chat session by updating its title.

#     The title is stripped of leading/trailing whitespace and must be
#     between 1 and 200 characters.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Verify session exists and is owned by user AND belongs to this application
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application")

#         # Update the title
#         updated = await _chat_repo.update_session_title(
#             db, session_id, payload.title, user_id, application_id
#         )
#         if updated == 0:
#             raise HTTPException(404, "Chat session not found")

#         # Re-fetch the session to return updated metadata
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found after update")

#         return ChatSessionResponse(
#             chat_session_id=str(session.chat_session_id),
#             application_id=str(session.application_id),
#             title=session.title,
#             conversation_state=session.conversation_state,
#             started_at=session.started_at,
#             updated_at=session.updated_at,
#             message_count=len(session.messages) if hasattr(session, 'messages') and session.messages else 0,
#         )


# # -------------------------------------------------------------------
# # GET /api/applications/{id}/chat/sessions/{id}/export/pdf
# # -- Export Chat Session as PDF
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/chat/sessions/{session_id}/export/pdf",
# )
# async def export_chat_session_pdf(
#     application_id: str,
#     session_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Export all messages for a chat session as a downloadable PDF.

#     Validates that the session belongs to the current user and the
#     specified application before generating the export.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application")

#         messages = await _chat_repo.get_messages(db, session_id, limit=10000)

#         title = session.title or "Untitled Session"
#         date_str = (
#             session.started_at.strftime("%Y-%m-%d")
#             if session.started_at
#             else ""
#         )
#         msg_dicts = [
#             {
#                 "role": msg.role,
#                 "content": msg.content,
#                 "created_at": msg.created_at,
#             }
#             for msg in messages
#         ]

#     buf = generate_chat_pdf(
#         title=title,
#         date=date_str,
#         message_count=len(msg_dicts),
#         messages=msg_dicts,
#     )

#     return StreamingResponse(
#         buf,
#         media_type="application/pdf",
#         headers={
#             "Content-Disposition": (
#                 f'attachment; filename="chat_export_{session_id}.pdf"'
#             ),
#         },
#     )


# # -------------------------------------------------------------------
# # How much of an interrupt document is handed to the resuming workflow node
# # inline. The document is also indexed and searchable, so this is a head start
# # rather than the only access -- which is why it is bounded rather than whole.
# HITL_DOCUMENT_CONTEXT_CHARS = 24000


# def _hitl_document_context_chars() -> int:
#     """Inline budget for a document uploaded into a file_upload interrupt."""
#     try:
#         return max(
#             1000,
#             int(os.getenv("APP_HITL_DOCUMENT_CONTEXT_CHARS", str(HITL_DOCUMENT_CONTEXT_CHARS))),
#         )
#     except (TypeError, ValueError):
#         return HITL_DOCUMENT_CONTEXT_CHARS


# def _format_upload_event_text(filename: str, status: str, size_bytes: Optional[int]) -> str:
#     """Build a human-readable upload event line for the chat timeline."""
#     normalized_status = (status or "unknown").lower()
#     if size_bytes and size_bytes > 0:
#         size_mb = size_bytes / (1024 * 1024)
#         return f"Uploaded file: {filename} ({normalized_status}, {size_mb:.2f} MB)"
#     return f"Uploaded file: {filename} ({normalized_status})"


# async def _record_upload_history_event(
#     db: AsyncSession,
#     application_id: str,
#     session_id: str,
#     user_id: str,
#     upload: DocumentUploadResponse,
# ) -> None:
#     """
#     Persist one timeline event per uploaded file.

#     WHY: upload rows are durable in ``application_documents`` but the chat
#     timeline is sourced from ``application_chat_messages``. Without writing
#     an explicit message event, uploads disappear from session history reloads.
#     """
#     try:
#         content = _format_upload_event_text(
#             filename=upload.filename,
#             status=upload.processing_status,
#             size_bytes=upload.size_bytes,
#         )
#         await _chat_repo.add_message(
#             db,
#             session_id,
#             "user",
#             content,
#             execution_trace={
#                 "type": "file_upload_event",
#                 "file_upload": {
#                     "document_id": upload.document_id,
#                     "session_id": upload.session_id,
#                     "filename": upload.filename,
#                     "processing_status": upload.processing_status,
#                     "mime_type": upload.mime_type,
#                     "size_bytes": upload.size_bytes,
#                     "chunk_count": upload.chunk_count,
#                 },
#             },
#             user_id=user_id,
#             application_id=application_id,
#         )
#     except Exception:
#         logger.exception(
#             "Failed to persist upload history event: app=%s session=%s file=%s",
#             application_id,
#             session_id,
#             upload.filename,
#         )


# # -------------------------------------------------------------------
# # Shared helper: save, index, and record a single uploaded file
# # -------------------------------------------------------------------
# async def _process_single_upload(
#     db: AsyncSession,
#     application_id: str,
#     session_id: str,
#     file: UploadFile,
#     rag_manager,
#     user_id: Optional[str] = None,
# ) -> DocumentUploadResponse:
#     """
#     Save one uploaded file to disk, create the DB record, chunk + embed
#     into the session-scoped FAISS index, and return a response model.

#     This is the canonical single-file processing logic.  Both the
#     existing ``/chat/upload`` endpoint (single file, backward-compatible)
#     and the new ``/chat/upload-batch`` endpoint (multiple files) delegate
#     here so there is exactly ONE code path for file ingestion.

#     CRITICAL STATE MANAGEMENT: The document is marked 'ready' only after
#     PostgreSQL successfully commits the stored chunks. If storage fails
#     (e.g., timeout, connection loss), the document status is 'failed' and
#     the HTTP response reflects that, rather than returning 201 Created
#     for an unusable document.

#     Args:
#         db: Active async DB session (caller manages commit/rollback).
#         application_id: Application UUID string.
#         session_id: Chat session UUID string (must already exist).
#         file: Validated UploadFile (caller must call validate_upload first).
#         rag_manager: SessionRAGManager instance, or None if unavailable.
#         user_id: The uploading user. Required for OCR and embeddings: every
#             model on this platform is a user's own credential, so without it
#             the vision client and the embeddings client both resolve to
#             nothing, the OCR pass is skipped, and no passage can be embedded.

#     Returns:
#         DocumentUploadResponse with processing results and session_id.

#     A document is 'ready' when its text could be read. Indexing is reported
#     separately through ``chunk_count``: conversion needs no model and embedding
#     needs a resolvable credential, so a file that converted perfectly used to be
#     recorded as 'failed' the moment embeddings were unavailable -- and the
#     extracted text was discarded with it. 'failed' now means the file could not
#     be read at all.
#     """
#     from apps.appmgr import document_store

#     original_filename = file.filename or "unnamed"
#     stored_filename = f"{application_id}_{uuid.uuid4().hex}_{original_filename}"
#     file_path = document_store.local_path(stored_filename)

#     # Create DB record first (DB-first pattern: no orphaned files on DB failure).
#     # size_bytes is set to 0 initially and updated after streaming completes.
#     doc = await _chat_repo.create_document(
#         db,
#         application_id=application_id,
#         chat_session_id=session_id,
#         original_filename=original_filename,
#         stored_filename=stored_filename,
#         mime_type=file.content_type,
#         size_bytes=0,
#     )
#     doc_id = str(doc.document_id)

#     # Read in 1MB chunks. The size ceiling is already enforced by
#     # ``validate_upload`` before this runs, so the payload is bounded.
#     size_bytes = 0
#     try:
#         buffer = bytearray()
#         while chunk := await file.read(1024 * 1024):
#             buffer.extend(chunk)
#             size_bytes += len(chunk)
#         payload = bytes(buffer)
#     except Exception:
#         logger.exception("Failed to read uploaded file: %s", original_filename)
#         await _chat_repo.update_document_status(db, doc_id, "failed")
#         return DocumentUploadResponse(
#             document_id=doc_id,
#             session_id=session_id,
#             filename=original_filename,
#             processing_status="failed",
#             mime_type=file.content_type,
#             size_bytes=0,
#             chunk_count=0,
#         )

#     # Postgres is the record. This is what makes an uploaded document survive a
#     # restart, a redeploy, or a request landing on a different replica —
#     # previously the bytes existed only under APP_UPLOADS_DIR and were lost
#     # with the container, while this row went on claiming the document existed.
#     if document_store.KEEP_ORIGINALS:
#         await _chat_repo.update_document_content(db, doc_id, payload)

#     # The local copy is a cache of that record, for the tools that still take a
#     # path (tabular analysis, image analysis). Failing to write it is not fatal:
#     # ``document_store.materialize`` writes it back from Postgres on demand.
#     document_store.write_local_copy(stored_filename, payload)

#     # Mark as "processing" and update actual file size
#     await _chat_repo.update_document_status(
#         db, doc_id, "processing", size_bytes=size_bytes
#     )

#     # Commit the document row before indexing begins.
#     #
#     # Passage storage runs on its own connection: ``session_documents._store``
#     # bridges to a thread and opens a fresh ``get_db_session()``, because an
#     # AsyncSession cannot be shared across threads. That connection is a
#     # separate transaction, so under READ COMMITTED it cannot see a row this
#     # one has not committed -- and every chunk insert fails the foreign key on
#     # ``application_document_chunks.document_id``, leaving a document with no
#     # searchable content.
#     #
#     # Committing here is consistent with the DB-first intent above: the row is
#     # meant to outlive a failure, and the RAG branch below already records
#     # failure by setting the status rather than by rolling the row back.
#     await db.commit()

#     # Image files (PNG, JPG, etc.) are consumed directly from disk by tools
#     # like document_analysis and file_reader. They cannot be chunked/embedded
#     # into a FAISS index — skip RAG processing and mark ready immediately.
#     _IMAGE_MIME_PREFIXES = ("image/",)
#     is_image = (file.content_type or "").startswith(_IMAGE_MIME_PREFIXES)

#     # Process RAG indexing SYNCHRONOUSLY so documents are ready for
#     # retrieval when the user sends the next message (no race condition).
#     # CRITICAL: Only mark 'ready' after chunks are successfully stored.
#     chunk_count = 0
#     if is_image:
#         # Images don't need text chunking — the file on disk is the source.
#         await _chat_repo.update_document_status(
#             db, doc_id, "ready", chunk_count=0, size_bytes=size_bytes,
#         )
#     elif rag_manager is not None:
#         try:
#             rag_result = await rag_manager.process_document(
#                 session_id=session_id,
#                 file_path=file_path,
#                 filename=original_filename,
#                 data=payload,
#                 application_id=application_id,
#                 document_id=doc_id,
#                 mime_type=file.content_type,
#                 user_id=user_id,
#             )
#             chunk_count = rag_result.get("chunk_count", 0)
#             content_md = rag_result.get("content_md") or ""

#             # The converted text is stored before anything is judged, so a
#             # document that was read but could not be indexed stays readable
#             # instead of being discarded. This is what makes 'ready' mean
#             # "we can read this" rather than "we happened to have an
#             # embedding model at the moment you uploaded it".
#             if content_md:
#                 await _chat_repo.update_document_markdown(
#                     db,
#                     doc_id,
#                     content_md=content_md,
#                     char_count=rag_result.get("char_count"),
#                     converted_by=rag_result.get("converted_by"),
#                     ocr_skipped_reason=rag_result.get("ocr_skipped_reason"),
#                 )

#             if not content_md:
#                 # Nothing readable came out. This is the real failure: an
#                 # empty, corrupt or password-protected file, or a scan with no
#                 # vision model available to transcribe it.
#                 reason = rag_result.get("error") or "No text could be read from this file."
#                 logger.error(
#                     "Nothing could be extracted: doc=%s file=%s -- %s",
#                     doc_id, original_filename, reason,
#                 )
#                 await _chat_repo.update_document_status(db, doc_id, "failed")
#                 return DocumentUploadResponse(
#                     document_id=doc_id,
#                     session_id=session_id,
#                     filename=original_filename,
#                     processing_status="failed",
#                     mime_type=file.content_type,
#                     size_bytes=size_bytes,
#                     chunk_count=0,
#                 )

#             if chunk_count == 0:
#                 # Readable but not searchable. Named explicitly, because the
#                 # cause is almost always a missing or misconfigured embedding
#                 # credential and that is actionable -- unlike the silent
#                 # "failed" this used to produce.
#                 logger.warning(
#                     "Document read but not indexed: doc=%s file=%s (%d chars). "
#                     "No embedding model resolved for user %s, so it can be read "
#                     "whole but not searched.",
#                     doc_id, original_filename, len(content_md), user_id or "<none>",
#                 )

#             await _chat_repo.update_document_status(
#                 db, doc_id, "ready", chunk_count=chunk_count, size_bytes=size_bytes,
#             )
#         except Exception as exc:
#             logger.exception(
#                 "RAG processing failed for doc=%s file=%s: %s",
#                 doc_id, original_filename, exc,
#             )
#             await _chat_repo.update_document_status(db, doc_id, "failed")
#             return DocumentUploadResponse(
#                 document_id=doc_id,
#                 session_id=session_id,
#                 filename=original_filename,
#                 processing_status="failed",
#                 mime_type=file.content_type,
#                 size_bytes=size_bytes,
#                 chunk_count=0,
#             )
#     else:
#         # No RAG manager — mark ready immediately (file saved, just not indexed)
#         await _chat_repo.update_document_status(db, doc_id, "ready", size_bytes=size_bytes)

#     return DocumentUploadResponse(
#         document_id=doc_id,
#         session_id=session_id,
#         filename=original_filename,
#         processing_status="ready",
#         mime_type=file.content_type,
#         size_bytes=size_bytes,
#         chunk_count=chunk_count,
#     )


# async def _background_rag_process(
#     doc_id: str,
#     session_id: str,
#     file_path: str,
#     filename: str,
#     rag_manager,
# ) -> None:
#     """
#     Background task: run RAG processing and update document status in DB.

#     WHY: Runs as an asyncio background task so the upload HTTP response
#     returns immediately. Opens its own DB session (cannot reuse the request
#     session which is closed when the endpoint returns).

#     Args:
#         doc_id: Document UUID string to update in DB.
#         session_id: Chat session UUID string.
#         file_path: Absolute path to the file on disk.
#         filename: Original filename for metadata.
#         rag_manager: Initialized SessionRAGManager instance.
#     """
#     from echolib.database import get_db_session as _get_db

#     try:
#         result = await rag_manager.process_document(
#             session_id=session_id,
#             file_path=file_path,
#             filename=filename,
#         )
#         chunk_count = result.get("chunk_count", 0)
#         async with _get_db() as db:
#             await _chat_repo.update_document_status(
#                 db, doc_id, "ready", chunk_count=chunk_count
#             )
#         logger.info(
#             "Background RAG processing complete: doc=%s, chunks=%d",
#             doc_id, chunk_count,
#         )
#     except Exception as exc:
#         logger.exception(
#             "Background RAG processing failed for doc=%s file=%s: %s",
#             doc_id, filename, exc,
#         )
#         try:
#             from echolib.database import get_db_session as _get_db2
#             async with _get_db2() as db:
#                 await _chat_repo.update_document_status(db, doc_id, "failed")
#         except Exception:
#             logger.exception(
#                 "Failed to update document status to 'failed' for doc=%s", doc_id
#             )


# # Query-string spellings of "no session" that clients send before the first
# # message exists. A real chat session id is always a UUID, so none of these
# # can ever name one.
# _EMPTY_SESSION_ID_SENTINELS = frozenset({"", "null", "undefined", "none"})


# def _normalize_optional_session_id(session_id: Optional[str]) -> Optional[str]:
#     """
#     Map a placeholder session id to ``None``.

#     WHY: a client with no session yet (file uploaded before the first message)
#     can serialize its empty value as ``session_id=null``. That arrives here as
#     the text ``"null"``, fails UUID validation, and the upload is rejected --
#     even though a missing session is exactly the case that auto-creates one.
#     """
#     if session_id is None:
#         return None
#     stripped = session_id.strip()
#     if stripped.lower() in _EMPTY_SESSION_ID_SENTINELS:
#         return None
#     return stripped


# async def _ensure_upload_session(
#     db: AsyncSession,
#     application_id: str,
#     session_id: Optional[str],
#     user_id: str,
#     user_role: str = "user",
# ):
#     """
#     Validate or create a chat session for document upload.

#     Returns (session, session_id) tuple.  Raises HTTPException on
#     invalid input.
#     """
#     session_id = _normalize_optional_session_id(session_id)

#     if session_id is not None:
#         try:
#             uuid.UUID(session_id)
#         except (ValueError, TypeError):
#             raise HTTPException(
#                 400,
#                 f"Invalid session_id format: '{session_id}' is not a valid UUID.",
#             )

#     app = await _app_repo.get_accessible_application(db, application_id, user_id, user_role)
#     if app is None:
#         raise HTTPException(404, "Application not found")
#     if not app.upload_enabled:
#         raise HTTPException(400, "Document upload is not enabled for this application.")

#     if session_id:
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application.")
#     else:
#         session = await _chat_repo.create_session(
#             db, application_id, user_id,
#             title="Document Upload Session",
#         )
#         session_id = str(session.chat_session_id)

#     return app, session, session_id


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/chat/upload -- Single-file Upload
# # (Backward-compatible: keeps form field name "file", same response shape + session_id)
# # -------------------------------------------------------------------
# @router.post(
#     "/{application_id}/chat/upload",
#     status_code=201,
# )
# async def upload_chat_document(
#     application_id: str,
#     file: List[UploadFile] = File(...),
#     session_id: Optional[str] = Query(
#         None, description="Optional chat session UUID to bind the document to."
#     ),
#     user_input: Optional[str] = Query(
#         None, description="Optional user query for RAG processing (used during file_upload interrupt)."
#     ),
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Upload one or more documents for RAG processing within an application.

#     WHY changed from single to List[UploadFile]: aligns the /chat/upload endpoint
#     with the withoutKV codebase pattern and allows multi-file upload from the
#     same form field name "file", preserving backward compatibility.

#     The application must have ``upload_enabled == True``. Each file is
#     saved to disk, an ``ApplicationDocument`` record is created, and the
#     document is chunked, embedded, and indexed into a session-scoped FAISS
#     index for retrieval at query time.

#     When the session is in a ``file_upload`` interrupt state (from a Start node
#     with file upload config) AND exactly one file is sent, the document is
#     ingested through the shared upload path and the workflow is automatically
#     resumed with the document's own text.

#     The response always includes ``session_id`` so the frontend can reuse it for
#     subsequent uploads or chat messages. If ``session_id`` is omitted, a new
#     session is auto-created.

#     Individual file failures are recorded per-document
#     (``processing_status == "failed"``) without aborting remaining files.
#     """
#     MAX_FILES_PER_UPLOAD = 20
#     if len(file) > MAX_FILES_PER_UPLOAD:
#         raise HTTPException(
#             status_code=400,
#             detail=f"Maximum {MAX_FILES_PER_UPLOAD} files per upload request.",
#         )
#     if not file:
#         raise HTTPException(status_code=400, detail="No files provided.")

#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         app, session, session_id = await _ensure_upload_session(
#             db, application_id, session_id, user_id, user.role,
#         )

#         # ------------------------------------------------------------------
#         # Detect file_upload interrupt state
#         # ------------------------------------------------------------------
#         context_data = session.context_data or {}
#         hitl_state = context_data.get("hitl_state")
#         is_file_upload_interrupt = (
#             session.conversation_state == "awaiting_clarification"
#             and hitl_state
#             and hitl_state.get("interrupt_type") == "file_upload"
#         )

#         # ------------------------------------------------------------------
#         # HITL interrupt path: single-file upload into a file_upload
#         # interrupt state is ingested normally, then resumes the workflow.
#         # ------------------------------------------------------------------
#         if is_file_upload_interrupt and len(file) == 1:
#             single_file = file[0]

#             await validate_upload(
#                 single_file,
#                 allowed_extensions=[".pdf", ".docx", ".txt", ".csv", ".md"],
#                 max_size_bytes=50 * 1024 * 1024,
#             )

#             # The same ingestion every other upload gets.
#             #
#             # This branch used to run ``TraditionalRAGService``: PyMuPDF page
#             # extraction, a hardcoded ``gpt-4o-mini`` / ``text-embedding-ada-002``
#             # pair, and platform Azure secrets that a bring-your-own-LLM
#             # deployment does not set. It was a fourth document path with no
#             # OCR, and it wrote nothing to ``application_document_chunks`` -- so
#             # the file the workflow had just asked for was unfindable the moment
#             # the interrupt resumed. Routing it through the one path means a
#             # document uploaded into an interrupt is exactly as readable as one
#             # uploaded into ordinary chat.
#             from echolib.di import container as di_container

#             try:
#                 rag_manager = di_container.resolve("rag.session_manager")
#             except KeyError:
#                 rag_manager = None
#                 logger.warning(
#                     "rag.session_manager not registered; the interrupt document "
#                     "will be stored but not indexed"
#                 )

#             upload = await _process_single_upload(
#                 db, application_id, session_id, single_file, rag_manager, user_id,
#             )
#             doc_id = upload.document_id
#             original_filename = upload.filename
#             chunk_count = upload.chunk_count
#             processing_status = upload.processing_status

#             await _record_upload_history_event(
#                 db,
#                 application_id=application_id,
#                 session_id=session_id,
#                 user_id=user_id,
#                 upload=upload,
#             )

#             # The evidence changed. Without this the cached ledger keeps
#             # reporting "no documents" and the resumed workflow can ask for the
#             # file the user just handed it.
#             from apps.appmgr.context import invalidate_session

#             invalidate_session(application_id, session_id)

#             # What the resuming node receives is now the document itself rather
#             # than an answer generated about it. A node that wanted a summary
#             # can produce one from the text; a node that wanted the text could
#             # never have recovered it from a summary.
#             document_context = ""
#             stored = await _chat_repo.get_document_markdown(db, doc_id)
#             if stored and stored.get("content_md"):
#                 budget = _hitl_document_context_chars()
#                 body = stored["content_md"]
#                 document_context = (
#                     body
#                     if len(body) <= budget
#                     else body[:budget] + "\n\n... [truncated; search the document for the rest]"
#                 )

#             hitl_result = await _resume_workflow_and_finalize(
#                 db, session_id, app, hitl_state,
#                 action="upload_file",
#                 resume_payload={
#                     "document_context": document_context,
#                     "document_metadata": {
#                         "filename": original_filename,
#                         "size": upload.size_bytes or 0,
#                         "chunk_count": chunk_count,
#                         "document_id": doc_id,
#                     },
#                 },
#                 user_id=user_id,
#             )

#             return FileUploadResumeResponse(
#                 document_id=doc_id,
#                 filename=original_filename,
#                 processing_status=processing_status,
#                 chunk_count=chunk_count,
#                 workflow_status=hitl_result.status,
#                 workflow_output=hitl_result.message if hitl_result.status == "completed" else None,
#                 conversation_state=hitl_result.conversation_state,
#             )

#         # ------------------------------------------------------------------
#         # Normal upload path (1 or N files): session-scoped RAG index
#         # ------------------------------------------------------------------
#         from echolib.di import container as di_container

#         try:
#             rag_manager = di_container.resolve('rag.session_manager')
#         except KeyError:
#             rag_manager = None
#             logger.warning(
#                 "rag.session_manager not registered; files will be saved but not indexed"
#             )

#         doc_responses: List[DocumentUploadResponse] = []
#         total_chunks = 0

#         for f in file:
#             # Per-file isolation: one file failing must NOT abort remaining files
#             try:
#                 await validate_upload(
#                     f,
#                     allowed_extensions=[
#                         ".pdf", ".docx", ".xlsx", ".xls", ".csv",
#                         ".txt", ".md", ".pptx", ".png", ".jpg",
#                     ],
#                     max_size_bytes=50 * 1024 * 1024,
#                 )
#                 resp = await _process_single_upload(
#                     db, application_id, session_id, f, rag_manager, user_id,
#                 )
#             except Exception as exc:
#                 logger.exception(
#                     "Failed to process uploaded file '%s': %s",
#                     f.filename, exc,
#                 )
#                 resp = DocumentUploadResponse(
#                     document_id=str(uuid.uuid4()),
#                     session_id=session_id,
#                     filename=f.filename or "unknown",
#                     processing_status="failed",
#                     mime_type=f.content_type,
#                     size_bytes=0,
#                     chunk_count=0,
#                 )

#             doc_responses.append(resp)
#             total_chunks += resp.chunk_count

#             await _record_upload_history_event(
#                 db,
#                 application_id=application_id,
#                 session_id=session_id,
#                 user_id=user_id,
#                 upload=resp,
#             )

#         # The session's evidence changed. Without this the cached ledger would
#         # keep reporting "no documents" and the application could ask the user
#         # for a file they just uploaded.
#         from apps.appmgr.context import invalidate_session

#         invalidate_session(application_id, session_id)

#         return UploadResponse(
#             session_id=session_id,
#             documents=doc_responses,
#             total_chunk_count=total_chunks,
#         )


# # -------------------------------------------------------------------
# # POST /api/applications/{application_id}/chat/upload-batch -- Multi-file Upload
# # -------------------------------------------------------------------
# @router.post(
#     "/{application_id}/chat/upload-batch",
#     status_code=201,
#     response_model=BatchDocumentUploadResponse,
# )
# async def upload_chat_documents_batch(
#     application_id: str,
#     files: List[UploadFile] = File(..., description="One or more files to upload and index."),
#     session_id: Optional[str] = Query(
#         None, description="Optional chat session UUID to bind the documents to."
#     ),
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Upload multiple documents for RAG processing within an application.

#     All files are saved, chunked, embedded, and indexed into the **same**
#     session-scoped FAISS index so that subsequent chat queries retrieve
#     context from every uploaded file.

#     The response always includes ``session_id``.  Pass this value back
#     to ``/chat`` or subsequent upload calls to keep all files in the
#     same retrieval context.

#     Individual file failures are recorded per-document (``processing_status
#     == "failed"``) without aborting the remaining files.
#     """
#     user_id = resolve_user_id(user)

#     if not files:
#         raise HTTPException(400, "At least one file is required.")

#     async with get_db_session() as db:
#         _app, _session, session_id = await _ensure_upload_session(
#             db, application_id, session_id, user_id, user.role,
#         )

#         from echolib.di import container as di_container

#         try:
#             rag_manager = di_container.resolve('rag.session_manager')
#         except KeyError:
#             rag_manager = None
#             logger.warning("rag.session_manager not registered; files will be saved but not indexed")

#         doc_responses: List[DocumentUploadResponse] = []
#         total_chunk_count = 0

#         for file in files:
#             # Per-file isolation: one file failing must NOT abort remaining files
#             try:
#                 await validate_upload(
#                     file,
#                     allowed_extensions=[
#                         ".pdf", ".docx", ".xlsx", ".xls", ".csv",
#                         ".txt", ".md", ".pptx", ".png", ".jpg",
#                     ],
#                     max_size_bytes=50 * 1024 * 1024,
#                 )
#                 resp = await _process_single_upload(
#                     db, application_id, session_id, file, rag_manager, user_id,
#                 )
#             except Exception as exc:
#                 logger.exception(
#                     "Failed to process uploaded file '%s': %s",
#                     file.filename, exc,
#                 )
#                 resp = DocumentUploadResponse(
#                     document_id=str(uuid.uuid4()),
#                     session_id=session_id,
#                     filename=file.filename or "unknown",
#                     processing_status="failed",
#                     mime_type=file.content_type,
#                     size_bytes=0,
#                     chunk_count=0,
#                 )

#             doc_responses.append(resp)
#             total_chunk_count += resp.chunk_count

#             await _record_upload_history_event(
#                 db,
#                 application_id=application_id,
#                 session_id=session_id,
#                 user_id=user_id,
#                 upload=resp,
#             )

#         # Same reason as the single-file path: the ledger must see the upload
#         # on the very next message, not when its TTL happens to expire.
#         from apps.appmgr.context import invalidate_session

#         invalidate_session(application_id, session_id)

#         return BatchDocumentUploadResponse(
#             session_id=session_id,
#             documents=doc_responses,
#             total_chunk_count=total_chunk_count,
#         )


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/chat/sessions/{session_id}/documents
# # Returns all documents in a session with their current processing status.
# # Frontend polls this until all documents reach status="ready".
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/chat/sessions/{session_id}/documents",
#     response_model=None,
# )
# async def get_session_documents(
#     application_id: str,
#     session_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Return all documents in a session with their current processing status.

#     WHY: Background processing (Task 2.2) means files are no longer immediately
#     ready on upload. The frontend polls this endpoint until all documents show
#     status="ready". Provides a consistent view of per-file processing progress.

#     Args:
#         application_id: Application UUID string (path param).
#         session_id: Chat session UUID string (path param).

#     Returns:
#         Dict with session_id, documents list, and all_ready bool.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         # Verify session ownership and application membership
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(404, "Chat session not found for this application.")

#         docs = await _chat_repo.get_session_documents(db, session_id)

#     return {
#         "session_id": session_id,
#         "documents": [
#             {
#                 "document_id": str(doc.document_id),
#                 "original_filename": doc.original_filename,
#                 "processing_status": doc.processing_status,
#                 "chunk_count": doc.chunk_count,
#                 "size_bytes": doc.size_bytes,
#                 "mime_type": doc.mime_type,
#             }
#             for doc in docs
#         ],
#         "all_ready": all(d.processing_status == "ready" for d in docs),
#     }


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/chat/sessions/{session_id}/generated-files
# #     List generated files for a session
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/chat/sessions/{session_id}/generated-files",
#     response_model=None,
# )
# async def list_generated_files(
#     application_id: str,
#     session_id: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     List all generated files (PPT, Excel, charts) for a chat session.

#     WHY: The frontend downloads panel calls this endpoint to render a list
#     of downloadable files produced by agent tools during the session.

#     Args:
#         application_id: Application UUID string (path param).
#         session_id: Chat session UUID string (path param).

#     Returns:
#         Dict with session_id and list of file metadata dicts including
#         download URLs.
#     """
#     user_id = resolve_user_id(user)

#     async with get_db_session() as db:
#         session = await _chat_repo.get_session(db, session_id, user_id, application_id)
#         if session is None:
#             raise HTTPException(status_code=404, detail="Chat session not found.")

#         files = await _gen_file_repo.list_by_session(db, session_id)

#     now = datetime.now(timezone.utc)
#     available_files = []
#     for file_record in files:
#         if file_record.expires_at and file_record.expires_at < now:
#             continue
#         is_valid_path, _reason, _normalized_path, _size_bytes = validate_generated_file_path(
#             file_record.file_path,
#             require_exists=True,
#             require_non_empty=False,
#         )
#         if not is_valid_path:
#             continue
#         available_files.append(file_record)

#     base_url = f"/api/applications/{application_id}/generated-files"
#     return {
#         "session_id": session_id,
#         "files": [
#             {
#                 "generated_file_id": str(f.generated_file_id),
#                 "original_filename": f.original_filename,
#                 "mime_type": f.mime_type,
#                 "size_bytes": f.size_bytes,
#                 "download_url": f"{base_url}/{f.download_key}",
#                 "expires_at": f.expires_at.isoformat() if f.expires_at else None,
#                 "created_at": f.created_at.isoformat() if f.created_at else None,
#             }
#             for f in available_files
#         ],
#     }


# # -------------------------------------------------------------------
# # GET /api/applications/{application_id}/generated-files/{download_key}
# #     Download a generated file by its URL-safe key
# # -------------------------------------------------------------------
# @router.get(
#     "/{application_id}/generated-files/{download_key}",
# )
# async def download_generated_file(
#     application_id: str,
#     download_key: str,
#     user: UserContext = Depends(require_user),
# ):
#     """
#     Stream a generated file (PPT, Excel, chart) to the client.

#     WHY: Agent tools write files to disk and embed a [GENERATED_FILE:...]
#     marker in their output. skill_executor registers each file in the DB
#     with a URL-safe download_key. The frontend constructs the download URL
#     from the key and calls this endpoint to trigger the file download.

#     Security: Caller must be authenticated and have access to the target
#     application. The download_key is then resolved within that access scope.

#     Args:
#         application_id: Application UUID string (path param, for validation).
#         download_key: 32-char hex token from the GeneratedFile record.

#     Returns:
#         FileResponse with Content-Disposition: attachment.

#     Raises:
#         404: If the key is not found, expired, or deleted.
#         410: If the file no longer exists on disk.
#     """
#     user_id = resolve_user_id(user)

#     logger.info(
#         "generated_file_download_attempt",
#         extra={
#             "application_id": application_id,
#             "download_key": download_key,
#             "user_id": user_id,
#         },
#     )

#     owner_app_id: Optional[str] = None
#     async with get_db_session() as db:
#         app = await _app_repo.get_accessible_application(
#             db,
#             application_id,
#             user_id,
#             user.role,
#         )
#         if app is None:
#             logger.warning(
#                 "generated_file_download_denied_application_access",
#                 extra={
#                     "application_id": application_id,
#                     "download_key": download_key,
#                     "user_id": user_id,
#                 },
#             )
#             raise HTTPException(status_code=404, detail="Generated file not found.")

#         record = await _gen_file_repo.get_by_download_key(db, download_key)

#         if record and record.application_id is None and record.chat_session_id is not None:
#             session_owner = await _chat_repo.get_session(
#                 db,
#                 str(record.chat_session_id),
#                 user_id,
#             )
#             owner_app_id = (
#                 str(session_owner.application_id)
#                 if session_owner and getattr(session_owner, "application_id", None)
#                 else None
#             )

#     if record is None:
#         logger.warning(
#             "generated_file_download_missing_record",
#             extra={
#                 "application_id": application_id,
#                 "download_key": download_key,
#                 "user_id": user_id,
#             },
#         )
#         raise HTTPException(status_code=404, detail="Generated file not found.")

#     record_app_id = str(record.application_id) if record.application_id else None
#     if record_app_id != application_id:
#         # Backward-compatible ownership resolution for legacy rows where
#         # application_id is NULL but chat_session_id is set correctly.
#         if record.application_id is None and record.chat_session_id is not None:
#             if owner_app_id == application_id:
#                 logger.info(
#                     "generated_file_download_owner_resolved_via_session",
#                     extra={
#                         "application_id": application_id,
#                         "download_key": download_key,
#                         "chat_session_id": str(record.chat_session_id),
#                         "user_id": user_id,
#                     },
#                 )
#             else:
#                 logger.warning(
#                     "generated_file_download_application_mismatch",
#                     extra={
#                         "application_id": application_id,
#                         "download_key": download_key,
#                         "record_application_id": record_app_id,
#                         "record_chat_session_id": str(record.chat_session_id),
#                         "resolved_session_application_id": owner_app_id,
#                         "user_id": user_id,
#                     },
#                 )
#                 raise HTTPException(status_code=404, detail="Generated file not found.")
#         else:
#             logger.warning(
#                 "generated_file_download_application_mismatch",
#                 extra={
#                     "application_id": application_id,
#                     "download_key": download_key,
#                     "record_application_id": record_app_id,
#                     "user_id": user_id,
#                 },
#             )
#             raise HTTPException(status_code=404, detail="Generated file not found.")

#     if record.expires_at and record.expires_at < datetime.now(timezone.utc):
#         logger.info(
#             "generated_file_download_expired",
#             extra={
#                 "application_id": application_id,
#                 "download_key": download_key,
#                 "user_id": user_id,
#             },
#         )
#         raise HTTPException(
#             status_code=410,
#             detail="This file has expired and is no longer available.",
#         )

#     logger.info(
#         f"DOWNLOAD_HOST={socket.gethostname()}"
#     )

#     logger.info(
#         f"DOWNLOAD_DB_PATH={record.file_path}"
#     )

#     logger.info(
#         f"DOWNLOAD_DB_PATH_EXISTS={os.path.exists(record.file_path)}"
#     )

#     is_valid_path, path_reason, normalized_path, _size_bytes = validate_generated_file_path(
#         record.file_path,
#         require_exists=True,
#         require_non_empty=False,
#     )
#     if not is_valid_path:
#         logger.error(
#             f"VALIDATION_REASON={path_reason}"
#         )

#         logger.error(
#             f"NORMALIZED_PATH={normalized_path}"
#         )

#         logger.error(
#             f"NORMALIZED_PATH_EXISTS={os.path.exists(normalized_path) if normalized_path else False}"
#         )
#         logger.warning(
#             "generated_file_download_missing_disk_file",
#             extra={
#                 "application_id": application_id,
#                 "download_key": download_key,
#                 "file_path": record.file_path,
#                 "resolved_file_path": normalized_path,
#                 "validation_reason": path_reason,
#                 "file_path_is_absolute": os.path.isabs(record.file_path),
#                 "cwd": os.getcwd(),
#                 "app_uploads_dir": os.getenv("APP_UPLOADS_DIR"),
#                 "record_expires_at": record.expires_at.isoformat() if record.expires_at else None,
#                 "user_id": user_id,
#             },
#         )
#         raise HTTPException(
#             status_code=410,
#             detail="The generated file is no longer available on disk.",
#         )

#     logger.info(
#         "generated_file_download_success",
#         extra={
#             "application_id": application_id,
#             "download_key": download_key,
#             "file_path": record.file_path,
#             "user_id": user_id,
#         },
#     )

#     media_type = record.mime_type or "application/octet-stream"
#     return FileResponse(
#         path=normalized_path,
#         media_type=media_type,
#         filename=record.original_filename,
#     )


# # ===================================================================
# # Lookup / Catalog Router
# # ===================================================================

# lookup_router = APIRouter(tags=["Application Lookups"])


# @lookup_router.get("/api/llms", response_model=List[LookupResponse])
# async def list_llms(user: UserContext = Depends(require_user)):
#     """List all available LLMs for the application wizard."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppLlm).order_by(AppLlm.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=str(row.llm_id), name=row.name)
#             for row in rows
#         ]


# @lookup_router.get("/api/data-sources", response_model=List[LookupResponse])
# async def list_data_sources(user: UserContext = Depends(require_user)):
#     """List all available data sources."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppDataSource).order_by(AppDataSource.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=row.data_source_id, name=row.name)
#             for row in rows
#         ]


# @lookup_router.get("/api/designations", response_model=List[LookupResponse])
# async def list_designations(user: UserContext = Depends(require_user)):
#     """List all available designations."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppDesignation).order_by(AppDesignation.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=str(row.designation_id), name=row.name)
#             for row in rows
#         ]


# @lookup_router.get("/api/business-units", response_model=List[LookupResponse])
# async def list_business_units(user: UserContext = Depends(require_user)):
#     """List all available business units."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppBusinessUnit).order_by(AppBusinessUnit.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=str(row.business_unit_id), name=row.name)
#             for row in rows
#         ]


# @lookup_router.get("/api/tags", response_model=List[LookupResponse])
# async def list_tags(user: UserContext = Depends(require_user)):
#     """List all available tags."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppTag).order_by(AppTag.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=str(row.tag_id), name=row.name)
#             for row in rows
#         ]


# @lookup_router.get("/api/personas", response_model=List[LookupResponse])
# async def list_personas(user: UserContext = Depends(require_user)):
#     """List all available personas."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppPersona).order_by(AppPersona.name.asc())
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(id=str(row.persona_id), name=row.name)
#             for row in rows
#         ]


# @lookup_router.get(
#     "/api/guardrail-categories", response_model=List[LookupResponse]
# )
# async def list_guardrail_categories(user: UserContext = Depends(require_user)):
#     """List all available guardrail categories."""
#     async with get_db_session() as db:
#         result = await db.execute(
#             select(AppGuardrailCategory).order_by(
#                 AppGuardrailCategory.name.asc()
#             )
#         )
#         rows = result.scalars().all()
#         return [
#             LookupResponse(
#                 id=str(row.guardrail_category_id), name=row.name
#             )
#             for row in rows
#         ]


# # -------------------------------------------------------------------
# # POST /api/llms/seed -- Seed default LLMs if table is empty
# # -------------------------------------------------------------------
# @lookup_router.post("/api/llms/seed", response_model=List[LookupResponse])
# async def seed_llms(user: UserContext = Depends(require_user)):
#     """Seed the app_llms table with default LLMs if empty."""
#     async with get_db_session() as db:
#         existing = await db.execute(select(func.count()).select_from(AppLlm))
#         count = existing.scalar() or 0
#         if count > 0:
#             result = await db.execute(select(AppLlm).order_by(AppLlm.name.asc()))
#             rows = result.scalars().all()
#             return [LookupResponse(id=str(row.llm_id), name=row.name) for row in rows]

#         defaults = [
#             AppLlm(name="GPT-4o", provider="openai", model_name="gpt-4o", base_url="https://api.openai.com/v1", api_key_env="OPENAI_API_KEY", is_default=False),
#             AppLlm(name="GPT-4o Mini", provider="openai", model_name="gpt-4o-mini", base_url="https://api.openai.com/v1", api_key_env="OPENAI_API_KEY", is_default=False),
#             AppLlm(name="Claude Sonnet", provider="anthropic", model_name="claude-sonnet-4-20250514", base_url="https://api.anthropic.com", api_key_env="ANTHROPIC_API_KEY", is_default=False),
#             AppLlm(name="Azure GPT-4o Mini", provider="azure", model_name="gpt-4o-mini", base_url="", api_key_env="AZURE_OPENAI_API_KEY", is_default=True),
#             AppLlm(name="Ollama Local", provider="ollama", model_name="llama3", base_url="http://localhost:11434/v1", api_key_env=None, is_default=False),
#         ]
#         db.add_all(defaults)
#         await db.flush()

#         result = await db.execute(select(AppLlm).order_by(AppLlm.name.asc()))
#         rows = result.scalars().all()
#         return [LookupResponse(id=str(row.llm_id), name=row.name) for row in rows]


# # -------------------------------------------------------------------
# # POST /api/data-sources/seed -- Seed default data sources if empty
# # -------------------------------------------------------------------
# @lookup_router.post("/api/data-sources/seed", response_model=List[LookupResponse])
# async def seed_data_sources(user: UserContext = Depends(require_user)):
#     """Seed the app_data_sources table with defaults if empty."""
#     async with get_db_session() as db:
#         existing = await db.execute(select(func.count()).select_from(AppDataSource))
#         count = existing.scalar() or 0
#         if count > 0:
#             result = await db.execute(select(AppDataSource).order_by(AppDataSource.name.asc()))
#             rows = result.scalars().all()
#             return [LookupResponse(id=row.data_source_id, name=row.name) for row in rows]

#         defaults = [
#             AppDataSource(data_source_id="mcp_filesystem", name="Local Filesystem", kind="mcp", source_metadata={"description": "Access local files"}),
#             AppDataSource(data_source_id="mcp_web_search", name="Web Search", kind="mcp", source_metadata={"description": "Search the web"}),
#             AppDataSource(data_source_id="api_rest", name="REST API", kind="api", source_metadata={"description": "Connect to REST APIs"}),
#         ]
#         db.add_all(defaults)
#         await db.flush()

#         result = await db.execute(select(AppDataSource).order_by(AppDataSource.name.asc()))
#         rows = result.scalars().all()
#         return [LookupResponse(id=row.data_source_id, name=row.name) for row in rows]


# # ===================================================================
# # Skills Router
# # ===================================================================

# skills_router = APIRouter(tags=["Application Skills"])


# @skills_router.get("/api/skills", response_model=List[SkillResponse])
# async def list_skills(
#     user: UserContext = Depends(require_user),
# ):
#     """
#     List all workflows and agents for the current user.

#     Queries both the ``workflows`` and ``agents`` PostgreSQL tables
#     and returns a unified list labeled by skill_type.

#     Falls back to include DEFAULT_USER_ID data when the authenticated
#     user has no data (dev/test convenience).
#     """
#     user_id = resolve_user_id(user)

#     # Include DEFAULT_USER_ID as fallback so dev/test users always
#     # see shared data even if their JWT creates a new user identity.
#     user_ids = [
#         func.cast(user_id, Workflow.user_id.type),
#         func.cast(DEFAULT_USER_ID, Workflow.user_id.type),
#     ]

#     async with get_db_session() as db:
#         skills: List[SkillResponse] = []

#         # ---- Workflows ----
#         wf_stmt = (
#             select(Workflow)
#             .where(
#                 or_(*(Workflow.user_id == uid for uid in user_ids)),
#                 Workflow.status != "archived",
#                 Workflow.is_deleted == False,  # noqa: E712
#             )
#             .order_by(Workflow.name.asc())
#         )
#         wf_result = await db.execute(wf_stmt)
#         seen_wf_names = set()
#         for wf in wf_result.scalars().all():
#             # Deduplicate by name (prefer user's own copy over default)
#             if wf.name in seen_wf_names:
#                 continue
#             seen_wf_names.add(wf.name)
#             description = None
#             if wf.definition and isinstance(wf.definition, dict):
#                 description = wf.definition.get("description")
#             skills.append(
#                 SkillResponse(
#                     skill_id=str(wf.workflow_id),
#                     skill_type="workflow",
#                     name=wf.name,
#                     description=description,
#                 )
#             )

#         # ---- Agents ----
#         agt_stmt = (
#             select(Agent)
#             .where(
#                 or_(*(Agent.user_id == uid for uid in user_ids)),
#                 Agent.is_deleted == False,  # noqa: E712
#             )
#             .order_by(Agent.name.asc())
#         )
#         agt_result = await db.execute(agt_stmt)
#         seen_agt_names = set()
#         for agt in agt_result.scalars().all():
#             # Deduplicate by name
#             if agt.name in seen_agt_names:
#                 continue
#             seen_agt_names.add(agt.name)
#             name = agt.name
#             description = None
#             if agt.definition and isinstance(agt.definition, dict):
#                 name = agt.definition.get("name") or agt.name
#                 # description is authoritative; role is a legacy fallback only.
#                 description = agt.definition.get("description") or agt.definition.get("role")
#             skills.append(
#                 SkillResponse(
#                     skill_id=str(agt.agent_id),
#                     skill_type="agent",
#                     name=name,
#                     description=description,
#                 )
#             )

#         return skills