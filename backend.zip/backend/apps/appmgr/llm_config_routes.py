"""
EchoAI — Per-Application LLM Config CRUD API (Phase 3)

Endpoints for storing, retrieving, deleting, and testing per-app LLM
credentials via Azure Key Vault (or in-memory fallback for local dev).

Route group:
    /api/applications/{application_id}/llm-config/...

On save the endpoint also updates the ``ApplicationLlmLink`` table so
the orchestrator can resolve ``kv://<app_id>`` references to real
credentials at runtime.
"""

import logging
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.database import get_db_session
from echolib.models.application import Application, ApplicationLlmLink
from echolib.secrets_provider import secrets
from echolib.security import require_user, require_admin_or_above, resolve_user_id
from echolib.types import UserContext

logger = logging.getLogger(__name__)

# ======================================================================
# Schemas
# ======================================================================


class LlmConfigEntry(BaseModel):
    """
    A single LLM credential configuration for one role.

    Mirrors the shape used by ``llm_provider.json`` so consumers
    (LLMFactory, LLMClientBuilder, etc.) can use it directly.
    """
    role: str = Field(
        "general",
        description="Role this LLM serves: 'general', 'orchestrator', or 'enhancer'.",
        pattern="^(general|orchestrator|enhancer)$",
    )
    provider: str = Field(..., min_length=1, max_length=100, description="LLM provider slug, e.g. 'azure', 'openai', 'ollama'.")
    model_name: str = Field(..., min_length=1, max_length=255, description="Provider-specific model name.")
    api_key: Optional[str] = Field(None, description="API key (stored encrypted in Key Vault).")
    base_url: Optional[str] = Field(None, max_length=1024, description="Provider base URL.")
    api_version: Optional[str] = Field(None, max_length=50, description="API version (Azure OpenAI).")
    deployment_name: Optional[str] = Field(None, max_length=255, description="Azure deployment name.")
    extra: Optional[Dict[str, Any]] = Field(None, description="Additional provider-specific parameters.")


class LlmConfigSaveRequest(BaseModel):
    """Request body for saving LLM configs for an application."""
    configs: List[LlmConfigEntry] = Field(
        ...,
        min_length=1,
        description="One or more LLM configs keyed by role.",
    )


class LlmConfigResponse(BaseModel):
    """Single LLM config returned to the caller (api_key masked)."""
    role: str
    provider: str
    model_name: str
    api_key_set: bool = Field(description="True when an API key is stored (value is never returned).")
    base_url: Optional[str] = None
    api_version: Optional[str] = None
    deployment_name: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


class LlmConfigListResponse(BaseModel):
    """Response wrapper for listing all LLM configs of an application."""
    application_id: str
    configs: List[LlmConfigResponse]


class LlmConfigTestRequest(BaseModel):
    """Optional override fields when testing credentials."""
    prompt: str = Field(
        "Say hello in one sentence.",
        max_length=500,
        description="Short prompt used for the test invocation.",
    )


class LlmConfigTestResponse(BaseModel):
    """Result of a credential test call."""
    success: bool
    model_response: Optional[str] = None
    error: Optional[str] = None


# ======================================================================
# Router
# ======================================================================

llm_config_router = APIRouter(
    prefix="/api/applications/{application_id}/llm-config",
    tags=["LLM Config"],
)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _build_kv_payload(entry: LlmConfigEntry) -> Dict[str, str]:
    """Convert a schema entry into the dict persisted in Key Vault."""
    payload: Dict[str, str] = {
        "role": entry.role,
        "provider": entry.provider,
        "model_name": entry.model_name,
    }
    if entry.api_key:
        payload["api_key"] = entry.api_key
    if entry.base_url:
        payload["base_url"] = entry.base_url
    if entry.api_version:
        payload["api_version"] = entry.api_version
    if entry.deployment_name:
        payload["deployment_name"] = entry.deployment_name
    if entry.extra:
        # Flatten extra into the payload with a prefix to avoid collisions
        for k, v in entry.extra.items():
            payload[f"extra.{k}"] = str(v)
    return payload


def _mask_config(raw: Dict[str, str]) -> LlmConfigResponse:
    """Turn a raw KV payload dict into a response with masked api_key."""
    return LlmConfigResponse(
        role=raw.get("role", "general"),
        provider=raw.get("provider", ""),
        model_name=raw.get("model_name", ""),
        api_key_set=bool(raw.get("api_key")),
        base_url=raw.get("base_url"),
        api_version=raw.get("api_version"),
        deployment_name=raw.get("deployment_name"),
        extra={
            k.removeprefix("extra."): v
            for k, v in raw.items()
            if k.startswith("extra.")
        } or None,
    )


async def _verify_app_access(
    application_id: str, user_id: str
) -> UUID:
    """Verify the application exists and the user owns it. Returns the app UUID."""
    async with get_db_session() as db:
        stmt = select(Application.application_id, Application.created_by).where(
            Application.application_id == application_id
        )
        row = (await db.execute(stmt)).first()
        if row is None:
            raise HTTPException(status_code=404, detail="Application not found.")
        if str(row.created_by) != user_id:
            raise HTTPException(status_code=403, detail="Access denied.")
        return row.application_id


# ------------------------------------------------------------------
# POST  — Save / overwrite LLM configs for an app
# ------------------------------------------------------------------

@llm_config_router.post("", status_code=201, response_model=LlmConfigListResponse)
async def save_llm_config(
    application_id: str,
    payload: LlmConfigSaveRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Store one or more LLM credential sets for an application.

    Each config entry is persisted as a Key Vault secret keyed by
    ``llm-config-<app_id>-<role>``.  The ``ApplicationLlmLink`` table
    is updated so downstream code can resolve ``kv://<app_id>``
    references.
    """
    user_id = resolve_user_id(user)
    app_uuid = await _verify_app_access(application_id, user_id)

    # Validate no duplicate roles
    roles_seen: set = set()
    for entry in payload.configs:
        if entry.role in roles_seen:
            raise HTTPException(
                status_code=422,
                detail=f"Duplicate role '{entry.role}' in request.",
            )
        roles_seen.add(entry.role)

    saved: List[LlmConfigResponse] = []

    for entry in payload.configs:
        kv_payload = _build_kv_payload(entry)
        # Store per-role secret: key = "<app_id>-<role>"
        kv_key = f"{application_id}-{entry.role}"
        secrets.store_llm_config(kv_key, kv_payload)
        saved.append(_mask_config(kv_payload))

    # Update ApplicationLlmLink table
    async with get_db_session() as db:
        # Remove old links for this app
        await db.execute(
            delete(ApplicationLlmLink).where(
                ApplicationLlmLink.application_id == app_uuid
            )
        )
        # Insert new links referencing KV
        for entry in payload.configs:
            db.add(
                ApplicationLlmLink(
                    application_id=app_uuid,
                    llm_id=f"kv://{application_id}-{entry.role}",
                    role=entry.role,
                    name=f"{entry.provider}/{entry.model_name}",
                )
            )

    logger.info(
        "LLM config saved for app %s — roles: %s",
        application_id,
        [e.role for e in payload.configs],
    )

    return LlmConfigListResponse(
        application_id=application_id,
        configs=saved,
    )


# ------------------------------------------------------------------
# GET   — Retrieve all LLM configs for an app
# ------------------------------------------------------------------

@llm_config_router.get("", response_model=LlmConfigListResponse)
async def list_llm_configs(
    application_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """List all stored LLM configs for an application (api_key masked)."""
    user_id = resolve_user_id(user)
    await _verify_app_access(application_id, user_id)

    # Discover stored roles from ApplicationLlmLink
    async with get_db_session() as db:
        stmt = select(ApplicationLlmLink).where(
            ApplicationLlmLink.application_id == application_id,
            ApplicationLlmLink.llm_id.startswith("kv://"),
        )
        rows = (await db.execute(stmt)).scalars().all()

    configs: List[LlmConfigResponse] = []
    for link in rows:
        kv_key = link.llm_id.removeprefix("kv://")
        raw = secrets.get_llm_config(kv_key)
        if raw is not None:
            configs.append(_mask_config(raw))

    return LlmConfigListResponse(
        application_id=application_id,
        configs=configs,
    )


# ------------------------------------------------------------------
# GET   — Retrieve single LLM config by role
# ------------------------------------------------------------------

@llm_config_router.get("/{role}", response_model=LlmConfigResponse)
async def get_llm_config_by_role(
    application_id: str,
    role: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Retrieve LLM config for a specific role (api_key masked)."""
    user_id = resolve_user_id(user)
    await _verify_app_access(application_id, user_id)

    kv_key = f"{application_id}-{role}"
    raw = secrets.get_llm_config(kv_key)
    if raw is None:
        raise HTTPException(
            status_code=404,
            detail=f"No LLM config found for role '{role}'.",
        )
    return _mask_config(raw)


# ------------------------------------------------------------------
# DELETE — Remove LLM config for a specific role
# ------------------------------------------------------------------

@llm_config_router.delete("/{role}", status_code=204)
async def delete_llm_config_by_role(
    application_id: str,
    role: str,
    user: UserContext = Depends(require_user),
):
    """Delete LLM config for a specific role from Key Vault and DB link."""
    user_id = resolve_user_id(user)
    app_uuid = await _verify_app_access(application_id, user_id)

    kv_key = f"{application_id}-{role}"
    secrets.delete_llm_config(kv_key)

    async with get_db_session() as db:
        await db.execute(
            delete(ApplicationLlmLink).where(
                ApplicationLlmLink.application_id == app_uuid,
                ApplicationLlmLink.llm_id == f"kv://{kv_key}",
            )
        )

    logger.info("LLM config deleted for app %s role %s", application_id, role)


# ------------------------------------------------------------------
# DELETE — Remove ALL LLM configs for an app
# ------------------------------------------------------------------

@llm_config_router.delete("", status_code=204)
async def delete_all_llm_configs(
    application_id: str,
    user: UserContext = Depends(require_user),
):
    """Delete all LLM configs for an application."""
    user_id = resolve_user_id(user)
    app_uuid = await _verify_app_access(application_id, user_id)

    # Find all kv:// links to clean up KV secrets
    async with get_db_session() as db:
        stmt = select(ApplicationLlmLink.llm_id).where(
            ApplicationLlmLink.application_id == app_uuid,
            ApplicationLlmLink.llm_id.startswith("kv://"),
        )
        kv_ids = (await db.execute(stmt)).scalars().all()

    for llm_id in kv_ids:
        kv_key = llm_id.removeprefix("kv://")
        secrets.delete_llm_config(kv_key)

    async with get_db_session() as db:
        await db.execute(
            delete(ApplicationLlmLink).where(
                ApplicationLlmLink.application_id == app_uuid,
                ApplicationLlmLink.llm_id.startswith("kv://"),
            )
        )

    logger.info("All LLM configs deleted for app %s", application_id)


# ------------------------------------------------------------------
# POST  — Test LLM credentials with a quick invocation
# ------------------------------------------------------------------

@llm_config_router.post("/{role}/test", response_model=LlmConfigTestResponse)
async def test_llm_config(
    application_id: str,
    role: str,
    body: LlmConfigTestRequest = LlmConfigTestRequest(),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Test stored LLM credentials by making a single invocation.

    Uses the LLMFactory to build a client from the stored config and
    invokes it with a short prompt. Returns success/failure with the
    model response or error message.
    """
    user_id = resolve_user_id(user)
    await _verify_app_access(application_id, user_id)

    kv_key = f"{application_id}-{role}"
    raw = secrets.get_llm_config(kv_key)
    if raw is None:
        raise HTTPException(
            status_code=404,
            detail=f"No LLM config found for role '{role}'.",
        )

    try:
        from echolib.llm_factory import LLMFactory

        factory = LLMFactory()
        # Build a model config dict compatible with LLMClientBuilder
        model_config = {
            "id": f"kv-test-{application_id}-{role}",
            "name": f"KV Test ({role})",
            "provider": raw.get("provider", ""),
            "model_name": raw.get("model_name", ""),
            "base_url": raw.get("base_url", ""),
            "api_key": raw.get("api_key", ""),
        }
        if raw.get("api_version"):
            model_config["api_version"] = raw["api_version"]
        if raw.get("deployment_name"):
            model_config["deployment_name"] = raw["deployment_name"]

        llm_client = factory.client_builder.build_client(
            model_config=model_config,
            temperature=0.0,
            max_tokens=100,
            streaming=False,
        )
        response = llm_client.invoke(body.prompt)
        # LangChain BaseMessage or string
        content = response.content if hasattr(response, "content") else str(response)

        return LlmConfigTestResponse(success=True, model_response=content)
    except Exception as e:
        logger.warning(
            "LLM config test failed for app %s role %s: %s",
            application_id,
            role,
            e,
        )
        return LlmConfigTestResponse(success=False, error=str(e))
