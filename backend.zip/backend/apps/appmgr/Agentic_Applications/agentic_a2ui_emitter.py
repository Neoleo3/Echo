"""
EchoAI Agentic Application — A2UI Message Emitter

Generates EchoAI A2UI Protocol JSONL messages for agentic application execution.
Each canvas component is mapped to an A2UI component catalog type.

Note: This uses the EchoAI internal A2UI protocol, not the official A2A spec.

The emitter produces three kinds of messages:
    surfaceUpdate    — defines the full component tree for a canvas
    dataModelUpdate  — pushes data for individual component outputs
    beginRendering   — signals the frontend to start rendering

Inter-component communication:
    When Component A (e.g. agent_trigger) produces output at on_success_key,
    the pipeline emits a dataModelUpdate targeting that key. Component B
    (e.g. data_table) bound to the same data_key receives the update
    reactively via the frontend A2UI renderer.

Architecture:
    This module is stateless. It builds JSON strings; the pipeline/routes
    handle SSE transport.
"""

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Heading level → A2UI usageHint
_HEADING_HINTS = {"h1": "h1", "h2": "h2", "h3": "h3", "h4": "h4", "h5": "h5"}


def _surface_id(app_id: str) -> str:
    return f"agentic_{app_id}"


# ---------------------------------------------------------------------------
# Component builders — one per canvas category
# ---------------------------------------------------------------------------

# Normalise frontend aliases to canonical backend slugs
_ALIAS_MAP = {
    "card": "card_container",
    "textarea": "text_area",
    "multiselect": "multi_select",
    "rating": "star_rating",
    "markdown_box": "markdown",
    "status_timeline": "timeline",
    "image_display": "image",
}


def _normalise_type(ctype: str) -> str:
    return _ALIAS_MAP.get(ctype, ctype)


def _build_layout_component(comp: dict) -> dict:
    """Build an A2UI component dict for a layout canvas component."""
    ctype = _normalise_type(comp.get("type", ""))
    props = comp.get("props") or {}
    cid = comp.get("id", "")

    if ctype == "heading":
        level = props.get("level", props.get("size", "h2"))
        hint = _HEADING_HINTS.get(str(level).lower(), "h2")
        return {
            "id": cid,
            "type": "Text",
            "content": {"literalString": props.get("text", props.get("label", "Heading"))},
            "hint": hint,
        }

    if ctype == "label":
        return {
            "id": cid,
            "type": "Text",
            "content": {"literalString": props.get("text", props.get("content", props.get("label", "")))},
            "hint": "body",
        }

    if ctype == "divider":
        return {"id": cid, "type": "Divider"}

    if ctype == "spacer":
        return {
            "id": cid,
            "type": "Spacer",
            "height": props.get("height", 16),
        }

    if ctype == "card_container":
        return {
            "id": cid,
            "type": "Card",
            "children": {"explicitList": []},  # filled by tree builder
        }

    return {"id": cid, "type": "Text", "content": {"literalString": f"[{ctype}]"}}


def _build_input_component(comp: dict) -> dict:
    """Build an A2UI component dict for an input canvas component."""
    ctype = _normalise_type(comp.get("type", ""))
    props = comp.get("props") or {}
    cid = comp.get("id", "")
    data_key = props.get("data_key", cid)

    if ctype in ("short_text", "text_area", "number", "date_picker"):
        input_type = "number" if ctype == "number" else ("date" if ctype == "date_picker" else "text")
        return {
            "id": cid,
            "type": "TextField",
            "label": {"literalString": props.get("label", data_key)},
            "placeholder": props.get("placeholder", ""),
            "dataPath": f"/{data_key}",
            "inputType": input_type,
        }

    if ctype == "select":
        options = props.get("options", [])
        if isinstance(options, str):
            options = [o.strip() for o in options.split(",") if o.strip()]
        return {
            "id": cid,
            "type": "Select",
            "label": {"literalString": props.get("label", data_key)},
            "options": options,
            "dataPath": f"/{data_key}",
        }

    if ctype == "multi_select":
        options = props.get("options", [])
        if isinstance(options, str):
            options = [o.strip() for o in options.split(",") if o.strip()]
        return {
            "id": cid,
            "type": "Select",
            "label": {"literalString": props.get("label", data_key)},
            "options": options,
            "dataPath": f"/{data_key}",
            "multiSelect": True,
        }

    if ctype == "slider":
        return {
            "id": cid,
            "type": "Slider",
            "label": {"literalString": props.get("label", data_key)},
            "min": props.get("min", 0),
            "max": props.get("max", 100),
            "step": props.get("step", 1),
            "dataPath": f"/{data_key}",
        }

    if ctype == "toggle":
        return {
            "id": cid,
            "type": "CheckBox",
            "label": {"literalString": props.get("label", data_key)},
            "checked": {"path": f"/{data_key}"},
        }

    if ctype == "file_upload":
        accept = props.get("accept", [])
        if isinstance(accept, str):
            accept = [a.strip() for a in accept.split(",") if a.strip()]
        return {
            "id": cid,
            "type": "FileField",
            "label": {"literalString": props.get("label", "Upload")},
            "dataPath": f"/{data_key}",
            "accept": accept,
            "maxSizeMb": props.get("max_size_mb", 10),
        }

    if ctype == "star_rating":
        return {
            "id": cid,
            "type": "Rating",
            "label": {"literalString": props.get("label", data_key)},
            "dataPath": f"/{data_key}",
            "max": 5,
        }

    return {"id": cid, "type": "TextField", "label": {"literalString": data_key}, "dataPath": f"/{data_key}"}


def _build_display_component(comp: dict) -> dict:
    """Build an A2UI component for a display canvas component."""
    ctype = _normalise_type(comp.get("type", ""))
    props = comp.get("props") or {}
    cid = comp.get("id", "")
    data_key = props.get("data_key", cid)

    if ctype in ("bar_chart", "line_chart", "pie_chart"):
        type_map = {"bar_chart": "BarChart", "line_chart": "LineChart", "pie_chart": "PieChart"}
        return {
            "id": cid,
            "type": type_map[ctype],
            "dataPath": f"/{data_key}",
            "title": {"literalString": props.get("label", ctype.replace("_", " ").title())},
        }

    if ctype == "data_table":
        return {
            "id": cid,
            "type": "DataTable",
            "dataPath": f"/{data_key}",
            "title": {"literalString": props.get("label", "Data Table")},
        }

    if ctype == "markdown":
        return {
            "id": cid,
            "type": "Markdown",
            "content": {"path": f"/{data_key}"},
        }

    if ctype == "timeline":
        return {
            "id": cid,
            "type": "Timeline",
            "dataPath": f"/{data_key}",
            "title": {"literalString": props.get("label", "Timeline")},
        }

    if ctype == "metric_card":
        return {
            "id": cid,
            "type": "MetricCard",
            "label": {"literalString": props.get("label", "Metric")},
            "value": {"path": f"/{data_key}"},
            "subtext": props.get("subtext", ""),
            "unit": props.get("unit", ""),
        }

    if ctype == "image":
        src = props.get("src", "")
        return {
            "id": cid,
            "type": "Image",
            "src": {"literalString": src} if src else {"path": f"/{data_key}"},
        }

    return {"id": cid, "type": "Text", "content": {"path": f"/{data_key}"}}


def _build_interaction_component(comp: dict) -> dict:
    """Build an A2UI component for an interaction canvas component."""
    ctype = _normalise_type(comp.get("type", ""))
    props = comp.get("props") or {}
    cid = comp.get("id", "")
    data_key = props.get("data_key", cid)

    if ctype == "submit_button":
        return {
            "id": cid,
            "type": "Button",
            "label": {"literalString": props.get("label", "▶ Run")},
            "primary": True,
            "action": {"actionId": data_key},
        }

    if ctype in ("api_trigger", "agent_trigger", "workflow_trigger"):
        label_map = {
            "api_trigger": "🌐 Call API",
            "agent_trigger": "🤖 Run Agent",
            "workflow_trigger": "⚡ Run Workflow",
        }
        return {
            "id": cid,
            "type": "Button",
            "label": {"literalString": props.get("label", label_map.get(ctype, "Run"))},
            "primary": False,
            "action": {"actionId": data_key},
        }

    if ctype == "chat_interface":
        # Chat is a compound component: a chat history area + input + send button
        history_id = f"{cid}_history"
        input_id = f"{cid}_input"
        send_id = f"{cid}_send"
        return {
            "id": cid,
            "type": "ChatInterface",
            "dataPath": f"/{data_key}",
            "label": {"literalString": props.get("title", props.get("chat_title", "AI Assistant"))},
            "children": {"explicitList": [history_id, input_id, send_id]},
            "_sub_components": [
                {
                    "id": history_id,
                    "type": "Markdown",
                    "content": {"path": f"/{data_key}_history"},
                },
                {
                    "id": input_id,
                    "type": "TextField",
                    "label": {"literalString": props.get("title", "Message")},
                    "placeholder": "Type your message...",
                    "dataPath": f"/{data_key}_input",
                },
                {
                    "id": send_id,
                    "type": "Button",
                    "label": {"literalString": "Send"},
                    "primary": True,
                    "action": {"actionId": f"{data_key}_send"},
                },
            ],
        }

    return {"id": cid, "type": "Button", "label": {"literalString": ctype}, "action": {"actionId": data_key}}


# ---------------------------------------------------------------------------
# Canvas → A2UI component router
# ---------------------------------------------------------------------------

_LAYOUT_TYPES = {"heading", "label", "divider", "spacer", "card_container",
                 "card"}  # card = frontend alias for card_container
_INPUT_TYPES = {"short_text", "text_area", "textarea", "number", "select",
                "multi_select", "multiselect", "slider", "toggle",
                "date_picker", "file_upload", "star_rating", "rating"}
_DISPLAY_TYPES = {"bar_chart", "line_chart", "pie_chart", "data_table",
                  "markdown", "markdown_box", "timeline", "status_timeline",
                  "metric_card", "image", "image_display"}
_INTERACTION_TYPES = {"submit_button", "api_trigger", "agent_trigger",
                      "workflow_trigger", "chat_interface"}


def _build_component(comp: dict) -> dict:
    ctype = _normalise_type(comp.get("type", ""))
    if ctype in _LAYOUT_TYPES:
        return _build_layout_component(comp)
    if ctype in _INPUT_TYPES:
        return _build_input_component(comp)
    if ctype in _DISPLAY_TYPES:
        return _build_display_component(comp)
    if ctype in _INTERACTION_TYPES:
        return _build_interaction_component(comp)
    return {"id": comp.get("id", "unknown"), "type": "Text",
            "content": {"literalString": f"[Unknown: {ctype}]"}}


# ---------------------------------------------------------------------------
# Public API — build full A2UI surface from canvas_config
# ---------------------------------------------------------------------------

def build_surface_messages(
    app_id: str,
    canvas_config: List[Dict[str, Any]],
    data_state: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """
    Build the initial A2UI surface from a canvas_config array.

    Returns a list of JSONL strings:
        1. surfaceUpdate  — full component tree
        2. dataModelUpdate — initial data state (all data_keys initialized)
        3. beginRendering  — signal to start rendering

    These lines should be sent as SSE `data:` fields to the frontend.
    """
    sid = _surface_id(app_id)

    # Sort by Y position for top-to-bottom rendering
    sorted_canvas = sorted(canvas_config, key=lambda c: c.get("y", 0))

    components: List[dict] = []
    root_children: List[str] = []
    initial_data: Dict[str, Any] = dict(data_state or {})

    for comp in sorted_canvas:
        cid = comp.get("id", "")
        ctype = comp.get("type", "")
        props = comp.get("props") or {}
        data_key = props.get("data_key", cid)

        a2ui_comp = _build_component(comp)

        # Handle chat_interface sub-components
        sub_components = a2ui_comp.pop("_sub_components", None)
        components.append(a2ui_comp)
        root_children.append(cid)

        if sub_components:
            for sub in sub_components:
                components.append(sub)

        # Initialize data keys
        if ctype in _INPUT_TYPES:
            if data_key not in initial_data:
                default = props.get("default_value", props.get("defaultValue"))
                initial_data[data_key] = default
        elif ctype in _DISPLAY_TYPES:
            if data_key not in initial_data:
                initial_data[data_key] = None
        elif ctype == "chat_interface":
            if f"{data_key}_history" not in initial_data:
                initial_data[f"{data_key}_history"] = ""
            if f"{data_key}_input" not in initial_data:
                initial_data[f"{data_key}_input"] = ""
        # Interaction triggers: initialize on_success_key
        if ctype in _INTERACTION_TYPES:
            osk = props.get("on_success_key")
            if osk and osk not in initial_data:
                initial_data[osk] = None

    # Build root Column wrapping everything
    root = {
        "id": "root",
        "type": "Column",
        "children": {"explicitList": root_children},
    }
    components.insert(0, root)

    # 1. surfaceUpdate
    surface_msg = {
        "type": "surfaceUpdate",
        "surfaceId": sid,
        "catalog": "std:v1",
        "components": components,
    }

    # 2. dataModelUpdate
    data_msg = {
        "type": "dataModelUpdate",
        "surfaceId": sid,
        "data": initial_data,
    }

    # 3. beginRendering
    begin_msg = {
        "type": "beginRendering",
        "surfaceId": sid,
        "rootComponentId": "root",
    }

    return [
        json.dumps(surface_msg, separators=(",", ":")),
        json.dumps(data_msg, separators=(",", ":")),
        json.dumps(begin_msg, separators=(",", ":")),
    ]


def emit_data_update(
    app_id: str,
    updates: Dict[str, Any],
) -> str:
    """
    Emit an incremental A2UI dataModelUpdate.

    Used after a component executes: pushes its output to the surface
    data model so bound display components reactively update.

    Args:
        app_id: The agentic application ID.
        updates: Dict of {data_key: value} to merge into the surface data model.

    Returns:
        JSONL string for SSE.
    """
    sid = _surface_id(app_id)
    msg = {
        "type": "dataModelUpdate",
        "surfaceId": sid,
        "data": updates,
    }
    return json.dumps(msg, separators=(",", ":"))


def emit_step_status(
    app_id: str,
    component_id: str,
    component_type: str,
    status: str,
    output: Any = None,
    error: Optional[str] = None,
) -> str:
    """
    Emit an executionStatusUpdate A2UI message for a single step.

    Args:
        app_id: The agentic application ID.
        component_id: Which component just ran.
        component_type: e.g. 'agent_trigger'.
        status: 'running' | 'completed' | 'failed'.
        output: The component output (if completed).
        error: Error message (if failed).

    Returns:
        JSONL string for SSE.
    """
    sid = _surface_id(app_id)
    step = {
        "componentId": component_id,
        "componentType": component_type,
        "status": status,
    }
    if output is not None:
        step["output"] = output
    if error:
        step["error"] = error

    msg = {
        "type": "executionStatusUpdate",
        "surfaceId": sid,
        "step": step,
    }
    return json.dumps(msg, separators=(",", ":"))


def emit_final_answer(
    app_id: str,
    data_state: Dict[str, Any],
    steps: List[Dict[str, Any]],
    status: str,
    errors: List[str],
) -> str:
    """
    Emit the final A2UI response after all components have executed.

    Sends two messages as a newline-separated pair:
      1. dataModelUpdate — the complete domain data (no underscore keys)
      2. executionStatusUpdate — execution completion metadata

    Returns:
        Newline-separated JSONL strings for SSE (two data: events).
    """
    sid = _surface_id(app_id)

    # 1. Clean data model update (domain data only)
    data_msg = {
        "type": "dataModelUpdate",
        "surfaceId": sid,
        "data": data_state,
    }

    # 2. Execution completion status (protocol metadata)
    exec_msg = {
        "type": "executionStatusUpdate",
        "surfaceId": sid,
        "complete": True,
        "status": status,
        "steps": steps,
        "errors": errors,
    }

    return (
        json.dumps(data_msg, separators=(",", ":"))
        + "\n"
        + json.dumps(exec_msg, separators=(",", ":"))
    )


def emit_delete_surface(app_id: str) -> str:
    """
    Emit a deleteSurface A2UI message to remove the surface from the client.

    Args:
        app_id: The agentic application ID.

    Returns:
        JSONL string for SSE.
    """
    sid = _surface_id(app_id)
    msg = {
        "type": "deleteSurface",
        "surfaceId": sid,
    }
    return json.dumps(msg, separators=(",", ":"))
