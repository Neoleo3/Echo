"""Canvas synthesizer for intent-first app creation."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

CANVAS_W = 1100
CANVAS_H = 840

_PADDING_X = 32
_PADDING_Y = 24
_SECTION_GAP = 18
_GRID_GAP = 14

_INPUT_TYPES = {
    "short_text",
    "text_area",
    "number",
    "select",
    "multi_select",
    "slider",
    "toggle",
    "date_picker",
    "file_upload",
    "star_rating",
}

_DISPLAY_TYPES = {
    "bar_chart",
    "line_chart",
    "pie_chart",
    "data_table",
    "markdown",
    "timeline",
    "metric_card",
    "image",
    "ppt_generator",
}

_ACTION_TYPES = {"api_trigger", "agent_trigger", "workflow_trigger", "chat_interface"}

_FULL_WIDTH_TYPES = {
    "heading",
    "text_area",
    "file_upload",
    "chat_interface",
    "data_table",
    "markdown",
    "timeline",
    "image",
    "ppt_generator",
}


def _component_height(ctype: str) -> int:
    height_by_type = {
        "heading": 56,
        "short_text": 72,
        "number": 72,
        "select": 72,
        "multi_select": 86,
        "slider": 72,
        "toggle": 56,
        "date_picker": 72,
        "text_area": 116,
        "file_upload": 120,
        "agent_trigger": 60,
        "workflow_trigger": 60,
        "api_trigger": 60,
        "chat_interface": 280,
        "bar_chart": 220,
        "line_chart": 220,
        "pie_chart": 220,
        "data_table": 230,
        "markdown": 220,
        "timeline": 220,
        "metric_card": 120,
        "image": 220,
        "ppt_generator": 190,
        "submit_button": 56,
    }
    return height_by_type.get(ctype, 84)


def _assign_section_layout(
    components: List[Dict[str, Any]],
    *,
    start_y: int,
    left_x: int,
    content_w: int,
    max_y: int,
    cols: int = 1,
) -> int:
    """Assign non-overlapping layout coordinates to a section of components."""
    if not components:
        return start_y

    col_count = max(1, cols)
    if col_count == 1:
        col_w = content_w
    else:
        col_w = int((content_w - (_GRID_GAP * (col_count - 1))) / col_count)

    y = start_y
    row_h = 0
    col = 0

    for comp in components:
        ctype = str(comp.get("type") or "").strip().lower()
        comp_h = _component_height(ctype)
        is_full = ctype in _FULL_WIDTH_TYPES or col_count == 1

        if is_full and col != 0:
            y += row_h + _GRID_GAP
            col = 0
            row_h = 0

        if y + comp_h > max_y:
            # Keep the component visible in bounds when canvas is dense.
            y = max(start_y, max_y - comp_h)

        if is_full:
            x = left_x
            w = content_w
            comp["x"] = x
            comp["y"] = y
            comp["w"] = w
            comp["h"] = comp_h
            y += comp_h + _GRID_GAP
            col = 0
            row_h = 0
            continue

        x = left_x + (col * (col_w + _GRID_GAP))
        comp["x"] = x
        comp["y"] = y
        comp["w"] = col_w
        comp["h"] = comp_h

        row_h = max(row_h, comp_h)
        col += 1

        if col >= col_count:
            y += row_h + _GRID_GAP
            col = 0
            row_h = 0

    if col != 0:
        y += row_h + _GRID_GAP

    return y


def _layout_canvas_for_frontend(components: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Apply sectioned pixel layout tuned for the frontend 1100x840 canvas."""
    if not components:
        return components

    left_x = _PADDING_X
    top_y = _PADDING_Y
    content_w = CANVAS_W - (_PADDING_X * 2)
    max_y = CANVAS_H - _PADDING_Y

    headings = [c for c in components if str(c.get("type") or "").strip().lower() == "heading"]
    inputs = [c for c in components if str(c.get("type") or "").strip().lower() in _INPUT_TYPES]
    actions = [c for c in components if str(c.get("type") or "").strip().lower() in _ACTION_TYPES]
    outputs = [c for c in components if str(c.get("type") or "").strip().lower() in _DISPLAY_TYPES]
    submit = [c for c in components if str(c.get("type") or "").strip().lower() == "submit_button"]

    used_ids = {id(c) for c in headings + inputs + actions + outputs + submit}
    misc = [c for c in components if id(c) not in used_ids]

    y = top_y
    y = _assign_section_layout(headings, start_y=y, left_x=left_x, content_w=content_w, max_y=max_y, cols=1)
    y += _SECTION_GAP
    y = _assign_section_layout(inputs, start_y=y, left_x=left_x, content_w=content_w, max_y=max_y, cols=2)
    y += _SECTION_GAP
    y = _assign_section_layout(actions, start_y=y, left_x=left_x, content_w=content_w, max_y=max_y, cols=2)
    y += _SECTION_GAP
    y = _assign_section_layout(outputs + misc, start_y=y, left_x=left_x, content_w=content_w, max_y=max_y, cols=1)

    if submit:
        submit_y = min(max_y - _component_height("submit_button"), y + _SECTION_GAP)
        _assign_section_layout(
            submit,
            start_y=submit_y,
            left_x=left_x,
            content_w=min(220, content_w),
            max_y=max_y,
            cols=1,
        )

    return components


def _strict_intent_template_canvas() -> List[Dict[str, Any]]:
    """Return the deterministic starter template required by the frontend intent flow."""
    return [
        {
            "id": "c_1",
            "type": "short_text",
            "x": 222.5,
            "y": 179,
            "w": 280,
            "h": 72,
            "props": {
                "data_key": "short_text_1",
            },
        },
        {
            "id": "c_2",
            "type": "file_upload",
            "x": 363.5,
            "y": 380,
            "w": 280,
            "h": 100,
            "props": {
                "data_key": "file_upload_2",
            },
        },
        {
            "id": "c_3",
            "type": "workflow_trigger",
            "x": 282.5,
            "y": 564,
            "w": 240,
            "h": 80,
            "props": {
                "data_key": "workflow_trigger_3",
                "workflow_id": "PASTE_YOUR_WORKFLOW_ID_HERE",
            },
        },
        {
            "id": "c_4",
            "type": "workflow_trigger",
            "x": 642.5,
            "y": 495,
            "w": 240,
            "h": 80,
            "props": {
                "data_key": "workflow_trigger_4",
                "workflow_id": "PASTE_YOUR_WORKFLOW_ID_HERE",
            },
        },
        {
            "id": "c_5",
            "type": "api_trigger",
            "x": 725.5,
            "y": 270,
            "w": 240,
            "h": 80,
            "props": {
                "data_key": "api_trigger_5",
            },
        },
    ]


def synthesize_canvas_from_intent(
    *,
    intent: Dict[str, Any],
    reuse_plan: Dict[str, Any],
    template_mode: str = "legacy",
) -> List[Dict[str, Any]]:
    """
    Build a canonical starter canvas from user intent and reuse decision.

    This canvas is then passed through the existing orchestrator so final A2UI
    is generated via Echo's canonical path.
    """
    if template_mode == "strict_intent_v1":
        components = _layout_canvas_for_frontend(_strict_intent_template_canvas())
        logger.info(
            "canvas_synthesizer: template_mode=%s components=%d canvas=%dx%d",
            template_mode,
            len(components),
            CANVAS_W,
            CANVAS_H,
        )
        return components

    app_type = intent.get("app_type_hint") or "workflow_app"
    requires_images = bool(intent.get("requires_images"))
    requires_ppt = bool(intent.get("requires_ppt"))
    requested_slide_count = intent.get("requested_slide_count")
    prefers_existing_template = bool(intent.get("prefers_existing_template"))

    components: List[Dict[str, Any]] = []

    components.append(
        {
            "id": "c_heading_1",
            "type": "heading",
            "x": 0,
            "y": 0,
            "w": 12,
            "h": 1,
            "props": {"text": f"{app_type.replace('_', ' ').title()}"},
        }
    )
    components.append(
        {
            "id": "c_input_1",
            "type": "short_text",
            "x": 0,
            "y": 1,
            "w": 12,
            "h": 1,
            "props": {
                "label": "Describe what you need",
                "placeholder": "Enter request",
                "data_key": "user_query",
            },
        }
    )

    selected_agent_id = reuse_plan.get("selected_agent_id")
    selected_workflow_id = reuse_plan.get("selected_workflow_id")
    generate_agent = reuse_plan.get("generate_agent", False)
    generate_workflow = reuse_plan.get("generate_workflow", False)

    # NEW: Support multi-asset selection (both agent AND workflow on canvas)
    # Orchestrator will route query to appropriate component at runtime
    current_y = 2
    
    # Add workflow_trigger if selected or needs generation
    if selected_workflow_id or generate_workflow:
        components.append(
            {
                "id": "c_trigger_wf_1",
                "type": "workflow_trigger",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 1,
                "props": {
                    "data_key": "run_workflow",
                    "workflow_id": selected_workflow_id or "PASTE_YOUR_WORKFLOW_ID_HERE",
                    "input_mapping": {"user_query": "{{user_query}}"},
                    "on_success_key": "result_markdown",
                },
            }
        )
        current_y += 1
    
    # Add agent_trigger if selected or needs generation
    if selected_agent_id or generate_agent:
        components.append(
            {
                "id": "c_trigger_agent_1",
                "type": "agent_trigger",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 1,
                "props": {
                    "data_key": "run_agent",
                    "agent_id": selected_agent_id or "PASTE_YOUR_AGENT_ID_HERE",
                    "input_keys": ["user_query"],
                    "on_success_key": "result_markdown",
                },
            }
        )
        current_y += 1
    
    # Fallback: if neither selected, add agent_trigger placeholder
    if not selected_agent_id and not selected_workflow_id and not generate_agent and not generate_workflow:
        components.append(
            {
                "id": "c_trigger_agent_1",
                "type": "agent_trigger",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 1,
                "props": {
                    "data_key": "run_agent",
                    "agent_id": "PASTE_YOUR_AGENT_ID_HERE",
                    "input_keys": ["user_query"],
                    "on_success_key": "result_markdown",
                },
            }
        )
        current_y += 1

    components.append(
        {
            "id": "c_output_md_1",
            "type": "markdown",
            "x": 0,
            "y": current_y,
            "w": 12,
            "h": 3,
            "props": {
                "label": "Result",
                "data_key": "result_markdown",
            },
        }
    )
    
    current_y += 3

    if requires_ppt:
        slide_hint = ""
        if isinstance(requested_slide_count, int) and requested_slide_count > 0:
            slide_hint = f" ({requested_slide_count} slides requested)"

        template_hint = "Use an available template from the registry"
        if prefers_existing_template:
            template_hint = "Use the existing available template"

        components.append(
            {
                "id": "c_input_ppt_payload_1",
                "type": "text_area",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 2,
                "props": {
                    "label": f"Presentation data (JSON){slide_hint}",
                    "placeholder": (
                        "Paste structured JSON for PPT generation. "
                        f"{template_hint}."
                    ),
                    "data_key": "presentation_payload",
                },
            }
        )
        current_y += 2
        
        components.append(
            {
                "id": "c_output_ppt_1",
                "type": "ppt_generator",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 2,
                "props": {
                    "label": "Generated Presentation",
                    "data_key": "presentation_payload",
                    "use_template": False,
                    "title": f"Generated Presentation{slide_hint}",
                    "slide_count": requested_slide_count,
                    "allow_ai_fallback": True,
                    "on_success_key": "presentation_artifact",
                },
            }
        )
        current_y += 2

    if requires_images:
        components.append(
            {
                "id": "c_output_img_1",
                "type": "image",
                "x": 0,
                "y": current_y,
                "w": 12,
                "h": 3,
                "props": {
                    "label": "Visual Output",
                    "data_key": "result_image_url",
                },
            }
        )
        current_y += 3

    components.append(
        {
            "id": "c_submit_1",
            "type": "submit_button",
            "x": 0,
            "y": current_y,
            "w": 12,
            "h": 1,
            "props": {
                "label": "Run",
                "data_key": "run_app",
            },
        }
    )

    components = _layout_canvas_for_frontend(components)

    logger.info(
        "canvas_synthesizer: app_type=%s components=%d requires_images=%s requires_ppt=%s canvas=%dx%d",
        app_type,
        len(components),
        requires_images,
        requires_ppt,
        CANVAS_W,
        CANVAS_H,
    )
    return components
