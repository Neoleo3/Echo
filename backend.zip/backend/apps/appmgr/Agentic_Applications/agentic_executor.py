"""
EchoAI Agentic Application — Component Executor

Handlers for each runnable (needs_exec=True) component type:

    handle_agent_trigger    — Loads agent from DB by agent_id, runs via AgentInstance.chat()
                             — Registers any generated files from agent output
    handle_api_trigger      — Stateless HTTP call via APIConnectorService (no saving)
    handle_workflow_trigger — Validates workflow exists in DB (execution future)
    handle_chat_interface   — Multi-turn chat using platform default LLM

All handlers share the same signature:
    async def handle_*(props, data_state, user_id) -> ComponentResult
"""

import asyncio
import json
import logging
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

PDF_TEXT_PREVIEW_MAX_CHARS = int(os.getenv("AGENTIC_PDF_TEXT_PREVIEW_MAX_CHARS", "12000"))


# ---------------------------------------------------------------------------
# Result type shared by all handlers
# ---------------------------------------------------------------------------

@dataclass
class ComponentResult:
    success: bool
    output: Any = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Template substitution  {{data_key}} → data_state[data_key]
# ---------------------------------------------------------------------------

def _substitute(template: str, data_state: Dict[str, Any]) -> str:
    if not isinstance(template, str):
        return template

    def replacer(match: re.Match) -> str:
        key = match.group(1).strip()
        value = data_state.get(key)
        if value is None:
            return match.group(0)
        if isinstance(value, (dict, list)):
            return json.dumps(value)
        return str(value)

    return re.sub(r"\{\{([^}]+)\}\}", replacer, template)


def _substitute_dict(d: Dict[str, Any], data_state: Dict[str, Any]) -> Dict[str, Any]:
    result = {}
    for k, v in d.items():
        if isinstance(v, str):
            result[k] = _substitute(v, data_state)
        elif isinstance(v, dict):
            result[k] = _substitute_dict(v, data_state)
        else:
            result[k] = v
    return result


def _substitute_value(value: Any, data_state: Dict[str, Any]) -> Any:
    if isinstance(value, str):
        return _substitute(value, data_state)
    if isinstance(value, dict):
        return _substitute_dict(value, data_state)
    if isinstance(value, list):
        return [_substitute_value(v, data_state) for v in value]
    return value


# ---------------------------------------------------------------------------
# Build agent input string from input_keys + data_state
# ---------------------------------------------------------------------------

def _build_agent_input(props: Dict[str, Any], data_state: Dict[str, Any]) -> str:
    input_keys: List[str] = props.get("input_keys") or []

    if input_keys:
        parts = []
        for key in input_keys:
            value = data_state.get(key)
            if value is not None:
                if isinstance(value, (dict, list)):
                    parts.append(f"{key}: {json.dumps(value, indent=2)}")
                else:
                    parts.append(f"{key}: {value}")
        return "\n".join(parts) if parts else "No input data provided."
    else:
        if not data_state:
            return "No input data provided."
        lines = []
        for k, v in data_state.items():
            if isinstance(v, (dict, list)):
                lines.append(f"{k}: {json.dumps(v, indent=2)}")
            else:
                lines.append(f"{k}: {v}")
        return "\n".join(lines)


async def _resolve_agentic_file_handle(
    value: Any,
    *,
    user_id: str,
) -> Any:
    file_id: Optional[str] = None
    if isinstance(value, dict) and value.get("file_id"):
        file_id = str(value.get("file_id"))
    elif isinstance(value, str):
        file_id = value
    else:
        return value

    try:
        from echolib.database import get_db_session
        from echolib.models.agentic_upload import AgenticUploadedFile
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        fid = safe_uuid(file_id)
        uid = safe_uuid(user_id)
        if fid is None or uid is None:
            return value

        async with get_db_session() as db:
            stmt = select(AgenticUploadedFile).where(
                AgenticUploadedFile.file_id == fid,
                AgenticUploadedFile.user_id == uid,
            )
            result = await db.execute(stmt)
            row = result.scalar_one_or_none()
            if row is None:
                return value

        meta = {
            "file_id": str(row.file_id),
            "original_filename": row.original_filename,
            "mime_type": row.mime_type,
            "size_bytes": row.size_bytes,
            "stored_in_db": bool(getattr(row, "content", None)),
        }

        mime = (row.mime_type or "").lower()
        name_l = (row.original_filename or "").lower()

        if mime.startswith("text/") or name_l.endswith((".txt", ".md", ".csv")):
            try:
                raw = (row.content or b"")[: 50 * 1024]
                text = raw.decode("utf-8", errors="replace")
                return {"file": meta, "text_preview": text}
            except Exception:
                return {"file": meta}

        if mime == "application/pdf" or name_l.endswith(".pdf"):
            preview = _extract_pdf_text_preview(row.content or b"")
            if preview:
                return {"file": meta, "pdf_text_preview": preview}
            return {"file": meta}

        return {"file": meta}

    except Exception:
        logger.debug("resolve_agentic_file_handle: failed", exc_info=True)
        return value


def _extract_pdf_text_preview(pdf_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
        from io import BytesIO

        reader = PdfReader(BytesIO(pdf_bytes))
        parts: List[str] = []
        for page in reader.pages[:20]:
            try:
                txt = page.extract_text() or ""
            except Exception:
                txt = ""
            if txt:
                parts.append(txt)
            if sum(len(p) for p in parts) >= PDF_TEXT_PREVIEW_MAX_CHARS:
                break
        text = "\n\n".join(parts).strip()
        if len(text) > PDF_TEXT_PREVIEW_MAX_CHARS:
            text = text[:PDF_TEXT_PREVIEW_MAX_CHARS]
        return text
    except Exception:
        return ""


async def _resolve_inputs_for_agent(
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    *,
    user_id: str,
) -> Dict[str, Any]:
    input_keys: List[str] = props.get("input_keys") or []
    if not input_keys:
        return data_state

    resolved = dict(data_state)
    for k in input_keys:
        if k in resolved:
            resolved[k] = await _resolve_agentic_file_handle(resolved[k], user_id=user_id)
    return resolved


# ---------------------------------------------------------------------------
# HANDLER 1 — agent_trigger
# ---------------------------------------------------------------------------

async def handle_agent_trigger(
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    user_id: str,
) -> ComponentResult:
    agent_id: Optional[str] = props.get("agent_id")
    if not agent_id:
        return ComponentResult(
            success=False,
            error="agent_trigger: agent_id is required but was not provided",
        )

    try:
        from echolib.di import container

        registry = container.resolve("agent.registry")
        factory = container.resolve("agent.factory")

        agent_def = await registry.get_agent_from_db(agent_id, user_id)
        if agent_def is None:
            return ComponentResult(
                success=False,
                error=f"agent_trigger: agent '{agent_id}' not found in database",
            )

        # user_id is required: without it the credential cascade skips the user's
        # own LLM credential and silently falls back to platform secrets.
        instance = factory.create_agent(agent_def, bind_tools=True, user_id=user_id)

        resolved_state = await _resolve_inputs_for_agent(props, data_state, user_id=user_id)
        user_input = _build_agent_input(props, resolved_state)

        logger.info(
            "agent_trigger: running agent '%s' for user '%s'",
            agent_id, user_id,
        )

        # Off-thread: ``chat`` compiles the agent and runs the model round trip
        # synchronously. On the loop thread it stalls every other request, and
        # connector resolution -- which awaits the connector services on that
        # same loop -- cannot complete at all.
        response = await asyncio.to_thread(
            instance.chat, message=user_input, user_id=user_id
        )
        result_text = response.get("content", "") if isinstance(response, dict) else str(response)

        # NEW: Register any generated files and replace markers with download links
        try:
            from .agentic_file_handler import get_file_handler
            
            file_handler = get_file_handler()
            data_key = props.get("data_key", "agent_output")
            
            result_text, file_records = await file_handler.extract_and_register_files(
                result_text,
                data_key,
                user_id,
                chat_session_id=None,  # TODO: pass from component context
                app_id=None,  # TODO: pass from component context
            )
            
            if file_records:
                logger.info(
                    "agent_trigger: registered %d files from agent output",
                    len(file_records)
                )
        except Exception as exc:
            logger.warning("agent_trigger: file registration error (non-fatal): %s", exc)
            # Continue with unsanitized output if file registration fails

        return ComponentResult(success=True, output=result_text)

    except Exception as exc:
        logger.exception("agent_trigger: unexpected error for agent '%s'", agent_id)
        return ComponentResult(success=False, error=f"agent_trigger: {str(exc)}")


# ---------------------------------------------------------------------------
# HANDLER 2 — api_trigger
# ---------------------------------------------------------------------------

def _build_auth_config(auth_type: str, auth_value: Optional[str]) -> Dict[str, Any]:
    auth_type = (auth_type or "no_auth").lower()

    if auth_type in ("no_auth", "none", ""):
        return {"auth_type": "none"}
    elif auth_type == "bearer_token":
        return {"auth_type": "bearer", "token": auth_value or ""}
    elif auth_type == "api_key_header":
        return {"auth_type": "api_key", "key": "X-API-Key", "value": auth_value or "", "add_to": "header"}
    elif auth_type == "api_key_query":
        return {"auth_type": "api_key", "key": "api_key", "value": auth_value or "", "add_to": "query"}
    elif auth_type == "basic":
        parts = (auth_value or ":").split(":", 1)
        return {"auth_type": "basic", "username": parts[0], "password": parts[1] if len(parts) > 1 else ""}

    logger.warning("api_trigger: unknown auth_type '%s', falling back to no_auth", auth_type)
    return {"auth_type": "none"}


async def handle_api_trigger(
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    user_id: str,
) -> ComponentResult:
    method: str = (props.get("method") or "GET").upper()
    raw_url: str = props.get("url") or ""
    auth_type: str = props.get("auth_type") or "no_auth"
    auth_value: Optional[str] = props.get("auth_value")
    custom_headers: Dict[str, str] = props.get("headers") or {}
    raw_body: Any = props.get("body")
    verify_ssl_raw: Any = props.get("verify_ssl", True)
    verify_ssl: bool = (
        verify_ssl_raw
        if isinstance(verify_ssl_raw, bool)
        else str(verify_ssl_raw).strip().lower() not in ("0", "false", "no", "off")
    )

    if not raw_url:
        return ComponentResult(
            success=False,
            error="api_trigger: url is required but was not provided",
        )

    url = _substitute(raw_url, data_state)
    if raw_body is not None:
        raw_body = _substitute_value(raw_body, data_state)

    try:
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError("URL must include scheme and host")
        base_url = f"{parsed.scheme}://{parsed.netloc}"
        endpoint = parsed.path or "/"
        query_string = parsed.query
    except Exception as exc:
        return ComponentResult(
            success=False,
            error=f"api_trigger: invalid URL '{url}': {exc}",
        )

    auth_config = _build_auth_config(auth_type, auth_value)

    default_headers: Dict[str, str] = {}
    if method in ("POST", "PUT", "PATCH"):
        default_headers["Content-Type"] = "application/json"
    if custom_headers:
        default_headers.update(custom_headers)

    try:
        from echolib.connectors.api_service import APIConnectorService

        query_params: Optional[Dict[str, str]] = None
        if query_string:
            from urllib.parse import parse_qs
            raw_params = parse_qs(query_string)
            query_params = {k: v[0] for k, v in raw_params.items()}

        body = None
        if raw_body and method in ("POST", "PUT", "PATCH"):
            if isinstance(raw_body, (dict, list)):
                body = raw_body
            elif isinstance(raw_body, str):
                try:
                    body = json.loads(raw_body)
                except json.JSONDecodeError:
                    body = raw_body
            else:
                body = raw_body

        logger.info("api_trigger: %s %s (user=%s)", method, url, user_id)

        api_config = {
            "connector_id": f"agentic_tmp_{id(props)}",
            "endpoint_url": url,
            "method": method,
            "headers": default_headers,
            "query_params": query_params or {},
            "default_body": body,
            "timeout": 30,
            "verify_ssl": verify_ssl,
            "retry_count": 1,
            "auth_type": auth_config.get("auth_type", "none"),
            "auth_config": auth_config,
        }

        if "type" in api_config["auth_config"] and "auth_type" not in api_config["auth_config"]:
            api_config["auth_config"]["auth_type"] = api_config["auth_config"].pop("type")

        _api_svc = APIConnectorService()
        invoke_result = await _api_svc.invoke_raw(api_config, override_body=body, override_params=query_params)

        if hasattr(invoke_result, "model_dump"):
            result_dict = invoke_result.model_dump()
        else:
            result_dict = invoke_result

        if result_dict.get("success"):
            return ComponentResult(success=True, output=result_dict.get("data"))
        else:
            return ComponentResult(
                success=False,
                error=(
                    f"api_trigger: HTTP {result_dict.get('status_code', '?')} — "
                    f"{result_dict.get('error') or 'request failed'}"
                ),
            )

    except Exception as exc:
        logger.exception("api_trigger: unexpected error for url '%s'", url)
        return ComponentResult(success=False, error=f"api_trigger: {str(exc)}")


# ---------------------------------------------------------------------------
# HANDLER 3 — workflow_trigger
# ---------------------------------------------------------------------------

async def handle_workflow_trigger(
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    user_id: str,
) -> ComponentResult:
    workflow_id: Optional[str] = props.get("workflow_id")
    if not workflow_id:
        return ComponentResult(
            success=False,
            error="workflow_trigger: workflow_id is required but was not provided",
        )

    raw_input_mapping: Dict[str, Any] = props.get("input_mapping") or {}
    input_mapping = _substitute_dict(raw_input_mapping, data_state)
    user_input = _build_agent_input(props, data_state)

    try:
        import asyncio
        from echolib.di import container

        try:
            executor = container.resolve("workflow.executor")
        except Exception:
            return ComponentResult(
                success=False,
                error="workflow_trigger: workflow executor not available (DI resolution failed)",
            )

        input_payload = {
            "user_input": user_input,
            "data_state": {k: v for k, v in data_state.items() if v is not None},
        }
        if input_mapping:
            input_payload["input_mapping"] = input_mapping

        logger.info(
            "workflow_trigger: executing workflow '%s' for user '%s'",
            workflow_id, user_id,
        )

        try:
            from echolib.repositories.storage_gateway import StorageGateway
            gateway: StorageGateway = container.resolve("workflow.storage_gateway")
            workflow_def = await gateway.load_workflow(workflow_id, user_id)
        except Exception:
            workflow_def = None

        loop = asyncio.get_event_loop()

        if workflow_def is not None:
            try:
                result = await loop.run_in_executor(
                    None,
                    lambda: executor.execute_from_definition(
                        workflow_def, "draft", input_payload
                    ),
                )
            except AttributeError:
                result = await loop.run_in_executor(
                    None,
                    lambda: executor.execute_workflow(
                        workflow_id, "draft", None, input_payload
                    ),
                )
        else:
            result = await loop.run_in_executor(
                None,
                lambda: executor.execute_workflow(
                    workflow_id, "draft", None, input_payload
                ),
            )

        if isinstance(result, dict):
            output = result.get("final_output", result.get("output", result))
        elif isinstance(result, str):
            output = result
        else:
            output = str(result)

        return ComponentResult(success=True, output=output)

    except Exception as exc:
        logger.exception(
            "workflow_trigger: unexpected error for workflow '%s'", workflow_id
        )
        return ComponentResult(success=False, error=f"workflow_trigger: {str(exc)}")


# ---------------------------------------------------------------------------
# HANDLER 4 — chat_interface
# Uses echolib.llm_resolver (CurrCloud pattern) instead of LLMManager
# ---------------------------------------------------------------------------

async def handle_chat_interface(
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    user_id: str,
    message: Optional[str] = None,
    history: Optional[List[Dict[str, str]]] = None,
) -> ComponentResult:
    if not message:
        return ComponentResult(
            success=False,
            error="chat_interface: message is required",
        )

    chat_title: str = props.get("chat_title", "AI Assistant")

    try:
        from echolib.llm_resolver import resolve_and_build_llm_sync

        # user_id is required: without it the credential cascade skips Tier 1
        # entirely and every application chat runs on platform secrets rather
        # than the user's own LLM credential.
        llm = resolve_and_build_llm_sync(
            user_id=user_id,
            component="agent_runtime",
        )

        messages: List[Dict[str, str]] = list(history or [])
        messages.append({"role": "user", "content": message})

        logger.info(
            "chat_interface: '%s' — sending message (user=%s)",
            chat_title, user_id,
        )

        response = llm.invoke(messages)
        if hasattr(response, "content"):
            response_text = response.content
        elif isinstance(response, dict):
            response_text = response.get("content", str(response))
        else:
            response_text = str(response)

        return ComponentResult(
            success=True,
            output={
                "role": "assistant",
                "content": response_text,
            },
        )

    except Exception as exc:
        logger.exception("chat_interface: unexpected error")
        return ComponentResult(success=False, error=f"chat_interface: {str(exc)}")


# ---------------------------------------------------------------------------
# Chart HTML post-processor
# ---------------------------------------------------------------------------

CHART_TYPES = {"bar_chart", "line_chart", "pie_chart", "timeline", "status_timeline"}

_CHART_PROMPT = """\
You are a data visualisation assistant. Produce a complete, self-contained HTML page \
that renders a Vega-Lite chart.

STRICT RULES:
1. Return ONLY raw HTML starting with <!DOCTYPE html>. No markdown, no explanation.
2. Use these exact CDN scripts in <head>:
   <script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
   <script src="https://cdn.jsdelivr.net/npm/vega-lite@5"></script>
   <script src="https://cdn.jsdelivr.net/npm/vega-embed@6"></script>
3. Target div: <div id="chart-div" style="width:600px;height:400px;"></div>
4. Embed using: vegaEmbed('#chart-div', spec, {{ actions: false }})
5. The Vega-Lite spec must contain:
   - "$schema": "https://vega.github.io/schema/vega-lite/v5.json"
   - "data": {{"values": [ ...rows from the data below... ]}}
   - "mark" and "encoding" appropriate for the chart type
6. Chart-type rules:
   - bar_chart  → mark "bar",  x = categorical, y = numeric
   - line_chart → mark "line" with point:true
   - pie_chart  → mark "arc",  theta = numeric, color = categorical
   - timeline   → mark "bar" horizontal, x = start, x2 = end, y = label
7. Do NOT apply transforms unless data fields are genuinely temporal strings.
8. Use the exact field names from the data rows.

Chart type: {chart_type}
Data:
{data}

Return only the HTML.
"""


async def render_chart_html(chart_type: str, data: Any) -> str:
    """Call the platform default LLM to turn raw data into a Vega-Lite HTML page."""
    import asyncio
    from .agentic_orchestrator import call_llm

    data_str = json.dumps(data, indent=2) if not isinstance(data, str) else data
    prompt = _CHART_PROMPT.format(
        chart_type=chart_type,
        data=data_str,
    )
    loop = asyncio.get_event_loop()
    html = await loop.run_in_executor(None, call_llm, prompt)

    html = html.strip()
    for fence in ("```html", "```"):
        if html.startswith(fence):
            html = html[len(fence):]
    html = html.rstrip("`").strip()
    return html


# ---------------------------------------------------------------------------
# Central dispatcher
# ---------------------------------------------------------------------------

RUNNABLE_TYPES = {"agent_trigger", "api_trigger", "workflow_trigger", "chat_interface"}


async def dispatch(
    component_type: str,
    props: Dict[str, Any],
    data_state: Dict[str, Any],
    user_id: str,
    chat_message: Optional[str] = None,
    chat_history: Optional[List[Dict[str, str]]] = None,
) -> ComponentResult:
    if component_type == "agent_trigger":
        return await handle_agent_trigger(props, data_state, user_id)
    elif component_type == "api_trigger":
        return await handle_api_trigger(props, data_state, user_id)
    elif component_type == "workflow_trigger":
        return await handle_workflow_trigger(props, data_state, user_id)
    elif component_type == "chat_interface":
        return await handle_chat_interface(
            props, data_state, user_id,
            message=chat_message,
            history=chat_history,
        )
    else:
        return ComponentResult(
            success=False,
            error=f"No handler available for component type '{component_type}'",
        )
