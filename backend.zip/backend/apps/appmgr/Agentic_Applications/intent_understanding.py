"""
Intent understanding for intent-first agentic app creation.

This module intentionally uses lightweight deterministic parsing so the
intent pipeline remains fast, observable, and resilient even when LLM calls
are unavailable.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Set

logger = logging.getLogger(__name__)

_STOPWORDS = {
    "a", "an", "the", "and", "or", "to", "for", "of", "in", "on", "with",
    "is", "are", "be", "it", "this", "that", "i", "we", "you", "my", "our",
}

_APP_TYPE_KEYWORDS = {
    "website": {"website", "landing", "web", "webapp", "site"},
    "dashboard": {"dashboard", "kpi", "metrics", "chart", "analytics"},
    "chat_app": {"chat", "assistant", "qna", "conversation"},
    "workflow_app": {"workflow", "approval", "pipeline", "automation"},
    "data_app": {"data", "analysis", "dataset", "table", "report"},
}

_IMAGE_KEYWORDS = {
    "image", "images", "photo", "photos", "gallery", "visual", "logo", "thumbnail",
    "chart", "graph", "plot",
}

_PRESENTATION_KEYWORDS = {
    "ppt", "pptx", "powerpoint", "presentation", "slides", "slide",
    "deck", "infographic",
}


def _extract_requested_slide_count(text: str) -> int | None:
    if not isinstance(text, str):
        return None

    patterns = [
        r"\b(\d{1,2})\s*[- ]?(?:slide|slides)\b",
        r"\b(?:slide|slides)\s*(?:count\s*)?(?:of\s*)?(\d{1,2})\b",
    ]

    lowered = text.lower()
    for pattern in patterns:
        match = re.search(pattern, lowered)
        if not match:
            continue
        try:
            value = int(match.group(1))
        except Exception:
            continue
        if 1 <= value <= 50:
            return value
    return None


def _keywords(text: str) -> Set[str]:
    if not isinstance(text, str):
        return set()
    tokens = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return {t for t in tokens if len(t) >= 3 and t not in _STOPWORDS}


def understand_intent(*, prompt: str, name: str = "", description: str = "") -> Dict[str, Any]:
    """
    Parse user intent from prompt + optional metadata.

    Returns structured intent with confidence and ambiguity flags for HITL gating.
    """
    full_text = " ".join(x for x in [prompt, name, description] if isinstance(x, str) and x.strip())
    keys = _keywords(full_text)

    score_by_type: Dict[str, int] = {}
    for app_type, app_keys in _APP_TYPE_KEYWORDS.items():
        score_by_type[app_type] = len(keys.intersection(app_keys))

    ranked = sorted(score_by_type.items(), key=lambda kv: kv[1], reverse=True)
    top_type, top_score = ranked[0] if ranked else ("workflow_app", 0)
    second_score = ranked[1][1] if len(ranked) > 1 else 0

    # Ambiguity increases when prompt is short or top classes/or app types are tied.
    short_prompt_penalty = 0.2 if len(full_text.strip()) < 30 else 0.0
    tied_penalty = 0.25 if top_score == second_score else 0.0
    low_signal_penalty = 0.35 if top_score == 0 else 0.0

    ambiguity_score = min(1.0, short_prompt_penalty + tied_penalty + low_signal_penalty)
    confidence = max(0.0, 1.0 - ambiguity_score)

    requires_images = bool(keys.intersection(_IMAGE_KEYWORDS))
    requires_ppt = bool(keys.intersection(_PRESENTATION_KEYWORDS))
    requested_slide_count = _extract_requested_slide_count(full_text) if requires_ppt else None

    lowered_text = full_text.lower()
    prefers_existing_template = requires_ppt and bool(
        re.search(r"\b(existing|present|available|current)\s+template\b", lowered_text)
        or re.search(r"\buse\b.*\btemplate\b", lowered_text)
    )

    missing_details: List[str] = []
    if len(full_text.strip()) < 30:
        missing_details.append("Describe the business goal and primary user task")
    if top_score == 0:
        missing_details.append("Specify whether you need website, dashboard, chat, workflow, or data app")

    intent = {
        "intent_text": full_text,
        "app_type_hint": top_type,
        "confidence": round(confidence, 3),
        "ambiguity_score": round(ambiguity_score, 3),
        "requires_images": requires_images,
        "requires_ppt": requires_ppt,
        "requested_slide_count": requested_slide_count,
        "prefers_existing_template": prefers_existing_template,
        "missing_details": missing_details,
        "keyword_summary": sorted(list(keys))[:40],
        "scores": score_by_type,
    }

    logger.info(
        "intent_understanding: app_type_hint=%s confidence=%.3f ambiguity=%.3f requires_images=%s requires_ppt=%s requested_slide_count=%s prefers_existing_template=%s",
        intent["app_type_hint"],
        intent["confidence"],
        intent["ambiguity_score"],
        intent["requires_images"],
        intent["requires_ppt"],
        intent["requested_slide_count"],
        intent["prefers_existing_template"],
    )
    return intent
