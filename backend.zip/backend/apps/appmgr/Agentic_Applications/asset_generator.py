"""
Asset Generator for Intent-First Agentic App Creation (Phase 5)

Generates agent and workflow definitions from natural language intent when
no suitable existing assets match. Reuses existing designer services and
leverages LLM calls for generation.

Key Design:
- Call designer services directly (not HTTP) to avoid auth/overhead
- Structured error handling with GenerationError exception
- Proper RBAC/user scoping via user_id parameter
- DB session management for persistence
- OTel spans for observability
- KeyVault credentials already in environment
"""

from __future__ import annotations

import asyncio
import logging
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple
from uuid import UUID

from opentelemetry import trace
from echolib.di import container as di_container
from echolib.database import get_db_session
from echolib.credential_resolver import resolve_llm_credential
from echolib.id_utils import normalize_to_uuid
from echolib.repositories.agent_repo import AgentRepository
from echolib.repositories.workflow_repo import WorkflowRepository

logger = logging.getLogger(__name__)
tracer = trace.get_tracer(__name__)


def _resolve_designer(key: str):
    """Resolve a designer from deployed backend DI registrations only."""
    try:
        if key == "agent.designer":
            import apps.agent.container  # noqa: F401
        elif key == "workflow.designer":
            import apps.workflow.container  # noqa: F401
        return di_container.resolve(key)
    except Exception as exc:
        raise AssetGenerationError(
            f"A2UI_DEP_RESOLVE_FAILED: unable to resolve {key}",
            error_code="A2UI_DEP_RESOLVE_FAILED",
            cause=exc,
        )


# ============================================================================
# Error Types
# ============================================================================


class AssetGenerationError(Exception):
    """Base error for asset generation failures."""

    def __init__(self, message: str, error_code: str = "GENERATION_FAILED", cause: Optional[Exception] = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.cause = cause


class AgentGenerationError(AssetGenerationError):
    """Error during agent generation."""

    def __init__(self, message: str, cause: Optional[Exception] = None):
        super().__init__(message, error_code="AGENT_GENERATION_FAILED", cause=cause)


class WorkflowGenerationError(AssetGenerationError):
    """Error during workflow generation."""

    def __init__(self, message: str, cause: Optional[Exception] = None):
        super().__init__(message, error_code="WORKFLOW_GENERATION_FAILED", cause=cause)


# ============================================================================
# Asset Generation Functions
# ============================================================================


async def generate_agent_from_intent(
    *,
    intent_text: str,
    user_id: UUID,
    model: Optional[str] = None,
    icon: Optional[str] = None,
    tools: Optional[list] = None,
    variables: Optional[list] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate an agent definition from natural language intent.

    Uses the existing agent designer service to create a new agent.
    Reuses the proven LLM path from /agents/design/prompt endpoint.

    Args:
        intent_text: User's natural language description of desired agent
        user_id: UUID of the user initiating generation (for RBAC)
        model: Optional LLM model to use (default: gpt-4o-mini)
        icon: Optional agent icon
        tools: Optional list of tool definitions
        variables: Optional list of variable definitions

    Returns:
        Agent definition dict with keys: agent_id, name, description, tools, variables, etc.
        Plus generation_metadata with timestamp and model info.

    Raises:
        AgentGenerationError: If generation fails
    """
    with tracer.start_as_current_span("generate_agent_from_intent") as span:
        span.set_attribute("intent_length", len(intent_text))
        span.set_attribute("user_id", str(user_id))
        span.set_attribute("model", model or "gpt-4o-mini")

        try:
            logger.info(
                "generate_agent_from_intent: start request_id=%s user_id=%s intent_len=%d model=%s",
                request_id,
                str(user_id),
                len(intent_text),
                model or "gpt-4o-mini",
            )

            # Validate intent
            if not intent_text or not intent_text.strip():
                raise AgentGenerationError("Intent text cannot be empty", cause=ValueError("Empty intent"))

            try:
                designer = _resolve_designer("agent.designer")
            except AssetGenerationError as e:
                raise AgentGenerationError(
                    "A2UI_GEN_AGENT_DESIGNER_RESOLVE_FAILED",
                    cause=e.cause or e,
                )

            # Call designer service (runs in thread pool to avoid blocking async)
            start_time = datetime.now(timezone.utc)

            agent, design_meta = await asyncio.to_thread(
                designer.design_from_prompt_with_diagnostics,
                user_prompt=intent_text,
                default_model=model or "gpt-4o-mini",
                icon=icon or "",
                tools=tools or [],
                variables=variables or [],
                user_id=user_id,
            )

            generation_latency_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)

            # Check for fallback (degraded generation)
            if design_meta.get("fallback_used"):
                logger.warning(
                    "generate_agent_from_intent: fallback request_id=%s user_id=%s reason=%s",
                    request_id,
                    str(user_id),
                    design_meta.get("fallback_reason"),
                )
                span.add_event("generation_fallback", {"reason": design_meta.get("fallback_reason")})

            # Enrich with metadata
            result = deepcopy(agent) if isinstance(agent, dict) else agent.model_dump()
            result["generation_metadata"] = {
                "generated_at": start_time.isoformat(),
                "generation_latency_ms": generation_latency_ms,
                "model_used": model or "gpt-4o-mini",
                "fallback_used": design_meta.get("fallback_used", False),
                "fallback_reason": design_meta.get("fallback_reason"),
                "design_meta": design_meta,
            }

            # Persist generated agent immediately so agent_trigger can run
            # against the user's saved agent library.
            persisted_agent = deepcopy(result)
            raw_agent_id = str(persisted_agent.get("agent_id") or "").strip()
            if not raw_agent_id:
                raise AgentGenerationError("Generated agent is missing agent_id")

            normalized_agent_id = normalize_to_uuid(raw_agent_id)
            persisted_agent["agent_id"] = normalized_agent_id

            agent_repo = AgentRepository()
            async with get_db_session() as db:
                await agent_repo.upsert(
                    db=db,
                    user_id=str(user_id),
                    agent_data=persisted_agent,
                )

            result["agent_id"] = normalized_agent_id
            result["persistence"] = {
                "saved_to_db": True,
                "db_agent_id": normalized_agent_id,
            }

            logger.info(
                "generate_agent_from_intent: success request_id=%s user_id=%s agent_id=%s latency_ms=%d model=%s saved_to_db=%s",
                request_id,
                str(user_id),
                result.get("agent_id"),
                generation_latency_ms,
                model or "gpt-4o-mini",
                True,
            )

            span.set_attribute("generation_latency_ms", generation_latency_ms)
            span.set_attribute("fallback_used", design_meta.get("fallback_used", False))

            return result

        except AgentGenerationError:
            raise
        except Exception as e:
            logger.error(
                "generate_agent_from_intent: failed request_id=%s user_id=%s error=%s",
                request_id,
                str(user_id),
                str(e),
                exc_info=True,
            )
            span.record_exception(e)
            raise AgentGenerationError(f"A2UI_GEN_AGENT_FAILED: {str(e)}", cause=e)


async def generate_workflow_from_intent(
    *,
    intent_text: str,
    user_id: UUID,
    model: Optional[str] = None,
    agents: Optional[list] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate a workflow definition from natural language intent.

    Uses the existing workflow designer service to create a new workflow.
    Reuses the proven LLM path from /workflows/design/prompt endpoint.

    Args:
        intent_text: User's natural language description of desired workflow
        user_id: UUID of the user initiating generation (for RBAC)
        model: Optional LLM model config
        agents: Optional list of agents to embed in workflow

    Returns:
        Workflow definition dict with keys: workflow_id, name, description, nodes, etc.
        Plus agents list and generation_metadata.

    Raises:
        WorkflowGenerationError: If generation fails
    """
    with tracer.start_as_current_span("generate_workflow_from_intent") as span:
        span.set_attribute("intent_length", len(intent_text))
        span.set_attribute("user_id", str(user_id))

        try:
            logger.info(
                "generate_workflow_from_intent: start request_id=%s user_id=%s intent_len=%d model=%s",
                request_id,
                str(user_id),
                len(intent_text),
                model or "default",
            )

            # Validate intent
            if not intent_text or not intent_text.strip():
                raise WorkflowGenerationError("Intent text cannot be empty", cause=ValueError("Empty intent"))

            try:
                designer = _resolve_designer("workflow.designer")
            except AssetGenerationError as e:
                raise WorkflowGenerationError(
                    "A2UI_GEN_WORKFLOW_DESIGNER_RESOLVE_FAILED",
                    cause=e.cause or e,
                )

            # WorkflowDesigner expects default_llm as a dict, not a raw string model name.
            workflow_llm_config: Dict[str, Any] | None = None
            if isinstance(model, dict):
                workflow_llm_config = model
            elif isinstance(model, str) and model.strip():
                workflow_llm_config = {
                    "provider": "azure",
                    "model": model.strip(),
                    "temperature": 0.3,
                }

            # Resolve credential id in the current async loop and thread it through
            # designer config to avoid cross-loop async DB access inside sync designer code.
            if user_id:
                try:
                    async with get_db_session() as db:
                        cred = await resolve_llm_credential(db_session=db, user_id=str(user_id))
                    credential_id = (cred or {}).get("credential_id") if isinstance(cred, dict) else None
                    if credential_id:
                        workflow_llm_config = dict(workflow_llm_config or {})
                        workflow_llm_config["credential_id"] = credential_id
                except Exception as e:
                    logger.warning(
                        "generate_workflow_from_intent: credential pre-resolve failed request_id=%s user_id=%s error=%s",
                        request_id,
                        str(user_id),
                        str(e),
                    )

            # Call designer service
            start_time = datetime.now(timezone.utc)

            workflow, generated_agents = await asyncio.to_thread(
                designer.design_from_prompt,
                user_prompt=intent_text,
                default_llm=workflow_llm_config,
                user_id=user_id,
            )

            generation_latency_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)

            # Enrich workflow with metadata
            result = deepcopy(workflow) if isinstance(workflow, dict) else workflow.model_dump()
            result["agents"] = generated_agents or agents or []
            result["generation_metadata"] = {
                "generated_at": start_time.isoformat(),
                "generation_latency_ms": generation_latency_ms,
                "model_used": model or "default",
                "agents_count": len(result.get("agents", [])),
            }

            # Persist generated workflow immediately so workflow_trigger can execute
            # the returned workflow_id without relying on transient designer output.
            persisted_workflow = deepcopy(result)
            wf_id = str(persisted_workflow.get("workflow_id") or "").strip()
            if not wf_id:
                raise WorkflowGenerationError("Generated workflow is missing workflow_id")

            embedded_agents = persisted_workflow.get("agents")
            if isinstance(embedded_agents, dict):
                persisted_workflow["agents"] = [
                    v for v in embedded_agents.values() if isinstance(v, dict)
                ]

            db_workflow_id = normalize_to_uuid(wf_id)
            workflow_repo = WorkflowRepository()
            async with get_db_session() as db:
                await workflow_repo.save_with_agents(
                    db=db,
                    user_id=str(user_id),
                    workflow_data=persisted_workflow,
                    db_workflow_id=db_workflow_id,
                )

            # Keep the response aligned with the persisted shape.
            result["agents"] = persisted_workflow.get("agents", [])
            result["persistence"] = {
                "saved_to_db": True,
                "db_workflow_id": db_workflow_id,
            }

            logger.info(
                "generate_workflow_from_intent: success request_id=%s user_id=%s workflow_id=%s latency_ms=%d agents_count=%d model=%s saved_to_db=%s",
                request_id,
                str(user_id),
                result.get("workflow_id"),
                generation_latency_ms,
                len(result.get("agents", [])),
                model or "default",
                True,
            )

            span.set_attribute("generation_latency_ms", generation_latency_ms)
            span.set_attribute("agents_count", len(result.get("agents", [])))

            return result

        except WorkflowGenerationError:
            raise
        except Exception as e:
            logger.error(
                "generate_workflow_from_intent: failed request_id=%s user_id=%s error=%s",
                request_id,
                str(user_id),
                str(e),
                exc_info=True,
            )
            span.record_exception(e)
            raise WorkflowGenerationError(f"A2UI_GEN_WORKFLOW_FAILED: {str(e)}", cause=e)


async def generate_assets_from_intent(
    *,
    intent: Dict[str, Any],
    user_id: UUID,
    generate_agent: bool = True,
    generate_workflow: bool = True,
    model: Optional[str] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate both agent and workflow assets from intent.

    Coordinates parallel generation of agent and workflow when needed.
    Handles failures gracefully—if one fails, attempts to return the other.

    Args:
        intent: Intent dict from understand_intent() with app_type_hint, etc.
        user_id: UUID of user initiating generation
        generate_agent: Whether to generate agent
        generate_workflow: Whether to generate workflow
        model: Optional LLM model to use

    Returns:
        Dict with keys:
        - agent: Generated agent definition (or None)
        - workflow: Generated workflow definition (or None)
        - agents_for_workflow: Agents embedded in workflow
        - generation_errors: List of any errors that occurred
        - metadata: Overall generation metadata
    """
    with tracer.start_as_current_span("generate_assets_from_intent") as span:
        span.set_attribute("user_id", str(user_id))
        span.set_attribute("generate_agent", generate_agent)
        span.set_attribute("generate_workflow", generate_workflow)

        intent_text = intent.get("intent_text", "")
        logger.info(
            "generate_assets_from_intent: start request_id=%s user_id=%s intent_len=%d generate_agent=%s generate_workflow=%s model=%s",
            request_id,
            str(user_id),
            len(intent_text),
            generate_agent,
            generate_workflow,
            model or "default",
        )

        result = {
            "agent": None,
            "workflow": None,
            "agents_for_workflow": [],
            "generation_errors": [],
            "metadata": {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "intent_text_length": len(intent_text),
                "app_type_hint": intent.get("app_type_hint"),
            },
        }

        # Generate agent if requested
        if generate_agent:
            try:
                agent = await generate_agent_from_intent(
                    intent_text=intent_text,
                    user_id=user_id,
                    model=model,
                    request_id=request_id,
                )
                result["agent"] = agent
                logger.info(
                    "generate_assets_from_intent: agent generated request_id=%s user_id=%s agent_id=%s",
                    request_id,
                    str(user_id),
                    (agent or {}).get("agent_id"),
                )
            except AgentGenerationError as e:
                logger.error(
                    "generate_assets_from_intent: agent generation failed request_id=%s user_id=%s error=%s error_code=%s",
                    request_id,
                    str(user_id),
                    e.message,
                    e.error_code,
                )
                result["generation_errors"].append({"type": "agent", "error": e.message})
                span.add_event("agent_generation_failed", {"error": e.message})

        # Generate workflow if requested
        if generate_workflow:
            try:
                workflow = await generate_workflow_from_intent(
                    intent_text=intent_text,
                    user_id=user_id,
                    model=model,
                    agents=result.get("agent") and [result["agent"]] or [],
                    request_id=request_id,
                )
                result["workflow"] = workflow
                result["agents_for_workflow"] = workflow.get("agents", [])
                logger.info(
                    "generate_assets_from_intent: workflow generated request_id=%s user_id=%s workflow_id=%s",
                    request_id,
                    str(user_id),
                    (workflow or {}).get("workflow_id"),
                )
            except WorkflowGenerationError as e:
                logger.error(
                    "generate_assets_from_intent: workflow generation failed request_id=%s user_id=%s error=%s error_code=%s",
                    request_id,
                    str(user_id),
                    e.message,
                    e.error_code,
                )
                result["generation_errors"].append({"type": "workflow", "error": e.message})
                span.add_event("workflow_generation_failed", {"error": e.message})

        # Log overall result
        has_agent = result.get("agent") is not None
        has_workflow = result.get("workflow") is not None
        has_errors = len(result.get("generation_errors", [])) > 0

        logger.info(
            "generate_assets_from_intent: complete request_id=%s user_id=%s has_agent=%s has_workflow=%s errors=%d",
            request_id,
            str(user_id),
            has_agent,
            has_workflow,
            len(result.get("generation_errors", [])),
        )

        span.set_attribute("agent_generated", has_agent)
        span.set_attribute("workflow_generated", has_workflow)
        span.set_attribute("has_errors", has_errors)

        return result
