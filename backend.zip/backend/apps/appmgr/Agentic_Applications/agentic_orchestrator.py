
"""
EchoAI Agentic Application — LLM Orchestrator

Phase 1 orchestration pipeline:

    1. Parse canvas_config -> extract component inventory
    2. Fetch context from DB only when needed
       - If agent_id already provided on canvas -> fetch just that agent's details
       - If agent_id NOT provided -> fetch all available agents so LLM can pick
       - Same logic for workflows
    3. Build a clear LLM prompt with instructions + canvas + context
    4. Call the platform default LLM (is_default=true)
    5. Parse + validate the LLM response
    6. Resolve/create AI assets when needed
    7. Patch final A2UI JSON with execution bindings
    8. Return the structured result including a2ui_json and final_application_json

The orchestrator does NOT execute any components -- that is Phase 2.
"""

from __future__ import annotations

import copy
import json
import logging
import re
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set, Tuple

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

ExecutionCreateFn = Callable[[Dict[str, Any]], Awaitable[Optional[Dict[str, Any]]]]

PLACEHOLDER_IDS = frozenset(
    {
        "PASTE_YOUR_AGENT_ID_HERE",
        "PASTE_AGENT_ID_HERE",
        "YOUR_AGENT_ID",
        "AGENT_ID",
        "TODO",
        "TBD",
        "NULL",
        "NONE",
    }
)


def _is_placeholder_id(value: Any) -> bool:
    if value is None:
        return True
    if not isinstance(value, str):
        return False
    v = value.strip()
    if v == "":
        return True
    return v.upper() in PLACEHOLDER_IDS


_STOPWORDS = frozenset(
    {
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "but",
        "by",
        "for",
        "from",
        "has",
        "have",
        "if",
        "in",
        "into",
        "is",
        "it",
        "its",
        "of",
        "on",
        "or",
        "our",
        "so",
        "that",
        "the",
        "their",
        "then",
        "this",
        "to",
        "with",
        "you",
        "your",
    }
)


def _keywords(text: str) -> Set[str]:
    if not isinstance(text, str):
        return set()
    tokens = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return {t for t in tokens if len(t) >= 3 and t not in _STOPWORDS}


def _agent_text(agent: Dict[str, Any]) -> str:
    if not isinstance(agent, dict):
        return ""
    return " ".join(
        str(x)
        for x in (
            agent.get("name", ""),
            agent.get("role", ""),
            agent.get("description", ""),
        )
        if x is not None
    )


def _app_intent_text(canvas_config: List[Dict[str, Any]]) -> str:
    """
    Extract lightweight app intent hints from the canvas itself.
    We don't have name/description here, so we use common label/text fields.
    """
    parts: List[str] = []
    for c in canvas_config:
        if not isinstance(c, dict):
            continue
        props = c.get("props") or {}
        for key in ("text", "content", "label", "title", "placeholder", "url"):
            val = props.get(key)
            if isinstance(val, str) and val.strip():
                parts.append(val.strip())
    return " ".join(parts[:50])


def _is_agent_relevant(app_text: str, agent: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Very conservative heuristic: require at least 1 shared keyword between
    the app intent text and the agent name/role/description.
    """
    a = _keywords(app_text)
    b = _keywords(_agent_text(agent))
    overlap = a.intersection(b)
    if overlap:
        return True, f"keyword overlap {sorted(list(overlap))[:5]}"
    return False, "no keyword overlap"


# ---------------------------------------------------------------------------
# A2UI format spec -- compact reference injected into prompt
# ---------------------------------------------------------------------------

A2UI_SPEC = """\
A2UI JSON format:
{
  "components": [
    { "id": "unique_id", "component": { "ComponentType": { ...props... } } }
  ],
  "data": { "only_dynamic_keys": null }
}

Available component types:
- Column: { children: { explicitList: ["id1","id2"] }, alignment: "center"|"start"|"end" }
- Row: { children: { explicitList: ["id1","id2"] }, distribution: "spaceAround"|"spaceBetween" }
- Card: { child: "child_id" }
- Text: { text: { literalString: "static" } OR { path: "/data_key" }, usageHint: "h1"|"h2"|"h3"|"body"|"caption" }
- TextField: { label: { literalString: "Label" }, placeholder: "hint", dataPath: "/data_key" }
- FileField: {
    label: { literalString: "Upload" },
    dataPath: "/data_key",
    accept: [".pdf", ".png"],
    maxSizeMb: 5
  }
  Use FileField for canvas type file_upload ONLY — never use TextField for files.
- Button: { label: { literalString: "Run" }, primary: true, actionId: "data_key_of_trigger" }
- Select: { label: { literalString: "Choose" }, options: ["a","b"], dataPath: "/data_key" }
- CheckBox: { label: { literalString: "Toggle" }, checked: { path: "/data_key" } }
- BarChart: { dataPath: "/data_key", title: { literalString: "Title" } }
- LineChart: { dataPath: "/data_key", title: { literalString: "Title" } }
- PieChart: { dataPath: "/data_key", title: { literalString: "Title" } }
- DataTable: { dataPath: "/data_key", title: { literalString: "Title" } }
- Markdown: { content: { path: "/data_key" } }
- MetricCard: { label: { literalString: "KPI" }, value: { path: "/data_key" } }
- Image: { src: { literalString: "url" } OR { path: "/data_key" } }
- Divider: {}
- Spacer: { height: 16 }

STRUCTURAL RULES — follow these exactly:

1. ALWAYS start with a root Column that wraps the entire app.
   The root component must have id "root" and contain all other top-level sections.

2. Group components into logical sections using Card or Column:
   - Input section: all user input fields together (TextField, Select, CheckBox etc.)
   - Action section: trigger buttons (api_trigger, agent_trigger, workflow_trigger)
   - Output section: display components (DataTable, Markdown, BarChart, MetricCard etc.)
   Use Card to visually separate sections. Use Column inside Card for vertical stacking.
   Use Row for side-by-side items (e.g. two metric cards or two buttons next to each other).

3. Order sections top-to-bottom matching the canvas Y position order:
   - Lowest Y value = appears first (top of page)
   - Highest Y value = appears last (bottom of page)

4. DATA DICT RULES — critical:
   INCLUDE in data dict: keys that receive runtime values at runtime
     - Output keys: on_success_key values from api_trigger, agent_trigger, workflow_trigger
     - Input keys: data_key of input components (short_text, file_upload, select etc.)
   DO NOT INCLUDE in data dict: static layout component keys
     - Never include: heading, label, divider, spacer, submit_button, card_container data_keys

5. Component rendering rules:
   - api_trigger, agent_trigger, workflow_trigger -> render as Button (actionId = component props.data_key)
   - submit_button -> render as Button (actionId = component props.data_key); use primary: true only if this is the main final action
   - chat_interface -> render as Column containing a Markdown (for history) and a TextField and Button
   - heading -> render as Text with appropriate usageHint (h1/h2/h3)
   - label -> render as Text with usageHint "body" or "caption"
   - short_text, number, text_area -> TextField with dataPath /data_key
   - file_upload -> FileField (NOT TextField) with dataPath /data_key; copy accept + maxSizeMb from canvas props when present
   - Display components (markdown, bar_chart, data_table, metric_card etc.) -> bind to /data_key from canvas (usually the on_success_key of the upstream trigger)
   - If a metric_card or other display uses a data_key that is not any trigger's on_success_key, still bind it and include that key in data — the same agent run may populate multiple keys (e.g. analysis text + risk score)

6. Button primary flag: prefer at most ONE primary: true button in the whole surface (the main submit). Set primary: false on secondary actions (e.g. prefetch API).

7. Every id referenced in children.explicitList must have its own entry in the components array.
   Never reference an id that does not exist as a component.
"""


# ---------------------------------------------------------------------------
# Canvas component type reference -- short version for prompt
# ---------------------------------------------------------------------------

CANVAS_TYPES = """\
Canvas component types:
LAYOUT: heading, label, divider, spacer, card_container, submit_button
INPUT: short_text, text_area, number, select, multi_select, slider, toggle, date_picker, file_upload, star_rating
DISPLAY: bar_chart, line_chart, pie_chart, data_table, markdown, timeline, metric_card, image
INTERACTION:
  api_trigger     - HTTP API call. props: method, url, auth_type, auth_value, body, input_keys, on_success_key
  agent_trigger   - runs an AI agent. props: agent_id (optional), input_keys, on_success_key
  workflow_trigger- runs a workflow. props: workflow_id (optional), input_mapping, on_success_key
  chat_interface  - conversational AI chat. props: chat_title, welcome_message

Data flow:
  input_keys     = list of data_keys this trigger reads as input
  on_success_key = data_key of the display component that receives this trigger output
"""


# ---------------------------------------------------------------------------
# Step 1 -- Parse canvas config into a component inventory
# ---------------------------------------------------------------------------

def parse_canvas_inventory(canvas_config: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Extract key signals from canvas_config.
    Returns a clean inventory dict used for DB fetching and prompt building.
    """
    interaction_types = {"api_trigger", "agent_trigger", "workflow_trigger", "chat_interface"}

    inventory = {
        "interaction_components": [],
        "agents_provided": [],
        "workflows_provided": [],
        "needs_agent_selection": False,
        "needs_workflow_selection": False,
    }

    sorted_canvas = sorted(canvas_config, key=lambda c: c.get("y", 0))

    for comp in sorted_canvas:
        ctype = comp.get("type", "")
        if ctype not in interaction_types:
            continue

        props = comp.get("props") or {}
        data_key = props.get("data_key", comp.get("id"))

        entry = {
            "id": comp.get("id"),
            "type": ctype,
            "data_key": data_key,
            "input_keys": props.get("input_keys", []),
            "on_success_key": props.get("on_success_key"),
        }

        if ctype == "agent_trigger":
            agent_id = props.get("agent_id")
            entry["agent_id"] = agent_id
            entry["agent_id_provided"] = not _is_placeholder_id(agent_id)
            if entry["agent_id_provided"]:
                inventory["agents_provided"].append(agent_id)
            else:
                inventory["needs_agent_selection"] = True

        elif ctype == "workflow_trigger":
            wf_id = props.get("workflow_id")
            entry["workflow_id"] = wf_id
            entry["workflow_id_provided"] = not _is_placeholder_id(wf_id)
            if entry["workflow_id_provided"]:
                inventory["workflows_provided"].append(wf_id)
            else:
                inventory["needs_workflow_selection"] = True

        elif ctype == "api_trigger":
            entry["method"] = props.get("method", "GET")
            entry["url"] = props.get("url", "")

        inventory["interaction_components"].append(entry)

    return inventory


_TRIGGER_TYPES = {"submit_button", "api_trigger", "agent_trigger", "workflow_trigger"}
_AI_COMPONENT_TYPES = {"agent_trigger", "workflow_trigger", "chat_interface"}


def build_orchestration_planner(
    canvas_config: List[Dict[str, Any]],
    app_name: str = "",
    app_description: str = "",
    inventory: Optional[Dict[str, Any]] = None,
    db_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Build a planner snapshot aligned with the orchestration workflow.
    """
    inv = inventory or parse_canvas_inventory(canvas_config)
    component_types = {
        str(c.get("type") or "").strip()
        for c in (canvas_config or [])
        if isinstance(c, dict)
    }
    prompt_signal = " ".join([app_name or "", app_description or "", _app_intent_text(canvas_config)]).strip()

    context = db_context or {}
    mode = context.get("mode") or {}
    existing_agents_count = len(context.get("agents") or [])
    existing_workflows_count = len(context.get("workflows") or [])

    ai_required = bool(component_types.intersection(_AI_COMPONENT_TYPES))
    frontend_required = True

    agent_mode = str(mode.get("agents") or ("choose" if inv.get("needs_agent_selection") else "selected"))
    workflow_mode = str(mode.get("workflows") or ("choose" if inv.get("needs_workflow_selection") else "selected"))

    def _resolution(mode_value: str, needs_selection: bool, existing_count: int) -> str:
        if mode_value == "none":
            return "not_required"
        if mode_value == "selected" or not needs_selection:
            return "use_provided"
        if existing_count > 0:
            return "reuse_existing"
        return "create_new_if_missing"

    prompt_lower = prompt_signal.lower()
    if "chat" in prompt_lower or "assistant" in prompt_lower:
        inferred_goal = "conversational_agentic_app"
    elif "workflow" in prompt_lower:
        inferred_goal = "workflow_orchestration_app"
    elif "dashboard" in prompt_lower or "report" in prompt_lower:
        inferred_goal = "analysis_dashboard_app"
    else:
        inferred_goal = "general_agentic_app"

    return {
        "intent_goal": {"inferred_goal": inferred_goal, "prompt_signal": prompt_signal[:500]},
        "backend_plan": [
            {"stage": "intent_goal_understanding", "step": "B"},
            {"stage": "backend_plan_creation", "step": "C"},
            {"stage": "ai_required_gate", "step": "C1", "value": ai_required},
            {"stage": "agent_workflow_resolution", "step": "D"},
            {"stage": "frontend_required_gate", "step": "F", "value": frontend_required},
            {"stage": "a2ui_generation", "step": "G_G1"},
            {"stage": "binding_injection", "step": "H_J_J1"},
            {"stage": "finalize_publish_persist", "step": "K_L_M"},
        ],
        "resolution_strategy": {
            "agent": _resolution(agent_mode, bool(inv.get("needs_agent_selection")), existing_agents_count),
            "workflow": _resolution(workflow_mode, bool(inv.get("needs_workflow_selection")), existing_workflows_count),
        },
        "context_signals": {
            "agent_mode": agent_mode,
            "workflow_mode": workflow_mode,
            "existing_agents_count": existing_agents_count,
            "existing_workflows_count": existing_workflows_count,
        },
        "gates": {"ai_required": ai_required, "frontend_required": frontend_required},
    }


def build_workflow_decisions(canvas_config: List[Dict[str, Any]], orchestration_metadata: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    component_types = {str(c.get("type") or "").strip() for c in (canvas_config or []) if isinstance(c, dict)}
    selected_agents = (orchestration_metadata or {}).get("selected_agents") or []
    selected_workflows = (orchestration_metadata or {}).get("selected_workflows") or []

    ai_required = bool(component_types.intersection(_AI_COMPONENT_TYPES) or selected_agents or selected_workflows)

    return {
        "ai_required": ai_required,
        "frontend_required": True,
        "decision_basis": {
            "component_types": sorted([t for t in component_types if t]),
            "selected_agents_count": len(selected_agents),
            "selected_workflows_count": len(selected_workflows),
        },
    }


def build_action_bindings(canvas_config: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[str]]:
    bindings: List[Dict[str, Any]] = []
    errors: List[str] = []

    for comp in canvas_config or []:
        if not isinstance(comp, dict):
            continue

        comp_id = str(comp.get("id") or "").strip()
        comp_type = str(comp.get("type") or "").strip()
        props = comp.get("props") or {}
        data_key = str(props.get("data_key") or comp_id).strip()

        if comp_type in _TRIGGER_TYPES:
            if not data_key:
                errors.append(f"Component '{comp_id or '<unknown>'}' of type '{comp_type}' is missing data_key")
                continue

            bindings.append(
                {
                    "action_id": data_key,
                    "component_id": comp_id,
                    "component_type": comp_type,
                    "execution_mode": "run_stream",
                    "endpoint": "/api/applications/agentic/run/stream",
                    "payload_contract": {
                        "agentic_app_id": "uuid",
                        "inputs": "object",
                        "triggered_components": "string[]",
                        "chat_message": "optional string",
                        "chat_history": "optional object[]",
                    },
                }
            )

        if comp_type == "chat_interface":
            chat_action = f"{data_key}_send" if data_key else ""
            if not chat_action:
                errors.append(f"Chat interface '{comp_id or '<unknown>'}' is missing data_key")
                continue

            bindings.append(
                {
                    "action_id": chat_action,
                    "component_id": comp_id,
                    "component_type": comp_type,
                    "execution_mode": "chat_stream",
                    "endpoint": "/api/applications/agentic/chat",
                    "payload_contract": {
                        "agentic_app_id": "uuid",
                        "component_id": "string",
                        "message": "string",
                        "session_id": "optional string",
                        "data_state": "object",
                        "chat_history": "optional object[]",
                    },
                }
            )

    by_action: Dict[str, List[Dict[str, Any]]] = {}
    for b in bindings:
        aid = str(b.get("action_id") or "").strip()
        if aid:
            by_action.setdefault(aid, []).append(b)

    for aid, rows in by_action.items():
        if len(rows) > 1:
            errors.append(f"Duplicate action binding for action_id '{aid}'")

    return bindings, errors


def validate_action_bindings(canvas_config: List[Dict[str, Any]], bindings: List[Dict[str, Any]]) -> List[str]:
    required_actions: Set[str] = set()
    for comp in canvas_config or []:
        if not isinstance(comp, dict):
            continue
        ctype = str(comp.get("type") or "").strip()
        if ctype not in _TRIGGER_TYPES:
            continue
        props = comp.get("props") or {}
        comp_id = str(comp.get("id") or "").strip()
        action_id = str(props.get("data_key") or comp_id).strip()
        if action_id:
            required_actions.add(action_id)

    bound_actions = {str(b.get("action_id") or "").strip() for b in (bindings or []) if isinstance(b, dict)}
    missing = sorted([aid for aid in required_actions if aid not in bound_actions])
    return [f"Missing action binding for '{aid}'" for aid in missing]


# ---------------------------------------------------------------------------
# Final execution wiring helpers
# ---------------------------------------------------------------------------

def determine_frontend_type(canvas_config: List[Dict[str, Any]], parsed: Optional[Dict[str, Any]] = None) -> str:
    component_types = {str(c.get("type") or "").strip() for c in (canvas_config or []) if isinstance(c, dict)}
    app_type = str((parsed or {}).get("app_type") or "").lower()

    if "chat_interface" in component_types or "chat" in app_type:
        return "chat"
    if component_types.intersection({"bar_chart", "line_chart", "pie_chart", "metric_card", "data_table"}):
        return "dashboard"
    if component_types.intersection({"short_text", "text_area", "number", "select", "multi_select", "slider", "toggle", "date_picker", "file_upload", "star_rating"}):
        return "form"
    if "workflow_trigger" in component_types or "workflow" in app_type:
        return "workflow_ui"
    if component_types.intersection(_AI_COMPONENT_TYPES):
        return "agentic_ui"
    return "generic"


def _select_primary_asset_id(items: Any, id_key: str) -> Optional[str]:
    if not isinstance(items, list):
        return None
    for item in items:
        if not isinstance(item, dict):
            continue
        value = item.get(id_key)
        if isinstance(value, str) and value.strip() and not _is_placeholder_id(value):
            return value.strip()
    return None


def _selection_maps(parsed: Dict[str, Any]) -> Tuple[Dict[str, str], Dict[str, str]]:
    agent_map: Dict[str, str] = {}
    workflow_map: Dict[str, str] = {}

    for row in parsed.get("selected_agents") or []:
        if not isinstance(row, dict):
            continue
        data_key = row.get("component_data_key")
        agent_id = row.get("agent_id")
        if isinstance(data_key, str) and data_key.strip() and isinstance(agent_id, str) and agent_id.strip() and not _is_placeholder_id(agent_id):
            agent_map[data_key.strip()] = agent_id.strip()

    for row in parsed.get("selected_workflows") or []:
        if not isinstance(row, dict):
            continue
        data_key = row.get("component_data_key")
        workflow_id = row.get("workflow_id")
        if isinstance(data_key, str) and data_key.strip() and isinstance(workflow_id, str) and workflow_id.strip() and not _is_placeholder_id(workflow_id):
            workflow_map[data_key.strip()] = workflow_id.strip()

    return agent_map, workflow_map


def _build_execution_endpoint(target_type: str, target_id: str) -> str:
    tt = str(target_type or "").strip().lower()
    if tt == "agent":
        return f"/execute/agent/{target_id}"
    if tt == "workflow":
        return f"/execute/workflow/{target_id}"
    raise ValueError(f"Unsupported execution target_type='{target_type}'")


async def resolve_or_create_ai_assets(
    *,
    parsed: Dict[str, Any],
    workflow_decisions: Dict[str, Any],
    create_agent_fn: Optional[ExecutionCreateFn] = None,
    create_workflow_fn: Optional[ExecutionCreateFn] = None,
) -> Dict[str, Any]:
    parsed_out = copy.deepcopy(parsed or {})
    decisions = copy.deepcopy(workflow_decisions or {})

    ai_required = bool(decisions.get("ai_required"))
    resolved_agent_id = _select_primary_asset_id(parsed_out.get("selected_agents"), "agent_id")
    resolved_workflow_id = _select_primary_asset_id(parsed_out.get("selected_workflows"), "workflow_id")

    pending_asset_creation: List[Dict[str, str]] = []

    if ai_required and not resolved_agent_id and create_agent_fn is not None:
        try:
            created_agent = await create_agent_fn(parsed_out)
            if isinstance(created_agent, dict):
                created_agent_id = _select_primary_asset_id([created_agent], "agent_id")
                if created_agent_id:
                    parsed_out.setdefault("selected_agents", []).append(created_agent)
                    resolved_agent_id = created_agent_id
        except Exception as exc:
            logger.exception("resolve_or_create_ai_assets: create_agent_fn failed")
            pending_asset_creation.append({"asset_type": "agent", "status": "creation_failed", "reason": str(exc)})

    if ai_required and not resolved_workflow_id and create_workflow_fn is not None:
        try:
            created_workflow = await create_workflow_fn(parsed_out)
            if isinstance(created_workflow, dict):
                created_workflow_id = _select_primary_asset_id([created_workflow], "workflow_id")
                if created_workflow_id:
                    parsed_out.setdefault("selected_workflows", []).append(created_workflow)
                    resolved_workflow_id = created_workflow_id
        except Exception as exc:
            logger.exception("resolve_or_create_ai_assets: create_workflow_fn failed")
            pending_asset_creation.append({"asset_type": "workflow", "status": "creation_failed", "reason": str(exc)})

    if ai_required and not resolved_agent_id:
        pending_asset_creation.append({"asset_type": "agent", "status": "unresolved"})
    if ai_required and not resolved_workflow_id:
        pending_asset_creation.append({"asset_type": "workflow", "status": "unresolved"})

    decisions["resolved_agent_id"] = resolved_agent_id
    decisions["resolved_workflow_id"] = resolved_workflow_id
    decisions["pending_asset_creation"] = pending_asset_creation

    parsed_out["workflow_decisions"] = decisions
    return parsed_out


def patch_action_bindings(action_bindings: List[Dict[str, Any]], parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
    patched: List[Dict[str, Any]] = []
    agent_map, workflow_map = _selection_maps(parsed)

    for binding in action_bindings or []:
        if not isinstance(binding, dict):
            patched.append(binding)
            continue

        row = copy.deepcopy(binding)
        action_id = str(row.get("action_id") or "").strip()

        if action_id in agent_map:
            agent_id = agent_map[action_id]
            row["execution_target"] = {"type": "agent", "agent_id": agent_id}
            row["execution_mode"] = "agent_execute"
            row["endpoint"] = _build_execution_endpoint("agent", agent_id)
        elif action_id in workflow_map:
            workflow_id = workflow_map[action_id]
            row["execution_target"] = {"type": "workflow", "workflow_id": workflow_id}
            row["execution_mode"] = "workflow_execute"
            row["endpoint"] = _build_execution_endpoint("workflow", workflow_id)

        patched.append(row)

    return patched


def patch_a2ui_execution_bindings(a2ui_json: Dict[str, Any], parsed: Dict[str, Any]) -> Dict[str, Any]:
    patched = copy.deepcopy(a2ui_json or {})
    components = patched.get("components")
    if not isinstance(components, list):
        return patched

    agent_map, workflow_map = _selection_maps(parsed)

    for comp in components:
        if not isinstance(comp, dict):
            continue
        node = comp.get("component")
        if not isinstance(node, dict):
            continue
        button = node.get("Button")
        if not isinstance(button, dict):
            continue
        action_id = str(button.get("actionId") or "").strip()
        if not action_id:
            continue

        if action_id in agent_map:
            agent_id = agent_map[action_id]
            button["executionTarget"] = {"type": "agent", "agent_id": agent_id}
            button["on_click"] = {"type": "api_call", "method": "POST", "endpoint": _build_execution_endpoint("agent", agent_id)}
        elif action_id in workflow_map:
            workflow_id = workflow_map[action_id]
            button["executionTarget"] = {"type": "workflow", "workflow_id": workflow_id}
            button["on_click"] = {"type": "api_call", "method": "POST", "endpoint": _build_execution_endpoint("workflow", workflow_id)}

    return patched


def build_final_application_json(parsed: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "app_type": parsed.get("app_type"),
        "reasoning": parsed.get("reasoning"),
        "selected_agents": copy.deepcopy(parsed.get("selected_agents") or []),
        "selected_workflows": copy.deepcopy(parsed.get("selected_workflows") or []),
        "selected_skills": copy.deepcopy(parsed.get("selected_skills") or []),
        "selected_persona": copy.deepcopy(parsed.get("selected_persona") or {}),
        "workflow_planner": copy.deepcopy(parsed.get("workflow_planner") or {}),
        "workflow_decisions": copy.deepcopy(parsed.get("workflow_decisions") or {}),
        "action_bindings": copy.deepcopy(parsed.get("action_bindings") or []),
        "a2ui_json": copy.deepcopy(parsed.get("a2ui_json") or {}),
    }


# ---------------------------------------------------------------------------
# Step 2 -- Fetch context from DB (only what is needed)
# ---------------------------------------------------------------------------

async def fetch_db_context(db: AsyncSession, user_id: str, inventory: Dict[str, Any]) -> Dict[str, Any]:
    from echolib.models.agent import Agent as AgentModel
    from echolib.models.workflow import Workflow as WorkflowModel
    from echolib.repositories.base import safe_uuid
    from echolib.repositories.storage_gateway import StorageGateway
    from echolib.repositories.workflow_repo import WorkflowRepository

    has_agent_trigger = any(c["type"] == "agent_trigger" for c in inventory["interaction_components"])
    has_workflow_trigger = any(c["type"] == "workflow_trigger" for c in inventory["interaction_components"])

    agent_mode = "none" if not has_agent_trigger else "selected" if inventory["agents_provided"] and not inventory["needs_agent_selection"] else "choose"
    workflow_mode = "none" if not has_workflow_trigger else "selected" if inventory["workflows_provided"] and not inventory["needs_workflow_selection"] else "choose"

    context: Dict[str, Any] = {"agents": [], "workflows": [], "skills": [], "personas": [], "mode": {"agents": agent_mode, "workflows": workflow_mode}}

    user_uuid = safe_uuid(user_id)
    if user_uuid is None:
        return context

    discovery_gateway = StorageGateway()
    workflow_repo = WorkflowRepository()

    if agent_mode != "none":
        try:
            if agent_mode == "selected":
                agent_uuids = [safe_uuid(aid) for aid in inventory["agents_provided"] if safe_uuid(aid)]
                stmt = select(AgentModel).where(AgentModel.agent_id.in_(agent_uuids), AgentModel.is_deleted == False)  # noqa: E712
                result = await db.execute(stmt)
                for agent in result.scalars().all():
                    defn = agent.definition or {}
                    context["agents"].append({
                        "agent_id": str(agent.agent_id),
                        "name": agent.name,
                        "role": defn.get("role", ""),
                        "description": defn.get("description", defn.get("backstory", "")),
                    })
            else:
                discovered_agents = await discovery_gateway.list_agents(str(user_uuid))
                for item in discovered_agents:
                    if not isinstance(item, dict):
                        continue
                    agent_id = str(item.get("agent_id") or "").strip()
                    if not agent_id:
                        continue
                    context["agents"].append(
                        {
                            "agent_id": agent_id,
                            "name": str(item.get("name") or "").strip() or "Unnamed Agent",
                            "role": str(item.get("role") or "").strip(),
                            "description": str(
                                item.get("description")
                                or item.get("backstory")
                                or ((item.get("definition") or {}).get("description") if isinstance(item.get("definition"), dict) else "")
                                or ""
                            ).strip(),
                        }
                    )

                # Fallback to direct DB select if discovery source is empty.
                if not context["agents"]:
                    stmt = select(AgentModel).where(AgentModel.user_id == user_uuid, AgentModel.is_deleted == False)  # noqa: E712
                    result = await db.execute(stmt)
                    for agent in result.scalars().all():
                        defn = agent.definition or {}
                        context["agents"].append({
                            "agent_id": str(agent.agent_id),
                            "name": agent.name,
                            "role": defn.get("role", ""),
                            "description": defn.get("description", defn.get("backstory", "")),
                        })
        except Exception as exc:
            logger.warning("fetch_db_context: agent query failed: %s", exc)

    if workflow_mode != "none":
        try:
            if workflow_mode == "selected":
                wf_uuids = [safe_uuid(wid) for wid in inventory["workflows_provided"] if safe_uuid(wid)]
                stmt = select(WorkflowModel).where(WorkflowModel.workflow_id.in_(wf_uuids), WorkflowModel.is_deleted == False)  # noqa: E712
                result = await db.execute(stmt)
                for wf in result.scalars().all():
                    defn = wf.definition or {}
                    context["workflows"].append({
                        "workflow_id": str(wf.workflow_id),
                        "name": wf.name,
                        "description": defn.get("description", ""),
                        "status": wf.status,
                    })
            else:
                discovered_workflows = await workflow_repo.list_by_user(
                    db,
                    str(user_uuid),
                    limit=500,
                )
                for wf in discovered_workflows:
                    defn = wf.definition or {}
                    context["workflows"].append(
                        {
                            "workflow_id": str(wf.workflow_id),
                            "name": wf.name,
                            "description": defn.get("description", ""),
                            "status": wf.status,
                        }
                    )

                # Fallback to direct DB select if discovery source is empty.
                if not context["workflows"]:
                    stmt = select(WorkflowModel).where(WorkflowModel.user_id == user_uuid, WorkflowModel.is_deleted == False)  # noqa: E712
                    result = await db.execute(stmt)
                    for wf in result.scalars().all():
                        defn = wf.definition or {}
                        context["workflows"].append({
                            "workflow_id": str(wf.workflow_id),
                            "name": wf.name,
                            "description": defn.get("description", ""),
                            "status": wf.status,
                        })
        except Exception as exc:
            logger.warning("fetch_db_context: workflow query failed: %s", exc)

    try:
        from echolib.models.workflow import Workflow as WorkflowModel2
        from echolib.models.agent import Agent as AgentModel2

        wf_stmt = select(WorkflowModel2).where(WorkflowModel2.user_id == user_uuid, WorkflowModel2.status != "archived", WorkflowModel2.is_deleted == False).order_by(WorkflowModel2.name)  # noqa: E712
        wf_result = await db.execute(wf_stmt)
        for wf in wf_result.scalars().all():
            defn = wf.definition or {}
            context["skills"].append({"skill_id": str(wf.workflow_id), "skill_type": "workflow", "name": wf.name, "description": defn.get("description", "")})

        agt_stmt = select(AgentModel2).where(AgentModel2.user_id == user_uuid, AgentModel2.is_deleted == False).order_by(AgentModel2.name)  # noqa: E712
        agt_result = await db.execute(agt_stmt)
        for agt in agt_result.scalars().all():
            defn = agt.definition or {}
            # description is authoritative; role is a legacy fallback only.
            context["skills"].append({"skill_id": str(agt.agent_id), "skill_type": "agent", "name": agt.name, "description": defn.get("description") or defn.get("role", "")})
    except Exception as exc:
        logger.warning("fetch_db_context: skills query failed: %s", exc)

    try:
        from echolib.models.application_lookups import AppPersona
        persona_stmt = select(AppPersona).order_by(AppPersona.name)
        persona_result = await db.execute(persona_stmt)
        for persona in persona_result.scalars().all():
            context["personas"].append({"persona_id": str(persona.persona_id), "name": persona.name, "description": persona.description or ""})
    except Exception as exc:
        logger.warning("fetch_db_context: personas query failed: %s", exc)

    return context


# ---------------------------------------------------------------------------
# Step 3 -- Build the LLM prompt
# ---------------------------------------------------------------------------

def build_prompt(canvas_config: List[Dict[str, Any]], inventory: Dict[str, Any], db_context: Dict[str, Any]) -> str:
    agent_mode = db_context["mode"]["agents"]
    if agent_mode == "none":
        agent_section = "No agent_trigger components in this canvas. Skip agent selection."
    elif agent_mode == "selected":
        agent_section = (
            "The user has already selected the agent on the canvas. "
            "Use the exact agent_id values already in the canvas JSON. "
            "Agent details for your reference:\n" + json.dumps(db_context["agents"], indent=2)
        )
    else:
        if db_context["agents"]:
            agent_section = (
                "The user has NOT selected an agent. "
                "Choose the best matching agent from this list based on what the app does:\n"
                + json.dumps(db_context["agents"], indent=2)
            )
        else:
            agent_section = (
                "The user has NOT selected an agent and no agents exist in the system yet. "
                "Set selected_agents to [] and mention this in reasoning."
            )

    wf_mode = db_context["mode"]["workflows"]
    if wf_mode == "none":
        workflow_section = "No workflow_trigger components in this canvas. Skip workflow selection."
    elif wf_mode == "selected":
        workflow_section = (
            "The user has already selected the workflow on the canvas. "
            "Use the exact workflow_id values already in the canvas JSON. "
            "Workflow details for reference:\n" + json.dumps(db_context["workflows"], indent=2)
        )
    else:
        if db_context["workflows"]:
            workflow_section = (
                "The user has NOT selected a workflow. "
                "Choose the best matching workflow from this list:\n"
                + json.dumps(db_context["workflows"], indent=2)
            )
        else:
            workflow_section = (
                "The user has NOT selected a workflow and no workflows exist in the system yet. "
                "Set selected_workflows to [] and mention this in reasoning."
            )

    if db_context.get("skills"):
        skills_section = (
            "These are the available skills in the system (agents and workflows). "
            "Select which ones this application needs based on its components and purpose:\n"
            + json.dumps(db_context["skills"], indent=2)
        )
    else:
        skills_section = "No skills are available in the system yet. Set selected_skills to []."

    if db_context.get("personas"):
        persona_section = (
            "These are the available personas. "
            "Select the one that best fits the tone and purpose of this application:\n"
            + json.dumps(db_context["personas"], indent=2)
        )
    else:
        persona_section = (
            "No personas are available in the system yet. "
            "Suggest a suitable persona name in selected_persona even if it does not exist."
        )

    prompt = (
        "You are an AI application architect for EchoAI, a no-code visual app builder.\n\n"
        "A user has built an application on a drag-and-drop canvas. They placed components, "
        "configured their properties, and connected them using data keys.\n\n"
        "Your job:\n"
        "1. Read the canvas JSON the user built\n"
        "2. Understand what kind of web application they are creating\n"
        "3. Select the best agent, workflow, skills, and persona from the available options\n"
        "4. Determine the correct data flow — which component output goes to which component input\n"
        "5. Convert the entire canvas into a valid A2UI JSON that the frontend will render\n\n"
        "IMPORTANT AGENT SELECTION RULE:\n"
        "- If NONE of the available agents are suitable for the app's purpose, you MUST set selected_agents to []\n"
        "- Do NOT pick an unrelated agent just because it is the only option\n\n"
        "IMPORTANT SKILL SELECTION RULE:\n"
        "- Only select skills that will actually be used by this app.\n"
        "- If selected_agents is [] and selected_workflows is [], you MUST set selected_skills to [].\n"
        "- selected_skills is OPTIONAL metadata: it may be [] even when an agent/workflow is selected.\n"
        "- Never select a random/unrelated skill.\n\n"
        "IMPORTANT VALIDATION RULES:\n"
        "- Do NOT invent new component ids (like c_2) that are not present in the canvas JSON.\n"
        "- The ids you put in root.children.explicitList must be REAL component ids that exist as entries in a2ui_json.components.\n\n"
        "--- CANVAS COMPONENT TYPES ---\n"
        + CANVAS_TYPES
        + "\n--- A2UI OUTPUT FORMAT ---\n"
        + A2UI_SPEC
        + "\n--- CANVAS JSON (what the user built) ---\n"
        + json.dumps(canvas_config, indent=2)
        + "\n\n--- AGENT CONTEXT ---\n"
        + agent_section
        + "\n\n--- WORKFLOW CONTEXT ---\n"
        + workflow_section
        + "\n\n--- AVAILABLE SKILLS ---\n"
        + skills_section
        + "\n\n--- AVAILABLE PERSONAS ---\n"
        + persona_section
        + "\n\n--- YOUR OUTPUT ---\n\n"
        "Return ONLY a single valid JSON object. No explanation before or after. No markdown fences.\n\n"
        "Use this exact structure:\n"
        "{\n"
        '  "app_type": "short string e.g. api_dashboard, agent_qa_app, chat_app, data_pipeline",\n'
        '  "reasoning": "2-3 sentences: what this app does, the data flow, and why you made your choices",\n'
        '  "selected_agents": [\n'
        '    { "component_data_key": "data_key of agent_trigger component", "agent_id": "UUID", "agent_name": "name", "reason": "why selected" }\n'
        "  ],\n"
        '  "selected_workflows": [\n'
        '    { "component_data_key": "data_key of workflow_trigger component", "workflow_id": "UUID", "workflow_name": "name", "reason": "why selected" }\n'
        "  ],\n"
        '  "selected_skills": [\n'
        '    { "skill_id": "UUID", "skill_type": "agent or workflow", "name": "skill name", "reason": "why this skill is needed" }\n'
        "  ],\n"
        '  "selected_persona": { "persona_id": "UUID or null if not in list", "name": "persona name", "reason": "why this persona fits" },\n'
        '  "a2ui_json": {\n'
        '    "components": [ ...complete list of A2UI component objects... ],\n'
        '    "data": { ...every data_key from the canvas initialized to null... }\n'
        "  }\n"
        "}\n\n"
        "Critical rules for a2ui_json:\n"
        "- Every canvas component must appear in the A2UI output as its own component entry with the SAME id as on the canvas (e.g. canvas id c_7 -> A2UI component id c_7)\n"
        "- Every api_trigger, agent_trigger, workflow_trigger, submit_button MUST have a Button whose actionId equals that component's props.data_key\n"
        "- Components appear in top-to-bottom order matching their Y position on canvas\n"
        "- api_trigger, agent_trigger, workflow_trigger -> render as Button (actionId = component data_key)\n"
        "- chat_interface -> render as Column with a TextField and a Button\n"
        "- Display components (markdown, bar_chart, data_table, metric_card etc.) -> data-bound to the on_success_key of the trigger that feeds them\n"
        "- Input: short_text etc. -> TextField; file_upload -> FileField (never TextField for files)\n"
        "- Use Column for vertical stacks, Row for side-by-side layout\n"
        "- Every id referenced in children must exist as its own component entry in the list\n"
        "- Initialize every data_key that appears in the canvas in the data dict to null\n"
        "- Include any extra display-bound keys (e.g. metric_card) even if not an on_success_key\n"
    )
    return prompt.strip()


def build_retry_prompt(*, previous_prompt: str, validation_error: str, raw_response: str) -> str:
    return (
        previous_prompt
        + "\n\n--- VALIDATION ERROR ---\n"
        + validation_error
        + "\n\n--- YOUR PREVIOUS (INVALID) JSON (for debugging) ---\n"
        + raw_response[:4000]
        + "\n\nReturn a corrected JSON object that satisfies ALL rules.\n"
    )


ORCHESTRATION_METADATA_KEYS = (
    "app_type",
    "reasoning",
    "selected_agents",
    "selected_workflows",
    "selected_skills",
    "selected_persona",
    "workflow_planner",
    "workflow_decisions",
    "action_bindings",
)


def _normalize_nullish(obj: Any) -> Any:
    if isinstance(obj, str):
        s = obj.strip().lower()
        if s in {"null", "none", ""}:
            return None
        return obj
    if isinstance(obj, list):
        return [_normalize_nullish(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _normalize_nullish(v) for k, v in obj.items()}
    return obj


def slice_orchestration_metadata(parsed: Dict[str, Any]) -> Dict[str, Any]:
    raw = {k: parsed[k] for k in ORCHESTRATION_METADATA_KEYS if k in parsed}
    return _normalize_nullish(raw)


def _summarize_context_items(items: List[Dict[str, Any]], id_key: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for it in items[:50]:
        if not isinstance(it, dict):
            continue
        out.append({id_key: it.get(id_key), "name": it.get("name"), "skill_type": it.get("skill_type")})
    return out


def apply_agent_selection_policy(parsed: Dict[str, Any], *, canvas_config: List[Dict[str, Any]], inventory: Dict[str, Any], db_context: Dict[str, Any], app_name: str = "", app_description: str = "") -> Dict[str, Any]:
    if not isinstance(parsed, dict):
        return parsed
    if not inventory.get("needs_agent_selection"):
        return parsed

    available_agents = db_context.get("agents") or []
    available_by_id = {str(a.get("agent_id")): a for a in available_agents if isinstance(a, dict) and a.get("agent_id")}
    available_ids = set(available_by_id.keys())

    selected_agents = parsed.get("selected_agents")
    if not isinstance(selected_agents, list) or len(selected_agents) == 0:
        parsed["selected_agents"] = []
        return parsed

    app_text = " ".join(filter(None, [app_name, app_description, _app_intent_text(canvas_config)]))
    kept: List[Dict[str, Any]] = []
    dropped: List[str] = []
    single_agent_pool = len(available_ids) == 1

    for item in selected_agents:
        if not isinstance(item, dict):
            continue
        aid = item.get("agent_id")
        if not isinstance(aid, str) or aid not in available_ids:
            dropped.append(f"{aid} (not available)")
            continue
        if not single_agent_pool:
            ok, reason = _is_agent_relevant(app_text, available_by_id[aid])
            if not ok:
                dropped.append(f"{aid} ({reason})")
                continue
        kept.append(item)

    if dropped and not kept:
        logger.info("orchestrate: cleared selected_agents (unassigned). dropped=%s", dropped)
        parsed["selected_agents"] = []
        skills = parsed.get("selected_skills")
        if isinstance(skills, list):
            dropped_ids = {d.split(" ", 1)[0] for d in dropped}
            parsed["selected_skills"] = [
                s for s in skills if not (isinstance(s, dict) and str(s.get("skill_type")) == "agent" and str(s.get("skill_id")) in dropped_ids)
            ]
    return parsed


def apply_skill_selection_policy(parsed: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(parsed, dict):
        return parsed

    selected_agents = parsed.get("selected_agents") or []
    selected_workflows = parsed.get("selected_workflows") or []
    skills = parsed.get("selected_skills") or []

    if not isinstance(skills, list):
        parsed["selected_skills"] = []
        return parsed
    if (not selected_agents) and (not selected_workflows):
        parsed["selected_skills"] = []
        return parsed

    allowed_agent_ids = {str(a.get("agent_id")) for a in selected_agents if isinstance(a, dict) and a.get("agent_id") is not None}
    allowed_workflow_ids = {str(w.get("workflow_id")) for w in selected_workflows if isinstance(w, dict) and w.get("workflow_id") is not None}
    allowed_skill_ids = allowed_agent_ids.union(allowed_workflow_ids)

    filtered: List[Dict[str, Any]] = []
    for s in skills:
        if not isinstance(s, dict):
            continue
        reason = s.get("reason")
        if isinstance(reason, str) and "not applicable" in reason.lower():
            continue
        skill_id = s.get("skill_id")
        if skill_id is None:
            continue
        if allowed_skill_ids and str(skill_id) not in allowed_skill_ids:
            continue
        filtered.append(s)

    parsed["selected_skills"] = filtered
    return parsed


CANVAS_TRIGGER_TYPES = frozenset({"api_trigger", "agent_trigger", "workflow_trigger", "submit_button"})


def _canvas_component_ids(canvas_config: List[Dict[str, Any]]) -> set:
    out = set()
    for c in canvas_config:
        if isinstance(c, dict) and c.get("id"):
            out.add(str(c["id"]))
    return out


def _collect_a2ui_component_ids(components: List[Any]) -> set:
    out = set()
    for comp in components:
        if isinstance(comp, dict) and comp.get("id"):
            out.add(str(comp["id"]))
    return out


def _trigger_action_keys(canvas_config: List[Dict[str, Any]]) -> set:
    keys = set()
    for c in canvas_config:
        if not isinstance(c, dict):
            continue
        if c.get("type") not in CANVAS_TRIGGER_TYPES:
            continue
        props = c.get("props") or {}
        dk = props.get("data_key") or c.get("id")
        if dk:
            keys.add(str(dk))
    return keys


def _extract_button_action_ids(components: List[Any]) -> set:
    actions = set()
    for comp in components:
        if not isinstance(comp, dict):
            continue
        inner = comp.get("component")
        if not isinstance(inner, dict):
            continue
        btn = inner.get("Button")
        if isinstance(btn, dict) and btn.get("actionId") is not None:
            actions.add(str(btn["actionId"]))
    return actions


def _path_to_root_key(path: str) -> str:
    if not isinstance(path, str) or not path.startswith("/"):
        return ""
    p = path.lstrip("/")
    if "[" in p:
        p = p.split("[", 1)[0].rstrip("/")
    return p.split("/")[0] if p else ""


def _collect_bound_data_keys(obj: Any, out: set) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ("dataPath", "path") and isinstance(v, str):
                rk = _path_to_root_key(v)
                if rk:
                    out.add(rk)
            else:
                _collect_bound_data_keys(v, out)
    elif isinstance(obj, list):
        for item in obj:
            _collect_bound_data_keys(item, out)


def _referenced_child_ids(components: List[Any]) -> set:
    refs = set()
    def walk(o: Any) -> None:
        if isinstance(o, dict):
            if "explicitList" in o and isinstance(o["explicitList"], list):
                for x in o["explicitList"]:
                    if isinstance(x, str):
                        refs.add(x)
            if "child" in o and isinstance(o["child"], str):
                refs.add(o["child"])
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for i in o:
                walk(i)
    for comp in components:
        walk(comp)
    return refs


def validate_parsed_response(parsed: Dict[str, Any], canvas_config: List[Dict[str, Any]]) -> None:
    if "app_type" not in parsed:
        raise ValueError("LLM response missing 'app_type'")
    if "a2ui_json" not in parsed:
        raise ValueError("LLM response missing 'a2ui_json'")
    a2ui = parsed["a2ui_json"]
    if not isinstance(a2ui, dict):
        raise ValueError(f"a2ui_json must be a dict, got {type(a2ui).__name__}")
    if "components" not in a2ui or not isinstance(a2ui.get("components"), list):
        raise ValueError("a2ui_json.components must be a list")
    if len(a2ui["components"]) == 0:
        raise ValueError("a2ui_json.components must not be empty")
    if "data" not in a2ui or not isinstance(a2ui.get("data"), dict):
        raise ValueError("a2ui_json.data must be a dict")

    components = a2ui["components"]
    a2ui_ids = _collect_a2ui_component_ids(components)
    canvas_ids = _canvas_component_ids(canvas_config)
    missing_canvas = canvas_ids - a2ui_ids
    if missing_canvas:
        raise ValueError("A2UI output is missing these canvas component ids: " f"{sorted(missing_canvas)}")

    required_actions = _trigger_action_keys(canvas_config)
    button_actions = _extract_button_action_ids(components)
    missing_actions = required_actions - button_actions
    if missing_actions:
        raise ValueError("A2UI output is missing Button actionId for these trigger data_keys: " f"{sorted(missing_actions)}")

    bound_keys: set = set()
    for comp in components:
        _collect_bound_data_keys(comp, bound_keys)
    data_keys = set(a2ui["data"].keys())
    missing_bindings = bound_keys - data_keys
    if missing_bindings:
        raise ValueError("a2ui_json.data is missing keys referenced by UI bindings: " f"{sorted(missing_bindings)}")

    child_refs = _referenced_child_ids(components)
    missing_refs = child_refs - a2ui_ids
    if missing_refs:
        raise ValueError("A2UI references undefined component ids in children/card: " f"{sorted(missing_refs)}")


def validate_final_application_artifact(parsed: Dict[str, Any], canvas_config: List[Dict[str, Any]]) -> None:
    if not isinstance(parsed, dict):
        raise ValueError("Final parsed artifact must be a dict")
    workflow_decisions = parsed.get("workflow_decisions") or {}
    a2ui = parsed.get("a2ui_json") or {}
    components = a2ui.get("components") or []
    ai_required = bool(workflow_decisions.get("ai_required"))

    root_exists = any(isinstance(comp, dict) and comp.get("id") == "root" for comp in components)
    if not root_exists:
        raise ValueError("a2ui_json must contain a root component with id 'root'")

    primary_buttons = 0
    on_click_endpoints: Dict[str, str] = {}
    for comp in components:
        if not isinstance(comp, dict):
            continue
        node = comp.get("component") or {}
        button = node.get("Button")
        if not isinstance(button, dict):
            continue
        if button.get("primary") is True:
            primary_buttons += 1
        action_id = str(button.get("actionId") or "").strip()
        on_click = button.get("on_click")
        if action_id and isinstance(on_click, dict):
            endpoint = on_click.get("endpoint")
            if isinstance(endpoint, str) and endpoint.strip():
                on_click_endpoints[action_id] = endpoint.strip()

    if primary_buttons > 1:
        raise ValueError("a2ui_json must not contain more than one primary button")

    if ai_required:
        agent_map, workflow_map = _selection_maps(parsed)
        required_action_ids = set(agent_map.keys()).union(workflow_map.keys())
        missing_action_bindings = sorted([aid for aid in required_action_ids if aid not in on_click_endpoints])
        if missing_action_bindings:
            raise ValueError("Missing on_click execution binding for action_ids: " f"{missing_action_bindings}")

        unresolved = workflow_decisions.get("pending_asset_creation") or []
        if unresolved and not workflow_decisions.get("resolved_agent_id") and not workflow_decisions.get("resolved_workflow_id"):
            raise ValueError("AI is required but no resolved agent/workflow id is available")

        for action_id, endpoint in on_click_endpoints.items():
            if action_id in agent_map and not endpoint.endswith(agent_map[action_id]):
                raise ValueError(f"Agent action_id '{action_id}' endpoint does not end with agent_id")
            if action_id in workflow_map and not endpoint.endswith(workflow_map[action_id]):
                raise ValueError(f"Workflow action_id '{action_id}' endpoint does not end with workflow_id")


# ---------------------------------------------------------------------------
# Step 4 -- Call the default LLM
# ---------------------------------------------------------------------------

async def call_llm(prompt: str, user_id: Optional[str] = None) -> str:
    try:
        from echolib.llm_resolver import resolve_and_build_llm

        llm = await resolve_and_build_llm(
            user_id=user_id,
            component="agentic_orchestrator",
            framework="langchain",
        )
        # Ensure sufficient token budget for response by constraining max_tokens
        # This prevents LLM responses from being truncated mid-JSON
        response = llm.invoke(prompt, max_tokens=8000)
        if isinstance(response, str):
            return response
        if hasattr(response, "content"):
            return response.content
        if isinstance(response, dict):
            return response.get("content", str(response))
        return str(response)
    except Exception as exc:
        logger.exception("call_llm: LLM invocation failed")
        raise RuntimeError(f"LLM call failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Step 5 -- Parse and validate LLM response
# ---------------------------------------------------------------------------

def parse_llm_response(raw: str) -> Dict[str, Any]:
    # Detect if response is likely truncated (incomplete JSON)
    is_likely_truncated = (
        not raw.strip().endswith("}") or
        raw.strip().endswith(": ") or
        raw.strip().endswith(": []") or
        raw.count("{") != raw.count("}")
    )
    
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    cleaned = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("`").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    # Enhanced error message with truncation indicator and response size
    truncation_indicator = " [LIKELY TRUNCATED]" if is_likely_truncated else ""
    error_msg = (
        f"LLM did not return valid JSON{truncation_indicator}. "
        f"Response size: {len(raw)} chars. First 500 chars: {raw[:500]}"
    )
    logger.error("%s", error_msg)
    raise ValueError(error_msg)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def orchestrate(
    db: AsyncSession,
    canvas_config: List[Dict[str, Any]],
    user_id: str,
    app_name: str = "",
    app_description: str = "",
    create_agent_fn: Optional[ExecutionCreateFn] = None,
    create_workflow_fn: Optional[ExecutionCreateFn] = None,
) -> Dict[str, Any]:
    logger.info("orchestrate: start user=%s components=%d", user_id, len(canvas_config))

    inventory = parse_canvas_inventory(canvas_config)
    logger.info("orchestrate: needs_agent_selection=%s needs_workflow_selection=%s", inventory["needs_agent_selection"], inventory["needs_workflow_selection"])

    db_context = await fetch_db_context(db, user_id, inventory)
    logger.info(
        "orchestrate: agents=%d mode=%s workflows=%d mode=%s skills=%d personas=%d",
        len(db_context["agents"]),
        db_context["mode"]["agents"],
        len(db_context["workflows"]),
        db_context["mode"]["workflows"],
        len(db_context.get("skills", [])),
        len(db_context.get("personas", [])),
    )

    try:
        logger.info(
            "orchestrate: LLM context summary agents=%s workflows=%s skills=%s personas=%s",
            json.dumps(_summarize_context_items(db_context.get("agents", []), "agent_id")),
            json.dumps(_summarize_context_items(db_context.get("workflows", []), "workflow_id")),
            json.dumps(_summarize_context_items(db_context.get("skills", []), "skill_id")),
            json.dumps(_summarize_context_items(db_context.get("personas", []), "persona_id")),
        )
    except Exception:
        logger.debug("orchestrate: failed to log context summary", exc_info=True)

    prompt = build_prompt(canvas_config, inventory, db_context)
    logger.info("orchestrate: prompt=%d chars", len(prompt))

    raw_response = await call_llm(prompt, user_id=user_id)
    logger.info("orchestrate: LLM response=%d chars", len(raw_response))

    parsed = parse_llm_response(raw_response)
    try:
        validate_parsed_response(parsed, canvas_config)
    except ValueError as exc:
        retry_prompt = build_retry_prompt(previous_prompt=prompt, validation_error=str(exc), raw_response=raw_response)
        logger.warning("orchestrate: validation failed, retrying once: %s", exc)
        raw_response_2 = await call_llm(retry_prompt, user_id=user_id)
        logger.info("orchestrate: LLM response (retry)=%d chars", len(raw_response_2))
        parsed = parse_llm_response(raw_response_2)
        validate_parsed_response(parsed, canvas_config)

    parsed = apply_agent_selection_policy(parsed, canvas_config=canvas_config, inventory=inventory, db_context=db_context, app_name=app_name, app_description=app_description)
    parsed = apply_skill_selection_policy(parsed)

    planner = build_orchestration_planner(canvas_config=canvas_config, app_name=app_name, app_description=app_description, inventory=inventory, db_context=db_context)
    workflow_decisions = build_workflow_decisions(canvas_config=canvas_config, orchestration_metadata=parsed)

    parsed["workflow_planner"] = planner
    parsed["workflow_decisions"] = workflow_decisions

    parsed = await resolve_or_create_ai_assets(parsed=parsed, workflow_decisions=workflow_decisions, create_agent_fn=create_agent_fn, create_workflow_fn=create_workflow_fn)

    parsed["workflow_decisions"]["frontend_type"] = determine_frontend_type(canvas_config, parsed)

    action_bindings, binding_errors = build_action_bindings(canvas_config)
    binding_errors.extend(validate_action_bindings(canvas_config, action_bindings))
    parsed["action_bindings"] = patch_action_bindings(action_bindings, parsed)

    parsed["a2ui_json"] = patch_a2ui_execution_bindings(parsed.get("a2ui_json") or {}, parsed)

    validate_final_application_artifact(parsed, canvas_config)
    parsed["final_application_json"] = build_final_application_json(parsed)

    if binding_errors:
        parsed["action_binding_errors"] = binding_errors

    logger.info(
        "orchestrate: done app_type=%s a2ui_components=%d frontend_type=%s resolved_agent_id=%s resolved_workflow_id=%s",
        parsed.get("app_type"),
        len(parsed.get("a2ui_json", {}).get("components", [])),
        (parsed.get("workflow_decisions") or {}).get("frontend_type"),
        (parsed.get("workflow_decisions") or {}).get("resolved_agent_id"),
        (parsed.get("workflow_decisions") or {}).get("resolved_workflow_id"),
    )
    return parsed
