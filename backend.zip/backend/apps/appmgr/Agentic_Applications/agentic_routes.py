"""
EchoAI Agentic Application — Routes

Endpoints:
    POST /api/applications/agentic
        Accept the canvas JSON from the IDE, validate it, and persist
        it as a new agentic application in DRAFT status.

    GET  /api/applications/agentic
        Return all non-deleted agentic applications for the authenticated
        user as a list of app cards.

Design notes:
    - No existing files are modified by this module.
    - Auth / DB session patterns follow apps/appmgr/routes.py exactly.
    - The router is registered in apps/gateway/main.py.
"""

import logging
import os
import uuid
import copy
from time import perf_counter
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, File, UploadFile, Form
from fastapi.params import Depends
from pydantic import BaseModel, ConfigDict
from starlette.responses import StreamingResponse
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.database import get_db_session
from echolib.upload_validation import validate_upload
from echolib.models.agentic_application import AgenticApplication
from echolib.models.agentic_upload import AgenticUploadedFile
from echolib.models.agentic_chat_session import AgenticChatSession
from echolib.models.user import User
from echolib.models.user_links import UserDesignationLink, UserBusinessUnitLink
from echolib.security import require_user, require_super_admin, require_admin_or_above, resolve_user_id
from echolib.types import UserContext

from .agentic_components import is_known_type
from .agentic_orchestrator import (
    orchestrate,
    slice_orchestration_metadata,
    build_workflow_decisions,
    build_action_bindings,
    validate_action_bindings,
)
from .intent_understanding import understand_intent
from .asset_matcher import rank_existing_assets
from .reuse_policy import decide_reuse_plan
from .canvas_synthesizer import synthesize_canvas_from_intent
from .asset_generator import generate_assets_from_intent, AssetGenerationError
from .agentic_schemas import (
    AgenticAppUpdate,
    AgenticAppDelete,
    ExecuteRequest,
    ExecuteResponse,
    RunRequest,
    RunResponse,
    RunStepResult,
    RunStreamRequest,
    ChatStreamRequest,
    PublishRequest,
    AgenticAppCard,
    AgenticAppCreate,
    AgenticIntentCreate,
    AgenticAppDetail,
    AgenticAppListResponse,
    AgenticFileUploadResponse,
    Actions,
    WorkflowAction,
    AgentAction,
    ActionInputMapping,
    ActionOutputMapping,
)

from echolib.repositories.approval_audit_repo import ApprovalAuditRepository
from echolib.repositories.notification_repo import NotificationRepository

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/applications/agentic",
    tags=["Agentic Applications"],
)

# Directory for agentic app file uploads
AGENTIC_UPLOADS_DIR = os.getenv(
    "AGENTIC_APP_UPLOADS_DIR",
    os.path.join("apps", "appmgr", "uploads_agentic"),
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _model_to_card(app: AgenticApplication) -> AgenticAppCard:
    """Convert a DB row to a lightweight list card."""
    return AgenticAppCard(
        agentic_app_id=str(app.agentic_app_id),
        name=app.name,
        description=app.description,
        status=app.status,
        app_type="agentic",
        approval_status=app.approval_status,
        approved_by=str(app.approved_by) if app.approved_by else None,
        rejection_reason=app.rejection_reason,
        created_at=app.created_at,
        updated_at=app.updated_at,
    )


def _model_to_detail(app: AgenticApplication) -> AgenticAppDetail:
    """Convert a DB row to the full detail schema."""
    return AgenticAppDetail(
        agentic_app_id=str(app.agentic_app_id),
        user_id=str(app.user_id),
        name=app.name,
        description=app.description,
        status=app.status,
        app_type="agentic",
        canvas_config=app.canvas_config or [],
        a2ui_config=app.a2ui_config,
        orchestration_metadata=app.orchestration_metadata,
        actions=_build_actions_from_app(app) if app.actions else None,
        approval_status=app.approval_status,
        approved_by=str(app.approved_by) if app.approved_by else None,
        rejection_reason=app.rejection_reason,
        created_at=app.created_at,
        updated_at=app.updated_at,
    )


# ---------------------------------------------------------------------------
# ACTION GENERATION HELPERS
# ---------------------------------------------------------------------------


def _extract_input_components(canvas_config: list) -> list[dict]:
    """
    Extract all INPUT category components from canvas.
    
    Returns list of dicts: {component_id, component_type, data_key, label}
    """
    if not isinstance(canvas_config, list):
        return []
    
    input_components = []
    INPUT_TYPES = {
        "short_text", "text_area", "number", "select", "multi_select",
        "checkbox", "date_picker", "file_upload", "slider", "tags"
    }
    
    for component in canvas_config:
        if not isinstance(component, dict):
            continue
        
        comp_type = component.get("type", "").strip()
        if comp_type not in INPUT_TYPES:
            continue
        
        props = component.get("props") or {}
        data_key = props.get("data_key") or component.get("id")
        
        if not data_key:
            continue
        
        label = props.get("label") or props.get("placeholder") or comp_type
        
        input_components.append({
            "component_id": component.get("id", ""),
            "component_type": comp_type,
            "data_key": data_key,
            "label": label,
        })
    
    return input_components


def _extract_output_components(canvas_config: list) -> list[dict]:
    """
    Extract all OUTPUT/DISPLAY category components from canvas.
    
    Returns list of dicts: {component_id, component_type, output_key, label}
    """
    if not isinstance(canvas_config, list):
        return []
    
    output_components = []
    OUTPUT_TYPES = {
        "markdown_viewer", "table", "chart", "code_block",
        "metric_display", "ppt_viewer", "file_download", "raw_json"
    }
    
    for component in canvas_config:
        if not isinstance(component, dict):
            continue
        
        comp_type = component.get("type", "").strip()
        if comp_type not in OUTPUT_TYPES:
            continue
        
        props = component.get("props") or {}
        output_key = props.get("output_key") or props.get("data_key") or component.get("id")
        
        if not output_key:
            continue
        
        label = props.get("label") or comp_type
        
        output_components.append({
            "component_id": component.get("id", ""),
            "component_type": comp_type,
            "output_key": output_key,
            "label": label,
        })
    
    return output_components


def _add_action_id_to_submit_buttons(canvas_config: list, action_id: str = "run_workflow") -> tuple[list, int]:
    """
    Enrich submit_button components with actionId.
    
    Returns (updated_canvas, count_modified)
    """
    if not isinstance(canvas_config, list):
        return canvas_config, 0
    
    updated = copy.deepcopy(canvas_config)
    modified_count = 0
    
    for component in updated:
        if not isinstance(component, dict):
            continue
        
        if component.get("type") != "submit_button":
            continue
        
        props = component.get("props") or {}
        if "actionId" not in props or not props.get("actionId"):
            props["actionId"] = action_id
            component["props"] = props
            modified_count += 1
            logger.debug(
                "Added actionId=%s to submit_button id=%s",
                action_id,
                component.get("id"),
            )
    
    return updated, modified_count


def _build_actions_from_canvas_and_orchestration(
    canvas_config: list,
    orchestration_metadata: dict,
) -> Optional[dict]:
    """
    Build Actions object from canvas config and orchestration metadata.
    
    Extracts either:
    - 'run_workflow' action from orchestration_metadata.selected_workflows[0], OR
    - 'run_agent' action from orchestration_metadata.selected_agents[0]
    
    Returns dict suitable for Actions schema, or None if neither workflow nor agent selected.
    """
    if not isinstance(canvas_config, list) or not isinstance(orchestration_metadata, dict):
        return None
    
    # Extract input/output mappings from canvas (reused for both workflow and agent)
    input_components = _extract_input_components(canvas_config)
    output_components = _extract_output_components(canvas_config)
    
    if not input_components:
        logger.warning("No INPUT components found in canvas for action mappings")
    if not output_components:
        logger.warning("No OUTPUT components found in canvas for action mappings")
    
    # Try workflow first
    selected_workflows = orchestration_metadata.get("selected_workflows") or []
    if selected_workflows and isinstance(selected_workflows, list):
        workflow_entry = selected_workflows[0]
        if isinstance(workflow_entry, dict):
            workflow_id = workflow_entry.get("workflow_id")
            if workflow_id:
                try:
                    UUID(workflow_id)
                    action = {
                        "action_id": "run_workflow",
                        "workflow_id": workflow_id,
                        "input_mapping": input_components,
                        "output_mapping": output_components,
                        "metadata": {
                            "generated_at": datetime.now(timezone.utc).isoformat(),
                            "source": "orchestration_build",
                        },
                    }
                    return {"run_workflow": action}
                except (ValueError, AttributeError):
                    logger.warning("Invalid workflow_id format (not UUID): %s", workflow_id)
    
    # Try agent if workflow not available
    selected_agents = orchestration_metadata.get("selected_agents") or []
    if selected_agents and isinstance(selected_agents, list):
        agent_entry = selected_agents[0]
        if isinstance(agent_entry, dict):
            agent_id = agent_entry.get("agent_id")
            if agent_id:
                try:
                    UUID(agent_id)
                    action = {
                        "action_id": "run_agent",
                        "agent_id": agent_id,
                        "input_mapping": input_components,
                        "output_mapping": output_components,
                        "metadata": {
                            "generated_at": datetime.now(timezone.utc).isoformat(),
                            "source": "orchestration_build",
                        },
                    }
                    return {"run_agent": action}
                except (ValueError, AttributeError):
                    logger.warning("Invalid agent_id format (not UUID): %s", agent_id)
    
    # Neither workflow nor agent found
    logger.warning("No valid workflow_id or agent_id found in orchestration_metadata")
    return None


def _build_actions_from_app(app: "AgenticApplication") -> Optional[dict]:
    """
    Reconstruct Actions object from persisted app data.
    
    This is used when retrieving from DB and needs to match schema validation.
    """
    if not app.actions:
        return None
    
    from .agentic_schemas import Actions
    try:
        return Actions(**app.actions).model_dump() if isinstance(app.actions, dict) else app.actions
    except Exception as e:
        logger.warning("Failed to parse actions from app %s: %s", app.agentic_app_id, e)
        return None


def _validate_canvas_config(canvas_config: list) -> list[str]:
    """
    Run structural validation on the canvas_config array.

    Returns a list of warning strings for any components whose type is
    not in the component registry.  These are warnings, not errors — we
    save the app regardless, because new component types may be added to
    the frontend before the backend registry is updated.

    The only hard errors (empty array, missing id/type) are enforced by
    the Pydantic schema (AgenticAppCreate).
    """
    warnings: list[str] = []

    for i, component in enumerate(canvas_config):
        if not isinstance(component, dict):
            warnings.append(f"Component at index {i} is not an object — skipped")
            continue

        comp_id = component.get("id", f"<index {i}>")
        comp_type = component.get("type")

        if not comp_type:
            warnings.append(f"Component '{comp_id}' has no 'type' field")
            continue

        if not is_known_type(comp_type):
            warnings.append(
                f"Component '{comp_id}' has unknown type '{comp_type}' "
                f"— will be stored as-is"
            )

    return warnings


def _coerce_bool(value: Any, *, default: bool = True) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _extract_validation_value(validations: Any, validation_id: str, field_name: str) -> Optional[Any]:
    if not isinstance(validations, list):
        return None
    for rule in validations:
        if not isinstance(rule, dict):
            continue
        if str(rule.get("id") or "").strip().lower() != validation_id.lower():
            continue
        if field_name in rule:
            return rule.get(field_name)
    return None


def _normalize_canvas_for_frontend_contract(canvas_config: list) -> list:
    """
    Normalize canvas props for frontend/backend compatibility without dropping user keys.

    Rules:
    - Preserve original component types/keys from client payload.
    - Add compatibility aliases required by backend executors/A2UI emitters.
    - Fill critical defaults only when missing.
    """
    if not isinstance(canvas_config, list):
        return canvas_config

    normalized = copy.deepcopy(canvas_config)

    for component in normalized:
        if not isinstance(component, dict):
            continue

        ctype = str(component.get("type") or "").strip().lower()
        props = component.get("props")
        if not isinstance(props, dict):
            props = {}

        comp_id = str(component.get("id") or "").strip()
        if comp_id and not props.get("data_key"):
            props["data_key"] = comp_id

        if ctype == "heading":
            if not props.get("level") and props.get("size"):
                props["level"] = props.get("size")

        if ctype == "chat_interface":
            if not props.get("chat_title") and props.get("title"):
                props["chat_title"] = props.get("title")
            if not props.get("welcome_message") and props.get("welcome"):
                props["welcome_message"] = props.get("welcome")

        if ctype == "file_upload":
            validations = props.get("validations")
            if not props.get("accept"):
                accepted = _extract_validation_value(validations, "file_types", "allowedTypes")
                if accepted:
                    props["accept"] = accepted
            if props.get("max_size_mb") is None:
                max_mb = _extract_validation_value(validations, "max_size_mb", "maxMb")
                if max_mb not in (None, ""):
                    try:
                        props["max_size_mb"] = int(max_mb)
                    except (TypeError, ValueError):
                        props["max_size_mb"] = max_mb

        if ctype == "ppt_generator":
            if "use_template" not in props:
                props["use_template"] = False
            if "allow_ai_fallback" not in props:
                props["allow_ai_fallback"] = True

        if ctype == "api_trigger":
            if not props.get("method"):
                props["method"] = "GET"

        component["props"] = props

    return normalized


def _build_intent_refinement_detail(missing_details: list[str]) -> dict:
    """Return a consistent, user-friendly refine-prompt message."""
    hints = [d for d in (missing_details or []) if isinstance(d, str) and d.strip()]
    if not hints:
        hints = [
            "Specify the business goal of the app.",
            "Specify what inputs the user will provide.",
            "Specify what output should be generated.",
        ]

    return {
        "code": "REFINE_PROMPT_REQUIRED",
        "message": (
            "We could not generate a reliable canvas from this prompt yet. "
            "Please refine your prompt with the missing details below."
        ),
        "hitl": True,
        "assistant_role": "clarification",
        "missing_details": hints,
        "example_prompt": (
            "Create an invoice review app where users upload a PDF invoice and enter vendor name. "
            "Run workflow to extract total amount and tax, "
            "then call an API trigger to post the extracted summary to /finance/review."
        ),
    }


def _build_reuse_candidate_options(candidates: dict) -> list[str]:
    workflow_opts = [
        f"workflow:{c.get('asset_id')}:{c.get('name')}"
        for c in (candidates.get("workflows") or [])[:3]
        if isinstance(c, dict)
    ]
    agent_opts = [
        f"agent:{c.get('asset_id')}:{c.get('name')}"
        for c in (candidates.get("agents") or [])[:3]
        if isinstance(c, dict)
    ]
    return workflow_opts + agent_opts + ["generate:new"]


def _parse_hitl_selected_candidate(selected_candidate: Optional[str]) -> dict:
    token = str(selected_candidate or "").strip()
    if not token:
        return {
            "kind": None,
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "force_generate_new": False,
            "token": "",
        }

    kind, sep, remainder = token.partition(":")
    if not sep:
        raise ValueError(
            "selected_candidate must be one of: 'agent:<id>:<name>', 'workflow:<id>:<name>', or 'generate:new'"
        )

    kind_l = kind.strip().lower()
    rem = remainder.strip()
    if kind_l == "generate" and rem.lower() == "new":
        return {
            "kind": "generate",
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "force_generate_new": True,
            "token": token,
        }

    if kind_l not in {"agent", "workflow"}:
        raise ValueError(
            "selected_candidate must be one of: 'agent:<id>:<name>', 'workflow:<id>:<name>', or 'generate:new'"
        )

    asset_id = rem.split(":", 1)[0].strip()
    if not asset_id:
        raise ValueError("selected_candidate is missing asset id")

    try:
        UUID(asset_id)
    except (ValueError, AttributeError):
        raise ValueError("selected_candidate asset id must be a valid UUID")

    return {
        "kind": kind_l,
        "selected_agent_id": asset_id if kind_l == "agent" else None,
        "selected_workflow_id": asset_id if kind_l == "workflow" else None,
        "force_generate_new": False,
        "token": token,
    }


def _build_grouped_candidate_options(candidates: dict) -> dict:
    """
    Build grouped candidate options for multi-asset checkbox selection.
    
    Returns structured dict for frontend to render separate Workflow and Agent sections.
    
    Args:
        candidates: Dict with workflows and agents lists from rank_existing_assets()
        
    Returns:
        {
            "workflows": [
                {"asset_id": "...", "name": "...", "description": "...", ...},
                ...
            ],
            "agents": [
                {"asset_id": "...", "name": "...", "description": "...", ...},
                ...
            ],
            "selected_workflows": [],  # Empty initially; frontend updates on selection
            "selected_agents": [],     # Empty initially; frontend updates on selection
        }
    """
    return {
        "workflows": candidates.get("workflows", [])[:3],  # Top 3 candidates
        "agents": candidates.get("agents", [])[:3],        # Top 3 candidates
        "selected_workflows": [],
        "selected_agents": [],
    }


def _parse_multi_asset_selection(selected_assets: Optional[str]) -> dict:
    """
    Parse multi-asset selection format from frontend.
    
    Format: "agent_ids:id1,id2|workflow_ids:id3,id4"
    - agent_ids: comma-separated list of agent UUIDs (optional)
    - workflow_ids: comma-separated list of workflow UUIDs (optional)
    - At least one must be present
    
    Args:
        selected_assets: Selection payload from frontend (or None)
        
    Returns:
        {
            "selected_agent_ids": [...],      # List of agent UUIDs
            "selected_workflow_ids": [...],   # List of workflow UUIDs
            "mode": "agent_only" | "workflow_only" | "both",
            "is_valid": bool,
            "error": str or None,
        }
    """
    payload = str(selected_assets or "").strip()
    
    if not payload:
        return {
            "selected_agent_ids": [],
            "selected_workflow_ids": [],
            "mode": None,
            "is_valid": False,
            "error": "No selection provided",
        }
    
    result = {
        "selected_agent_ids": [],
        "selected_workflow_ids": [],
        "mode": None,
        "is_valid": True,
        "error": None,
    }
    
    # Parse segments: "agent_ids:id1,id2|workflow_ids:id3"
    segments = payload.split("|")
    
    for segment in segments:
        segment = segment.strip()
        if not segment:
            continue
        
        if segment.startswith("agent_ids:"):
            ids_str = segment[10:].strip()  # Remove "agent_ids:" prefix
            if ids_str:
                agent_ids = [id.strip() for id in ids_str.split(",") if id.strip()]
                # Validate UUIDs
                try:
                    for agent_id in agent_ids:
                        UUID(agent_id)
                    result["selected_agent_ids"] = agent_ids
                except (ValueError, AttributeError):
                    result["is_valid"] = False
                    result["error"] = f"Invalid agent UUID: {agent_id}"
                    return result
        
        elif segment.startswith("workflow_ids:"):
            ids_str = segment[13:].strip()  # Remove "workflow_ids:" prefix
            if ids_str:
                workflow_ids = [id.strip() for id in ids_str.split(",") if id.strip()]
                # Validate UUIDs
                try:
                    for workflow_id in workflow_ids:
                        UUID(workflow_id)
                    result["selected_workflow_ids"] = workflow_ids
                except (ValueError, AttributeError):
                    result["is_valid"] = False
                    result["error"] = f"Invalid workflow UUID: {workflow_id}"
                    return result
        
        elif segment == "generate:new":
            # Placeholder for "generate new" option (handled separately)
            pass
        
        else:
            result["is_valid"] = False
            result["error"] = f"Unknown selection segment: {segment}"
            return result
    
    # Validate: at least one asset selected
    if not result["selected_agent_ids"] and not result["selected_workflow_ids"]:
        result["is_valid"] = False
        result["error"] = "Must select at least one agent or workflow"
        return result
    
    # Determine mode
    if result["selected_agent_ids"] and result["selected_workflow_ids"]:
        result["mode"] = "both"
    elif result["selected_agent_ids"]:
        result["mode"] = "agent_only"
    else:
        result["mode"] = "workflow_only"
    
    return result


async def _workflow_exists_for_user(workflow_id: str, user_id: str) -> bool:
    """Check whether a workflow ID is resolvable for this user via DB-primary reads."""
    if not workflow_id or not isinstance(workflow_id, str):
        return False

    try:
        from echolib.repositories.storage_gateway import StorageGateway

        gateway = StorageGateway()
        definition = await gateway.load_workflow(workflow_id, user_id, state="draft")
        return isinstance(definition, dict) and bool(definition)
    except Exception:
        return False


async def _agent_exists_for_user(agent_id: str, user_id: str) -> bool:
    if not agent_id or not isinstance(agent_id, str):
        return False

    try:
        agent_uuid = UUID(agent_id)
        user_uuid = UUID(user_id)
    except (ValueError, AttributeError):
        return False

    from echolib.models.agent import Agent

    async with get_db_session() as db:
        stmt = select(Agent.agent_id).where(
            Agent.agent_id == agent_uuid,
            Agent.user_id == user_uuid,
            Agent.is_deleted == False,  # noqa: E712
        )
        row = (await db.execute(stmt)).first()
    return row is not None


def _apply_llm_selections_to_canvas(
    canvas_config: list,
    orchestration_metadata: dict,
) -> list:
    """
    Apply LLM-selected agent/workflow IDs directly into canvas_config
    so /run can execute without a manual update call.

    Mapping key:
      - selected_agents[].component_data_key matches agent_trigger props.data_key
      - selected_workflows[].component_data_key matches workflow_trigger props.data_key
    """
    if not isinstance(canvas_config, list) or not isinstance(orchestration_metadata, dict):
        return canvas_config

    selected_agents = orchestration_metadata.get("selected_agents") or []
    selected_workflows = orchestration_metadata.get("selected_workflows") or []

    def _is_valid_uuid_str(v: str) -> bool:
        try:
            UUID(v)
            return True
        except Exception:
            return False

    agent_map = {}
    for a in selected_agents:
        if not (isinstance(a, dict) and a.get("component_data_key") and a.get("agent_id")):
            continue
        agent_id = str(a["agent_id"]).strip()
        # Never apply placeholders like PUT_* or non-UUID ids.
        if agent_id.upper().startswith("PUT_") or not _is_valid_uuid_str(agent_id):
            continue
        agent_map[str(a["component_data_key"])] = agent_id

    wf_map = {}
    for w in selected_workflows:
        if not (isinstance(w, dict) and w.get("component_data_key") and w.get("workflow_id")):
            continue
        wf_id = str(w["workflow_id"]).strip()
        if wf_id.upper().startswith("PUT_") or not _is_valid_uuid_str(wf_id):
            continue
        wf_map[str(w["component_data_key"])] = wf_id

    if not agent_map and not wf_map:
        return canvas_config

    updated = copy.deepcopy(canvas_config)
    applied_agents = 0
    applied_wfs = 0

    for comp in updated:
        if not isinstance(comp, dict):
            continue
        ctype = comp.get("type")
        props = comp.get("props") or {}
        data_key = props.get("data_key") or comp.get("id")
        if not data_key:
            continue

        if ctype == "agent_trigger" and str(data_key) in agent_map:
            # Only apply when missing/placeholder
            if not props.get("agent_id") or str(props.get("agent_id")).upper().startswith("PUT_"):
                props["agent_id"] = agent_map[str(data_key)]
                comp["props"] = props
                applied_agents += 1

        if ctype == "workflow_trigger" and str(data_key) in wf_map:
            if not props.get("workflow_id") or str(props.get("workflow_id")).upper().startswith("PUT_"):
                props["workflow_id"] = wf_map[str(data_key)]
                comp["props"] = props
                applied_wfs += 1

    if applied_agents or applied_wfs:
        logger.info(
            "build_agentic_app: applied LLM selections to canvas: agents=%d workflows=%d",
            applied_agents,
            applied_wfs,
        )

    return updated


def _normalize_submit_button_data_key(canvas_config: list) -> list:
    """
    Ensure every submit_button uses data_key='run_app'.

    Scope is intentionally limited to POST/UPDATE flows so existing read,
    execute, and approval APIs are unaffected.
    """
    if not isinstance(canvas_config, list):
        return canvas_config

    updated = copy.deepcopy(canvas_config)
    changed = 0

    for comp in updated:
        if not isinstance(comp, dict):
            continue
        if comp.get("type") != "submit_button":
            continue

        props = comp.get("props") or {}
        if props.get("data_key") != "run_app":
            props["data_key"] = "run_app"
            comp["props"] = props
            changed += 1

    if changed:
        logger.info(
            "normalized submit_button data_key to run_app for %d component(s)",
            changed,
        )

    return updated



def _normalize_a2ui_payload_shape(a2ui_config: Optional[dict]) -> Optional[dict]:
    """
    Keep orchestrator output intact while adding optional fields commonly
    expected by the canvas/editor payload format.
    """
    if not isinstance(a2ui_config, dict):
        return a2ui_config

    out = copy.deepcopy(a2ui_config)
    components = out.get("components")
    if not isinstance(components, list):
        return out

    has_root = False
    for comp in components:
        if not isinstance(comp, dict):
            continue

        cid = str(comp.get("id") or "")
        node = comp.get("component")
        if isinstance(node, dict) and not comp.get("type") and len(node) == 1:
            comp["type"] = next(iter(node.keys()))

        if cid == "root":
            has_root = True
            if isinstance(node, dict):
                root_col = node.get("Column")
                if isinstance(root_col, dict) and "children" in root_col and "children" not in comp:
                    comp["children"] = copy.deepcopy(root_col.get("children"))

    if has_root and not out.get("rootComponentId"):
        out["rootComponentId"] = "root"

    return out


# ---------------------------------------------------------------------------
# POST /api/applications/agentic  — Build + Save as Draft
# ---------------------------------------------------------------------------


@router.post("", response_model=AgenticAppDetail, status_code=201)
async def build_agentic_app(
    payload: AgenticAppCreate,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Save a canvas layout as a new agentic application in DRAFT status.

    Called when the user clicks **Build** in the canvas IDE.

    Validation (minimal by design):
        - ``name``          : non-empty string (enforced by schema)
        - ``canvas_config`` : non-empty array  (enforced by schema)

    Any unknown component types produce warnings in the logs but do NOT
    block the save — the full canvas_config is persisted as-is.

    Returns the full application record including its new ``agentic_app_id``.
    """
    user_id_str = resolve_user_id(user)

    # Convert user_id string to UUID for the DB row
    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid user identity")

    # Log any unknown component types (non-blocking)
    warnings = _validate_canvas_config(payload.canvas_config)
    if warnings:
        logger.warning(
            "build_agentic_app: canvas_config warnings for user %s: %s",
            user_id_str,
            warnings,
        )

    # ------------------------------------------------------------------
    # Run LLM orchestrator — classify app, select agents/workflows,
    # generate A2UI JSON.  Fail fast if LLM cannot produce valid output.
    # ------------------------------------------------------------------
    async with get_db_session() as db:
        try:
            orchestration_result = await orchestrate(
                db=db,
                canvas_config=payload.canvas_config,
                user_id=user_id_str,
                app_name=payload.name or "",
                app_description=payload.description or "",
            )
        except (RuntimeError, ValueError) as exc:
            logger.error("build_agentic_app: orchestration failed: %s", exc)
            raise HTTPException(
                status_code=400,
                detail=f"Build failed — {str(exc)}",
            )

    a2ui_config = _normalize_a2ui_payload_shape(orchestration_result.get("a2ui_json"))
    orchestration_metadata = slice_orchestration_metadata(orchestration_result)
    
    # Apply LLM-selected agent/workflow IDs to canvas IF orchestrator provided them.
    # This only mutates components that have placeholders or missing IDs.
    canvas_to_save = _apply_llm_selections_to_canvas(
        payload.canvas_config,
        orchestration_metadata or {},
    )

    # Prefer orchestrator-produced metadata (db-context aware), fallback only when absent.
    planner = (
        orchestration_result.get("workflow_planner")
        or (orchestration_metadata or {}).get("workflow_planner")
        or {}
    )
    workflow_decisions = (
        orchestration_result.get("workflow_decisions")
        or (orchestration_metadata or {}).get("workflow_decisions")
        or build_workflow_decisions(
            canvas_config=canvas_to_save,
            orchestration_metadata=orchestration_metadata,
        )
    )
    action_bindings = (
        orchestration_result.get("action_bindings")
        or (orchestration_metadata or {}).get("action_bindings")
        or []
    )

    binding_errors = [
        str(err)
        for err in (orchestration_result.get("action_binding_errors") or [])
        if str(err).strip()
    ]
    if not action_bindings:
        action_bindings, generated_binding_errors = build_action_bindings(canvas_to_save)
        binding_errors.extend(generated_binding_errors)

    binding_errors.extend(validate_action_bindings(canvas_to_save, action_bindings))
    if binding_errors:
        binding_errors = list(dict.fromkeys(binding_errors))
    if binding_errors:
        raise HTTPException(
            status_code=400,
            detail=f"Build failed — invalid action bindings: {'; '.join(binding_errors)}",
        )

    orchestration_metadata = {
        **(orchestration_metadata or {}),
        "workflow_planner": planner,
        "workflow_decisions": workflow_decisions,
        "action_bindings": action_bindings,
        "build_version": "orchestration_v1",
        "binding_version": "action_binding_v1",
        "orchestration_timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # ------------------------------------------------------------------
    # Generate Actions section from canvas and orchestration
    # ------------------------------------------------------------------
    # Enrich submit buttons with actionId="run_workflow"
    canvas_with_actions, button_count = _add_action_id_to_submit_buttons(canvas_to_save)
    logger.info(
        "Enriched %d submit buttons with actionId=run_workflow for app %s",
        button_count,
        payload.name,
    )

    # Build the Actions object (workflow_id from orchestration + input/output mappings)
    try:
        actions_dict = _build_actions_from_canvas_and_orchestration(
            canvas_with_actions,
            orchestration_metadata,
        )
        if not actions_dict:
            logger.warning(
                "No actions generated for app %s — workflow selection may be missing",
                payload.name,
            )
            raise HTTPException(
                status_code=400,
                detail="Build failed — no workflow was selected during orchestration",
            )
        
        # Validate actions schema
        actions_obj = Actions(**actions_dict)
        logger.info(
            "Built actions for app %s: run_workflow with %d inputs, %d outputs",
            payload.name,
            len(actions_obj.run_workflow.input_mapping) if actions_obj.run_workflow else 0,
            len(actions_obj.run_workflow.output_mapping) if actions_obj.run_workflow else 0,
        )
    except Exception as e:
        logger.error("Failed to build actions for app %s: %s", payload.name, e)
        raise HTTPException(
            status_code=400,
            detail=f"Build failed — could not generate actions: {str(e)}",
        )

    # ------------------------------------------------------------------
    # Save to DB — persist canvas_config, a2ui_config, orchestration snapshot, actions
    # ------------------------------------------------------------------
    async with get_db_session() as db:
        app = AgenticApplication(
            user_id=user_uuid,
            name=payload.name,
            description=payload.description,
            status="draft",
            canvas_config=canvas_with_actions,
            a2ui_config=a2ui_config,
            orchestration_metadata=orchestration_metadata or None,
            actions=actions_dict or None,
            is_deleted=False,
            approval_status="pending",
        )
        db.add(app)
        await db.flush()

        # Audit log
        await _audit_repo.log_action(
            db,
            agentic_app_id=str(app.agentic_app_id),
            action="submitted",
            performed_by=user_id_str,
        )

        # Notify super_admins
        await _notify_super_admins_for_agentic_app(
            db, app,
            notif_type="approval_pending",
            title=f"New agentic application '{app.name}' pending approval",
            message=f"Agentic application '{app.name}' has been submitted for approval.",
        )

        await db.commit()
        await db.refresh(app)

        logger.info(
            "Agentic app created: id=%s name=%r app_type=%s user=%s",
            app.agentic_app_id,
            app.name,
            orchestration_result.get("app_type"),
            user_id_str,
        )

        return _model_to_detail(app)


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/intent  — Intent-first Canvas Generation
# ---------------------------------------------------------------------------


@router.post("/intent", response_model=List[dict], status_code=200)
async def build_agentic_app_from_intent(
    payload: AgenticIntentCreate,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Generate a starter canvas from natural language intent.

    This endpoint is generation-only and intentionally does not persist any app.
    Persistence must happen only after user approval via POST /api/applications/agentic.
    """
    request_id = uuid.uuid4().hex
    route_start = perf_counter()
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid user identity")

    logger.info(
        "build_agentic_app_from_intent: start request_id=%s user_id=%s prompt_len=%d preferred_model=%s auto_generate=%s from_hitl=%s selected_candidate=%s selected_assets=%s",
        request_id,
        user_id_str,
        len(payload.prompt or ""),
        payload.preferred_llm_model,
        payload.auto_generate_assets,
        payload.from_hitl_refine,
        payload.selected_candidate,
        payload.selected_assets if hasattr(payload, 'selected_assets') else None,
    )

    intent = understand_intent(
        prompt=payload.prompt,
        name=payload.name or "",
        description=payload.description or "",
    )

    async with get_db_session() as db:
        candidates = await rank_existing_assets(
            db=db,
            user_uuid=user_uuid,
            intent_text=intent.get("intent_text", payload.prompt),
        )

    # NEW: Support multi-asset selection (agent_ids + workflow_ids)
    # BACKWARD COMPAT: Fall back to old single-selection format
    selected_assets_param = getattr(payload, 'selected_assets', None)
    hitl_selection = {}  # Initialize for use in validation below
    
    if selected_assets_param:
        # Multi-asset selection path (NEW)
        asset_selection = _parse_multi_asset_selection(selected_assets_param)
        
        if not asset_selection["is_valid"]:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "INVALID_ASSET_SELECTION",
                    "message": asset_selection["error"],
                    "candidate_options": _build_grouped_candidate_options(candidates),
                },
            )
        
        # Build reuse plan from multi-asset selection
        selected_agent_ids = asset_selection["selected_agent_ids"]
        selected_workflow_ids = asset_selection["selected_workflow_ids"]
        
        # For now, support one agent + one workflow (future: multiple instances)
        selected_agent_id = selected_agent_ids[0] if selected_agent_ids else None
        selected_workflow_id = selected_workflow_ids[0] if selected_workflow_ids else None
        
        reuse_plan = {
            "mode": "mixed" if (selected_agent_id and selected_workflow_id) else "generate_new",
            "selected_agent_id": selected_agent_id,
            "selected_workflow_id": selected_workflow_id,
            "generate_agent": not selected_agent_id,
            "generate_workflow": not selected_workflow_id,
            "reasons": [f"multi_asset_selection_mode:{asset_selection['mode']}"],
        }
        
        logger.info(
            "build_agentic_app_from_intent: multi-asset selection request_id=%s mode=%s agents=%s workflows=%s",
            request_id,
            asset_selection["mode"],
            selected_agent_ids,
            selected_workflow_ids,
        )
    
    else:
        # Backward compatibility: single-selection path (OLD)
        try:
            hitl_selection = _parse_hitl_selected_candidate(payload.selected_candidate)
        except ValueError as exc:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "INVALID_HITL_SELECTION",
                    "message": str(exc),
                    "candidate_options": _build_reuse_candidate_options(candidates),
                },
            )

        if hitl_selection.get("force_generate_new"):
            reuse_plan = {
                "mode": "generate_new",
                "selected_agent_id": None,
                "selected_workflow_id": None,
                "reasons": ["hitl_user_selected_generate_new"],
                "generate_agent": True,
                "generate_workflow": True,
            }
        else:
            reuse_plan = decide_reuse_plan(
                intent=intent,
                candidates=candidates,
                auto_generate_assets=payload.auto_generate_assets,
                selected_agent_from_hitl=hitl_selection.get("selected_agent_id"),
                selected_workflow_from_hitl=hitl_selection.get("selected_workflow_id"),
            )

    selected_workflow_id = reuse_plan.get("selected_workflow_id")
    if isinstance(selected_workflow_id, str) and selected_workflow_id.strip():
        workflow_exists = await _workflow_exists_for_user(selected_workflow_id, user_id_str)
        if not workflow_exists:
            # Only check hitl_selection.kind if we're in old single-selection path
            if hitl_selection and hitl_selection.get("kind") == "workflow":
                raise HTTPException(
                    status_code=400,
                    detail={
                        "code": "INVALID_WORKFLOW_SELECTION",
                        "message": "Selected workflow is no longer available. Please choose another option.",
                        "candidate_options": _build_reuse_candidate_options(candidates),
                    },
                )

            next_workflow_id = None
            for candidate in candidates.get("workflows") or []:
                candidate_id = str((candidate or {}).get("asset_id") or "").strip()
                if not candidate_id or candidate_id == selected_workflow_id:
                    continue
                if await _workflow_exists_for_user(candidate_id, user_id_str):
                    next_workflow_id = candidate_id
                    break

            if next_workflow_id:
                reuse_plan["selected_workflow_id"] = next_workflow_id
                reuse_plan.setdefault("reasons", []).append("selected_workflow_missing_fallback_to_next_candidate")
            else:
                if payload.auto_generate_assets:
                    reuse_plan["mode"] = "generate_new"
                    reuse_plan["selected_workflow_id"] = None
                    reuse_plan["generate_workflow"] = True
                    reuse_plan.setdefault("reasons", []).append("selected_workflow_missing_auto_generated")
                else:
                    detail = _build_intent_refinement_detail([])
                    detail["message"] = (
                        "The selected reusable workflow is no longer available. "
                        "Please choose a different workflow or enable auto-generation."
                    )
                    detail["candidate_options"] = ["generate:new"]
                    raise HTTPException(status_code=409, detail=detail)

    selected_agent_id = reuse_plan.get("selected_agent_id")
    if isinstance(selected_agent_id, str) and selected_agent_id.strip():
        agent_exists = await _agent_exists_for_user(selected_agent_id, user_id_str)
        if not agent_exists:
            # Only check hitl_selection.kind if we're in old single-selection path
            if hitl_selection and hitl_selection.get("kind") == "agent":
                raise HTTPException(
                    status_code=400,
                    detail={
                        "code": "INVALID_AGENT_SELECTION",
                        "message": "Selected agent is no longer available. Please choose another option.",
                        "candidate_options": _build_reuse_candidate_options(candidates),
                    },
                )

            next_agent_id = None
            for candidate in candidates.get("agents") or []:
                candidate_id = str((candidate or {}).get("asset_id") or "").strip()
                if not candidate_id or candidate_id == selected_agent_id:
                    continue
                if await _agent_exists_for_user(candidate_id, user_id_str):
                    next_agent_id = candidate_id
                    break

            if next_agent_id:
                reuse_plan["selected_agent_id"] = next_agent_id
                reuse_plan.setdefault("reasons", []).append("selected_agent_missing_fallback_to_next_candidate")
            else:
                reuse_plan["selected_agent_id"] = None
                if payload.auto_generate_assets:
                    reuse_plan["mode"] = "generate_new"
                    reuse_plan["generate_agent"] = True
                    reuse_plan.setdefault("reasons", []).append("selected_agent_missing_auto_generated")

    logger.info(
        "build_agentic_app_from_intent: decision request_id=%s user_id=%s mode=%s confidence=%.3f",
        request_id,
        user_id_str,
        reuse_plan.get("mode"),
        float(intent.get("confidence", 0.0) or 0.0),
    )

    if reuse_plan.get("mode") in {"hitl_clarification", "hitl_reuse_choice"}:
        detail = _build_intent_refinement_detail(intent.get("missing_details") or [])
        if reuse_plan.get("mode") == "hitl_reuse_choice":
            detail["message"] = (
                "We found multiple reusable assets and need your preference before generating the canvas. "
                "Please clarify whether to reuse one of the options or generate a new setup."
            )
            detail["assistant_role"] = "reuse_choice"
            detail["candidate_options"] = _build_reuse_candidate_options(candidates)
        raise HTTPException(status_code=409, detail=detail)

    canvas_seed = synthesize_canvas_from_intent(
        intent=intent,
        reuse_plan=reuse_plan,
        template_mode="legacy",
    )
    canvas_seed = _normalize_canvas_for_frontend_contract(canvas_seed)

    warnings = _validate_canvas_config(canvas_seed)
    if warnings:
        logger.warning(
            "build_agentic_app_from_intent: synthesized canvas warnings user=%s warnings=%s",
            user_id_str,
            warnings,
        )

    generation_metadata = None
    should_generate = (
        reuse_plan.get("mode") == "generate_new"
        or reuse_plan.get("generate_agent")
        or reuse_plan.get("generate_workflow")
    )

    if should_generate:
        try:
            generation_metadata = await generate_assets_from_intent(
                intent=intent,
                user_id=user_uuid,
                generate_agent=reuse_plan.get("generate_agent", True),
                generate_workflow=reuse_plan.get("generate_workflow", True),
                model=payload.preferred_llm_model,
                request_id=request_id,
            )
        except AssetGenerationError as e:
            raise HTTPException(
                status_code=400,
                detail=f"Asset generation failed: {e.message}",
            )
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Asset generation failed unexpectedly: {str(e)}",
            )

    reusable_agent_id = reuse_plan.get("selected_agent_id")
    reusable_wf_id = reuse_plan.get("selected_workflow_id")
    agent_payload = ((generation_metadata or {}).get("agent") or {})
    workflow_payload = ((generation_metadata or {}).get("workflow") or {})
    generated_agent_id = agent_payload.get("agent_id") if isinstance(agent_payload, dict) else None
    generated_wf_id = workflow_payload.get("workflow_id") if isinstance(workflow_payload, dict) else None
    resolved_agent_id = generated_agent_id or reusable_agent_id
    resolved_workflow_id = generated_wf_id or reusable_wf_id

    if resolved_agent_id:
        for component in canvas_seed:
            if component.get("type") == "agent_trigger":
                props = component.get("props") or {}
                if not props.get("agent_id") or str(props.get("agent_id")).upper().startswith("PASTE_"):
                    props["agent_id"] = str(resolved_agent_id)
                    component["props"] = props

    if resolved_workflow_id:
        for component in canvas_seed:
            if component.get("type") == "workflow_trigger":
                props = component.get("props") or {}
                if not props.get("workflow_id") or str(props.get("workflow_id")).upper().startswith("PASTE_"):
                    props["workflow_id"] = str(resolved_workflow_id)
                    component["props"] = props

    logger.info(
        "build_agentic_app_from_intent: success request_id=%s user_id=%s mode=%s duration_ms=%d generation_errors=%d",
        request_id,
        user_id_str,
        reuse_plan.get("mode"),
        int((perf_counter() - route_start) * 1000),
        len((generation_metadata or {}).get("generation_errors", [])) if generation_metadata else 0,
    )
    return canvas_seed


# ---------------------------------------------------------------------------
# GET /api/applications/agentic  — List Agentic Apps
# ---------------------------------------------------------------------------


@router.get("", response_model=AgenticAppListResponse)
async def list_agentic_apps(
    user: UserContext = Depends(require_user),
):
    """
    Return all non-deleted agentic applications owned by the current user.

    Results are ordered newest-first (by ``created_at`` descending).
    Each item is a lightweight card — canvas_config is NOT included in
    the list to keep response payloads small.
    """
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid user identity")

    async with get_db_session() as db:
        stmt = (
            select(AgenticApplication)
            .where(
                AgenticApplication.user_id == user_uuid,
                AgenticApplication.is_deleted == False,  # noqa: E712
            )
            .order_by(AgenticApplication.created_at.desc())
        )
        result = await db.execute(stmt)
        apps: List[AgenticApplication] = list(result.scalars().all())

    cards = [_model_to_card(a) for a in apps]

    return AgenticAppListResponse(
        total=len(cards),
        items=cards,
    )


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/upload — FileField binary upload
# ---------------------------------------------------------------------------


@router.post("/upload", response_model=AgenticFileUploadResponse, status_code=201)
async def upload_agentic_file(
    agentic_app_id: str = Form(...),
    file: UploadFile = File(...),
    user: UserContext = Depends(require_user),
):
    """
    Upload a file for an agentic application.

    The frontend stores the returned handle in A2UI data_state at the FileField's dataPath,
    e.g. data_state["offer_letter_file"] = {file_id, original_filename, mime_type, size_bytes}.
    """
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid user identity: user_id '{user_id_str}' is not a UUID",
        )
    try:
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid agentic_app_id: '{agentic_app_id}' is not a UUID",
        )

    # Validate file (defaults; frontend enforces accepted_types too)
    await validate_upload(
        file,
        allowed_extensions=[".pdf", ".docx", ".txt", ".csv", ".md", ".png", ".jpg", ".jpeg"],
        max_size_bytes=10 * 1024 * 1024,
    )

    # Ensure app exists and is owned by user
    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()
        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")

        content = await file.read()
        size_bytes = len(content)

        original_filename = file.filename or "unnamed"
        stored_filename = f"{agentic_app_id}_{uuid.uuid4().hex}_{original_filename}"
        file_path = os.path.join(AGENTIC_UPLOADS_DIR, stored_filename)

        row = AgenticUploadedFile(
            agentic_app_id=app_uuid,
            user_id=user_uuid,
            original_filename=original_filename,
            stored_filename=stored_filename,
            mime_type=file.content_type,
            size_bytes=size_bytes,
            content=content,
        )
        db.add(row)
        await db.flush()  # get file_id

        # Optional disk write (disabled by default when content is stored in DB)
        store_disk = os.getenv("AGENTIC_UPLOAD_STORE_DISK", "false").lower() in ("1", "true", "yes")
        if store_disk:
            try:
                os.makedirs(AGENTIC_UPLOADS_DIR, exist_ok=True)
                with open(file_path, "wb") as f:
                    f.write(content)
            except OSError:
                logger.exception("upload_agentic_file: failed to write file: %s", file_path)
                raise HTTPException(status_code=500, detail="Failed to save uploaded file")

        await db.commit()
        await db.refresh(row)

        return AgenticFileUploadResponse(
            file_id=str(row.file_id),
            original_filename=row.original_filename,
            mime_type=row.mime_type,
            size_bytes=size_bytes,
            created_at=row.created_at,
        )


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/{id}/execute  — Mode 1: single component
# ---------------------------------------------------------------------------

@router.post("/execute", response_model=ExecuteResponse)
async def execute_component(
    payload: ExecuteRequest,
    user: UserContext = Depends(require_user),
):
    """
    Execute a single canvas component by component_id.

    Used by the canvas IDE Preview mode so the builder can test each
    trigger individually.
    """
    from .agentic_executor import dispatch, RUNNABLE_TYPES

    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid user identity: user_id '{user_id_str}' is not a UUID",
        )
    try:
        app_uuid = UUID(payload.agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=(
                "Invalid agentic_app_id: "
                f"'{payload.agentic_app_id}' is not a UUID"
            ),
        )

    # ------------------------------------------------------------------
    # 1. Load app
    # ------------------------------------------------------------------
    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

    if app is None:
        raise HTTPException(status_code=404, detail="Agentic app not found")

    canvas: List[dict] = app.canvas_config or []

    # ------------------------------------------------------------------
    # 2. Find target component
    # ------------------------------------------------------------------
    target = next(
        (c for c in canvas if c.get("id") == payload.component_id),
        None,
    )
    if target is None:
        raise HTTPException(
            status_code=404,
            detail=f"Component '{payload.component_id}' not found in canvas_config",
        )

    # ------------------------------------------------------------------
    # 3. Merge props: stored props + runtime override (override wins)
    # ------------------------------------------------------------------
    stored_props: dict = target.get("props") or {}
    final_props = {**stored_props, **payload.props_override}

    on_success_key: Optional[str] = final_props.get("on_success_key")

    # ------------------------------------------------------------------
    # 4. Validate component is runnable
    # ------------------------------------------------------------------
    comp_type = payload.component_type
    if comp_type not in RUNNABLE_TYPES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Component type '{comp_type}' is not executable. "
                f"Runnable types: {sorted(RUNNABLE_TYPES)}"
            ),
        )

    # ------------------------------------------------------------------
    # 5. Dispatch to handler
    # ------------------------------------------------------------------
    component_result = await dispatch(
        component_type=comp_type,
        props=final_props,
        data_state=payload.data_state,
        user_id=user_id_str,
        chat_message=payload.chat_message,
        chat_history=payload.chat_history,
    )

    logger.info(
        "execute_component: app=%s comp=%s type=%s success=%s",
        payload.agentic_app_id,
        payload.component_id,
        comp_type,
        component_result.success,
    )

    return ExecuteResponse(
        component_id=payload.component_id,
        component_type=comp_type,
        success=component_result.success,
        output=component_result.output,
        on_success_key=on_success_key,
        error=component_result.error,
    )


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/{id}/run  — Mode 2: full sequential
# ---------------------------------------------------------------------------

@router.post("/run", response_model=RunResponse)
async def run_agentic_app(
    payload: RunRequest,
    user: UserContext = Depends(require_user),
):
    """
    Run all runnable components in canvas Y-order in one request.

    Used when the end user fills all inputs and clicks Submit.
    """
    from .agentic_executor import dispatch, RUNNABLE_TYPES

    # In run mode, we execute chat_interface too (requires chat_message).
    SEQUENTIAL_TYPES = RUNNABLE_TYPES

    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid user identity: user_id '{user_id_str}' is not a UUID",
        )
    try:
        app_uuid = UUID(payload.agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=400,
            detail=(
                "Invalid agentic_app_id: "
                f"'{payload.agentic_app_id}' is not a UUID"
            ),
        )

    # ------------------------------------------------------------------
    # 1. Load app
    # ------------------------------------------------------------------
    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

    if app is None:
        raise HTTPException(status_code=404, detail="Agentic app not found")

    canvas: List[dict] = app.canvas_config or []

    if not canvas:
        raise HTTPException(
            status_code=400,
            detail="App has no canvas components — nothing to run",
        )

    # ------------------------------------------------------------------
    # 2. Sort by Y position (top-to-bottom)
    # ------------------------------------------------------------------
    sorted_canvas = sorted(canvas, key=lambda c: c.get("y", 0))

    # ------------------------------------------------------------------
    # 3. Seed data_state with user inputs
    # Normalise keys: strip leading "/" that the A2UI frontend may add
    # ------------------------------------------------------------------
    data_state: dict = {
        (k.lstrip("/") if isinstance(k, str) else k): v
        for k, v in payload.inputs.items()
    }

    # ------------------------------------------------------------------
    # 4. Execute runnable components in order
    # ------------------------------------------------------------------
    steps: List[RunStepResult] = []
    errors: List[str] = []
    ran = 0
    succeeded = 0

    for component in sorted_canvas:
        comp_id: str = component.get("id", "unknown")
        comp_type: str = component.get("type", "")
        props: dict = component.get("props") or {}
        data_key: str = props.get("data_key", comp_id)
        on_success_key: Optional[str] = props.get("on_success_key")

        # Skip non-runnable and chat_interface
        if comp_type not in SEQUENTIAL_TYPES:
            continue

        ran += 1

        component_result = await dispatch(
            component_type=comp_type,
            props=props,
            data_state=data_state,
            user_id=user_id_str,
            chat_message=payload.chat_message,
            chat_history=payload.chat_history,
        )

        step = RunStepResult(
            component_id=comp_id,
            component_type=comp_type,
            data_key=data_key,
            on_success_key=on_success_key,
            success=component_result.success,
            error=component_result.error,
        )
        steps.append(step)

        if component_result.success:
            succeeded += 1
            # Store output so subsequent components can use it
            if on_success_key:
                data_state[on_success_key] = component_result.output
            # Also store on the component's own data_key for completeness
            data_state[data_key] = component_result.output
        else:
            err_msg = component_result.error or f"Component '{comp_id}' failed"
            errors.append(err_msg)
            logger.warning(
                "run_agentic_app: step failed — app=%s comp=%s err=%s",
                payload.agentic_app_id,
                comp_id,
                err_msg,
            )

    # ------------------------------------------------------------------
    # 4b. Post-process: render HTML charts for visual components
    # ------------------------------------------------------------------
    from .agentic_executor import CHART_TYPES, render_chart_html

    for component in sorted_canvas:
        comp_type = component.get("type", "")
        if comp_type not in CHART_TYPES:
            continue
        props = component.get("props") or {}
        data_key = props.get("data_key", component.get("id"))
        raw_value = data_state.get(data_key)
        if raw_value is None:
            continue  # upstream trigger hasn't populated this key — skip
        try:
            html = await render_chart_html(comp_type, raw_value)
            data_state[data_key] = html
            logger.info(
                "run_agentic_app: chart HTML generated data_key=%s type=%s",
                data_key, comp_type,
            )
        except Exception as exc:
            logger.warning(
                "run_agentic_app: chart HTML failed data_key=%s: %s",
                data_key, exc,
            )
            # Leave the raw value in place — frontend can still attempt to handle it

    # ------------------------------------------------------------------
    # 5. Determine overall status
    # ------------------------------------------------------------------
    if ran == 0:
        overall_status = "success"   # nothing to run is still valid
    elif succeeded == ran:
        overall_status = "success"
    elif succeeded == 0:
        overall_status = "failed"
    else:
        overall_status = "partial"

    logger.info(
        "run_agentic_app: app=%s status=%s ran=%d succeeded=%d",
        payload.agentic_app_id, overall_status, ran, succeeded,
    )

    return RunResponse(
        agentic_app_id=payload.agentic_app_id,
        status=overall_status,
        outputs=data_state,
        steps=steps,
        errors=errors,
    )


# ---------------------------------------------------------------------------
# PUT /api/applications/agentic/{id}  — Update
# ---------------------------------------------------------------------------

@router.post("/update", response_model=AgenticAppDetail)
async def update_agentic_app(
    payload: AgenticAppUpdate,
    user: UserContext = Depends(require_user),
):
    """
    Update any fields of an agentic application.

    All fields are optional — only fields present in the request body
    are written. Fields omitted or set to null are left unchanged.
    """
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid user identity")

    async with get_db_session() as db:
        # Load app
        try:
            app_uuid = UUID(payload.agentic_app_id)
        except (ValueError, AttributeError):
            raise HTTPException(status_code=400, detail="Invalid agentic_app_id")

        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")

        # Apply only the fields that were explicitly provided
        if payload.name is not None:
            app.name = payload.name

        if payload.description is not None:
            app.description = payload.description

        if payload.status is not None:
            if payload.status not in ("draft", "published"):
                raise HTTPException(
                    status_code=400,
                    detail="status must be 'draft' or 'published'",
                )
            app.status = payload.status

        if payload.canvas_config is not None:
            app.canvas_config = payload.canvas_config

        # Manually bump updated_at since SQLAlchemy onupdate
        # only fires on column-level changes via ORM flush
        app.updated_at = datetime.now(timezone.utc)

        await db.commit()
        await db.refresh(app)

        logger.info(
            "update_agentic_app: id=%s user=%s fields=%s",
            payload.agentic_app_id,
            user_id_str,
            [f for f in ("name", "description", "status", "canvas_config")
             if getattr(payload, f) is not None],
        )

        return _model_to_detail(app)


# ---------------------------------------------------------------------------
# DELETE /api/applications/agentic/{id}  — Soft Delete
# ---------------------------------------------------------------------------

@router.post("/delete", status_code=204)
async def delete_agentic_app(
    payload: AgenticAppDelete,
    user: UserContext = Depends(require_user),
):
    """
    Hard-delete an agentic application (physical delete).

    This deletes the row from the database. Related uploaded files are
    removed via FK ON DELETE CASCADE.
    Returns 204 No Content on success.
    """
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid user identity")

    async with get_db_session() as db:
        try:
            app_uuid = UUID(payload.agentic_app_id)
        except (ValueError, AttributeError):
            raise HTTPException(status_code=400, detail="Invalid agentic_app_id")

        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")

        # Physical delete (FK cascades remove dependent uploads)
        await db.delete(app)
        await db.commit()

    logger.info(
        "delete_agentic_app: id=%s user=%s (hard deleted)",
        payload.agentic_app_id,
        user_id_str,
    )

    from fastapi import Response
    return Response(status_code=204)


# ---------------------------------------------------------------------------
# GET /api/applications/agentic/{id}  — Get Single App Detail
# ---------------------------------------------------------------------------

@router.get("/{agentic_app_id}", response_model=AgenticAppDetail)
async def get_agentic_app(
    agentic_app_id: str,
    user: UserContext = Depends(require_user),
):
    """
    Return the full detail of a single agentic application.

    Used by the published app runtime to load canvas_config + a2ui_config.
    """
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

    if app is None:
        raise HTTPException(status_code=404, detail="Agentic app not found")

    return _model_to_detail(app)


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/publish  — Publish App
# ---------------------------------------------------------------------------

@router.post("/publish", response_model=AgenticAppDetail)
async def publish_agentic_app(
    payload: PublishRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Publish an agentic application, making it available for end-user use.

    Validates the app has at least one runnable component before publishing.
    Sets status from 'draft' to 'published'.
    """
    from .agentic_executor import RUNNABLE_TYPES

    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(payload.agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")

        # Approval gate: must be approved before publishing
        if app.approval_status != "approved":
            raise HTTPException(
                status_code=400,
                detail="Application must be approved by a Super Admin before publishing",
            )

        # Validate: at least one runnable component
        canvas: list = app.canvas_config or []
        # runnable = [
        #     c for c in canvas
        #     if c.get("type", "") in RUNNABLE_TYPES
        # ]
        runnable = True
        if not runnable:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Cannot publish: the app has no runnable components "
                    "(need at least one agent_trigger, api_trigger, "
                    "workflow_trigger, or chat_interface)."
                ),
            )

        app.status = "published"
        app.updated_at = datetime.now(timezone.utc)

        await db.commit()
        await db.refresh(app)

        logger.info(
            "publish_agentic_app: id=%s user=%s",
            payload.agentic_app_id,
            user_id_str,
        )

        return _model_to_detail(app)


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/run/stream  — SSE Streaming Execution
# ---------------------------------------------------------------------------

@router.post("/run/stream")
async def run_agentic_app_stream(
    payload: RunStreamRequest,
    user: UserContext = Depends(require_user),
):
    """
    Run an agentic application with A2UI SSE streaming.

    All runnable components execute in canvas Y-order. Each execution step
    emits A2UI JSONL messages via Server-Sent Events.
    """
    from .agentic_pipeline import AgenticOrchestrationPipeline

    user_id_str = resolve_user_id(user)

    try:
        UUID(user_id_str)
        UUID(payload.agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    pipeline = AgenticOrchestrationPipeline()

    async def event_generator():
        async for msg in pipeline.run_streaming(
            app_id=payload.agentic_app_id,
            user_id=user_id_str,
            inputs=payload.inputs,
            triggered_components=payload.triggered_components,
            chat_message=payload.chat_message,
            chat_history=payload.chat_history,
        ):
            yield f"data: {msg}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# POST /api/applications/agentic/chat  — Per-Component Chat
# ---------------------------------------------------------------------------

@router.post("/chat")
async def chat_agentic_component(
    payload: ChatStreamRequest,
    user: UserContext = Depends(require_user),
):
    """
    Send a chat message to a specific chat_interface component.

    The response is streamed as A2UI JSONL via SSE. The chat is scoped
    to (app_id, component_id, user_id) for independent conversation history.
    """
    from .agentic_executor import dispatch
    from .agentic_a2ui_emitter import emit_data_update, emit_step_status

    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(payload.agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    # Load app
    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

    if app is None:
        raise HTTPException(status_code=404, detail="Agentic app not found")

    # Find the chat_interface component
    canvas: list = app.canvas_config or []
    target = next(
        (c for c in canvas if c.get("id") == payload.component_id),
        None,
    )
    if target is None:
        raise HTTPException(
            status_code=404,
            detail=f"Component '{payload.component_id}' not found in canvas",
        )
    if target.get("type") != "chat_interface":
        raise HTTPException(
            status_code=400,
            detail=f"Component '{payload.component_id}' is not a chat_interface",
        )

    props = target.get("props") or {}
    data_key = props.get("data_key", payload.component_id)

    # ── Session management ────────────────────────────────────────────
    session_obj: Optional[AgenticChatSession] = None
    chat_history: list = []

    if payload.session_id:
        # Try loading existing session
        try:
            session_uuid = UUID(payload.session_id)
            async with get_db_session() as db:
                stmt = select(AgenticChatSession).where(
                    AgenticChatSession.session_id == session_uuid,
                    AgenticChatSession.agentic_app_id == app_uuid,
                    AgenticChatSession.component_id == payload.component_id,
                    AgenticChatSession.user_id == user_uuid,
                )
                result = await db.execute(stmt)
                session_obj = result.scalar_one_or_none()
        except (ValueError, AttributeError):
            pass  # Invalid UUID → fall through to create new

    if session_obj:
        chat_history = list(session_obj.messages or [])
    else:
        # Use client-supplied history as fallback, or start fresh
        chat_history = list(payload.chat_history or [])
        # Create a new session
        session_obj = AgenticChatSession(
            agentic_app_id=app_uuid,
            component_id=payload.component_id,
            user_id=user_uuid,
            messages=chat_history,
            title=payload.message[:120] if payload.message else None,
        )
        async with get_db_session() as db:
            db.add(session_obj)
            await db.flush()

    # The session_id to return to the frontend
    session_id_str = str(session_obj.session_id)

    async def chat_event_generator():
        # Emit running status
        yield f"data: {emit_step_status(payload.agentic_app_id, payload.component_id, 'chat_interface', 'running')}\n\n"

        # Execute chat — pass server-side history to the LLM handler
        chat_result = await dispatch(
            component_type="chat_interface",
            props=props,
            data_state=payload.data_state,
            user_id=user_id_str,
            chat_message=payload.message,
            chat_history=chat_history,
        )

        if chat_result.success:
            output = chat_result.output
            content = output.get("content", str(output)) if isinstance(output, dict) else str(output)

            # Persist the turn (user + assistant) into the session
            updated_messages = list(chat_history)
            updated_messages.append({"role": "user", "content": payload.message})
            updated_messages.append({"role": "assistant", "content": content})
            try:
                async with get_db_session() as db:
                    stmt = select(AgenticChatSession).where(
                        AgenticChatSession.session_id == session_obj.session_id,
                    )
                    result = await db.execute(stmt)
                    row = result.scalar_one_or_none()
                    if row:
                        row.messages = updated_messages
                        row.updated_at = datetime.now(timezone.utc)
            except Exception:
                logger.warning("Failed to persist chat session %s", session_id_str, exc_info=True)

            # Emit A2UI messages
            yield f"data: {emit_data_update(payload.agentic_app_id, {f'{data_key}_history': content, data_key: content, f'{data_key}_session_id': session_id_str})}\n\n"
            yield f"data: {emit_step_status(payload.agentic_app_id, payload.component_id, 'chat_interface', 'completed')}\n\n"
        else:
            yield f"data: {emit_step_status(payload.agentic_app_id, payload.component_id, 'chat_interface', 'failed', error=chat_result.error)}\n\n"

    return StreamingResponse(
        chat_event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ===================================================================
# AGENTIC APPROVAL QUEUE ENDPOINTS
# ===================================================================

_audit_repo = ApprovalAuditRepository()
_notif_repo = NotificationRepository()


async def _notify_super_admins_for_agentic_app(
    db: AsyncSession,
    app: AgenticApplication,
    notif_type: str,
    title: str,
    message: str,
) -> None:
    """
    Create notifications for super_admins with matching BU/designation.

    Since agentic apps have no app-level BU/designation links, ABAC
    matches on the creator user's BU/designation against super_admin's.
    Falls back to all super_admins if no match.
    """
    creator_uuid = app.user_id

    # Super_admins whose designation overlaps with the creator's
    desig_match = User.user_id.in_(
        select(UserDesignationLink.user_id).where(
            UserDesignationLink.designation_id.in_(
                select(UserDesignationLink.designation_id).where(
                    UserDesignationLink.user_id == creator_uuid
                )
            )
        )
    )
    # Super_admins whose BU overlaps with the creator's
    bu_match = User.user_id.in_(
        select(UserBusinessUnitLink.user_id).where(
            UserBusinessUnitLink.business_unit_id.in_(
                select(UserBusinessUnitLink.business_unit_id).where(
                    UserBusinessUnitLink.user_id == creator_uuid
                )
            )
        )
    )
    stmt = select(User.user_id).where(
        User.role == "super_admin",
        User.is_active == True,  # noqa: E712
        desig_match,
        bu_match,
    )
    result = await db.execute(stmt)
    sa_ids = [str(uid) for uid in result.scalars().all()]

    if not sa_ids:
        # Fallback: notify all super_admins
        fallback = await db.execute(
            select(User.user_id).where(
                User.role == "super_admin",
                User.is_active == True,  # noqa: E712
            )
        )
        sa_ids = [str(uid) for uid in fallback.scalars().all()]

    if sa_ids:
        await _notif_repo.create_bulk_notifications(
            db,
            user_ids=sa_ids,
            type=notif_type,
            title=title,
            message=message,
            reference_id=str(app.agentic_app_id),
            reference_type="agentic_application",
        )


class AgenticRejectPayload(BaseModel):
    """Request body for rejecting an agentic application."""
    comment: Optional[str] = None


class AgenticApprovalQueueItem(BaseModel):
    """Agentic app card for the approval queue."""
    agentic_app_id: str
    app_type: str = "agentic"
    name: str
    description: Optional[str] = None
    status: str
    approval_status: str
    approved_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    user_id: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# -------------------------------------------------------------------
# GET /api/applications/agentic/approval-queue
# -------------------------------------------------------------------
@router.get("/approval-queue", response_model=List[AgenticApprovalQueueItem])
async def get_agentic_approval_queue(
    user: UserContext = Depends(require_super_admin),
):
    """List agentic applications pending approval."""
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
    except (ValueError, AttributeError):
        return []

    async with get_db_session() as db:
        # ABAC: only show agentic apps whose creator shares BU & designation
        # with the requesting super_admin, or apps the super_admin owns.
        desig_match = AgenticApplication.user_id.in_(
            select(UserDesignationLink.user_id).where(
                UserDesignationLink.designation_id.in_(
                    select(UserDesignationLink.designation_id).where(
                        UserDesignationLink.user_id == user_uuid
                    )
                )
            )
        )
        bu_match = AgenticApplication.user_id.in_(
            select(UserBusinessUnitLink.user_id).where(
                UserBusinessUnitLink.business_unit_id.in_(
                    select(UserBusinessUnitLink.business_unit_id).where(
                        UserBusinessUnitLink.user_id == user_uuid
                    )
                )
            )
        )
        stmt = (
            select(AgenticApplication)
            .where(
                AgenticApplication.approval_status == "pending",
                AgenticApplication.is_deleted == False,  # noqa: E712
                or_(
                    (desig_match & bu_match),
                    AgenticApplication.user_id == user_uuid,
                ),
            )
            .order_by(AgenticApplication.created_at.desc())
        )
        result = await db.execute(stmt)
        apps = list(result.scalars().all())

        return [
            AgenticApprovalQueueItem(
                agentic_app_id=str(app.agentic_app_id),
                name=app.name,
                description=app.description,
                status=app.status,
                approval_status=app.approval_status,
                approved_by=str(app.approved_by) if app.approved_by else None,
                rejection_reason=app.rejection_reason,
                user_id=str(app.user_id),
                created_at=app.created_at,
                updated_at=app.updated_at,
            )
            for app in apps
        ]


# -------------------------------------------------------------------
# POST /api/applications/agentic/{agentic_app_id}/approve
# -------------------------------------------------------------------
@router.post("/{agentic_app_id}/approve", response_model=AgenticAppDetail)
async def approve_agentic_app(
    agentic_app_id: str,
    user: UserContext = Depends(require_super_admin),
):
    """Approve an agentic application (super_admin only)."""
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")
        if app.approval_status != "pending":
            raise HTTPException(status_code=400, detail=f"App is not pending approval (current: {app.approval_status})")

        app.approval_status = "approved"
        app.approved_by = user_uuid
        app.rejection_reason = None
        app.updated_at = datetime.now(timezone.utc)
        await db.flush()

        # Audit log
        await _audit_repo.log_action(
            db,
            agentic_app_id=agentic_app_id,
            action="approved",
            performed_by=user_id_str,
        )

        # Notify app owner
        await _notif_repo.create_notification(
            db,
            user_id=str(app.user_id),
            type="approval_approved",
            title=f"Application '{app.name}' approved",
            message=f"Your agentic application '{app.name}' has been approved. You can now publish it.",
            reference_id=agentic_app_id,
            reference_type="agentic_application",
        )

        await db.commit()
        await db.refresh(app)
        return _model_to_detail(app)


# -------------------------------------------------------------------
# POST /api/applications/agentic/{agentic_app_id}/reject
# -------------------------------------------------------------------
@router.post("/{agentic_app_id}/reject", response_model=AgenticAppDetail)
async def reject_agentic_app(
    agentic_app_id: str,
    payload: AgenticRejectPayload = None,
    user: UserContext = Depends(require_super_admin),
):
    """Reject an agentic application with optional comment (super_admin only)."""
    user_id_str = resolve_user_id(user)
    comment = payload.comment if payload else None

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")
        if app.approval_status != "pending":
            raise HTTPException(status_code=400, detail=f"App is not pending approval (current: {app.approval_status})")

        app.approval_status = "rejected"
        app.approved_by = user_uuid
        app.rejection_reason = comment
        app.updated_at = datetime.now(timezone.utc)
        await db.flush()

        # Audit log
        await _audit_repo.log_action(
            db,
            agentic_app_id=agentic_app_id,
            action="rejected",
            performed_by=user_id_str,
            comment=comment,
        )

        # Notify app owner
        msg = f"Your agentic application '{app.name}' was rejected."
        if comment:
            msg += f" Reason: {comment}"
        await _notif_repo.create_notification(
            db,
            user_id=str(app.user_id),
            type="approval_rejected",
            title=f"Application '{app.name}' rejected",
            message=msg,
            reference_id=agentic_app_id,
            reference_type="agentic_application",
        )

        await db.commit()
        await db.refresh(app)
        return _model_to_detail(app)


# -------------------------------------------------------------------
# POST /api/applications/agentic/{agentic_app_id}/resubmit-approval
# -------------------------------------------------------------------
@router.post("/{agentic_app_id}/resubmit-approval", response_model=AgenticAppDetail)
async def resubmit_agentic_app(
    agentic_app_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Resubmit a rejected agentic application for approval."""
    user_id_str = resolve_user_id(user)

    try:
        user_uuid = UUID(user_id_str)
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()

        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")
        if app.approval_status != "rejected":
            raise HTTPException(status_code=400, detail="Only rejected applications can be resubmitted")

        app.approval_status = "pending"
        app.approved_by = None
        app.rejection_reason = None
        app.status = "draft"
        app.updated_at = datetime.now(timezone.utc)
        await db.flush()

        # Audit log
        await _audit_repo.log_action(
            db,
            agentic_app_id=agentic_app_id,
            action="resubmitted",
            performed_by=user_id_str,
        )

        # Notify super_admins
        await _notify_super_admins_for_agentic_app(
            db, app,
            notif_type="approval_pending",
            title=f"Agentic application '{app.name}' resubmitted",
            message=f"Agentic application '{app.name}' has been resubmitted for approval.",
        )

        await db.commit()
        await db.refresh(app)
        return _model_to_detail(app)


# -------------------------------------------------------------------
# GET /api/applications/agentic/{agentic_app_id}/audit-trail
# -------------------------------------------------------------------
@router.get("/{agentic_app_id}/audit-trail")
async def get_agentic_audit_trail(
    agentic_app_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Get the approval audit trail for an agentic application."""
    user_id_str = resolve_user_id(user)

    try:
        app_uuid = UUID(agentic_app_id)
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Invalid ID format")

    async with get_db_session() as db:
        # Verify caller owns the app or is super_admin
        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        app = result.scalar_one_or_none()
        if app is None:
            raise HTTPException(status_code=404, detail="Agentic app not found")
        if str(app.user_id) != user_id_str and user.role != "super_admin":
            raise HTTPException(status_code=403, detail="You can only view audit trails for your own applications")

        entries = await _audit_repo.get_audit_trail(db, agentic_app_id=agentic_app_id)
        return [
            {
                "audit_id": str(e.audit_id),
                "action": e.action,
                "performed_by": str(e.performed_by),
                "comment": e.comment,
                "created_at": e.created_at.isoformat(),
            }
            for e in entries
        ]


# ---------------------------------------------------------------------------
# NEW PHASE 4: File Download Endpoint
# ---------------------------------------------------------------------------

@router.get("/files/{file_id}/download")
async def download_generated_file(
    file_id: str,
    user: UserContext = Depends(require_user),
) -> StreamingResponse:
    """
    Download a generated file (PPT, PDF, etc) by file_id.
    
    Security: Verify user owns the file before streaming.
    
    Args:
        file_id: UUID of the registered file
        user: Current user context
        
    Returns:
        StreamingResponse with file content
    """
    try:
        file_uuid = UUID(file_id)
        user_id_str = resolve_user_id(user)
        user_uuid = UUID(user_id_str)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Invalid file_id format")
    
    try:
        async with get_db_session() as db:
            stmt = select(AgenticUploadedFile).where(
                AgenticUploadedFile.file_id == file_uuid,
                AgenticUploadedFile.user_id == user_uuid,
            )
            result = await db.execute(stmt)
            file_record = result.scalar_one_or_none()
            
            if file_record is None:
                raise HTTPException(
                    status_code=404,
                    detail="File not found or access denied",
                )
            
            # Check if file exists on disk
            file_path = file_record.file_path
            if not os.path.exists(file_path):
                logger.error("File record exists but file missing: %s", file_path)
                raise HTTPException(
                    status_code=404,
                    detail="File not found on disk",
                )
            
            # Stream file to client
            logger.info(
                "download_generated_file: user=%s file=%s",
                user_id_str, file_record.original_filename,
            )
            
            def file_iterator(path: str, chunk_size: int = 8192):
                with open(path, 'rb') as f:
                    while True:
                        chunk = f.read(chunk_size)
                        if not chunk:
                            break
                        yield chunk
            
            return StreamingResponse(
                file_iterator(file_path),
                media_type=file_record.mime_type or "application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename=\"{file_record.original_filename}\"",
                },
            )
    
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("download_generated_file: unexpected error: %s", exc)
        raise HTTPException(status_code=500, detail="File download failed")
