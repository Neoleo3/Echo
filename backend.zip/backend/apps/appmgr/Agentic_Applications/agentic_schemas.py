"""
EchoAI Agentic Application — Pydantic Schemas

Request and response models for the agentic application endpoints:
    POST /api/applications/agentic   (build + save as draft)
    GET  /api/applications/agentic   (list agentic apps)

Design:
    - AgenticAppCreate  : what the frontend sends when the user hits Build
    - AgenticAppCard    : lightweight card shown in the list view
    - AgenticAppDetail  : full record including canvas_config
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ---------------------------------------------------------------------------
# REQUEST SCHEMAS
# ---------------------------------------------------------------------------


class AgenticAppCreate(BaseModel):
    """
    Payload sent by the canvas IDE when the user clicks Build.

    Only ``name`` and ``canvas_config`` are required.
    ``canvas_config`` must be a non-empty list — an empty canvas cannot
    be saved as a meaningful application.
    """

    name: str = Field(..., min_length=1, max_length=255,
                      description="Display name for the application")

    description: Optional[str] = Field(
        None,
        description="Optional free-text description",
    )

    canvas_config: List[Dict[str, Any]] = Field(
        ...,
        min_length=1,
        description=(
            "Flat array of canvas component objects produced by the IDE. "
            "Each element must have at minimum: id (str), type (str)."
        ),
    )

    @field_validator("name", mode="before")
    @classmethod
    def strip_name(cls, v: Any) -> Any:
        if isinstance(v, str):
            return v.strip()
        return v

    @field_validator("canvas_config", mode="before")
    @classmethod
    def validate_canvas_not_empty(cls, v: Any) -> Any:
        if isinstance(v, list) and len(v) == 0:
            raise ValueError("canvas_config must not be empty")
        return v


class AgenticIntentCreate(BaseModel):
    """
    Intent-first app creation payload.

    The user can describe the desired app/website and the backend will:
      1) infer intent,
      2) reuse existing user workflows/agents when suitable,
      3) synthesize an initial canvas,
      4) orchestrate A2UI output.
    """

    prompt: str = Field(
        ...,
        min_length=8,
        max_length=6000,
        description="Natural language app/website description from the user",
    )

    name: Optional[str] = Field(
        None,
        min_length=1,
        max_length=255,
        description="Optional app name override",
    )

    description: Optional[str] = Field(
        None,
        description="Optional app description override",
    )

    preferred_artifact_mode: Optional[str] = Field(
        None,
        description="Optional hint such as website, dashboard, workflow, report",
    )

    preferred_llm_model: Optional[str] = Field(
        None,
        description="Optional LLM model override for asset generation (e.g., gpt-4o-mini, gpt-4o)",
    )

    auto_generate_assets: bool = Field(
        True,
        description=(
            "If true, allow automatic generation path when no suitable existing "
            "workflow/agent matches are found."
        ),
    )

    selected_candidate: Optional[str] = Field(
        None,
        max_length=1024,
        description=(
            "Optional HITL selection token from candidate_options. "
            "Accepted formats: 'agent:<id>:<name>', 'workflow:<id>:<name>', or 'generate:new'."
        ),
    )

    selected_assets: Optional[str] = Field(
        None,
        max_length=2048,
        description=(
            "NEW: Multi-asset selection format for checkboxes (multi-select). "
            "Format: 'agent_ids:id1,id2|workflow_ids:id3'. "
            "At least one must be present. Overrides selected_candidate if provided."
        ),
    )

    from_hitl_refine: bool = Field(
        False,
        description="Indicates this request is a retry after a HITL clarification/reuse response.",
    )

    @field_validator("prompt", mode="before")
    @classmethod
    def strip_prompt(cls, v: Any) -> Any:
        if isinstance(v, str):
            return v.strip()
        return v

    @field_validator("name", mode="before")
    @classmethod
    def strip_name_optional(cls, v: Any) -> Any:
        if isinstance(v, str):
            return v.strip()
        return v

    @field_validator("selected_candidate", mode="before")
    @classmethod
    def strip_selected_candidate(cls, v: Any) -> Any:
        if isinstance(v, str):
            value = v.strip()
            return value or None
        return v

    @field_validator("selected_assets", mode="before")
    @classmethod
    def strip_selected_assets(cls, v: Any) -> Any:
        if isinstance(v, str):
            value = v.strip()
            return value or None
        return v


# ---------------------------------------------------------------------------
# ACTION DEFINITIONS — workflow execution contract
# ---------------------------------------------------------------------------


class ActionInputMapping(BaseModel):
    """Maps an input component to a workflow input parameter."""

    component_id: str = Field(
        ...,
        description="The canvas component ID that captures user input",
    )
    component_type: str = Field(
        ...,
        description="Component type slug: short_text, text_area, number, select, etc.",
    )
    data_key: str = Field(
        ...,
        description="The key where this input is stored in frontend data_state",
    )
    label: Optional[str] = Field(
        None,
        description="Human-readable label extracted from component props",
    )


class ActionOutputMapping(BaseModel):
    """Maps a workflow output to a display component."""

    component_id: str = Field(
        ...,
        description="The canvas component ID that displays output",
    )
    component_type: str = Field(
        ...,
        description="Component type slug: markdown_viewer, table, chart, etc.",
    )
    output_key: Optional[str] = Field(
        None,
        description="The key where workflow output is stored in data_state",
    )
    label: Optional[str] = Field(
        None,
        description="Human-readable label extracted from component props",
    )


class WorkflowAction(BaseModel):
    """Defines a single executable workflow action."""

    action_id: str = Field(
        ...,
        description="Unique action identifier: typically 'run_workflow'",
    )
    workflow_id: str = Field(
        ...,
        description="UUID of the workflow to execute",
    )
    input_mapping: List[ActionInputMapping] = Field(
        default_factory=list,
        description="How to map canvas inputs to workflow parameters",
    )
    output_mapping: List[ActionOutputMapping] = Field(
        default_factory=list,
        description="How to map workflow outputs to display components",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        None,
        description="Additional metadata: execution hints, timeouts, etc.",
    )


class AgentAction(BaseModel):
    """Defines a single executable agent action."""

    action_id: str = Field(
        ...,
        description="Unique action identifier: typically 'run_agent'",
    )
    agent_id: str = Field(
        ...,
        description="UUID of the agent to execute",
    )
    input_mapping: List[ActionInputMapping] = Field(
        default_factory=list,
        description="How to map canvas inputs to agent parameters",
    )
    output_mapping: List[ActionOutputMapping] = Field(
        default_factory=list,
        description="How to map agent outputs to display components",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        None,
        description="Additional metadata: execution hints, timeouts, etc.",
    )


class Actions(BaseModel):
    """Encapsulates all executable actions for an agentic application."""

    run_workflow: Optional[WorkflowAction] = Field(
        None,
        description="Default workflow execution action. Present on generated apps.",
    )
    run_agent: Optional[AgentAction] = Field(
        None,
        description="Default agent execution action. Present on generated apps.",
    )

# ---------------------------------------------------------------------------
# RESPONSE SCHEMAS
# ---------------------------------------------------------------------------


class AgenticAppCard(BaseModel):
    """
    Lightweight card returned in the list view.

    Contains only the fields needed to render an app card in the
    Applications list alongside custom apps.
    """

    agentic_app_id: str
    name: str
    description: Optional[str] = None
    status: str
    app_type: str = "agentic"   # constant — tells frontend this is an agentic app
    approval_status: str = "pending"
    approved_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AgenticAppDetail(BaseModel):
    """
    Full agentic application record including canvas_config.

    Returned by the build endpoint (POST) and any future
    detail / edit endpoint (GET /{id}).
    """

    agentic_app_id: str
    user_id: str
    name: str
    description: Optional[str] = None
    status: str
    app_type: str = "agentic"
    canvas_config: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list,
        description="Full canvas component array",
    )
    a2ui_config: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "LLM-generated A2UI JSON returned to frontend for rendering. "
            "Contains components array and data bindings."
        ),
    )
    orchestration_metadata: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "LLM orchestration snapshot: classified app_type, reasoning, "
            "selected_agents, selected_workflows, selected_skills, selected_persona."
        ),
    )
    actions: Optional[Actions] = Field(
        None,
        description=(
            "Executable workflow actions. Defines action_id, workflow_id, "
            "input/output mappings, removing backend routing knowledge from UI."
        ),
    )
    created_at: datetime
    updated_at: datetime
    approval_status: str = "pending"
    approved_by: Optional[str] = None
    rejection_reason: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class AgenticAppListResponse(BaseModel):
    """Response envelope for GET /api/applications/agentic."""

    total: int
    items: List[AgenticAppCard]


# ---------------------------------------------------------------------------
# FILE UPLOAD (A2UI FileField) — store binary, return JSON handle
# ---------------------------------------------------------------------------


class AgenticFileUploadResponse(BaseModel):
    """Response from POST /api/applications/agentic/upload."""

    file_id: str
    original_filename: str
    mime_type: Optional[str] = None
    size_bytes: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# EXECUTE — single component (Mode 1 / builder preview)
# ---------------------------------------------------------------------------

class ExecuteRequest(BaseModel):
    """
    Request body for POST /api/applications/agentic/{id}/execute

    Runs one component by its component_id.
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to execute the component from",
    )
    component_id: str = Field(
        ...,
        description="The 'id' field of the target component in canvas_config",
    )
    component_type: str = Field(
        ...,
        description="Type slug: agent_trigger | api_trigger | workflow_trigger | chat_interface",
    )
    data_state: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Current frontend data_state: all filled input values and "
            "results accumulated so far, keyed by data_key."
        ),
    )
    props_override: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Runtime overrides merged over stored props from canvas_config. "
            "Override wins. Used for builder testing."
        ),
    )
    chat_message: Optional[str] = Field(
        None, description="Current user message (chat_interface only)"
    )
    chat_history: Optional[List[Dict[str, Any]]] = Field(
        None, description="Prior conversation turns (chat_interface only)"
    )


class ExecuteResponse(BaseModel):
    """Response from POST /api/applications/agentic/{id}/execute"""

    component_id: str
    component_type: str
    success: bool
    output: Optional[Any] = Field(
        None,
        description="Result to store at on_success_key in frontend data_state",
    )
    on_success_key: Optional[str] = Field(
        None,
        description=(
            "data_key of the display component that receives output. "
            "Frontend sets data_state[on_success_key] = output."
        ),
    )
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# RUN — full sequential (Mode 2 / end user submit)
# ---------------------------------------------------------------------------

class RunRequest(BaseModel):
    """
    Request body for POST /api/applications/agentic/run
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to run",
    )

    chat_message: Optional[str] = Field(
        None,
        description=(
            "Optional chat message used when the canvas contains a chat_interface "
            "component."
        ),
    )
    chat_history: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Optional prior chat turns for chat_interface execution.",
    )

    inputs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "User-provided runtime input values keyed by data_key. "
            "Example: {\"short_text_3\": \"EMP-1042\"}"
        ),
    )


class RunStepResult(BaseModel):
    """Result of one component step during a full run."""

    component_id: str
    component_type: str
    data_key: str
    on_success_key: Optional[str] = None
    success: bool
    error: Optional[str] = None


class RunResponse(BaseModel):
    """Response from POST /api/applications/agentic/{id}/run"""

    agentic_app_id: str
    status: str = Field(
        description="'success' | 'partial' | 'failed'"
    )
    outputs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Final data_state after all components ran. "
            "Keyed by data_key."
        ),
    )
    steps: List[RunStepResult] = Field(
        default_factory=list,
        description="Per-step execution summary.",
    )
    errors: List[str] = Field(
        default_factory=list,
        description="Collected error messages from failed steps.",
    )


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------

class AgenticAppUpdate(BaseModel):
    """
    Request body for POST /api/applications/agentic/update
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to update",
    )
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    status: Optional[str] = Field(
        None,
        description="Lifecycle status: draft | published",
    )
    canvas_config: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Full replacement canvas_config array. Pass null to leave unchanged.",
    )

    @field_validator("name", mode="before")
    @classmethod
    def strip_name(cls, v: Any) -> Any:
        if isinstance(v, str):
            return v.strip()
        return v


class AgenticAppDelete(BaseModel):
    """
    Request body for POST /api/applications/agentic/delete
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to delete",
    )


# ---------------------------------------------------------------------------
# RUN STREAM — SSE streaming mode
# ---------------------------------------------------------------------------

class RunStreamRequest(BaseModel):
    """
    Request body for POST /api/applications/agentic/run/stream
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to run",
    )

    inputs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "User-provided runtime input values keyed by data_key."
        ),
    )

    triggered_components: Optional[List[str]] = Field(
        None,
        description=(
            "Optional list of component IDs to execute (from submit button triggers). "
            "If null/omitted, all runnable components execute in Y-order."
        ),
    )

    chat_message: Optional[str] = Field(
        None,
        description="Optional chat message for chat_interface components.",
    )
    chat_history: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Optional prior chat turns for chat_interface execution.",
    )


# ---------------------------------------------------------------------------
# CHAT STREAM — per-component chat
# ---------------------------------------------------------------------------

class ChatStreamRequest(BaseModel):
    """
    Request body for POST /api/applications/agentic/{id}/chat
    """

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app",
    )

    component_id: str = Field(
        ...,
        description="ID of the chat_interface component on the canvas",
    )

    message: str = Field(
        ..., min_length=1,
        description="The user's chat message",
    )

    session_id: Optional[str] = Field(
        None,
        description=(
            "Existing chat session UUID. Omit to create a new session "
            "scoped to (app_id, component_id, user_id)."
        ),
    )

    data_state: Dict[str, Any] = Field(
        default_factory=dict,
        description="Current frontend data_state for context.",
    )

    chat_history: Optional[List[Dict[str, Any]]] = Field(
        None,
        description="Prior conversation turns.",
    )


# ---------------------------------------------------------------------------
# PUBLISH
# ---------------------------------------------------------------------------

class PublishRequest(BaseModel):
    """Request body for POST /api/applications/agentic/{id}/publish"""

    agentic_app_id: str = Field(
        ...,
        description="ID of the agentic app to publish",
    )
