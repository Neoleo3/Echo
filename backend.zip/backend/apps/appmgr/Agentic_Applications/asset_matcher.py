"""
Asset matcher for intent-first app generation.

Finds and ranks existing user workflows/agents by intent overlap so the
system can reuse existing assets before generating new ones.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Set
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models.agent import Agent
from echolib.models.workflow import Workflow
from echolib.repositories.storage_gateway import StorageGateway
from echolib.repositories.workflow_repo import WorkflowRepository

logger = logging.getLogger(__name__)

_STOPWORDS = {
    "a", "an", "the", "and", "or", "to", "for", "of", "in", "on", "with",
    "is", "are", "be", "it", "this", "that", "i", "we", "you", "my", "our",
} # too static


def _keywords(text: str) -> Set[str]:
    if not isinstance(text, str):
        return set()
    tokens = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return {t for t in tokens if len(t) >= 3 and t not in _STOPWORDS}


def _overlap_score(intent_keys: Set[str], text: str) -> float:
    if not intent_keys:
        return 0.0
    cand = _keywords(text)
    if not cand:
        return 0.0
    overlap = intent_keys.intersection(cand)
    return len(overlap) / max(1, len(intent_keys))


def _infer_intent_target(intent_text: str) -> str:
    text = (intent_text or "").lower()
    workflow_terms = {"workflow", "approval", "pipeline", "process", "orchestrate", "steps", "automation"}
    agent_terms = {"agent", "assistant", "chat", "copilot", "qa", "ask", "conversational"}

    workflow_hits = sum(1 for term in workflow_terms if term in text)
    agent_hits = sum(1 for term in agent_terms if term in text)

    if workflow_hits > agent_hits:
        return "workflow"
    if agent_hits > workflow_hits:
        return "agent"
    return "neutral"


def _recency_bonus(ts: Any) -> float:
    if not isinstance(ts, datetime):
        return 0.0

    now = datetime.now(timezone.utc)
    dt = ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)
    age_days = max(0, (now - dt).days)

    if age_days <= 30:
        return 0.12
    if age_days <= 90:
        return 0.08
    if age_days <= 180:
        return 0.04
    return 0.0


def _type_affinity_bonus(intent_target: str, asset_type: str) -> float:
    if intent_target == "neutral":
        return 0.0
    return 0.08 if intent_target == asset_type else -0.02


def _final_score(*, overlap: float, recency: float, affinity: float) -> float:
    score = (0.85 * overlap) + recency + affinity
    return max(0.0, min(1.0, score))


async def _discover_agents(user_id: str) -> List[Dict[str, Any]]:
    """Discovery-first agent retrieval using StorageGateway list path."""
    gateway = StorageGateway()
    discovered: List[Dict[str, Any]] = []

    try:
        for item in await gateway.list_agents(user_id):
            if not isinstance(item, dict):
                continue
            agent_id = str(item.get("agent_id") or "").strip()
            if not agent_id:
                continue
            discovered.append(
                {
                    "agent_id": agent_id,
                    "name": str(item.get("name") or "").strip() or "Unnamed Agent",
                    "role": str(item.get("role") or "").strip(),
                    "description": str(
                        item.get("description")
                        or item.get("backstory")
                        or ((item.get("definition") or {}).get("description") if isinstance(item.get("definition"), dict) else "")
                        or ""
                    ).strip(),
                    "updated_at": item.get("updated_at"),
                    "created_at": item.get("created_at"),
                    "source": "discovery_gateway",
                }
            )
    except Exception as exc:
        logger.warning("asset_matcher: agent discovery failed for user=%s error=%s", user_id, exc)

    return discovered


async def _discover_workflows(db: AsyncSession, user_id: str) -> List[Dict[str, Any]]:
    """Discovery-first workflow retrieval using repository list path."""
    repo = WorkflowRepository()
    discovered: List[Dict[str, Any]] = []

    try:
        rows = await repo.list_by_user(db, user_id, limit=500)
        for row in rows:
            definition = row.definition or {}
            discovered.append(
                {
                    "workflow_id": str(row.workflow_id),
                    "name": str(row.name or "").strip() or "Unnamed Workflow",
                    "description": str(
                        definition.get("description") if isinstance(definition, dict) else ""
                    ).strip(),
                    "status": str(getattr(row, "status", "") or "").strip(),
                    "updated_at": getattr(row, "updated_at", None),
                    "created_at": getattr(row, "created_at", None),
                    "source": "workflow_repository",
                }
            )
    except Exception as exc:
        logger.warning("asset_matcher: workflow discovery failed for user=%s error=%s", user_id, exc)

    return discovered


async def rank_existing_assets(
    *,
    db: AsyncSession,
    user_uuid: UUID,
    intent_text: str,
    max_candidates: int = 5,
) -> Dict[str, List[Dict[str, Any]]]:
    """Return ranked agent/workflow candidates for the user."""
    intent_keys = _keywords(intent_text)
    intent_target = _infer_intent_target(intent_text)

    discovered_agents = await _discover_agents(str(user_uuid))
    discovered_workflows = await _discover_workflows(db, str(user_uuid))

    # Fallback to direct model queries if discovery returned nothing.
    if not discovered_agents:
        agents_result = await db.execute(
            select(Agent).where(
                Agent.user_id == user_uuid,
                Agent.is_deleted == False,  # noqa: E712
            )
        )
        for a in agents_result.scalars().all():
            definition = a.definition or {}
            discovered_agents.append(
                {
                    "agent_id": str(a.agent_id),
                    "name": str(a.name or "").strip() or "Unnamed Agent",
                    "role": str(definition.get("role") or "").strip(),
                    "description": str(
                        definition.get("description") or definition.get("backstory") or ""
                    ).strip(),
                    "updated_at": getattr(a, "updated_at", None),
                    "created_at": getattr(a, "created_at", None),
                    "source": "direct_db_fallback",
                }
            )

    if not discovered_workflows:
        workflows_result = await db.execute(
            select(Workflow).where(
                Workflow.user_id == user_uuid,
                Workflow.is_deleted == False,  # noqa: E712
            )
        )
        for w in workflows_result.scalars().all():
            definition = w.definition or {}
            discovered_workflows.append(
                {
                    "workflow_id": str(w.workflow_id),
                    "name": str(w.name or "").strip() or "Unnamed Workflow",
                    "description": str(definition.get("description") or "").strip(),
                    "status": str(getattr(w, "status", "") or "").strip(),
                    "updated_at": getattr(w, "updated_at", None),
                    "created_at": getattr(w, "created_at", None),
                    "source": "direct_db_fallback",
                }
            )

    agent_candidates: List[Dict[str, Any]] = []
    for a in discovered_agents:
        text = " ".join(
            str(x)
            for x in [a.get("name", ""), a.get("role", ""), a.get("description", "")]
            if x
        )
        overlap = _overlap_score(intent_keys, text)
        recency = _recency_bonus(a.get("updated_at") or a.get("created_at"))
        affinity = _type_affinity_bonus(intent_target, "agent")
        score = _final_score(overlap=overlap, recency=recency, affinity=affinity)
        if score <= 0:
            continue
        agent_candidates.append(
            {
                "asset_type": "agent",
                "asset_id": str(a.get("agent_id") or ""),
                "name": str(a.get("name") or "Unnamed Agent"),
                "score": round(score, 4),
                "why": f"overlap={overlap:.3f}; recency={recency:.3f}; affinity={affinity:.3f}",
                "source": a.get("source", "unknown"),
            }
        )

    workflow_candidates: List[Dict[str, Any]] = []
    for w in discovered_workflows:
        text = " ".join(
            str(x)
            for x in [w.get("name", ""), w.get("description", ""), w.get("status", "")]
            if x
        )
        overlap = _overlap_score(intent_keys, text)
        recency = _recency_bonus(w.get("updated_at") or w.get("created_at"))
        affinity = _type_affinity_bonus(intent_target, "workflow")
        score = _final_score(overlap=overlap, recency=recency, affinity=affinity)
        if score <= 0:
            continue
        workflow_candidates.append(
            {
                "asset_type": "workflow",
                "asset_id": str(w.get("workflow_id") or ""),
                "name": str(w.get("name") or "Unnamed Workflow"),
                "score": round(score, 4),
                "why": f"overlap={overlap:.3f}; recency={recency:.3f}; affinity={affinity:.3f}",
                "source": w.get("source", "unknown"),
            }
        )

    agent_candidates.sort(key=lambda x: x["score"], reverse=True)
    workflow_candidates.sort(key=lambda x: x["score"], reverse=True)

    ranked = {
        "agents": agent_candidates[:max_candidates],
        "workflows": workflow_candidates[:max_candidates],
    }

    logger.info(
        "asset_matcher: user=%s intent_target=%s candidates agents=%d workflows=%d",
        str(user_uuid),
        intent_target,
        len(ranked["agents"]),
        len(ranked["workflows"]),
    )
    return ranked
