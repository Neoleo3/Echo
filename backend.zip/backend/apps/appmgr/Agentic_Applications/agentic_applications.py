"""
DEPRECATED — Re-export from canonical location.

The authoritative model lives at ``echolib.models.agentic_application``.
This file exists only so that any accidental ``from .agentic_applications
import AgenticApplication`` within this package still resolves correctly.
"""

from echolib.models.agentic_application import AgenticApplication  # noqa: F401

__all__ = ["AgenticApplication"]
