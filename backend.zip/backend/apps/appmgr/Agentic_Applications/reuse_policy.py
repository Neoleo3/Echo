"""Reuse policy for choosing existing assets vs generation path."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

HIGH_CONFIDENCE_THRESHOLD = 0.62
MEDIUM_CONFIDENCE_THRESHOLD = 0.32
LOW_REUSE_THRESHOLD = 0.15


def decide_reuse_plan(
    *,
    intent: Dict[str, Any],
    candidates: Dict[str, Any],
    auto_generate_assets: bool,
    selected_agent_from_hitl: Optional[str] = None,
    selected_workflow_from_hitl: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Decide reuse/generate/HITL behavior.

    Returns a plan dict with keys:
      - mode: reuse | hitl_reuse_choice | generate_new | hitl_clarification
      - selected_agent_id / selected_workflow_id
      - reasons
      - generate_agent: bool indicating if new agent should be generated
      - generate_workflow: bool indicating if new workflow should be generated
    """
    confidence = float(intent.get("confidence", 0.0) or 0.0)
    missing = intent.get("missing_details") or []
    if confidence < 0.5 or missing:
        logger.info("reuse_policy: clarification required confidence=%.3f missing=%d", confidence, len(missing))
        return {
            "mode": "hitl_clarification",
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "reasons": ["low_intent_confidence_or_missing_details"],
            "generate_agent": False,
            "generate_workflow": False,
        }

    # If HITL selections were made, use them
    if selected_agent_from_hitl or selected_workflow_from_hitl:
        logger.info(
            "reuse_policy: using HITL selection agent_id=%s workflow_id=%s",
            selected_agent_from_hitl,
            selected_workflow_from_hitl,
        )
        return {
            "mode": "reuse",
            "selected_agent_id": selected_agent_from_hitl,
            "selected_workflow_id": selected_workflow_from_hitl,
            "reasons": ["hitl_user_selection"],
            "generate_agent": selected_agent_from_hitl is None,
            "generate_workflow": selected_workflow_from_hitl is None,
        }

    top_agent = (candidates.get("agents") or [None])[0]
    top_wf = (candidates.get("workflows") or [None])[0]
    has_any_candidate = bool(top_agent or top_wf)
    top_score = max(
        float((top_agent or {}).get("score", 0.0) or 0.0),
        float((top_wf or {}).get("score", 0.0) or 0.0),
    )

    if top_score >= HIGH_CONFIDENCE_THRESHOLD:
        agent_score = float((top_agent or {}).get("score", 0.0) or 0.0)
        workflow_score = float((top_wf or {}).get("score", 0.0) or 0.0)

        selected_agent_id = None
        selected_workflow_id = None
        if agent_score >= workflow_score and top_agent:
            selected_agent_id = top_agent.get("asset_id")
        elif top_wf:
            selected_workflow_id = top_wf.get("asset_id")

        logger.info("reuse_policy: auto reuse top_score=%.3f", top_score)
        return {
            "mode": "reuse",
            "selected_agent_id": selected_agent_id,
            "selected_workflow_id": selected_workflow_id,
            "reasons": ["high_confidence_candidate_match"],
            "generate_agent": False,
            "generate_workflow": False,
        }

    if top_score >= MEDIUM_CONFIDENCE_THRESHOLD:
        logger.info("reuse_policy: HITL reuse choice top_score=%.3f", top_score)
        return {
            "mode": "hitl_reuse_choice",
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "reasons": ["medium_confidence_candidates"],
            "generate_agent": False,
            "generate_workflow": False,
        }

    # Prefer reuse exploration over immediate generation whenever there is a
    # non-trivial candidate signal.
    if has_any_candidate and top_score >= LOW_REUSE_THRESHOLD:
        logger.info("reuse_policy: low-confidence HITL reuse choice top_score=%.3f", top_score)
        return {
            "mode": "hitl_reuse_choice",
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "reasons": ["low_confidence_but_candidate_exists"],
            "generate_agent": False,
            "generate_workflow": False,
        }

    if auto_generate_assets:
        logger.info("reuse_policy: generate_new top_score=%.3f", top_score)
        return {
            "mode": "generate_new",
            "selected_agent_id": None,
            "selected_workflow_id": None,
            "reasons": ["no_suitable_existing_assets"],
            "generate_agent": True,
            "generate_workflow": True,
        }

    logger.info("reuse_policy: fallback HITL reuse choice top_score=%.3f", top_score)
    return {
        "mode": "hitl_reuse_choice",
        "selected_agent_id": None,
        "selected_workflow_id": None,
        "reasons": ["generation_disabled_and_no_high_confidence_match"],
        "generate_agent": False,
        "generate_workflow": False,
    }
