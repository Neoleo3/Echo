"""
Agentic Application — Generated File Handler

Manages registration and tracking of generated files (PPT, PDF, etc.)
produced by agents during execution.

When agent tools generate files, they emit markers like:
  [GENERATED_FILE:/path/to/file.pptx:presentation.pptx]

This handler:
  1. Scans output for file markers
  2. Registers each file in AgenticUploadedFile DB model
  3. Returns download URLs for frontend rendering
  4. Provides file retrieval/download endpoints
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Dict, Optional
from uuid import UUID

logger = logging.getLogger(__name__)

# Marker pattern: [GENERATED_FILE:/absolute/path/to/file.ext:filename.ext]
_GENERATED_FILE_MARKER_RE = re.compile(
    r"\[GENERATED_FILE:(?P<payload>[^\]]+)\]"
)


class AgenticFileHandler:
    """
    Manages lifecycle of generated files from agent execution.
    """
    
    def __init__(self):
        """Initialize the file handler."""
        pass
    
    async def extract_and_register_files(
        self,
        output_text: str,
        data_key: str,
        user_id: str,
        chat_session_id: Optional[str] = None,
        app_id: Optional[str] = None,
    ) -> tuple[str, list[dict]]:
        """
        Scan output for file markers, register files, return sanitized output.
        
        Args:
            output_text: Agent output potentially containing file markers
            data_key: Which data key this output is associated with
            user_id: User UUID who owns these files
            chat_session_id: Optional chat session UUID for context
            app_id: Optional app UUID for context
            
        Returns:
            Tuple of (sanitized_output, file_records) where:
            - sanitized_output: Original text with markers replaced by markdown links
            - file_records: List of registered file dicts with download URLs
        """
        if not isinstance(output_text, str):
            return output_text, []
        
        # If no markers, return as-is
        if "[GENERATED_FILE:" not in output_text:
            return output_text, []
        
        file_records = []
        
        def replace_marker(match: re.Match) -> str:
            payload = match.group("payload")
            file_path, filename = self._parse_file_marker(payload)
            
            if not file_path or not filename:
                logger.warning("Invalid file marker format: %s", payload)
                return match.group(0)  # Return original marker
            
            # TODO: In real implementation, call async DB function to register file
            # For now, return a markdown link with placeholder
            file_record = {
                "original_filename": filename,
                "file_path": file_path,
                "mime_type": self._infer_mime_type(filename),
                "size_bytes": 0,  # TODO: Get from file system
                "user_id": user_id,
                "chat_session_id": chat_session_id,
                "app_id": app_id,
            }
            file_records.append(file_record)
            
            # Build markdown download link
            # URL pattern: /api/applications/agentic/files/{file_id}/download
            # file_id would be generated during DB storage
            download_url = f"/api/applications/agentic/generated-files/download?filename={filename}&path={file_path}"
            markdown_link = f"[📥 Download {filename}]({download_url})"
            
            return markdown_link
        
        # Replace all markers
        sanitized = _GENERATED_FILE_MARKER_RE.sub(replace_marker, output_text)
        
        logger.info(
            "extract_and_register_files: extracted %d files from output (user=%s)",
            len(file_records), user_id
        )
        
        return sanitized, file_records
    
    @staticmethod
    def _parse_file_marker(payload: str) -> tuple[Optional[str], Optional[str]]:
        """
        Parse file marker payload into path and filename.
        
        Payload format: /absolute/path/to/file.ext:filename.ext
        
        Split on last colon to support colons in file paths (e.g., Windows drives).
        
        Args:
            payload: Raw marker payload
            
        Returns:
            Tuple of (file_path, filename) or (None, None) on parse error
        """
        if not payload or ":" not in payload:
            return None, None
        
        # Split on rightmost colon
        parts = payload.rsplit(":", 1)
        if len(parts) != 2:
            return None, None
        
        file_path = parts[0].strip()
        filename = parts[1].strip()
        
        if not file_path or not filename:
            return None, None
        
        return file_path, filename
    
    @staticmethod
    def _infer_mime_type(filename: str) -> str:
        """
        Infer MIME type from filename extension.
        
        Args:
            filename: File name with extension
            
        Returns:
            MIME type string
        """
        if not filename:
            return "application/octet-stream"
        
        lower_name = filename.lower()
        
        mime_map = {
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".ppt": "application/vnd.ms-powerpoint",
            ".pdf": "application/pdf",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".txt": "text/plain",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".csv": "text/csv",
            ".json": "application/json",
        }
        
        for ext, mime_type in mime_map.items():
            if lower_name.endswith(ext):
                return mime_type
        
        return "application/octet-stream"
    
    async def register_file_in_db(
        self,
        file_path: str,
        filename: str,
        user_id: str,
        chat_session_id: Optional[str] = None,
        app_id: Optional[str] = None,
    ) -> Optional[str]:
        """
        Register a generated file in the database.
        
        Args:
            file_path: Full path to the file on disk
            filename: Original filename for download
            user_id: User UUID who owns the file
            chat_session_id: Optional chat session context
            app_id: Optional app context
            
        Returns:
            file_id (UUID string) if successful, None on error
        """
        try:
            # TODO: Implement DB registration using AgenticUploadedFile model
            # This is a placeholder; real implementation uses SQLAlchemy + async DB session
            
            if not os.path.exists(file_path):
                logger.error("File not found for registration: %s", file_path)
                return None
            
            file_size = os.path.getsize(file_path)
            mime_type = self._infer_mime_type(filename)
            
            # TODO: Create AgenticUploadedFile record
            # file_id = UUID(...)
            # await db.add(AgenticUploadedFile(...))
            # await db.flush()
            
            logger.info(
                "register_file_in_db: registered file %s (size=%d, user=%s)",
                filename, file_size, user_id
            )
            
            # Placeholder return
            return str(UUID(int=0))
            
        except Exception as exc:
            logger.exception("register_file_in_db: error registering %s: %s", filename, exc)
            return None
    
    @staticmethod
    def format_file_link(
        file_id: str,
        filename: str,
    ) -> str:
        """
        Format a file link for markdown display.
        
        Args:
            file_id: UUID of registered file
            filename: Display name
            
        Returns:
            Markdown link string
        """
        download_url = f"/api/applications/agentic/files/{file_id}/download"
        return f"[📥 Download {filename}]({download_url})"


# Singleton instance
_handler = None


def get_file_handler() -> AgenticFileHandler:
    """Get or create the singleton file handler instance."""
    global _handler
    if _handler is None:
        _handler = AgenticFileHandler()
    return _handler


__all__ = ["AgenticFileHandler", "get_file_handler"]
