"""
Agentic Application — Intent-Based Orchestration

Analyzes user queries to determine:
  1. Whether to execute (conversational queries skip execution)
  2. Which path to take: agent (focused queries) OR workflow (comprehensive requests)
  3. Confidence level and reasoning for decisions

This layer sits between the user input and component execution,
providing intelligent routing without modifying the canvas structure.

The orchestrator preserves both agent_trigger and workflow_trigger components
on the canvas, but selectively executes only the chosen path.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Conversational Query Detection
# ---------------------------------------------------------------------------

_GREETING_PATTERNS = {
    r"\b(hello|hi|hey|greetings|hey there|howdy)\b",
    r"\b(how are you|how r u|how's it going|what's up|wasup|whats good)\b",
    r"\b(good morning|good afternoon|good evening|g'morning|g'afternoon)\b",
    r"\b(thank you|thanks|thankyou|thx|ty|appreciate it|much appreciated)\b",
    r"\b(goodbye|bye|see you|farewell|catch you later|cya|ttyl)\b",
    r"\b(okay|ok|sure|alright|got it|understood|will do|sounds good)\b",
    r"\b(help|assist|can you help|please help me)\b",  # Generic help requests
    r"^\s*\?\s*$",  # Just a question mark
    r"^\s*\.\s*$",  # Just a period (punctuation-only queries)
}

_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from",
    "has", "have", "if", "in", "into", "is", "it", "its", "of", "on", "or",
    "our", "so", "that", "the", "their", "then", "this", "to", "with", "you", "your",
}

# Keywords indicating comprehensive/workflow-level requests
_WORKFLOW_KEYWORDS = {
    "full", "complete", "comprehensive", "detailed", "thorough", "entire",
    "review", "analysis", "analysis", "report", "summary", "multi", "multiple",
    "step", "process", "workflow", "pipeline", "end-to-end", "overall",
    "combined", "integrated", "holistic", "all of", "everything",
}

# Keywords indicating focused/agent-level requests
_AGENT_KEYWORDS = {
    "what", "when", "why", "how", "which", "specific", "particular",
    "answer", "explain", "tell", "define", "list", "show", "find",
    "check", "verify", "validate", "confirm", "quick", "simple",
}


def _is_conversational_query(query: str) -> bool:
    """
    Detect conversational queries (greetings, small talk, off-topic).
    
    Args:
        query: User's input message
        
    Returns:
        True if query is conversational and should skip execution
    """
    if not isinstance(query, str):
        return False
    
    lowered = query.strip().lower()
    
    # Empty query
    if not lowered or len(lowered) < 2:
        return True
    
    # Check against greeting patterns
    for pattern in _GREETING_PATTERNS:
        if re.search(pattern, lowered, re.IGNORECASE):
            return True
    
    # Very short queries without keywords (likely incomplete)
    words = re.findall(r"\b[a-z0-9]+\b", lowered)
    if len(words) <= 1 and not any(w in _AGENT_KEYWORDS | _WORKFLOW_KEYWORDS for w in words):
        return True
    
    return False


def _extract_keywords(text: str) -> Set[str]:
    """
    Extract significant keywords from text (length >= 3, not stopwords).
    
    Args:
        text: Input text to parse
        
    Returns:
        Set of keywords
    """
    if not isinstance(text, str):
        return set()
    
    tokens = re.findall(r"\b[a-zA-Z0-9]+\b", text.lower())
    return {t for t in tokens if len(t) >= 3 and t not in _STOPWORDS}


def _score_agent_vs_workflow(query: str) -> tuple[str, float]:
    """
    Determine if query prefers agent (focused) or workflow (comprehensive).
    
    Heuristic scoring based on keyword presence:
    - Workflow keywords (full, complete, review, analysis, etc.)
    - Agent keywords (what, why, specific, quick, etc.)
    - Query length (short = agent, long = workflow)
    - Interrogative structure (questions = agent, statements = workflow)
    
    Args:
        query: User's input message
        
    Returns:
        Tuple of (preferred_path, confidence) where path is "agent" or "workflow"
        and confidence is 0.0-1.0
    """
    if not isinstance(query, str):
        return "workflow", 0.5  # Default to workflow for unknown inputs
    
    lowered = query.lower()
    keywords = _extract_keywords(query)
    
    workflow_score = 0.0
    agent_score = 0.0
    
    # Keyword scoring
    workflow_matches = len(keywords.intersection(_WORKFLOW_KEYWORDS))
    agent_matches = len(keywords.intersection(_AGENT_KEYWORDS))
    
    workflow_score += workflow_matches * 2  # Weight workflow keywords higher
    agent_score += agent_matches * 1.5
    
    # Length heuristic: longer queries often indicate more comprehensive requests
    word_count = len(re.findall(r"\b\w+\b", lowered))
    if word_count >= 20:
        workflow_score += 2.0
    elif word_count <= 5:
        agent_score += 1.5
    
    # Interrogative structure: questions often = agent, statements = workflow
    question_marks = lowered.count("?")
    if question_marks >= 1:
        agent_score += 2.0
    
    # Common phrase indicators
    if any(phrase in lowered for phrase in ["create", "generate", "build", "make", "produce"]):
        workflow_score += 1.5
    
    if any(phrase in lowered for phrase in ["what is", "tell me", "explain", "how do"]):
        agent_score += 1.5
    
    # Determine preference
    if workflow_score == agent_score:
        # Tie: default to agent (faster, lower cost)
        return "agent", 0.5
    
    if workflow_score > agent_score:
        confidence = min(1.0, workflow_score / (workflow_score + agent_score + 1.0))
        return "workflow", confidence
    else:
        confidence = min(1.0, agent_score / (workflow_score + agent_score + 1.0))
        return "agent", confidence


def _build_reasoning(
    query: str,
    should_execute: bool,
    selected_path: Optional[str] = None,
    is_conversational: bool = False,
) -> str:
    """
    Generate human-readable reasoning for orchestration decision.
    
    Args:
        query: Original user query
        should_execute: Whether execution will proceed
        selected_path: "agent", "workflow", or None
        is_conversational: Whether query was detected as conversational
        
    Returns:
        Reasoning explanation string
    """
    if not should_execute:
        if is_conversational:
            return "Detected conversational query; responding directly without component execution."
        else:
            return "Query did not match any available skills or components."
    
    if selected_path == "agent":
        return "Query is focused and specific; routing to agent for quick single-perspective analysis."
    elif selected_path == "workflow":
        return "Query requests comprehensive analysis or report; routing to workflow for multi-step investigation."
    else:
        return f"Query analyzed; selected path: {selected_path}"


def analyze_query_intent(
    query: str,
    canvas_config: Optional[List[Dict[str, Any]]] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Analyze user query intent and determine execution strategy.
    
    This function performs deterministic intent parsing WITHOUT calling LLM.
    It is stateless and fast, designed for real-time decision-making at the start
    of each execution.
    
    Args:
        query: User's message/query
        canvas_config: Optional canvas configuration (for detecting available components)
        user_id: Optional user ID (for future context-aware analysis)
        
    Returns:
        Dict with keys:
            - should_execute (bool): Whether to proceed with component execution
            - fallback_message (str): Response if should_execute=False (conversational reply)
            - selected_path (str|None): "agent" or "workflow" if should_execute=True
            - reasoning (str): Explanation of the decision
            - confidence (float): 0.0-1.0 confidence in this decision
            - is_conversational (bool): Was this detected as a conversational query?
    """
    
    if not isinstance(query, str):
        query = str(query) if query else ""
    
    query = query.strip()
    
    # Step 1: Check if conversational
    is_conversational = _is_conversational_query(query)
    
    if is_conversational:
        return {
            "should_execute": False,
            "fallback_message": _generate_conversational_reply(query),
            "selected_path": None,
            "reasoning": _build_reasoning(query, False, is_conversational=True),
            "confidence": 1.0,
            "is_conversational": True,
        }
    
    # Step 2: Check if canvas has components to execute
    has_components = _canvas_has_executable_components(canvas_config)
    if not has_components:
        return {
            "should_execute": False,
            "fallback_message": "No executable components configured in this application.",
            "selected_path": None,
            "reasoning": "Canvas has no agent_trigger or workflow_trigger components.",
            "confidence": 0.9,
            "is_conversational": False,
        }
    
    # Step 3: Score agent vs workflow preference
    selected_path, confidence = _score_agent_vs_workflow(query)
    
    # Step 4: Check if selected path exists in canvas
    if selected_path == "agent" and not _canvas_has_component_type(canvas_config, "agent_trigger"):
        # No agent available, try workflow
        if _canvas_has_component_type(canvas_config, "workflow_trigger"):
            selected_path = "workflow"
            confidence = max(0.5, confidence - 0.2)  # Lower confidence due to mismatch
        else:
            return {
                "should_execute": False,
                "fallback_message": "No agent or workflow components available.",
                "selected_path": None,
                "reasoning": "Canvas missing both agent_trigger and workflow_trigger components.",
                "confidence": 0.9,
                "is_conversational": False,
            }
    
    elif selected_path == "workflow" and not _canvas_has_component_type(canvas_config, "workflow_trigger"):
        # No workflow available, try agent
        if _canvas_has_component_type(canvas_config, "agent_trigger"):
            selected_path = "agent"
            confidence = max(0.5, confidence - 0.2)
        else:
            return {
                "should_execute": False,
                "fallback_message": "No agent or workflow components available.",
                "selected_path": None,
                "reasoning": "Canvas missing both agent_trigger and workflow_trigger components.",
                "confidence": 0.9,
                "is_conversational": False,
            }
    
    return {
        "should_execute": True,
        "fallback_message": None,
        "selected_path": selected_path,
        "reasoning": _build_reasoning(query, True, selected_path),
        "confidence": confidence,
        "is_conversational": False,
    }


def _canvas_has_executable_components(canvas_config: Optional[List[Dict[str, Any]]]) -> bool:
    """Check if canvas has any agent_trigger or workflow_trigger components."""
    if not isinstance(canvas_config, list):
        return False
    
    for comp in canvas_config:
        if not isinstance(comp, dict):
            continue
        if comp.get("type") in ("agent_trigger", "workflow_trigger"):
            return True
    
    return False


def _canvas_has_component_type(
    canvas_config: Optional[List[Dict[str, Any]]],
    component_type: str,
) -> bool:
    """Check if canvas has a specific component type."""
    if not isinstance(canvas_config, list):
        return False
    
    for comp in canvas_config:
        if not isinstance(comp, dict):
            continue
        if comp.get("type") == component_type:
            return True
    
    return False


def _generate_conversational_reply(query: str) -> str:
    """
    Generate a friendly response for conversational queries.
    
    Args:
        query: User's conversational message
        
    Returns:
        Natural language response
    """
    lowered = query.strip().lower()
    
    # Greeting responses
    if re.search(r"\b(hello|hi|hey|greetings)\b", lowered):
        return "Hello! 👋 I'm here to help. What would you like me to do?"
    
    if re.search(r"\bhow are you\b", lowered):
        return "I'm doing well, thanks for asking! How can I assist you?"
    
    if re.search(r"\b(what's up|whats up|wasup)\b", lowered):
        return "Not much, ready to help! What do you need?"
    
    if re.search(r"\b(thanks|thank you|thx|ty)\b", lowered):
        return "You're welcome! 😊 Is there anything else I can help with?"
    
    if re.search(r"\b(goodbye|bye|see you)\b", lowered):
        return "Goodbye! Feel free to come back if you need anything. 👋"
    
    if re.search(r"\b(help|assist)\b", lowered) and len(lowered.split()) <= 3:
        return (
            "I can help! I run agents and workflows to analyze data, generate content, "
            "and process information. What would you like me to help you with?"
        )
    
    # Catch-all for other conversational queries
    return (
        "That's a good question! I'm designed to help with specific tasks. "
        "Please describe what you'd like me to do, and I'll assist you."
    )


# Export the main public function
__all__ = ["analyze_query_intent"]
