"""
Agentic Application — Output Aggregation & Formatting

Transforms intermediate execution results into a single final output.

This formatter:
  1. Extracts the last successful component's result
  2. Suppresses intermediate outputs from earlier components
  3. Preserves execution metadata for debugging
  4. Prepares data for A2UI final answer emission

The formatter does NOT execute components; it post-processes the results
after all components have run.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AgenticOutputFormatter:
    """
    Formats execution results from the agentic pipeline into a final output.
    
    Responsibility: Extract final output and suppress intermediate results.
    """
    
    def __init__(self):
        """Initialize the formatter."""
        pass
    
    def aggregate_outputs(
        self,
        execution_steps: List[Dict[str, Any]],
        canvas_config: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Aggregate step results into a single final output.
        
        Strategy:
          1. Find the last successfully executed component
          2. Use its output as the final result
          3. Return metadata about execution for logging/debugging
          
        Args:
            execution_steps: List of step execution records from pipeline
                Each record: {
                    "component_id": str,
                    "component_type": str,
                    "data_key": str,
                    "on_success_key": Optional[str],
                    "success": bool,
                    "output": Any,
                    "error": Optional[str],
                }
            canvas_config: Optional canvas configuration for metadata
            
        Returns:
            Dict with keys:
                - final_output (str|dict): The result to show user
                - final_data_key (str): Which data key holds the final output
                - final_component_id (str): Which component produced this
                - final_component_type (str): Type of the final component
                - execution_summary (dict):
                    - steps_run (int): Total components executed
                    - steps_succeeded (int): How many succeeded
                    - steps_failed (int): How many failed
                    - failed_components (list): IDs of failed components
                - is_success (bool): Whether execution succeeded overall
        """
        if not isinstance(execution_steps, list):
            return self._build_error_response("No execution steps provided")
        
        # Find last successful step
        last_success = None
        last_success_idx = -1
        
        for idx in range(len(execution_steps) - 1, -1, -1):
            step = execution_steps[idx]
            if not isinstance(step, dict):
                continue
            if step.get("success") is True:
                last_success = step
                last_success_idx = idx
                break
        
        if last_success is None:
            # All steps failed
            failed_ids = [
                s.get("component_id", f"step_{i}")
                for i, s in enumerate(execution_steps)
                if isinstance(s, dict) and s.get("success") is False
            ]
            return self._build_error_response(
                f"All execution steps failed: {failed_ids}",
                failed_components=failed_ids,
                total_steps=len(execution_steps),
            )
        
        # Extract final output information
        final_data_key = last_success.get("on_success_key") or last_success.get("data_key", "result")
        final_component_id = last_success.get("component_id", "unknown")
        final_component_type = last_success.get("component_type", "unknown")
        final_output = last_success.get("output", "")
        
        # Build execution summary
        failed_components = [
            s.get("component_id", f"step_{i}")
            for i, s in enumerate(execution_steps)
            if isinstance(s, dict) and s.get("success") is False
        ]
        
        return {
            "final_output": final_output,
            "final_data_key": final_data_key,
            "final_component_id": final_component_id,
            "final_component_type": final_component_type,
            "execution_summary": {
                "steps_run": len(execution_steps),
                "steps_succeeded": sum(1 for s in execution_steps if isinstance(s, dict) and s.get("success")),
                "steps_failed": len(failed_components),
                "failed_components": failed_components,
                "last_success_step": last_success_idx + 1,  # 1-indexed
            },
            "is_success": True,
        }
    
    def _build_error_response(
        self,
        error_message: str,
        failed_components: Optional[List[str]] = None,
        total_steps: int = 0,
    ) -> Dict[str, Any]:
        """Build a standard error response structure."""
        return {
            "final_output": error_message,
            "final_data_key": "error",
            "final_component_id": None,
            "final_component_type": None,
            "execution_summary": {
                "steps_run": total_steps,
                "steps_succeeded": 0,
                "steps_failed": total_steps,
                "failed_components": failed_components or [],
                "last_success_step": -1,
            },
            "is_success": False,
        }
    
    def filter_outputs_for_display(
        self,
        all_outputs: Dict[str, Any],
        final_data_key: str,
    ) -> Dict[str, Any]:
        """
        Filter outputs dictionary to include only the final result.
        
        This is used when building A2UI data model updates.
        Instead of emitting all intermediate keys, we only return
        the final output for display components to render.
        
        Args:
            all_outputs: Complete outputs dict from execution
            final_data_key: Which key is the final output
            
        Returns:
            Filtered outputs dict with only the final key
        """
        if not isinstance(all_outputs, dict):
            return {}
        
        if not final_data_key:
            return {}
        
        # Return only the final output
        final_value = all_outputs.get(final_data_key)
        
        return {
            final_data_key: final_value
        }


# Singleton instance
_formatter = None


def get_formatter() -> AgenticOutputFormatter:
    """Get or create the singleton formatter instance."""
    global _formatter
    if _formatter is None:
        _formatter = AgenticOutputFormatter()
    return _formatter


__all__ = ["AgenticOutputFormatter", "get_formatter"]
