"""
EchoAI Agentic Application — Component Registry

Defines every component type available in the canvas IDE.
Each entry describes:
    - type_slug   : The string identifier used in canvas_config JSON
    - category    : LAYOUT | INPUT | DISPLAY | INTERACTION
    - label       : Human-readable display name
    - props       : Expected keys inside the component's props dict
    - needs_exec  : True if this component type requires backend processing
"""

from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Prop descriptor
# ---------------------------------------------------------------------------

class PropDescriptor:
    def __init__(self, name: str, type_hint: str, required: bool = False, description: str = ""):
        self.name = name
        self.type_hint = type_hint
        self.required = required
        self.description = description

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.type_hint,
            "required": self.required,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Component descriptor
# ---------------------------------------------------------------------------

class ComponentDescriptor:
    def __init__(
        self,
        type_slug: str,
        label: str,
        category: str,
        needs_exec: bool,
        props: List[PropDescriptor],
        description: str = "",
    ):
        self.type_slug = type_slug
        self.label = label
        self.category = category
        self.needs_exec = needs_exec
        self.props = props
        self.description = description

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type_slug": self.type_slug,
            "label": self.label,
            "category": self.category,
            "needs_exec": self.needs_exec,
            "description": self.description,
            "props": [p.to_dict() for p in self.props],
        }


# ---------------------------------------------------------------------------
# The registry — all known component types
# ---------------------------------------------------------------------------

COMPONENT_REGISTRY: List[ComponentDescriptor] = [

    # LAYOUT
    ComponentDescriptor(
        type_slug="heading", label="Heading", category="LAYOUT", needs_exec=False,
        description="A heading/title text block.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("text", "str", required=False),
            PropDescriptor("level", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="label", label="Label / Text", category="LAYOUT", needs_exec=False,
        description="A static label or paragraph of text.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("content", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="divider", label="Divider", category="LAYOUT", needs_exec=False,
        description="A horizontal rule / visual separator.",
        props=[PropDescriptor("data_key", "str", required=True)],
    ),
    ComponentDescriptor(
        type_slug="spacer", label="Spacer", category="LAYOUT", needs_exec=False,
        description="An empty vertical spacer block.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("height", "int", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="card_container", label="Card Container", category="LAYOUT", needs_exec=False,
        description="A card wrapper that groups child components visually.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
        ],
    ),

    # INPUT
    ComponentDescriptor(
        type_slug="short_text", label="Short Text", category="INPUT", needs_exec=False,
        description="A single-line text input.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("placeholder", "str", required=False),
            PropDescriptor("default_value", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="text_area", label="Text Area", category="INPUT", needs_exec=False,
        description="A multi-line text input.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("placeholder", "str", required=False),
            PropDescriptor("rows", "int", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="number", label="Number", category="INPUT", needs_exec=False,
        description="A numeric input field.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("min", "float", required=False),
            PropDescriptor("max", "float", required=False),
            PropDescriptor("default_value", "float", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="select", label="Select", category="INPUT", needs_exec=False,
        description="A single-choice dropdown.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("options", "list[str]", required=False),
            PropDescriptor("default_value", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="multi_select", label="Multi-Select", category="INPUT", needs_exec=False,
        description="A multi-choice selection.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("options", "list[str]", required=False),
            PropDescriptor("default_value", "list[str]", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="slider", label="Slider", category="INPUT", needs_exec=False,
        description="A range slider input.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("min", "float", required=False),
            PropDescriptor("max", "float", required=False),
            PropDescriptor("step", "float", required=False),
            PropDescriptor("default_value", "float", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="toggle", label="Toggle", category="INPUT", needs_exec=False,
        description="A boolean toggle switch.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("default_value", "bool", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="date_picker", label="Date Picker", category="INPUT", needs_exec=False,
        description="A date input field.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("default_value", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="file_upload", label="File Upload", category="INPUT", needs_exec=False,
        description="A file upload input.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("accepted_types", "list[str]", required=False),
            PropDescriptor("max_size_mb", "int", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="star_rating", label="Star Rating", category="INPUT", needs_exec=False,
        description="A star rating input (1–5).",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("max_stars", "int", required=False),
        ],
    ),

    # DISPLAY
    ComponentDescriptor(
        type_slug="bar_chart", label="Bar Chart", category="DISPLAY", needs_exec=False,
        description="Renders a bar chart.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
            PropDescriptor("x_label", "str", required=False),
            PropDescriptor("y_label", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="line_chart", label="Line Chart", category="DISPLAY", needs_exec=False,
        description="Renders a line chart.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
            PropDescriptor("x_label", "str", required=False),
            PropDescriptor("y_label", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="pie_chart", label="Pie Chart", category="DISPLAY", needs_exec=False,
        description="Renders a pie chart.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="data_table", label="Data Table", category="DISPLAY", needs_exec=False,
        description="Renders tabular data.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
            PropDescriptor("columns", "list[str]", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="markdown", label="Markdown", category="DISPLAY", needs_exec=False,
        description="Renders markdown text.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("default_content", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="timeline", label="Timeline", category="DISPLAY", needs_exec=False,
        description="Renders a timeline of events.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("title", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="metric_card", label="Metric Card", category="DISPLAY", needs_exec=False,
        description="Renders a KPI/metric card.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("unit", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="image", label="Image", category="DISPLAY", needs_exec=False,
        description="Renders an image.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("src", "str", required=False),
            PropDescriptor("alt", "str", required=False),
        ],
    ),

    # INTERACTION
    ComponentDescriptor(
        type_slug="submit_button", label="Submit Button", category="INTERACTION", needs_exec=False,
        description="A button that collects all input values and submits the form.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="chat_interface", label="Chat Interface", category="INTERACTION", needs_exec=True,
        description="An embedded conversational chat widget.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("label", "str", required=False),
            PropDescriptor("chat_title", "str", required=False),
            PropDescriptor("welcome_message", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="api_trigger", label="API Trigger", category="INTERACTION", needs_exec=True,
        description="Makes an external HTTP API call.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("method", "str", required=True),
            PropDescriptor("url", "str", required=True),
            PropDescriptor("auth_type", "str", required=False),
            PropDescriptor("auth_value", "str", required=False),
            PropDescriptor("headers", "dict", required=False),
            PropDescriptor("body", "str", required=False),
            PropDescriptor("on_success_key", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="workflow_trigger", label="Workflow Trigger", category="INTERACTION", needs_exec=True,
        description="Triggers an existing EchoAI workflow by ID.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("workflow_id", "str", required=False),
            PropDescriptor("environment", "str", required=False),
            PropDescriptor("input_mapping", "dict", required=False),
            PropDescriptor("on_success_key", "str", required=False),
        ],
    ),
    ComponentDescriptor(
        type_slug="agent_trigger", label="Agent Trigger", category="INTERACTION", needs_exec=True,
        description="Runs an EchoAI agent.",
        props=[
            PropDescriptor("data_key", "str", required=True),
            PropDescriptor("agent_id", "str", required=False),
            PropDescriptor("model", "str", required=False),
            PropDescriptor("system_prompt", "str", required=False),
            PropDescriptor("max_tokens", "int", required=False),
            PropDescriptor("tools", "list[str]", required=False),
            PropDescriptor("on_success_key", "str", required=False),
        ],
    ),
]


# ---------------------------------------------------------------------------
# Lookup helpers
# ---------------------------------------------------------------------------

_REGISTRY_MAP: Dict[str, ComponentDescriptor] = {
    c.type_slug: c for c in COMPONENT_REGISTRY
}

_FRONTEND_ALIASES: Dict[str, str] = {
    "card":             "card_container",
    "textarea":         "text_area",
    "multiselect":      "multi_select",
    "rating":           "star_rating",
    "markdown_box":     "markdown",
    "status_timeline":  "timeline",
    "image_display":    "image",
}

for _alias, _canonical in _FRONTEND_ALIASES.items():
    if _canonical in _REGISTRY_MAP:
        _REGISTRY_MAP[_alias] = _REGISTRY_MAP[_canonical]


def get_component(type_slug: str) -> ComponentDescriptor | None:
    """Return the ComponentDescriptor for a given type_slug, or None if unknown."""
    return _REGISTRY_MAP.get(type_slug)


def is_known_type(type_slug: str) -> bool:
    """Return True if the type_slug is a recognised component type."""
    return type_slug in _REGISTRY_MAP


def get_all_components() -> List[Dict[str, Any]]:
    """Return the full registry as a list of dicts (for API serialization)."""
    return [c.to_dict() for c in COMPONENT_REGISTRY]


def get_components_by_category(category: str) -> List[Dict[str, Any]]:
    """Return all components belonging to a given category."""
    return [
        c.to_dict()
        for c in COMPONENT_REGISTRY
        if c.category == category
    ]
