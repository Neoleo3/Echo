"""
EchoAI Agentic Application — Runtime Orchestration Pipeline

The runtime pipeline that executes an agentic application end-to-end,
streaming A2UI messages to the frontend for each step.

Execution modes:
    run()            — synchronous full execution, returns RunResponse
    run_streaming()  — async generator yielding SSE-ready A2UI JSONL strings

Pipeline steps:
    1. Load app from DB
    2. Analyze query intent (agent vs workflow vs conversational)
    3. Filter canvas to selected path
    4. Sort canvas by Y position
    5. Seed data_state from user inputs
    6. For each runnable component in Y-order:
       a. Emit A2UI step_status(running)
       b. Dispatch to handler (agent/api/workflow/chat)
       c. On success: data_state[on_success_key] = output
          → emit A2UI dataModelUpdate for that key
       d. On failure: record error → emit A2UI step_status(failed)
    7. Post-process charts (render HTML)
    8. Format final output (show only last component)
    9. Emit final A2UI answer with aggregated data
    10. Return aggregated response
"""

import asyncio
import json
import logging
import time
from typing import Any, AsyncGenerator, Dict, List, Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.database import get_db_session
from echolib.models.agentic_application import AgenticApplication
from echolib.security import resolve_user_id

from .agentic_executor import (
    RUNNABLE_TYPES,
    CHART_TYPES,
    ComponentResult,
    dispatch,
    render_chart_html,
)
from .agentic_a2ui_emitter import (
    build_surface_messages,
    emit_data_update,
    emit_step_status,
    emit_final_answer,
    emit_delete_surface,
)
from .agentic_intent_orchestrator import analyze_query_intent
from .agentic_output_formatter import get_formatter
from .agentic_file_handler import get_file_handler

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# HELPER: Component Filtering by Orchestration Path
# ---------------------------------------------------------------------------

def _filter_components_for_path(
    canvas: List[Dict[str, Any]],
    selected_path: Optional[str],
) -> List[Dict[str, Any]]:
    """
    Filter canvas components based on orchestration path selection.
    
    If path is "agent": skip all workflow_trigger components
    If path is "workflow": skip all agent_trigger components
    If path is None: return canvas as-is
    
    Maintains original Y-order.
    
    Args:
        canvas: Original canvas config
        selected_path: "agent", "workflow", or None
        
    Returns:
        Filtered canvas maintaining Y-order
    """
    if not selected_path or selected_path not in ("agent", "workflow"):
        return canvas
    
    if selected_path == "agent":
        # Skip workflow triggers, keep agent triggers
        return [
            c for c in canvas
            if not isinstance(c, dict) or c.get("type") != "workflow_trigger"
        ]
    elif selected_path == "workflow":
        # Skip agent triggers, keep workflow triggers
        return [
            c for c in canvas
            if not isinstance(c, dict) or c.get("type") != "agent_trigger"
        ]
    
    return canvas


class AgenticOrchestrationPipeline:
    """
    Runtime orchestration pipeline for agentic applications.

    Orchestrates the execution of all runnable canvas components in Y-order,
    streaming A2UI messages for each step.
    """

    async def _load_app(
        self,
        db: AsyncSession,
        app_id: str,
        user_id: str,
    ) -> Optional[AgenticApplication]:
        """Load an agentic application from DB, verifying ownership."""
        try:
            app_uuid = UUID(app_id)
            user_uuid = UUID(user_id)
        except (ValueError, AttributeError):
            return None

        stmt = select(AgenticApplication).where(
            AgenticApplication.agentic_app_id == app_uuid,
            AgenticApplication.user_id == user_uuid,
            AgenticApplication.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def run(
        self,
        app_id: str,
        user_id: str,
        inputs: Dict[str, Any],
        triggered_components: Optional[List[str]] = None,
        chat_message: Optional[str] = None,
        chat_history: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Execute the agentic app synchronously (non-streaming).

        Args:
            app_id: Agentic application UUID.
            user_id: User UUID.
            inputs: User-provided input values keyed by data_key.
            triggered_components: Optional list of component IDs to execute
                (from submit button triggers). If None, all runnable components execute.
            chat_message: Optional chat message for chat_interface components.
            chat_history: Optional prior chat turns.

        Returns:
            Dict with status, outputs, steps, errors, a2ui_messages.
        """
        async with get_db_session() as db:
            app = await self._load_app(db, app_id, user_id)

        if app is None:
            return {
                "status": "failed",
                "outputs": {},
                "steps": [],
                "errors": ["Agentic app not found or access denied"],
                "a2ui_messages": [],
            }

        canvas: List[dict] = app.canvas_config or []
        if not canvas:
            return {
                "status": "failed",
                "outputs": {},
                "steps": [],
                "errors": ["App has no canvas components"],
                "a2ui_messages": [],
            }

        return await self._execute_pipeline(
            app_id=app_id,
            user_id=user_id,
            canvas=canvas,
            inputs=inputs,
            triggered_components=triggered_components,
            chat_message=chat_message,
            chat_history=chat_history,
        )

    async def run_streaming(
        self,
        app_id: str,
        user_id: str,
        inputs: Dict[str, Any],
        triggered_components: Optional[List[str]] = None,
        chat_message: Optional[str] = None,
        chat_history: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Execute the agentic app with A2UI SSE streaming.

        Yields JSONL strings, each representing an A2UI message.
        The caller wraps these as SSE `data:` events.

        Yields:
            str: A2UI JSONL messages in order:
                1. surfaceUpdate (full component tree)
                2. dataModelUpdate (initial data)
                3. beginRendering
                4. For each step: step_status(running) → dataModelUpdate → step_status(completed/failed)
                5. Final dataModelUpdate with all outputs
        """
        async with get_db_session() as db:
            app = await self._load_app(db, app_id, user_id)

        if app is None:
            yield emit_step_status(
                app_id, "pipeline", "error", "failed",
                error="Agentic app not found or access denied",
            )
            return

        canvas: List[dict] = app.canvas_config or []
        if not canvas:
            yield emit_step_status(
                app_id, "pipeline", "error", "failed",
                error="App has no canvas components",
            )
            return

        # NEW: Step 1 — Analyze query intent (conversational vs agent vs workflow)
        orchestration_result = analyze_query_intent(
            query=chat_message or "",
            canvas_config=canvas,
            user_id=user_id,
        )
        
        if not orchestration_result.get("should_execute"):
            # Conversational query: return direct reply, skip component execution
            fallback_msg = orchestration_result.get("fallback_message", "Hello!")
            yield emit_step_status(
                app_id, "pipeline", "conversational", "completed",
                output=fallback_msg,
            )
            logger.info(
                "pipeline streaming: conversational query (app=%s, user=%s)",
                app_id, user_id,
            )
            return
        
        # Step 2 — Filter canvas based on selected path
        selected_path = orchestration_result.get("selected_path")
        filtered_canvas = _filter_components_for_path(canvas, selected_path)
        
        logger.info(
            "pipeline streaming: orchestration analysis: path=%s confidence=%.2f (app=%s)",
            selected_path,
            orchestration_result.get("confidence", 0.0),
            app_id,
        )

        # 1-3: Emit initial A2UI surface
        initial_data = self._seed_data_state(canvas, inputs)
        surface_messages = build_surface_messages(app_id, canvas, initial_data)
        for msg in surface_messages:
            yield msg

        # Sort by Y position
        sorted_canvas = sorted(filtered_canvas, key=lambda c: c.get("y", 0))

        data_state = dict(initial_data)
        steps: List[Dict[str, Any]] = []
        errors: List[str] = []
        ran = 0
        succeeded = 0

        for component in sorted_canvas:
            comp_id = component.get("id", "unknown")
            comp_type = component.get("type", "")
            props = component.get("props") or {}
            data_key = props.get("data_key", comp_id)
            on_success_key = props.get("on_success_key")

            # Skip non-runnable
            if comp_type not in RUNNABLE_TYPES:
                continue

            # If triggered_components specified, only run those
            # Match on both comp_id and data_key (actionId uses data_key)
            if triggered_components and comp_id not in triggered_components and data_key not in triggered_components:
                continue

            ran += 1

            # Emit running status
            yield emit_step_status(app_id, comp_id, comp_type, "running")

            # Execute
            result = await dispatch(
                component_type=comp_type,
                props=props,
                data_state=data_state,
                user_id=user_id,
                chat_message=chat_message,
                chat_history=chat_history,
            )

            step_info = {
                "component_id": comp_id,
                "component_type": comp_type,
                "data_key": data_key,
                "on_success_key": on_success_key,
                "success": result.success,
                "error": result.error,
            }
            steps.append(step_info)

            if result.success:
                succeeded += 1
                # Store output in data_state
                if on_success_key:
                    data_state[on_success_key] = result.output
                data_state[data_key] = result.output

                # Emit A2UI data update for bound display components
                updates = {data_key: result.output}
                if on_success_key:
                    updates[on_success_key] = result.output
                yield emit_data_update(app_id, updates)

                # Emit completed
                yield emit_step_status(app_id, comp_id, comp_type, "completed")
            else:
                err_msg = result.error or f"Component '{comp_id}' failed"
                errors.append(err_msg)
                yield emit_step_status(
                    app_id, comp_id, comp_type, "failed", error=err_msg,
                )

        # Post-process charts
        for component in sorted_canvas:
            comp_type = component.get("type", "")
            if comp_type not in CHART_TYPES:
                continue
            props = component.get("props") or {}
            data_key = props.get("data_key", component.get("id"))
            raw_value = data_state.get(data_key)
            if raw_value is None:
                continue
            try:
                html = await render_chart_html(comp_type, raw_value)
                data_state[data_key] = html
                yield emit_data_update(app_id, {data_key: html})
            except Exception as exc:
                logger.warning(
                    "pipeline: chart render failed data_key=%s: %s",
                    data_key, exc,
                )

        # Determine status
        if ran == 0:
            status = "success"
        elif succeeded == ran:
            status = "success"
        elif succeeded == 0:
            status = "failed"
        else:
            status = "partial"

        # NEW: Step 8 — Format output (extract only final result)
        formatter = get_formatter()
        formatted_result = formatter.aggregate_outputs(steps, canvas)
        final_output = formatted_result.get("final_output", "")
        final_data_key = formatted_result.get("final_data_key", "result")
        
        # NEW: Step 9 — Register generated files and replace markers with download links
        file_handler = get_file_handler()
        final_output, file_records = await file_handler.extract_and_register_files(
            str(final_output) if final_output else "",
            final_data_key,
            user_id,
            chat_session_id=None,  # TODO: pass from context
            app_id=str(app_id),
        )
        
        # Update data_state with sanitized output (file markers replaced with links)
        data_state[final_data_key] = final_output
        yield emit_data_update(app_id, {final_data_key: final_output})

        # Emit final answer (with aggregated output only)
        final = emit_final_answer(app_id, {final_data_key: final_output}, steps, status, errors)
        for line in final.split("\n"):
            if line.strip():
                yield line

        logger.info(
            "pipeline streaming: app=%s status=%s ran=%d succeeded=%d files=%d",
            app_id, status, ran, succeeded, len(file_records),
        )

    async def _execute_pipeline(
        self,
        app_id: str,
        user_id: str,
        canvas: List[dict],
        inputs: Dict[str, Any],
        triggered_components: Optional[List[str]] = None,
        chat_message: Optional[str] = None,
        chat_history: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Internal synchronous pipeline execution (used by run())."""
        
        # NEW: Step 1 — Analyze query intent
        orchestration_result = analyze_query_intent(
            query=chat_message or "",
            canvas_config=canvas,
            user_id=user_id,
        )
        
        if not orchestration_result.get("should_execute"):
            # Conversational query: return direct reply
            fallback_msg = orchestration_result.get("fallback_message", "Hello!")
            return {
                "status": "success",
                "outputs": {"response": fallback_msg},
                "steps": [],
                "errors": [],
                "a2ui_messages": [
                    emit_step_status(app_id, "pipeline", "conversational", "completed",
                                     output=fallback_msg)
                ],
            }
        
        # Step 2 — Filter canvas based on selected path
        selected_path = orchestration_result.get("selected_path")
        filtered_canvas = _filter_components_for_path(canvas, selected_path)
        
        sorted_canvas = sorted(filtered_canvas, key=lambda c: c.get("y", 0))

        data_state = self._seed_data_state(canvas, inputs)
        a2ui_messages: List[str] = []
        steps: List[Dict[str, Any]] = []
        errors: List[str] = []
        ran = 0
        succeeded = 0

        # Emit initial surface
        a2ui_messages.extend(build_surface_messages(app_id, canvas, data_state))

        for component in sorted_canvas:
            comp_id = component.get("id", "unknown")
            comp_type = component.get("type", "")
            props = component.get("props") or {}
            data_key = props.get("data_key", comp_id)
            on_success_key = props.get("on_success_key")

            if comp_type not in RUNNABLE_TYPES:
                continue

            if triggered_components and comp_id not in triggered_components and data_key not in triggered_components:
                continue

            ran += 1

            a2ui_messages.append(
                emit_step_status(app_id, comp_id, comp_type, "running")
            )

            result = await dispatch(
                component_type=comp_type,
                props=props,
                data_state=data_state,
                user_id=user_id,
                chat_message=chat_message,
                chat_history=chat_history,
            )

            step_info = {
                "component_id": comp_id,
                "component_type": comp_type,
                "data_key": data_key,
                "on_success_key": on_success_key,
                "success": result.success,
                "error": result.error,
            }
            steps.append(step_info)

            if result.success:
                succeeded += 1
                if on_success_key:
                    data_state[on_success_key] = result.output
                data_state[data_key] = result.output

                updates = {data_key: result.output}
                if on_success_key:
                    updates[on_success_key] = result.output
                a2ui_messages.append(emit_data_update(app_id, updates))
                a2ui_messages.append(
                    emit_step_status(app_id, comp_id, comp_type, "completed")
                )
            else:
                err_msg = result.error or f"Component '{comp_id}' failed"
                errors.append(err_msg)
                a2ui_messages.append(
                    emit_step_status(app_id, comp_id, comp_type, "failed", error=err_msg)
                )

        # Post-process charts
        for component in sorted_canvas:
            comp_type = component.get("type", "")
            if comp_type not in CHART_TYPES:
                continue
            props = component.get("props") or {}
            data_key = props.get("data_key", component.get("id"))
            raw_value = data_state.get(data_key)
            if raw_value is None:
                continue
            try:
                html = await render_chart_html(comp_type, raw_value)
                data_state[data_key] = html
                a2ui_messages.append(emit_data_update(app_id, {data_key: html}))
            except Exception as exc:
                logger.warning("pipeline: chart render failed: %s", exc)

        if ran == 0:
            status = "success"
        elif succeeded == ran:
            status = "success"
        elif succeeded == 0:
            status = "failed"
        else:
            status = "partial"

        # NEW: Step 8 — Format output (extract only final result)
        formatter = get_formatter()
        formatted_result = formatter.aggregate_outputs(steps, canvas)
        final_output = formatted_result.get("final_output", "")
        final_data_key = formatted_result.get("final_data_key", "result")
        
        # NEW: Step 9 — Register generated files and replace markers with download links
        file_handler = get_file_handler()
        final_output, file_records = await file_handler.extract_and_register_files(
            str(final_output) if final_output else "",
            final_data_key,
            user_id,
            chat_session_id=None,  # TODO: pass from context
            app_id=str(app_id),
        )
        
        # Update data_state with sanitized output
        sanitized_outputs = {final_data_key: final_output}

        # Emit final answer
        final = emit_final_answer(app_id, sanitized_outputs, steps, status, errors)
        for line in final.split("\n"):
            if line.strip():
                a2ui_messages.append(line)

        return {
            "status": status,
            "outputs": sanitized_outputs,
            "steps": steps,
            "errors": errors,
            "a2ui_messages": a2ui_messages,
        }

    @staticmethod
    def _seed_data_state(
        canvas: List[dict],
        inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Build the initial data_state from canvas defaults + user inputs.

        - Normalize keys: strip leading "/" (A2UI dataPath format).
        - Seed input components with default_value from props.
        - Overlay user-provided inputs (user wins).
        """
        data_state: Dict[str, Any] = {}

        # Seed defaults from canvas
        for comp in canvas:
            props = comp.get("props") or {}
            data_key = props.get("data_key", comp.get("id", ""))
            default = props.get("default_value", props.get("defaultValue"))
            if default is not None:
                data_state[data_key] = default

            # Initialize on_success_key to None
            osk = props.get("on_success_key")
            if osk and osk not in data_state:
                data_state[osk] = None

        # Overlay user inputs (strip leading / from A2UI paths)
        for k, v in inputs.items():
            clean_key = k.lstrip("/") if isinstance(k, str) else k
            data_state[clean_key] = v

        return data_state
