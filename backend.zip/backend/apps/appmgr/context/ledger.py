"""
The Application Context Ledger — what evidence an application actually has.

WHAT: One typed, immutable snapshot of everything a chat turn can draw on:
      the application's linked datasources with their health, its knowledge
      bases with their index state, and the documents uploaded into this
      session.
WHY:  ``app-plan.md`` Issue 2: today each of those is fetched fresh on every
      message by three separate functions, and nothing holds the result. A
      database is re-introspected and every MCP resource re-fetched per turn,
      while the answers are identical. The requirement is that a datasource
      added to an application is "floated throughout the application context
      until the user chats with that app" — which means resolved once and held,
      not re-derived per message.

The ledger is also the ground truth later phases check against: Phase D shows
it to the planner as *Available Evidence*, and Phase E answers "is the RFP
actually here?" from it rather than from a model's opinion. That is why it is
typed and immutable — a snapshot that can be reasoned about, not a bag of
strings assembled inline.

**Nothing here raises.** A source that cannot be reached is recorded with
``reachable=False`` and a reason. An application whose every datasource is down
still produces a ledger; it simply reports that. Replacing that report with an
exception would take the chat down for a datasource being briefly unavailable.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from . import sources as source_resolver
from .cache import (
    LEDGER_CACHE,
    ledger_enabled,
    ledger_key,
    ledger_ttl_seconds,
)

logger = logging.getLogger(__name__)

_IMAGE_MIMES = frozenset({
    "image/jpeg", "image/jpg", "image/png", "image/bmp",
    "image/tiff", "image/webp", "image/gif",
})


# ---------------------------------------------------------------------------
# The snapshot
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class LedgerSource:
    """One datasource linked to the application, as it stands right now."""

    source_id: str
    kind: str                       # api | mcp | database | knowledge | ""
    name: str
    reachable: bool
    detail: str = ""                # "12 tables", "4 documents indexed"
    error: Optional[str] = None
    payload: str = ""               # schema summary or resource text; never a secret
    meta: Mapping[str, Any] = field(default_factory=dict)

    def describe(self) -> Dict[str, Any]:
        """
        Identity and health only — safe to return over the API and to log.

        Deliberately excludes ``payload`` and ``meta``: the first can be a
        hundred thousand characters of business data and the second carries
        retrieval configuration. Neither belongs in a health response.
        """
        return {
            "source_id": self.source_id,
            "kind": self.kind,
            "name": self.name,
            "reachable": self.reachable,
            "detail": self.detail,
            "error": self.error,
        }


@dataclass(frozen=True)
class LedgerDoc:
    """One document or spreadsheet uploaded into this chat session."""

    document_id: str
    filename: str
    mime_type: str = ""
    status: str = ""
    stored_filename: str = ""
    # The chat session the document was uploaded into. Under the widened
    # ``user_application`` scope the ledger also carries uploads from earlier
    # conversations; this is what lets "uploaded in *this* conversation" still
    # be answered exactly. Empty when the source row does not record one.
    session_id: str = ""

    @property
    def is_image(self) -> bool:
        return (self.mime_type or "").lower() in _IMAGE_MIMES

    def describe(self) -> Dict[str, Any]:
        return {
            "document_id": self.document_id,
            "filename": self.filename,
            "mime_type": self.mime_type,
            "status": self.status,
        }


@dataclass(frozen=True)
class ApplicationContext:
    """
    Everything one chat turn can draw on, resolved once per session.

    Immutable by construction: a turn reads a consistent snapshot, and a
    background refresh replaces it wholesale rather than mutating it under a
    request that is midway through planning.
    """

    application_id: str
    chat_session_id: Optional[str]
    connectors: Tuple[LedgerSource, ...] = ()
    knowledge: Tuple[LedgerSource, ...] = ()
    session_docs: Tuple[LedgerDoc, ...] = ()
    tabular: Tuple[LedgerDoc, ...] = ()
    resolved_at: float = 0.0
    errors: Tuple[str, ...] = ()
    # The application's owner — the identity its datasources were resolved
    # under, and the one an agent must re-use when it calls one of them as a
    # tool. Travels onto the contribution so the agent build never has to
    # re-derive it.
    owner_user_id: str = ""

    # -- queries the rest of the pipeline asks -----------------------------

    def by_kind(self, kind: str) -> Tuple[LedgerSource, ...]:
        return tuple(s for s in self.connectors if s.kind == kind)

    @property
    def databases(self) -> Tuple[LedgerSource, ...]:
        return self.by_kind(source_resolver.KIND_DATABASE)

    @property
    def mcp_servers(self) -> Tuple[LedgerSource, ...]:
        return self.by_kind(source_resolver.KIND_MCP)

    @property
    def apis(self) -> Tuple[LedgerSource, ...]:
        return self.by_kind(source_resolver.KIND_API)

    @property
    def current_session_docs(self) -> Tuple[LedgerDoc, ...]:
        """
        Ready documents uploaded into *this* conversation, and nothing else.

        The answer to "has the user given me a document for this request". A
        document from an earlier conversation -- reachable under the widened
        ``user_application`` scope -- is not one, and a knowledge base never is:
        it is the application's reference material, not the user's submission.
        A document with no recorded session predates the field and is kept.
        """
        current = str(self.chat_session_id or "")
        return tuple(
            doc
            for doc in self.session_docs
            if doc.status == "ready"
            and (not doc.session_id or not current or doc.session_id == current)
        )

    @property
    def knowledge_base_ids(self) -> Tuple[str, ...]:
        """Ids of the knowledge bases that resolved, for the retrieval path."""
        return tuple(s.source_id for s in self.knowledge if s.reachable)

    def knowledge_metadata(self) -> Dict[str, Dict[str, Any]]:
        """
        ``{kb_id: metadata}`` for every resolved knowledge base.

        A fresh dict per call: the retriever mutates what it is handed, and the
        ledger is shared across a session.
        """
        return {
            s.source_id: dict(s.meta)
            for s in self.knowledge
            if s.reachable and s.meta
        }

    @property
    def has_readable_document(self) -> bool:
        """True when at least one uploaded document can actually be read."""
        return any(d.status == "ready" for d in self.session_docs)

    @property
    def indexed_knowledge_documents(self) -> int:
        return sum(int(s.meta.get("document_count") or 0) for s in self.knowledge)

    def describe(self) -> Dict[str, Any]:
        """The health view returned by ``GET /applications/{id}/context``."""
        return {
            "application_id": self.application_id,
            "chat_session_id": self.chat_session_id,
            "resolved_at": self.resolved_at,
            "age_seconds": max(0.0, time.time() - self.resolved_at),
            "connectors": [s.describe() for s in self.connectors],
            "knowledge": [s.describe() for s in self.knowledge],
            "session_documents": [d.describe() for d in self.session_docs],
            "tabular_files": [d.describe() for d in self.tabular],
            "counts": {
                "connectors": len(self.connectors),
                "connectors_reachable": sum(1 for s in self.connectors if s.reachable),
                "knowledge_bases": len(self.knowledge),
                "indexed_documents": self.indexed_knowledge_documents,
                "session_documents": len(self.session_docs),
                "tabular_files": len(self.tabular),
            },
            "errors": list(self.errors),
        }


EMPTY = ApplicationContext(application_id="", chat_session_id=None)


# ---------------------------------------------------------------------------
# Resolution
# ---------------------------------------------------------------------------

def _linked_source_ids(app: Any) -> List[str]:
    """Every ``data_source_id`` linked to the application, de-duplicated."""
    seen: List[str] = []
    for link in (getattr(app, "data_source_links", None) or []):
        source_id = str(getattr(link, "data_source_id", "") or "").strip()
        if source_id and source_id not in seen:
            seen.append(source_id)
    return seen


def _linked_knowledge_ids(app: Any) -> List[str]:
    """
    Knowledge bases linked explicitly, separate from the datasource picker.

    Both surfaces exist: ``knowledge_base_links`` is the dedicated one, and the
    datasource picker also writes knowledge-base UUIDs into
    ``data_source_links``. Collecting both is what the previous retrieval code
    did, and dropping either would silently unlink a user's knowledge base.
    """
    seen: List[str] = []
    for link in (getattr(app, "knowledge_base_links", None) or []):
        kb_id = str(getattr(link, "knowledge_base_id", "") or "").strip()
        if kb_id and kb_id not in seen:
            seen.append(kb_id)
    return seen


async def _resolve_knowledge(kb_ids: Sequence[str]) -> List[LedgerSource]:
    """
    Load knowledge-base metadata and index state.

    Only bases that are ``synced`` and not deleted are usable; anything else is
    reported unreachable with the reason, rather than omitted. The document
    count is what tells the readiness surface — and later the Evidence Gate —
    that a base is attached but has nothing in it, which is otherwise
    indistinguishable from a base that simply did not match the query.
    """
    if not kb_ids:
        return []

    from echolib.database import get_db_session
    from echolib.models.knowledge import KnowledgeBase, KnowledgeDocument
    from echolib.repositories.base import safe_uuid
    from echolib.repositories.knowledge_chunk_repo import KnowledgeChunkRepository
    from sqlalchemy import func, select

    uuid_by_id = {kid: safe_uuid(kid) for kid in kb_ids}
    uuids = [u for u in uuid_by_id.values() if u is not None]
    if not uuids:
        return []

    rows: Dict[str, Dict[str, Any]] = {}
    counts: Dict[str, int] = {}
    passage_counts: Dict[str, int] = {}
    markdown_counts: Dict[str, int] = {}
    try:
        async with get_db_session() as db:
            result = await db.execute(
                select(
                    KnowledgeBase.id,
                    KnowledgeBase.name,
                    KnowledgeBase.status,
                    KnowledgeBase.processing_type,
                    KnowledgeBase.search_type,
                    KnowledgeBase.top_k,
                    KnowledgeBase.embedding_model,
                    KnowledgeBase.vector_weight,
                    KnowledgeBase.keyword_weight,
                    KnowledgeBase.user_id,
                ).where(
                    KnowledgeBase.id.in_(uuids),
                    KnowledgeBase.is_deleted == False,  # noqa: E712
                )
            )
            for row in result.all():
                rows[str(row.id)] = {
                    "name": row.name,
                    "status": row.status,
                    "processing_type": row.processing_type or "vector",
                    "search_type": row.search_type or "similarity",
                    "top_k": row.top_k or 10,
                    "embedding_model": row.embedding_model,
                    "vector_weight": row.vector_weight or 0.5,
                    "keyword_weight": row.keyword_weight or 0.5,
                    # The base's owner: its passages were embedded with that
                    # account's credential, so queries are embedded there too.
                    "owner_user_id": str(row.user_id) if row.user_id else None,
                }

            count_result = await db.execute(
                select(
                    KnowledgeDocument.knowledge_base_id,
                    func.count(KnowledgeDocument.id),
                )
                .where(
                    KnowledgeDocument.knowledge_base_id.in_(uuids),
                    KnowledgeDocument.processing_status == "completed",
                )
                .group_by(KnowledgeDocument.knowledge_base_id)
            )
            counts = {str(kb_id): int(total) for kb_id, total in count_result.all()}

            # What actually makes a base searchable, and both answers are in
            # Postgres. ``knowledge_document_chunks`` is the vector store;
            # ``docling_markdown`` is the extracted text a base can be rebuilt
            # from on first use. Neither depends on a file that a container
            # restart takes away.
            passage_counts = await KnowledgeChunkRepository().counts_for_knowledge_bases(
                db, uuids
            )

            markdown_result = await db.execute(
                select(
                    KnowledgeDocument.knowledge_base_id,
                    func.count(KnowledgeDocument.id),
                )
                .where(
                    KnowledgeDocument.knowledge_base_id.in_(uuids),
                    KnowledgeDocument.processing_status == "completed",
                    KnowledgeDocument.docling_markdown.isnot(None),
                    KnowledgeDocument.docling_markdown != "",
                )
                .group_by(KnowledgeDocument.knowledge_base_id)
            )
            markdown_counts = {
                str(kb_id): int(total) for kb_id, total in markdown_result.all()
            }
    except Exception:
        logger.warning(
            "Knowledge-base metadata could not be loaded; "
            "linked bases will be reported unresolved",
            exc_info=True,
        )
        return [
            LedgerSource(
                source_id=kid,
                kind=source_resolver.KIND_KNOWLEDGE,
                name=kid,
                reachable=False,
                error="knowledge base metadata could not be loaded",
            )
            for kid in kb_ids
        ]

    resolved: List[LedgerSource] = []
    for kb_id in kb_ids:
        info = rows.get(kb_id)
        if info is None:
            resolved.append(
                LedgerSource(
                    source_id=kb_id,
                    kind=source_resolver.KIND_KNOWLEDGE,
                    name=kb_id,
                    reachable=False,
                    error="knowledge base not found or deleted",
                )
            )
            continue

        status = (info.get("status") or "").lower()
        document_count = counts.get(kb_id, 0)
        meta = dict(info)
        meta["document_count"] = document_count

        if status != "synced":
            resolved.append(
                LedgerSource(
                    source_id=kb_id,
                    kind=source_resolver.KIND_KNOWLEDGE,
                    name=info.get("name") or kb_id,
                    reachable=False,
                    detail=f"status is '{status or 'unknown'}'",
                    error=f"knowledge base is not synced (status '{status or 'unknown'}')",
                    meta=meta,
                )
            )
            continue

        # Synced is not the same as searchable — but searchability is a fact
        # about Postgres, not about this container's filesystem.
        #
        # This check used to be ``faiss_index_exists``, an ``os.path.exists``
        # against ``{KNOWLEDGE_STORAGE_DIR}/{kb_id}/faiss_index/``. That
        # directory is on the container's writable layer: it does not survive a
        # restart or a redeploy and is invisible to every other replica. So a
        # perfectly good knowledge base was reported UNAVAILABLE, the retrieval
        # path skipped it, ``build_contribution`` bound no ``kb__`` tool, and
        # the chat named the base while answering as though it were empty.
        #
        # A base is searchable when its text is in Postgres: either as stored
        # passages, or as the extracted markdown those passages are rebuilt
        # from on first use. The local index is now only a cache in front of
        # that, so its absence is not an answer.
        processing_type = str(info.get("processing_type") or "vector").lower()
        needs_vector_index = processing_type in ("vector", "hybrid")

        passage_count = passage_counts.get(kb_id, 0)
        markdown_count = markdown_counts.get(kb_id, 0)
        meta["passage_count"] = passage_count

        searchable = True
        if needs_vector_index:
            searchable = bool(passage_count or markdown_count)
            if not searchable:
                try:
                    from apps.knowledge.vector_store import faiss_index_exists

                    # Only reachable here for a base ingested before passages
                    # became durable *and* still served by the replica that
                    # built its index.
                    searchable = faiss_index_exists(kb_id)
                except Exception:
                    # Unverifiable is not the same as absent. Failing open keeps
                    # a working base usable if the check itself breaks; the
                    # retrieval path still reports honestly when it finds
                    # nothing.
                    logger.warning(
                        "Could not verify the local index for knowledge base %s; "
                        "treating it as available",
                        kb_id, exc_info=True,
                    )
                    searchable = True

        if not searchable:
            resolved.append(
                LedgerSource(
                    source_id=kb_id,
                    kind=source_resolver.KIND_KNOWLEDGE,
                    name=info.get("name") or kb_id,
                    reachable=False,
                    detail=f"{document_count} document{'s' if document_count != 1 else ''}, no readable text",
                    error=(
                        "knowledge base has no extracted text stored, so it "
                        "cannot be searched — reprocess its documents"
                    ),
                    meta=meta,
                )
            )
            continue

        resolved.append(
            LedgerSource(
                source_id=kb_id,
                kind=source_resolver.KIND_KNOWLEDGE,
                name=info.get("name") or kb_id,
                reachable=True,
                detail=(
                    f"{document_count} document{'s' if document_count != 1 else ''} indexed"
                    if document_count
                    else "no documents indexed"
                ),
                meta=meta,
            )
        )

    return resolved


async def _resolve_connector(
    source_id: str, kind: str, user_id: str
) -> LedgerSource:
    """Resolve one non-knowledge datasource into a ledger entry."""
    if not kind:
        return LedgerSource(
            source_id=source_id,
            kind=source_resolver.KIND_UNKNOWN,
            name=source_id,
            reachable=False,
            error="no connector, database or knowledge base matches this id",
        )

    name, payload, error = await source_resolver.load_payload(kind, source_id, user_id)

    detail = ""
    if kind == source_resolver.KIND_DATABASE and payload:
        # One line per table, minus the "### Database:" heading.
        table_count = max(0, len(payload.splitlines()) - 1)
        detail = f"{table_count} table{'s' if table_count != 1 else ''}"
    elif kind == source_resolver.KIND_MCP and payload:
        detail = f"{len(payload)} characters of resource content"

    return LedgerSource(
        source_id=source_id,
        kind=kind,
        name=name,
        reachable=error is None,
        detail=detail,
        error=error,
        payload=payload,
    )


async def _resolve_session_documents(
    chat_repo: Any,
    db: Any,
    chat_session_id: Optional[str],
    *,
    application_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> Tuple[Tuple[LedgerDoc, ...], Tuple[LedgerDoc, ...]]:
    """
    The uploaded documents and spreadsheets this turn can draw on.

    Both are read here so the ledger is the single answer to "what has the user
    given us" — the question the Evidence Gate will ask.

    Scope follows ``APP_DOCUMENT_SCOPE``. Under the default, ``session``, this
    is exactly the current conversation's uploads and a document stays where it
    was given. Under ``user_application`` it is every document *this user* has
    uploaded into *this application*, so reopening an application no longer
    hides the file they provided last time — the row and its passages were
    always still there, but nothing looked past the current conversation.

    Tabular files stay session-scoped in both modes. They are read by the pandas
    skill as whole spreadsheets rather than retrieved from, so widening them
    would silently change which file an analysis runs against.
    """
    if not chat_session_id or chat_repo is None or db is None:
        return (), ()

    documents: List[LedgerDoc] = []
    tabular: List[LedgerDoc] = []

    widen = False
    try:
        from apps.rag.session_documents import SCOPE_USER_APPLICATION, _effective_scope

        widen = (
            _effective_scope(None) == SCOPE_USER_APPLICATION
            and bool(application_id)
            and bool(user_id)
        )
    except Exception:
        logger.debug("Document scope could not be resolved; using session scope", exc_info=True)

    try:
        if widen:
            rows = await chat_repo.get_user_application_documents(
                db, str(application_id), str(user_id), status="ready"
            )
        else:
            rows = await chat_repo.get_session_documents(
                db, chat_session_id, status="ready"
            )
        documents = [
            LedgerDoc(
                document_id=str(getattr(row, "document_id", "") or ""),
                filename=getattr(row, "original_filename", "") or "",
                mime_type=getattr(row, "mime_type", "") or "",
                status="ready",
                stored_filename=getattr(row, "stored_filename", "") or "",
                session_id=str(getattr(row, "chat_session_id", "") or ""),
            )
            for row in (rows or [])
        ]
    except Exception:
        logger.debug(
            "Session documents unavailable for session %s", chat_session_id, exc_info=True
        )

    try:
        rows = await chat_repo.get_tabular_documents(db, chat_session_id)
        tabular = [
            LedgerDoc(
                document_id=str(getattr(row, "document_id", "") or ""),
                filename=getattr(row, "original_filename", "") or "",
                mime_type=getattr(row, "mime_type", "") or "",
                status="ready",
                stored_filename=getattr(row, "stored_filename", "") or "",
                session_id=str(getattr(row, "chat_session_id", "") or ""),
            )
            for row in (rows or [])
        ]
    except Exception:
        logger.debug(
            "Tabular documents unavailable for session %s", chat_session_id, exc_info=True
        )

    return tuple(documents), tuple(tabular)


async def build_ledger(
    app: Any,
    *,
    user_id: str,
    chat_session_id: Optional[str] = None,
    chat_repo: Any = None,
    db: Any = None,
) -> ApplicationContext:
    """
    Resolve the ledger from scratch, without consulting the cache.

    Datasources resolve concurrently: an application with a database, two MCP
    servers and a knowledge base would otherwise pay the sum of four timeouts
    on the first message of every session.

    **Two identities, deliberately.** Datasources are resolved under the
    application's *owner*, because the owner is who linked them and every
    connector service scopes its lookup by user — resolving them as whoever is
    chatting made a published application's sources unreachable for everyone but
    its author. Session documents stay scoped to the *caller*: they are that
    user's uploads and must never be served to another.
    """
    application_id = str(getattr(app, "application_id", "") or "")
    owner_user_id = str(getattr(app, "user_id", "") or "")
    principal = owner_user_id or user_id
    started = time.monotonic()

    linked = _linked_source_ids(app)
    kinds = await source_resolver.classify(linked, principal) if linked else {}

    # Knowledge bases arrive from two surfaces; both are honoured.
    kb_ids: List[str] = []
    for kb_id in _linked_knowledge_ids(app):
        if kb_id not in kb_ids:
            kb_ids.append(kb_id)
    for source_id, kind in kinds.items():
        if kind == source_resolver.KIND_KNOWLEDGE and source_id not in kb_ids:
            kb_ids.append(source_id)

    connector_ids = [
        source_id
        for source_id in linked
        if kinds.get(source_id) != source_resolver.KIND_KNOWLEDGE
    ]

    knowledge_task = _resolve_knowledge(kb_ids)
    connector_tasks = [
        _resolve_connector(source_id, kinds.get(source_id, ""), principal)
        for source_id in connector_ids
    ]
    documents_task = _resolve_session_documents(
        chat_repo, db, chat_session_id,
        application_id=application_id or None,
        user_id=user_id or None,
    )

    knowledge, connector_results, (session_docs, tabular) = await asyncio.gather(
        knowledge_task,
        asyncio.gather(*connector_tasks) if connector_tasks else _empty_list(),
        documents_task,
    )

    connectors = tuple(connector_results)
    errors = tuple(
        f"{s.name or s.source_id}: {s.error}"
        for s in (*connectors, *knowledge)
        if s.error
    )

    ledger = ApplicationContext(
        application_id=application_id,
        chat_session_id=chat_session_id,
        connectors=connectors,
        knowledge=tuple(knowledge),
        session_docs=session_docs,
        tabular=tabular,
        resolved_at=time.time(),
        errors=errors,
        owner_user_id=principal,
    )

    logger.info(
        "Ledger built for application %s session %s in %dms: "
        "%d/%d connectors reachable, %d knowledge bases (%d documents indexed), "
        "%d session documents, %d tabular files",
        application_id, chat_session_id,
        int((time.monotonic() - started) * 1000),
        sum(1 for s in connectors if s.reachable), len(connectors),
        len(knowledge), ledger.indexed_knowledge_documents,
        len(session_docs), len(tabular),
    )
    if errors:
        # The counts above cannot say *why* a source was dropped, and a source
        # the ledger reports unreachable is a source the chat answers without.
        # That took a ledger dump to diagnose once; it is one line here.
        logger.warning(
            "Application %s has %d unavailable data source(s): %s",
            application_id, len(errors), "; ".join(errors),
        )
    return ledger


async def _empty_list() -> List[Any]:
    """An awaitable empty list, so ``gather`` can be called unconditionally."""
    return []


async def get_or_build_ledger(
    app: Any,
    *,
    user_id: str,
    chat_session_id: Optional[str] = None,
    chat_repo: Any = None,
    db: Any = None,
    force: bool = False,
) -> ApplicationContext:
    """
    Return this session's ledger, building it only when there is none to serve.

    WHAT: The single entry point the pipeline calls in place of the three
          per-turn ``_retrieve_*`` functions.
    WHY:  "The data from the datasource must be fetched and must be floated
          throughout the application context until the user chats with that
          app" — so it is resolved on the first message and held, not rebuilt
          per message.
    INPUT: The loaded application, the acting user, and the chat session whose
           uploads count as evidence.
    OUTPUT: An :class:`ApplicationContext`. Never raises: a resolution failure
            produces a ledger that reports the failure.

    ``APP_CONTEXT_LEDGER=0`` bypasses the cache entirely and rebuilds per turn,
    which is the pre-Phase-A behaviour.
    """
    application_id = str(getattr(app, "application_id", "") or "")

    if not ledger_enabled():
        return await build_ledger(
            app, user_id=user_id, chat_session_id=chat_session_id,
            chat_repo=chat_repo, db=db,
        )

    key = ledger_key(application_id, chat_session_id, user_id)
    if not force:
        entry = LEDGER_CACHE.get(key)
        if entry is not None and entry.age_seconds() < ledger_ttl_seconds():
            return entry.value

    try:
        ledger = await build_ledger(
            app, user_id=user_id, chat_session_id=chat_session_id,
            chat_repo=chat_repo, db=db,
        )
    except Exception:
        logger.exception(
            "Ledger could not be built for application %s; "
            "serving the previous one if there is one",
            application_id,
        )
        entry = LEDGER_CACHE.get(key)
        if entry is not None:
            return entry.value
        return ApplicationContext(
            application_id=application_id,
            chat_session_id=chat_session_id,
            resolved_at=time.time(),
            errors=("application context could not be resolved",),
        )

    LEDGER_CACHE.put(key, ledger)
    return ledger


__all__ = [
    "EMPTY",
    "ApplicationContext",
    "LedgerDoc",
    "LedgerSource",
    "build_ledger",
    "get_or_build_ledger",
]
