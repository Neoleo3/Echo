"""
Application Context Ledger — what evidence an application has, resolved once.

WHAT: The typed snapshot of an application's linked datasources, knowledge
      bases and session uploads, plus the rendering that turns it into the
      context blocks the orchestration pipeline consumes.
WHY:  ``app-plan.md`` Phase A. Before this package, three separate functions in
      ``pipeline.py`` re-fetched the same three things on every single message —
      a full database introspection, a live MCP resource fetch, and up to
      100,000 characters of knowledge-base content — and nothing held the
      result between turns. A datasource attached to an application is supposed
      to stay in that application's context for the conversation, not be
      rediscovered per message.

Nothing here performs authorization. The pipeline has already established that
this user may use this application; the ledger resolves each source **as that
user**, so a source they do not own simply does not resolve.

Nothing here raises into the pipeline either. An unreachable source is reported
as unreachable — that report is the point, and it is what the health endpoint
and, later, the Evidence Gate read.
"""
from .cache import (
    invalidate_application,
    invalidate_session,
    invalidate_source,
    ledger_enabled,
)
from .descriptors import available_evidence, database_context, mcp_context
from .ledger import (
    ApplicationContext,
    LedgerDoc,
    LedgerSource,
    build_ledger,
    get_or_build_ledger,
)
from .sources import (
    KIND_API,
    KIND_DATABASE,
    KIND_KNOWLEDGE,
    KIND_MCP,
)

__all__ = [
    "ApplicationContext",
    "KIND_API",
    "KIND_DATABASE",
    "KIND_KNOWLEDGE",
    "KIND_MCP",
    "LedgerDoc",
    "LedgerSource",
    "available_evidence",
    "build_ledger",
    "database_context",
    "get_or_build_ledger",
    "invalidate_application",
    "invalidate_session",
    "invalidate_source",
    "ledger_enabled",
    "mcp_context",
]
