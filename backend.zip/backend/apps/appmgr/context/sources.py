"""
What each linked datasource actually is, resolved once.

WHAT: Classification of an application's ``data_source_id`` values into
      ``knowledge`` / ``database`` / ``mcp`` / ``api``, and the per-kind
      resolution that produces each source's health and payload.
WHY:  ``app-plan.md`` Cause 2e: ``application_data_source_links`` stores one
      opaque string for four different kinds of thing, so three separate
      retrieval functions each probed every id against their own service and
      swallowed the misses (``pipeline.py:1994-2001``, ``:2328-2338``,
      ``:2411-2415``). N datasources produced 3N probes per turn and every
      misclassification was silent. Classification now happens once, is cached,
      and an id that resolves to nothing is **recorded** rather than dropped.

**Loop-thread discipline.** The connector services are synchronous and reach
the network; ``apps.connector.middleware.refs`` refuses outright when called
from the event-loop thread (``Plan_1.md`` Phase 5b.1). Every call into them
here goes through ``asyncio.to_thread``. The knowledge-base lookup is native
async SQL and stays on the loop.

**Failure policy.** Nothing in this module raises into the pipeline. A source
that cannot be reached comes back with ``reachable=False`` and an ``error``
string, because "this database is attached but unreachable" is the answer the
readiness surface exists to give — an exception would replace it with nothing.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .cache import (
    CLASSIFICATION_CACHE,
    PAYLOAD_CACHE,
    classification_key,
    classification_ttl_seconds,
    payload_key,
    payload_ttl_seconds,
)

logger = logging.getLogger(__name__)

KIND_API = "api"
KIND_MCP = "mcp"
KIND_DATABASE = "database"
KIND_KNOWLEDGE = "knowledge"
KIND_UNKNOWN = ""

# Ceilings for the rendered database schema. Identical to the values
# ``_retrieve_db_data_source_context`` used, so its output is unchanged.
MAX_TABLES = 60
MAX_COLUMNS = 40
MAX_MCP_CHARS = 100_000

RESOLUTION_TIMEOUT_SECONDS = 15.0


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------

async def _knowledge_base_ids(source_ids: Sequence[str]) -> Dict[str, str]:
    """
    Return ``{source_id: name}`` for the ids that are knowledge bases.

    One query for the whole set rather than one per id. Non-UUID ids are
    filtered before the query because knowledge-base primary keys are UUIDs
    and a catalog id such as ``mcp-xxx`` would only raise.
    """
    from echolib.database import get_db_session
    from echolib.models.knowledge import KnowledgeBase
    from echolib.repositories.base import safe_uuid
    from sqlalchemy import select

    candidates = {sid: safe_uuid(sid) for sid in source_ids}
    uuids = [u for u in candidates.values() if u is not None]
    if not uuids:
        return {}

    try:
        async with get_db_session() as db:
            result = await db.execute(
                select(KnowledgeBase.id, KnowledgeBase.name).where(
                    KnowledgeBase.id.in_(uuids),
                    KnowledgeBase.is_deleted == False,  # noqa: E712
                )
            )
            found = {str(row.id): row.name for row in result.all()}
    except Exception:
        logger.warning(
            "Knowledge-base classification query failed; "
            "linked knowledge bases will be reported unresolved",
            exc_info=True,
        )
        return {}

    return {sid: found[str(uid)] for sid, uid in candidates.items()
            if uid is not None and str(uid) in found}


def _probe_connector_kind(source_id: str, user_id: str) -> str:
    """
    Ask each connector service, in turn, whether it owns this id.

    Synchronous and network-bound — always called through ``asyncio.to_thread``.
    """
    from apps.connector.middleware.refs import _infer_kind

    try:
        kind, _record = _infer_kind(source_id, user_id)
        return kind or KIND_UNKNOWN
    except Exception:
        logger.debug("Kind probe failed for '%s'", source_id, exc_info=True)
        return KIND_UNKNOWN


async def classify(source_ids: Sequence[str], user_id: str) -> Dict[str, str]:
    """
    Resolve every datasource id to its owning service, once.

    WHAT: Returns ``{source_id: kind}``, where kind is one of ``knowledge`` /
          ``database`` / ``mcp`` / ``api``, or ``""`` when nothing claims it.
    WHY:  Replaces the three blind probe loops. An unclaimed id is returned as
          ``""`` so the caller can record it as an error instead of dropping it.
    INPUT: The application's linked datasource ids and the acting user.
    OUTPUT: One entry per input id. Never raises.

    Knowledge bases are checked first and in one query: they are the only kind
    identified by a row this service owns, so confirming them up front removes
    them from the far more expensive connector probing.
    """
    ids = [str(sid).strip() for sid in source_ids if str(sid or "").strip()]
    if not ids:
        return {}

    resolved: Dict[str, str] = {}
    unresolved: List[str] = []

    # Cached classifications first — a datasource does not change identity.
    for source_id in ids:
        entry = CLASSIFICATION_CACHE.get(classification_key(source_id, user_id))
        if entry is not None and entry.age_seconds() < classification_ttl_seconds():
            resolved[source_id] = entry.value
        else:
            unresolved.append(source_id)

    if not unresolved:
        return resolved

    knowledge = await _knowledge_base_ids(unresolved)
    for source_id in list(unresolved):
        if source_id in knowledge:
            resolved[source_id] = KIND_KNOWLEDGE
            CLASSIFICATION_CACHE.put(
                classification_key(source_id, user_id), KIND_KNOWLEDGE
            )
            unresolved.remove(source_id)

    if unresolved and user_id:
        probes = await asyncio.gather(
            *[
                asyncio.to_thread(_probe_connector_kind, source_id, user_id)
                for source_id in unresolved
            ],
            return_exceptions=True,
        )
        for source_id, kind in zip(unresolved, probes):
            if isinstance(kind, BaseException) or not kind:
                resolved[source_id] = KIND_UNKNOWN
                continue
            resolved[source_id] = kind
            CLASSIFICATION_CACHE.put(classification_key(source_id, user_id), kind)
    else:
        for source_id in unresolved:
            resolved[source_id] = KIND_UNKNOWN

    return resolved


# ---------------------------------------------------------------------------
# Per-kind resolution
# ---------------------------------------------------------------------------

def _render_schema(name: str, tables: Sequence[Any]) -> str:
    """
    Render a database's tables and columns.

    Byte-identical to what ``_retrieve_db_data_source_context`` produced, so
    replacing the caller does not change a single prompt.
    """
    lines = [f"### Database: {name}"]
    for table in tables[:MAX_TABLES]:
        if not isinstance(table, dict):
            lines.append(f"- {table}")
            continue
        table_name = table.get("table_name") or table.get("name") or "?"
        columns = table.get("columns") or []
        rendered: List[str] = []
        for column in columns[:MAX_COLUMNS]:
            if isinstance(column, dict):
                rendered.append(
                    f"{column.get('name')} {column.get('type', '')}".strip()
                )
            else:
                rendered.append(str(column))
        row_count = table.get("row_count")
        suffix = f" [{row_count} rows]" if isinstance(row_count, int) else ""
        lines.append(f"- {table_name}({', '.join(rendered)}){suffix}")
    return "\n".join(lines)


def _load_database(source_id: str, user_id: str) -> Tuple[str, str, Optional[str]]:
    """
    Introspect one database. Returns ``(display_name, schema_text, error)``.

    Synchronous: ``get_connection`` and ``get_full_schema`` both do blocking
    I/O, and ``get_full_schema`` additionally runs a row count per table. This
    is the single most expensive thing the old per-turn path did.
    """
    from apps.connector.db_connector import DatabaseConnectorService

    service = DatabaseConnectorService()
    connection = service.get_connection(source_id, user_id=user_id)
    if not connection:
        return source_id, "", "connection not found for this user"

    name = (
        connection.get("name") if isinstance(connection, dict) else None
    ) or source_id

    schema = service.get_full_schema(source_id)
    tables = schema.get("tables") or schema.get("tables_info") or []
    if not tables:
        return name, "", "no tables visible on this connection"

    return name, _render_schema(name, tables), None


def _load_api(source_id: str, user_id: str) -> Tuple[str, Optional[str]]:
    """Confirm an API connector is present and enabled. Returns ``(name, error)``."""
    from apps.connector.middleware.refs import _fetch_api_record

    record = _fetch_api_record(source_id, user_id)
    if not record:
        return source_id, "connector not found for this user"
    name = record.get("name") or source_id
    if not record.get("enabled", True):
        return name, "connector is disabled"
    return name, None


async def _load_mcp(source_id: str, user_id: str) -> Tuple[str, str, Optional[str]]:
    """
    Fetch one MCP server's resource context. Returns ``(name, text, error)``.

    Native async, unlike the other two: ``MCPConnectorService`` exposes an
    async surface and the old code awaited it directly.
    """
    from echolib.services import ConnectorManager

    service = ConnectorManager().mcp
    text = await service.get_resource_context(
        source_id, user_id=user_id, max_total_chars=MAX_MCP_CHARS
    )
    if not text or not str(text).strip():
        return source_id, "", "no resource content available"
    return source_id, str(text), None


async def load_payload(
    kind: str, source_id: str, user_id: str
) -> Tuple[str, str, Optional[str]]:
    """
    Resolve one source's display name, payload and error, with caching.

    WHAT: Dispatches to the loader for ``kind`` and caches the result.
    WHY:  A database schema and an MCP resource fetch are the two things that
          made the old path cost seconds per message. Cached per source rather
          than per application, so two applications linking the same database
          share one introspection.
    OUTPUT: ``(name, payload_text, error)``. ``error`` is ``None`` on success.
            Never raises — a failure is returned, not thrown.
    """
    key = payload_key(kind, source_id, user_id)
    entry = PAYLOAD_CACHE.get(key)
    if entry is not None and entry.age_seconds() < payload_ttl_seconds():
        name, payload, error = entry.value
        return name, payload, error

    try:
        if kind == KIND_DATABASE:
            result = await asyncio.wait_for(
                asyncio.to_thread(_load_database, source_id, user_id),
                timeout=RESOLUTION_TIMEOUT_SECONDS,
            )
        elif kind == KIND_MCP:
            result = await asyncio.wait_for(
                _load_mcp(source_id, user_id),
                timeout=RESOLUTION_TIMEOUT_SECONDS,
            )
        elif kind == KIND_API:
            name, error = await asyncio.wait_for(
                asyncio.to_thread(_load_api, source_id, user_id),
                timeout=RESOLUTION_TIMEOUT_SECONDS,
            )
            result = (name, "", error)
        else:
            return source_id, "", "datasource kind could not be determined"
    except asyncio.TimeoutError:
        logger.warning(
            "Datasource '%s' (%s) timed out after %.0fs",
            source_id, kind, RESOLUTION_TIMEOUT_SECONDS,
        )
        return source_id, "", f"timed out after {RESOLUTION_TIMEOUT_SECONDS:.0f}s"
    except Exception as exc:  # noqa: BLE001 -- reported, never raised
        logger.warning(
            "Datasource '%s' (%s) could not be resolved: %s",
            source_id, kind, exc, exc_info=True,
        )
        return source_id, "", str(exc)

    PAYLOAD_CACHE.put(key, result)
    return result


__all__ = [
    "KIND_API",
    "KIND_DATABASE",
    "KIND_KNOWLEDGE",
    "KIND_MCP",
    "KIND_UNKNOWN",
    "classify",
    "load_payload",
]
