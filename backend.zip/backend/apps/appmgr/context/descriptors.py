"""
Rendering the ledger into the strings the pipeline already consumes.

WHAT: Assembles a resolved :class:`ApplicationContext` into the MCP and
      database context blocks the orchestrator and the skill executor expect,
      plus the compact *Available Evidence* summary later phases will show the
      planner.
WHY:  ``app-plan.md`` Phase A requires the three ``_retrieve_*`` functions to
      be "re-expressed over the ledger, returning byte-identical strings" — the
      cost model changes, the prompts do not. Every ceiling and every
      truncation marker below is therefore copied from the function it
      replaces, not chosen afresh.

The two assemblers differ in one detail that looks like an inconsistency and is
not: the MCP path only appends a truncated tail when more than 200 characters
of budget remain, while the database path appends whatever is left. Both
behaviours are preserved exactly as they were, because changing either would
alter a prompt this phase is not permitted to alter.

*Available Evidence* is new. It is deliberately a **descriptor** — what exists,
whether it is reachable, how much is in it — and never a payload. Current
context-engineering guidance is that stuffing retrieved content into a planning
prompt degrades the decision it is meant to inform; the planner needs to know a
database is attached and reachable, not to read its rows.
"""
from __future__ import annotations

import logging
from typing import List, Optional, Sequence

from .ledger import ApplicationContext, LedgerSource

logger = logging.getLogger(__name__)

# Ceilings inherited from the functions these replace.
MCP_MAX_TOTAL_CHARS = 100_000
DB_MAX_TOTAL_CHARS = 60_000

TRUNCATION_MARKER = "\n... [truncated]"

# The Available Evidence block is a summary, not a payload. Kept small on
# purpose: it competes for the same prompt budget as the skill manifest.
EVIDENCE_MAX_CHARS = 4_000


def _join_within_budget(
    payloads: Sequence[str],
    *,
    max_total_chars: int,
    min_remainder: int = 0,
) -> Optional[str]:
    """
    Concatenate payloads up to a character ceiling.

    ``min_remainder`` reproduces the difference between the two original
    call sites: the MCP path required more than 200 characters of headroom
    before it would append a truncated tail, the database path required none.
    """
    sections: List[str] = []
    total = 0

    for payload in payloads:
        if not payload or not payload.strip():
            continue
        if total + len(payload) > max_total_chars:
            remaining = max_total_chars - total
            if remaining > min_remainder:
                sections.append(payload[: max(0, remaining)] + TRUNCATION_MARKER)
            break
        sections.append(payload)
        total += len(payload)

    if not sections:
        return None
    return "\n\n".join(sections)


def mcp_context(ledger: ApplicationContext) -> Optional[str]:
    """
    The MCP resource block, or ``None`` when no MCP server yielded content.

    Replaces ``_retrieve_mcp_data_source_context``. Identical output; the
    difference is that the resource fetch happened when the ledger was built
    rather than on this turn.
    """
    payloads = [s.payload for s in ledger.mcp_servers if s.reachable and s.payload]
    assembled = _join_within_budget(
        payloads, max_total_chars=MCP_MAX_TOTAL_CHARS, min_remainder=200
    )
    if assembled:
        logger.info(
            "MCP data source context: %d section(s), %d chars from %d linked server(s)",
            len(payloads), len(assembled), len(ledger.mcp_servers),
        )
    return assembled


def database_context(ledger: ApplicationContext) -> Optional[str]:
    """
    The database schema block, or ``None`` when no database resolved.

    Replaces ``_retrieve_db_data_source_context``. Read-only introspection
    only — no queries, no schema changes — exactly as before.
    """
    payloads = [s.payload for s in ledger.databases if s.reachable and s.payload]
    assembled = _join_within_budget(
        payloads, max_total_chars=DB_MAX_TOTAL_CHARS, min_remainder=0
    )
    if assembled:
        logger.info(
            "Database data source context: %d schema section(s), %d chars",
            len(payloads), len(assembled),
        )
    return assembled


def _source_line(source: LedgerSource) -> str:
    """One line describing a source's identity and health."""
    parts = [f"- {source.name} ({source.kind or 'unrecognised'})"]
    if source.reachable:
        parts.append(f": {source.detail}" if source.detail else ": available")
    else:
        parts.append(f": UNAVAILABLE — {source.error or 'not reachable'}")
    return "".join(parts)


def available_evidence(
    ledger: ApplicationContext, *, max_chars: int = EVIDENCE_MAX_CHARS
) -> str:
    """
    A compact statement of what this turn can actually draw on.

    WHAT: Names every attached source, whether it is reachable, and what is in
          it, plus the documents uploaded into this conversation.
    WHY:  Phase D shows this to the planner so it can decide what a request
          needs *while knowing what is present*. An unreachable database is
          stated as unreachable rather than omitted — a planner that cannot
          tell "no database" from "database down" will confidently plan around
          data it cannot get.
    OUTPUT: A markdown block, or ``""`` when the application has nothing
            attached and nothing uploaded.
    """
    lines: List[str] = []

    # Only this conversation's uploads are the user's submission. Stated
    # explicitly when there are none: listing knowledge bases with no word about
    # uploads let the planner read reference material as the document the user
    # asked it to review, and run the whole workflow on nothing.
    uploaded = ledger.current_session_docs
    if uploaded:
        lines.append("Documents uploaded in this conversation:")
        lines.extend(
            f"- {doc.filename}" + (" (image)" if doc.is_image else "")
            for doc in uploaded
        )
    elif ledger.knowledge or ledger.connectors or ledger.tabular:
        # With nothing attached at all the block stays empty, and the planning
        # prompt already says "nothing is attached and nothing uploaded".
        lines.append(
            "No documents have been uploaded in this conversation."
            + (
                " The knowledge bases below are the application's reference "
                "material, not a document the user has submitted."
                if ledger.knowledge
                else ""
            )
        )

    if ledger.tabular:
        lines.append("")
        lines.append("Spreadsheets available for analysis:")
        lines.extend(f"- {doc.filename}" for doc in ledger.tabular)

    if ledger.knowledge:
        lines.append("")
        lines.append("Knowledge bases:")
        lines.extend(_source_line(source) for source in ledger.knowledge)

    if ledger.connectors:
        lines.append("")
        lines.append("Connected data sources:")
        lines.extend(_source_line(source) for source in ledger.connectors)

    if not lines:
        return ""

    block = "\n".join(lines).strip()
    if len(block) > max_chars:
        block = block[:max_chars].rstrip() + TRUNCATION_MARKER
    return block


__all__ = [
    "DB_MAX_TOTAL_CHARS",
    "MCP_MAX_TOTAL_CHARS",
    "available_evidence",
    "database_context",
    "mcp_context",
]
