"""
Session-scoped keying over the shared TTL cache.

WHAT: Cache keys and TTLs for the Application Context Ledger, plus the
      invalidation entry points the rest of the platform calls when the thing
      being cached actually changes.
WHY:  ``app-plan.md`` Phase A requires the ledger to be "resolved once per chat
      session, cached, invalidated on change" rather than rebuilt per turn.
      Today every message re-introspects every linked database and re-fetches
      every MCP resource.

This module deliberately adds **no cache implementation**. It is a keying layer
over ``apps.connector.middleware.cache.TTLCache``, which already provides
thread safety, TTL expiry and — the property that matters here —
stale-but-serving: when a refresh fails the previous value is returned rather
than degrading the application to no context at all. Introducing a second cache
would mean a second set of those semantics to keep correct.

Three caches, because the three things being cached change on entirely
different schedules:

``CLASSIFICATION_CACHE``
    Which service owns a ``data_source_id`` (``api`` / ``mcp`` / ``database`` /
    ``knowledge``). A datasource does not change identity, so this is keyed by
    id alone and held for a long TTL. This is what replaces the three blind
    probe loops described in ``app-plan.md`` Cause 2e.

``LEDGER_CACHE``
    The assembled :class:`ApplicationContext` for one chat session. Keyed by
    ``(application_id, chat_session_id)`` because session documents belong to
    the session while linked sources belong to the application.

``PAYLOAD_CACHE``
    The expensive per-source payloads — a database schema summary, an MCP
    resource fetch. Keyed by source so two applications linking the same
    database share one introspection.

Nothing here is query-dependent. Knowledge-base *retrieval* varies with the
user's question and is therefore never cached; only the base's metadata is.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

from apps.connector.middleware.cache import TTLCache

logger = logging.getLogger(__name__)

DEFAULT_LEDGER_TTL_SECONDS = 900
DEFAULT_CLASSIFICATION_TTL_SECONDS = 3600
DEFAULT_PAYLOAD_TTL_SECONDS = 900


def _int_env(name: str, default: int, minimum: int = 1) -> int:
    """Read a positive integer setting, falling back on anything unparseable."""
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def ledger_ttl_seconds() -> int:
    """How long an assembled ledger is served before it is rebuilt."""
    return _int_env("APP_CONTEXT_TTL_SECONDS", DEFAULT_LEDGER_TTL_SECONDS)


def classification_ttl_seconds() -> int:
    """How long a datasource's resolved kind is trusted."""
    return _int_env(
        "APP_CONTEXT_CLASSIFICATION_TTL_SECONDS", DEFAULT_CLASSIFICATION_TTL_SECONDS
    )


def payload_ttl_seconds() -> int:
    """How long a schema summary or MCP resource fetch is served."""
    return _int_env("APP_CONTEXT_PAYLOAD_TTL_SECONDS", DEFAULT_PAYLOAD_TTL_SECONDS)


def ledger_enabled() -> bool:
    """
    Whether the ledger is used at all.

    ``APP_CONTEXT_LEDGER=0`` restores the previous per-turn fetching verbatim.
    This is a **performance** rollback for a caching change, not a switch on
    application behaviour — the plan carries no behavioural feature flags.
    """
    raw = os.getenv("APP_CONTEXT_LEDGER")
    if raw is None or not raw.strip():
        return True
    return raw.strip().lower() not in ("0", "false", "no", "off")


# One instance per concern. Module-level because the cost being avoided is
# per-process, not per-request.
CLASSIFICATION_CACHE = TTLCache(ttl_seconds=DEFAULT_CLASSIFICATION_TTL_SECONDS)
LEDGER_CACHE = TTLCache(ttl_seconds=DEFAULT_LEDGER_TTL_SECONDS)
PAYLOAD_CACHE = TTLCache(ttl_seconds=DEFAULT_PAYLOAD_TTL_SECONDS)


# ---------------------------------------------------------------------------
# Keys
# ---------------------------------------------------------------------------

def ledger_key(
    application_id: str,
    chat_session_id: Optional[str],
    user_id: Optional[str] = None,
) -> str:
    """
    Cache key for one application's ledger within one chat session.

    Datasources resolve under the application's owner and are therefore the same
    for every caller, but the session documents on the same snapshot are the
    *caller's* uploads. The caller is part of the key so a widened document
    scope can never serve one user's files to another.
    """
    return f"ledger:{application_id}:{chat_session_id or '-'}:{user_id or '-'}"


def classification_key(source_id: str, user_id: str) -> str:
    """
    Cache key for a datasource's kind.

    Scoped by user as well as id: resolution asks each connector service
    whether *this user* owns the source, so a hit must not be served across
    users.
    """
    return f"kind:{user_id}:{source_id}"


def payload_key(kind: str, source_id: str, user_id: str) -> str:
    """Cache key for one source's expensive payload."""
    return f"payload:{kind}:{user_id}:{source_id}"


# ---------------------------------------------------------------------------
# Invalidation
# ---------------------------------------------------------------------------

def invalidate_session(application_id: str, chat_session_id: Optional[str]) -> None:
    """
    Drop the ledger for one chat session.

    Called when a document is uploaded: the session's evidence changed, and a
    ledger that still reports "no documents" would make the application ask for
    a file the user just provided.
    """
    # Prefix, not an exact key: the ledger is also keyed by caller and an
    # upload knows only the application and the session. Reconstructing an
    # exact key here would drop nothing and leave the session reporting "no
    # documents" for a file the user just provided.
    dropped = LEDGER_CACHE.invalidate_prefix(
        f"ledger:{application_id}:{chat_session_id or '-'}:"
    )
    logger.debug(
        "Ledger invalidated for application %s session %s (%d entr%s)",
        application_id, chat_session_id, dropped, "y" if dropped == 1 else "ies",
    )


def invalidate_application(application_id: str) -> None:
    """
    Drop every cached ledger for an application.

    Called when the application's linked datasources or knowledge bases change.
    Session keys are not enumerable from here without holding a second index,
    so this clears the ledger cache wholesale: rebuilding is one resolution
    pass and correctness after a link change matters more than a warm cache for
    unrelated applications.
    """
    LEDGER_CACHE.clear()
    logger.info(
        "Ledger cache cleared after datasource change on application %s",
        application_id,
    )


def invalidate_source(source_id: str, user_id: str) -> None:
    """Drop one datasource's classification and payload."""
    CLASSIFICATION_CACHE.invalidate(classification_key(source_id, user_id))
    for kind in ("api", "mcp", "database", "knowledge"):
        PAYLOAD_CACHE.invalidate(payload_key(kind, source_id, user_id))


__all__ = [
    "CLASSIFICATION_CACHE",
    "LEDGER_CACHE",
    "PAYLOAD_CACHE",
    "classification_key",
    "classification_ttl_seconds",
    "invalidate_application",
    "invalidate_session",
    "invalidate_source",
    "ledger_enabled",
    "ledger_key",
    "ledger_ttl_seconds",
    "payload_key",
    "payload_ttl_seconds",
]
