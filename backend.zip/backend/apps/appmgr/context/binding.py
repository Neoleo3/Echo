"""
Turning the ledger into capability the agent can actually use.

WHAT: Converts a resolved :class:`ApplicationContext` into a *contribution* —
      the connectors, knowledge bases and session documents an application
      lends to every agent that runs inside one of its chat turns — and merges
      that contribution into an agent definition.
WHY:  ``app-plan.md`` Issue 2, Causes 2c and 2d. Today an application's
      datasources arrive at the agent as up to 200,000 characters of text
      pasted onto the front of the user's question, and its databases do not
      arrive at all. Meanwhile ``Plan_1.md`` Phases 5 and 6 already built the
      machinery that turns an attachment into a *callable tool* with guards,
      budgets and per-invocation credential resolution — it was simply keyed on
      the agent's own attachments and never saw the application's.

This module is the join. It writes nothing, calls nothing, and never mutates
its inputs: it takes a ledger and a definition and returns a new definition.

**Why a contribution rather than a rewrite of the stored agent.** The agent
belongs to its author; the datasources belong to the application. Merging at
build time means an agent used by two applications sees each one's sources
while it is running there, and neither application's configuration is written
into an agent record it does not own.

**The gate that would otherwise eat this.** ``echolib.agent_contract``'s
``attached_connectors`` / ``attached_files`` / ``attached_knowledge_sources``
return nothing while an agent's own Connector Settings toggle is off. Every
entry produced here therefore carries ``origin="application"``, which those
functions honour as an exemption: the per-agent toggle governs the agent
author's attachments, not the application owner's. Without that, an agent whose
toggle happened to be off would silently drop the application's database and
the failure would look like the ledger's fault.

**Serializable by construction.** A contribution is plain JSON-able data — no
callables, no service handles. It travels to workflow agents inside the graph's
execution context, and a checkpointed HITL workflow serializes that state.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Mapping, Optional

from .ledger import ApplicationContext
from .sources import KIND_API, KIND_DATABASE, KIND_MCP

logger = logging.getLogger(__name__)

ORIGIN_APPLICATION = "application"

# Kinds an agent can actually call. An unresolved source is deliberately
# excluded: the readiness gate reports it, but binding a tool that cannot work
# would give the model a capability that fails on use.
BINDABLE_KINDS = (KIND_API, KIND_MCP, KIND_DATABASE)

# Ceiling on how many application connectors are bound to one agent. Loading
# every tool definition up front degrades tool-selection accuracy and inflates
# latency; the sources beyond the cap stay attached and stay described, they
# simply are not bound. ``app-plan.md`` Phase B risk row.
DEFAULT_MAX_BOUND_CONNECTORS = 8


def _max_bound_connectors() -> int:
    import os

    try:
        return max(1, int(os.getenv("APP_MAX_BOUND_CONNECTORS", str(DEFAULT_MAX_BOUND_CONNECTORS))))
    except (TypeError, ValueError):
        return DEFAULT_MAX_BOUND_CONNECTORS


def _alias(name: str, fallback: str) -> str:
    """
    A stable, tool-name-safe alias for a source.

    Tool names are derived from this, so it is reduced to lowercase word
    characters. An empty result falls back to the id, which is always present.
    """
    cleaned = re.sub(r"[^0-9a-zA-Z]+", "_", (name or "").strip()).strip("_").lower()
    return cleaned or re.sub(r"[^0-9a-zA-Z]+", "_", fallback).strip("_").lower()


def build_contribution(
    ledger: Optional[ApplicationContext],
    *,
    llm_selection: Optional[Any] = None,
) -> Optional[Dict[str, Any]]:
    """
    Describe what this application lends to an agent for this turn.

    WHAT: The reachable connectors and knowledge bases from the ledger, plus
          the identity of the session's uploaded documents.
    WHY:  This is the object that travels to every agent the turn executes —
          standalone, workflow node, or HITL node — so that "a datasource added
          to an app gives the whole app that context" is true of the things
          that actually run, not only of the planner.
    OUTPUT: A JSON-able dict, or ``None`` when the application has nothing to
            lend, so callers can skip the merge entirely.

    Unreachable sources are omitted. They are still reported by the ledger and
    by the readiness gate; what they must not do is become a bound tool that
    fails the moment the model trusts it.
    """
    if ledger is None:
        return None

    limit = _max_bound_connectors()
    connectors: List[Dict[str, Any]] = []
    skipped = 0

    for source in ledger.connectors:
        if not source.reachable or source.kind not in BINDABLE_KINDS:
            continue
        if len(connectors) >= limit:
            skipped += 1
            continue
        connectors.append(
            {
                "connector_id": source.source_id,
                "kind": source.kind,
                "alias": _alias(source.name, source.source_id),
                "enabled": True,
                "origin": ORIGIN_APPLICATION,
                # The identity this source resolved under, carried so the agent
                # build reads and *calls* it as the same principal. Without it
                # the agent re-resolved a lent connector as whoever was
                # chatting, and every connector service scopes by user.
                "owner_user_id": ledger.owner_user_id,
            }
        )

    if skipped:
        logger.warning(
            "Application %s has %d reachable connectors beyond the bind limit of %d; "
            "they remain attached and described but are not bound as tools",
            ledger.application_id, skipped, limit,
        )

    knowledge_sources = [
        {
            "knowledge_base_id": source.source_id,
            "name": source.name,
            "alias": _alias(source.name, source.source_id),
            "enabled": True,
            "origin": ORIGIN_APPLICATION,
            # See the connector entry above. This also replaces an unscoped
            # read on the agent side with one scoped to the application's
            # owner, which is tighter, not looser.
            "owner_user_id": ledger.owner_user_id,
        }
        for source in ledger.knowledge
        if source.reachable
    ]

    session_documents = [
        {
            "document_id": doc.document_id,
            "name": doc.filename,
            "mime_type": doc.mime_type,
        }
        for doc in ledger.session_docs
    ]

    # The application's model, carried so an agent that never chose one of its
    # own can inherit it rather than falling to the personal default of whoever
    # is chatting. Identity only — no key, no secret.
    llm: Dict[str, Any] = {}
    if llm_selection is not None and getattr(llm_selection, "is_usable", False):
        llm = {
            k: v
            for k, v in (
                ("credential_id", getattr(llm_selection, "credential_id", None)),
                ("model_id", getattr(llm_selection, "model_id", None)),
            )
            if v
        }
        # The account that chose this LLM, so an agent inheriting it resolves
        # the credential there rather than in the chatting user's account.
        llm_owner = str(getattr(llm_selection, "owner_user_id", "") or "")
        if llm and llm_owner:
            llm["owner_user_id"] = llm_owner

    if not connectors and not knowledge_sources and not session_documents and not llm:
        return None

    contribution: Dict[str, Any] = {
        "application_id": ledger.application_id,
        "chat_session_id": ledger.chat_session_id,
    }
    if llm:
        contribution["llm"] = llm
    if connectors:
        contribution["connectors"] = connectors
    if knowledge_sources:
        contribution["knowledge_sources"] = knowledge_sources
    if session_documents:
        contribution["session_documents"] = session_documents

    logger.info(
        "Application contribution for %s: %d connector(s), %d knowledge base(s), "
        "%d session document(s)",
        ledger.application_id, len(connectors), len(knowledge_sources),
        len(session_documents),
    )
    return contribution


def merge_into_agent_definition(
    definition: Optional[Mapping[str, Any]],
    contribution: Optional[Mapping[str, Any]],
) -> Dict[str, Any]:
    """
    Return a new definition carrying the application's sources as well.

    Delegates to ``echolib.agent_contract.merge_application_sources``, which
    owns the persisted shape. The merge lives there rather than here because
    the agent factory consumes contributions and the application layer produces
    them, and neither may import the other.
    """
    from echolib.agent_contract import merge_application_sources

    return merge_application_sources(
        dict(definition or {}), dict(contribution or {}) or None
    )


__all__ = [
    "ORIGIN_APPLICATION",
    "build_contribution",
    "merge_into_agent_definition",
]
