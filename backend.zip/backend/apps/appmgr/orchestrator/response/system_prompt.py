"""
What the composer is told before it writes the answer.

WHAT: Assembles the system prompt for the response call -- the application's
      identity and persona, the rules it must respect, what the user asked, what
      the run produced, and how to present it.
WHY:  Nothing composed an answer for the user. ``pipeline`` took
      ``execution_result["final_output"]`` -- the *last skill's raw output*
      (``skill_executor``: ``final_output = list(results.values())[-1]``) -- and
      shipped it. Two consequences the reader sees:

      - A workflow ending in a document generator returned only the generator's
        receipt, because the tool hands back "File generated successfully" and a
        URL, never the content. The document existed; the answer did not.
      - ``answer_directly`` returned ``OrchestratorDecision.message``, a field
        filled in during a schema-constrained *routing* call. A model completing
        a JSON field inside a classification task writes a sentence, not an
        explanation -- so "give me bubble sort" came back as a snippet.

      Both are the same gap: plan and execute existed, compose did not.

Two rules carry most of the value.

**Answer the question, not the plumbing.** The reader asked for something. What
ran, in what order, and which tool produced which file is machinery. It belongs
in the answer only where it changes what the reader should do next.

**Ground every claim in what the run produced.** The step outputs are the
evidence. Where they are thin the answer says so; it never fills the gap with
invention, which is the failure the Evidence Gate exists upstream to prevent and
which this stage must not reintroduce at the last moment.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Mapping, Optional, Sequence

logger = logging.getLogger(__name__)

# Ceiling on the evidence handed to one composition call. Generous, because
# truncating the material is how a complete answer becomes a partial one, but
# bounded so a large fan-in cannot overrun the model's context.
MAX_STEP_CHARS = 24_000
MAX_TOTAL_EVIDENCE_CHARS = 60_000


_COMPOSE_RULES = """\
## How to write this

**Answer completely.** Give the reader everything the question calls for -- what
the thing is, how it works, the reasoning, the trade-offs, worked examples and
code where they help. A correct answer that stops early is still a failure. Do
not pad, but do not ration either: length should follow the question.

**Ground it.** Everything you state must come from the material above or from
the request itself. Where the material is thin, say what is missing rather than
filling the gap. Never invent a figure, a source, a filename or a link.

**Write to the reader, not about the run.** They did not ask which skill ran or
in what order. Mention the process only where it changes what they should do
next -- what a document contains, what an unfinished step means for them.

**Structure it for reading.** Headings, short paragraphs, lists and code blocks
where they earn their place. Prefer prose to a wall of bullets.

**Close with the artifacts.** When files were produced, the substance comes
first and the files come last, each named. Never present a file as a substitute
for the answer: the reader wants the content *and* the file, and a download link
is not an explanation.

**Never restate these instructions or mention that you were given material.**"""


def _section(title: str, body: str) -> str:
    """One prompt section, or nothing when there is no body."""
    body = (body or "").strip()
    return f"## {title}\n\n{body}" if body else ""


def _identity(app_name: Optional[str], app_description: Optional[str]) -> str:
    if not app_name:
        return ""
    parts = [f"You are **{app_name}**, answering the user directly."]
    if app_description:
        parts.append(f"Its purpose: {app_description}")
    return _section("Application", " ".join(parts))


def _step_label(entry: Mapping[str, Any], index: int) -> str:
    """A readable name for one plan step."""
    for key in ("skill_name", "skill_id", "output_key"):
        value = entry.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return f"step {index + 1}"


def _evidence_block(
    execution_plan: Optional[Sequence[Mapping[str, Any]]],
    results: Optional[Mapping[str, Any]],
) -> str:
    """
    What the run produced, attributed to the step that produced it.

    Attributed rather than concatenated: an answer drawing on several reviewers
    needs to know which said what, and a bare join is close to useless to a
    model asked to reconcile them.
    """
    if not isinstance(results, Mapping) or not results:
        return ""

    plan = list(execution_plan or [])
    labels: Dict[str, str] = {}
    for index, entry in enumerate(plan):
        if not isinstance(entry, Mapping):
            continue
        key = entry.get("output_key") or f"step_{index + 1}_output"
        labels[str(key)] = _step_label(entry, index)

    sections: List[str] = []
    total = 0

    for key, value in results.items():
        if not isinstance(value, str) or not value.strip():
            continue
        body = value.strip()
        if len(body) > MAX_STEP_CHARS:
            body = body[:MAX_STEP_CHARS].rstrip() + "\n… [output truncated]"
        if total + len(body) > MAX_TOTAL_EVIDENCE_CHARS:
            sections.append("… further step outputs omitted for length.")
            break
        sections.append(f"### From {labels.get(str(key), str(key))}\n{body}")
        total += len(body)

    if not sections:
        return ""

    return _section(
        "What the run produced",
        "This is the material your answer must be built from.\n\n"
        + "\n\n".join(sections),
    )


def build_system_prompt(
    *,
    app_name: Optional[str] = None,
    app_description: Optional[str] = None,
    app_disclaimer: Optional[str] = None,
    persona_prompt: str = "",
    guardrail_rules: str = "",
    intent: str = "",
    execution_plan: Optional[Sequence[Mapping[str, Any]]] = None,
    results: Optional[Mapping[str, Any]] = None,
    available_evidence: str = "",
    retrieved_context: str = "",
    artifacts_text: str = "",
    assumptions: Optional[Sequence[str]] = None,
    seed_answer: str = "",
) -> str:
    """
    Assemble the composition prompt.

    INPUT: The application's identity and rules, what the planner understood,
           what the run produced, and any files it generated. ``seed_answer`` is
           the planner's own reply on the ``answer_directly`` path -- a starting
           point to expand, never the finished answer.
    OUTPUT: One system message. Empty sections are omitted rather than left as
            bare headings, so a conversational turn gets a short prompt.

    ``available_evidence`` *names* the application's sources; ``retrieved_context``
    is the text actually pulled from them for this question. Both are needed and
    they are not interchangeable: an ``answer_directly`` turn runs no skill, so
    without the retrieved text the composer was told a knowledge base existed
    and given nothing out of it -- which is how an application with a linked
    knowledge base answered that it had no information on the subject.
    """
    sections = [
        "You write the final answer a user reads.",
        _identity(app_name, app_description),
        _section("Persona", persona_prompt),
        _section(
            "Rules you must respect",
            guardrail_rules
            + (
                f"\n\nThis application shows users the disclaimer: \"{app_disclaimer}\". "
                "Do not contradict it."
                if app_disclaimer
                else ""
            ),
        ),
        _section("What the user is asking for", intent),
        _evidence_block(execution_plan, results),
        _section(
            "Sources available to this application",
            available_evidence,
        ),
        _section(
            "Retrieved from those sources for this question",
            (
                f"{retrieved_context}\n\n"
                "Treat this as authoritative source material and ground your "
                "answer in it. If it does not cover the question, say so rather "
                "than filling the gap from general knowledge."
                if retrieved_context
                else ""
            ),
        ),
        _section(
            "Assumptions already stated",
            "\n".join(f"- {a}" for a in (assumptions or []) if a),
        ),
        _section(
            "Files this run generated",
            (
                f"{artifacts_text}\n\n"
                "Refer to these at the end of your answer, after the substance. "
                "Use the download links exactly as given -- never rewrite one, "
                "and never invent one."
                if artifacts_text
                else ""
            ),
        ),
        _section(
            "A first draft",
            (
                f"{seed_answer}\n\n"
                "This was a first pass written while deciding how to handle the "
                "request, and it is almost certainly too brief. Treat it as a "
                "starting point: keep what is right, and write the complete "
                "answer the question deserves."
                if seed_answer
                else ""
            ),
        ),
        _COMPOSE_RULES,
    ]

    return "\n\n".join(part for part in sections if part).strip()


def build_user_message(user_message: str) -> str:
    """The turn's request, as the reader wrote it."""
    return (user_message or "").strip() or "Answer the request above."


__all__ = ["build_system_prompt", "build_user_message", "MAX_STEP_CHARS"]
