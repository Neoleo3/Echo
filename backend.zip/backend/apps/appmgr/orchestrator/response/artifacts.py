"""
Keeping generated files attached to the answer that describes them.

WHAT: Finds the download links a run produced, and guarantees they survive
      composition.
WHY:  ``SkillExecutor._register_generated_files`` runs *inside* ``execute_plan``
      (``skill_executor.py:294-300``), so by the time the pipeline reads
      ``final_output`` every ``[GENERATED_FILE:...]`` marker has already become a
      markdown download link -- in each step's output and in ``final_output``.

      The response composer rewrites that text. A model asked to rewrite will
      sometimes drop a URL, reword it, or invent a ``sandbox:`` link in its place
      -- the executor already fights that last one with ``_SANDBOX_LINK_RE``. A
      lost link means a file that was generated, registered and is sitting on
      disk with no way for the user to reach it.

      So the link is **not** entrusted to the prompt. It is extracted before
      composition and re-attached afterwards in code. Prompting is an
      optimisation here; this module is the guarantee.

Nothing here calls a model, and nothing here parses the original markers -- by
this point they are already resolved. It reads only the text the platform itself
wrote, in the exact shape ``skill_executor`` writes it.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Mapping, NamedTuple, Optional, Sequence

logger = logging.getLogger(__name__)


class Artifact(NamedTuple):
    """One generated file a run produced, and where to download it."""

    filename: str
    url: str

    def as_line(self) -> str:
        """Rendered exactly as ``skill_executor`` renders it."""
        return f"Your file **{self.filename}** is ready. [Click here to download]({self.url})"


# The link ``SkillExecutor._register_generated_files`` writes
# (``skill_executor.py:776-779, 796-799``) and the workflow path's equivalent in
# ``generated_files.register_generated_files``. Matched rather than reconstructed,
# so a change to that wording is a visible break here instead of a silent miss.
_LINK_RE = re.compile(
    r"Your file \*\*(?P<filename>[^*]+)\*\* is ready\. "
    r"\[Click here to download\]\((?P<url>[^)]+)\)"
)

# The degraded form, used when registration failed. There is no URL to protect,
# but the statement that a file exists still belongs in the answer.
_UNLINKED_RE = re.compile(
    r"Your file \*\*(?P<filename>[^*]+)\*\* was generated(?P<tail>[^.]*)\."
)


def _texts_of(execution_result: Optional[Mapping[str, Any]]) -> List[str]:
    """Every user-facing string a run produced, newest last."""
    if not isinstance(execution_result, Mapping):
        return []

    texts: List[str] = []
    results = execution_result.get("results")
    if isinstance(results, Mapping):
        texts.extend(v for v in results.values() if isinstance(v, str) and v)

    final_output = execution_result.get("final_output")
    if isinstance(final_output, str) and final_output:
        texts.append(final_output)

    return texts


def collect(execution_result: Optional[Mapping[str, Any]]) -> List[Artifact]:
    """
    The files this run generated, de-duplicated by download URL.

    OUTPUT: Artifacts in the order they were produced. Empty when the run
            generated nothing, which is the common case and costs one scan.
    """
    seen: Dict[str, Artifact] = {}

    for text in _texts_of(execution_result):
        for match in _LINK_RE.finditer(text):
            url = match.group("url").strip()
            filename = match.group("filename").strip()
            if url and url not in seen:
                seen[url] = Artifact(filename=filename, url=url)

    return list(seen.values())


def unlinked_notices(execution_result: Optional[Mapping[str, Any]]) -> List[str]:
    """
    Files that were generated but could not be registered for download.

    Carried through separately so the answer can still say the file exists.
    """
    notices: List[str] = []
    for text in _texts_of(execution_result):
        for match in _UNLINKED_RE.finditer(text):
            line = match.group(0).strip()
            if line not in notices:
                notices.append(line)
    return notices


def describe(artifacts: Sequence[Artifact]) -> str:
    """
    The artifact list as the composer is told about it.

    Given to the model so it can *refer* to the file naturally in its closing
    sentence. It is not how the link reaches the user -- :func:`ensure` is.
    """
    if not artifacts:
        return ""
    return "\n".join(
        f"- {a.filename} (download link: {a.url})" for a in artifacts
    )


def ensure(
    composed: str,
    artifacts: Sequence[Artifact],
    *,
    notices: Sequence[str] = (),
) -> str:
    """
    Re-attach any download link the composed answer does not already carry.

    WHAT: Appends a link line for every artifact whose URL is absent from
          ``composed``, and any unregistered-file notice likewise.
    WHY:  This is the guarantee that a working download survives composition.
          Matching is by **URL**, not by wording: the model is free to introduce
          the file in its own words, and as long as it kept the link the line is
          not repeated.
    OUTPUT: The answer with every artifact reachable. Never shorter than the
            input.
    """
    if not artifacts and not notices:
        return composed

    text = composed or ""
    missing = [a for a in artifacts if a.url not in text]
    missing_notices = [n for n in notices if n not in text]

    if not missing and not missing_notices:
        return text

    logger.info(
        "Re-attaching %d generated-file link(s) and %d notice(s) the composed "
        "answer did not carry",
        len(missing), len(missing_notices),
    )

    parts = [text.rstrip()] if text.strip() else []
    parts.extend(a.as_line() for a in missing)
    parts.extend(missing_notices)
    return "\n\n".join(part for part in parts if part)


__all__ = [
    "Artifact",
    "collect",
    "describe",
    "ensure",
    "unlinked_notices",
]
