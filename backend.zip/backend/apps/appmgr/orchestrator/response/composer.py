"""
The response call: one model call that turns a finished run into an answer.

WHAT: Composes the text the user reads, from the request, the plan, the step
      outputs and any files the run generated.
WHY:  ``pipeline`` returned ``execution_result["final_output"]`` -- the last
      skill's raw output -- straight to the reader. Nothing ever wrote an answer
      *for them*. See ``system_prompt`` for the two symptoms that produced.

**Degradation is the whole safety story.** This stage is additive: it improves
an answer that already exists. So every failure path returns that existing
answer unchanged, and a composition failure can never turn a successful run into
a failed turn. There is no schema and no second tier -- the output is prose, so
there is nothing to validate and nothing to re-ask for.

The artifact guarantee lives in ``artifacts.ensure``, not here. This module may
mention a file; only that one makes sure its download link reaches the reader.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Mapping, Optional, Sequence

from echolib.llm_resolver import resolve_and_build_llm

from . import artifacts as artifact_tools
from .system_prompt import build_system_prompt, build_user_message

logger = logging.getLogger(__name__)

# The composer writes prose, so a little more latitude than the planner's 0.1.
COMPOSE_TEMPERATURE = 0.3

COMPONENT = "response_composer"


def _plan_of(orchestrator_output: Optional[Mapping[str, Any]]) -> Sequence[Mapping[str, Any]]:
    plan = (orchestrator_output or {}).get("execution_plan")
    return plan if isinstance(plan, list) else []


def _text_of(response: Any) -> str:
    """Read the reply text out of whatever the provider returned."""
    content = getattr(response, "content", response)
    if isinstance(content, list):
        # Some providers answer in content blocks rather than a string.
        content = "".join(
            part.get("text", "") if isinstance(part, dict) else str(part)
            for part in content
        )
    return content.strip() if isinstance(content, str) else str(content).strip()


def should_compose(
    execution_result: Optional[Mapping[str, Any]],
    fallback_text: str,
) -> bool:
    """
    Whether composing would add anything to this turn.

    Skipped when a single step already produced the whole answer and generated
    no files -- there is nothing to reconcile, and a rewrite would spend a call
    to restate one output. Any fan-in, or any generated file, is composed:
    those are exactly the turns where the raw last output is not the answer.
    """
    if not isinstance(execution_result, Mapping):
        return False

    results = execution_result.get("results")
    step_count = len(results) if isinstance(results, Mapping) else 0

    if step_count == 0:
        return False

    if artifact_tools.collect(execution_result):
        return True
    if artifact_tools.unlinked_notices(execution_result):
        return True

    if step_count > 1:
        return True

    # One step, no files: compose only when the raw output is too thin to be the
    # answer on its own. A substantial single-skill result already is one.
    return len((fallback_text or "").strip()) < 400


async def compose(
    *,
    user_message: str,
    fallback_text: str,
    execution_result: Optional[Mapping[str, Any]] = None,
    orchestrator_output: Optional[Mapping[str, Any]] = None,
    app: Any = None,
    persona_prompt: str = "",
    guardrail_rules: str = "",
    available_evidence: str = "",
    retrieved_context: str = "",
    seed_answer: str = "",
    llm_selection: Any = None,
    app_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> str:
    """
    Write the answer for one turn.

    INPUT: The reader's message, the text that would otherwise be returned, and
           everything the run knows about what it just did.
    OUTPUT: The composed answer, with every generated file still reachable.
            Returns ``fallback_text`` unchanged on any failure.

    Runs on the application's own LLM -- the same pinned selection the planner
    uses -- so a bring-your-own-model deployment composes on the model it chose.
    """
    plan = _plan_of(orchestrator_output)
    results = (execution_result or {}).get("results")
    found = artifact_tools.collect(execution_result)
    notices = artifact_tools.unlinked_notices(execution_result)

    try:
        pinned = (
            llm_selection.resolver_kwargs()
            if llm_selection is not None and hasattr(llm_selection, "resolver_kwargs")
            else {}
        )

        llm = await resolve_and_build_llm(
            user_id=user_id,
            app_id=app_id,
            component=COMPONENT,
            temperature=COMPOSE_TEMPERATURE,
            allow_platform_fallback=True,
            framework="langchain",
            **pinned,
        )

        system_prompt = build_system_prompt(
            app_name=getattr(app, "name", None),
            app_description=getattr(app, "description", None),
            app_disclaimer=getattr(app, "disclaimer", None),
            persona_prompt=persona_prompt,
            guardrail_rules=guardrail_rules,
            intent=str((orchestrator_output or {}).get("intent") or ""),
            execution_plan=plan,
            results=results if isinstance(results, Mapping) else None,
            available_evidence=available_evidence,
            retrieved_context=retrieved_context,
            artifacts_text=artifact_tools.describe(found),
            assumptions=(orchestrator_output or {}).get("assumptions") or [],
            seed_answer=seed_answer,
        )

        from langchain_core.messages import HumanMessage, SystemMessage

        response = await asyncio.to_thread(
            llm.invoke,
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=build_user_message(user_message)),
            ],
        )
        composed = _text_of(response)

        if not composed:
            logger.warning(
                "Response composer returned nothing; keeping the raw output"
            )
            return fallback_text

        logger.info(
            "Composed response: %d char(s) from %d step output(s), %d artifact(s)",
            len(composed),
            len(results) if isinstance(results, Mapping) else 0,
            len(found),
        )
        return artifact_tools.ensure(composed, found, notices=notices)

    except Exception:  # noqa: BLE001 -- additive stage, never fails a turn
        logger.warning(
            "Response composition failed; returning the run's own output "
            "unchanged. The turn is unaffected.",
            exc_info=True,
        )
        # The raw output already carries its links: this is the text the
        # platform returned before this stage existed.
        return fallback_text


__all__ = ["compose", "should_compose", "COMPONENT"]
