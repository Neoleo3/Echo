"""
Composing the answer a user reads, after the run that produced it.

WHAT: The stage between execution and the reader. Turns a plan, its step
      outputs and any generated files into one grounded answer.
WHY:  The pipeline had planning and execution and nothing in between them and
      the user: ``final_output`` was the last skill's raw output, shipped as-is.
      A workflow ending in a document generator therefore returned the
      generator's receipt instead of the document's substance, and
      ``answer_directly`` returned a field filled in during a routing call.

Deliberately shaped like ``apps/appmgr/orchestrator/planning/`` beside it -- a
prompt module, a call module, and one concern per file -- so the two stages of
the orchestrator read the same way.

``artifacts`` is the part that must never be skipped: it re-attaches any
download link the composed answer dropped, in code rather than by prompting.
"""
from .artifacts import Artifact, collect, describe, ensure, unlinked_notices
from .composer import COMPONENT, compose, should_compose
from .system_prompt import build_system_prompt, build_user_message

__all__ = [
    "COMPONENT",
    "Artifact",
    "build_system_prompt",
    "build_user_message",
    "collect",
    "compose",
    "describe",
    "ensure",
    "should_compose",
    "unlinked_notices",
]
