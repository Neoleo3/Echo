"""
EchoAI Orchestrator -- Core LLM Intelligence

The orchestrator is the "brain" of the application pipeline.
Given the enhanced prompt, skill manifest, conversation history,
persona instructions, and guardrail rules, it decides:

    1. Which skills to invoke
    2. In what order (sequential / parallel / hybrid)
    3. How to chain inputs and outputs between steps
    4. Whether clarification is needed (HITL)
    5. Whether to return a fallback message (out-of-scope)

The orchestrator returns an execution plan as a structured JSON
object that the SkillExecutor can carry out.
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from echolib.llm_resolver import resolve_and_build_llm

logger = logging.getLogger(__name__)

# import os

# from typing import Optional
# from echolib.keyvault_loader import load_dotenv_with_keyvault

# def ensure_env_loaded():
#     """Ensure environment is loaded: use KeyVault if present, else try .env"""
#     load_dotenv_with_keyvault()

# def get_env_value_or_fail(key: str) -> str:
#     value = os.environ.get(key)
#     if not value:
#         raise EnvironmentError(
#             f"Required environment variable '{key}' not found. "
#             "Load secrets from Azure Key Vault or ensure your .env file is present."
#         )
#     return value

# ensure_env_loaded()

# llm = AzureChatOpenAI(
#     azure_endpoint=get_env_value_or_fail("AZURE_OPENAI_ENDPOINT"),
#     api_key=get_env_value_or_fail("AZURE_OPENAI_API_KEY"),  # type: ignore
#     api_version=get_env_value_or_fail("AZURE_OPENAI_API_VERSION"),
#     azure_deployment=get_env_value_or_fail("AZURE_OPENAI_DEPLOYMENT"),
#     temperature=0.1,
# )
# ---------------------------------------------------------------------------
# Alternative: OpenAI SDK (uncomment to use instead of LangChain)
# ---------------------------------------------------------------------------
# from openai import OpenAI
# openai_client = OpenAI(
#     api_key="your-key-here",
#     base_url="https://api.openai.com/v1",
# )
# OPENAI_MODEL = "gpt-4o-mini"
#
# def _call_openai(system_prompt: str, user_message: str) -> str:
#     """Call OpenAI-compatible API directly using the openai SDK."""
#     response = openai_client.chat.completions.create(
#         model=OPENAI_MODEL,
#         messages=[
#             {"role": "system", "content": system_prompt},
#             {"role": "user", "content": user_message},
#         ],
#         temperature=0.2,
#     )
#     return response.choices[0].message.content or ""
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# System Prompt Template
# ---------------------------------------------------------------------------

_ORCHESTRATOR_SYSTEM_PROMPT = """\
You are an AI orchestrator that decides which skills (workflows and agents) to invoke based on the user's request.

{app_identity_section}

{persona_section}

{guardrail_section}

{disclaimer_section}

{tags_section}

{access_context_section}

{data_sources_section}

{document_context_section}

{knowledge_context_section}

{mcp_data_sources_context_section}

{db_data_sources_context_section}

{tabular_data_section}

## Available Skills

{skill_manifest_section}

## Conversation History

{history_section}

## Instructions

1. Analyze the user's request and determine which skill(s) to invoke.
2. When choosing between a workflow and an agent for the same domain:
   - **Prefer workflows** for complex tasks requiring multi-step analysis, comprehensive reports, or tasks that benefit from multiple specialized agents collaborating (e.g., full contract review with legal, financial, and compliance analysis).
   - **Prefer agents** for simple, focused tasks that need a quick single-perspective answer (e.g., "what is the penalty clause in section 5?").
   - A workflow with N agents provides deeper, more thorough analysis but takes longer. A single agent is faster but narrower in scope.
   - If the user asks for a "full review", "complete analysis", "detailed report", or similar comprehensive requests, prefer the workflow.
   - If the user asks a specific, narrow question, prefer the agent.
3. If the request maps to a single skill, use execution_strategy "single".
4. If multiple skills are needed in sequence (output of one feeds the next), use "sequential".
5. If multiple skills can run independently in parallel, use "parallel".
6. If a mix of dependent and independent steps is needed, use "hybrid".
7. If the user's request is unclear or ambiguous, set needs_clarification=true and provide a clarification_question.
8. For greetings, small talk, and general conversational messages (e.g. hello, hi, how are you, thanks, goodbye, good morning, what's up, etc.), respond with a friendly, natural reply. Set fallback_message to your conversational response and set is_conversational to true. Do NOT treat these as errors or out-of-scope requests.
9. If the request is genuinely out-of-scope (harmful, nonsensical, or completely unrelated to any available skill and not a conversational message), set fallback_message to a helpful explanation of your capabilities and set is_conversational to false.
10. Never invent skill IDs or names -- only use skills from the Available Skills list.
11. If no skills match the request at all and it is not a conversational message, set fallback_message.
12. If the application has a disclaimer, be aware of it when responding and ensure your responses are consistent with it.
13. If Knowledge Base Context is provided, treat it as AUTHORITATIVE source material. When the user's question can be answered from this context, you MUST generate a comprehensive answer in fallback_message using ONLY the knowledge base content. Do not invoke any skills for such questions -- set the execution_plan to an empty list and provide the grounded answer directly in fallback_message. Set is_conversational to false.
14. When the user has uploaded tabular data (Excel/CSV), they may ask questions that require analysis of that data. In such cases, route their request to an agent that can perform data analysis. The data_analyst tool is auto-bound to all agents and will be invoked automatically when the agent determines it is needed. You do not need to specify the tabular file names in the execution plan -- just ensure the agent selected has the capability to analyze tabular data and it will have access to the files in its tool inputs.
15. Always provide a clear, specific reasoning in the "reasoning" field to explain how you arrived at your decisions. This is critical for transparency and debugging.
16. Conversation continuity: When the current message is a follow-up reference (e.g. "give me more details", "explain further", "summarize that", "elaborate"), use the Conversation History to determine the topic and route to the same skill or respond accordingly. When the message is a clear, self-contained new request (e.g. "tell me about elephants"), handle it on its own merit regardless of prior conversation topics. You may still set needs_clarification=true when the request is genuinely ambiguous even after considering history.

## Output Format

Return ONLY valid JSON (no markdown, no commentary) with this exact structure:
{{
    "reasoning": "Brief explanation of your decision",
    "execution_strategy": "single|sequential|parallel|hybrid",
    "execution_plan": [
        {{
            "step": 1,
            "skill_id": "uuid-of-the-skill",
            "skill_type": "workflow|agent",
            "skill_name": "Human-readable name",
            "depends_on": [],
            "parallel_group": null,
            "input_source": "user_input|step_N_output|merged",
            "output_key": "result_identifier"
        }}
    ],
    "final_output_from": "step_N|merged",
    "needs_clarification": false,
    "clarification_question": null,
    "fallback_message": null,
    "is_conversational": false
}}
"""


class Orchestrator:
    """
    Core orchestrator LLM that produces an execution plan from the
    user's enhanced prompt and available skill manifest.
    """

    async def plan(
        self,
        enhanced_prompt: str,
        skill_manifest: Dict[str, Any],
        conversation_history: List[Dict[str, str]],
        persona_prompt: str,
        guardrail_rules: str,
        document_context: Optional[str] = None,
        app_tags: Optional[List[str]] = None,
        app_designations: Optional[List[str]] = None,
        app_business_units: Optional[List[str]] = None,
        app_name: Optional[str] = None,
        app_description: Optional[str] = None,
        app_disclaimer: Optional[str] = None,
        app_data_sources: Optional[List[str]] = None,
        app_id: Optional[str] = None,
        user_id: Optional[str] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        knowledge_context: Optional[str] = None,
        mcp_data_sources_context: Optional[str] = None,
        db_data_sources_context: Optional[str] = None,
        llm_selection: Optional[Any] = None,
        available_evidence: str = "",
        known_text: str = "",
        rounds_used: int = 0,
        rounds_max: int = 2,
        original_prompt: str = "",
        replan_note: str = "",
    ) -> Dict[str, Any]:
        """
        Generate an execution plan for the given prompt.

        Args:
            enhanced_prompt: The prompt-enhanced user message.
            skill_manifest: Dict from SkillManifestBuilder.build_manifest().
            conversation_history: List of {"role": ..., "content": ...} dicts
                (most recent last, limited to last N messages).
            persona_prompt: Persona instruction string (may be empty).
            guardrail_rules: Guardrail rule summary string (may be empty).
            document_context: Optional document context retrieved from
                session-scoped RAG index (may be None).
            app_tags: Optional list of tag names assigned to the application.
            app_designations: Optional list of designation names for access context.
            app_business_units: Optional list of business unit names for access context.
            app_name: Optional application name for identity context.
            app_description: Optional application description for identity context.
            app_disclaimer: Optional disclaimer text for compliance awareness.
            app_data_sources: Optional list of data source names connected to the app.
            app_id: Optional application ID for per-app LLM credential lookup.
            user_id: Optional user UUID for user-level LLM credential resolution.
            tabular_files: Optional list of {"file_path": str, "filename": str} dicts
                representing uploaded Excel/CSV files in the session. Used to inform
                the orchestrator that tabular data analysis is available.
            knowledge_context: Optional knowledge base context assembled from
                linked knowledge bases (docling_markdown or search results).
            mcp_data_sources_context: Optional context string assembled from
                MCP data source resource contents linked to the application.

        Returns:
            Execution plan dict matching the JSON schema above.
        """
        fallback = self._empty_plan(
            fallback_message="I was unable to determine how to handle your request. "
            "Please try rephrasing."
        )

        try:
            from langchain_core.messages import SystemMessage, HumanMessage

            # ---- Build LLM via centralized resolver (user -> app -> platform fallback) ----
            # Pinned to the application's own LLM when it has one. Bring your
            # own model means the model the application was built with decides
            # what runs -- not the personal default of whoever is chatting.
            pinned = (
                llm_selection.resolver_kwargs()
                if llm_selection is not None and hasattr(llm_selection, "resolver_kwargs")
                else {}
            )

            llm = await resolve_and_build_llm(
                user_id=user_id,
                app_id=app_id,
                component="orchestrator",
                temperature=0.1,
                allow_platform_fallback=True,
                framework="langchain",
                **pinned,
            )

            # ---- Schema-constrained planning (app-plan.md Phase D) ----
            # One call produces intent, requirements and plan. It falls back to
            # the freeform path below only when neither structured output nor
            # JSON mode yields a conformant object, so a provider that supports
            # neither behaves exactly as it did before this shipped.
            try:
                from .planning import (
                    build_system_prompt as build_planning_prompt,
                    build_user_message,
                    plan_decision,
                )

                decision = await asyncio.to_thread(
                    plan_decision,
                    llm,
                    system_prompt=build_planning_prompt(
                        skill_manifest=skill_manifest,
                        available_evidence=available_evidence,
                        conversation_history=conversation_history,
                        persona_prompt=persona_prompt,
                        guardrail_rules=guardrail_rules,
                        app_name=app_name,
                        app_description=app_description,
                        app_disclaimer=app_disclaimer,
                        app_tags=app_tags,
                        app_designations=app_designations,
                        app_business_units=app_business_units,
                        known_text=known_text,
                        rounds_used=rounds_used,
                        rounds_max=rounds_max,
                        replan_note=replan_note,
                    ),
                    user_message=build_user_message(enhanced_prompt, original_prompt),
                )
                logger.info(
                    "Planned: decision=%s produces_new_content=%s "
                    "blocking_requirements=%d steps=%d",
                    decision.decision,
                    decision.produces_new_content,
                    len(decision.blocking_requirements()),
                    len(decision.execution_plan),
                )
                return decision.to_legacy_plan()
            except Exception as exc:  # noqa: BLE001 -- degrade, never fail the turn
                logger.warning(
                    "Structured planning unavailable (%s); using the freeform path",
                    exc,
                )

            system_prompt = self._build_system_prompt(
                skill_manifest,
                conversation_history,
                persona_prompt,
                guardrail_rules,
                document_context=document_context,
                app_tags=app_tags,
                app_designations=app_designations,
                app_business_units=app_business_units,
                app_name=app_name,
                app_description=app_description,
                app_disclaimer=app_disclaimer,
                app_data_sources=app_data_sources,
                tabular_files=tabular_files,
                knowledge_context=knowledge_context,
                mcp_data_sources_context=mcp_data_sources_context,
                db_data_sources_context=db_data_sources_context,
            )

            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=enhanced_prompt),
            ]

            # LangChain .invoke() is synchronous -- wrap in thread
            response = await asyncio.to_thread(llm.invoke, messages)
            raw_text = response.content if hasattr(response, "content") else str(response)

            return self._parse_plan(raw_text)

        except Exception:
            logger.exception("Orchestrator LLM call failed")
            return fallback

    # ------------------------------------------------------------------
    # System prompt construction
    # ------------------------------------------------------------------

    def _build_system_prompt(
        self,
        skill_manifest: Dict[str, Any],
        conversation_history: List[Dict[str, str]],
        persona_prompt: str,
        guardrail_rules: str,
        document_context: Optional[str] = None,
        app_tags: Optional[List[str]] = None,
        app_designations: Optional[List[str]] = None,
        app_business_units: Optional[List[str]] = None,
        app_name: Optional[str] = None,
        app_description: Optional[str] = None,
        app_disclaimer: Optional[str] = None,
        app_data_sources: Optional[List[str]] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        knowledge_context: Optional[str] = None,
        mcp_data_sources_context: Optional[str] = None,
        db_data_sources_context: Optional[str] = None,
    ) -> str:
        """Assemble the full system prompt from parts."""
        # App identity section
        app_identity_section = ""
        if app_name:
            identity_parts = [f"You are the AI assistant for the application **{app_name}**."]
            if app_description:
                identity_parts.append(f"Application purpose: {app_description}")
            app_identity_section = "## Application Identity\n\n" + " ".join(identity_parts)

        # Persona section
        persona_section = ""
        if persona_prompt:
            persona_section = f"## Persona\n\n{persona_prompt}"

        # Guardrail section
        guardrail_section = ""
        if guardrail_rules:
            guardrail_section = (
                "## Guardrail Rules\n\n"
                "You must respect these rules when selecting skills and "
                "formulating responses:\n"
                f"{guardrail_rules}"
            )

        # Disclaimer section
        disclaimer_section = ""
        if app_disclaimer:
            disclaimer_section = (
                "## Disclaimer\n\n"
                "This application has the following disclaimer that users see:\n"
                f"\"{app_disclaimer}\"\n\n"
                "Be mindful of this disclaimer in your responses. Do not contradict it."
            )

        # Tags section
        tags_section = ""
        if app_tags:
            tags_section = (
                "## Application Tags\n\n"
                f"This application is tagged as: {', '.join(app_tags)}. "
                "Consider these tags as contextual metadata when selecting "
                "skills and formulating responses."
            )

        # Access context section
        access_context_section = ""
        access_parts = []
        if app_designations:
            access_parts.append(f"Designated for: {', '.join(app_designations)}")
        if app_business_units:
            access_parts.append(f"Business units: {', '.join(app_business_units)}")
        if access_parts:
            access_context_section = (
                "## Access Context\n\n"
                f"{'. '.join(access_parts)}. "
                "Tailor responses appropriately for this audience."
            )

        # Data sources section
        data_sources_section = ""
        if app_data_sources:
            data_sources_section = (
                "## Connected Data Sources\n\n"
                f"This application has access to the following data sources: "
                f"{', '.join(app_data_sources)}. "
                "Consider these when determining which skills to invoke and "
                "what data is available for answering the user's request."
            )

        # Document context section
        document_context_section = ""
        if document_context:
            document_context_section = (
                "## Uploaded Document Context\n\n"
                "The user has uploaded documents in this conversation. The following relevant "
                "excerpts were retrieved based on their current question. Use this context "
                "when selecting skills and understand that the skills will also receive this "
                "context as input.\n\n"
                f"{document_context}"
            )

        # Knowledge base context section
        knowledge_context_section = ""
        if knowledge_context:
            knowledge_context_section = (
                "## Knowledge Base Context\n\n"
                "The following content was retrieved from knowledge bases linked to this "
                "application. Treat this as AUTHORITATIVE source material. When the user's "
                "question can be answered from this context, provide a comprehensive answer "
                "directly — do not invoke skills unnecessarily.\n\n"
                f"{knowledge_context}"
            )

        # MCP data sources context section
        mcp_data_sources_context_section = ""
        if mcp_data_sources_context:
            mcp_data_sources_context_section = (
                "## MCP Data Source Context\n\n"
                "The following content was retrieved from MCP servers linked to this "
                "application as data sources. Use this as reference material when "
                "answering the user's question. The data was fetched from live MCP "
                "server resources.\n\n"
                f"{mcp_data_sources_context}"
            )

        # Database data sources context section (schema grounding)
        db_data_sources_context_section = ""
        if db_data_sources_context:
            db_data_sources_context_section = (
                "## Database Data Source Schema\n\n"
                "The following databases are linked to this application as data "
                "sources. Their table/column schema is provided so you can ground "
                "answers in the actual data structure and route data questions to "
                "agents that have a database/SQL tool. Treat this as authoritative "
                "structure metadata.\n\n"
                f"{db_data_sources_context}"
            )

        # Tabular data section — informs the orchestrator that structured/numeric
        # files are present so it can route data analysis requests to agents that
        # have the data_analyst tool auto-bound.
        tabular_data_section = ""
        if tabular_files:
            file_names = [f.get("filename", "unknown") for f in tabular_files]
            tabular_data_section = (
                "## Uploaded Tabular Data\n\n"
                "The following structured data files (Excel/CSV) have been uploaded "
                "and are ready for computational analysis in this session:\n"
                + "\n".join(f"- {name}" for name in file_names)
                + "\n\n"
                "When the user asks questions, requests computations, statistics, or "
                "charts about this data, route their request to an agent that can perform "
                "data analysis. The data_analyst tool is auto-bound to all agents and will "
                "be invoked automatically when the agent determines it is needed."
            )

        # Skill manifest section
        skills = skill_manifest.get("skills", [])
        if skills:
            skill_lines = []
            for s in skills:
                line = (
                    f"- **{s['name']}** (id={s['skill_id']}, type={s['skill_type']}): "
                    f"{s.get('description', 'No description')}"
                )
                caps = s.get("capabilities", [])
                if caps:
                    line += f" | Capabilities: {', '.join(caps)}"
                tools = s.get("tools", [])
                if tools:
                    line += f" | Tools: {', '.join(tools)}"
                em = s.get("execution_model")
                if em:
                    line += f" | Execution model: {em}"
                agent_count = s.get("agent_count")
                if agent_count:
                    line += f" | Agents: {agent_count}"
                agent_names = s.get("agent_names", [])
                if agent_names:
                    line += f" | Agent team: {', '.join(agent_names[:8])}"
                skill_lines.append(line)
            skill_manifest_section = "\n".join(skill_lines)
        else:
            skill_manifest_section = "(No skills available)"

        # Conversation history section (last 8 messages = 4 exchanges max)
        # Already limited to 8 by the pipeline; defensive slice here
        history_msgs = conversation_history[-8:] if conversation_history else []
        if history_msgs:
            history_lines = []
            # Token-budget aware truncation:
            # - Recent messages (last 4): full content up to 500 chars
            # - Older messages (first 4): truncated to 200 chars
            for idx, msg in enumerate(history_msgs):
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
                # Newer messages get more space
                max_chars = 500 if idx >= len(history_msgs) - 4 else 200
                if len(content) > max_chars:
                    content = content[:max_chars] + "..."
                history_lines.append(f"[{role}]: {content}")
            history_section = "\n".join(history_lines)
        else:
            history_section = "(No prior conversation)"

        return _ORCHESTRATOR_SYSTEM_PROMPT.format(
            app_identity_section=app_identity_section,
            persona_section=persona_section,
            guardrail_section=guardrail_section,
            disclaimer_section=disclaimer_section,
            tags_section=tags_section,
            access_context_section=access_context_section,
            data_sources_section=data_sources_section,
            document_context_section=document_context_section,
            tabular_data_section=tabular_data_section,
            knowledge_context_section=knowledge_context_section,
            mcp_data_sources_context_section=mcp_data_sources_context_section,
            db_data_sources_context_section=db_data_sources_context_section,
            skill_manifest_section=skill_manifest_section,
            history_section=history_section,
        )

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_plan(self, raw_text: str) -> Dict[str, Any]:
        """Parse the LLM JSON response into the execution plan dict."""
        try:
            text = raw_text.strip()
            # Strip markdown code fences
            if text.startswith("```"):
                text = text.split("\n", 1)[-1] if "\n" in text else text[3:]
            if text.endswith("```"):
                text = text[:-3].strip()

            plan = json.loads(text)

            # Validate required keys and fill defaults
            plan.setdefault("reasoning", "")
            plan.setdefault("execution_strategy", "single")
            plan.setdefault("execution_plan", [])
            plan.setdefault("final_output_from", "step_1")
            plan.setdefault("needs_clarification", False)
            plan.setdefault("clarification_question", None)
            plan.setdefault("fallback_message", None)
            plan.setdefault("is_conversational", False)

            # Normalize execution_plan entries
            for step in plan.get("execution_plan", []):
                step.setdefault("step", 1)
                step.setdefault("skill_id", "")
                step.setdefault("skill_type", "workflow")
                step.setdefault("skill_name", "")
                step.setdefault("depends_on", [])
                step.setdefault("parallel_group", None)
                step.setdefault("input_source", "user_input")
                step.setdefault("output_key", f"step_{step['step']}_output")

            return plan

        except (json.JSONDecodeError, AttributeError, KeyError) as exc:
            logger.warning("Failed to parse orchestrator response as JSON: %s", exc)
            # Attempt to extract useful information from raw text
            return self._empty_plan(
                fallback_message=(
                    "I encountered an issue processing your request. "
                    "Please try again or rephrase your question."
                )
            )

    @staticmethod
    def _empty_plan(
        fallback_message: Optional[str] = None,
        clarification_question: Optional[str] = None,
        is_conversational: bool = False,
    ) -> Dict[str, Any]:
        """Return a minimal valid plan."""
        return {
            "reasoning": "Unable to produce execution plan",
            "execution_strategy": "single",
            "execution_plan": [],
            "final_output_from": "none",
            "needs_clarification": clarification_question is not None,
            "clarification_question": clarification_question,
            "fallback_message": fallback_message,
            "is_conversational": is_conversational,
        }
