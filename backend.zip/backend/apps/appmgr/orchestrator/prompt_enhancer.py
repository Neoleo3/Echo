"""
EchoAI Orchestrator -- Prompt Enhancer

Performs a single LLM call to improve the user's raw input:
    - Fixes typos and grammatical errors
    - Clarifies ambiguous intent
    - Improves readability

The enhancer does NOT answer the user's question.  It only restructures
the text and returns the enhanced version alongside detected intent
and a confidence score.

Uses a module-level ChatOpenAI instance.  Fill in the ``model``,
``base_url``, and ``api_key`` placeholders before running.

Graceful degradation: if the LLM call fails for any reason, the
original input is passed through unchanged.
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from echolib.llm_resolver import resolve_and_build_llm

logger = logging.getLogger(__name__)

# System prompt for the enhancer LLM
_ENHANCER_SYSTEM_PROMPT = (
    "You are a prompt enhancer. Your job is to improve the user's prompt.\n"
    "Fix typos, clarify intent, improve grammar, and make the prompt clearer.\n"
    "Do NOT answer the question. Do NOT add information.\n"
    "If conversation history is provided, use it to resolve ONLY vague or \n"
    "ambiguous references in the current message (e.g. 'that', 'it', 'more \n"
    "details', 'elaborate', 'give me detailed answer'). Rewrite the prompt to \n"
    "explicitly reference the topic from the previous exchange.\n"
    "Do NOT modify self-contained, clear prompts that introduce a new topic — \n"
    "leave them unchanged even if the history discusses something else.\n"
    "Return ONLY valid JSON with these keys:\n"
    '  "enhanced_prompt": the improved prompt text,\n'
    '  "detected_intent": a short phrase describing what the user wants,\n'
    '  "confidence": a float between 0.0 and 1.0 indicating how confident '
    "you are about the detected intent.\n"
    "Return nothing else -- only the JSON object."
)


class PromptEnhancer:
    """
    LLM-powered prompt enhancer.

    Uses LangChain ``SystemMessage`` / ``HumanMessage`` with the
    module-level ``ChatOpenAI`` instance defined above.
    """

    async def enhance(
        self,
        user_input: str,
        app_id: Optional[str] = None,
        user_id: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        llm_selection: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Enhance a user prompt via an LLM call.

        Args:
            user_input: Raw user message.
            app_id: Optional application ID for per-app LLM credential lookup.
            user_id: Optional user UUID for user-level LLM credential resolution.
            conversation_history: Optional list of {"role": ..., "content": ...}
                dicts from the current session. Used to resolve vague follow-up
                references in the user's prompt.
            llm_selection: The application's chosen LLM, from
                ``echolib.app_llm.resolve_app_llm_selection``. When present it
                pins the credential cascade so the enhancer runs on the model
                the application was configured with rather than on whatever the
                chatting user happens to have set as their personal default.
                Absent or unusable, behaviour is unchanged.

        Returns:
            Dict with keys:
                enhanced_prompt (str) -- the improved prompt
                detected_intent (str) -- short intent description
                confidence (float) -- intent confidence 0.0-1.0
        """
        fallback = {
            "enhanced_prompt": user_input,
            "detected_intent": "unknown",
            "confidence": 0.0,
        }

        if not user_input or not user_input.strip():
            return fallback

        try:
            from langchain_core.messages import SystemMessage, HumanMessage

            # ---- Build LLM via centralized resolver (user -> app -> platform fallback) ----
            # The application's LLM is pinned at Tier 1 / 1b, above the user's
            # personal default. Splatted unconditionally: an application that
            # has chosen nothing yields no keyword arguments and the cascade
            # behaves exactly as it did before.
            pinned = (
                llm_selection.resolver_kwargs()
                if llm_selection is not None and hasattr(llm_selection, "resolver_kwargs")
                else {}
            )

            llm = await resolve_and_build_llm(
                user_id=user_id,
                app_id=app_id,
                component="prompt_enhancer",
                temperature=0.1,
                allow_platform_fallback=True,
                framework="langchain",
                **pinned,
            )

            # Build user message with optional conversation history context
            human_content = user_input
            if conversation_history:
                history_lines = []
                for msg in conversation_history[-6:]:
                    role = msg.get("role", "unknown")
                    content = msg.get("content", "")
                    if len(content) > 300:
                        content = content[:300] + "..."
                    history_lines.append(f"[{role}]: {content}")
                history_text = "\n".join(history_lines)
                human_content = (
                    f"Conversation history:\n{history_text}\n\n"
                    f"Current user message to enhance:\n{user_input}"
                )

            messages = [
                SystemMessage(content=_ENHANCER_SYSTEM_PROMPT),
                HumanMessage(content=human_content),
            ]

            # LangChain .invoke() is synchronous -- wrap in thread
            response = await asyncio.to_thread(llm.invoke, messages)
            raw_text = response.content if hasattr(response, "content") else str(response)

            return self._parse_response(raw_text, user_input)

        except Exception:
            logger.exception("Prompt enhancement failed; passing through original input")
            return fallback

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_response(raw_text: str, original_input: str) -> Dict[str, Any]:
        """
        Parse the LLM JSON response into the expected dict structure.

        Falls back to the original input if parsing fails.
        """
        fallback = {
            "enhanced_prompt": original_input,
            "detected_intent": "unknown",
            "confidence": 0.0,
        }

        try:
            # Strip markdown code fences if present
            text = raw_text.strip()
            if text.startswith("```"):
                # Remove opening fence (possibly ```json)
                text = text.split("\n", 1)[-1] if "\n" in text else text[3:]
            if text.endswith("```"):
                text = text[:-3].strip()

            data = json.loads(text)

            enhanced = data.get("enhanced_prompt", original_input)
            intent = data.get("detected_intent", "unknown")
            confidence = data.get("confidence", 0.0)

            # Validate types
            if not isinstance(enhanced, str):
                enhanced = str(enhanced)
            if not isinstance(intent, str):
                intent = str(intent)
            try:
                confidence = float(confidence)
                confidence = max(0.0, min(1.0, confidence))
            except (ValueError, TypeError):
                confidence = 0.0

            return {
                "enhanced_prompt": enhanced,
                "detected_intent": intent,
                "confidence": confidence,
            }

        except (json.JSONDecodeError, AttributeError, KeyError):
            logger.warning("Could not parse enhancer response as JSON; using raw text")
            # If we got text but it is not JSON, use it as the enhanced prompt
            if raw_text and raw_text.strip():
                return {
                    "enhanced_prompt": raw_text.strip(),
                    "detected_intent": "unknown",
                    "confidence": 0.0,
                }
            return fallback