"""
Checking that the evidence a request needs is actually there, before running it.

WHAT: A pure function between planning and execution. It takes the requirements
      the planner declared and answers, from the Application Context Ledger,
      whether each one is actually present — then either lets the run proceed or
      stops it with a message naming what is missing.
WHY:  ``app-plan.md`` Issue 1. Phase D made the planner *declare* what a request
      needs; nothing read the declaration. "Evaluate this RFP" with no upload
      still planned straight to execution and the workflow invented an RFP.

**Why this makes no model call, on a bring-your-own-LLM platform.**

Two reasons, and both matter.

The first is correctness. The question here is *"is there a readable document in
this session?"* — a fact the database already holds. Asking a model to judge it
would replace a lookup with a guess, and a guess is exactly what this phase
exists to remove. Current guidance is explicit: use deterministic checks
wherever possible rather than LLM-based validation, and enforce governance
before actions reach the wire so a blocked action is *structurally impossible
rather than merely unlikely*.

The second is that this platform supplies no model of its own. Every LLM belongs
to the user, and the one selected for an application drives every stage before
an agent runs. A gate that needed its own model would either need a platform
credential — which the platform deliberately does not provide — or would fail
whenever the user's model was unavailable. A gate that needs no model always
works, for every tenant, at zero cost.

**This is not the only layer, and it is not claimed to be.** Microsoft's own
groundedness detection is model-based, but it answers a different question:
whether a generated *answer* is supported by a *source it was given*. It
presupposes the source exists. This gate is what establishes that. Relevance —
"a document is here, but is it the right one?" — is handled downstream, by the
agent's own retrieval (Phase B) and by the optional sufficiency grader that
already ships in ``apps/agent/readiness/grading.py``.

**It never stops a run on its own opinion.** Two independent keys are required:
the planner must mark a requirement blocking, *and* the ledger must confirm it
absent. A well-specified request never reaches the refusal branch, and a
requirement the gate does not understand is demoted rather than enforced — it
fails toward executing, always.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# At most this many blocking requirements are put to the user at once. Research
# on clarification-seeking finds well-calibrated askers match frontier quality
# with far fewer questions, and that over-asking simply trades hallucination for
# interrogation. Anything beyond the cap is demoted to optional.
MAX_BLOCKING = 3

OUTCOME_PROCEED = "proceed"
OUTCOME_PROCEED_WITH_CAVEAT = "proceed_with_caveat"
OUTCOME_STOP = "stop"

REASON_MISSING_EVIDENCE = "missing_evidence"

# Marks a requirement the gate derived from a skill's configuration rather than
# one the planner declared.
SOURCE_SKILL_PRECONDITION = "skill_precondition"


@dataclass(frozen=True)
class Satisfaction:
    """One requirement the ledger confirmed, and what confirmed it."""

    label: str
    kind: str
    satisfied_by: str          # the source's name, e.g. "q3-proposal.pdf"
    source_kind: str           # where it came from, e.g. "session_document"


@dataclass(frozen=True)
class GateResult:
    """What the gate concluded, in full, for the trace and the renderer."""

    outcome: str = OUTCOME_PROCEED
    reason: Optional[str] = None
    missing: Tuple[Dict[str, Any], ...] = ()
    optional: Tuple[Dict[str, Any], ...] = ()
    satisfied: Tuple[Satisfaction, ...] = ()
    demoted: Tuple[Dict[str, Any], ...] = ()
    capped: int = 0
    available: Tuple[str, ...] = ()
    duration_ms: int = 0

    # Shape of the plan that was gated, captured before a stop clears it.
    # ``app-plan.md`` defers per-step gating "until trace data shows it
    # happening" -- and without these two fields that rule cannot be checked,
    # because ``apply()`` empties ``execution_plan`` on a stop. Together they
    # answer the only question that would justify the change: were any blocked
    # turns multi-step *and* genuinely parallel, so that the unblocked steps
    # could have produced standalone value?
    planned_steps: int = 0
    execution_strategy: str = ""

    @property
    def stopped(self) -> bool:
        return self.outcome == OUTCOME_STOP

    @property
    def configured_only(self) -> bool:
        """
        True when the stop rests only on a skill's configured upload need.

        The planner declared nothing missing; it planned a skill that cannot
        run without an upload. That is the one stop worth a second look -- the
        request may not have needed that skill at all.
        """
        return self.stopped and bool(self.missing) and all(
            m.get("source") == SOURCE_SKILL_PRECONDITION for m in self.missing
        )

    def satisfied_note(self) -> str:
        """
        Tell the executing skill which source answers which requirement.

        A run that proceeds because a document was found should say *which*
        document, and what it is expected to be. An agent handed a file with no
        idea what it is supposed to contain cannot notice when it is the wrong
        file; an agent told "the RFP you were asked to evaluate is
        q3-proposal.pdf" can. This is the cheapest available narrowing of the
        gap between a source being *present* and being *relevant*, and it costs
        no model call.
        """
        if not self.satisfied:
            return ""
        lines = [
            f"- {s.label}: {s.satisfied_by}"
            for s in self.satisfied
            if s.satisfied_by
        ]
        if not lines:
            return ""
        return (
            "The following were confirmed available for this request:\n"
            + "\n".join(lines)
            + "\nUse them. If one does not actually contain what it should, say "
            "so plainly rather than working around it."
        )

    def caveat_note(self) -> str:
        """Instruction injected when the run proceeds with unmet optional needs."""
        if not self.optional:
            return ""
        labels = [str(o.get("label") or "") for o in self.optional]
        labels = [label for label in labels if label]
        if not labels:
            return ""
        return (
            "These were not available for this request: "
            + ", ".join(labels)
            + ". Complete the task with what you have, and state explicitly "
            "what you could not verify. Do not present an assumption as a "
            "finding."
        )

    def describe(self) -> Dict[str, Any]:
        """
        The record written on every turn, whether it stopped or proceeded.

        ``app-plan.md`` Decision 1 removed the feature flag in favour of
        observability: a misfire has to be diagnosable from the trace rather
        than by toggling the gate off. The suppression list is the evidence that
        it is not over-asking.
        """
        return {
            "outcome": self.outcome,
            "reason": self.reason,
            "missing": [m.get("label") for m in self.missing],
            "optional": [o.get("label") for o in self.optional],
            "satisfied": [
                {
                    "label": s.label,
                    "satisfied_by": s.satisfied_by,
                    "source": s.source_kind,
                }
                for s in self.satisfied
            ],
            "demoted": list(self.demoted),
            "capped": self.capped,
            "duration_ms": self.duration_ms,
            "planned_steps": self.planned_steps,
            "execution_strategy": self.execution_strategy,
        }


# ---------------------------------------------------------------------------
# The lookups
# ---------------------------------------------------------------------------
#
# Five entries, one per kind the ledger can answer for. These are not business
# rules and nothing here knows what an RFP is: the planner decides *what* a
# request requires, and this table only answers *whether it is there*. Adding a
# use case changes nothing below.


def _uploaded_documents(ledger: Any) -> Tuple[Any, ...]:
    """
    Ready documents uploaded into this conversation -- the user's submission.

    Never a knowledge base, and never a file from an earlier conversation. A
    ledger without ``current_session_docs`` (a stand-in in a caller that builds
    its own) falls back to every ready session document, which is what this
    lookup returned before.
    """
    current = getattr(ledger, "current_session_docs", None)
    if current is not None:
        return tuple(current)
    return tuple(
        doc
        for doc in (getattr(ledger, "session_docs", ()) or ())
        if getattr(doc, "status", "") == "ready"
    )


def _first_document(ledger: Any) -> Optional[Tuple[str, str]]:
    for doc in _uploaded_documents(ledger):
        return doc.filename, "session_document"
    return None


def _first_tabular(ledger: Any) -> Optional[Tuple[str, str]]:
    for doc in getattr(ledger, "tabular", ()) or ():
        return doc.filename, "spreadsheet"
    return None


def _first_database(ledger: Any) -> Optional[Tuple[str, str]]:
    for source in getattr(ledger, "databases", ()) or ():
        if source.reachable:
            return source.name, "database"
    return None


def _first_knowledge(ledger: Any) -> Optional[Tuple[str, str]]:
    for source in getattr(ledger, "knowledge", ()) or ():
        if source.reachable and int((source.meta or {}).get("document_count") or 0) > 0:
            return source.name, "knowledge_base"
    return None


def _first_connector(ledger: Any) -> Optional[Tuple[str, str]]:
    for source in getattr(ledger, "connectors", ()) or ():
        if source.reachable:
            return source.name, source.kind or "connector"
    return None


def _first_upload(ledger: Any) -> Optional[Tuple[str, str]]:
    """Any file the user uploaded in this conversation -- a document or a spreadsheet."""
    return _first_document(ledger) or _first_tabular(ledger)


_LOOKUPS: Dict[str, Callable[[Any], Optional[Tuple[str, str]]]] = {
    "document": _first_document,
    "tabular": _first_tabular,
    "database": _first_database,
    "knowledge": _first_knowledge,
    "connector": _first_connector,
}

# Lookups the gate uses for requirements it derives itself. Never a planner
# kind -- the planner's vocabulary is the closed set above -- so a requirement
# carrying one of these always came from configuration, not from a model.
_INTERNAL_LOOKUPS: Dict[str, Callable[[Any], Optional[Tuple[str, str]]]] = {
    "upload": _first_upload,
}

# Kinds a *file the user supplies* can be. A requirement that names file types
# is always one of these, whatever kind it was filed under.
_FILE_KINDS = ("document", "tabular")


def _effective_kind(entry: Dict[str, Any]) -> str:
    """
    The kind a requirement is actually checked as.

    WHAT: The declared kind, except that a requirement listing file types
          (``accepts``) is checked as an uploaded document.
    WHY:  "The ARB document to review, pdf or docx" is a file the user must
          upload. Filed under ``knowledge`` it was satisfied by any knowledge
          base with a document in it, and the workflow ran on reference
          material instead of the user's submission. Only an upload in this
          conversation can satisfy a file requirement.
    """
    kind = str(entry.get("kind") or "").strip().lower()
    accepts = [a for a in (entry.get("accepts") or []) if str(a).strip()]
    if accepts and kind not in _FILE_KINDS:
        return "document"
    return kind


def _lookup_for(
    entry: Dict[str, Any],
) -> Optional[Callable[[Any], Optional[Tuple[str, str]]]]:
    """The lookup that answers one requirement, or ``None`` for an unknown kind."""
    internal = str(entry.get("lookup") or "")
    if internal:
        return _INTERNAL_LOOKUPS.get(internal)
    return _LOOKUPS.get(_effective_kind(entry))


def _skill_key(value: Any) -> str:
    """
    One comparable form of a skill id.

    The manifest lists ids as UUIDs while a planner may echo them back as
    ``wf_<hex>`` / ``agt_<hex>`` or without hyphens. A lookup that compared the
    raw strings missed the skill and let an upload-dependent workflow run.
    """
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        from echolib.id_utils import normalize_to_uuid

        return normalize_to_uuid(raw)
    except Exception:  # noqa: BLE001 -- an unparseable id is compared as written
        return raw.lower()


def declares_user_file(plan: Optional[Dict[str, Any]]) -> bool:
    """
    Whether the planner named a file the user must supply, blocking or not.

    Used to refuse the one escape from an upload stop: a request the planner
    itself described as being about the user's document is never answered
    without that document.
    """
    if not isinstance(plan, dict):
        return False
    return any(
        isinstance(entry, dict) and _effective_kind(entry) in _FILE_KINDS
        for entry in (plan.get("evidence_required") or [])
    )


def skill_upload_requirements(
    plan: Optional[Dict[str, Any]],
    skill_manifest: Optional[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    The uploads the planned skills need before they can run, from configuration.

    WHAT: One blocking requirement per planned skill whose manifest entry says
          ``needs_uploaded_document`` -- its Start node requires a file upload,
          or the agent the Start node feeds reads files with File Reader.
    WHY:  Every other requirement is the planner's inference, and the planner
          does not reliably declare one: with knowledge bases attached it
          treated them as the document to review, or declared nothing, and the
          whole workflow ran on no input. What a workflow consumes is a fact of
          its configuration, so it is checked as a fact, on every turn.
    OUTPUT: Requirement dicts in the planner's shape, marked
            ``source="skill_precondition"``. Empty when no planned skill needs
            an upload, which is every application this does not concern.
    """
    if not isinstance(plan, dict) or not isinstance(skill_manifest, dict):
        return []

    by_id: Dict[str, Dict[str, Any]] = {}
    for skill in skill_manifest.get("skills") or []:
        if isinstance(skill, dict) and skill.get("needs_uploaded_document"):
            by_id[_skill_key(skill.get("skill_id"))] = skill

    if not by_id:
        return []

    requirements: List[Dict[str, Any]] = []
    seen: set = set()
    for step in plan.get("execution_plan") or []:
        if not isinstance(step, dict):
            continue
        skill_id = _skill_key(step.get("skill_id"))
        skill = by_id.get(skill_id)
        if skill is None or skill_id in seen:
            continue
        seen.add(skill_id)
        name = str(skill.get("name") or step.get("skill_name") or "this workflow")
        requirements.append(
            {
                "kind": "document",
                "lookup": "upload",
                "label": f"the document for {name} to work on",
                "blocking": True,
                "why": (
                    "This workflow works on a document you upload in this "
                    "conversation, and none has been uploaded yet."
                ),
                "accepts": list(skill.get("upload_accepts") or []),
                "source": SOURCE_SKILL_PRECONDITION,
                "skill_id": str(skill.get("skill_id") or skill_id),
            }
        )
    return requirements


def _available_summary(ledger: Any) -> Tuple[str, ...]:
    """
    What the application *does* have, for the message.

    A refusal that only says what is missing reads as a dead end. Saying what is
    present tells the user whether they misconfigured the application or simply
    forgot to attach something.
    """
    items: List[str] = []

    ready_docs = _uploaded_documents(ledger)
    if ready_docs:
        items.append(f"{len(ready_docs)} uploaded document(s)")
    if getattr(ledger, "tabular", ()):
        items.append(f"{len(ledger.tabular)} spreadsheet(s)")

    for label, sources in (
        ("database", getattr(ledger, "databases", ()) or ()),
        ("knowledge base", getattr(ledger, "knowledge", ()) or ()),
    ):
        reachable = [s for s in sources if s.reachable]
        if reachable:
            names = ", ".join(s.name for s in reachable[:3])
            items.append(f"{len(reachable)} {label}(s): {names}")

    return tuple(items)


# ---------------------------------------------------------------------------
# The gate
# ---------------------------------------------------------------------------

def check(
    plan: Optional[Dict[str, Any]],
    ledger: Any,
    skill_manifest: Optional[Dict[str, Any]] = None,
) -> GateResult:
    """
    Decide whether this turn may execute.

    WHAT: Resolves every blocking artifact requirement against the ledger.
    WHY:  The planner's requirement list is an inference. Acting on it unchecked
          fails both ways — refusing when the document is present, proceeding
          when it is not. Only a lookup can settle it.
    INPUT: The legacy plan dict from ``OrchestratorDecision.to_legacy_plan()``,
           and this session's ledger.
    OUTPUT: A :class:`GateResult`. Never raises, never calls a model.

    Requirements the planner did not mark blocking are collected as *optional*
    and never stop anything — they become an instruction to say what could not
    be verified.

    ``skill_manifest``, when given, adds the uploads the planned skills need by
    configuration (:func:`skill_upload_requirements`). Those do not depend on
    the planner declaring anything. Omitted, the gate behaves as before.
    """
    import time

    started = time.monotonic()

    if not isinstance(plan, dict) or ledger is None:
        return GateResult(duration_ms=0)

    # Captured now, because a stop clears the plan before it is traced.
    steps = plan.get("execution_plan")
    planned_steps = len(steps) if isinstance(steps, list) else 0
    strategy = str(plan.get("execution_strategy") or "")

    declared = plan.get("evidence_required")
    declared = declared if isinstance(declared, list) else []

    # A configured upload need is redundant only when the planner already
    # declared a blocking file requirement of its own -- that one is checked
    # below, and a second bullet would ask for the same file twice. Listed
    # first so the cap below can never demote it to optional.
    declares_blocking_file = any(
        isinstance(entry, dict)
        and entry.get("blocking")
        and _effective_kind(entry) in _FILE_KINDS
        for entry in declared
    )
    configured = (
        []
        if declares_blocking_file
        else skill_upload_requirements(plan, skill_manifest)
    )
    requirements = configured + declared

    if not requirements:
        return GateResult(
            duration_ms=int((time.monotonic() - started) * 1000),
            planned_steps=planned_steps,
            execution_strategy=strategy,
        )

    missing: List[Dict[str, Any]] = []
    optional: List[Dict[str, Any]] = []
    satisfied: List[Satisfaction] = []
    demoted: List[Dict[str, Any]] = []

    # Answering directly about a document the user has not uploaded is writing
    # the review of nothing. When the planner itself names a user document the
    # request is about, that requirement blocks a direct answer however it was
    # flagged -- "optional" only makes sense for a run that still reads real
    # input. Every other decision keeps the planner's own flag.
    answers_directly = str(plan.get("decision") or "") == "answer_directly"

    for entry in requirements:
        if not isinstance(entry, dict):
            continue

        kind = _effective_kind(entry)
        label = str(entry.get("label") or kind or "something").strip()
        lookup = _lookup_for(entry)

        if lookup is None:
            # Schema drift, an unenforced grammar, or a repaired tool call that
            # produced a kind this gate has no lookup for. It must never stop a
            # run: a false proceed is today's behaviour and no regression, while
            # a false stop is a new, user-visible defect.
            demoted.append({"label": label, "kind": kind, "reason": "unknown_kind"})
            optional.append({**entry, "label": label})
            continue

        found = lookup(ledger)
        if found is not None:
            name, source_kind = found
            satisfied.append(
                Satisfaction(label=label, kind=kind, satisfied_by=name, source_kind=source_kind)
            )
            continue

        if entry.get("blocking") or (answers_directly and kind in _FILE_KINDS):
            missing.append({**entry, "label": label})
        else:
            optional.append({**entry, "label": label})

    capped = 0
    if len(missing) > MAX_BLOCKING:
        capped = len(missing) - MAX_BLOCKING
        optional.extend(missing[MAX_BLOCKING:])
        missing = missing[:MAX_BLOCKING]

    duration_ms = int((time.monotonic() - started) * 1000)

    if missing:
        logger.info(
            "Evidence gate stopping the run: %d requirement(s) absent (%s); "
            "%d satisfied, %d optional, plan was %d step(s) / %s",
            len(missing), ", ".join(m["label"] for m in missing),
            len(satisfied), len(optional), planned_steps, strategy or "unspecified",
        )
        return GateResult(
            outcome=OUTCOME_STOP,
            reason=REASON_MISSING_EVIDENCE,
            missing=tuple(missing),
            optional=tuple(optional),
            satisfied=tuple(satisfied),
            demoted=tuple(demoted),
            capped=capped,
            available=_available_summary(ledger),
            duration_ms=duration_ms,
            planned_steps=planned_steps,
            execution_strategy=strategy,
        )

    outcome = OUTCOME_PROCEED_WITH_CAVEAT if optional else OUTCOME_PROCEED
    if satisfied:
        logger.debug(
            "Evidence gate: %d requirement(s) satisfied from the ledger",
            len(satisfied),
        )

    return GateResult(
        outcome=outcome,
        missing=(),
        optional=tuple(optional),
        satisfied=tuple(satisfied),
        demoted=tuple(demoted),
        capped=capped,
        available=_available_summary(ledger),
        duration_ms=duration_ms,
        planned_steps=planned_steps,
        execution_strategy=strategy,
    )


@dataclass(frozen=True)
class Reconciliation:
    """Verdict on an ask the ledger contradicts."""

    resolved: bool = False
    satisfied: Tuple[Satisfaction, ...] = ()
    unresolved: Tuple[str, ...] = ()

    def describe(self) -> Dict[str, Any]:
        """Trace record, so a correction is always attributable."""
        return {
            "resolved": self.resolved,
            "satisfied": [
                {"label": s.label, "kind": s.kind, "satisfied_by": s.satisfied_by}
                for s in self.satisfied
            ],
            "unresolved": list(self.unresolved),
        }

    def satisfied_text(self) -> str:
        """What to state back to the planner on the re-plan."""
        if not self.satisfied:
            return ""
        return "\n".join(
            f"- {s.label}: {s.satisfied_by}" for s in self.satisfied if s.satisfied_by
        )


def reconcile(plan: Optional[Dict[str, Any]], ledger: Any) -> Reconciliation:
    """
    Decide whether an ask is already answered by what the session holds.

    WHAT: For a plan whose decision is to come back to the user, resolves every
          **blocking artifact** requirement against the ledger and reports
          whether all of them are in fact present.
    WHY:  ``check`` is one-directional. It turns a proceed into a stop when a
          declared artifact is absent, but nothing turned a *false ask* into a
          proceed when the artifact is plainly there -- so a user who had just
          uploaded a document was asked to upload it. The ledger is the ground
          truth for presence; consulting it only in order to refuse is half the
          mechanism.
    INPUT: The legacy plan dict, and this session's ledger.
    OUTPUT: A :class:`Reconciliation`. ``resolved`` is true only when there is at
            least one blocking artifact requirement and **every** blocking
            requirement is an artifact kind that the ledger satisfies.
            Never raises, never calls a model.

    Deliberately conservative in three ways:

    * A blocking **information** requirement ("which client is this for") has no
      answer in any ledger. One of those present means the ask stands, and this
      returns ``resolved=False``.
    * An unrecognised ``kind`` counts as unresolved. ``check`` demotes those
      toward executing because a false stop is the worse failure there; here the
      safe direction is the opposite -- keep asking rather than silently proceed
      on evidence nobody confirmed.
    * A decision that is not an ask is not reconciled at all.
    """
    if not isinstance(plan, dict) or ledger is None:
        return Reconciliation()

    if not plan.get("needs_clarification"):
        return Reconciliation()

    evidence = plan.get("evidence_required")
    evidence = evidence if isinstance(evidence, list) else []
    information = plan.get("information_required")
    information = information if isinstance(information, list) else []

    # A parameter the user has to supply cannot be looked up. One blocking
    # entry here and the ask is legitimate.
    blocking_information = [
        entry
        for entry in information
        if isinstance(entry, dict) and entry.get("blocking")
    ]
    if blocking_information:
        return Reconciliation(
            unresolved=tuple(
                str(e.get("label") or "unnamed") for e in blocking_information
            )
        )

    blocking_evidence = [
        entry for entry in evidence if isinstance(entry, dict) and entry.get("blocking")
    ]
    if not blocking_evidence:
        # Asking without any blocking artifact requirement. Not this
        # function's business -- the clarification budget handles it.
        return Reconciliation()

    satisfied: List[Satisfaction] = []
    unresolved: List[str] = []

    for entry in blocking_evidence:
        kind = _effective_kind(entry)
        label = str(entry.get("label") or kind or "something").strip()
        lookup = _lookup_for(entry)

        if lookup is None:
            unresolved.append(label)
            continue

        found = lookup(ledger)
        if found is None:
            unresolved.append(label)
            continue

        name, source_kind = found
        satisfied.append(
            Satisfaction(
                label=label, kind=kind, satisfied_by=name, source_kind=source_kind
            )
        )

    if unresolved or not satisfied:
        return Reconciliation(
            satisfied=tuple(satisfied), unresolved=tuple(unresolved)
        )

    logger.info(
        "Evidence reconciliation: the planner asked for %d artifact(s) the "
        "session already holds (%s); the ask is superseded",
        len(satisfied),
        ", ".join(f"{s.label}={s.satisfied_by}" for s in satisfied),
    )
    return Reconciliation(resolved=True, satisfied=tuple(satisfied))


def apply(plan: Dict[str, Any], result: GateResult, message: str) -> Dict[str, Any]:
    """
    Fold a stop decision into the plan the pipeline already routes on.

    WHAT: Returns a new plan carrying the gate's verdict.
    WHY:  ``HITLManager`` branches on ``needs_clarification``; reusing that
          branch means the stop travels the existing clarification path with no
          new state machine and no new session state value.

    ``evidence_block`` marks the stop as an *artifact* stop. The clarification
    budget honours it and never force-proceeds: an information requirement has a
    default — page count, tone, format — but a missing document has none, and
    "proceed without the RFP using a reasonable default" is precisely the
    invention this whole plan exists to prevent. The run keeps stating what it
    needs until it is provided or the request changes. That is not a loop: it
    costs one planning call per turn and escalates nothing.
    """
    updated = dict(plan)

    if not result.stopped:
        return updated

    updated["needs_clarification"] = True
    updated["clarification_question"] = message
    updated["decision"] = "needs_input"
    updated["evidence_block"] = True
    # Whether the stop is waiting for a file from the user, as opposed to a
    # database or connector only an administrator can attach. Read on the next
    # turn to decide whether that message answers this stop.
    updated["awaiting_upload"] = any(
        _effective_kind(m) in _FILE_KINDS for m in result.missing
    )
    updated["execution_plan"] = []
    return updated


__all__ = [
    "MAX_BLOCKING",
    "OUTCOME_PROCEED",
    "OUTCOME_PROCEED_WITH_CAVEAT",
    "OUTCOME_STOP",
    "REASON_MISSING_EVIDENCE",
    "SOURCE_SKILL_PRECONDITION",
    "GateResult",
    "Reconciliation",
    "Satisfaction",
    "apply",
    "check",
    "declares_user_file",
    "reconcile",
    "skill_upload_requirements",
]
