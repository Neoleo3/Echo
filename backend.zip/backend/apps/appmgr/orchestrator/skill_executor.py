"""
EchoAI Orchestrator -- Skill Executor

Executes the orchestrator's execution plan by invoking the appropriate
skill for each step:

    - Workflows: resolved via DI container -> WorkflowExecutor.execute_workflow()
    - Agents:    resolved via DI container -> StandaloneAgentRunner.run()

Execution Strategies:
    - single:     Execute one skill, return output
    - sequential: Loop steps in order; output N -> input N+1
    - parallel:   Group by parallel_group; asyncio.gather() per group
    - hybrid:     Topological sort on depends_on; independent steps run in parallel
"""

import asyncio
import logging
import os
import re
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from echolib.generated_files import validate_generated_file_path
from echolib.type_resolver import TypeResolver  # ✅ For type validation of workflow inputs

logger = logging.getLogger(__name__)

# Pattern to match [GENERATED_FILE:path:filename] markers emitted by agent tools.
# We capture the full payload then split from the right to support colons in paths
# (for example Windows drive letters like C:\\...).
_GENERATED_FILE_MARKER_RE = re.compile(
    r"\[GENERATED_FILE:(?P<payload>[^\]]+)\]"
)

# Pattern to match LLM-fabricated sandbox: markdown links that should be stripped.
# Captures: [link text](sandbox:/any/path)
_SANDBOX_LINK_RE = re.compile(
    r"\[([^\]]*)\]\(sandbox:[^)]+\)"
)

# Separator ``_build_merged_document_context`` puts between the session's file
# manifest and the passages retrieved for this turn.
_EXCERPT_SEPARATOR = "\n\n--- RETRIEVED EXCERPTS ---\n\n"


def _manifest_only(document_context: str) -> str:
    """
    Keep the list of uploaded filenames, drop the retrieved passages.

    The manifest names what the conversation holds and carries no document
    content; the excerpts are one similarity search made against the user's
    opening question, before any agent knew what it needed. When the agent has
    ``documents__search`` it retrieves far better passages itself — but only if
    it is told the files exist, which is what the manifest does.

    A context with no separator is entirely excerpts (nothing was uploaded this
    turn but something was retrieved), so nothing is kept.
    """
    text = document_context or ""
    head, separator, _ = text.partition(_EXCERPT_SEPARATOR)
    if not separator:
        return "" if not text.startswith("DOCUMENTS IN THIS SESSION") else text
    return head


class _AgentStreamEmitter:
    """
    Turns an agent's execution events into what an application chat reader sees.

    Two channels, deliberately distinct — this is the split every production
    assistant makes:

    - **Activity.** "Running: Sales Insights" → "using data_analyst" → "done".
      Written onto the plan step the pipeline already created for this skill, so
      the reader sees progress on the row that is already on screen.
    - **Answer.** Token fragments as ``output_delta`` frames, so the text appears
      as it is written instead of arriving whole after every step has finished.

    The activity line updates an **existing** step rather than publishing a step
    array of its own. The CrewAI executor this replaces emitted a one-element
    array, and because an A2UI ``dataModelUpdate`` replaces ``/steps`` outright,
    every other step vanished from the reader's screen for the duration of the
    agent call and reappeared afterwards.
    """

    def __init__(
        self,
        *,
        sse_queue: Optional[asyncio.Queue],
        run_id: Optional[str],
        activity: Optional[Any],
        step_num: int,
        agent_name: str,
    ) -> None:
        from echolib.a2ui import A2UIStreamBuilder
        from apps.agent.streaming import TokenCoalescer

        self._queue = sse_queue
        self._run_id = run_id
        self._activity = activity
        self._step_num = step_num
        self._agent_name = agent_name
        self._builder = A2UIStreamBuilder()
        self._coalescer = TokenCoalescer()

    async def on_event(self, event: Any) -> None:
        """Consume one ``AgentEvent``. Never raises into the run."""
        from apps.agent.streaming import (
            EVENT_ERROR,
            EVENT_FINAL,
            EVENT_PROGRESS,
            EVENT_TOKEN,
            EVENT_TOOL_END,
            EVENT_TOOL_START,
        )

        try:
            if event.type == EVENT_TOKEN:
                batch = self._coalescer.add(event.text)
                if batch:
                    await self._send_delta(batch)
            elif event.type == EVENT_TOOL_START:
                await self._say(f"using {event.name}")
            elif event.type == EVENT_TOOL_END:
                await self._say(f"{event.name} finished")
            elif event.type == EVENT_PROGRESS and event.text:
                await self._say(event.text[:120])
            elif event.type == EVENT_FINAL:
                await self._flush()
            elif event.type == EVENT_ERROR:
                await self._say(f"failed: {event.text[:120]}")
        except Exception:
            logger.debug("Agent stream emission failed", exc_info=True)

    async def close(self) -> None:
        """Flush anything still buffered. Safe to call more than once."""
        try:
            await self._flush()
        except Exception:
            logger.debug("Agent stream flush failed", exc_info=True)

    # -- internals -----------------------------------------------------

    async def _flush(self) -> None:
        batch = self._coalescer.flush()
        if batch:
            await self._send_delta(batch)

    async def _send_delta(self, text: str) -> None:
        if self._queue is None or not self._run_id:
            return
        line = self._builder.output_delta(self._run_id, text, self._coalescer.seq)
        try:
            self._queue.put_nowait(line)
        except asyncio.QueueFull:
            # Dropping a fragment would corrupt the reader's running text, so a
            # full queue means the reader is not keeping up and the answer is
            # delivered whole by ``final_output`` instead.
            logger.debug("SSE queue full; dropping agent output delta")

    async def _say(self, detail: str) -> None:
        """Update the pipeline's step line for this skill."""
        if self._activity is None:
            return
        result = self._activity(self._step_num, self._agent_name, detail)
        if asyncio.iscoroutine(result):
            await result


class SkillExecutor:
    """
    Executes an orchestrator plan by dispatching to workflow and agent executors.
    """

    def __init__(self) -> None:
        # Agent execution is resolved per call from the DI container
        # (``agent.standalone``) rather than constructed here. Phase 9 replaced
        # the CrewAI ``StandaloneAgentExecutor`` this class used to own; the
        # replacement lives under ``apps/agent`` because it is the agent app's
        # concern, and importing it directly would be the app-to-app dependency
        # Finding 13 is about.
        pass

    async def execute_plan(
        self,
        db: AsyncSession,
        execution_plan: List[Dict[str, Any]],
        execution_strategy: str,
        user_input: str,
        app_config: Optional[Dict[str, Any]] = None,
        document_context: Optional[str] = None,
        tabular_files: Optional[List[Dict[str, Any]]] = None,
        knowledge_context: Optional[str] = None,
        mcp_data_source_context: Optional[str] = None,
        db_data_source_context: Optional[str] = None,
        application_context: Optional[Dict[str, Any]] = None,
        evidence_notes: Optional[List[str]] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        sse_queue: Optional[asyncio.Queue] = None,
        run_id: Optional[str] = None,
        app_id: Optional[str] = None,
        user_id: Optional[str] = None,
        chat_session_id: Optional[str] = None,
        application_id: Optional[str] = None,
        on_activity: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Execute the orchestrator's plan.

        Note: Agent-vs-workflow deduplication is handled upstream in
        SkillManifestBuilder._build_from_db().  Agents that are already
        embedded inside a linked workflow are excluded from the manifest,
        so the orchestrator LLM will never generate plans that invoke
        the same agent both standalone and within a workflow.

        Args:
            db: Async database session.
            execution_plan: List of step dicts from the orchestrator output.
            execution_strategy: "single" | "sequential" | "parallel" | "hybrid"
            user_input: The original/enhanced user input.
            app_config: Optional application config dict (not used directly
                        but available for future extensibility).
            document_context: Optional document context retrieved from
                session-scoped RAG index. When provided, it is prepended
                to each step's input so workflows and agents receive the
                relevant document chunks.
            sse_queue: Optional asyncio.Queue for A2UI SSE streaming.
            run_id: Optional run identifier for A2UI streaming. When provided,
                it is injected into the workflow executor's input_payload so
                that workflow transparency events route to the correct
                ws_manager queue subscriber. Defaults to None to not break
                existing callers.
            chat_session_id: Optional UUID string of the chat session. When
                provided, generated file markers in agent output are registered
                in the DB and replaced with download URLs.
            application_id: Optional UUID string of the application. Required
                alongside chat_session_id for generated file registration.
            on_activity: Optional callback ``(step_num, skill_name, detail)``
                invoked while an agent runs, so the caller can update the step
                line the reader is already looking at. The caller owns the step
                array; this executor never publishes one.

        Returns:
            Dict with keys:
                results: {output_key: result_text} for each step
                final_output: str -- the final response text
                execution_log: list of step log dicts
        """
        # Store document_context on instance for use in _execute_step
        self._document_context = document_context
        # Store knowledge_context on instance for use in _execute_step
        self._knowledge_context = knowledge_context
        # Store MCP data source context on instance for use in _execute_step
        self._mcp_data_source_context = mcp_data_source_context
        # Store DB data source context. It used to be computed, handed to the
        # planner, and then dropped before execution -- so a database linked to
        # an application was visible when choosing a skill and invisible to the
        # skill that ran (app-plan.md Cause 2b).
        self._db_data_source_context = db_data_source_context
        # What the application lends every agent this turn: its reachable
        # connectors, knowledge bases and session documents, as capability
        # rather than as pasted text.
        self._application_context = application_context
        # What the Evidence Gate established before this run was allowed to
        # start: which source satisfies which declared requirement, and what
        # could not be verified. A skill told that "the RFP to evaluate is
        # q3-proposal.pdf" can notice when that file is not an RFP; a skill
        # handed an unlabelled file cannot.
        self._evidence_notes: List[str] = list(evidence_notes or [])
        # Store conversation_history on instance for use in _execute_step
        self._conversation_history = conversation_history
        # Store tabular_files on instance for data_analyst tool injection
        self._tabular_files: List[Dict[str, Any]] = tabular_files or []
        # Store sse_queue on instance for use in _execute_agent
        self._sse_queue = sse_queue
        # Store run_id on instance for injection into workflow input_payload
        self._run_id = run_id
        # Store app_id on instance for per-app LLM credential resolution
        self._app_id = app_id
        # Store user_id on instance for user-level LLM credential resolution
        self._user_id = user_id
        # Store session context for generated file registration
        self._chat_session_id = chat_session_id
        self._application_id = application_id
        # Live activity callback. The pipeline owns the step array the reader
        # sees, so an executing agent reports progress through this rather than
        # publishing a competing array of its own.
        self._activity = on_activity

        if not execution_plan:
            return {
                "results": {},
                "final_output": "",
                "execution_log": [],
            }

        strategy = execution_strategy.lower()

        if strategy == "single":
            result = await self._execute_single(db, execution_plan, user_input)
        elif strategy == "sequential":
            result = await self._execute_sequential(db, execution_plan, user_input)
        elif strategy == "parallel":
            result = await self._execute_parallel(db, execution_plan, user_input)
        elif strategy == "hybrid":
            result = await self._execute_hybrid(db, execution_plan, user_input)
        else:
            logger.warning(
                "Unknown execution strategy '%s'; falling back to sequential",
                strategy,
            )
            result = await self._execute_sequential(db, execution_plan, user_input)

        # Post-process: scan all text outputs for [GENERATED_FILE:...] markers,
        # register them in the DB (GeneratedFileRepository), and replace the
        # markers with human-readable download prompts.
        if chat_session_id and application_id and not result.get("hitl_interrupted"):
            result = await self._register_generated_files(
                db, result, chat_session_id, application_id
            )

        return result

    # ------------------------------------------------------------------
    # Single
    # ------------------------------------------------------------------

    async def _execute_single(
        self,
        db: AsyncSession,
        plan: List[Dict[str, Any]],
        user_input: str,
    ) -> Dict[str, Any]:
        """Execute a single skill."""
        step = plan[0]
        result, log_entry = await self._execute_step(
            db, step, user_input, {}
        )

        # HITL interrupt check
        if isinstance(result, dict) and result.get("hitl_interrupted"):
            return {
                "hitl_interrupted": True,
                "completed_steps": [],
                "interrupted_at_step": step.get("step", 0),
                "interrupt_payload": result,
                "run_id": result.get("run_id"),
                "workflow_id": result.get("workflow_id"),
                "results": {},
                "final_output": "",
                "execution_log": [log_entry],
            }

        output_key = step.get("output_key", "step_1_output")
        return {
            "results": {output_key: result},
            "final_output": result,
            "execution_log": [log_entry],
        }

    # ------------------------------------------------------------------
    # Sequential
    # ------------------------------------------------------------------

    async def _execute_sequential(
        self,
        db: AsyncSession,
        plan: List[Dict[str, Any]],
        user_input: str,
    ) -> Dict[str, Any]:
        """Execute steps one after another; output N feeds input N+1."""
        results: Dict[str, str] = {}
        execution_log: List[Dict[str, Any]] = []
        current_input = user_input
        completed_steps: List[Dict[str, Any]] = []

        for step in sorted(plan, key=lambda s: s.get("step", 0)):
            input_source = step.get("input_source", "user_input")
            if input_source.startswith("step_") and input_source.endswith("_output"):
                # Use previous step's output
                current_input = results.get(input_source, current_input)
            elif input_source == "merged":
                # Merge all previous results
                current_input = "\n\n".join(results.values()) if results else user_input

            result, log_entry = await self._execute_step(
                db, step, current_input, results
            )

            # HITL interrupt check -- stop sequential execution and
            # propagate the interrupt along with completed prior steps.
            if isinstance(result, dict) and result.get("hitl_interrupted"):
                execution_log.append(log_entry)
                remaining_steps = [
                    s for s in sorted(plan, key=lambda s: s.get("step", 0))
                    if s.get("step", 0) > step.get("step", 0)
                ]
                return {
                    "hitl_interrupted": True,
                    "completed_steps": completed_steps,
                    "interrupted_at_step": step.get("step", 0),
                    "interrupt_payload": result,
                    "run_id": result.get("run_id"),
                    "workflow_id": result.get("workflow_id"),
                    "remaining_plan": remaining_steps,
                    "results": results,
                    "final_output": list(results.values())[-1] if results else "",
                    "execution_log": execution_log,
                }

            output_key = step.get("output_key", f"step_{step.get('step', 0)}_output")
            results[output_key] = result
            execution_log.append(log_entry)
            completed_steps.append({
                "step": step.get("step", 0),
                "skill_name": step.get("skill_name", step.get("skill_id", "")),
                "output": result,
            })
            current_input = result  # default chain

        final_output = list(results.values())[-1] if results else ""
        return {
            "results": results,
            "final_output": final_output,
            "execution_log": execution_log,
        }

    # ------------------------------------------------------------------
    # Parallel
    # ------------------------------------------------------------------

    async def _execute_parallel(
        self,
        db: AsyncSession,
        plan: List[Dict[str, Any]],
        user_input: str,
    ) -> Dict[str, Any]:
        """Execute steps grouped by parallel_group concurrently.

        When any step in a parallel group returns a HITL interrupt,
        we collect outputs from all completed steps (this group +
        prior groups) and propagate the interrupt upward.  Only the
        *first* HITL interrupt encountered in a group is surfaced;
        others are logged but not tracked (a single HITL pause is
        enough to halt the pipeline).
        """
        groups: Dict[Optional[Any], List[Dict[str, Any]]] = defaultdict(list)
        for step in plan:
            pg = step.get("parallel_group")
            groups[pg].append(step)

        results: Dict[str, str] = {}
        execution_log: List[Dict[str, Any]] = []
        completed_steps: List[Dict[str, Any]] = []

        for group_key in sorted(groups.keys(), key=lambda k: str(k)):
            group_steps = groups[group_key]
            tasks = [
                self._execute_step(db, step, user_input, results)
                for step in group_steps
            ]
            group_results = await asyncio.gather(*tasks, return_exceptions=True)

            hitl_interrupt = None  # first HITL interrupt in this group

            for step, result_or_exc in zip(group_steps, group_results):
                output_key = step.get("output_key", f"step_{step.get('step', 0)}_output")
                if isinstance(result_or_exc, Exception):
                    logger.error(
                        "Parallel step %s failed: %s", step.get("step"), result_or_exc
                    )
                    results[output_key] = f"[Error: {result_or_exc}]"
                    execution_log.append({
                        "step": step.get("step"),
                        "skill_id": step.get("skill_id"),
                        "status": "failed",
                        "error": str(result_or_exc),
                    })
                else:
                    result_text, log_entry = result_or_exc
                    execution_log.append(log_entry)

                    # Check for HITL interrupt
                    if isinstance(result_text, dict) and result_text.get("hitl_interrupted"):
                        if hitl_interrupt is None:
                            hitl_interrupt = result_text
                            hitl_interrupt["_step"] = step
                        else:
                            logger.warning(
                                "Multiple HITL interrupts in parallel group %s; "
                                "only the first is propagated.", group_key,
                            )
                    else:
                        results[output_key] = result_text
                        completed_steps.append({
                            "step": step.get("step", 0),
                            "skill_name": step.get("skill_name", step.get("skill_id", "")),
                            "output": result_text,
                        })

            # If a HITL interrupt occurred in this group, stop processing
            if hitl_interrupt is not None:
                interrupted_step = hitl_interrupt.pop("_step", {})
                remaining_group_keys = [
                    k for k in sorted(groups.keys(), key=lambda k: str(k))
                    if str(k) > str(group_key)
                ]
                remaining_steps = []
                for rk in remaining_group_keys:
                    remaining_steps.extend(groups[rk])

                return {
                    "hitl_interrupted": True,
                    "completed_steps": completed_steps,
                    "interrupted_at_step": interrupted_step.get("step", 0),
                    "interrupt_payload": hitl_interrupt,
                    "run_id": hitl_interrupt.get("run_id"),
                    "workflow_id": hitl_interrupt.get("workflow_id"),
                    "remaining_plan": remaining_steps,
                    "results": results,
                    "final_output": list(results.values())[-1] if results else "",
                    "execution_log": execution_log,
                }

        final_output = "\n\n---\n\n".join(results.values()) if results else ""
        return {
            "results": results,
            "final_output": final_output,
            "execution_log": execution_log,
        }

    # ------------------------------------------------------------------
    # Hybrid (topological sort)
    # ------------------------------------------------------------------

    async def _execute_hybrid(
        self,
        db: AsyncSession,
        plan: List[Dict[str, Any]],
        user_input: str,
    ) -> Dict[str, Any]:
        """
        Execute steps based on dependency graph.

        Steps with no unresolved dependencies run in parallel.
        Steps that depend on others wait for their dependencies.

        When any step returns a HITL interrupt, execution halts
        immediately.  Completed step outputs and remaining plan
        steps are collected and propagated upward.
        """
        results: Dict[str, str] = {}
        execution_log: List[Dict[str, Any]] = []
        completed_steps: List[Dict[str, Any]] = []

        # Build dependency map
        step_map: Dict[int, Dict[str, Any]] = {}
        for step in plan:
            step_num = step.get("step", 0)
            step_map[step_num] = step

        completed: set = set()
        remaining = set(step_map.keys())

        while remaining:
            # Find steps whose dependencies are all completed
            ready = []
            for step_num in remaining:
                step = step_map[step_num]
                deps = step.get("depends_on", [])
                if all(d in completed for d in deps):
                    ready.append(step_num)

            if not ready:
                # No progress -- break to avoid infinite loop (circular deps)
                logger.error(
                    "Hybrid execution stalled: circular dependencies detected "
                    "among steps %s", remaining,
                )
                for step_num in remaining:
                    step = step_map[step_num]
                    output_key = step.get("output_key", f"step_{step_num}_output")
                    results[output_key] = "[Error: circular dependency]"
                    execution_log.append({
                        "step": step_num,
                        "skill_id": step.get("skill_id"),
                        "status": "failed",
                        "error": "Circular dependency detected",
                    })
                break

            # Execute ready steps in parallel
            tasks = []
            for step_num in ready:
                step = step_map[step_num]
                input_source = step.get("input_source", "user_input")
                step_input = user_input
                if input_source.startswith("step_") and input_source.endswith("_output"):
                    step_input = results.get(input_source, user_input)
                elif input_source == "merged":
                    # Merge results from dependencies
                    dep_results = []
                    for d in step.get("depends_on", []):
                        dep_step = step_map.get(d)
                        if dep_step:
                            dep_key = dep_step.get("output_key", f"step_{d}_output")
                            if dep_key in results:
                                dep_results.append(results[dep_key])
                    step_input = "\n\n".join(dep_results) if dep_results else user_input

                tasks.append(
                    (step_num, self._execute_step(db, step, step_input, results))
                )

            coros = [t[1] for t in tasks]
            gathered = await asyncio.gather(*coros, return_exceptions=True)

            hitl_interrupt = None  # first HITL interrupt in this batch

            for (step_num, _), result_or_exc in zip(tasks, gathered):
                step = step_map[step_num]
                output_key = step.get("output_key", f"step_{step_num}_output")
                if isinstance(result_or_exc, Exception):
                    logger.error("Hybrid step %s failed: %s", step_num, result_or_exc)
                    results[output_key] = f"[Error: {result_or_exc}]"
                    execution_log.append({
                        "step": step_num,
                        "skill_id": step.get("skill_id"),
                        "status": "failed",
                        "error": str(result_or_exc),
                    })
                else:
                    result_text, log_entry = result_or_exc
                    execution_log.append(log_entry)

                    # Check for HITL interrupt
                    if isinstance(result_text, dict) and result_text.get("hitl_interrupted"):
                        if hitl_interrupt is None:
                            hitl_interrupt = result_text
                            hitl_interrupt["_step_num"] = step_num
                        else:
                            logger.warning(
                                "Multiple HITL interrupts in hybrid batch; "
                                "only the first is propagated.",
                            )
                    else:
                        results[output_key] = result_text
                        completed_steps.append({
                            "step": step_num,
                            "skill_name": step.get("skill_name", step.get("skill_id", "")),
                            "output": result_text,
                        })

                completed.add(step_num)
                remaining.discard(step_num)

            # If a HITL interrupt occurred in this batch, stop processing
            if hitl_interrupt is not None:
                interrupted_step_num = hitl_interrupt.pop("_step_num", 0)
                remaining_steps = [
                    step_map[sn] for sn in sorted(remaining)
                ]
                return {
                    "hitl_interrupted": True,
                    "completed_steps": completed_steps,
                    "interrupted_at_step": interrupted_step_num,
                    "interrupt_payload": hitl_interrupt,
                    "run_id": hitl_interrupt.get("run_id"),
                    "workflow_id": hitl_interrupt.get("workflow_id"),
                    "remaining_plan": remaining_steps,
                    "results": results,
                    "final_output": list(results.values())[-1] if results else "",
                    "execution_log": execution_log,
                }

        final_output = list(results.values())[-1] if results else ""
        return {
            "results": results,
            "final_output": final_output,
            "execution_log": execution_log,
        }

    # ------------------------------------------------------------------
    # Generated file registration (post-execution marker scanning)
    # ------------------------------------------------------------------

    async def _register_generated_files(
        self,
        db: AsyncSession,
        execution_result: Dict[str, Any],
        chat_session_id: str,
        application_id: str,
    ) -> Dict[str, Any]:
        """
        Scan all text outputs in the execution result for [GENERATED_FILE:...]
        markers, register each discovered file in the DB, and replace the
        marker with a human-readable download prompt including the download URL.

        WHY: Agent tools (ppt_generator, excel_generator, data_analyst) write
        files to disk and embed opaque markers in their output. This method
        converts those markers into registered download links so the frontend
        can present clickable download buttons to the user.

        The pattern is: [GENERATED_FILE:/path/to/file.pptx:My Presentation.pptx]
        After processing it becomes:
            "Your file is ready for download: [My Presentation.pptx](/api/...)"

        Args:
            db: Async database session (used to flush new GeneratedFile records).
            execution_result: The dict returned by the strategy execute method.
            chat_session_id: UUID string of the originating chat session.
            application_id: UUID string of the originating application.

        Returns:
            A new execution_result dict with markers replaced by download links.
            The original dict is not mutated.
        """
        from echolib.repositories.generated_file_repo import GeneratedFileRepository

        _gen_file_repo = GeneratedFileRepository()
        base_url = f"/api/applications/{application_id}/generated-files"

        # MIME type lookup table for known generator output types
        _MIME_MAP = {
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".pdf": "application/pdf",
        }

        # Keep one DB registration per unique normalized artifact in this
        # execution result. Duplicate markers can appear across step outputs and
        # final_output, which otherwise creates multiple download keys.
        registered_artifacts: Dict[tuple, str] = {}

        async def _replace_markers(text: str) -> str:
            """Replace [GENERATED_FILE:path:filename] markers with download links."""
            if not text:
                return text

            if "[GENERATED_FILE:" not in text:
                # Remove hallucinated sandbox links even when no generated marker exists.
                return _SANDBOX_LINK_RE.sub(
                    lambda m: m.group(1) if m.group(1) else "",
                    text,
                )

            result_text = text
            for match in _GENERATED_FILE_MARKER_RE.finditer(text):
                payload = match.group("payload")
                if ":" not in payload:
                    logger.warning("Malformed generated file marker payload: %s", payload)
                    continue

                file_path, filename = payload.rsplit(":", 1)
                file_path = file_path.strip()
                filename = filename.strip()
                if not file_path or not filename:
                    logger.warning("Incomplete generated file marker payload: %s", payload)
                    continue

                is_valid_path, path_reason, normalized_path, _size_bytes = validate_generated_file_path(
                    file_path,
                    require_exists=True,
                    require_non_empty=True,
                )
                file_path = normalized_path
                ext = os.path.splitext(filename)[1].lower()
                mime_type = _MIME_MAP.get(ext, "application/octet-stream")
                artifact_key = (file_path, filename)

                if not is_valid_path:
                    logger.warning(
                        "generated_file_registration_rejected",
                        extra={
                            "reason": path_reason,
                            "filename": filename,
                            "file_path": file_path,
                            "cwd": os.getcwd(),
                            "app_uploads_dir": os.getenv("APP_UPLOADS_DIR"),
                            "chat_session_id": chat_session_id,
                            "application_id": application_id,
                        },
                    )
                    replacement = (
                        f"Your file **{filename}** was generated, but is not available for download."
                    )
                    result_text = result_text.replace(match.group(0), replacement, 1)
                    continue

                if artifact_key in registered_artifacts:
                    download_url = registered_artifacts[artifact_key]
                    replacement = (
                        f"Your file **{filename}** is ready. "
                        f"[Click here to download]({download_url})"
                    )
                    logger.info(
                        "Skipped duplicate generated file marker for '%s' (path=%s)",
                        filename,
                        file_path,
                    )
                    result_text = result_text.replace(match.group(0), replacement, 1)
                    continue

                try:
                    record = await _gen_file_repo.register(
                        db,
                        chat_session_id=chat_session_id,
                        application_id=application_id,
                        original_filename=filename,
                        file_path=file_path,
                        mime_type=mime_type,
                    )
                    download_url = f"{base_url}/{record.download_key}"
                    registered_artifacts[artifact_key] = download_url
                    replacement = (
                        f"Your file **{filename}** is ready. "
                        f"[Click here to download]({download_url})"
                    )
                    logger.info(
                        "Registered generated file '%s' with key=%s",
                        filename, record.download_key,
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to register generated file '%s': %s",
                        filename, exc,
                    )
                    replacement = f"Your file **{filename}** was generated."

                result_text = result_text.replace(match.group(0), replacement, 1)

            # Commit the new records now that all markers in this output are processed
            try:
                await db.commit()
            except Exception as exc:
                logger.warning("Could not commit generated file records: %s", exc)
                await db.rollback()

            # Strip any LLM-fabricated sandbox: markdown links that slipped through.
            # These are hallucinated URLs (e.g. [Download](sandbox:/app/uploads/...))
            # that the frontend cannot resolve. Remove them since the real download
            # link was already injected above from the [GENERATED_FILE:...] marker.
            result_text = _SANDBOX_LINK_RE.sub(
                lambda m: m.group(1) if m.group(1) else "",
                result_text,
            )

            return result_text

        # Build a new result dict with markers replaced (immutable pattern)
        new_results = {}
        for key, value in execution_result.get("results", {}).items():
            if isinstance(value, str):
                new_results[key] = await _replace_markers(value)
            else:
                new_results[key] = value

        new_final_output = execution_result.get("final_output", "")
        if isinstance(new_final_output, str):
            new_final_output = await _replace_markers(new_final_output)

        return {
            **execution_result,
            "results": new_results,
            "final_output": new_final_output,
        }

    # ------------------------------------------------------------------
    # Single-step execution dispatcher
    # ------------------------------------------------------------------

    @staticmethod
    def _context_mode() -> str:
        """
        How retrieved context reaches a skill: ``capability`` or ``inline``.

        ``capability`` (the default) hands the agent tools and lets it fetch
        what it needs. ``inline`` is the pre-Phase-B behaviour — every source
        concatenated onto the front of the step input — kept as a per-deployment
        rollback, not as a supported mode.
        """
        mode = (os.getenv("APP_CONTEXT_MODE") or "capability").strip().lower()
        return mode if mode in ("capability", "inline") else "capability"

    def _inject_context(self, step_input: str) -> str:
        """
        Prepend the context blocks a skill cannot reach any other way.

        WHAT: Appends document / knowledge / MCP / database context to the step
              input, subject to the mode above.
        WHY:  ``app-plan.md`` Causes 2b and 2c. Two separate defects are fixed
              here. The database block was computed every turn, given to the
              planner, and then never passed to the executor — so an agent
              could not see a linked database at all. And every other block was
              pasted whole, up to roughly 200,000 characters per step, which
              truncates long documents and spends the model's attention before
              it knows what it needs.

        In ``capability`` mode a source is pasted **only when the agent has no
        tool for it**: the application's connectors, knowledge bases and session
        documents are now bound as tools by the factory, so re-pasting their
        content would both duplicate it and undo the change. Anything the
        application could not turn into a capability still arrives as text,
        because arriving truncated is better than not arriving.

        This decision is necessarily made *before* the agent is built, so it
        rests on the contribution predicting what the build will bind. That
        prediction is sound for one specific reason: the contribution lists only
        sources the ledger resolved, and since the resource-principal change the
        agent re-resolves each of them under the *same* identity the ledger used
        (the application's owner, carried on the entry as ``owner_user_id``).
        Before that, the two halves used different identities and could disagree
        — the text was suppressed on the strength of a tool the agent then
        failed to build, and the turn ran with neither. ``_reconcile_grounding``
        checks the two after the fact so any residual divergence is loud rather
        than silent.

        The document *manifest* is the exception and is never suppressed. It is
        a short list of filenames carrying no document content, and it is what
        tells the agent which files exist to search for in the first place —
        suppressing it alongside the excerpts left an agent holding a search
        tool with nothing to tell it what was worth searching for.
        """
        mode = self._context_mode()
        contribution = getattr(self, "_application_context", None) or {}

        bound_knowledge = bool(contribution.get("knowledge_sources"))
        bound_connectors = {
            str(entry.get("kind") or "")
            for entry in (contribution.get("connectors") or [])
        }
        bound_documents = bool(contribution.get("session_documents"))

        document_context = getattr(self, "_document_context", None)
        document_payload = document_context
        document_reachable = bound_documents
        if mode == "capability" and bound_documents and document_context:
            # Keep the manifest, drop the excerpts: the agent retrieves those
            # itself, and far more precisely, once it knows what to look for.
            # What remains carries no document content, so it is always inlined.
            document_payload = _manifest_only(document_context)
            document_reachable = False

        blocks = (
            ("UPLOADED DOCUMENT CONTEXT",
             document_payload,
             document_reachable),
            ("KNOWLEDGE BASE CONTEXT",
             getattr(self, "_knowledge_context", None),
             bound_knowledge),
            ("MCP DATA SOURCE CONTEXT",
             getattr(self, "_mcp_data_source_context", None),
             "mcp" in bound_connectors),
            ("DATABASE SCHEMA CONTEXT",
             getattr(self, "_db_data_source_context", None),
             "database" in bound_connectors),
        )

        for label, content, reachable_as_tool in blocks:
            if not content:
                continue
            if mode == "capability" and reachable_as_tool:
                logger.debug(
                    "%s not inlined: the agent can reach it as a tool", label
                )
                continue
            step_input = f"{step_input}\n\n{label}:\n{content}"

        # Always included, in either mode: these are short, they name what the
        # skill is expected to work with, and they are what the gate verified
        # before allowing the run to start.
        for note in getattr(self, "_evidence_notes", []) or []:
            if note:
                step_input = f"{step_input}\n\n{note}"

        return step_input

    async def _execute_step(
        self,
        db: AsyncSession,
        step: Dict[str, Any],
        step_input: str,
        previous_results: Dict[str, str],
    ) -> tuple:
        """
        Execute a single step from the plan.

        Returns:
            Tuple of (result_text_or_hitl_dict, log_entry: dict)

            When a workflow step contains HITL nodes and the workflow
            pauses at an interrupt, result_text_or_hitl_dict will be a
            dict with ``hitl_interrupted == True`` instead of a plain
            string.  Callers (execute_plan strategies) must check for
            this and propagate the interrupt upward.
        """
        skill_type = step.get("skill_type", "workflow")
        skill_id = step.get("skill_id", "")
        skill_name = step.get("skill_name", skill_id)
        step_num = step.get("step", 0)

        step_input = self._inject_context(step_input)

        # Inject conversation history into step input if available
        conversation_history = getattr(self, "_conversation_history", None)
        if conversation_history:
            history_lines = []
            for msg in conversation_history[-4:]:
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
                if len(content) > 200:
                    content = content[:200] + "..."
                history_lines.append(f"[{role}]: {content}")
            history_text = "\n".join(history_lines)
            step_input = f"{step_input}\n\nCONVERSATION HISTORY:\n{history_text}"

        start_time = time.monotonic()
        result_text: Any = ""
        status = "completed"
        error_msg = None

        try:
            if skill_type == "workflow":
                # HITL-aware path: check for HITL nodes first
                hitl_result = await self._execute_workflow_hitl_aware(
                    db, skill_id, step_input
                )
                if isinstance(hitl_result, dict) and hitl_result.get("hitl_interrupted"):
                    # Workflow paused at HITL node -- propagate upward
                    duration_ms = int((time.monotonic() - start_time) * 1000)
                    log_entry = {
                        "step": step_num,
                        "skill_id": skill_id,
                        "skill_type": skill_type,
                        "skill_name": skill_name,
                        "status": "interrupted",
                        "duration_ms": duration_ms,
                        "error": None,
                    }
                    return hitl_result, log_entry
                # Normal completion -- hitl_result is a plain string
                result_text = hitl_result
            elif skill_type == "agent":
                result_text = await self._execute_agent(
                    db, skill_id, step_input, previous_results, skill_name, step_num
                )
            else:
                raise ValueError(f"Unknown skill_type: {skill_type}")

        except Exception as exc:
            status = "failed"
            error_msg = str(exc)
            result_text = f"[Skill execution failed: {error_msg}]"
            logger.exception(
                "Step %s (%s: %s) failed", step_num, skill_type, skill_name
            )

        duration_ms = int((time.monotonic() - start_time) * 1000)

        log_entry = {
            "step": step_num,
            "skill_id": skill_id,
            "skill_type": skill_type,
            "skill_name": skill_name,
            "status": status,
            "duration_ms": duration_ms,
            "error": error_msg,
        }

        return result_text, log_entry

    # ------------------------------------------------------------------
    # Workflow execution (black box via WorkflowExecutor)
    # ------------------------------------------------------------------

    def _with_application_context(
        self, wf_def: Optional[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """
        Lend the application's datasources to every agent in a workflow.

        WHAT: Returns a copy of the workflow definition whose ``execution``
              block also carries this turn's application contribution.
        WHY:  ``execution`` becomes the graph's ``_aura_exec`` state key, which
              every agent node reads as its ``exec_context`` and hands to
              ``AgentFactory.build_with_context``. It is therefore the one
              channel that reaches every node of the graph — including parallel
              branches, which is why this is state rather than a context
              variable — with no change to the workflow engine.
        OUTPUT: A **copy**. The definition is loaded from the database and is
                shared; writing the contribution into it would leak one
                application's sources into the next run of the same workflow.
        """
        contribution = getattr(self, "_application_context", None)
        if not wf_def or not contribution:
            return wf_def

        updated = dict(wf_def)
        execution = dict(updated.get("execution") or {})
        execution["application_context"] = contribution
        updated["execution"] = execution
        return updated

    def _register_run_context(self, workflow_id: str) -> None:
        """
        Register this turn's run with the workflow transparency tracker.

        WHAT: Creates the ``StepTracker`` run context for the ``run_id`` this
              executor is about to hand the workflow engine.
        WHY:  The application injects its own ``run_id`` into the workflow's
              input payload so transparency events route back to the A2UI
              stream, but nothing ever *registered* that id --
              ``step_tracker.create_run`` was called from exactly one place, the
              designer chat route. So every workflow run inside an application
              took ``StepTracker.start_step``'s "backward compatibility" branch,
              logged ``Run <id> not found, creating new context`` on its first
              step, and recorded every ``execution_steps`` row against
              ``workflow_id="unknown"``.
        INPUT: The best-known identifier for the workflow about to run.
        OUTPUT: None. Never raises -- transparency is observability, and a run
                must not fail because its bookkeeping could not start.

        Idempotent: a context that already exists is left alone, so the designer
        path (which registers its own) is unaffected if it ever routes through
        here.
        """
        run_id = getattr(self, "_run_id", None)
        if not run_id:
            return

        try:
            from echolib.config import settings

            if not settings.transparency_enabled:
                return

            from apps.workflow.runtime.transparency import step_tracker

            if step_tracker.get_run(run_id) is None:
                step_tracker.create_run(run_id, str(workflow_id or "unknown"))
        except Exception:
            logger.debug(
                "Could not register transparency run context for %s", run_id,
                exc_info=True,
            )

    async def _execute_workflow(
        self, db: AsyncSession, workflow_id: str, user_input: str
    ) -> str:
        """
        Execute a workflow by resolving WorkflowExecutor from DI.

        DB-first: loads the workflow definition from the database and passes
        it directly to execute_from_definition(), avoiding filesystem reads.
        Falls back to the original filesystem-based execute_workflow() if
        the DB definition is not available.

        WorkflowExecutor methods are synchronous (LangGraph invoke), so
        we wrap them in asyncio.to_thread().
        """
        executor = self._resolve_workflow_executor()

        input_payload = {
            "user_input": user_input,
            "message": user_input,
        }

        # Inject user_id so workflow agents resolve per-user LLM credentials
        if self._user_id:
            input_payload["user_id"] = self._user_id

        # Inject run_id so workflow transparency events route to the
        # correct ws_manager queue subscriber for A2UI SSE streaming.
        _run_id = getattr(self, "_run_id", None)
        if _run_id:
            input_payload["run_id"] = _run_id

        # DB-first: try to load definition directly from DB
        wf_def = await self._load_workflow_def_from_db(db, workflow_id)
        # Registered against the definition's own id where there is one, so the
        # run records the same identifier the designer path would record.
        self._register_run_context(
            (wf_def or {}).get("workflow_id") or workflow_id
        )
        wf_def = self._with_application_context(wf_def)

        # ✅ PHASE B: Apply type validation to input_payload if state_schema defined
        # This ensures defensive type coercion for multi-agent workflows
        if wf_def and wf_def.get("state_schema"):
            state_schema = wf_def.get("state_schema", {})
            try:
                # Validate and coerce user_input variables according to state schema
                coerced_payload = TypeResolver.coerce_variables(input_payload, state_schema)
                logger.debug(
                    "Type validation applied to workflow input",
                    extra={"workflow_id": workflow_id, "validation": "success"}
                )
                input_payload.update(coerced_payload)
            except Exception as e:
                # Graceful fallback: log warning but allow execution to continue
                logger.warning(
                    f"Type validation failed for workflow '{workflow_id}', using raw input",
                    extra={"workflow_id": workflow_id, "error": str(e)}
                )
                # Continue with original input_payload (backward compat)

        if wf_def:
            # Use the new definition-based execution (no filesystem read)
            result = await asyncio.to_thread(
                executor.execute_from_definition,
                wf_def,
                "draft",
                input_payload,
            )
        else:
            # Fallback: resolve filesystem ID and use original method.
            #
            # This path CANNOT carry the application's datasources. The
            # contribution rides on ``wf_def["execution"]``, and there is no
            # definition here to attach it to -- so every agent in the workflow
            # runs with no connectors, no knowledge bases and no access to the
            # documents uploaded into this chat. That produced agents built with
            # ``connector_tools=0 context_tools=0 session_doc_tools=0`` which
            # then correctly reported that they could not read the uploaded file
            # and declined to produce a report, with nothing anywhere saying
            # why. It is logged loudly rather than silently degraded.
            contribution = getattr(self, "_application_context", None)
            if contribution:
                logger.warning(
                    "Workflow %s is running without the application's "
                    "datasources: its definition could not be loaded from the "
                    "database, and the fallback execution path cannot carry "
                    "them. %d connector(s), %d knowledge base(s) and %d session "
                    "document(s) will be unreachable to every agent in this "
                    "run, which may cause them to report missing inputs.",
                    workflow_id,
                    len(contribution.get("connectors") or []),
                    len(contribution.get("knowledge_sources") or []),
                    len(contribution.get("session_documents") or []),
                )

            fs_workflow_id = await self._resolve_fs_workflow_id(db, workflow_id)
            result = await asyncio.to_thread(
                executor.execute_workflow,
                fs_workflow_id,
                "draft",
                None,
                input_payload,
            )

        if result.get("status") == "failed":
            raise RuntimeError(
                f"Workflow execution failed: {result.get('error', 'unknown')}"
            )

        # Extract output text
        return self._extract_output_text(result.get("output", {}))

    # ------------------------------------------------------------------
    # HITL-aware workflow execution (additive — does NOT modify
    # _execute_workflow or any other existing method)
    # ------------------------------------------------------------------

    async def _execute_workflow_hitl_aware(
        self, db: AsyncSession, workflow_id: str, user_input: str
    ) -> Any:
        """
        Execute a workflow with HITL awareness.

        DB-first: loads the workflow definition from the database for both
        HITL detection and execution, avoiding redundant filesystem reads.

        Checks whether the workflow definition contains any HITL nodes.
        If yes, calls ``execute_hitl_from_definition()`` which can return
        an interrupt.  If no HITL nodes are present, delegates to
        ``_execute_workflow()`` unchanged.

        Returns:
            str  -- normal output text (no HITL, or HITL workflow that
                    completed without interrupting).
            dict -- ``{"hitl_interrupted": True, ...}`` when the workflow
                    paused at a HITL node.
        """
        # Load definition from DB once for both HITL detection and execution
        wf_def = await self._load_workflow_def_from_db(db, workflow_id)
        wf_def = self._with_application_context(wf_def)

        # Check for HITL nodes in the definition
        has_hitl = False
        if wf_def:
            # With the application's context attached, a Start node's file
            # upload is satisfied by the conversation's uploads and never
            # pauses (``compiler._create_start_node``); the Evidence Gate has
            # already refused the turn when there were none. Only a genuine
            # HITL node needs the interrupt-aware path then.
            in_application = bool(
                ((wf_def.get("execution") or {}).get("application_context"))
            )
            for agent in wf_def.get("agents", []):
                if isinstance(agent, dict):
                    metadata = agent.get("metadata", {})
                    if isinstance(metadata, dict) and metadata.get("node_type") == "HITL":
                        has_hitl = True
                        break
                    # Start node with file upload also uses interrupt()
                    if (
                        not in_application
                        and isinstance(metadata, dict)
                        and metadata.get("node_type") == "Start"
                        and metadata.get("file_upload_config", {}).get("enabled")
                    ):
                        has_hitl = True
                        break
        else:
            # No DB definition -- fall back to original DB query for HITL check
            has_hitl = await self._workflow_has_hitl_nodes(db, workflow_id)

        if not has_hitl:
            # No HITL nodes -- delegate to existing method unchanged
            return await self._execute_workflow(db, workflow_id, user_input)

        # --- HITL-aware path ---
        executor = self._resolve_workflow_executor()

        input_payload = {
            "user_input": user_input,
            "message": user_input,
        }

        # Inject user_id so workflow agents resolve per-user LLM credentials
        if self._user_id:
            input_payload["user_id"] = self._user_id

        # Inject run_id so workflow transparency events route to the
        # correct ws_manager queue subscriber for A2UI SSE streaming.
        _run_id = getattr(self, "_run_id", None)
        if _run_id:
            input_payload["run_id"] = _run_id

        self._register_run_context(
            (wf_def or {}).get("workflow_id") or workflow_id
        )

        if wf_def:
            # DB-first: use definition-based HITL execution
            result = await asyncio.to_thread(
                executor.execute_hitl_from_definition,
                wf_def,
                "draft",
                input_payload,
            )
            fs_workflow_id = wf_def.get("workflow_id", workflow_id)
        else:
            # Fallback: resolve filesystem ID and use original method
            fs_workflow_id = await self._resolve_fs_workflow_id(db, workflow_id)
            result = await asyncio.to_thread(
                executor.execute_workflow_hitl,
                fs_workflow_id,
                "draft",
                None,
                input_payload,
            )

        if result.get("status") == "failed":
            raise RuntimeError(
                f"Workflow execution failed: {result.get('error', 'unknown')}"
            )

        if result.get("status") == "interrupted":
            # Workflow paused at a HITL node
            logger.info(
                "Workflow %s interrupted at HITL node (run_id=%s)",
                workflow_id, result.get("run_id"),
            )
            return {
                "hitl_interrupted": True,
                "run_id": result.get("run_id", ""),
                "workflow_id": workflow_id,
                "fs_workflow_id": fs_workflow_id,
                "interrupt": result.get("interrupt", {}),
                "partial_output": result.get("output", {}),
            }

        # Completed normally -- extract text output
        return self._extract_output_text(result.get("output", {}))

    async def _workflow_has_hitl_nodes(
        self, db: AsyncSession, workflow_id: str
    ) -> bool:
        """
        Check whether a workflow definition contains any HITL nodes.

        Loads the workflow ``definition`` JSONB from the database and
        inspects each agent entry for ``metadata.node_type == "HITL"``.

        Args:
            db: Async database session.
            workflow_id: DB UUID or filesystem ID of the workflow.

        Returns:
            True if at least one HITL node is present.
        """
        from echolib.models.workflow import Workflow
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        wf_uuid = safe_uuid(workflow_id)
        if wf_uuid is None:
            # Not a valid UUID — cannot query DB
            return False

        stmt = select(Workflow.definition).where(
            Workflow.workflow_id == wf_uuid
        )
        row = await db.execute(stmt)
        definition = row.scalar_one_or_none()

        if not definition or not isinstance(definition, dict):
            return False

        for agent in definition.get("agents", []):
            if isinstance(agent, dict):
                metadata = agent.get("metadata", {})
                if isinstance(metadata, dict) and metadata.get("node_type") == "HITL":
                    return True

        return False

    @staticmethod
    def _strip_internal_blocks(text: str) -> str:
        """
        Remove intermediate ``INTERNAL`` prefixed blocks and standalone
        JSON blobs from output text.

        Multi-task agent runs produce intermediate outputs prefixed with
        ``INTERNAL`` (e.g., extraction results, risk assessments) that are
        meant for inter-agent communication, not end-user display.  Only
        the final user-facing output (executive summary, report, etc.)
        should be shown.

        Strategy:
          1. Use regex to remove ``INTERNAL``-prefixed sections that may
             span multiple lines (including multi-line JSON bodies).
          2. Remove standalone top-level JSON objects (``{ ... }``) that
             appear between or alongside INTERNAL blocks — these are
             typically unprefixed intermediate outputs.
          3. Clean up leftover separator lines (``---``).
          4. If nothing user-facing remains, return the last INTERNAL
             block with the prefix stripped.

        Args:
            text: Raw output text potentially containing INTERNAL blocks.

        Returns:
            Cleaned text with only user-facing content.
        """
        if not text or "INTERNAL" not in text:
            return text

        import re

        # Phase 1: Remove INTERNAL-prefixed sections.
        # Each section starts with "INTERNAL" or "__INTERNAL__" (at line
        # start or after whitespace) and extends until the next INTERNAL
        # marker, a separator line (---), or the end of the string.
        cleaned = re.sub(
            r'(?:^|\n)_*INTERNAL_*.*?(?=\n_*INTERNAL_*|\n-{3,}\s*\n|\Z)',
            '',
            text,
            flags=re.DOTALL,
        )

        # Phase 2: Remove standalone top-level JSON objects that sit
        # on their own (i.e. preceded and followed by blank lines or
        # string boundaries).  These are intermediate outputs
        # that were not prefixed with INTERNAL by the LLM.
        cleaned = re.sub(
            r'(?:^|\n\s*\n)\s*\{[\s\S]*?\}\s*(?=\n\s*\n|\Z)',
            '',
            cleaned,
            flags=re.DOTALL,
        )

        # Phase 3: Remove leftover separator lines (---).
        cleaned = re.sub(r'\n-{3,}\s*\n', '\n\n', cleaned)
        # Collapse excessive blank lines.
        cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
        cleaned = cleaned.strip()

        if cleaned:
            return cleaned

        # Edge case: everything was removed — return the last INTERNAL
        # block with the prefix stripped so there is *some* output.
        last_match = None
        for m in re.finditer(
            r'_*INTERNAL_*\s*(.*?)(?=\n_*INTERNAL_*|\Z)', text, re.DOTALL
        ):
            last_match = m
        if last_match:
            return last_match.group(1).strip()

        return text

    @staticmethod
    def _extract_output_text(output: Any) -> str:
        """
        Extract human-readable text from a workflow output dict.

        Mirrors the extraction logic in ``_execute_workflow()`` so that
        HITL-aware completions produce identical output formatting.

        Applies INTERNAL block filtering to remove intermediate task
        outputs that are not meant for end-user display, then formats
        any remaining raw JSON into clean markdown via the response
        formatter module.

        Args:
            output: Raw workflow output (dict or other).

        Returns:
            Clean, formatted text string suitable for UI display.
        """
        import re
        from apps.workflow.runtime.response_formatter import format_output_for_ui

        if not isinstance(output, dict):
            text = SkillExecutor._strip_internal_blocks(str(output).strip())
            return format_output_for_ui(text)

        output_text = (
            output.get("crew_result")
            or output.get("result")
            or output.get("parallel_output")
            or output.get("hierarchical_output")
            or output.get("merged_output")
        )
        if not output_text:
            for v in output.values():
                if isinstance(v, str) and len(v) > 10:
                    output_text = v
                    break
            if not output_text:
                output_text = str(output)

        output_text = output_text.replace("\\n", "\n")
        output_text = re.sub(r"^String\s*\n", "", output_text, count=1)
        output_text = re.sub(r"\n{3,}", "\n\n", output_text)
        output_text = output_text.strip()

        # Filter out INTERNAL prefixed blocks from intermediate outputs
        output_text = SkillExecutor._strip_internal_blocks(output_text)

        # Format any remaining raw JSON into clean markdown
        output_text = format_output_for_ui(output_text)

        return output_text

    @staticmethod
    async def _load_workflow_def_from_db(
        db: AsyncSession, workflow_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Load the workflow definition dict directly from the database.

        Tries two lookup strategies:
          1. Normalize workflow_id to UUID and query by primary key.
          2. Query by filesystem-prefixed ID stored in definition JSONB.

        Args:
            db: Async database session.
            workflow_id: DB UUID or filesystem ID of the workflow.

        Returns:
            Workflow definition dict if found, None otherwise.
        """
        from echolib.models.workflow import Workflow
        from echolib.repositories.base import safe_uuid
        from echolib.id_utils import normalize_to_uuid
        from sqlalchemy import select

        # Strategy 1: by UUID primary key
        try:
            uuid_id = normalize_to_uuid(workflow_id)
            wf_uuid = safe_uuid(uuid_id)
            if wf_uuid is not None:
                stmt = select(Workflow.definition).where(
                    Workflow.workflow_id == wf_uuid
                )
                row = await db.execute(stmt)
                definition = row.scalar_one_or_none()
                if definition and isinstance(definition, dict):
                    return definition
        except (ValueError, Exception):
            pass

        # Strategy 2: by fs_id in definition JSONB
        try:
            stmt = select(Workflow.definition).where(
                Workflow.definition["workflow_id"].astext == workflow_id
            )
            row = await db.execute(stmt)
            definition = row.scalar_one_or_none()
            if definition and isinstance(definition, dict):
                return definition
        except Exception:
            pass

        return None

    @staticmethod
    async def _resolve_fs_workflow_id(
        db: AsyncSession, db_workflow_id: str
    ) -> str:
        """
        Resolve the filesystem workflow_id (wf_...) from the database UUID.

        The skill manifest uses the DB UUID as skill_id, but the filesystem
        storage uses the internal wf_ prefixed ID from the workflow definition.
        """
        from echolib.models.workflow import Workflow
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        wf_uuid = safe_uuid(db_workflow_id)
        if wf_uuid is None:
            # Already a non-UUID id (e.g. wf_...), use as-is
            return db_workflow_id

        stmt = select(Workflow.definition).where(
            Workflow.workflow_id == wf_uuid
        )
        result = await db.execute(stmt)
        definition = result.scalar_one_or_none()

        if definition and isinstance(definition, dict):
            fs_id = definition.get("workflow_id")
            if fs_id and fs_id.startswith("wf_"):
                # Definition already stores the correct filesystem ID
                logger.info(
                    "Resolved DB workflow UUID %s -> filesystem ID %s",
                    db_workflow_id, fs_id,
                )
                return fs_id

        # Definition missing, or its workflow_id is a raw UUID (not wf_ prefixed).
        # Convert UUID to wf_ format: wf_ + uuid without hyphens
        fs_id = f"wf_{db_workflow_id.replace('-', '')}"
        logger.info(
            "Resolved DB workflow UUID %s -> filesystem ID %s (via conversion)",
            db_workflow_id, fs_id,
        )
        return fs_id

    @staticmethod
    def _resolve_workflow_executor():
        """
        Resolve WorkflowExecutor from the DI container.

        The workflow module registers it as 'workflow.executor'.
        """
        from echolib.di import container

        try:
            return container.resolve("workflow.executor")
        except KeyError:
            logger.error(
                "WorkflowExecutor not registered in DI container. "
                "Ensure the workflow module is initialized."
            )
            raise RuntimeError(
                "WorkflowExecutor not available. "
                "The workflow module may not be initialized."
            )

    # ------------------------------------------------------------------
    # Agent execution (standalone)
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_agent_runner():
        """
        Resolve StandaloneAgentRunner from the DI container.

        The agent module registers it as 'agent.standalone'. Mirrors
        ``_resolve_workflow_executor`` so both skill kinds fail the same way
        with the same kind of message.
        """
        from echolib.di import container

        try:
            return container.resolve("agent.standalone")
        except KeyError:
            logger.error(
                "StandaloneAgentRunner not registered in DI container. "
                "Ensure the agent module is initialized."
            )
            raise RuntimeError(
                "Agent execution not available. "
                "The agent module may not be initialized."
            )

    async def _execute_agent(
        self,
        db: AsyncSession,
        agent_id: str,
        user_input: str,
        previous_results: Dict[str, str],
        skill_name: str = "",
        step_num: int = 0,
    ) -> str:
        """
        Execute one agent through the single instantiation path.

        WHAT: Resolves ``agent.standalone`` and runs the agent, forwarding every
              event to the application's SSE queue as it happens.
        WHY:  Phase 9 removed the CrewAI executor this used to call. The agent now
              compiles through ``AgentFactory.build_with_context``, so it runs on
              its own configured credential and model, with its attached
              connectors, documents and knowledge bases, under the readiness gate
              — none of which the CrewAI path had.
        INPUT: Open session, agent id, this step's input, prior step outputs.
        OUTPUT: The agent's answer text.

        The live activity line and the token stream are emitted here rather than
        inside the runner: the runner is transport-agnostic by design, and A2UI
        is this application's presentation protocol, not the agent's.
        """
        context: Optional[Dict[str, Any]] = None
        if previous_results:
            # Pass the most recent result as context
            last_result = list(previous_results.values())[-1] if previous_results else ""
            context = {"previous_output": last_result}

        # The application's datasources travel on the execution context, which
        # the runner already threads into every tool call and which the factory
        # reads when it builds. Carried as data, never as a service handle, so a
        # checkpointed workflow can serialize the state that holds it.
        application_context = getattr(self, "_application_context", None)
        if application_context:
            context = dict(context or {})
            context["application_context"] = application_context
            # The agent's own readiness gate reads run state for a declared
            # file requirement. Surfacing this conversation's uploads here is
            # what lets it tell "no document" from "a document the agent did
            # not happen to have attached at configuration time".
            session_documents = application_context.get("session_documents")
            if session_documents:
                context["session_documents"] = [
                    str(d.get("name") or "")
                    for d in session_documents
                    if isinstance(d, dict) and d.get("name")
                ]

        runner = self._resolve_agent_runner()
        emitter = _AgentStreamEmitter(
            sse_queue=getattr(self, "_sse_queue", None),
            run_id=getattr(self, "_run_id", None),
            activity=getattr(self, "_activity", None),
            step_num=step_num,
            agent_name=skill_name or "agent",
        )

        try:
            result = await runner.run(
                db=db,
                agent_id=agent_id,
                user_input=user_input,
                context=context,
                app_id=getattr(self, "_app_id", None),
                user_id=getattr(self, "_user_id", None),
                tabular_files=getattr(self, "_tabular_files", None),
                chat_session_id=getattr(self, "_chat_session_id", None),
                run_id=getattr(self, "_run_id", None),
                on_event=emitter.on_event,
            )
        finally:
            await emitter.close()

        self._reconcile_grounding(agent_id, skill_name, result)

        return result.get("result", "")

    def _reconcile_grounding(
        self, agent_id: str, skill_name: str, result: Dict[str, Any]
    ) -> None:
        """
        Check that the agent got what the application predicted it would.

        WHAT: Compares the contribution this turn lent against what the build
              actually resolved, and reports any shortfall.
        WHY:  ``_inject_context`` suppresses pasted text whenever the
              contribution says a source will be bound as a tool. If the build
              then fails to bind it, the turn runs with neither the tool nor the
              text — and nothing anywhere says so. That is the failure mode that
              made this class of bug survive several fixes: every individual log
              line looked correct.
        OUTPUT: None. Observability only; never raises, never alters the answer.
        """
        try:
            contribution = getattr(self, "_application_context", None) or {}
            metadata = result.get("metadata") or {}

            expected_kb = len(contribution.get("knowledge_sources") or [])
            expected_conn = len(contribution.get("connectors") or [])
            if not expected_kb and not expected_conn:
                return

            context_meta = metadata.get("context") or {}
            connector_meta = metadata.get("connectors") or {}

            actual_kb = int(context_meta.get("knowledge_resolved") or 0)
            actual_conn = int(connector_meta.get("resolved") or 0)

            if actual_kb < expected_kb or actual_conn < expected_conn:
                logger.error(
                    "Grounding shortfall for agent '%s' (%s): the application "
                    "lent %d knowledge base(s) and %d connector(s), but the "
                    "build resolved %d and %d. Text for the unbound sources was "
                    "suppressed on the assumption they would be reachable, so "
                    "this answer is less grounded than it should be.",
                    skill_name or agent_id, agent_id,
                    expected_kb, expected_conn, actual_kb, actual_conn,
                )
        except Exception:  # noqa: BLE001 -- reporting must not break a turn
            logger.debug("Could not reconcile the grounding surface", exc_info=True)
