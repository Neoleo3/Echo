"""
EchoAI Orchestrator -- Skill Manifest Builder

Queries PostgreSQL to build a structured manifest of all skills
(workflows + agents) linked to an application.  The manifest is
included in the orchestrator LLM system prompt so it can decide
which skills to invoke.

Data Sources:
    - application_skill_links  (which skills are bound to this app)
    - workflows table          (definition JSONB for rich metadata)
    - agents table             (definition JSONB for rich metadata)

Caching:
    Simple in-memory dict per application_id with a TTL.
    Invalidated when the caller signals a setup change.
"""

import logging
import time
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.id_utils import normalize_to_uuid

logger = logging.getLogger(__name__)

# Default TTL for cached manifests (seconds)
_DEFAULT_CACHE_TTL = 300  # 5 minutes

# Workflow nodes that route a run without reading anything themselves. The
# upload check looks through them to the first agents a run actually reaches.
_ROUTING_NODE_TYPES = frozenset({"Conditional", "Loop", "HITL", "Map"})

# Nodes that end a path; nothing past them is an entry agent.
_TERMINAL_NODE_TYPES = frozenset({"Start", "End"})


class SkillManifestBuilder:
    """
    Builds a structured skill manifest from PostgreSQL for inclusion
    in the orchestrator's system prompt.
    """

    def __init__(self, cache_ttl: int = _DEFAULT_CACHE_TTL) -> None:
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._cache_timestamps: Dict[str, float] = {}
        self._cache_ttl = cache_ttl

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def build_manifest(
        self,
        db: AsyncSession,
        application_id: str,
    ) -> Dict[str, Any]:
        """
        Build (or return cached) skill manifest for an application.

        Args:
            db: Async database session.
            application_id: Application UUID string.

        Returns:
            Dict with key ``skills`` containing a list of skill metadata dicts.
        """
        # Check cache
        cached = self._get_cached(application_id)
        if cached is not None:
            return cached

        manifest = await self._build_from_db(db, application_id)
        self._set_cached(application_id, manifest)
        return manifest

    def invalidate(self, application_id: str) -> None:
        """
        Invalidate cached manifest for an application.

        Should be called whenever the application's skill links change
        (e.g. after a setup PATCH).
        """
        self._cache.pop(application_id, None)
        self._cache_timestamps.pop(application_id, None)

    def invalidate_all(self) -> None:
        """Clear entire manifest cache."""
        self._cache.clear()
        self._cache_timestamps.clear()

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _get_cached(self, application_id: str) -> Optional[Dict[str, Any]]:
        ts = self._cache_timestamps.get(application_id)
        if ts is None:
            return None
        if (time.monotonic() - ts) > self._cache_ttl:
            self.invalidate(application_id)
            return None
        return self._cache.get(application_id)

    def _set_cached(self, application_id: str, manifest: Dict[str, Any]) -> None:
        self._cache[application_id] = manifest
        self._cache_timestamps[application_id] = time.monotonic()

    # ------------------------------------------------------------------
    # Database query
    # ------------------------------------------------------------------

    async def _build_from_db(
        self,
        db: AsyncSession,
        application_id: str,
    ) -> Dict[str, Any]:
        """
        Query skill links and join with workflows/agents tables for
        rich metadata.

        Deduplication:
            Agents that are already embedded inside a linked workflow's
            definition are excluded from the standalone agent list.  This
            prevents the orchestrator LLM from seeing (and potentially
            invoking) the same agent twice -- once via the workflow and
            once as a standalone skill.
        """
        from echolib.models.application import ApplicationSkillLink
        from echolib.models.workflow import Workflow
        from echolib.models.agent import Agent
        from echolib.repositories.base import safe_uuid

        app_uuid = safe_uuid(application_id)
        if app_uuid is None:
            return {"skills": []}

        # Fetch skill links for this application
        stmt = select(ApplicationSkillLink).where(
            ApplicationSkillLink.application_id == app_uuid
        )
        result = await db.execute(stmt)
        links = list(result.scalars().all())

        if not links:
            return {"skills": []}

        # Partition links by type
        workflow_ids: List[str] = []
        agent_ids: List[str] = []
        link_map: Dict[str, ApplicationSkillLink] = {}

        for link in links:
            link_map[f"{link.skill_type}:{link.skill_id}"] = link
            if link.skill_type == "workflow":
                workflow_ids.append(link.skill_id)
            elif link.skill_type == "agent":
                agent_ids.append(link.skill_id)

        skills: List[Dict[str, Any]] = []

        # ----------------------------------------------------------
        # Phase 1: Fetch workflow metadata and collect embedded agents
        # ----------------------------------------------------------
        # Set of agent IDs that are already embedded inside at least
        # one linked workflow.  These will be excluded from the
        # standalone agent list to prevent double-execution.
        embedded_agent_ids: set = set()
        # (manifest entry, definition) per workflow, for the upload check that
        # needs the entry agents' live records -- read in one query below.
        workflow_entries: List[tuple] = []

        if workflow_ids:
            wf_uuids = [safe_uuid(wid) for wid in workflow_ids]
            wf_uuids = [u for u in wf_uuids if u is not None]
            if wf_uuids:
                wf_stmt = select(Workflow).where(
                    Workflow.workflow_id.in_(wf_uuids),
                    Workflow.is_deleted == False,  # noqa: E712
                )
                wf_result = await db.execute(wf_stmt)
                workflows = list(wf_result.scalars().all())

                for wf in workflows:
                    link_key = f"workflow:{str(wf.workflow_id)}"
                    link = link_map.get(link_key)
                    defn = wf.definition or {}
                    entry = self._build_workflow_entry(wf, defn, link)
                    skills.append(entry)
                    workflow_entries.append((entry, defn))

                    # Extract agent IDs embedded in this workflow
                    # Normalize to UUID format so dedup comparison works
                    # even when workflow definitions store IDs as prefixed
                    # strings (e.g. "agt_<hex>") while the DB uses UUIDs.
                    if isinstance(defn, dict):
                        for embedded_agent in defn.get("agents", []):
                            if isinstance(embedded_agent, dict):
                                aid = embedded_agent.get("agent_id")
                                if aid:
                                    try:
                                        normalized = normalize_to_uuid(str(aid))
                                        embedded_agent_ids.add(normalized)
                                    except ValueError:
                                        pass  # Skip invalid IDs (e.g., "agt_identity_map")

        if workflow_entries:
            await self._mark_upload_needs(db, workflow_entries)

        # ----------------------------------------------------------
        # Phase 2: Fetch agent metadata (excluding embedded agents)
        # ----------------------------------------------------------
        if agent_ids:
            agt_uuids = [safe_uuid(aid) for aid in agent_ids]
            agt_uuids = [u for u in agt_uuids if u is not None]
            if agt_uuids:
                agt_stmt = select(Agent).where(
                    Agent.agent_id.in_(agt_uuids),
                    Agent.is_deleted == False,  # noqa: E712
                )
                agt_result = await db.execute(agt_stmt)
                agents = list(agt_result.scalars().all())

                for agt in agents:
                    agent_id_str = str(agt.agent_id)
                    # Normalize for consistent comparison with embedded IDs
                    try:
                        normalized_agent_id = normalize_to_uuid(agent_id_str)
                    except ValueError:
                        normalized_agent_id = agent_id_str

                    # Skip agents already embedded in a linked workflow
                    if normalized_agent_id in embedded_agent_ids:
                        link_key = f"agent:{agent_id_str}"
                        link = link_map.get(link_key)
                        logger.info(
                            "Skipping agent '%s' (id=%s) from manifest -- "
                            "already embedded in a linked workflow",
                            link.skill_name if link else agt.name,
                            agent_id_str,
                        )
                        continue

                    link_key = f"agent:{agent_id_str}"
                    link = link_map.get(link_key)
                    defn = agt.definition or {}
                    skills.append(
                        self._build_agent_entry(agt, defn, link)
                    )

        # Log deduplication summary when agents were removed
        if embedded_agent_ids:
            linked_agent_id_strs = set()
            for aid in agent_ids:
                try:
                    linked_agent_id_strs.add(normalize_to_uuid(str(aid)))
                except ValueError:
                    linked_agent_id_strs.add(str(aid))
            excluded_count = len(embedded_agent_ids & linked_agent_id_strs)
            if excluded_count:
                logger.info(
                    "Agent deduplication: %d agent(s) embedded in workflows, "
                    "%d excluded from standalone manifest",
                    len(embedded_agent_ids),
                    excluded_count,
                )

        # Also add skills from links that had no matching DB record
        # (use denormalized data from the link itself).
        # Exclude agent links whose IDs are embedded in a workflow.
        existing_keys = {f"{s['skill_type']}:{s['skill_id']}" for s in skills}
        for key, link in link_map.items():
            if key not in existing_keys:
                # Skip fallback agent entries that are embedded in workflows
                # Normalize for consistent comparison with embedded IDs
                try:
                    normalized_link_id = normalize_to_uuid(str(link.skill_id))
                except ValueError:
                    normalized_link_id = str(link.skill_id)
                if (
                    link.skill_type == "agent"
                    and normalized_link_id in embedded_agent_ids
                ):
                    continue
                skills.append({
                    "skill_id": link.skill_id,
                    "skill_type": link.skill_type,
                    "name": link.skill_name or link.skill_id,
                    "description": link.skill_description or "",
                    "capabilities": [],
                })

        return {"skills": skills}

    # ------------------------------------------------------------------
    # Upload preconditions
    # ------------------------------------------------------------------

    @staticmethod
    async def _mark_upload_needs(
        db: AsyncSession, workflow_entries: List[tuple]
    ) -> None:
        """
        Mark each workflow that cannot run without a document uploaded in chat.

        WHAT: Sets ``needs_uploaded_document`` (and ``upload_accepts``) on a
              workflow's manifest entry when its Start node requires a file
              upload, or when an agent the Start node feeds reads files with
              the File Reader tool.
        WHY:  The Evidence Gate stops a run for a missing document only when
              something says the document is needed. That used to be the
              planner alone, and with knowledge bases attached it routinely
              declared nothing -- so a review workflow ran end to end on no
              submission and produced an irrelevant report. What a workflow
              consumes is already in its configuration: the Start node's upload
              toggle, and the tool its first agent opens the submission with.
        INPUT: ``(entry, definition)`` pairs; entries are updated in place,
               before the manifest is cached or returned.

        Entry agents are read from the ``agents`` table because a workflow now
        stores references rather than copies, and the record is what runs. The
        embedded copy is the fallback, exactly as at execution time. One query
        covers every linked workflow.
        """
        entry_ids: Dict[int, List[str]] = {}
        wanted: set = set()
        for index, (entry, defn) in enumerate(workflow_entries):
            if entry.get("expects_file_upload"):
                entry["needs_uploaded_document"] = True
                continue
            ids = SkillManifestBuilder._entry_agent_ids(defn)
            entry_ids[index] = ids
            for agent_id in ids:
                try:
                    wanted.add(normalize_to_uuid(agent_id))
                except ValueError:
                    continue

        records: Dict[str, Dict[str, Any]] = {}
        if wanted:
            from echolib.models.agent import Agent
            from echolib.repositories.base import safe_uuid

            uuids = [u for u in (safe_uuid(a) for a in wanted) if u is not None]
            try:
                rows = (
                    await db.execute(
                        select(Agent).where(
                            Agent.agent_id.in_(uuids),
                            Agent.is_deleted == False,  # noqa: E712
                        )
                    )
                ).scalars().all()
                records = {str(row.agent_id): row.definition or {} for row in rows}
            except Exception:
                # Never fail a manifest over this: without the records the
                # embedded copies still answer below.
                logger.warning(
                    "Entry agents could not be read for the upload check; "
                    "using the copies embedded in the workflows",
                    exc_info=True,
                )

        for index, ids in entry_ids.items():
            entry, defn = workflow_entries[index]
            embedded = {
                str(agent.get("agent_id") or ""): agent
                for agent in (defn.get("agents") or [])
                if isinstance(agent, dict)
            }
            for agent_id in ids:
                try:
                    record = records.get(normalize_to_uuid(agent_id))
                except ValueError:
                    record = None
                source = record if record is not None else embedded.get(agent_id, {})
                if SkillManifestBuilder._uses_file_reader(source.get("tools")):
                    entry["needs_uploaded_document"] = True
                    logger.debug(
                        "Workflow '%s' needs an uploaded document: its entry "
                        "agent %s reads files with File Reader",
                        entry.get("name"), agent_id,
                    )
                    break

    @staticmethod
    def _entry_agent_ids(defn: Dict[str, Any]) -> List[str]:
        """
        The first agents a run reaches from the Start node, in connection order.

        Read from the stored ``connections`` (agent ids on both ends). Routing
        nodes -- a Conditional, a Loop, a HITL review -- do no reading of their
        own, so the walk passes through them to the agents they lead to; an
        End node stops it. A workflow with no Start node or no connections
        yields nothing, and is simply not marked.
        """
        node_types: Dict[str, str] = {}
        for agent in defn.get("agents") or []:
            if not isinstance(agent, dict):
                continue
            metadata = agent.get("metadata")
            node_type = (
                str(metadata.get("node_type") or "")
                if isinstance(metadata, dict)
                else ""
            )
            node_types[str(agent.get("agent_id") or "")] = node_type
        node_types.pop("", None)

        start_ids = [aid for aid, kind in node_types.items() if kind == "Start"]
        if not start_ids:
            return []

        edges: Dict[str, List[str]] = {}
        for connection in defn.get("connections") or []:
            if not isinstance(connection, dict):
                continue
            source = str(connection.get("from") or "")
            target = str(connection.get("to") or "")
            if source and target:
                edges.setdefault(source, []).append(target)

        ids: List[str] = []
        visited = set(start_ids)
        frontier = list(start_ids)
        while frontier:
            current = frontier.pop(0)
            for target in edges.get(current, []):
                if target in visited:
                    continue
                visited.add(target)
                kind = node_types.get(target, "")
                if kind in _ROUTING_NODE_TYPES:
                    frontier.append(target)
                elif kind not in _TERMINAL_NODE_TYPES:
                    ids.append(target)
        return ids

    @staticmethod
    def _uses_file_reader(tools: Any) -> bool:
        """
        Whether a tool list includes the File Reader.

        Tools are stored as ids (``tool_file_reader``) on current records and
        as ``{"tool_id", "name"}`` dicts or display names on older ones; all
        three are recognised.
        """
        for tool in tools or []:
            if isinstance(tool, dict):
                ident = tool.get("tool_id") or tool.get("id") or tool.get("name") or ""
            else:
                ident = tool
            normalized = str(ident or "").strip().lower().replace(" ", "_")
            if "file_reader" in normalized:
                return True
        return False

    # ------------------------------------------------------------------
    # Entry builders
    # ------------------------------------------------------------------

    @staticmethod
    def _build_workflow_entry(
        wf, defn: Dict[str, Any], link
    ) -> Dict[str, Any]:
        """Build a skill manifest entry for a workflow."""
        name = defn.get("name") or wf.name
        description = defn.get("description", "")
        if link and link.skill_description:
            description = link.skill_description

        execution_model = defn.get("execution_model", "sequential")

        # Extract capabilities and agent metadata from embedded agents
        capabilities: List[str] = []
        agents_list = defn.get("agents", [])
        agent_count = len(agents_list)
        agent_names: List[str] = []
        for agent_def in agents_list:
            if isinstance(agent_def, dict):
                role = agent_def.get("role", "")
                if role:
                    capabilities.append(role)
                aname = agent_def.get("name", "")
                if aname:
                    agent_names.append(aname)

        inputs, expects_upload, reads_from = SkillManifestBuilder._derive_workflow_io(
            agents_list
        )
        upload_accepts = SkillManifestBuilder._start_upload_accepts(agents_list)

        return {
            "skill_id": str(wf.workflow_id),
            "skill_type": "workflow",
            "name": name,
            "description": description,
            "capabilities": capabilities,
            "execution_model": execution_model,
            "agent_count": agent_count,
            "agent_names": agent_names,
            # Derived, never authored. The planner has to know what a skill
            # consumes before it can work out what a request is missing.
            "inputs": inputs,
            "expects_file_upload": expects_upload,
            "reads_from": reads_from,
            # Whether a run needs a document uploaded in this conversation.
            # Starts as the Start node's upload toggle; ``_mark_upload_needs``
            # also sets it when the entry agent reads files with File Reader.
            "needs_uploaded_document": expects_upload,
            "upload_accepts": upload_accepts,
        }

    @staticmethod
    def _start_upload_accepts(agents_list: List[Any]) -> List[str]:
        """File types the Start node's upload accepts, without dots, if stated."""
        for node in agents_list:
            if not isinstance(node, dict):
                continue
            metadata = node.get("metadata") or {}
            if not isinstance(metadata, dict) or metadata.get("node_type") != "Start":
                continue
            upload = metadata.get("file_upload_config")
            if not isinstance(upload, dict) or not upload.get("enabled"):
                return []
            types = upload.get("acceptedTypes") or []
            return [
                str(t).strip().lstrip(".").lower()
                for t in types
                if str(t).strip().lstrip(".")
            ]
        return []

    @staticmethod
    def _derive_workflow_io(agents_list: List[Any]) -> tuple:
        """
        Work out what a workflow takes in, from configuration that already exists.

        WHAT: Returns ``(inputs, expects_file_upload, reads_from)``.
        WHY:  Copilot Studio's orchestrator plans from the name, description,
              **inputs** and outputs of each capability; ours offered no inputs
              at all, so the model was asked what a request needs while being
              told nothing about what the chosen skill consumes.

        Three sources, all already in the workflow definition:

        - the Start node's ``input_schema`` — the canvas ``inputVariables``
          (``compiler.py:2561``);
        - the Start node's ``metadata.file_upload_config.enabled``, which is a
          hard precondition: the graph interrupts and waits
          (``node_mapper.py:495-497``);
        - what the member agents can reach — their connectors, documents and
          knowledge bases.

        Nothing is authored and nothing is guessed. A workflow that declares
        none of this yields empty lists, and the planner simply learns less
        about it.
        """
        inputs: List[str] = []
        reads_from: List[str] = []
        expects_upload = False

        for node in agents_list:
            if not isinstance(node, dict):
                continue

            metadata = node.get("metadata") or {}
            node_type = metadata.get("node_type") if isinstance(metadata, dict) else ""

            if node_type == "Start":
                for entry in node.get("input_schema") or []:
                    label = (
                        entry.get("name") or entry.get("label")
                        if isinstance(entry, dict)
                        else str(entry)
                    )
                    if label and label not in inputs:
                        inputs.append(str(label))

                upload = (
                    metadata.get("file_upload_config")
                    if isinstance(metadata, dict)
                    else None
                )
                if isinstance(upload, dict) and upload.get("enabled"):
                    expects_upload = True

            for source in SkillManifestBuilder._agent_sources(node):
                if source not in reads_from:
                    reads_from.append(source)

        return inputs, expects_upload, reads_from

    @staticmethod
    def _agent_sources(defn: Dict[str, Any]) -> List[str]:
        """
        Name the kinds of source an agent can reach.

        Kinds rather than identifiers: the planner needs to know a skill can
        reach a database, not which database. Naming the instance would put
        configuration detail into a prompt that exists to make a routing
        decision.

        **Read through the contract, not off the raw definition.** These keys
        are gated: ``attached_connectors`` / ``attached_files`` /
        ``attached_knowledge_sources`` return nothing while the agent's
        Connector Settings toggle is off, and exclude individually disabled
        entries. Reading the keys directly advertised capability the runtime
        would then refuse to hand over — the planner routed a question to an
        agent because it "reads from a knowledge base", and the agent answered
        that it had no knowledge. The manifest and the build now answer the same
        question the same way.
        """
        from echolib.agent_contract import (
            attached_connectors,
            attached_files,
            attached_knowledge_sources,
        )

        sources: List[str] = []

        for entry in attached_connectors(defn):
            kind = str(entry.get("kind") or "").strip().lower()
            label = {
                "database": "a database",
                "api": "an API",
                "mcp": "an MCP server",
            }.get(kind)
            if label and label not in sources:
                sources.append(label)

        if attached_files(defn) and "attached documents" not in sources:
            sources.append("attached documents")

        if attached_knowledge_sources(defn) and "a knowledge base" not in sources:
            sources.append("a knowledge base")

        return sources

    @staticmethod
    def _build_agent_entry(
        agt, defn: Dict[str, Any], link
    ) -> Dict[str, Any]:
        """Build a skill manifest entry for an agent."""
        name = defn.get("name") or agt.name
        description = defn.get("description", "")
        if link and link.skill_description:
            description = link.skill_description

        role = defn.get("role", "")
        goal = defn.get("goal", "")
        tools_list = defn.get("tools", [])
        tool_names = []
        for t in tools_list:
            if isinstance(t, str):
                tool_names.append(t)
            elif isinstance(t, dict):
                tool_names.append(t.get("name", str(t)))

        # Build capabilities from role and goal
        capabilities: List[str] = []
        if role:
            capabilities.append(role)
        if goal and goal != role:
            capabilities.append(goal)

        # What this agent declares it must be given, and what it can reach.
        # ``required_inputs`` has been generated since Plan_1 Phase 4 and
        # persisted since Phase 1; nothing has ever read it at planning time.
        inputs: List[str] = []
        for entry in defn.get("required_inputs") or []:
            if isinstance(entry, dict):
                label = entry.get("label") or entry.get("type")
                if label and str(label) not in inputs:
                    inputs.append(str(label))

        return {
            "skill_id": str(agt.agent_id),
            "skill_type": "agent",
            "name": name,
            "description": description,
            "capabilities": capabilities,
            "tools": tool_names,
            "inputs": inputs,
            "reads_from": SkillManifestBuilder._agent_sources(defn),
            "needs_uploaded_document": SkillManifestBuilder._agent_requires_upload(defn),
        }

    @staticmethod
    def _agent_requires_upload(defn: Dict[str, Any]) -> bool:
        """
        Whether a standalone agent cannot run without a document from chat.

        WHAT: True when the agent declares a blocking ``required_inputs`` entry
              of type ``file`` and carries no document of its own to satisfy it.
        WHY:  Deliberately *not* "the agent has File Reader". The agent designer
              attaches File Reader whenever a description mentions a report,
              data, content or analysis, so that signal would make ordinary
              agents demand an upload. A declared file input is the author's
              own statement, and it is the same one the readiness pre-check
              already enforces at run time -- here it is simply enforced before
              the run instead of during it.
        """
        from echolib.agent_contract import attached_files

        for entry in defn.get("required_inputs") or []:
            if not isinstance(entry, dict):
                continue
            if str(entry.get("type") or "").strip().lower() != "file":
                continue
            if entry.get("blocking", True) is False:
                continue
            return not attached_files(defn)
        return False