"""
EchoAI Orchestrator -- Orchestration Pipeline

The top-level coordinator that ties all orchestration steps together
for a single chat turn:

    1.  Load application from DB
    2.  Pre-guardrails check on raw user message
    3.  Build persona prompt
    4.  Enhance prompt
    5.  Build skill manifest
    6.  Get conversation history
    7.  Check HITL state (handle clarification flow)
    8.  Call orchestrator LLM for execution plan
    9.  Handle HITL response (clarify / fallback / execute)
    10. Execute skills
    11. Post-guardrails on output
    12. Save messages to DB
    13. Save execution trace
    14. Update session state back to awaiting_input
    15. Return response
"""

import asyncio
import copy
import json as _json
import logging
import os
import re as _re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

from sqlalchemy.ext.asyncio import AsyncSession

from .prompt_enhancer import PromptEnhancer
from .skill_manifest import SkillManifestBuilder
from .orchestrator import Orchestrator
from .guardrails import GuardrailsEngine
from .persona import PersonaFormatter
from .hitl import HITLManager
from .skill_executor import SkillExecutor

from echolib.app_llm import resolve_app_llm_selection
from apps.appmgr.context import available_evidence

from . import evidence_gate, missing_context
from . import slots as slot_tracker
from .planning import DECISION_ANSWER_DIRECTLY


def _sanitize_for_ui(text: str) -> str:
    """Last-mile sanitizer: strip INTERNAL blocks and format JSON for UI.

    Runs right before the response is saved to DB and returned to the
    frontend.  Performs two passes:

      1. Strip ``INTERNAL``-prefixed sections and ``__INTERNAL__`` blocks
         that contain inter-agent communication not meant for the user.
      2. Format any remaining raw JSON into clean, human-readable markdown
         via the dedicated response_formatter module.

    If stripping removes *everything*, returns the original text so the
    user always gets some output.

    Args:
        text: Raw output text from execution pipeline.

    Returns:
        Clean, formatted text suitable for UI display.
    """
    if not text or not isinstance(text, str):
        return text or ""

    # Step 1: Strip INTERNAL-prefixed sections.
    # These are intermediate outputs meant for inter-agent
    # communication, not end-user display.
    cleaned = text
    if "INTERNAL" in cleaned:
        cleaned = _re.sub(
            r'(?:^|\n)_*INTERNAL_*.*?(?=\n_*INTERNAL_*|\n-{3,}\s*\n|\Z)',
            '', cleaned, flags=_re.DOTALL,
        )
        cleaned = _re.sub(
            r'__INTERNAL__[\s\S]*?__END_INTERNAL__', '', cleaned
        )
        # Clean separators / blank lines
        cleaned = _re.sub(r'\n-{3,}\s*\n', '\n\n', cleaned)
        cleaned = _re.sub(r'\n{3,}', '\n\n', cleaned)
        cleaned = cleaned.strip()

    # If stripping removed everything, fall back to original
    if not cleaned:
        cleaned = text

    # Step 2: Format any remaining raw JSON into clean markdown.
    from apps.workflow.runtime.response_formatter import format_output_for_ui
    cleaned = format_output_for_ui(cleaned)

    return cleaned

logger = logging.getLogger(__name__)


async def _build_merged_document_context(
    chat_repo: Any,
    db: AsyncSession,
    session_id: str,
    enhanced_prompt: str,
    *,
    user_id: Optional[str] = None,
    application_id: Optional[str] = None,
) -> Optional[str]:
    """
    Session document manifest + RAG excerpts so agents know source filenames
    and get more chunks for multi-operator / annual-report questions.

    ``user_id`` is not optional in practice, only in signature. Every embedding
    model on this platform is a user's own credential, so a retrieval without
    one cannot embed the query and returns nothing — indistinguishable, from
    the caller's side, from a document that simply did not match.
    """
    log = logging.getLogger(__name__)
    manifest = ""
    n_ready_docs = 0
    _IMAGE_MIMES = frozenset({
        "image/jpeg", "image/jpg", "image/png", "image/bmp",
        "image/tiff", "image/webp", "image/gif",
    })
    try:
        ready_docs = await chat_repo.get_session_documents(
            db, session_id, status="ready"
        )
        n_ready_docs = len(ready_docs or [])
        if ready_docs:
            text_names = []
            image_names = []
            for d in ready_docs:
                if (d.mime_type or "").lower() in _IMAGE_MIMES:
                    image_names.append(d.original_filename)
                else:
                    text_names.append(d.original_filename)

            all_names = text_names + image_names
            manifest = (
                "DOCUMENTS IN THIS SESSION — use only these sources for numeric facts:\n"
                + "\n".join(f"- {n}" for n in all_names)
            )
            if text_names:
                manifest += (
                    "\n\nDOCUMENT_ANALYSIS NOTE (receipts/expenses only): for uploaded PDF or DOCX receipts, "
                    "you may call document_analysis directly with file_name and mime_type. "
                    "For general document Q&A, keep using file_reader and retrieved excerpts."
                )
            if image_names:
                manifest += (
                    "\n\nIMAGE FILES (cannot be text-searched — use document_analysis "
                    "tool with file_name and mime_type to extract and analyze them):\n"
                    + "\n".join(f"- {n}" for n in image_names)
                )
    except Exception:
        log.debug("Document manifest skipped for session %s", session_id)

    document_context: Optional[str] = None
    try:
        from echolib.di import container as di_container

        rag_manager = di_container.resolve("rag.session_manager")
        has_docs = rag_manager.has_documents(
            session_id, application_id=application_id, user_id=user_id
        )
        # More chunks when several annual reports are uploaded (comparative analysis).
        if has_docs and n_ready_docs >= 2:
            top_k = 24
        elif has_docs:
            top_k = 18
        else:
            top_k = 10
        if has_docs:
            document_context = rag_manager.retrieve(
                session_id,
                enhanced_prompt,
                top_k=top_k,
                user_id=user_id,
                application_id=application_id,
            )
    except KeyError:
        log.debug("rag.session_manager not registered; skipping document retrieval")
    except Exception:
        log.exception("Document retrieval failed for session %s", session_id)

    if manifest:
        if document_context and str(document_context).strip():
            return (
                f"{manifest}\n\n--- RETRIEVED EXCERPTS ---\n\n{document_context}"
            )
        return manifest
    return document_context


@dataclass(frozen=True)
class TurnContext:
    """
    Everything one turn retrieved before planning, resolved in one place.

    WHY: ``run()`` and ``run_stream()`` are two hand-maintained copies of the
    same sequence, and the context-retrieval segment had already drifted
    between them — the database context reached the planner on both paths but
    the executor on neither. Returning one object from one helper is what stops
    the next change landing in only one of the two.
    """

    ledger: Any
    document_context: Optional[str] = None
    knowledge_context: Optional[str] = None
    mcp_context: Optional[str] = None
    db_context: Optional[str] = None
    tabular_files: Tuple[Dict[str, Any], ...] = ()
    # What the application lends every agent this turn — its reachable
    # connectors, knowledge bases and session documents — as JSON-able data
    # the agent factory turns into tools. ``None`` when it has nothing to lend.
    application_contribution: Optional[Dict[str, Any]] = None

    def as_tabular_list(self) -> List[Dict[str, Any]]:
        """A fresh mutable list — downstream callers expect to own it."""
        return [dict(entry) for entry in self.tabular_files]

    def retrieved_text(self) -> str:
        """
        Everything actually pulled from this application's sources this turn.

        WHAT: The knowledge-base passages and uploaded-document excerpts, joined
              under headings, or ``""`` when nothing was retrieved.
        WHY:  An ``answer_directly`` turn runs no skill, so the composer is the
              only thing that will see this. Without it the application could
              hold a linked knowledge base, retrieve the right passages, and
              still answer that it had no information — the text was fetched and
              then dropped on the floor between retrieval and the reply.

        Deliberately excludes the MCP and database blocks: those are schema and
        resource *descriptions* meant to inform routing, not source material to
        answer from, and pasting them into a composition prompt invites the model
        to narrate an application's configuration back at its user.
        """
        parts: List[str] = []
        if self.knowledge_context:
            parts.append(f"From the linked knowledge bases:\n{self.knowledge_context}")
        if self.document_context:
            parts.append(f"From documents in this conversation:\n{self.document_context}")
        return "\n\n".join(parts)


# Live token preview retained per sub-step, in characters.
#
# A preview, not the answer: the full result arrives on ``step_completed``.
# Bounded so a long generation cannot grow the steps array without limit --
# every ``step_update`` re-sends the whole array, so an unbounded buffer would
# make each frame larger than the last.
_TOKEN_PREVIEW_CHARS = 1200


class OrchestrationPipeline:
    """
    Full orchestration pipeline coordinator.

    Composes all orchestrator components into a single ``run()`` method
    that processes one chat turn end-to-end.
    """

    @staticmethod
    async def _session_uploads(
        chat_repo: Any, db: AsyncSession, chat_session_id: str
    ) -> Tuple[Dict[str, str], ...]:
        """
        This conversation's uploads and their processing status, from Postgres.

        WHY: The context ledger is cached per worker process, and an upload
             invalidates the cache only in the worker that received it. With
             several workers, the next message can be served from a snapshot
             taken before the upload and report "no document" for a file the
             user has just provided. This one small query is the ground truth
             that snapshot is checked against. Never raises.
        """
        reader = getattr(chat_repo, "get_session_upload_states", None)
        if reader is None or not chat_session_id:
            return ()
        try:
            return tuple(await reader(db, chat_session_id))
        except Exception:  # noqa: BLE001 -- the cached snapshot still answers
            logger.debug(
                "Upload states unavailable for session %s", chat_session_id,
                exc_info=True,
            )
            return ()

    @staticmethod
    def _has_ready_upload(uploads: Sequence[Dict[str, str]]) -> bool:
        return any(str(u.get("status") or "") == "ready" for u in uploads)

    @staticmethod
    def _ledger_is_stale(ledger: Any, uploads: Sequence[Dict[str, str]]) -> bool:
        """
        Whether the cached ledger disagrees with Postgres about this chat's files.

        Compared on this conversation's ready uploads only -- documents and
        spreadsheets alike, since both are rows of the same table.
        """
        in_db = {
            str(u.get("document_id") or "")
            for u in uploads
            if str(u.get("status") or "") == "ready"
        }
        in_ledger = {
            doc.document_id
            for doc in (
                *getattr(ledger, "current_session_docs", ()),
                *getattr(ledger, "tabular", ()),
            )
        }
        in_db.discard("")
        in_ledger.discard("")
        return in_db != in_ledger

    @staticmethod
    def _answers_upload_request(
        conversation_state: str,
        session_ctx: Dict[str, Any],
        uploads: Sequence[Dict[str, str]],
        trace_data: Dict[str, Any],
    ) -> str:
        """
        Decide whether this message is a reply to an "upload the document" stop.

        WHAT: Returns the conversation state this turn should act on.
        WHY:  After a stop for a missing upload the session waits for a
              clarification, and the next message was always merged with the
              original request as its "answer". A user who asked something
              else instead -- "what is an ARB?" -- had that question folded into
              the review they could not yet run, re-planned into the same stop,
              and could not get a normal answer. The file is the only answer an
              upload stop can have: once one is here the merge resumes the
              original request exactly as before; until then the message is a
              new request, and the gate still checks every turn.
        """
        if (
            conversation_state == "awaiting_clarification"
            and session_ctx.get("awaiting_upload")
            and not OrchestrationPipeline._has_ready_upload(uploads)
        ):
            trace_data["upload_follow_up"] = "new_request"
            return "awaiting_input"
        return conversation_state

    async def _gate_turn(
        self,
        orchestrator_output: Dict[str, Any],
        *,
        ledger: Any,
        skill_manifest: Dict[str, Any],
        known_text: str,
        replan: Any,
        uploads: Sequence[Dict[str, str]],
        trace_data: Dict[str, Any],
    ) -> tuple:
        """
        Run the Evidence Gate for one turn and fold a stop into the plan.

        Shared by ``run()`` and ``run_stream()`` so the two cannot drift.

        OUTPUT: ``(plan, gate_result)``. The result is returned as well as
                applied: execution hands its ``satisfied_note`` and
                ``caveat_note`` to the skills, so a run knows which uploaded
                document answers the request and what could not be verified.
        """
        gate_result = evidence_gate.check(
            orchestrator_output, ledger, skill_manifest=skill_manifest
        )

        if gate_result.configured_only:
            orchestrator_output, gate_result = await self._reconsider_upload_stop(
                orchestrator_output,
                gate_result,
                ledger=ledger,
                skill_manifest=skill_manifest,
                known_text=known_text,
                replan=replan,
                trace_data=trace_data,
            )

        trace_data["evidence_gate"] = gate_result.describe()

        if gate_result.stopped:
            steps = orchestrator_output.get("execution_plan") or []
            orchestrator_output = evidence_gate.apply(
                orchestrator_output,
                gate_result,
                missing_context.render(
                    gate_result,
                    intent=orchestrator_output.get("intent", ""),
                    skill_name=(steps[0].get("skill_name", "") if steps else ""),
                    uploads=uploads,
                ),
            )
            trace_data["missing_context"] = missing_context.payload(
                gate_result, intent=orchestrator_output.get("intent", "")
            )
        return orchestrator_output, gate_result

    @staticmethod
    async def _reconsider_upload_stop(
        orchestrator_output: Dict[str, Any],
        gate_result: Any,
        *,
        ledger: Any,
        skill_manifest: Dict[str, Any],
        known_text: str,
        replan: Any,
        trace_data: Dict[str, Any],
    ) -> tuple:
        """
        Give a request stopped only by a skill's upload need one chance to be
        answered without that skill.

        WHAT: When the planner declared nothing missing but planned a skill that
              cannot run without an upload, states that fact and plans once
              more. The new plan replaces the stop only if it answers directly,
              produces no new content, names no user document, and passes the
              gate itself.
        WHY:  "What does our ARB guideline say about RTO?" needs no upload, but
              routed to the review workflow it was stopped and told to upload a
              file. The configured rule stays absolute -- a workflow that needs
              an upload still never runs without one; this only lets a request
              that never needed it be answered.

        Deliberately narrow. Choosing a *different* skill is not accepted: for
        "review my ARB submission" that would run some other agent on no
        submission, which is the failure the upload rule exists to prevent. A
        request that produces content, or that either plan described as being
        about the user's document, keeps the stop. At most one extra planning
        call, only on this path; any failure keeps the stop.
        """
        record: Dict[str, Any] = {"outcome": "stop_kept"}
        note = (
            "The skill you planned cannot run until the user uploads a document "
            "in this conversation, and none has been uploaded.\n\n"
            "Decide again. If this request is about the user's own document -- "
            "to review, evaluate, assess, analyse or report on it -- add it to "
            "`evidence_required` with `kind` `document` and `blocking` true, "
            "and choose `needs_input`. Only if the request can be answered fully "
            "without the user's document -- a general question, or one the "
            "knowledge bases answer -- choose `answer_directly` and reply in "
            "`message`."
        )

        try:
            replanned = await replan(known_text, note)
        except Exception:  # noqa: BLE001 -- the stop stands on any failure
            logger.exception("Re-plan after an upload stop failed; keeping the stop")
            record["outcome"] = "replan_failed"
            trace_data["upload_reconsideration"] = record
            return orchestrator_output, gate_result

        recheck = evidence_gate.check(replanned, ledger, skill_manifest=skill_manifest)
        accepted = (
            replanned.get("decision") == "answer_directly"
            and not replanned.get("produces_new_content")
            and not recheck.stopped
            and not evidence_gate.declares_user_file(orchestrator_output)
            and not evidence_gate.declares_user_file(replanned)
        )
        record["replanned_decision"] = replanned.get("decision")

        if accepted:
            logger.info(
                "Upload stop reconsidered: the request is answered without the "
                "upload-dependent skill"
            )
            record["outcome"] = "answered_without_upload"
            trace_data["upload_reconsideration"] = record
            return replanned, recheck

        trace_data["upload_reconsideration"] = record
        return orchestrator_output, gate_result

    @staticmethod
    async def _release_upload_pause(
        chat_repo: Any,
        db: AsyncSession,
        session: Any,
        *,
        chat_session_id: str,
        user_id: Optional[str],
        application_id: str,
    ) -> tuple:
        """
        Clear a workflow paused inside itself waiting for a file upload.

        WHAT: When the session is held on a Start-node ``file_upload`` interrupt,
              drops that pause and returns the session to ``awaiting_input``.
              Any other pause -- a genuine review node -- is returned untouched.
        WHY:  Inside an application a Start node no longer pauses for an upload:
              the upload is checked before the workflow starts, and the turn is
              refused with a request for the document when there is none. A
              session paused before this changed was refusing every message
              ("paused for human review") with no way forward in chat. The run
              it waited on is abandoned; the user's next message plans afresh.
        OUTPUT: ``(conversation_state, context_data)`` to use for the rest of
                this turn.
        """
        state = session.conversation_state
        context = session.context_data or {}
        hitl_state = context.get("hitl_state")

        if (
            state != "awaiting_clarification"
            or not isinstance(hitl_state, dict)
            or str(hitl_state.get("interrupt_type") or "") != "file_upload"
        ):
            return state, context

        remaining = {k: v for k, v in context.items() if k != "hitl_state"}
        await chat_repo.update_session_state(
            db,
            chat_session_id,
            conversation_state="awaiting_input",
            context_data=remaining,
            user_id=user_id or "",
            application_id=application_id,
        )
        logger.info(
            "Released session %s from a workflow paused for a file upload "
            "(run_id=%s); the upload is now checked before a workflow starts",
            chat_session_id, hitl_state.get("run_id", ""),
        )
        return "awaiting_input", remaining

    @staticmethod
    async def _reconcile_false_ask(
        orchestrator_output: Dict[str, Any],
        ledger: Any,
        known_text: str,
        replan: Any,
    ) -> tuple:
        """
        Turn an ask the session already answers into an execution.

        WHAT: When the planner comes back asking for artifacts the ledger shows
              are present, states them as established and plans once more.
        WHY:  The gate is one-directional -- it converts a proceed into a stop
              when a declared artifact is absent, but nothing converted a *false
              ask* into a proceed when the artifact was plainly there. A user who
              had just uploaded a document was asked to upload it, and only the
              next turn recovered, because by then the answer was in "Already
              established". This closes the same loop one turn earlier, from the
              ledger rather than from the user.

        OUTPUT: ``(plan, reconciliation_or_None)``. The plan is returned
                unchanged whenever there is nothing to reconcile.

        **Re-planned, not flag-flipped.** An ask carries ``steps=0``: clearing
        ``needs_clarification`` alone would leave an empty plan and answer
        nothing. The second call is what produces the steps.

        Bounded and safe: at most one extra planning call, only on the
        contradictory path, and if the re-plan still asks then the ask stands.
        A failure in the re-plan leaves the original ask untouched -- degrading
        to one wasted round is strictly better than failing the turn.
        """
        reconciliation = evidence_gate.reconcile(orchestrator_output, ledger)
        if not reconciliation.resolved:
            return orchestrator_output, (
                reconciliation if reconciliation.unresolved else None
            )

        # Stated through the same "Already established" channel Phase D uses,
        # so not re-asking is the natural reading of the planner's own input
        # rather than an instruction bolted on beside it.
        satisfied_text = reconciliation.satisfied_text()
        combined = "\n".join(part for part in (known_text, satisfied_text) if part)

        try:
            replanned = await replan(combined)
        except Exception:  # noqa: BLE001 -- never fail a turn on the correction
            logger.exception(
                "Re-plan after evidence reconciliation failed; keeping the "
                "original clarification request"
            )
            return orchestrator_output, reconciliation

        if replanned.get("needs_clarification"):
            # It asked again knowing the artifacts are present, so it wants
            # something the ledger genuinely cannot supply. Respect that.
            logger.info(
                "Re-plan still requests input after reconciliation; the ask stands"
            )
            return replanned, reconciliation

        logger.info(
            "Evidence reconciliation resolved a false clarification request; "
            "proceeding with %d step(s)",
            len(replanned.get("execution_plan") or []),
        )
        return replanned, reconciliation

    @staticmethod
    async def _reconcile_unrouted_answer(
        orchestrator_output: Dict[str, Any],
        skill_manifest: Dict[str, Any],
        known_text: str,
        replan: Any,
    ) -> tuple:
        """
        Turn "I will answer this myself" back into "run the skill that does it".

        WHAT: When the planner elects ``answer_directly`` for a request that it
              has itself marked as producing new content, while the application
              has skills and it planned none, states the contradiction and plans
              once more.
        WHY:  ``answer_directly`` is terminal. ``schema.to_legacy_plan`` maps it
              to ``fallback_message`` + ``is_conversational``, ``hitl.py:102-110``
              returns that text, and ``execution_plan`` is discarded unread — so
              an application with a workflow attached answers in the model's own
              prose and never invokes it. The state was already *detected* below
              and logged as a conflict; nothing acted on it, and the streaming
              path did not even detect it.

        OUTPUT: ``(plan, record_or_None)``. Unchanged whenever there is nothing
                to reconcile, so a genuine greeting is never re-planned.

        Two independent keys are required, exactly as the Evidence Gate demands
        two: the planner must have said this request *produces new content*, and
        the application must actually have a skill to route to. A conversational
        turn fails the first; an application with no skills fails the second, and
        for it ``answer_directly`` is the only correct answer.

        Bounded and safe, mirroring ``_reconcile_false_ask``: at most one extra
        planning call, only on the contradictory path, and if the re-plan still
        answers directly then that answer stands. A failure in the re-plan leaves
        the original answer untouched.
        """
        skills = skill_manifest.get("skills") or []
        if (
            orchestrator_output.get("decision") != DECISION_ANSWER_DIRECTLY
            or not orchestrator_output.get("produces_new_content")
            or orchestrator_output.get("execution_plan")
            or not skills
        ):
            return orchestrator_output, None

        record: Dict[str, Any] = {
            "outcome": "unresolved",
            "skills_available": len(skills),
            "original_decision": DECISION_ANSWER_DIRECTLY,
        }

        note = (
            "On your previous attempt at this same request you chose "
            "`answer_directly` while also marking it as producing new content, "
            "and you planned no skills. Those cannot all be true: producing "
            "something is work, and this application has skills listed above "
            "that exist to do it.\n\n"
            "Decide again. If a listed skill does this work, choose `execute` "
            "and plan it. Only keep `answer_directly` if this really is a "
            "greeting, small talk, or a question about the application itself."
        )

        try:
            replanned = await replan(known_text, note)
        except Exception:  # noqa: BLE001 -- never fail a turn on the correction
            logger.exception(
                "Re-plan after routing reconciliation failed; keeping the "
                "planner's direct answer"
            )
            return orchestrator_output, record

        if replanned.get("decision") == DECISION_ANSWER_DIRECTLY:
            # It answered directly again knowing the skills are there. Respect
            # that -- the model has more of the request than this check does.
            logger.info(
                "Re-plan still answers directly after routing reconciliation; "
                "the answer stands"
            )
            record["outcome"] = "answer_stands"
            return replanned, record

        steps = len(replanned.get("execution_plan") or [])
        logger.info(
            "Routing reconciliation converted a direct answer into %d step(s)",
            steps,
        )
        record["outcome"] = "routed"
        record["steps"] = steps
        return replanned, record

    @staticmethod
    async def _compose_response(
        *,
        user_message: str,
        fallback_text: str,
        app: Any,
        persona_prompt: str,
        guardrail_rules: str,
        available_evidence: str,
        llm_selection: Any,
        app_id: str,
        user_id: Optional[str],
        trace_data: Dict[str, Any],
        execution_result: Optional[Dict[str, Any]] = None,
        orchestrator_output: Optional[Dict[str, Any]] = None,
        seed_answer: str = "",
        retrieved_context: str = "",
    ) -> str:
        """
        Turn what a turn produced into the answer its reader gets.

        WHAT: One model call on the application's own LLM, composing from the
              request, the plan, the step outputs and any generated files.
        WHY:  The pipeline had a planning stage and an execution stage and
              nothing between execution and the user. ``final_output`` was the
              last skill's raw output, and ``answer_directly`` was a field
              filled in during a schema-constrained routing call -- so a
              document-generating workflow returned a receipt, and a direct
              question returned a sentence.
        OUTPUT: The composed answer, or ``fallback_text`` unchanged.

        Shared by both entry points and by both the executed and the
        answer-directly paths, because four hand-maintained copies of this is
        how ``run()`` and ``run_stream()`` drifted apart before.

        Never raises. Composition is additive: a failure here must leave the
        turn exactly as it would have been without this stage.
        """
        from .response import compose, should_compose

        # An answer-directly turn has no steps, so it is composed on the
        # strength of the seed rather than on ``should_compose``.
        if not seed_answer and not should_compose(execution_result, fallback_text):
            trace_data["response_composition"] = {"composed": False, "reason": "not_needed"}
            return fallback_text

        composed = await compose(
            user_message=user_message,
            fallback_text=fallback_text,
            execution_result=execution_result,
            orchestrator_output=orchestrator_output,
            app=app,
            persona_prompt=persona_prompt,
            guardrail_rules=guardrail_rules,
            available_evidence=available_evidence,
            retrieved_context=retrieved_context,
            seed_answer=seed_answer,
            llm_selection=llm_selection,
            app_id=app_id,
            user_id=user_id,
        )

        logger.info(
            "COMPOSITION COMPLETE. FALLBACK_LEN=%d COMPOSED_LEN=%d",
            len(fallback_text or ""),
            len(composed or ""),
        )

        trace_data["response_composition"] = {
            "composed": composed != fallback_text,
            "source_chars": len(fallback_text or ""),
            "composed_chars": len(composed or ""),
            "mode": "answer_directly" if seed_answer else "executed",
        }
        return composed

    @staticmethod
    def _apply_clarification_budget(
        orchestrator_output: Dict[str, Any],
        state: "slot_tracker.ClarificationState",
        user_message: str,
    ) -> tuple:
        """
        Guarantee that asking the user always terminates.

        WHAT: Lets a request come back to the user while it has rounds left,
              and converts the ask into an execution on stated assumptions once
              it does not.
        WHY:  Microsoft documents this exact failure in Copilot Studio's own
              generative orchestration -- the agent asks, is given a valid
              answer, and asks again, never proceeding. The cause is a planner
              re-deciding from scratch every turn. Showing it what is already
              known (handled in the prompt) removes the *reason* to re-ask;
              this removes the *ability*.
        OUTPUT: ``(plan, state)``. The plan is returned unchanged whenever the
                orchestrator was not asking for anything.

        A request that has exhausted its rounds does not fail and does not
        return an apology: it runs, and the user is told what was assumed.
        """
        if not orchestrator_output.get("needs_clarification"):
            # Nothing was asked, so nothing is outstanding. Any state from an
            # earlier round has served its purpose.
            return orchestrator_output, slot_tracker.cleared()

        requirements = [
            r
            for r in (
                list(orchestrator_output.get("evidence_required") or [])
                + list(orchestrator_output.get("information_required") or [])
            )
            if isinstance(r, dict) and r.get("blocking")
        ]

        if orchestrator_output.get("evidence_block"):
            # An artifact is missing, and an artifact has no default. The
            # clarification budget exists so a request never gets stuck asking
            # for *information* -- page count, tone, region -- where a sensible
            # default always exists. There is no sensible default for the RFP
            # the user asked to have evaluated, so forcing progress here would
            # mean inventing one: the exact failure this plan removes.
            #
            # This is not a loop. The run states what it needs once per turn,
            # costs a single planning call, and escalates nothing. It ends when
            # the user provides the artifact or asks for something else.
            logger.info(
                "Evidence block: an artifact requirement is unmet, so the "
                "clarification budget does not apply"
            )
            return orchestrator_output, state

        if state.exhausted:
            forced = slot_tracker.forced_assumptions(state)
            logger.info(
                "Clarification budget spent after %d round(s); proceeding on "
                "%d stated assumption(s)",
                state.round, len(forced),
            )
            proceeding = dict(orchestrator_output)
            proceeding["needs_clarification"] = False
            proceeding["clarification_question"] = None
            proceeding["decision"] = "execute"
            proceeding["assumptions"] = list(
                orchestrator_output.get("assumptions") or []
            ) + forced
            proceeding["clarification_exhausted"] = True
            return proceeding, slot_tracker.cleared()

        return orchestrator_output, slot_tracker.opened(
            state,
            original_prompt=state.original_prompt or user_message,
            requirements=requirements,
            assumptions=orchestrator_output.get("assumptions") or [],
        )

    @staticmethod
    async def _resolve_turn_context(
        *,
        app: Any,
        db: AsyncSession,
        chat_repo: Any,
        chat_session_id: str,
        user_id: str,
        enhanced_prompt: str,
        trace_data: Dict[str, Any],
        llm_selection: Optional[Any] = None,
        uploads: Optional[Sequence[Dict[str, str]]] = None,
    ) -> "TurnContext":
        """
        Resolve everything this turn can draw on, for both pipeline paths.

        WHAT: Builds (or serves) the Application Context Ledger, then renders
              the four context blocks the planner and executor consume.
        WHY:  ``app-plan.md`` Phase A. The three ``_retrieve_*`` functions used
              to run per message: a full database introspection, a live MCP
              resource fetch, and a knowledge-base metadata query. Only the
              knowledge *retrieval* genuinely varies per turn — it depends on
              the question — so only that still runs per turn.
        OUTPUT: A :class:`TurnContext`. Never raises: a source that cannot be
                reached is reported on the ledger, not thrown.
        """
        from apps.appmgr.context import get_or_build_ledger

        ledger = await get_or_build_ledger(
            app,
            user_id=user_id or "",
            chat_session_id=chat_session_id,
            chat_repo=chat_repo,
            db=db,
        )

        # The cached ledger is per worker; Postgres is not. Rebuilt when they
        # disagree about this chat's uploads, so neither the gate nor the agents
        # act on a snapshot taken before the user's latest file arrived.
        if uploads is not None and OrchestrationPipeline._ledger_is_stale(
            ledger, uploads
        ):
            logger.info(
                "Context ledger for session %s is behind its uploads; rebuilding",
                chat_session_id,
            )
            ledger = await get_or_build_ledger(
                app,
                user_id=user_id or "",
                chat_session_id=chat_session_id,
                chat_repo=chat_repo,
                db=db,
                force=True,
            )
            trace_data["ledger_refreshed"] = True

        document_context = await _build_merged_document_context(
            chat_repo, db, chat_session_id, enhanced_prompt,
            user_id=user_id or None,
            application_id=str(getattr(app, "application_id", "") or "") or None,
        )

        knowledge_context = await OrchestrationPipeline._retrieve_knowledge_context(
            app, user_id or "", enhanced_prompt, ledger=ledger,
        )
        mcp_context = await OrchestrationPipeline._retrieve_mcp_data_source_context(
            app, user_id or "", ledger=ledger,
        )
        db_context = await OrchestrationPipeline._retrieve_db_data_source_context(
            app, user_id or "", ledger=ledger,
        )

        # Tabular skills read spreadsheets with pandas, so they need a path.
        # The path is rehydrated from Postgres when this replica does not have
        # the file: the upload may have been received by a container that no
        # longer exists, and before documents were durable that meant the skill
        # silently found nothing.
        tabular_files = tuple(
            entry
            for entry in [
                await OrchestrationPipeline._materialize_tabular(doc)
                for doc in ledger.tabular
                if doc.stored_filename
            ]
            if entry is not None
        )

        from apps.appmgr.context.binding import build_contribution

        contribution = build_contribution(ledger, llm_selection=llm_selection)

        trace_data["document_context_used"] = document_context is not None
        trace_data["knowledge_context_used"] = bool(knowledge_context)
        trace_data["mcp_data_source_context_used"] = bool(mcp_context)
        trace_data["db_data_source_context_used"] = bool(db_context)
        trace_data["application_context"] = {
            "bound_connectors": len(( contribution or {}).get("connectors") or []),
            "bound_knowledge_bases": len((contribution or {}).get("knowledge_sources") or []),
            "searchable_documents": len((contribution or {}).get("session_documents") or []),
            "connectors": len(ledger.connectors),
            "connectors_reachable": sum(1 for s in ledger.connectors if s.reachable),
            "knowledge_bases": len(ledger.knowledge),
            "indexed_documents": ledger.indexed_knowledge_documents,
            "session_documents": len(ledger.session_docs),
            "tabular_files": len(ledger.tabular),
            "errors": list(ledger.errors),
        }

        return TurnContext(
            ledger=ledger,
            document_context=document_context,
            knowledge_context=knowledge_context,
            mcp_context=mcp_context,
            db_context=db_context,
            tabular_files=tabular_files,
            application_contribution=contribution,
        )

    def __init__(self) -> None:
        self._prompt_enhancer = PromptEnhancer()
        self._manifest_builder = SkillManifestBuilder()
        self._orchestrator = Orchestrator()
        self._guardrails = GuardrailsEngine()
        self._persona_formatter = PersonaFormatter()
        self._hitl_manager = HITLManager()
        self._skill_executor = SkillExecutor()

    async def run(
        self,
        db: AsyncSession,
        application_id: str,
        chat_session_id: Optional[str],
        user_message: str,
        user_id: str,
    ) -> Dict[str, Any]:
        """
        Execute one full orchestration turn.

        Args:
            db: Async database session (auto-commits on exit).
            application_id: Application UUID string.
            chat_session_id: Existing session UUID, or None to create new.
            user_message: Raw user input text.
            user_id: User UUID string.

        Returns:
            Dict with keys:
                response (str)          -- the final assistant message
                session_id (str)        -- chat session UUID
                conversation_state (str) -- current HITL state
                execution_trace (dict)  -- audit trail data
        """
        from echolib.repositories.application_repo import ApplicationRepository
        from echolib.repositories.application_chat_repo import ApplicationChatRepository
        from echolib.repositories.base import safe_uuid
        from echolib.models.application import Application
        from sqlalchemy import select

        app_repo = ApplicationRepository()
        chat_repo = ApplicationChatRepository()

        pipeline_start = time.monotonic()
        trace_data: Dict[str, Any] = {}

        # ------------------------------------------------------------------
        # 1. Load application (access already validated at route level)
        # ------------------------------------------------------------------
        _load_stmt = (
            select(Application)
            .where(
                Application.application_id == safe_uuid(application_id),
                Application.is_deleted == False,  # noqa: E712
            )
        )
        app = (await db.execute(_load_stmt)).scalar_one_or_none()
        if app is None:
            return self._error_response(
                "Application not found or access denied.",
                chat_session_id,
            )

        if app.status != "published":
            return self._error_response(
                "Application is not published. Only published applications can be used for chat.",
                chat_session_id,
            )

        # Record app LLM configuration in trace for frontend visibility
        trace_data["app_llm_config"] = [
            {"llm_id": link.llm_id, "role": link.role, "name": link.name}
            for link in (app.llm_links or [])
        ]

        # The application's own LLM, resolved once for this turn and used by
        # every orchestration-layer call. Bring-your-own-LLM means the model
        # chosen when the application was built decides what runs, rather than
        # the personal default of whoever happens to be chatting.
        llm_selection = await resolve_app_llm_selection(application_id, db=db)
        trace_data["orchestration_llm"] = llm_selection.describe()

        # ------------------------------------------------------------------
        # 2. Ensure chat session exists
        # ------------------------------------------------------------------
        is_new_session = False
        if chat_session_id:
            session = await chat_repo.get_session(db, chat_session_id, user_id, application_id)
            if session is None:
                return self._error_response(
                    "Chat session not found.", chat_session_id
                )
            if session.is_closed:
                return self._error_response(
                    "Chat session is closed.", chat_session_id
                )
        else:
            session = await chat_repo.create_session(
                db, application_id, user_id,
                title=user_message[:80] if user_message else "New Chat",
            )
            chat_session_id = str(session.chat_session_id)
            is_new_session = True

            # Inject welcome_prompt as the first assistant message in the session.
            # Skip trivial prompts (e.g. "hi", "hello") that add no value.
            _wp = (app.welcome_prompt or "").strip()
            _trivial_greetings = {"hi", "hello", "hey", "hola", "yo"}
            if _wp and len(_wp) > 10 and _wp.lower() not in _trivial_greetings:
                await chat_repo.add_message(
                    db, chat_session_id, "assistant", app.welcome_prompt,
                    execution_trace={"type": "welcome_prompt"},
                    user_id=user_id,
                    application_id=application_id,
                )

        # ------------------------------------------------------------------
        # 3. Pre-guardrails
        # ------------------------------------------------------------------
        guardrail_categories = await self._get_guardrail_category_names(db, app)
        pre_guard = self._guardrails.pre_process(
            user_message,
            guardrail_categories=guardrail_categories,
            guardrail_text=app.guardrail_text,
        )
        trace_data["guardrail_input"] = {
            "is_safe": pre_guard.is_safe,
            "violations": pre_guard.violations,
            "categories_triggered": pre_guard.categories_triggered,
        }

        if not pre_guard.is_safe:
            violation_msg = (
                "Your message was blocked by safety filters. "
                f"Violations: {', '.join(pre_guard.violations)}"
            )
            # Save user message and violation response
            await chat_repo.add_message(
                db, chat_session_id, "user", user_message,
                guardrail_flags=trace_data["guardrail_input"],
                user_id=user_id,
                application_id=application_id,
            )
            await chat_repo.add_message(
                db, chat_session_id, "assistant", violation_msg,
                user_id=user_id,
                application_id=application_id,
            )
            return {
                "response": violation_msg,
                "session_id": chat_session_id,
                "conversation_state": "awaiting_input",
                "execution_trace": trace_data,
            }

        # ------------------------------------------------------------------
        # 4. Check HITL state -- if awaiting_clarification, build combined prompt
        # ------------------------------------------------------------------
        effective_prompt = user_message
        is_clarification = False

        # Guard: if session is paused at a HITL node (workflow interrupt),
        # reject regular chat messages.  The user must use the
        # POST .../chat/hitl-decide endpoint to approve/reject/edit.
        conversation_state, _session_ctx_data = await self._release_upload_pause(
            chat_repo, db, session,
            chat_session_id=chat_session_id,
            user_id=user_id,
            application_id=application_id,
        )
        if (
            conversation_state == "awaiting_clarification"
            and _session_ctx_data.get("hitl_state")
        ):
            hitl_ctx = _session_ctx_data["hitl_state"].get("interrupt_payload", {})
            return {
                "response": (
                    "This session is paused for human review of a workflow. "
                    "Please use the review panel to approve, reject, edit, "
                    "before continuing the conversation."
                ),
                "session_id": chat_session_id,
                "conversation_state": "awaiting_hitl_review",
                "execution_trace": {
                    "hitl_context": {
                        "title": hitl_ctx.get("title"),
                        "message": hitl_ctx.get("message"),
                        "priority": hitl_ctx.get("priority"),
                        "allowed_decisions": hitl_ctx.get(
                            "allowed_decisions", ["approve", "reject"]
                        ),
                        "run_id": _session_ctx_data["hitl_state"].get("run_id", ""),
                    }
                },
            }

        # What this request has already asked for and already been told. Read
        # before anything else so the planner sees it as settled fact rather
        # than being instructed not to re-ask -- the mechanism that stops the
        # documented "asks, is answered, asks again" loop.
        clarification_state = slot_tracker.from_context(_session_ctx_data)

        # This chat's uploads, read once from Postgres for the whole turn.
        uploads = await self._session_uploads(chat_repo, db, chat_session_id)
        conversation_state = self._answers_upload_request(
            conversation_state, _session_ctx_data, uploads, trace_data
        )

        if conversation_state == "awaiting_clarification":
            clarification_ctx = await self._hitl_manager.get_clarification_context(
                db, chat_session_id
            )
            if clarification_ctx:
                effective_prompt = await self._hitl_manager.build_clarification_prompt(
                    original_prompt=clarification_ctx.get("original_prompt", user_message),
                    clarification_answer=user_message,
                    partial_analysis=clarification_ctx.get("partial_analysis", ""),
                    conversation_window=clarification_ctx.get("conversation_window"),
                )
                is_clarification = True

            # The user has answered. Record it before planning, so this turn is
            # the one that proceeds rather than the one that asks again.
            if clarification_state.is_active:
                clarification_state = slot_tracker.learned(
                    clarification_state, reply=user_message
                )

        # ------------------------------------------------------------------
        # 5. Build persona prompt
        # ------------------------------------------------------------------
        persona_prompt = await self._persona_formatter.build_persona_prompt(
            db,
            persona_id=str(app.persona_id) if app.persona_id else None,
            persona_text=app.persona_text,
        )

        # ------------------------------------------------------------------
        # 5a. Resolve tags, designations, business units, data sources
        # ------------------------------------------------------------------
        app_tags = await self._get_tag_names(db, app)
        app_designations = await self._get_designation_names(db, app)
        app_business_units = await self._get_business_unit_names(db, app)
        app_data_sources = await self._get_data_source_names(db, app)

        # Append linked knowledge base names so the orchestrator LLM
        # sees them as available data sources alongside MCP/DB connectors.
        kb_names = await self._get_knowledge_base_names(db, app)
        if kb_names:
            app_data_sources = list(app_data_sources) + [
                f"{name} (knowledge base)" for name in kb_names
            ]
        
        trace_data["app_tags"] = app_tags
        trace_data["app_designations"] = app_designations
        trace_data["app_business_units"] = app_business_units
        trace_data["app_data_sources"] = app_data_sources

        # ------------------------------------------------------------------
        # 6. Get conversation history (moved before enhance for context)
        # ------------------------------------------------------------------
        # Fetch last 8 messages (4 user + 4 assistant exchanges)
        # This preserves conversation context while limiting token usage
        history_messages = await chat_repo.get_messages(
            db, chat_session_id, limit=8
        )
        conversation_history = [
            {"role": msg.role, "content": msg.content}
            for msg in history_messages
        ]

        # ------------------------------------------------------------------
        # 7. Enhance prompt
        # ------------------------------------------------------------------
        enhancement = await self._prompt_enhancer.enhance(
            effective_prompt, app_id=application_id, user_id=user_id,
            conversation_history=conversation_history,
            llm_selection=llm_selection,
        )
        enhanced_prompt = enhancement.get("enhanced_prompt", effective_prompt)
        trace_data["enhanced_prompt"] = enhanced_prompt
        trace_data["detected_intent"] = enhancement.get("detected_intent")
        trace_data["intent_confidence"] = enhancement.get("confidence")

        # ------------------------------------------------------------------
        # 6a. Turn context: ledger + document / knowledge / MCP / DB retrieval
        # ------------------------------------------------------------------
        # One helper, shared with run_stream(), so the two paths cannot drift.
        turn_context = await self._resolve_turn_context(
            app=app,
            db=db,
            chat_repo=chat_repo,
            chat_session_id=chat_session_id,
            user_id=user_id,
            enhanced_prompt=enhanced_prompt,
            trace_data=trace_data,
            llm_selection=llm_selection,
            uploads=uploads,
        )
        document_context = turn_context.document_context
        knowledge_context = turn_context.knowledge_context
        mcp_data_source_context = turn_context.mcp_context
        db_data_source_context = turn_context.db_context
        tabular_files = turn_context.as_tabular_list()

        # ------------------------------------------------------------------
        # 8. Build skill manifest
        # ------------------------------------------------------------------
        skill_manifest = await self._manifest_builder.build_manifest(
            db, application_id
        )
        skills_list = skill_manifest.get("skills", [])
        trace_data["skill_count"] = len(skills_list)
        
        # DIAGNOSTIC: Log skill manifest details (Phase 1 RCA)
        if skills_list:
            logger.info(
                "✅ Skill manifest built: %d skills available",
                len(skills_list),
                extra={
                    "first_skill": {
                        "type": skills_list[0].get("skill_type"),
                        "name": skills_list[0].get("skill_name"),
                        "id": skills_list[0].get("skill_id"),
                    } if skills_list else None
                },
            )
        else:
            logger.error(
                "❌ NO SKILLS FOUND - Application has no linked workflows/agents. "
                "RCA Hypothesis 1: Empty skill manifest likely cause of answer_directly decision"
            )

        # ------------------------------------------------------------------
        # 9. Call orchestrator LLM
        # ------------------------------------------------------------------
        guardrail_rules_text = app.guardrail_text or ""

        async def _plan(known_text: str, replan_note: str = "") -> Dict[str, Any]:
            """One planning call. Only the two correction inputs vary."""
            return await self._orchestrator.plan(
                enhanced_prompt=enhanced_prompt,
                skill_manifest=skill_manifest,
                conversation_history=conversation_history,
                persona_prompt=persona_prompt,
                guardrail_rules=guardrail_rules_text,
                document_context=document_context,
                app_tags=app_tags,
                app_designations=app_designations,
                app_business_units=app_business_units,
                app_name=app.name,
                app_description=app.description,
                app_disclaimer=app.disclaimer,
                app_data_sources=app_data_sources,
                app_id=application_id,
                user_id=user_id,
                tabular_files=tabular_files,
                knowledge_context=knowledge_context,
                mcp_data_sources_context=mcp_data_source_context,
                db_data_sources_context=db_data_source_context,
                llm_selection=llm_selection,
                available_evidence=available_evidence(turn_context.ledger),
                known_text=known_text,
                rounds_used=clarification_state.round,
                rounds_max=slot_tracker.max_rounds(),
                original_prompt=clarification_state.original_prompt,
                replan_note=replan_note,
            )

        orchestrator_output = await _plan(clarification_state.known_text())
        
        # DIAGNOSTIC: Log orchestrator decision with conflict detection (Phase 2 RCA)
        decision = orchestrator_output.get("decision")
        produces_new = orchestrator_output.get("produces_new_content", False)
        steps_count = len(orchestrator_output.get("execution_plan", []))
        blocking_reqs = len(orchestrator_output.get("blocking_requirements", []))
        
        logger.info(
            "🎯 ORCHESTRATOR DECISION: decision=%s produces_new_content=%s "
            "execution_plan_steps=%d blocking_requirements=%d",
            decision, produces_new, steps_count, blocking_reqs,
            extra={
                "decision_details": {
                    "decision": decision,
                    "produces_new_content": produces_new,
                    "steps": steps_count,
                    "intent": orchestrator_output.get("intent", "")[:100],
                    "task_summary": orchestrator_output.get("task_summary", "")[:100],
                    "message": orchestrator_output.get("message", "")[:100] if orchestrator_output.get("message") else None,
                }
            },
        )
        
        # Reconcile a direct answer that should have been a route. This state
        # was previously detected right here and only logged; it is now acted
        # on, once, before anything downstream consumes the decision.
        orchestrator_output, routing_reconciliation = (
            await self._reconcile_unrouted_answer(
                orchestrator_output,
                skill_manifest,
                clarification_state.known_text(),
                _plan,
            )
        )
        if routing_reconciliation is not None:
            trace_data["routing_reconciliation"] = routing_reconciliation
            decision = orchestrator_output.get("decision")
            steps_count = len(orchestrator_output.get("execution_plan", []))

        if steps_count == 0 and decision == "execute":
            logger.error(
                "⚠️  EXECUTION PLAN EMPTY: decision=execute but execution_plan is empty (steps=0). "
                "RCA Hypothesis 4: Plan not being generated despite execute decision"
            )
        elif not skills_list and decision == "answer_directly":
            logger.info(
                "ℹ️  EXPECTED BEHAVIOR: No skills available + answer_directly decision is correct pairing"
            )
        else:
            logger.debug("✅ Decision and state appear consistent")

        # ------------------------------------------------------------------
        # 9a-pre. Reconcile a false ask against the ledger
        # ------------------------------------------------------------------
        orchestrator_output, reconciliation = await self._reconcile_false_ask(
            orchestrator_output,
            turn_context.ledger,
            clarification_state.known_text(),
            _plan,
        )
        if reconciliation is not None:
            trace_data["evidence_reconciliation"] = reconciliation.describe()

        # ------------------------------------------------------------------
        # 9a. Evidence Gate — between reasoning and action, zero model calls
        # ------------------------------------------------------------------
        # The planner declared what this request needs; the ledger decides
        # whether it is actually there. Two independent keys are required to
        # stop: the planner marking a requirement blocking, and the lookup
        # confirming it absent. The skill manifest adds a third source that
        # needs no planner: a planned workflow configured to need an uploaded
        # document stops here when this conversation has none, before it runs.
        orchestrator_output, gate_result = await self._gate_turn(
            orchestrator_output,
            ledger=turn_context.ledger,
            skill_manifest=skill_manifest,
            known_text=clarification_state.known_text(),
            replan=_plan,
            uploads=uploads,
            trace_data=trace_data,
        )

        # The termination guarantee. A request may come back to the user only
        # so many times; past the cap it proceeds on stated assumptions. This
        # is enforced here rather than asked of the model, because a stopping
        # condition that depends on a model choosing to stop is not one.
        orchestrator_output, clarification_state = self._apply_clarification_budget(
            orchestrator_output, clarification_state, user_message
        )
        trace_data["orchestrator_plan"] = orchestrator_output
        trace_data["clarification"] = clarification_state.describe()

        # ------------------------------------------------------------------
        # 10. Handle HITL response
        # ------------------------------------------------------------------
        hitl_action = await self._hitl_manager.handle_orchestrator_response(
            db, chat_session_id, orchestrator_output, enhanced_prompt,
            conversation_history=conversation_history,
        )

        action = hitl_action.get("action")

        # Helper to build session metadata dict when it's a new session
        def _session_meta() -> Optional[Dict[str, Any]]:
            if not is_new_session:
                return None
            return {
                "app_name": app.name,
                "app_description": app.description,
                "app_logo_url": app.logo_url,
                "welcome_prompt": app.welcome_prompt,
                "disclaimer": app.disclaimer,
                "starter_questions": app.starter_questions or [],
            }

        if action == "clarify":
            clarification_msg = hitl_action.get("message", "Could you clarify?")

            # Carry what has been asked and answered into the next turn.
            # ``HITLManager`` has already written its own clarification context;
            # this merges alongside it rather than replacing it, so both the
            # existing resume path and the budget keep working.
            try:
                await chat_repo.update_session_state(
                    db,
                    chat_session_id,
                    conversation_state="awaiting_clarification",
                    context_data={
                        **(session.context_data or {}),
                        slot_tracker.CONTEXT_KEY: clarification_state.to_context(),
                        # Read next turn by ``_answers_upload_request``.
                        "awaiting_upload": bool(
                            orchestrator_output.get("awaiting_upload")
                        ),
                    },
                    user_id=user_id,
                    application_id=application_id,
                )
            except Exception:
                logger.warning(
                    "Could not persist clarification state for session %s; "
                    "the round counter may restart",
                    chat_session_id, exc_info=True,
                )
            # Save messages
            await chat_repo.add_message(
                db, chat_session_id, "user", user_message,
                enhanced_prompt=enhanced_prompt,
                user_id=user_id,
                application_id=application_id,
            )
            await chat_repo.add_message(
                db, chat_session_id, "assistant", clarification_msg,
                execution_trace={"type": "clarification"},
                user_id=user_id,
                application_id=application_id,
            )
            clarify_result: Dict[str, Any] = {
                "response": clarification_msg,
                "session_id": chat_session_id,
                "conversation_state": "awaiting_clarification",
                "execution_trace": trace_data,
            }
            meta = _session_meta()
            if meta:
                clarify_result["session_metadata"] = meta
            return clarify_result

        if action == "fallback":
            fallback_msg = hitl_action.get("message", "")
            is_conversational = hitl_action.get("is_conversational", False)

            if is_conversational:
                # ``answer_directly``. The planner's reply is a *field on a
                # routing call* -- ``OrchestratorDecision.message``, filled in
                # while deciding what to do with the request -- so it comes back
                # as a sentence where the question deserved an explanation.
                # Composed properly here, with that reply as the first draft.
                full_fallback = await self._compose_response(
                    user_message=user_message,
                    fallback_text=fallback_msg,
                    orchestrator_output=orchestrator_output,
                    app=app,
                    persona_prompt=persona_prompt,
                    guardrail_rules=guardrail_rules_text,
                    available_evidence=available_evidence(turn_context.ledger),
                    # No skill ran on this path, so nothing else carries the
                    # retrieved text. Without it the composer knows a knowledge
                    # base exists and has nothing out of it.
                    retrieved_context=turn_context.retrieved_text(),
                    seed_answer=fallback_msg,
                    llm_selection=llm_selection,
                    app_id=application_id,
                    user_id=user_id,
                    trace_data=trace_data,
                )
            else:
                # Genuine out-of-scope -- prepend sorry_message and append
                # skill capability summary as before. Deliberately not composed:
                # this is a refusal with a fixed shape the operator configured,
                # not an answer.
                sorry = app.sorry_message or ""
                if sorry and fallback_msg:
                    full_fallback = f"{sorry}\n\n{fallback_msg}"
                elif sorry:
                    full_fallback = sorry
                else:
                    full_fallback = fallback_msg

                # Append skill capability summary
                skills = skill_manifest.get("skills", [])
                if skills:
                    skill_summary = ", ".join(
                        f"{s['name']} ({s['skill_type']})" for s in skills
                    )
                    full_fallback += (
                        f"\n\nI can help you with: {skill_summary}. "
                        "Please ask me something related to these capabilities."
                    )

            # Save messages
            await chat_repo.add_message(
                db, chat_session_id, "user", user_message,
                enhanced_prompt=enhanced_prompt,
                user_id=user_id,
                application_id=application_id,
            )
            await chat_repo.add_message(
                db, chat_session_id, "assistant", full_fallback,
                execution_trace={"type": "fallback", "fallback": True, "is_conversational": is_conversational},
                user_id=user_id,
                application_id=application_id,
            )
            fallback_result: Dict[str, Any] = {
                "response": full_fallback,
                "session_id": chat_session_id,
                "conversation_state": "awaiting_input",
                "execution_trace": trace_data,
            }
            meta = _session_meta()
            if meta:
                fallback_result["session_metadata"] = meta
            return fallback_result

        # ------------------------------------------------------------------
        # 11. Execute skills
        # ------------------------------------------------------------------
        plan = orchestrator_output.get("execution_plan", [])
        strategy = orchestrator_output.get("execution_strategy", "single")

        execution_result = await self._skill_executor.execute_plan(
            db=db,
            execution_plan=plan,
            execution_strategy=strategy,
            user_input=enhanced_prompt,
            document_context=document_context,
            knowledge_context=knowledge_context,
            mcp_data_source_context=mcp_data_source_context,
            # Was computed, shown to the planner, then dropped — so an agent
            # could not see a linked database at all (app-plan.md Cause 2b).
            db_data_source_context=db_data_source_context,
            # The application's datasources, as capability rather than text.
            application_context=turn_context.application_contribution,
            # What the gate confirmed, and what it could not.
            evidence_notes=[
                note
                for note in (gate_result.satisfied_note(), gate_result.caveat_note())
                if note
            ],
            conversation_history=conversation_history,
            tabular_files=tabular_files,
            app_id=application_id,
            user_id=user_id,
            chat_session_id=chat_session_id,
            application_id=application_id,
        )

        # ------------------------------------------------------------------
        # 11a. Check for HITL interrupt from workflow execution
        # ------------------------------------------------------------------
        if execution_result.get("hitl_interrupted"):
            hitl_interrupt = execution_result.get("interrupt_payload", {})
            interrupt_ctx = hitl_interrupt.get("interrupt", {})

            # Build partial response from completed steps
            completed_steps = execution_result.get("completed_steps", [])
            partial_parts = []
            for cs in completed_steps:
                partial_parts.append(
                    f"**Step {cs.get('step', '?')} ({cs.get('skill_name', 'unknown')}):** "
                    f"{cs.get('output', '')}"
                )
            partial_text = "\n\n".join(partial_parts) if partial_parts else ""
            if partial_text:
                partial_text += "\n\n---\n\n"
            partial_text += "Workflow paused for human review."

            # Store HITL context in session context_data for later resume
            hitl_state_data = {
                "hitl_state": {
                    "run_id": execution_result.get("run_id", ""),
                    "workflow_id": execution_result.get("workflow_id", ""),
                    "fs_workflow_id": hitl_interrupt.get("fs_workflow_id", ""),
                    "interrupt_payload": interrupt_ctx,
                    "interrupt_type": interrupt_ctx.get("interrupt_type", "hitl"),
                    "completed_steps": completed_steps,
                    "remaining_plan": execution_result.get("remaining_plan", []),
                    "execution_plan": plan,
                    "execution_strategy": strategy,
                    "enhanced_prompt": enhanced_prompt,
                }
            }

            # Derive allowed decisions from interrupt context
            allowed_decisions = interrupt_ctx.get(
                "allowed_decisions", ["approve", "reject"]
            )

            # Save user message
            await chat_repo.add_message(
                db, chat_session_id, "user", user_message,
                enhanced_prompt=enhanced_prompt,
                user_id=user_id,
                application_id=application_id,
            )
            # Save partial assistant message
            await chat_repo.add_message(
                db, chat_session_id, "assistant", partial_text,
                execution_trace={
                    "type": "hitl_interrupt",
                    "hitl_context": {
                        "title": interrupt_ctx.get("title"),
                        "message": interrupt_ctx.get("message"),
                        "priority": interrupt_ctx.get("priority"),
                        "allowed_decisions": allowed_decisions,
                        "run_id": execution_result.get("run_id", ""),
                        "node_outputs": interrupt_ctx.get("node_outputs"),
                    },
                },
                user_id=user_id,
                application_id=application_id,
            )

            # Update session state to awaiting_clarification (DB constraint
            # limits valid values; we use awaiting_clarification and
            # distinguish HITL via context_data.hitl_state).
            await chat_repo.update_session_state(
                db,
                chat_session_id,
                conversation_state="awaiting_clarification",
                context_data=hitl_state_data,
                user_id=user_id,
                application_id=application_id,
            )

            trace_data["execution_log"] = execution_result.get("execution_log", [])
            trace_data["hitl_context"] = {
                "title": interrupt_ctx.get("title"),
                "message": interrupt_ctx.get("message"),
                "priority": interrupt_ctx.get("priority"),
                "allowed_decisions": allowed_decisions,
                "run_id": execution_result.get("run_id", ""),
                "node_outputs": interrupt_ctx.get("node_outputs"),
            }

            hitl_result: Dict[str, Any] = {
                "response": partial_text,
                "session_id": chat_session_id,
                "conversation_state": "awaiting_hitl_review",
                "execution_trace": trace_data,
            }
            meta = _session_meta()
            if meta:
                hitl_result["session_metadata"] = meta
            return hitl_result

        final_output = execution_result.get("final_output", "")

        logger.info(
            "EXECUTION_FINAL_OUTPUT_LEN=%d",
            len(str(final_output or ""))
        )

        logger.info(
            "EXECUTION_FINAL_OUTPUT=%s",
            final_output,
        )

        # Defense-in-depth: strip any INTERNAL intermediate outputs
        # that survived lower-level filtering before reaching the UI.
        if isinstance(final_output, str) and "INTERNAL" in final_output:
            from apps.appmgr.orchestrator.skill_executor import SkillExecutor
            final_output = SkillExecutor._strip_internal_blocks(final_output)

        # Compose the answer the user reads.
        #
        # Until this stage existed the reader got ``final_output`` -- the *last
        # skill's raw output*. A workflow ending in a document generator
        # therefore returned that tool's receipt ("File generated successfully"
        # plus a URL) and never the document's substance, because the content
        # went *into* the tool as arguments and only a confirmation came back.
        #
        # Additive by construction: on any failure ``compose`` returns
        # ``final_output`` unchanged, and ``artifacts.ensure`` re-attaches every
        # download link in code, so a generated file can never be lost to a
        # rewrite. Guardrails and ``_sanitize_for_ui`` still run below on the
        # result, exactly as before.
        final_output = await self._compose_response(
            user_message=user_message,
            fallback_text=final_output,
            execution_result=execution_result,
            orchestrator_output=orchestrator_output,
            app=app,
            persona_prompt=persona_prompt,
            guardrail_rules=guardrail_rules_text,
            available_evidence=available_evidence(turn_context.ledger),
            llm_selection=llm_selection,
            app_id=application_id,
            user_id=user_id,
            trace_data=trace_data,
        )

        trace_data["execution_result"] = execution_result.get("results", {})
        trace_data["execution_log"] = execution_result.get("execution_log", [])
        trace_data["skills_invoked"] = execution_result.get("execution_log", [])

        # ------------------------------------------------------------------
        # 12. Post-guardrails on output
        # ------------------------------------------------------------------
        post_guard = self._guardrails.post_process(
            final_output,
            guardrail_categories=guardrail_categories,
            guardrail_text=app.guardrail_text,
        )
        trace_data["guardrail_output"] = {
            "is_safe": post_guard.is_safe,
            "violations": post_guard.violations,
            "categories_triggered": post_guard.categories_triggered,
        }
        final_output = _sanitize_for_ui(post_guard.sanitized_text)

        # ------------------------------------------------------------------
        # 13. Save messages to DB
        # ------------------------------------------------------------------
        user_msg_record = await chat_repo.add_message(
            db, chat_session_id, "user", user_message,
            enhanced_prompt=enhanced_prompt,
            user_id=user_id,
            application_id=application_id,
        )

        assistant_msg_record = await chat_repo.add_message(
            db, chat_session_id, "assistant", final_output,
            execution_trace=trace_data,
            guardrail_flags=trace_data.get("guardrail_output"),
            user_id=user_id,
            application_id=application_id,
        )

        # ------------------------------------------------------------------
        # 14. Save execution trace
        # ------------------------------------------------------------------
        total_duration_ms = int((time.monotonic() - pipeline_start) * 1000)
        trace_data["total_duration_ms"] = total_duration_ms

        try:
            await chat_repo.create_execution_trace(
                db,
                application_id=application_id,
                chat_session_id=chat_session_id,
                user_message=user_message,
                enhanced_prompt=enhanced_prompt,
                orchestrator_plan=orchestrator_output,
                execution_result=execution_result.get("results"),
                skills_invoked=execution_result.get("execution_log"),
                guardrail_input=trace_data.get("guardrail_input"),
                guardrail_output=trace_data.get("guardrail_output"),
                total_duration_ms=total_duration_ms,
                status="completed",
                message_id=str(user_msg_record.message_id),
            )
        except Exception:
            logger.exception("Failed to save execution trace")

        # ------------------------------------------------------------------
        # 15. Update session state back to awaiting_input
        # ------------------------------------------------------------------
        await chat_repo.update_session_state(
            db, chat_session_id, conversation_state="awaiting_input",
            user_id=user_id,
            application_id=application_id,
        )

        # ------------------------------------------------------------------
        # 16. Return response
        # ------------------------------------------------------------------
        result = {
            "response": final_output,
            "session_id": chat_session_id,
            "conversation_state": "awaiting_input",
            "execution_trace": trace_data,
        }

        # Include session metadata on new session creation so the frontend
        # can render welcome_prompt, disclaimer, starter_questions, etc.
        meta = _session_meta()
        if meta:
            result["session_metadata"] = meta

        return result

    # ------------------------------------------------------------------
    # Streaming variant -- A2UI SSE (enriched with step output data)
    # ------------------------------------------------------------------

    # Base step definitions for A2UI progress surface.
    # Skill execution steps are added dynamically based on the execution plan.
    _PIPELINE_STEPS_BASE = [
        {"id": "step_guardrails",  "icon": "shield",        "label": "Checking guardrails",  "status": "pending", "detail": "", "output": ""},
        {"id": "step_enhance",     "icon": "auto_fix_high", "label": "Enhancing prompt",     "status": "pending", "detail": "", "output": ""},
        {"id": "step_rag",         "icon": "search",        "label": "Retrieving context",   "status": "pending", "detail": "", "output": ""},
        {"id": "step_plan",        "icon": "account_tree",  "label": "Planning execution",   "status": "pending", "detail": "", "output": ""},
        # skill steps are inserted here dynamically
        {"id": "step_post_guard",  "icon": "verified",      "label": "Validating output",    "status": "pending", "detail": "", "output": ""},
    ]

    async def run_stream(
        self,
        sse_queue: asyncio.Queue,
        run_id: str,
        db: AsyncSession,
        app_id: str,
        user_input: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        uploaded_file_ids: Optional[List[str]] = None,
    ) -> None:
        """
        Execute the full orchestration pipeline while emitting A2UI v0.8
        JSONL events to *sse_queue* at each stage.

        This mirrors the logic in ``run()`` but adds streaming progress
        updates with rich per-stage output data.  The original ``run()``
        method is untouched.

        Workflow transparency events from the workflow runtime (arriving via
        ws_manager queue subscription) are translated to A2UI format by
        a background asyncio.Task before being placed on sse_queue.  This
        ensures the frontend only ever sees unified A2UI JSONL.

        When complete, puts ``None`` sentinel into the queue so the SSE
        generator knows the stream has ended.

        Args:
            sse_queue: asyncio.Queue to receive A2UI JSONL strings.
            run_id: Unique execution identifier for this request.
            db: Async database session.
            app_id: Application UUID string.
            user_input: Raw user input text.
            session_id: Existing session UUID, or None to create new.
            user_id: User UUID string.
            uploaded_file_ids: Optional list of uploaded file UUIDs.
        """
        import json as _json
        from echolib.a2ui import A2UIStreamBuilder
        from apps.workflow.runtime.ws_manager import ws_manager

        builder = A2UIStreamBuilder()
        steps = copy.deepcopy(self._PIPELINE_STEPS_BASE)

        # Index where dynamic skill steps will be inserted
        # (just before the last element, step_post_guard)
        _post_guard_idx = len(steps) - 1

        # Intermediate queue for raw transparency events from ws_manager.
        # A translator task converts these to A2UI format on sse_queue.
        raw_queue: asyncio.Queue = asyncio.Queue(maxsize=500)
        translator_task: Optional[asyncio.Task] = None

        async def _emit(line) -> None:
            """Put an A2UI JSONL line onto the SSE queue (non-blocking)."""
            try:
                sse_queue.put_nowait(line)
            except asyncio.QueueFull:
                pass

        async def _update_step(
            step_id: str,
            status: str,
            detail: str = "",
            output: str = "",
        ) -> None:
            """Update a step's status/detail/output and emit the full steps array."""
            for s in steps:
                if s["id"] == step_id:
                    s["status"] = status
                    if detail:
                        s["detail"] = detail
                    if output:
                        s["output"] = output
                    break
            await _emit(builder.step_update(run_id, steps))

        async def _agent_activity(step_num: int, skill_name: str, detail: str) -> None:
            """
            Report what a running agent is doing on its own plan step.

            The skill steps are created below as ``step_skill_{n}``; an executing
            agent writes its live detail onto that row rather than publishing a
            steps array of its own. The CrewAI executor removed in Phase 9 did
            publish one, and since an A2UI ``dataModelUpdate`` replaces
            ``/steps`` outright, every other step disappeared from the reader's
            screen while an agent ran.
            """
            await _update_step(f"step_skill_{step_num}", "running", detail=detail)

        def _safe_json(data: Any) -> str:
            """Serialize data to a compact JSON string, handling non-serialisable types."""
            try:
                return _json.dumps(data, separators=(",", ":"), default=str)
            except (TypeError, ValueError):
                return str(data)

        # --- Translator: converts raw transparency events to A2UI updates ---
        async def _translate_transparency_events() -> None:
            """
            Background task that reads raw transparency events from raw_queue,
            translates each into an A2UI dataModelUpdate, and puts the
            translated JSONL line onto sse_queue.

            Translation mapping:
              run_started    -> emit a preparation sub-step (running)
              step_started   -> insert visible sub-step into steps array (running)
              step_output    -> update sub-step output with intermediate data
              step_completed -> update sub-step to completed + output preview
              step_failed    -> update sub-step to failed + error message
              run_completed  -> mark formation sub-step completed
              run_failed     -> mark formation sub-step failed

            Sub-steps are inserted into the steps array immediately after the
            parent skill step (the running step_skill_N entry) so the frontend
            sees granular workflow progress: preparation, each agent
            starting/completing, tool calls, and merge operations.
            """
            # Track sub-steps by transparency step_id
            sub_steps: Dict[str, Dict[str, str]] = {}
            # Track the formation sub-step id for run_started/run_completed
            formation_sub_id: Optional[str] = None

            # Icon mapping for step types
            _STEP_TYPE_ICONS = {
                "agent": "person",
                "tool_call": "build",
                "llm_call": "psychology",
                "transform": "transform",
                "coordinator": "hub",
                "merge": "merge_type",
                "step_token": "edit_note",
                # Retained for historical execution_steps rows. Nothing emits
                # these two any more -- the CrewAI adapter that did was removed
                # in Phase 9 -- but a replayed run must still render.
                "parallel_crew": "groups",
                "hierarchical_crew": "account_tree",
            }

            def _find_parent_skill_index() -> int:
                """Find the index of the running parent skill step."""
                for idx_s, s in enumerate(steps):
                    if s["id"].startswith("step_skill_") and s["status"] == "running":
                        return idx_s
                return -1

            def _insert_sub_step_after_parent(sub_step_dict: Dict[str, str]) -> None:
                """Insert a sub-step into the steps array after the parent skill step and any existing sub-steps."""
                parent_idx = _find_parent_skill_index()
                if parent_idx < 0:
                    return
                # Find insertion point: after parent and all existing wf_ sub-steps
                insert_at = parent_idx + 1
                while insert_at < len(steps) and steps[insert_at]["id"].startswith("wf_"):
                    insert_at += 1
                steps.insert(insert_at, sub_step_dict)

            def _update_parent_detail() -> None:
                """Update the parent skill step's detail with sub-step progress."""
                parent_idx = _find_parent_skill_index()
                if parent_idx < 0:
                    return
                completed_count = sum(
                    1 for ss in sub_steps.values()
                    if ss["status"] == "completed"
                )
                running_count = sum(
                    1 for ss in sub_steps.values()
                    if ss["status"] == "running"
                )
                failed_count = sum(
                    1 for ss in sub_steps.values()
                    if ss["status"] == "failed"
                )
                total_count = len(sub_steps)
                parts = []
                if running_count:
                    # Show the name of the currently running sub-step
                    running_names = [
                        ss["label"] for ss in sub_steps.values()
                        if ss["status"] == "running"
                    ]
                    parts.append(f"Running: {', '.join(running_names)}")
                if completed_count:
                    parts.append(f"{completed_count}/{total_count} completed")
                if failed_count:
                    parts.append(f"{failed_count} failed")
                steps[parent_idx]["detail"] = " | ".join(parts) if parts else ""

            while True:
                try:
                    event = await asyncio.wait_for(raw_queue.get(), timeout=600.0)
                except asyncio.TimeoutError:
                    break
                if event is None:
                    break

                event_type = event.get("event", "") if isinstance(event, dict) else ""

                if event_type == "run_started":
                    # Workflow execution starting -- insert a preparation sub-step
                    payload = event.get("payload", {})
                    wf_id = payload.get("workflow_id", "")
                    formation_sub_id = f"wf_formation_{event.get('run_id', '')}"
                    formation_sub = {
                        "id": formation_sub_id,
                        "icon": "rocket_launch",
                        "label": "Preparing workflow",
                        "detail": f"Initializing workflow execution",
                        "status": "running",
                        "output": "",
                    }
                    _insert_sub_step_after_parent(formation_sub)
                    await _emit(builder.step_update(run_id, steps))

                elif event_type == "step_started":
                    payload = event.get("payload", {})
                    step_id = event.get("step_id", "")
                    step_name = payload.get("step_name", step_id)
                    step_type = payload.get("step_type", "agent")
                    input_summary = payload.get("input_summary", {})

                    # Build descriptive detail from input_summary
                    detail_parts = []
                    if isinstance(input_summary, dict):
                        if input_summary.get("manager"):
                            detail_parts.append(f"Manager: {input_summary['manager']}")
                        if input_summary.get("workers"):
                            workers = input_summary["workers"]
                            if isinstance(workers, list):
                                detail_parts.append(f"Workers: {', '.join(workers)}")
                        if input_summary.get("agent_name"):
                            detail_parts.append(f"Agent: {input_summary['agent_name']}")
                        if input_summary.get("agent_role"):
                            detail_parts.append(f"Role: {input_summary['agent_role']}")
                        if input_summary.get("agents"):
                            agents_list = input_summary["agents"]
                            if isinstance(agents_list, list):
                                detail_parts.append(f"Agents: {', '.join(agents_list)}")
                        if input_summary.get("merge_strategy"):
                            detail_parts.append(f"Strategy: {input_summary['merge_strategy']}")
                    detail_text = " | ".join(detail_parts) if detail_parts else ""

                    icon = _STEP_TYPE_ICONS.get(step_type, "play_circle")

                    sub_step = {
                        "id": f"wf_{step_id}" if step_id else f"wf_sub_{len(sub_steps)}",
                        "icon": icon,
                        "label": step_name,
                        "detail": detail_text,
                        "status": "running",
                        "output": "",
                    }
                    sub_steps[step_id] = sub_step

                    # Mark formation sub-step as completed if it exists and is still running
                    if formation_sub_id:
                        for s in steps:
                            if s["id"] == formation_sub_id and s["status"] == "running":
                                s["status"] = "completed"
                                s["detail"] = "Workflow ready"
                                break
                        formation_sub_id = None

                    # Insert the sub-step as a visible entry in the steps array
                    _insert_sub_step_after_parent(sub_step)
                    _update_parent_detail()

                    await _emit(builder.step_update(run_id, steps))

                elif event_type == "step_token":
                    # Live model output from a running agent.
                    #
                    # WHY THIS BRANCH EXISTS: the translator handled only step
                    # boundaries -- started, output, completed, failed -- so
                    # between two parallel agents starting and both finishing,
                    # the SSE stream emitted nothing at all. With rate-limit
                    # pacing sleeping tens of seconds per call, a reasoning
                    # model thinking before it writes, and a large generation,
                    # that gap ran past three minutes on a fourteen-agent run
                    # and the idle guard closed a perfectly healthy stream.
                    #
                    # ``publish_step_token_sync`` was already emitting these and
                    # the canvas WebSocket was already consuming them; only this
                    # translator dropped them. Forwarding them means the gap
                    # stops existing rather than being tolerated -- the reader
                    # sees the agent writing, the way ChatGPT and Copilot do.
                    #
                    # The publisher's own contract requires callers to coalesce
                    # before emitting, and ``agent_token_publisher`` does, so
                    # these arrive already batched. ``_emit`` is non-blocking and
                    # drops on a full queue, so a fast model cannot stall the
                    # pipeline here.
                    payload = event.get("payload", {})
                    step_id = event.get("step_id", "")
                    text = payload.get("text", "")
                    if text and step_id in sub_steps:
                        buffered = sub_steps[step_id].get("_token_buffer", "")
                        buffered += str(text)
                        # Bounded: this is a live preview, not the answer. The
                        # full result arrives on step_completed.
                        if len(buffered) > _TOKEN_PREVIEW_CHARS:
                            buffered = buffered[-_TOKEN_PREVIEW_CHARS:]
                        sub_steps[step_id]["_token_buffer"] = buffered

                        preview = buffered.strip()
                        sub_steps[step_id]["output"] = preview
                        sub_id = sub_steps[step_id]["id"]
                        for s in steps:
                            if s["id"] == sub_id:
                                s["output"] = preview
                                break
                        await _emit(builder.step_update(run_id, steps))

                elif event_type == "step_output":
                    # Intermediate output from a running step
                    payload = event.get("payload", {})
                    step_id = event.get("step_id", "")
                    intermediate = payload.get("intermediate_output", {})

                    if step_id in sub_steps:
                        preview = ""
                        if isinstance(intermediate, dict):
                            preview = intermediate.get("output_preview", str(intermediate))
                        else:
                            preview = str(intermediate)
                        # Truncate for display
                        if len(preview) > 300:
                            preview = preview[:300] + "..."
                        sub_steps[step_id]["output"] = preview
                        # Also update the corresponding entry in the steps array
                        sub_id = sub_steps[step_id]["id"]
                        for s in steps:
                            if s["id"] == sub_id:
                                s["output"] = preview
                                break

                    await _emit(builder.step_update(run_id, steps))

                elif event_type == "step_completed":
                    payload = event.get("payload", {})
                    step_id = event.get("step_id", "")
                    output_summary = payload.get("output_summary", {})
                    output_preview_text = payload.get("output_preview", "")

                    if step_id in sub_steps:
                        sub_steps[step_id]["status"] = "completed"
                        # Extract the best output preview
                        preview = output_preview_text
                        if not preview and isinstance(output_summary, dict):
                            preview = output_summary.get("output_preview", "")
                        if not preview and isinstance(output_summary, dict):
                            # Fallback: summarize key info from output_summary
                            summary_parts = []
                            for k, v in output_summary.items():
                                if k in ("output_preview", "tools_used"):
                                    continue
                                if isinstance(v, str) and v:
                                    summary_parts.append(f"{k}: {v[:100]}")
                                elif isinstance(v, list) and v:
                                    summary_parts.append(f"{k}: {', '.join(str(i) for i in v[:5])}")
                            preview = " | ".join(summary_parts) if summary_parts else "Completed"
                        if not preview:
                            preview = str(output_summary) if output_summary else "Completed"
                        # Truncate for display
                        if len(preview) > 300:
                            preview = preview[:300] + "..."
                        sub_steps[step_id]["output"] = preview

                        # Update the corresponding entry in the steps array
                        sub_id = sub_steps[step_id]["id"]
                        for s in steps:
                            if s["id"] == sub_id:
                                s["status"] = "completed"
                                s["output"] = preview
                                break

                    _update_parent_detail()

                    # Also accumulate sub-step summaries on the parent skill step output
                    parent_idx = _find_parent_skill_index()
                    if parent_idx >= 0:
                        parts = []
                        for ss in sub_steps.values():
                            name = ss["label"]
                            status = ss["status"]
                            out = ss["output"][:200] if ss["output"] else ""
                            if out:
                                parts.append(f"{name}: {out}")
                            else:
                                parts.append(f"{name}: {status}")
                        steps[parent_idx]["output"] = "\n".join(parts)

                    await _emit(builder.step_update(run_id, steps))

                elif event_type == "step_failed":
                    payload = event.get("payload", {})
                    step_id = event.get("step_id", "")
                    error_msg = payload.get("error", "Unknown error")

                    if step_id in sub_steps:
                        sub_steps[step_id]["status"] = "failed"
                        sub_steps[step_id]["output"] = f"Error: {error_msg}"

                        # Update the corresponding entry in the steps array
                        sub_id = sub_steps[step_id]["id"]
                        for s in steps:
                            if s["id"] == sub_id:
                                s["status"] = "failed"
                                s["output"] = f"Error: {error_msg}"
                                break

                    _update_parent_detail()
                    await _emit(builder.step_update(run_id, steps))

                elif event_type == "run_completed":
                    # Workflow run completed -- mark formation sub-step as
                    # completed if it's still running (edge case: no step events)
                    if formation_sub_id:
                        for s in steps:
                            if s["id"] == formation_sub_id and s["status"] == "running":
                                s["status"] = "completed"
                                s["detail"] = "Execution complete"
                                break
                        formation_sub_id = None
                    # Parent skill step completion is handled by the pipeline
                    # after execute_plan returns; no action needed here.

                elif event_type == "run_failed":
                    # Workflow run failed -- mark formation sub-step as failed
                    if formation_sub_id:
                        err = event.get("payload", {}).get("error", "Execution failed")
                        for s in steps:
                            if s["id"] == formation_sub_id and s["status"] == "running":
                                s["status"] = "failed"
                                s["output"] = f"Error: {err}"
                                break
                        formation_sub_id = None
                    await _emit(builder.step_update(run_id, steps))

        try:
            from echolib.repositories.application_repo import ApplicationRepository
            from echolib.repositories.application_chat_repo import ApplicationChatRepository
            from echolib.repositories.base import safe_uuid
            from echolib.models.application import Application
            from sqlalchemy import select

            app_repo = ApplicationRepository()
            chat_repo = ApplicationChatRepository()

            pipeline_start = time.monotonic()
            trace_data: Dict[str, Any] = {}

            # ---- Load application (access already validated at route level) ----
            _load_stmt = (
                select(Application)
                .where(
                    Application.application_id == safe_uuid(app_id),
                    Application.is_deleted == False,  # noqa: E712
                )
            )
            app = (await db.execute(_load_stmt)).scalar_one_or_none()
            app_name = app.name if app else "Application"

            # Emit initial surface
            for line in builder.build_initial_surface(run_id, app_name):
                await _emit(line)

            if app is None:
                await _update_step("step_guardrails", "failed", "Application not found")
                await _emit(builder.final_output_update(run_id, "Application not found or access denied."))
                return

            if app.status != "published":
                await _update_step("step_guardrails", "failed", "Application not published")
                await _emit(builder.final_output_update(run_id, "Application is not published."))
                return

            # ---- Ensure chat session ----
            if session_id:
                session = await chat_repo.get_session(db, session_id, user_id or "", app_id)
                if session is None or session.is_closed:
                    await _update_step("step_guardrails", "failed", "Session invalid")
                    await _emit(builder.final_output_update(run_id, "Chat session not found or closed."))
                    return
            else:
                session = await chat_repo.create_session(
                    db, app_id, user_id or "",
                    title=user_input[:80] if user_input else "New Chat",
                )
                session_id = str(session.chat_session_id)
                # Inject welcome_prompt only if it is meaningful (not trivial).
                _wp_s = (app.welcome_prompt or "").strip()
                _trivial_s = {"hi", "hello", "hey", "hola", "yo"}
                if _wp_s and len(_wp_s) > 10 and _wp_s.lower() not in _trivial_s:
                    await chat_repo.add_message(
                        db, session_id, "assistant", app.welcome_prompt,
                        execution_trace={"type": "welcome_prompt"},
                        user_id=user_id or "",
                        application_id=app_id,
                    )

            # Emit session_id so the frontend can track this chat session
            await _emit(builder.session_update(run_id, session_id))

            # What this request has already asked for and been told, same as
            # the non-streaming path. Read before planning so the planner sees
            # it as settled fact rather than re-deciding from scratch.
            clarification_state = slot_tracker.from_context(session.context_data or {})
            if (
                clarification_state.is_active
                and session.conversation_state == "awaiting_clarification"
            ):
                clarification_state = slot_tracker.learned(
                    clarification_state, reply=user_input
                )

            # ---- Step 1: Pre-guardrails ----
            await _update_step("step_guardrails", "running")
            guardrail_categories = await self._get_guardrail_category_names(db, app)
            pre_guard = self._guardrails.pre_process(
                user_input,
                guardrail_categories=guardrail_categories,
                guardrail_text=app.guardrail_text,
            )
            trace_data["guardrail_input"] = {
                "is_safe": pre_guard.is_safe,
                "violations": pre_guard.violations,
                "categories_triggered": pre_guard.categories_triggered,
            }

            if not pre_guard.is_safe:
                guard_output = "Blocked: " + ", ".join(pre_guard.violations)
                await _update_step(
                    "step_guardrails", "failed",
                    "Input blocked by safety filters",
                    output=guard_output,
                )
                violation_msg = (
                    "Your message was blocked by safety filters. "
                    f"Violations: {', '.join(pre_guard.violations)}"
                )
                await chat_repo.add_message(
                    db, session_id, "user", user_input,
                    guardrail_flags=trace_data["guardrail_input"],
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await chat_repo.add_message(
                    db, session_id, "assistant", violation_msg,
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await _emit(builder.final_output_update(run_id, violation_msg))
                return

            await _update_step(
                "step_guardrails", "completed", "",
                output="Safe",
            )

            # ---- HITL state check ----
            effective_prompt = user_input
            conversation_state, _session_ctx_data = await self._release_upload_pause(
                chat_repo, db, session,
                chat_session_id=session_id,
                user_id=user_id,
                application_id=app_id,
            )
            if (
                conversation_state == "awaiting_clarification"
                and _session_ctx_data.get("hitl_state")
            ):
                await _emit(builder.final_output_update(
                    run_id,
                    "This session is paused for human review. Use the review panel to continue.",
                ))
                return

            # This chat's uploads, read once from Postgres for the whole turn.
            uploads = await self._session_uploads(chat_repo, db, session_id)
            conversation_state = self._answers_upload_request(
                conversation_state, _session_ctx_data, uploads, trace_data
            )

            if conversation_state == "awaiting_clarification":
                clarification_ctx = await self._hitl_manager.get_clarification_context(db, session_id)
                if clarification_ctx:
                    effective_prompt = await self._hitl_manager.build_clarification_prompt(
                        original_prompt=clarification_ctx.get("original_prompt", user_input),
                        clarification_answer=user_input,
                        partial_analysis=clarification_ctx.get("partial_analysis", ""),
                        conversation_window=clarification_ctx.get("conversation_window"),
                    )

            # ---- Step 2: Enhance prompt ----
            await _update_step("step_enhance", "running")
            persona_prompt = await self._persona_formatter.build_persona_prompt(
                db,
                persona_id=str(app.persona_id) if app.persona_id else None,
                persona_text=app.persona_text,
            )

            # Fetch conversation history before enhance so follow-up
            # references can be resolved (e.g. "give me more details")
            history_messages = await chat_repo.get_messages(db, session_id, limit=8)
            conversation_history = [
                {"role": msg.role, "content": msg.content}
                for msg in history_messages
            ]

            # Same application LLM as the non-streaming path, resolved once for
            # this turn and shared by the enhancer and the planner.
            llm_selection = await resolve_app_llm_selection(app_id, db=db)
            trace_data["orchestration_llm"] = llm_selection.describe()

            enhancement = await self._prompt_enhancer.enhance(
                effective_prompt, app_id=app_id, user_id=user_id,
                conversation_history=conversation_history,
                llm_selection=llm_selection,
            )
            enhanced_prompt = enhancement.get("enhanced_prompt", effective_prompt)
            trace_data["enhanced_prompt"] = enhanced_prompt
            trace_data["detected_intent"] = enhancement.get("detected_intent")
            trace_data["intent_confidence"] = enhancement.get("confidence")

            await _update_step(
                "step_enhance", "completed", "",
                output=enhanced_prompt[:200],
            )

            # ---- Step 3: RAG retrieval ----
            # Identical resolution to run(), through the one shared helper.
            await _update_step("step_rag", "running")
            turn_context = await self._resolve_turn_context(
                app=app,
                db=db,
                chat_repo=chat_repo,
                chat_session_id=session_id,
                user_id=user_id or "",
                enhanced_prompt=enhanced_prompt,
                trace_data=trace_data,
                llm_selection=llm_selection,
                uploads=uploads,
            )
            document_context = turn_context.document_context
            knowledge_context_stream = turn_context.knowledge_context
            mcp_data_source_context_stream = turn_context.mcp_context
            db_data_source_context_stream = turn_context.db_context
            tabular_files_stream = turn_context.as_tabular_list()

            if document_context and str(document_context).strip():
                rag_output = (
                    document_context[:200] + "..."
                    if len(document_context) > 200
                    else document_context
                )
                rag_label = "Documents found"
            else:
                rag_output = "No indexed uploads for this session yet, or extraction failed — check document status."
                rag_label = "No documents"
            await _update_step(
                "step_rag", "completed",
                rag_label,
                output=rag_output,
            )

            # ---- Step 4: Plan execution ----
            await _update_step("step_plan", "running")
            skill_manifest = await self._manifest_builder.build_manifest(db, app_id)
            trace_data["skill_count"] = len(skill_manifest.get("skills", []))

            app_tags = await self._get_tag_names(db, app)
            app_designations = await self._get_designation_names(db, app)
            app_business_units = await self._get_business_unit_names(db, app)
            app_data_sources = await self._get_data_source_names(db, app)

            # Append linked knowledge base names (mirrors run() step)
            kb_names = await self._get_knowledge_base_names(db, app)
            if kb_names:
                app_data_sources = list(app_data_sources) + [
                    f"{name} (knowledge base)" for name in kb_names
                ]

            guardrail_rules_text = app.guardrail_text or ""

            async def _plan(
                known_text: str, replan_note: str = ""
            ) -> Dict[str, Any]:
                """One planning call. Only the two correction inputs vary."""
                return await self._orchestrator.plan(
                    enhanced_prompt=enhanced_prompt,
                    skill_manifest=skill_manifest,
                    conversation_history=conversation_history,
                    persona_prompt=persona_prompt,
                    guardrail_rules=guardrail_rules_text,
                    document_context=document_context,
                    app_tags=app_tags,
                    app_designations=app_designations,
                    app_business_units=app_business_units,
                    app_name=app.name,
                    app_description=app.description,
                    app_disclaimer=app.disclaimer,
                    app_data_sources=app_data_sources,
                    app_id=app_id,
                    user_id=user_id,
                    tabular_files=tabular_files_stream,
                    knowledge_context=knowledge_context_stream,
                    mcp_data_sources_context=mcp_data_source_context_stream,
                    db_data_sources_context=db_data_source_context_stream,
                    llm_selection=llm_selection,
                    available_evidence=available_evidence(turn_context.ledger),
                    known_text=known_text,
                    rounds_used=clarification_state.round,
                    rounds_max=slot_tracker.max_rounds(),
                    original_prompt=clarification_state.original_prompt,
                    replan_note=replan_note,
                )

            orchestrator_output = await _plan(clarification_state.known_text())

            # Reconcile a direct answer that should have been a route. The
            # non-streaming path detected this state and logged it; this path
            # did neither, which is why an application with a workflow attached
            # answered in the model's own prose and never invoked it.
            orchestrator_output, routing_reconciliation = (
                await self._reconcile_unrouted_answer(
                    orchestrator_output,
                    skill_manifest,
                    clarification_state.known_text(),
                    _plan,
                )
            )
            if routing_reconciliation is not None:
                trace_data["routing_reconciliation"] = routing_reconciliation

            # Reconcile a false ask against the ledger, identical to the
            # non-streaming path.
            orchestrator_output, reconciliation = await self._reconcile_false_ask(
                orchestrator_output,
                turn_context.ledger,
                clarification_state.known_text(),
                _plan,
            )
            if reconciliation is not None:
                trace_data["evidence_reconciliation"] = reconciliation.describe()

            # Evidence Gate, identical to the non-streaming path.
            orchestrator_output, gate_result = await self._gate_turn(
                orchestrator_output,
                ledger=turn_context.ledger,
                skill_manifest=skill_manifest,
                known_text=clarification_state.known_text(),
                replan=_plan,
                uploads=uploads,
                trace_data=trace_data,
            )

            # Same termination guarantee as the non-streaming path.
            orchestrator_output, clarification_state = self._apply_clarification_budget(
                orchestrator_output, clarification_state, user_input
            )
            trace_data["clarification"] = clarification_state.describe()
            trace_data["orchestrator_plan"] = orchestrator_output

            await _update_step(
                "step_plan", "completed", "",
                output=orchestrator_output.get("reasoning", "")[:200],
            )

            # ---- Handle HITL response ----
            hitl_action = await self._hitl_manager.handle_orchestrator_response(
                db, session_id, orchestrator_output, enhanced_prompt,
                conversation_history=conversation_history,
            )
            action = hitl_action.get("action")

            if action == "clarify":
                clarification_msg = hitl_action.get("message", "Could you clarify?")
                # Carry the round counter and what is known into the next turn.
                try:
                    await chat_repo.update_session_state(
                        db,
                        session_id,
                        conversation_state="awaiting_clarification",
                        context_data={
                            **(session.context_data or {}),
                            slot_tracker.CONTEXT_KEY: clarification_state.to_context(),
                            # Read next turn by ``_answers_upload_request``.
                            "awaiting_upload": bool(
                                orchestrator_output.get("awaiting_upload")
                            ),
                        },
                        user_id=user_id or "",
                        application_id=app_id,
                    )
                except Exception:
                    logger.warning(
                        "Could not persist clarification state for session %s",
                        session_id, exc_info=True,
                    )
                await chat_repo.add_message(
                    db, session_id, "user", user_input,
                    enhanced_prompt=enhanced_prompt,
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await chat_repo.add_message(
                    db, session_id, "assistant", clarification_msg,
                    execution_trace={"type": "clarification"},
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await _update_step("step_post_guard", "skipped")
                await _emit(builder.final_output_update(run_id, clarification_msg))
                return

            if action == "fallback":
                fallback_msg = hitl_action.get("message", "")
                is_conversational = hitl_action.get("is_conversational", False)

                if is_conversational:
                    # Composed, exactly as the non-streaming path does it: the
                    # planner's ``message`` is a routing field, not an answer.
                    full_fallback = await self._compose_response(
                        user_message=user_input,
                        fallback_text=fallback_msg,
                        orchestrator_output=orchestrator_output,
                        app=app,
                        persona_prompt=persona_prompt,
                        guardrail_rules=guardrail_rules_text,
                        available_evidence=available_evidence(turn_context.ledger),
                        # See the non-streaming path: an answer-directly turn
                        # runs no skill, so this is the only route the retrieved
                        # text has to the answer.
                        retrieved_context=turn_context.retrieved_text(),
                        seed_answer=fallback_msg,
                        llm_selection=llm_selection,
                        app_id=app_id,
                        user_id=user_id,
                        trace_data=trace_data,
                    )
                else:
                    sorry = app.sorry_message or ""
                    if sorry and fallback_msg:
                        full_fallback = f"{sorry}\n\n{fallback_msg}"
                    elif sorry:
                        full_fallback = sorry
                    else:
                        full_fallback = fallback_msg
                    skills = skill_manifest.get("skills", [])
                    if skills:
                        skill_summary = ", ".join(
                            f"{s['name']} ({s['skill_type']})" for s in skills
                        )
                        full_fallback += (
                            f"\n\nI can help you with: {skill_summary}. "
                            "Please ask me something related to these capabilities."
                        )

                await chat_repo.add_message(
                    db, session_id, "user", user_input,
                    enhanced_prompt=enhanced_prompt,
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await chat_repo.add_message(
                    db, session_id, "assistant", full_fallback,
                    execution_trace={
                        "type": "fallback", "fallback": True,
                        "is_conversational": is_conversational,
                    },
                    user_id=user_id or "",
                    application_id=app_id,
                )
                await _update_step("step_post_guard", "skipped")
                await _emit(builder.final_output_update(run_id, full_fallback))
                return

            # ---- Step 5: Execute skills ----
            # Insert dynamic per-skill steps before post_guard based on plan.
            plan = orchestrator_output.get("execution_plan", [])
            strategy = orchestrator_output.get("execution_strategy", "single")

            for idx, plan_step in enumerate(plan):
                skill_name = plan_step.get("skill_name", plan_step.get("skill_id", f"skill_{idx + 1}"))
                skill_step = {
                    "id": f"step_skill_{idx + 1}",
                    "icon": "play_circle",
                    "label": f"Running: {skill_name}",
                    "detail": plan_step.get("skill_type", "workflow"),
                    "status": "pending",
                    "output": "",
                }
                steps.insert(_post_guard_idx + idx, skill_step)

            # Emit updated steps array so frontend sees the skill steps
            if plan:
                await _emit(builder.step_update(run_id, steps))

            # Mark all skill steps as running
            for idx in range(len(plan)):
                await _update_step(f"step_skill_{idx + 1}", "running")

            # Subscribe raw_queue to ws_manager so workflow transparency
            # events route there (NOT directly to sse_queue).
            ws_manager.subscribe_queue(run_id, raw_queue)

            # Start translator task that converts raw transparency events
            # into A2UI format and puts them on sse_queue.
            translator_task = asyncio.create_task(
                _translate_transparency_events()
            )

            try:
                execution_result = await self._skill_executor.execute_plan(
                    db=db,
                    execution_plan=plan,
                    execution_strategy=strategy,
                    user_input=enhanced_prompt,
                    document_context=document_context,
                    tabular_files=tabular_files_stream,
                    knowledge_context=knowledge_context_stream,
                    mcp_data_source_context=mcp_data_source_context_stream,
                    # Same two additions as run(): the database context that
                    # never reached the executor, and the application's
                    # datasources as capability.
                    db_data_source_context=db_data_source_context_stream,
                    application_context=turn_context.application_contribution,
                    evidence_notes=[
                        note
                        for note in (
                            gate_result.satisfied_note(), gate_result.caveat_note()
                        )
                        if note
                    ],
                    conversation_history=conversation_history,
                    run_id=run_id,
                    sse_queue=sse_queue,
                    app_id=app_id,
                    user_id=user_id,
                    chat_session_id=session_id,
                    application_id=app_id,
                    on_activity=_agent_activity,
                )
            finally:
                # Unsubscribe and stop the translator
                ws_manager.unsubscribe_queue(run_id, raw_queue)
                # Signal translator to stop by putting None sentinel
                try:
                    raw_queue.put_nowait(None)
                except asyncio.QueueFull:
                    pass
                # Wait for translator to finish (with timeout)
                if translator_task is not None:
                    try:
                        await asyncio.wait_for(translator_task, timeout=5.0)
                    except (asyncio.TimeoutError, asyncio.CancelledError):
                        translator_task.cancel()
                        try:
                            await translator_task
                        except asyncio.CancelledError:
                            pass

            # Check for HITL interrupt
            if execution_result.get("hitl_interrupted"):
                for idx in range(len(plan)):
                    step_id = f"step_skill_{idx + 1}"
                    for s in steps:
                        if s["id"] == step_id and s["status"] == "running":
                            s["status"] = "interrupted"
                            s["detail"] = "Paused for human review"
                            break
                await _emit(builder.step_update(run_id, steps))
                await _update_step("step_post_guard", "skipped")

                # Extract interrupt context for file_upload distinction
                _hitl_interrupt = execution_result.get("interrupt_payload", {})
                _stream_interrupt_ctx = _hitl_interrupt.get("interrupt", {})
                if _stream_interrupt_ctx.get("interrupt_type") == "file_upload":
                    _hitl_msg = f"Workflow paused \u2014 {_stream_interrupt_ctx.get('message', 'please upload the required document.')}"
                else:
                    _hitl_msg = "Workflow paused for human review."

                # Persist HITL state so resume endpoints can pick it up
                _stream_hitl_state_data = {
                    "hitl_state": {
                        "run_id": execution_result.get("run_id", ""),
                        "workflow_id": execution_result.get("workflow_id", ""),
                        "fs_workflow_id": _hitl_interrupt.get("fs_workflow_id", ""),
                        "interrupt_payload": _stream_interrupt_ctx,
                        "interrupt_type": _stream_interrupt_ctx.get("interrupt_type", "hitl"),
                        "completed_steps": execution_result.get("completed_steps", []),
                        "remaining_plan": execution_result.get("remaining_plan", []),
                        "execution_plan": plan,
                        "execution_strategy": strategy,
                        "enhanced_prompt": enhanced_prompt,
                        "knowledge_context": knowledge_context_stream,
                    }
                }
                await chat_repo.update_session_state(
                    db,
                    session_id,
                    conversation_state="awaiting_clarification",
                    context_data=_stream_hitl_state_data,
                    user_id=user_id or "",
                    application_id=app_id,
                )

                await _emit(builder.final_output_update(run_id, _hitl_msg))
                return

            # Mark all skill steps as completed with their output.
            # Also finalize any sub-steps (wf_*) that are still showing
            # as "running" -- they belong to the translator task that has
            # already been stopped.
            exec_log = execution_result.get("execution_log", [])
            exec_results = execution_result.get("results", {})
            for idx in range(len(plan)):
                step_id = f"step_skill_{idx + 1}"
                # Find matching log entry
                log_entry = None
                if idx < len(exec_log):
                    log_entry = exec_log[idx]
                skill_output = ""
                if log_entry:
                    output_key = plan[idx].get(
                        "output_key", f"step_{plan[idx].get('step', idx + 1)}_output"
                    )
                    result_text = exec_results.get(output_key, "")
                    if plan[idx].get("skill_type") == "agent":
                        skill_output = result_text[:300] if isinstance(result_text, str) else str(result_text)[:300]
                    else:
                        skill_output = result_text[:300] if isinstance(result_text, str) else str(result_text)[:300]
                    status = log_entry.get("status", "completed")
                else:
                    status = "completed"
                await _update_step(step_id, status, output=skill_output)

            # Finalize any sub-steps still showing as "running"
            for s in steps:
                if s["id"].startswith("wf_") and s["status"] == "running":
                    s["status"] = "completed"
            await _emit(builder.step_update(run_id, steps))

            final_output = execution_result.get("final_output", "")

            logger.info(
                "EXECUTION_FINAL_OUTPUT_LEN=%d",
                len(str(final_output or ""))
            )

            logger.info(
                "EXECUTION_FINAL_OUTPUT=%s",
                final_output,
            )

            # Compose the answer, identically to the non-streaming path. This is
            # the path an application chat actually takes, so a workflow ending
            # in a document generator is composed here: the substance first, the
            # download link last, and the link re-attached in code if the
            # composed text dropped it.
            final_output = await self._compose_response(
                user_message=user_input,
                fallback_text=final_output,
                execution_result=execution_result,
                orchestrator_output=orchestrator_output,
                app=app,
                persona_prompt=persona_prompt,
                guardrail_rules=guardrail_rules_text,
                available_evidence=available_evidence(turn_context.ledger),
                llm_selection=llm_selection,
                app_id=app_id,
                user_id=user_id,
                trace_data=trace_data,
            )

            trace_data["execution_result"] = execution_result.get("results", {})
            trace_data["execution_log"] = execution_result.get("execution_log", [])

            # ---- Step 6: Post-guardrails ----
            await _update_step("step_post_guard", "running")
            post_guard = self._guardrails.post_process(
                final_output,
                guardrail_categories=guardrail_categories,
                guardrail_text=app.guardrail_text,
            )
            trace_data["guardrail_output"] = {
                "is_safe": post_guard.is_safe,
                "violations": post_guard.violations,
                "categories_triggered": post_guard.categories_triggered,
            }
            final_output = _sanitize_for_ui(post_guard.sanitized_text)
            await _update_step(
                "step_post_guard", "completed", "",
                output="Safe" if post_guard.is_safe else "Flagged",
            )

            # ---- Save messages ----
            await chat_repo.add_message(
                db, session_id, "user", user_input,
                enhanced_prompt=enhanced_prompt,
                user_id=user_id or "",
                application_id=app_id,
            )
            await chat_repo.add_message(
                db, session_id, "assistant", final_output,
                execution_trace=trace_data,
                guardrail_flags=trace_data.get("guardrail_output"),
                user_id=user_id or "",
                application_id=app_id,
            )

            # ---- Save execution trace ----
            total_duration_ms = int((time.monotonic() - pipeline_start) * 1000)
            trace_data["total_duration_ms"] = total_duration_ms
            try:
                await chat_repo.create_execution_trace(
                    db,
                    application_id=app_id,
                    chat_session_id=session_id,
                    user_message=user_input,
                    enhanced_prompt=enhanced_prompt,
                    orchestrator_plan=orchestrator_output,
                    execution_result=execution_result.get("results"),
                    skills_invoked=execution_result.get("execution_log"),
                    guardrail_input=trace_data.get("guardrail_input"),
                    guardrail_output=trace_data.get("guardrail_output"),
                    total_duration_ms=total_duration_ms,
                    status="completed",
                )
            except Exception:
                logger.exception("Failed to save execution trace")

            await chat_repo.update_session_state(
                db, session_id, conversation_state="awaiting_input",
                user_id=user_id or "",
                application_id=app_id,
            )

            # ---- Emit final output ----
            await _emit(builder.final_output_update(run_id, final_output))
            await _emit(builder.session_update(run_id, session_id))

        except Exception as exc:
            logger.exception("run_stream failed for run_id=%s", run_id)
            # Try to mark the last running step as failed
            for s in reversed(steps):
                if s["status"] == "running":
                    s["status"] = "failed"
                    s["detail"] = str(exc)[:120]
                    break
            try:
                await _emit(builder.step_update(run_id, steps))
                await _emit(builder.final_output_update(
                    run_id, f"Pipeline error: {exc}",
                ))
            except Exception:
                pass
        finally:
            # Clean up translator task if still running
            if translator_task is not None and not translator_task.done():
                translator_task.cancel()
                try:
                    await translator_task
                except asyncio.CancelledError:
                    pass

            # Settle every step that is still marked running, and emit one last
            # step_update before the stream closes.
            #
            # WHY: a step is marked completed by its own ``step_completed``
            # event. Any step whose event never arrives -- coalesced away,
            # dropped when ``raw_queue`` was full (it is ``put_nowait`` with
            # ``maxsize=500``), or simply never emitted on an early return --
            # stays ``running`` in the client forever. The final answer rendered
            # correctly while seven agents kept spinning, and only a page reload
            # cleared them, because nothing after the answer ever revised their
            # status.
            #
            # This runs in ``finally``, which is the one place all ten exit
            # paths converge: success, guardrail violation, clarification,
            # HITL pause, fallback and every error return. Settling here rather
            # than at each site is what makes it hold for paths added later.
            #
            # Additive and backward compatible: it emits the message the client
            # already handles on every update, carrying the same steps array
            # with only terminal statuses. A client that ignores it is no worse
            # off than today.
            try:
                settled = 0
                for _step in steps:
                    if _step.get("status") == "running":
                        _step["status"] = "completed"
                        settled += 1
                    for _sub in _step.get("sub_steps") or []:
                        if isinstance(_sub, dict) and _sub.get("status") == "running":
                            _sub["status"] = "completed"
                            settled += 1

                if settled:
                    logger.info(
                        "\n"
                        "  ┌─ RUN SETTLED ─ run %s\n"
                        "  │  steps left running at close : %d\n"
                        "  └─ marked completed so the client stops showing them\n"
                        "     as in progress. A step reaching this point produced\n"
                        "     its result; only its completion event was missing.",
                        run_id, settled,
                    )
                await _emit(builder.step_update(run_id, steps))
            except Exception:  # noqa: BLE001 -- never block the sentinel below
                logger.debug(
                    "Final step settle failed for run %s", run_id, exc_info=True
                )

            # Always put sentinel so SSE generator terminates
            try:
                await sse_queue.put(None)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------

    @staticmethod
    async def _get_guardrail_category_names(db: AsyncSession, app) -> List[str]:
        """Extract guardrail category names from app's guardrail links."""
        if not app.guardrail_links:
            return []

        from echolib.models.application_lookups import AppGuardrailCategory
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        category_ids = []
        for link in app.guardrail_links:
            uid = safe_uuid(str(link.guardrail_category_id))
            if uid:
                category_ids.append(uid)

        if not category_ids:
            return []

        stmt = select(AppGuardrailCategory).where(
            AppGuardrailCategory.guardrail_category_id.in_(category_ids)
        )
        result = await db.execute(stmt)
        categories = result.scalars().all()
        return [cat.name for cat in categories]

    @staticmethod
    async def _get_tag_names(db: AsyncSession, app) -> List[str]:
        """Extract tag names from app's tag links."""
        if not app.tag_links:
            return []

        from echolib.models.application_lookups import AppTag
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        tag_ids = []
        for link in app.tag_links:
            uid = safe_uuid(str(link.tag_id))
            if uid:
                tag_ids.append(uid)

        if not tag_ids:
            return []

        stmt = select(AppTag).where(AppTag.tag_id.in_(tag_ids))
        result = await db.execute(stmt)
        tags = result.scalars().all()
        return [t.name for t in tags]

    @staticmethod
    async def _get_designation_names(db: AsyncSession, app) -> List[str]:
        """Extract designation names from app's designation links."""
        if not app.designation_links:
            return []

        from echolib.models.application_lookups import AppDesignation
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        ids = []
        for link in app.designation_links:
            uid = safe_uuid(str(link.designation_id))
            if uid:
                ids.append(uid)

        if not ids:
            return []

        stmt = select(AppDesignation).where(AppDesignation.designation_id.in_(ids))
        result = await db.execute(stmt)
        return [d.name for d in result.scalars().all()]

    @staticmethod
    async def _get_business_unit_names(db: AsyncSession, app) -> List[str]:
        """Extract business unit names from app's business unit links."""
        if not app.business_unit_links:
            return []

        from echolib.models.application_lookups import AppBusinessUnit
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        ids = []
        for link in app.business_unit_links:
            uid = safe_uuid(str(link.business_unit_id))
            if uid:
                ids.append(uid)

        if not ids:
            return []

        stmt = select(AppBusinessUnit).where(AppBusinessUnit.business_unit_id.in_(ids))
        result = await db.execute(stmt)
        return [bu.name for bu in result.scalars().all()]

    @staticmethod
    async def _get_data_source_names(db: AsyncSession, app) -> List[str]:
        """Extract data source names from app's data source links."""
        if not app.data_source_links:
            return []

        from echolib.models.application_lookups import AppDataSource
        from sqlalchemy import select

        ds_ids = [link.data_source_id for link in app.data_source_links]
        if not ds_ids:
            return []

        stmt = select(AppDataSource).where(
            AppDataSource.data_source_id.in_(ds_ids)
        )
        result = await db.execute(stmt)
        return [ds.name for ds in result.scalars().all()]
    
    @staticmethod
    async def _get_knowledge_base_names(db: AsyncSession, app) -> List[str]:
        """Extract knowledge base names from app's knowledge base links
        AND data source links that reference knowledge bases."""
        from echolib.models.knowledge import KnowledgeBase
        from echolib.repositories.base import safe_uuid
        from sqlalchemy import select

        ids = []
        # Source 1: explicit KB links
        for link in (app.knowledge_base_links or []):
            uid = safe_uuid(str(link.knowledge_base_id))
            if uid:
                ids.append(uid)
        # Source 2: data source links (may contain KB UUIDs)
        for link in (app.data_source_links or []):
            uid = safe_uuid(str(link.data_source_id))
            if uid and uid not in ids:
                ids.append(uid)

        if not ids:
            return []

        stmt = select(KnowledgeBase).where(
            KnowledgeBase.id.in_(ids),
            KnowledgeBase.is_deleted == False,  # noqa: E712
        )
        result = await db.execute(stmt)
        return [kb.name for kb in result.scalars().all()]

    @staticmethod
    async def _materialize_tabular(doc) -> Optional[Dict[str, Any]]:
        """
        Give one tabular upload a readable local path.

        WHAT: Returns ``{"file_path", "filename"}``, writing the file back from
              Postgres when this replica does not already hold it.
        WHY:  Spreadsheet analysis takes a path. The uploaded file lives under
              ``APP_UPLOADS_DIR``, which is local to the container that
              received it — so after a restart, a redeploy, or a request routed
              to another replica, the path existed in the ledger and not on
              disk, and the skill produced an empty answer instead of an error.
        OUTPUT: ``None`` when no copy can be produced, so an unreadable
                document is dropped from the skill's inputs rather than handed
                over as a path that does not resolve.
        """
        from apps.appmgr import document_store
        from echolib.database import get_db_session

        try:
            async with get_db_session() as db:
                path = await document_store.materialize_stored(db, doc.stored_filename)
        except Exception:
            logger.warning(
                "Could not materialize tabular file '%s'", doc.stored_filename,
                exc_info=True,
            )
            path = None

        if not path:
            return None

        return {"file_path": path, "filename": doc.filename}

    @staticmethod
    async def _retrieve_knowledge_context(
        app,
        user_id: str,
        query: str,
        *,
        ledger: Optional[Any] = None,
        max_total_chars: int = 100000,
        timeout_sec: float = 30.0,
    ) -> Optional[str]:
        """Retrieve full document content from linked knowledge bases.

        Two-phase approach using **direct column-level SELECTs** (no ORM
        relationship traversal on detached objects):

          Phase 1 — Load ``docling_markdown`` text from ``KnowledgeDocument``
                    rows via explicit column SELECT inside the DB session.
                    Returns plain Python tuples — no detachment risk.
          Phase 2 — Fallback: if no docling_markdown exists (legacy KBs or
                    column missing from DB), use ``retriever.search()`` with
                    a high ``top_k`` to maximise coverage.

        Returns a formatted context string, or ``None``.
        """
        log = logging.getLogger(__name__)

        from echolib.models.knowledge import KnowledgeBase, KnowledgeDocument
        from echolib.repositories.base import safe_uuid
        from echolib.database import get_db_session
        from sqlalchemy import select

        # ------------------------------------------------------------------
        # Collect candidate KB IDs from TWO sources:
        #   1. app.knowledge_base_links  (ApplicationKnowledgeBaseLink rows)
        #   2. app.data_source_links     (ApplicationDataSourceLink rows —
        #      the UI data-source picker returns KBs with kind="knowledge"
        #      and stores their UUID as a data_source_id string)
        # ------------------------------------------------------------------
        kb_ids: List[str] = []
        preloaded_kb_map: Dict[str, Dict[str, Any]] = {}

        # The ledger has already resolved which linked ids are knowledge bases,
        # which of them are synced, and their retrieval settings — so the
        # collection and metadata query below are skipped entirely. Retrieval
        # itself still runs per turn: it depends on the user's question, which
        # is exactly what a session-scoped cache must not hold.
        if ledger is not None:
            kb_ids = list(ledger.knowledge_base_ids)
            preloaded_kb_map = ledger.knowledge_metadata()
            if not kb_ids:
                log.info(
                    "_retrieve_knowledge_context: ledger reports no usable "
                    "knowledge bases for this application — skipping"
                )
                return None

        # Source 1: explicit KB links
        if ledger is None and app.knowledge_base_links:
            for link in app.knowledge_base_links:
                kb_ids.append(str(link.knowledge_base_id))

        # Source 2: data source links (may contain KB UUIDs)
        if ledger is None and app.data_source_links:
            for link in app.data_source_links:
                ds_id = str(link.data_source_id).strip()
                # Only consider valid UUIDs (KB IDs are UUIDs; catalog
                # data source IDs are typically short strings like "mcp-xxx")
                if safe_uuid(ds_id) is not None and ds_id not in kb_ids:
                    kb_ids.append(ds_id)

        log.warning(
            "_retrieve_knowledge_context: collected %d candidate KB IDs "
            "(from %d knowledge_base_links + %d data_source_links): %s",
            len(kb_ids),
            len(app.knowledge_base_links or []),
            len(app.data_source_links or []),
            kb_ids,
        )

        if not kb_ids:
            log.warning("_retrieve_knowledge_context: no candidate KB IDs found — skipping")
            return None

        # ------------------------------------------------------------------
        # Step A: Load synced KB metadata (plain Python dicts — no ORM detachment)
        # ------------------------------------------------------------------
        kb_map: Dict[str, Dict[str, Any]] = {}  # kb_id -> {name, processing_type, ...}
        try:
            if preloaded_kb_map:
                # Already loaded, and already filtered to synced bases, when the
                # ledger resolved this session. Skipping the query is the point:
                # it ran on every message and returned the same rows each time.
                kb_map = preloaded_kb_map
            else:
                kb_map = await OrchestrationPipeline._load_kb_metadata(kb_ids)
                if kb_map is None:
                    return None
        except Exception:
            log.warning("_retrieve_knowledge_context: failed to load KB metadata", exc_info=True)
            return None

        if not kb_map:
            log.warning(
                "_retrieve_knowledge_context: 0 synced KBs for IDs %s — "
                "check knowledge_bases table (status must be 'synced', is_deleted=false)",
                kb_ids,
            )
            return None

        log.warning(
            "_retrieve_knowledge_context: %d synced KBs found: %s",
            len(kb_map),
            {kid: info["name"] for kid, info in kb_map.items()},
        )

        return await OrchestrationPipeline._knowledge_context_from_map(
            kb_map, kb_ids, query, user_id,
            max_total_chars=max_total_chars, timeout_sec=timeout_sec,
            # A base whose metadata predates ``owner_user_id`` (a ledger cached
            # before this field existed) is embedded under the application's
            # owner, who linked it -- never under the chatting user.
            embedding_owner_id=str(getattr(app, "user_id", "") or "") or None,
        )

    @staticmethod
    async def _load_kb_metadata(
        kb_ids: List[str],
    ) -> Optional[Dict[str, Dict[str, Any]]]:
        """
        Load synced knowledge-base metadata directly.

        The pre-ledger path, unchanged in behaviour and reached only when the
        ledger is disabled or unavailable. ``None`` means "stop" — no valid
        UUIDs — which is distinct from ``{}`` meaning "none synced".
        """
        log = logging.getLogger(__name__)

        from echolib.models.knowledge import KnowledgeBase
        from echolib.repositories.base import safe_uuid
        from echolib.database import get_db_session
        from sqlalchemy import select

        kb_map: Dict[str, Dict[str, Any]] = {}
        async with get_db_session() as kb_db:
            ids_uuid = [safe_uuid(kid) for kid in kb_ids]
            ids_uuid = [u for u in ids_uuid if u is not None]
            if not ids_uuid:
                log.warning("_retrieve_knowledge_context: no valid KB UUIDs after safe_uuid")
                return None
            res = await kb_db.execute(
                select(
                    KnowledgeBase.id,
                    KnowledgeBase.name,
                    KnowledgeBase.processing_type,
                    KnowledgeBase.search_type,
                    KnowledgeBase.top_k,
                    KnowledgeBase.embedding_model,
                    KnowledgeBase.vector_weight,
                    KnowledgeBase.keyword_weight,
                    KnowledgeBase.user_id,
                ).where(
                    KnowledgeBase.id.in_(ids_uuid),
                    KnowledgeBase.is_deleted == False,  # noqa: E712
                    KnowledgeBase.status == "synced",
                )
            )
            for row in res.all():
                kb_map[str(row.id)] = {
                    "name": row.name,
                    "processing_type": row.processing_type or "vector",
                    "search_type": row.search_type or "similarity",
                    "top_k": row.top_k or 10,
                    "embedding_model": row.embedding_model,
                    "vector_weight": row.vector_weight or 0.5,
                    "keyword_weight": row.keyword_weight or 0.5,
                    # The base's owner: its passages were embedded with that
                    # account's credential, so queries are embedded there too.
                    "owner_user_id": str(row.user_id) if row.user_id else None,
                }
        return kb_map

    @staticmethod
    async def _knowledge_context_from_map(
        kb_map: Dict[str, Dict[str, Any]],
        kb_ids: List[str],
        query: str,
        user_id: str,
        *,
        max_total_chars: int = 100000,
        timeout_sec: float = 30.0,
        embedding_owner_id: Optional[str] = None,
    ) -> Optional[str]:
        """
        Retrieve knowledge content for ``query`` against already-resolved bases.

        Split out from ``_retrieve_knowledge_context`` so the *resolution* of
        which bases exist can be cached per session while *retrieval* stays per
        turn — it depends on the user's question and must never be cached.
        Phases 1 and 2 below are unchanged.
        """
        log = logging.getLogger(__name__)

        from echolib.models.knowledge import KnowledgeDocument
        from echolib.repositories.base import safe_uuid
        from echolib.database import get_db_session
        from sqlalchemy import select

        # ------------------------------------------------------------------
        # Phase 1: Load full docling_markdown via direct column SELECT
        # ------------------------------------------------------------------
        # Query KnowledgeDocument columns directly — extract as plain tuples
        # INSIDE the session.  No ORM object detachment risk.
        #
        # IMPORTANT: Phase 1 loads full documents WITHOUT query relevance
        # filtering.  This only makes sense for single-document KBs where
        # the user clearly wants all content.  For multi-document KBs the
        # full-document dump can exceed the char budget, mix irrelevant
        # documents, and cause hallucinated responses.  In that case we
        # skip straight to Phase 2 (query-relevant chunk retrieval).
        #
        # "Single-document" is a property of a *knowledge base*, not of the
        # linked set. This condition used to be ``total_completed_docs == 1``
        # counted across every linked base, so two bases holding one small
        # document each -- the ordinary case for an application with a couple of
        # PDFs attached -- failed a test they actually satisfy, and their text
        # was skipped in favour of a vector search that then returned nothing.
        # Together with the budget check below, that is the whole of the
        # original intent: don't dump a corpus, do pass a document.
        doc_rows: List[tuple] = []  # (kb_id, kb_name, filename, markdown_text)
        docs_per_kb: Dict[str, int] = {}
        phase1_failed = False
        total_completed_docs = 0
        try:
            async with get_db_session() as doc_db:
                kb_id_uuids = [safe_uuid(kid) for kid in kb_map]
                kb_id_uuids = [u for u in kb_id_uuids if u is not None]
                res = await doc_db.execute(
                    select(
                        KnowledgeDocument.knowledge_base_id,
                        KnowledgeDocument.original_filename,
                        KnowledgeDocument.docling_markdown,
                        KnowledgeDocument.processing_status,
                    ).where(
                        KnowledgeDocument.knowledge_base_id.in_(kb_id_uuids),
                        KnowledgeDocument.processing_status == "completed",
                    )
                )
                for row in res.all():
                    total_completed_docs += 1
                    kb_id_str = str(row.knowledge_base_id)
                    docs_per_kb[kb_id_str] = docs_per_kb.get(kb_id_str, 0) + 1
                    kb_name = kb_map.get(kb_id_str, {}).get("name", kb_id_str)
                    md = (row.docling_markdown or "").strip()
                    log.warning(
                        "_retrieve_knowledge_context: doc '%s' (KB '%s'): "
                        "docling_markdown=%s",
                        row.original_filename,
                        kb_name,
                        f"{len(md)} chars" if md else "NULL/EMPTY",
                    )
                    if md:
                        doc_rows.append((kb_id_str, kb_name, row.original_filename, md))
        except Exception as exc:
            # Column might not exist in DB (migration not run) — log and fall through
            log.warning(
                "_retrieve_knowledge_context: Phase 1 docling_markdown query failed "
                "(column may not exist in DB): %s",
                exc,
            )
            phase1_failed = True

        # Use Phase 1 full-document loading only when every linked base holds a
        # single document and the whole lot fits the budget uncut. Both halves
        # matter: the first keeps unrelated documents out of the prompt, the
        # second keeps a large corpus from consuming the entire context and
        # arriving truncated mid-sentence.
        multi_doc_kbs = sorted(
            kb_id for kb_id, count in docs_per_kb.items() if count > 1
        )
        phase1_chars = sum(len(md) + len(filename) + 64 for _, _, filename, md in doc_rows)
        fits_budget = phase1_chars <= max_total_chars

        use_phase1 = (
            not phase1_failed
            and bool(doc_rows)
            and not multi_doc_kbs
            and fits_budget
        )

        if doc_rows and not use_phase1 and not phase1_failed:
            if multi_doc_kbs:
                log.info(
                    "_retrieve_knowledge_context: %d of %d linked knowledge base(s) "
                    "hold more than one document (%s) — using Phase 2 "
                    "query-relevant retrieval instead of a full-document load",
                    len(multi_doc_kbs), len(kb_map), ", ".join(multi_doc_kbs),
                )
            else:
                log.info(
                    "_retrieve_knowledge_context: the linked documents total "
                    "%d chars, over the %d-char budget — using Phase 2 "
                    "query-relevant retrieval instead of a full-document load",
                    phase1_chars, max_total_chars,
                )

        # Assemble context from docling_markdown (single-doc case only)
        if use_phase1:
            sections: List[str] = []
            total_chars = 0
            for kb_id_str, kb_name, filename, md in doc_rows:
                header = f"=== KNOWLEDGE BASE: {kb_name} | DOCUMENT: {filename} ==="
                section = f"{header}\n{md}"
                if total_chars + len(section) > max_total_chars:
                    remaining = max_total_chars - total_chars
                    if remaining > len(header) + 200:
                        section = section[:remaining] + "\n... [truncated]"
                        sections.append(section)
                        total_chars += len(section)
                    break
                sections.append(section)
                total_chars += len(section)
                if total_chars >= max_total_chars:
                    break

            if sections:
                assembled = "\n\n".join(sections)
                log.warning(
                    "_retrieve_knowledge_context: Phase 1 SUCCESS — "
                    "%d documents, %d chars assembled",
                    len(sections), len(assembled),
                )
                return assembled

        # ------------------------------------------------------------------
        # Phase 2 fallback: retriever.search() with high top_k
        # ------------------------------------------------------------------
        if phase1_failed:
            log.warning(
                "_retrieve_knowledge_context: Phase 1 failed (DB error); "
                "trying Phase 2 search fallback"
            )
        elif not doc_rows:
            log.warning(
                "_retrieve_knowledge_context: Phase 1 found 0 documents with "
                "docling_markdown across %d KBs; trying Phase 2 search fallback",
                len(kb_map),
            )
        else:
            # Reaching here with documents in hand is a *choice*, not a failure.
            # This branch used to log "found 0 documents" unconditionally, which
            # was false whenever Phase 1 was skipped rather than empty, and sent
            # every investigation of this path looking for missing text that was
            # never missing.
            log.info(
                "_retrieve_knowledge_context: Phase 1 has %d document(s) but was "
                "not used; trying Phase 2 query-relevant retrieval",
                len(doc_rows),
            )

        # Resolve knowledge.service for embeddings helper
        try:
            from echolib.di import container as di_container
            knowledge_service = di_container.resolve("knowledge.service")
        except KeyError:
            log.warning("_retrieve_knowledge_context: knowledge.service not registered in DI; cannot search")
            return None

        from apps.knowledge import retriever as kb_retriever

        async def _search_one_kb(kb_id: str, kb_info: Dict) -> List[str]:
            processing_type = kb_info["processing_type"]
            search_type = kb_info["search_type"]
            effective_top_k = max(20, kb_info["top_k"])
            try:
                embeddings = None
                if processing_type in ("vector", "hybrid"):
                    # Off the loop, deliberately. ``_get_embeddings`` resolves the
                    # user's credential through ``resolve_llm_credential_sync``,
                    # which refuses to run on the event-loop thread and returns
                    # None there -- so calling it from this coroutine silently
                    # dropped to ``llm_factory.get_default_model()`` and raised
                    # ModelNotFoundError on every deployment that configures no
                    # platform default. Retrieval then returned zero chunks while
                    # the planner was still being told the knowledge base was
                    # available evidence.
                    #
                    # Both the passage lookup and the credential resolution are
                    # synchronous, so they share the one worker thread rather
                    # than taking two.
                    def _resolve_embeddings() -> Any:
                        from apps.knowledge import chunk_store

                        return knowledge_service._get_embeddings(
                            kb_info.get("embedding_model"),
                            # The base owner's account, not the caller's: a
                            # shared application's user cannot reach the
                            # embedding credential the passages were indexed
                            # with.
                            user_id=(
                                kb_info.get("owner_user_id")
                                or embedding_owner_id
                                or user_id
                            ),
                            # The model the passages were actually indexed with
                            # outranks the configured one: a vector index can
                            # only be read by the model that wrote it.
                            indexed_model=chunk_store.indexed_embedding_model(kb_id),
                        )

                    embeddings = await asyncio.to_thread(_resolve_embeddings)
                    if embeddings is None:
                        log.warning(
                            "_retrieve_knowledge_context: no embedding model "
                            "resolved for KB %s (%s); its passages will be "
                            "searched by keyword",
                            kb_id, kb_info["name"],
                        )

                raw = await asyncio.to_thread(
                    kb_retriever.search,
                    kb_id=kb_id,
                    query=query,
                    embeddings=embeddings,
                    search_type=search_type,
                    top_k=effective_top_k,
                    vector_weight=kb_info["vector_weight"],
                    keyword_weight=kb_info["keyword_weight"],
                    processing_type=processing_type,
                )

                chunks = []
                for result in (raw or []):
                    text = result.get("content", "") if isinstance(result, dict) else str(result)
                    if text and text.strip():
                        chunks.append(f"[{kb_info['name']}] {text.strip()}")

                log.warning(
                    "_retrieve_knowledge_context: Phase 2 KB %s (%s): "
                    "%d chunks via %s/%s",
                    kb_id, kb_info["name"], len(chunks),
                    processing_type, search_type,
                )
                return chunks
            except Exception:
                log.warning(
                    "_retrieve_knowledge_context: Phase 2 search failed for kb_id=%s (%s)",
                    kb_id, kb_info["name"], exc_info=True,
                )
                return []

        try:
            all_results = await asyncio.wait_for(
                asyncio.gather(*[
                    _search_one_kb(kid, kb_map[kid])
                    for kid in kb_map
                ]),
                timeout=timeout_sec,
            )
        except asyncio.TimeoutError:
            log.warning(
                "_retrieve_knowledge_context: Phase 2 timed out after %.0fs",
                timeout_sec,
            )
            return None

        # Flatten and enforce char budget
        search_sections: List[str] = []
        total_chars = 0
        for chunks in all_results:
            for chunk in chunks:
                if total_chars + len(chunk) > max_total_chars:
                    break
                search_sections.append(chunk)
                total_chars += len(chunk)
            if total_chars >= max_total_chars:
                break

        if not search_sections:
            # The old hint here named FAISS and Neo4j, neither of which is the
            # usual cause. Retrieval no longer depends on a local FAISS index at
            # all, and it now falls back to keyword search over the stored
            # passages, so reaching this point means the passages themselves are
            # absent or genuinely match nothing.
            log.warning(
                "_retrieve_knowledge_context: Phase 2 returned 0 chunks across "
                "%d KBs — the bases hold no stored passages, or none matched. "
                "Check that their documents processed and that an embedding "
                "model resolves for this user",
                len(kb_map),
            )
            return None

        assembled = "\n\n".join(search_sections)
        log.warning(
            "_retrieve_knowledge_context: Phase 2 SUCCESS — %d chunks, %d chars",
            len(search_sections), len(assembled),
        )
        return assembled

    @staticmethod
    async def _retrieve_mcp_data_source_context(
        app,
        user_id: str,
        *,
        ledger: Optional[Any] = None,
        max_total_chars: int = 100_000,
        timeout_sec: float = 15.0,
    ) -> Optional[str]:
        """Retrieve resource content from MCP connectors linked as data sources.

        Iterates over the app's ``data_source_links``, identifies those whose
        ``data_source_id`` matches an MCP connector owned by the user, and
        collects cached resource content via
        ``MCPConnectorService.get_resource_context()``.

        Returns a formatted context string, or ``None`` if no MCP resources.

        When a ``ledger`` is supplied the resource fetch has already happened —
        once for the session rather than once per message — and this is a pure
        render of what it holds. The body below is the pre-ledger path, kept
        verbatim as the ``APP_CONTEXT_LEDGER=0`` fallback.
        """
        log = logging.getLogger(__name__)

        if ledger is not None:
            from apps.appmgr.context import mcp_context

            return mcp_context(ledger)

        if not app.data_source_links:
            return None

        # Collect candidate data source IDs
        ds_ids = [
            str(link.data_source_id).strip()
            for link in app.data_source_links
            if str(link.data_source_id).strip()
        ]
        if not ds_ids:
            return None

        # Get MCP service
        try:
            from echolib.services import ConnectorManager
            cm = ConnectorManager()
            mcp_service = cm.mcp
        except Exception:
            log.debug(
                "_retrieve_mcp_data_source_context: ConnectorManager not available",
                exc_info=True,
            )
            return None

        # For each data source ID, try to fetch MCP resource context
        # Data source IDs may be MCP connector IDs directly
        sections: list[str] = []
        total_chars = 0

        async def _fetch_one(ds_id: str) -> Optional[str]:
            try:
                return await mcp_service.get_resource_context(
                    ds_id, user_id=user_id, max_total_chars=max_total_chars,
                )
            except Exception:
                log.debug(
                    "_retrieve_mcp_data_source_context: failed for ds_id=%s",
                    ds_id, exc_info=True,
                )
                return None

        try:
            results = await asyncio.wait_for(
                asyncio.gather(*[_fetch_one(ds_id) for ds_id in ds_ids]),
                timeout=timeout_sec,
            )
        except asyncio.TimeoutError:
            log.warning(
                "_retrieve_mcp_data_source_context: timed out after %.0fs",
                timeout_sec,
            )
            return None

        for context_str in results:
            if not context_str or not context_str.strip():
                continue
            if total_chars + len(context_str) > max_total_chars:
                remaining = max_total_chars - total_chars
                if remaining > 200:
                    sections.append(context_str[:remaining] + "\n... [truncated]")
                break
            sections.append(context_str)
            total_chars += len(context_str)

        if not sections:
            return None

        assembled = "\n\n".join(sections)
        log.info(
            "_retrieve_mcp_data_source_context: SUCCESS — %d sections, %d chars "
            "from %d data source links",
            len(sections), len(assembled), len(ds_ids),
        )
        return assembled

    @staticmethod
    async def _retrieve_db_data_source_context(
        app,
        user_id: str,
        *,
        ledger: Optional[Any] = None,
        max_total_chars: int = 60_000,
        max_tables: int = 60,
        max_cols: int = 40,
        timeout_sec: float = 15.0,
    ) -> Optional[str]:
        """Retrieve SCHEMA content from Database connectors linked as data sources.

        Mirrors ``_retrieve_mcp_data_source_context``: iterates the app's
        ``data_source_links``, resolves any that are DB connections, and
        assembles a tables+columns schema summary so the application is grounded
        in the database structure (the spec's *Database → Application Context →
        Response*). Read-only introspection only — no queries, no schema changes.
        Unknown ds_ids (MCP/KB) are skipped silently.

        When a ``ledger`` is supplied the introspection has already happened —
        once for the session rather than once per message, which matters here
        more than anywhere else because ``get_full_schema`` runs a row count per
        table. The body below is the pre-ledger path, kept verbatim as the
        ``APP_CONTEXT_LEDGER=0`` fallback.
        """
        log = logging.getLogger(__name__)

        if ledger is not None:
            from apps.appmgr.context import database_context

            return database_context(ledger)

        if not app.data_source_links:
            return None
        ds_ids = [
            str(link.data_source_id).strip()
            for link in app.data_source_links
            if str(link.data_source_id).strip()
        ]
        if not ds_ids:
            return None

        try:
            from apps.connector.db_connector import DatabaseConnectorService
            db_service = DatabaseConnectorService()
        except Exception:
            log.debug("_retrieve_db_data_source_context: DB service unavailable", exc_info=True)
            return None

        def _fetch_one(ds_id: str) -> Optional[str]:
            try:
                conn = db_service.get_connection(ds_id, user_id=user_id)
                if not conn:
                    return None  # not a DB connection (likely MCP/KB) — skip
                schema = db_service.get_full_schema(ds_id)
                tables = schema.get("tables") or schema.get("tables_info") or []
                if not tables:
                    return None
                name = (conn.get("name") if isinstance(conn, dict) else None) or ds_id
                lines = [f"### Database: {name}"]
                for t in tables[:max_tables]:
                    if not isinstance(t, dict):
                        lines.append(f"- {t}")
                        continue
                    tname = t.get("table_name") or t.get("name") or "?"
                    cols = t.get("columns") or []
                    col_strs = []
                    for c in cols[:max_cols]:
                        if isinstance(c, dict):
                            col_strs.append(f"{c.get('name')} {c.get('type', '')}".strip())
                        else:
                            col_strs.append(str(c))
                    rc = t.get("row_count")
                    suffix = f" [{rc} rows]" if isinstance(rc, int) else ""
                    lines.append(f"- {tname}({', '.join(col_strs)}){suffix}")
                return "\n".join(lines)
            except Exception:
                log.debug("_retrieve_db_data_source_context: skip ds_id=%s", ds_id, exc_info=True)
                return None

        try:
            # get_connection / get_full_schema are SYNC + do DB I/O → off-thread
            results = await asyncio.wait_for(
                asyncio.gather(*[asyncio.to_thread(_fetch_one, ds_id) for ds_id in ds_ids]),
                timeout=timeout_sec,
            )
        except asyncio.TimeoutError:
            log.warning("_retrieve_db_data_source_context: timed out after %.0fs", timeout_sec)
            return None

        sections: list[str] = []
        total = 0
        for s in results:
            if not s or not s.strip():
                continue
            if total + len(s) > max_total_chars:
                sections.append(s[: max(0, max_total_chars - total)] + "\n... [truncated]")
                break
            sections.append(s)
            total += len(s)

        if not sections:
            return None
        assembled = "\n\n".join(sections)
        log.info(
            "_retrieve_db_data_source_context: SUCCESS — %d database schema section(s), %d chars",
            len(sections), len(assembled),
        )
        return assembled

    @staticmethod
    def _error_response(
        message: str, session_id: Optional[str]
    ) -> Dict[str, Any]:
        """Build a standard error response dict."""
        return {
            "response": message,
            "session_id": session_id or "",
            "conversation_state": "awaiting_input",
            "execution_trace": {"error": message},
        }