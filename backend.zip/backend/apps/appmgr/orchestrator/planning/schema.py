"""
What the orchestrator returns, under schema constraint.

WHAT: The one object the planning call produces — the request's intent, what it
      needs before it can be answered, and the plan for answering it.
WHY:  ``app-plan.md`` Causes 1a and 1b. The orchestrator asked for freeform JSON
      and scraped the result: fences stripped, ``json.loads``, eight
      ``setdefault`` calls, and a generic apology when it failed. Nothing in
      that shape could express "this request needs something I do not have", so
      a perfectly clear but completely unevidenced request — "Evaluate this
      RFP", "Give me an RFP document" — planned straight to execution and the
      model invented the missing material.

**Where a closed enum is used, and where it is deliberately not.**

The governing principle (``app-plan.md`` §4.2.1) is that a closed set belongs
only where the system can *act* on the distinction. Everywhere else the model
writes in its own words, because English gives it a dozen ways to say the same
thing and forcing a choice between synonyms produces a wrong answer rather than
a precise one.

Applied here:

- ``kind`` on :class:`EvidenceRequirement` is closed — each member is a lookup
  the ledger can actually perform. It is an index, not a taxonomy.
- ``produces_new_content`` is a **boolean**, not a five-way "task class". The
  only behaviour that depends on it is one rule: *if this request produces
  content that does not exist yet, the specification of what to produce is
  itself a requirement.* Whether the user said generate, draft, create, write,
  produce, compose, build or prepare does not change that rule, so the schema
  does not ask the model to pick among those words. ``task_summary`` carries the
  nuance in the model's own language.
- :class:`InformationRequirement` has **no enum at all**. A parameter can be
  anything — the target audience, the reporting period, which region, the
  client the document is for — and a closed list would force the model to
  approximate. Approximation is what makes a gate ask for the wrong thing.

**Structure is guaranteed; meaning is not.** Constrained decoding fixes keys and
types, never whether a value is sensible. Everything downstream treats these
fields as claims to be checked, not facts — which is why the artifact half is
verified against the ledger rather than trusted.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Kinds the Application Context Ledger can answer "present or absent" for.
# Adding a member here means teaching the gate a new lookup, in the same commit.
EvidenceKind = Literal["document", "tabular", "database", "knowledge", "connector"]

DECISION_EXECUTE = "execute"
DECISION_NEEDS_INPUT = "needs_input"
DECISION_CLARIFY = "clarify"
DECISION_ANSWER_DIRECTLY = "answer_directly"
DECISION_OUT_OF_SCOPE = "out_of_scope"


class EvidenceRequirement(BaseModel):
    """
    An **artifact** the request needs — something that either exists or does not.

    Verified by lookup against the ledger, never by the model's opinion. That is
    the whole reason the kind is a closed set: every member names something the
    platform can check.
    """

    kind: EvidenceKind = Field(
        description=(
            "Which kind of artifact this is. Use only these five. 'document' "
            "is a file the user uploads in this conversation — including any "
            "document they ask you to review or analyse. 'knowledge' is the "
            "application's own knowledge base of reference material, and is "
            "never the user's document. If what you need is not one of them, "
            "it belongs in information_required instead — never approximate "
            "it to the nearest kind here."
        )
    )
    label: str = Field(
        description="What is needed, in plain words the user will read. e.g. 'the RFP document'."
    )
    blocking: bool = Field(
        default=False,
        description=(
            "True only when proceeding without this would produce something "
            "arbitrary or wrong. False when a reasonable default exists."
        ),
    )
    why: str = Field(
        default="",
        description="Why it is needed. Shown to the user verbatim, so write it for them.",
    )
    accepts: List[str] = Field(
        default_factory=list,
        description=(
            "File extensions that would satisfy this, e.g. ['pdf','docx']. "
            "Empty if not a file. A requirement with file types can only be "
            "met by a file uploaded in this conversation."
        ),
    )


class InformationRequirement(BaseModel):
    """
    A **parameter** the request needs — a fact only the user can supply.

    No enum: this is where everything that is not one of the five artifact kinds
    belongs. Resolved from the conversation when the user has already said it,
    and asked for only when it is genuinely absent and genuinely matters.
    """

    label: str = Field(
        description=(
            "What you need to know, phrased as you would ask it. "
            "e.g. 'the client this RFP is for', 'which quarter to report on'."
        )
    )
    blocking: bool = Field(
        default=False,
        description=(
            "True only when guessing would make the output arbitrary. If a "
            "sensible default exists, set false and record it in assumptions."
        ),
    )
    why: str = Field(
        default="", description="Why it matters. Shown to the user verbatim."
    )


class PlanStep(BaseModel):
    """One skill invocation in the execution plan."""

    step: int = Field(default=1, description="1-based position in the plan.")
    skill_id: str = Field(default="", description="Exact id from the available skills. Never invent one.")
    skill_type: Literal["workflow", "agent"] = Field(default="workflow")
    skill_name: str = Field(default="", description="Human-readable name of the skill.")
    depends_on: List[int] = Field(default_factory=list, description="Step numbers that must finish first.")
    parallel_group: Optional[int] = Field(default=None, description="Steps sharing a group run together.")
    input_source: str = Field(default="user_input", description="'user_input' | 'step_N_output' | 'merged'.")
    output_key: str = Field(default="", description="Identifier for this step's result.")


class OrchestratorDecision(BaseModel):
    """
    The complete planning decision for one turn.

    Intent, requirements and plan in one model call — the shape Copilot Studio's
    orchestrator produces, where a user message becomes "a structured plan,
    identifying intents and choosing which tools or agents to invoke for each
    step". Splitting intent detection into its own call would add latency and
    another failure point without adding a decision.
    """

    # -- what the user is asking for -------------------------------------
    intent: str = Field(default="", description="What the user wants, in one sentence.")
    intent_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    task_summary: str = Field(
        default="",
        description="What this request is asking you to do, in your own words.",
    )
    produces_new_content: bool = Field(
        default=False,
        description=(
            "True when fulfilling this means producing content that does not "
            "exist yet — a document, a deck, a spreadsheet, a plan, a summary "
            "of nothing in particular. False when it means reading, analysing, "
            "querying or transforming something that already exists. When true, "
            "the specification of what to produce is itself a requirement: a "
            "document with no subject and no audience is invented content, not "
            "a document."
        ),
    )

    # -- what it needs before it can be answered --------------------------
    evidence_required: List[EvidenceRequirement] = Field(
        default_factory=list,
        description="Artifacts this request needs. Only the five listed kinds.",
    )
    information_required: List[InformationRequirement] = Field(
        default_factory=list,
        description=(
            "Facts this request needs that are not artifacts. Anything not one "
            "of the five artifact kinds goes here."
        ),
    )
    assumptions: List[str] = Field(
        default_factory=list,
        description=(
            "Defaults you chose in place of information you did not have, "
            "written for the user. This is how a request proceeds without "
            "interrogating them — decide, then say what you decided."
        ),
    )

    # -- what to do ------------------------------------------------------
    decision: Literal[
        "execute", "needs_input", "clarify", "answer_directly", "out_of_scope"
    ] = Field(default="execute")
    reasoning: str = Field(default="", description="Why you decided this. Shown to operators.")
    execution_strategy: Literal["single", "sequential", "parallel", "hybrid"] = Field(default="single")
    execution_plan: List[PlanStep] = Field(default_factory=list)
    final_output_from: str = Field(default="step_1")
    message: Optional[str] = Field(
        default=None,
        description=(
            "What to say to the user. Required for needs_input, clarify, "
            "answer_directly and out_of_scope. Null when executing."
        ),
    )

    # ------------------------------------------------------------------
    # Backward compatibility
    # ------------------------------------------------------------------

    def to_legacy_plan(self) -> Dict[str, Any]:
        """
        Render the decision in the dict shape the pipeline already consumes.

        WHAT: Produces exactly the keys ``_parse_plan`` used to emit, plus the
              new ones as additive extras.
        WHY:  ``HITLManager`` branches on ``needs_clarification`` then
              ``fallback_message`` (``hitl.py:72-123``); ``SkillExecutor`` reads
              ``execution_plan`` and ``execution_strategy``; the trace writer
              persists the whole dict, and rows written before this shipped must
              still render. Nothing downstream changes shape.

        Mapping, one decision to one legacy branch::

            execute          -> plan only
            needs_input      -> needs_clarification, question in message
            clarify          -> needs_clarification, question in message
            answer_directly  -> fallback_message, is_conversational True
            out_of_scope     -> fallback_message, is_conversational False
        """
        asks_user = self.decision in (DECISION_NEEDS_INPUT, DECISION_CLARIFY)
        answers_user = self.decision in (DECISION_ANSWER_DIRECTLY, DECISION_OUT_OF_SCOPE)

        plan: Dict[str, Any] = {
            # -- the legacy contract, unchanged --
            "reasoning": self.reasoning,
            "execution_strategy": self.execution_strategy,
            "execution_plan": [
                {
                    "step": s.step,
                    "skill_id": s.skill_id,
                    "skill_type": s.skill_type,
                    "skill_name": s.skill_name,
                    "depends_on": list(s.depends_on),
                    "parallel_group": s.parallel_group,
                    "input_source": s.input_source,
                    "output_key": s.output_key or f"step_{s.step}_output",
                }
                for s in self.execution_plan
            ],
            "final_output_from": self.final_output_from,
            "needs_clarification": asks_user,
            "clarification_question": self.message if asks_user else None,
            "fallback_message": self.message if answers_user else None,
            "is_conversational": self.decision == DECISION_ANSWER_DIRECTLY,
            # -- additive: read by the slot tracker and, later, the gate --
            "intent": self.intent,
            "intent_confidence": self.intent_confidence,
            "task_summary": self.task_summary,
            "produces_new_content": self.produces_new_content,
            "decision": self.decision,
            "evidence_required": [r.model_dump() for r in self.evidence_required],
            "information_required": [r.model_dump() for r in self.information_required],
            "assumptions": list(self.assumptions),
        }

        if asks_user and not plan["clarification_question"]:
            # A decision to ask with nothing to ask is unusable. Rather than
            # stall the turn, fall back to the requirement labels.
            plan["clarification_question"] = _question_from_requirements(self)

        return plan

    def blocking_requirements(self) -> List[Dict[str, Any]]:
        """
        Every requirement the model marked as genuinely blocking.

        One flat list, artifacts and parameters together, because the slot
        tracker cares about what is outstanding rather than which half it came
        from.
        """
        out: List[Dict[str, Any]] = []
        for r in self.evidence_required:
            if r.blocking:
                out.append({**r.model_dump(), "requirement_type": "evidence"})
        for r in self.information_required:
            if r.blocking:
                out.append({**r.model_dump(), "requirement_type": "information"})
        return out


def _question_from_requirements(decision: OrchestratorDecision) -> str:
    """Compose a question from the requirement labels when the model gave none."""
    labels = [r.label for r in decision.evidence_required if r.blocking]
    labels += [r.label for r in decision.information_required if r.blocking]
    labels = [label for label in labels if label]

    if not labels:
        return "Could you tell me a little more about what you need?"
    if len(labels) == 1:
        return f"Before I continue, could you tell me {labels[0]}?"
    listed = ", ".join(labels[:-1]) + f" and {labels[-1]}"
    return f"Before I continue, could you tell me {listed}?"


__all__ = [
    "DECISION_ANSWER_DIRECTLY",
    "DECISION_CLARIFY",
    "DECISION_EXECUTE",
    "DECISION_NEEDS_INPUT",
    "DECISION_OUT_OF_SCOPE",
    "EvidenceKind",
    "EvidenceRequirement",
    "InformationRequirement",
    "OrchestratorDecision",
    "PlanStep",
]
