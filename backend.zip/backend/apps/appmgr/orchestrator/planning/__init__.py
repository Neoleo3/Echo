"""
Schema-constrained planning for the application orchestrator.

WHAT: The prompt, the schema and the call that turn one user message into a
      decision — what the request means, what it needs before it can be
      answered, and which skills to run.
WHY:  ``app-plan.md`` Phase D. The orchestrator previously asked for freeform
      JSON and scraped the reply, and its output shape had no way to say "this
      request needs something I do not have" — so a clear but unevidenced
      request planned straight to execution and the model invented what was
      missing.

Deliberately shaped like ``apps/agent/designer/generation/``, which solved the
same problem one layer down in ``Plan_1.md`` Phase 4: a schema module, a prompt
module, and a call with structured output first and JSON mode behind it.
"""
from .planner import PlanningError, plan_decision
from .schema import (
    DECISION_ANSWER_DIRECTLY,
    DECISION_CLARIFY,
    DECISION_EXECUTE,
    DECISION_NEEDS_INPUT,
    DECISION_OUT_OF_SCOPE,
    EvidenceRequirement,
    InformationRequirement,
    OrchestratorDecision,
    PlanStep,
)
from .system_prompt import build_system_prompt, build_user_message

__all__ = [
    "DECISION_ANSWER_DIRECTLY",
    "DECISION_CLARIFY",
    "DECISION_EXECUTE",
    "DECISION_NEEDS_INPUT",
    "DECISION_OUT_OF_SCOPE",
    "EvidenceRequirement",
    "InformationRequirement",
    "OrchestratorDecision",
    "PlanStep",
    "PlanningError",
    "build_system_prompt",
    "build_user_message",
    "plan_decision",
]
