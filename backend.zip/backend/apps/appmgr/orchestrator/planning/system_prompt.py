"""
What the orchestrator is told before it plans.

WHAT: Assembles the system prompt for the planning call — the application's
      identity and rules, what evidence is actually available, what the skills
      can do and what they consume, and the handful of judgements the schema
      cannot express.
WHY:  The previous prompt carried sixteen prose instructions and twelve context
      slots, four of which pasted raw payloads — a knowledge base's whole text,
      a database's schema, every MCP resource. That spends the model's attention
      on content before it knows what it needs, and it still never asked the one
      question that matters: *can this request actually be answered with what I
      have?*

Two changes carry most of the value.

**Descriptors instead of payloads.** The planner is told a database is attached
and reachable and how many tables it has — not its rows. Agents reach the
content through tools (Phase B); the planner only decides *what to run*.

**Rules the schema cannot express, and nothing else.** Anything the schema
enforces — the output shape, the strategy values, never inventing a skill id —
is deleted rather than restated. What remains is judgement: when a request needs
something first, when to answer directly, when a workflow beats an agent.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

MAX_HISTORY_MESSAGES = 8
RECENT_HISTORY_CHARS = 500
OLDER_HISTORY_CHARS = 200


_CORE_RULES = """\
## How to decide

**1. Work out what this request actually needs before planning to do it.**

If it asks you to produce something that does not exist yet — a document, a
deck, a spreadsheet, a report, a plan — then *what to produce* is part of what
you need. A proposal with no client, no scope and no audience is not a proposal;
it is invented content with a title. Set `produces_new_content` true and put
what you need under `information_required`.

If it asks you to read, analyse, query or transform something, then that
something is what you need. Put it under `evidence_required` using one of the
five artifact kinds.

**2. Use what you already have before asking for anything.**

Check Available Evidence and the conversation. If the user has already told you
something, or already uploaded it, it is not missing — do not ask again. Only
what is genuinely absent may be a requirement.

A document listed under Available Evidence **is** the artifact. If the request
is to read, analyse or report on an uploaded document and one is listed there,
that requirement is already met: do not put it in `evidence_required` and do not
ask for it. Plan the work and let the skill read the document. Asking for a file
the user can see they have uploaded is the single worst failure here.

The reverse matters just as much. A knowledge base is the application's
reference material — templates, guidance, policy — never the document the user
is asking you to review. When the request is to review, evaluate, assess or
report on the user's own document and none has been uploaded in this
conversation, that document is missing: add it to `evidence_required` with
`kind` `document`, `blocking` true and the file types in `accepts`, and choose
`needs_input`. Do the same when the skill you would plan needs a document
uploaded in this conversation and none has been.

**3. Ask for very little, assume the rest, and say what you assumed.**

Mark a requirement `blocking` only when guessing would make the output
arbitrary or wrong. For everything else, choose a sensible default, set
`blocking` false, and write the default into `assumptions` in words the user
will read. Two blocking requirements is a lot. Three is almost always too many.

The difference matters: not knowing which client a proposal is for makes the
whole document arbitrary — ask. Not knowing how long it should be does not —
pick a length and say so.

**4. Then decide.**

- `execute` — you have what you need. Plan the skills.
- `needs_input` — something blocking is genuinely missing. Put a short, direct
  question in `message`, covering everything you need in one turn rather than
  one item at a time.
- `clarify` — the request is ambiguous rather than incomplete; you cannot tell
  which of two readings is meant.
- `answer_directly` — a greeting, small talk, a question about this application
  itself, or a question you can answer from the Available Evidence without doing
  work a skill exists to do. Put the reply in `message`.
- `out_of_scope` — nothing here can serve this request. Explain what you can do.

`answer_directly` is not an escape hatch. If the request asks you to produce,
analyse, review, draft or report on something, and a skill listed above does
that work, choose `execute` and plan that skill — even when you believe you
could write a good answer yourself. The skills are why this application exists;
answering around them returns your prose instead of the work the user
configured. Seeing a knowledge base or a document under Available Evidence means
a skill can read it, not that you should answer from it in the skill's place.

**5. Choosing between skills.**

Prefer a workflow for comprehensive work — a full review, a complete analysis, a
report drawing on several perspectives. Prefer a single agent for a specific,
narrow question. Use `sequential` when one step's output feeds the next,
`parallel` when steps are genuinely independent, `hybrid` when both.

**6. Follow the conversation.**

When the message is a follow-up — "more detail", "explain that", "and for last
quarter?" — it refers to what came before. When it introduces a new topic,
handle it on its own merit regardless of what was discussed earlier."""


def _section(title: str, body: str) -> str:
    """One prompt section, or nothing when there is no body."""
    body = (body or "").strip()
    return f"## {title}\n\n{body}" if body else ""


def _identity(app_name: Optional[str], app_description: Optional[str]) -> str:
    if not app_name:
        return ""
    parts = [f"You are the orchestrator for **{app_name}**."]
    if app_description:
        parts.append(f"Its purpose: {app_description}")
    return _section("Application", " ".join(parts))


def _skills_block(skill_manifest: Dict[str, Any]) -> str:
    """
    Render the skills, including what each one consumes.

    The inputs are the reason this section changed. Copilot Studio plans from
    "the name, description, inputs, and outputs" of each capability; ours
    previously offered no inputs at all, so the model was asked what a request
    needs while being told nothing about what the chosen skill takes. Those
    inputs are derived from configuration that already exists — nobody authors
    them.
    """
    skills = skill_manifest.get("skills") or []
    if not skills:
        return _section("Available skills", "(none — this application has no skills linked)")

    lines: List[str] = []
    for s in skills:
        line = (
            f"- **{s.get('name', 'unnamed')}** "
            f"(id={s.get('skill_id', '')}, type={s.get('skill_type', 'workflow')}): "
            f"{s.get('description') or 'No description'}"
        )
        for key, label in (
            ("capabilities", "Capabilities"),
            ("tools", "Tools"),
            ("agent_names", "Agents"),
            ("inputs", "Takes as input"),
            ("reads_from", "Can read"),
        ):
            values = s.get(key) or []
            if values:
                line += f" | {label}: {', '.join(str(v) for v in values[:8])}"
        if s.get("needs_uploaded_document") or s.get("expects_file_upload"):
            line += (
                " | **Needs a document uploaded in this conversation before it "
                "can run**"
            )
        if s.get("execution_model"):
            line += f" | Execution: {s['execution_model']}"
        lines.append(line)

    return _section("Available skills", "\n".join(lines))


def _history_block(conversation_history: Optional[Sequence[Dict[str, str]]]) -> str:
    """Recent turns, newer ones given more room."""
    messages = list(conversation_history or [])[-MAX_HISTORY_MESSAGES:]
    if not messages:
        return _section("Conversation so far", "(this is the first message)")

    lines: List[str] = []
    for index, message in enumerate(messages):
        content = message.get("content", "") or ""
        limit = (
            RECENT_HISTORY_CHARS
            if index >= len(messages) - 4
            else OLDER_HISTORY_CHARS
        )
        if len(content) > limit:
            content = content[:limit] + "..."
        lines.append(f"[{message.get('role', 'unknown')}]: {content}")

    return _section("Conversation so far", "\n".join(lines))


def _known_block(known_text: str, rounds_used: int, rounds_max: int) -> str:
    """
    What the user has already supplied during this request.

    Shown as established fact rather than as an instruction not to re-ask.
    A model that can see it already knows the client's name has no reason to
    ask for it — which is a more reliable mechanism than telling it not to.
    """
    if not known_text:
        return ""

    body = [
        "The following is already settled for the request in progress — the "
        "user supplied it, or it is already present in this session. Treat all "
        "of it as available and do not ask for any of it again:",
        "",
        known_text,
    ]
    if rounds_used >= rounds_max:
        body.append(
            "\nYou have already asked as many times as you may. Proceed with "
            "what you have, choose sensible defaults for anything still "
            "missing, and record those in `assumptions`. Do not ask again."
        )
    return _section("Already established", "\n".join(body))


def _correction_block(replan_note: str) -> str:
    """
    What was wrong with the previous attempt at this same turn.

    Only ever non-empty on a re-plan. Kept as its own section rather than folded
    into "Already established", which states what the *user* supplied — putting
    a correction there would tell the model the user said something they did not.
    """
    if not replan_note:
        return ""
    return _section("Correction required", replan_note)


def build_system_prompt(
    *,
    skill_manifest: Dict[str, Any],
    available_evidence: str = "",
    conversation_history: Optional[Sequence[Dict[str, str]]] = None,
    persona_prompt: str = "",
    guardrail_rules: str = "",
    app_name: Optional[str] = None,
    app_description: Optional[str] = None,
    app_disclaimer: Optional[str] = None,
    app_tags: Optional[Sequence[str]] = None,
    app_designations: Optional[Sequence[str]] = None,
    app_business_units: Optional[Sequence[str]] = None,
    known_text: str = "",
    rounds_used: int = 0,
    rounds_max: int = 2,
    replan_note: str = "",
) -> str:
    """
    Assemble the planning prompt.

    OUTPUT: A single system message. Sections with nothing in them are omitted
            entirely rather than left as empty headings, so a small application
            gets a short prompt.
    """
    audience: List[str] = []
    if app_designations:
        audience.append(f"Designated for: {', '.join(app_designations)}")
    if app_business_units:
        audience.append(f"Business units: {', '.join(app_business_units)}")
    if app_tags:
        audience.append(f"Tagged: {', '.join(app_tags)}")

    sections = [
        "You decide what an application should do with a user's request.",
        _identity(app_name, app_description),
        _section("Persona", persona_prompt),
        _section(
            "Rules you must respect",
            guardrail_rules
            + (
                f"\n\nThis application shows users the disclaimer: \"{app_disclaimer}\". "
                "Do not contradict it."
                if app_disclaimer
                else ""
            ),
        ),
        _section("Audience", ". ".join(audience)),
        _section(
            "Available evidence",
            (
                f"{available_evidence}\n\n"
                "This is what the application can actually reach right now. "
                "Sources marked unavailable cannot be used — do not plan around "
                "data you cannot get."
                if available_evidence
                else "Nothing is attached to this application and nothing has been "
                "uploaded in this conversation."
            ),
        ),
        _skills_block(skill_manifest),
        _history_block(conversation_history),
        _known_block(known_text, rounds_used, rounds_max),
        _correction_block(replan_note),
        _CORE_RULES,
    ]

    return "\n\n".join(part for part in sections if part).strip()


def build_user_message(enhanced_prompt: str, original_prompt: str = "") -> str:
    """
    The turn's message, with the original request restored when mid-clarification.

    A reply like "Acme, cloud migration" is meaningless alone. Carrying the
    request it answers is what lets the model see the whole thing rather than
    re-plan from a fragment.
    """
    if original_prompt and original_prompt.strip() != (enhanced_prompt or "").strip():
        return (
            f"The user originally asked:\n{original_prompt}\n\n"
            f"They have now replied:\n{enhanced_prompt}\n\n"
            "Combine both. If the reply supplies what you were missing, proceed."
        )
    return enhanced_prompt


__all__ = ["build_system_prompt", "build_user_message"]
