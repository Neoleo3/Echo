"""
The planning call, under schema constraint, with somewhere to fall.

WHAT: Sends the planning prompt and returns a validated
      :class:`OrchestratorDecision`.
WHY:  ``app-plan.md`` Cause 1b. The orchestrator asked for freeform JSON and
      scraped it — strip fences, ``json.loads``, eight ``setdefault`` calls, and
      a generic apology on failure. That is the transcribe-then-scrape pattern
      ``Plan_1.md`` Cause 3 removed from agent generation in Phase 4; the
      orchestrator was never migrated.

**The same three tiers as ``apps/agent/designer/generation/generator.py``**, so
the platform's two structured-output call sites behave alike::

    with_structured_output(OrchestratorDecision)   provider-native, or tool calls
      ↓  NotImplementedError / AttributeError / TypeError
    JSON mode: the shape spelled out, then extract the object
      ↓  anything at all
    raise PlanningError  →  the caller falls back to the legacy scraper

The third tier lives in the caller rather than here, and that is deliberate:
this module's job is to produce a decision or say that it could not. Deciding
that a failure means "behave exactly as the platform did last week" is the
orchestrator's call, and keeping it there is what makes the whole phase safely
reversible.

**``strict`` is not passed.** Strict schema adherence requires every property to
be required, which collides with the defaulted list fields this schema needs —
and current guidance is explicit that structured output guarantees shape, never
that a value is sensible, so strictness would buy less than it costs. Auto
strategy still selects provider-native structured output where the provider
supports it.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List

from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import ValidationError

from .schema import OrchestratorDecision

logger = logging.getLogger(__name__)


class PlanningError(Exception):
    """No schema-conformant decision could be obtained on any path."""


_JSON_MODE_INSTRUCTION = """
Return ONLY a JSON object with exactly this shape. No markdown, no commentary.

{
  "intent": "string",
  "intent_confidence": 0.0,
  "task_summary": "string",
  "produces_new_content": false,
  "evidence_required": [
    {"kind": "document|tabular|database|knowledge|connector",
     "label": "string", "blocking": false, "why": "string", "accepts": []}
  ],
  "information_required": [
    {"label": "string", "blocking": false, "why": "string"}
  ],
  "assumptions": ["string"],
  "decision": "execute|needs_input|clarify|answer_directly|out_of_scope",
  "reasoning": "string",
  "execution_strategy": "single|sequential|parallel|hybrid",
  "execution_plan": [
    {"step": 1, "skill_id": "string", "skill_type": "workflow|agent",
     "skill_name": "string", "depends_on": [], "parallel_group": null,
     "input_source": "user_input", "output_key": "string"}
  ],
  "final_output_from": "string",
  "message": "string or null"
}
"""


def _extract_json_object(text: str) -> Dict[str, Any]:
    """
    Recover the JSON object from a model reply that may be wrapped.

    Fences first, then the outermost brace pair. Only reached on the JSON-mode
    path, where the model was asked for bare JSON and something still wrapped
    it — a well-understood provider quirk, not the primary contract.
    """
    content = (text or "").strip()

    fenced = re.search(r"```(?:json)?\s*(.+?)```", content, re.DOTALL)
    if fenced:
        content = fenced.group(1).strip()

    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            return parsed
    except (json.JSONDecodeError, TypeError):
        pass

    start = content.find("{")
    end = content.rfind("}")
    if start >= 0 and end > start:
        try:
            parsed = json.loads(content[start : end + 1])
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass

    raise PlanningError("Planning model returned no JSON object")


def _coerce(result: Any) -> OrchestratorDecision:
    """Normalize whatever ``with_structured_output`` handed back."""
    if isinstance(result, OrchestratorDecision):
        return result
    if isinstance(result, dict):
        return OrchestratorDecision.model_validate(result)
    if hasattr(result, "model_dump"):
        return OrchestratorDecision.model_validate(result.model_dump())
    raise PlanningError(
        f"Planning model returned an unusable result type: {type(result).__name__}"
    )


def _invoke(llm: Any, messages: List[Any]) -> Any:
    return llm.invoke(messages)


def plan_decision(
    llm: Any,
    *,
    system_prompt: str,
    user_message: str,
) -> OrchestratorDecision:
    """
    Produce the planning decision for one turn.

    INPUT: A chat model from the resolver, the assembled system prompt, and the
           turn's message.
    OUTPUT: A validated :class:`OrchestratorDecision`.
    RAISES: :class:`PlanningError` when neither the structured nor the JSON-mode
            path yields a conformant object. The caller treats that as "use the
            legacy path", never as a failed turn.
    """
    messages = [SystemMessage(content=system_prompt), HumanMessage(content=user_message)]

    try:
        structured = llm.with_structured_output(OrchestratorDecision)
        result = _invoke(structured, messages)
        logger.info(
            "✅ Structured output path successful (Phase 3 RCA: LangChain structured output working)"
        )
        return _coerce(result)
    except (NotImplementedError, AttributeError, TypeError) as exc:
        logger.info(
            "❌ Structured output unavailable for planning (%s); falling back to JSON mode (Phase 3 RCA Hypothesis 3 detected)",
            type(exc).__name__,
        )
    except ValidationError as exc:
        logger.warning(
            "❌ Planning output failed schema validation: %s (Phase 3 RCA Hypothesis 3 indicator)",
            exc,
        )
    except Exception as exc:  # noqa: BLE001 -- try JSON mode before giving up
        logger.warning(
            "❌ Structured planning call failed (%s); trying JSON mode (Phase 3 RCA Hypothesis 3 detected)",
            exc,
        )

    fallback_messages = [
        SystemMessage(content=f"{system_prompt}\n{_JSON_MODE_INSTRUCTION}"),
        HumanMessage(content=user_message),
    ]

    try:
        response = _invoke(llm, fallback_messages)
        content = response.content if hasattr(response, "content") else str(response)
        decision = OrchestratorDecision.model_validate(_extract_json_object(content))
        logger.info(
            "✅ JSON mode fallback successful (Phase 3 RCA: JSON extraction working)"
        )
        return decision
    except ValidationError as exc:
        logger.error(
            "❌ JSON mode failed schema validation: %s (Phase 3 RCA Hypothesis 3 indicator)",
            exc,
        )
        raise PlanningError(f"Planning output failed schema validation: {exc}") from exc
    except PlanningError as pex:
        logger.error(
            "❌ JSON extraction failed: %s (Phase 3 RCA Hypothesis 3 confirmed)",
            pex,
        )
        raise
    except Exception as exc:  # noqa: BLE001 -- surfaced as PlanningError
        logger.error(
            "❌ Planning call failed entirely: %s (Phase 3 RCA Hypothesis 3 confirmed)",
            exc,
        )
        raise PlanningError(f"Planning call failed: {exc}") from exc


__all__ = ["PlanningError", "plan_decision"]
