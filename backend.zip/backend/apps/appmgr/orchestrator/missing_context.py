"""
Telling the user what is missing, in words they can act on.

WHAT: Renders the Evidence Gate's verdict into the message the user reads, and
      the typed payload the frontend can build a richer card from.
WHY:  A refusal is only useful if it says what would fix it. Microsoft's own
      grounded refusals name the cause — *"the response could not be grounded in
      your organization's data"*, *"Copilot couldn't verify access to the
      requested content"* — rather than returning a generic apology. The
      previous behaviour here was the opposite: an invented answer, or on the
      parse-failure path, *"I encountered an issue processing your request."*

**No model call.** The gate ran without one and so does this. On a
bring-your-own-LLM platform the refusal path must work even when the user's
model is unavailable or unconfigured — a system that needs a model in order to
say *"I need the RFP document"* has the dependency exactly backwards. A template
also keeps the message stable, which matters when the same message is rendered
on every turn until the file arrives.

The text is written to be shown verbatim. A client that renders nothing but
``response`` still gives the user a correct, actionable answer; the structured
payload in ``execution_trace.missing_context`` is an enhancement on top.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Sequence

logger = logging.getLogger(__name__)

ACTION_UPLOAD = "upload"
ACTION_CONNECT = "connect"
ACTION_DESCRIBE = "describe"

# Which call to action a missing kind implies.
_ACTION_BY_KIND = {
    "document": ACTION_UPLOAD,
    "tabular": ACTION_UPLOAD,
    "database": ACTION_CONNECT,
    "knowledge": ACTION_CONNECT,
    "connector": ACTION_CONNECT,
}

_VERB_BY_ACTION = {
    ACTION_UPLOAD: "Upload it and I'll continue.",
    ACTION_CONNECT: "Connect it in the application's data sources and I'll continue.",
    ACTION_DESCRIBE: "Tell me and I'll continue.",
}


def _opening(missing: Sequence[Dict[str, Any]]) -> str:
    """The first line: what is not here, stated plainly and without apology."""
    labels = [str(m.get("label") or "").strip() for m in missing]
    labels = [label for label in labels if label]

    if not labels:
        return "I'm missing something I need before I can do this."
    if len(labels) == 1:
        return f"I don't have {labels[0]}."
    listed = ", ".join(labels[:-1]) + f" and {labels[-1]}"
    return f"I don't have {listed}."


def _action_for(missing: Sequence[Dict[str, Any]]) -> str:
    """One call to action for the set — the most common kind wins."""
    actions = [
        _ACTION_BY_KIND.get(str(m.get("kind") or "").lower(), ACTION_DESCRIBE)
        for m in missing
    ]
    if not actions:
        return ACTION_DESCRIBE
    return max(set(actions), key=actions.count)


# Upload statuses that mean "a file arrived but cannot be read yet / at all".
_STATUS_PROCESSING = ("pending", "processing", "uploading")
_STATUS_FAILED = ("failed", "error")


def _upload_status_lines(uploads: Sequence[Dict[str, Any]]) -> List[str]:
    """
    Say what happened to a file the user did upload but the gate could not use.

    A user who just attached a document and is told "I don't have it" reads the
    application as broken. The truthful message is that the file is still being
    read, or could not be read -- and those need different actions.
    """
    processing = [
        str(u.get("filename") or "your file")
        for u in uploads
        if str(u.get("status") or "").lower() in _STATUS_PROCESSING
    ]
    failed = [
        str(u.get("filename") or "your file")
        for u in uploads
        if str(u.get("status") or "").lower() in _STATUS_FAILED
    ]
    lines: List[str] = []
    if processing:
        lines.append(
            f"{', '.join(processing)} is still being processed. Send your "
            "request again in a moment and I'll continue."
        )
    if failed:
        lines.append(
            f"{', '.join(failed)} could not be read. Please upload it again, "
            "or upload it in another format such as PDF or DOCX."
        )
    return lines


def render(
    result: Any,
    *,
    intent: str = "",
    skill_name: str = "",
    uploads: Sequence[Dict[str, Any]] = (),
) -> str:
    """
    Build the assistant's message for a stopped run.

    OUTPUT: Markdown, safe to display verbatim. Never empty — a gate that
            stopped must always produce something the user can act on.

    ``uploads`` is this conversation's upload states. Only files that are
    still processing or failed change the message; omitted, it is unchanged.
    """
    missing = list(getattr(result, "missing", ()) or ())
    optional = list(getattr(result, "optional", ()) or ())
    available = list(getattr(result, "available", ()) or ())

    lines: List[str] = [_opening(missing)]

    status_lines = (
        _upload_status_lines(uploads)
        if _action_for(missing) == ACTION_UPLOAD
        else []
    )
    if status_lines:
        lines.append("")
        lines.extend(status_lines)

    if missing:
        lines.append("")
        lines.append("**I need**")
        for entry in missing:
            label = str(entry.get("label") or "").strip() or "this"
            why = str(entry.get("why") or "").strip()
            accepts = [str(a).strip() for a in (entry.get("accepts") or []) if str(a).strip()]
            bullet = f"- {label}"
            if why:
                bullet += f" — {why}"
            if accepts:
                bullet += f" ({', '.join(accepts)})"
            lines.append(bullet)

    if optional:
        useful = [
            str(o.get("label") or "").strip()
            for o in optional
            if str(o.get("label") or "").strip()
        ]
        if useful:
            lines.append("")
            lines.append("**Helpful, but not required**")
            lines.extend(f"- {label}" for label in useful)

    if available:
        lines.append("")
        lines.append("I do have: " + ", ".join(available) + ".")

    if not status_lines:
        lines.append("")
        lines.append(_VERB_BY_ACTION[_action_for(missing)])

    return "\n".join(lines).strip()


def payload(
    result: Any,
    *,
    intent: str = "",
    skill_name: str = "",
    reason: str = "missing_evidence",
) -> Dict[str, Any]:
    """
    The typed block written to ``execution_trace.missing_context``.

    Everything a client needs to build the richer card described in the plan:
    what is required, what is optional, what the application does have, and
    which affordance to offer. Carries no credential and no source content.
    """
    missing = list(getattr(result, "missing", ()) or ())

    return {
        "reason": reason,
        "intent": intent,
        "skill_considered": skill_name,
        "missing": [
            {
                "kind": entry.get("kind"),
                "label": entry.get("label"),
                "why": entry.get("why") or "",
                "accepts": list(entry.get("accepts") or []),
                "blocking": True,
            }
            for entry in missing
        ],
        "optional": [
            {
                "kind": entry.get("kind"),
                "label": entry.get("label"),
                "why": entry.get("why") or "",
                "blocking": False,
            }
            for entry in (getattr(result, "optional", ()) or ())
        ],
        "available": list(getattr(result, "available", ()) or ()),
        "action": _action_for(missing),
    }


__all__ = [
    "ACTION_CONNECT",
    "ACTION_DESCRIBE",
    "ACTION_UPLOAD",
    "payload",
    "render",
]
