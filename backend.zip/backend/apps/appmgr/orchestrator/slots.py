"""
Remembering what was already asked, so the application never asks twice.

WHAT: The small piece of per-session state that turns "ask the user for what is
      missing" into something that always terminates — what has been asked, what
      has since become known, and how many rounds have gone by.
WHY:  Asking is easy to add and easy to get catastrophically wrong. Microsoft
      documents this exact failure in Copilot Studio's own generative
      orchestration: with it enabled, *"the bot asks a structured question, the
      user provides a valid answer, but the bot repeats the same question
      multiple times and never proceeds"* — and the same input processes
      correctly with orchestration switched off. The layer that adds the
      intelligence is the layer that introduces the loop.

**How the work is divided, and why.**

The model does the understanding. It reads what is already known and decides
whether the request can now be answered — because judging whether "for Acme, a
cloud migration" satisfies "the client this is for" and "scope of work" is a
language problem, and language problems belong to the language model. Nothing
here matches strings, keeps a status enum, or asks anyone to maintain state by
hand.

This module does the remembering, and one guarantee the model cannot give: a
run may return to the user only so many times. Past that it proceeds on stated
assumptions. That is a *termination* property, and a termination property that
depends on a model choosing to stop is not a guarantee. Research on multi-turn
clarification puts the useful band at one to three rounds and finds question
*precision* explains ~76% of task-completion variance while the number of
rounds explains under 1% — so the cap costs almost nothing and removes the
failure mode entirely.

**Where it lives.** ``chat_sessions.context_data``, the JSONB column that
already carries ``hitl_state`` and the clarification context. Additive key,
zero DDL. A session written before this shipped has no such key and behaves as
it did.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

CONTEXT_KEY = "requirement_slots"


def max_rounds() -> int:
    """
    How many times one request may come back to the user.

    Read from configuration rather than the environment so it is a product
    decision that ships with the code, not deployment trivia.
    """
    try:
        from echolib.config import settings

        return max(0, int(getattr(settings, "app_max_clarification_rounds", 2)))
    except Exception:  # noqa: BLE001 -- configuration must never break a turn
        return 2


@dataclass(frozen=True)
class ClarificationState:
    """
    What this request has asked for so far, and what it has since learned.

    Immutable: each turn produces a new state rather than editing the old one,
    so a half-applied update cannot leave a session asking about something it
    already knows.
    """

    original_prompt: str = ""
    round: int = 0
    asked: tuple = ()          # labels already put to the user, in order
    known: tuple = ()          # ("label", "what the user said") pairs
    assumptions: tuple = ()    # defaults recorded on the way through

    @property
    def is_active(self) -> bool:
        return bool(self.asked) or self.round > 0

    @property
    def exhausted(self) -> bool:
        """True once the request has used its rounds and must now proceed."""
        return self.round >= max_rounds()

    def known_text(self) -> str:
        """
        What is already established, rendered for the model.

        This is the whole anti-repetition mechanism: the model is *shown* what
        it already knows before it decides what is still missing, so not
        re-asking is the natural reading of its input rather than an
        instruction it has to remember to obey.
        """
        if not self.known:
            return ""
        lines = [f"- {label}: {value}" for label, value in self.known if label]
        return "\n".join(lines)

    def to_context(self) -> Dict[str, Any]:
        """Serialize for ``chat_sessions.context_data``. Plain JSON only."""
        return {
            "original_prompt": self.original_prompt,
            "round": self.round,
            "asked": list(self.asked),
            "known": [list(pair) for pair in self.known],
            "assumptions": list(self.assumptions),
        }

    def describe(self) -> Dict[str, Any]:
        """Counts for the execution trace — no user content."""
        return {
            "round": self.round,
            "max_rounds": max_rounds(),
            "asked": len(self.asked),
            "known": len(self.known),
            "exhausted": self.exhausted,
        }


EMPTY = ClarificationState()


def from_context(context_data: Optional[Dict[str, Any]]) -> ClarificationState:
    """
    Read the state back, tolerating anything that is not it.

    A session predating this feature, a hand-edited row, or a partially written
    blob all yield the neutral state rather than an exception: an unreadable
    tracker must degrade to "we have not asked anything yet", never to a failed
    turn.
    """
    raw = (context_data or {}).get(CONTEXT_KEY)
    if not isinstance(raw, dict):
        return EMPTY

    known: List[tuple] = []
    for pair in raw.get("known") or []:
        if isinstance(pair, (list, tuple)) and len(pair) == 2:
            known.append((str(pair[0]), str(pair[1])))

    try:
        round_number = max(0, int(raw.get("round") or 0))
    except (TypeError, ValueError):
        round_number = 0

    return ClarificationState(
        original_prompt=str(raw.get("original_prompt") or ""),
        round=round_number,
        asked=tuple(str(a) for a in (raw.get("asked") or []) if str(a).strip()),
        known=tuple(known),
        assumptions=tuple(str(a) for a in (raw.get("assumptions") or []) if str(a).strip()),
    )


def opened(
    state: ClarificationState,
    *,
    original_prompt: str,
    requirements: Sequence[Dict[str, Any]],
    assumptions: Sequence[str] = (),
) -> ClarificationState:
    """
    Record that the application has just asked for these things.

    Returns a new state with the round advanced and the labels remembered. The
    original prompt is captured on the first round only — it is what the user
    actually wanted, and every later turn is an answer to a question about it,
    not a new request.
    """
    labels = [
        str(r.get("label") or "").strip()
        for r in requirements
        if str(r.get("label") or "").strip()
    ]

    return ClarificationState(
        original_prompt=state.original_prompt or original_prompt,
        round=state.round + 1,
        asked=tuple(list(state.asked) + [label for label in labels if label not in state.asked]),
        known=state.known,
        assumptions=tuple(list(state.assumptions) + [str(a) for a in assumptions if a]),
    )


def learned(
    state: ClarificationState,
    *,
    reply: str,
    resolved: Sequence[Dict[str, Any]] = (),
    assumptions: Sequence[str] = (),
) -> ClarificationState:
    """
    Fold what the user just said into what is known.

    ``resolved`` is the model's own reading of which outstanding items the reply
    answered, as ``{"label": ..., "value": ...}``. When it reports nothing —
    because the provider degraded, or because the reply genuinely answered
    nothing specific — the raw reply is still recorded against the outstanding
    labels, so the next turn sees that an answer was given even if it could not
    be attributed. A turn that produced *no* record at all is how a loop starts.
    """
    known = list(state.known)
    seen = {label for label, _ in known}

    for item in resolved:
        if not isinstance(item, dict):
            continue
        label = str(item.get("label") or "").strip()
        value = str(item.get("value") or "").strip()
        if not label or not value or label in seen:
            continue
        known.append((label, value))
        seen.add(label)

    cleaned_reply = (reply or "").strip()
    if cleaned_reply and not resolved:
        outstanding = [a for a in state.asked if a not in seen]
        target = outstanding[0] if outstanding else "additional detail"
        known.append((target, cleaned_reply))

    return ClarificationState(
        original_prompt=state.original_prompt,
        round=state.round,
        asked=state.asked,
        known=tuple(known),
        assumptions=tuple(list(state.assumptions) + [str(a) for a in assumptions if a]),
    )


def cleared() -> ClarificationState:
    """The neutral state, written once a request has been answered."""
    return EMPTY


def forced_assumptions(state: ClarificationState) -> List[str]:
    """
    What the application is proceeding on now that its rounds are spent.

    Everything asked and not answered becomes an explicit assumption rather than
    a silent one. The user is told the run went ahead and on what basis, which
    is the difference between a default and an invention.
    """
    answered = {label for label, _ in state.known}
    return [
        f"Proceeded without {label}, using a reasonable default."
        for label in state.asked
        if label not in answered
    ]


__all__ = [
    "CONTEXT_KEY",
    "EMPTY",
    "ClarificationState",
    "cleared",
    "forced_assumptions",
    "from_context",
    "learned",
    "max_rounds",
    "opened",
]
