"""
Durable storage for documents uploaded into an application chat.

WHAT: One place that decides where an uploaded document lives, and hands back a
      local path only when something genuinely needs one.
WHY:  Uploads were written to ``APP_UPLOADS_DIR`` and indexed into a FAISS
      directory beside it. The deployment runs more than one replica with no
      shared filesystem, so a restart, a redeploy, or a request landing on a
      different replica lost both — while the ``application_documents`` row
      survived and kept claiming the document was ready. The agent then
      answered as though nothing had been uploaded, and the only fix available
      to the user was to upload it again.

The rule this module enforces:

    Postgres is the source of truth. Local disk is a cache of it.

``content_bytes`` on the row is written at upload, before anything is
converted. Several skills and tools still take a filesystem path — tabular
analysis reads spreadsheets with pandas, image analysis reads the file
directly — so the bytes are also written to ``APP_UPLOADS_DIR`` for them. That
write is a convenience, not the record: when the path is missing, because this
replica never saw the upload or the container was replaced,
:func:`materialize` writes it back from Postgres and the caller proceeds
unchanged.

Nothing here converts, chunks or embeds. Conversion belongs to
``apps.markitdown`` and retrieval to ``SessionRAGManager``; this module only
answers "where are the bytes".
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models.application_chat import ApplicationDocument
from echolib.repositories.base import safe_uuid

logger = logging.getLogger(__name__)

UPLOADS_DIR = os.getenv("APP_UPLOADS_DIR", os.path.join("apps", "appmgr", "uploads"))

# Storing the original doubles what an upload costs in the database. It buys
# re-conversion without a re-upload and rehydration on any replica, which is
# the whole point of this module, so it is on by default and opt-out only.
KEEP_ORIGINALS = os.getenv("APP_KEEP_UPLOAD_ORIGINALS", "true").lower() != "false"


def local_path(stored_filename: str) -> str:
    """The conventional on-disk location for one stored document."""
    return os.path.join(UPLOADS_DIR, stored_filename)


def write_local_copy(stored_filename: str, payload: bytes) -> Optional[str]:
    """
    Write the disk copy, or return ``None`` when the filesystem refuses.

    Best-effort by design: the durable record is the database row, so a disk
    that is full or read-only must not fail an upload that Postgres accepted.
    """
    if not stored_filename or payload is None:
        return None

    path = local_path(stored_filename)
    try:
        Path(UPLOADS_DIR).mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as handle:
            handle.write(payload)
        return path
    except OSError:
        logger.warning(
            "Could not write the local copy of '%s'; Postgres remains the record",
            stored_filename,
            exc_info=True,
        )
        return None


async def materialize(db: AsyncSession, document_id: str) -> Optional[str]:
    """
    Return a local path for one document, writing it back from Postgres if
    this replica does not have it.

    WHAT: Ensures the file exists under ``APP_UPLOADS_DIR`` and returns its
          path.
    WHY:  Tabular skills and image analysis take a path, not bytes. Without
          rehydration those tools break the moment the container that received
          the upload is replaced — which is exactly the failure this work
          exists to remove.
    OUTPUT: The path, or ``None`` when the document is unknown and no stored
            copy exists. Never raises: a caller that cannot get a path should
            report a missing document, not fail the turn.
    """
    doc_uuid = safe_uuid(document_id)
    if doc_uuid is None:
        return None

    try:
        result = await db.execute(
            select(
                ApplicationDocument.stored_filename,
                ApplicationDocument.content_bytes,
            ).where(ApplicationDocument.document_id == doc_uuid)
        )
        row = result.first()
    except Exception:
        logger.exception("Could not read document '%s' for materialization", document_id)
        return None

    if row is None:
        return None

    stored_filename, content_bytes = row[0], row[1]
    if not stored_filename:
        return None

    path = local_path(stored_filename)
    if os.path.isfile(path):
        return path

    if not content_bytes:
        logger.warning(
            "Document '%s' has no local copy and no stored bytes; it was "
            "uploaded before durable storage or with originals disabled",
            document_id,
        )
        return None

    return write_local_copy(stored_filename, content_bytes)


async def materialize_stored(
    db: AsyncSession, stored_filename: str
) -> Optional[str]:
    """
    Rehydrate by stored filename, for callers that hold the name and not the id.

    The readiness ledger records ``stored_filename`` on each tabular document,
    so this is the lookup the orchestration pipeline needs.
    """
    if not stored_filename:
        return None

    path = local_path(stored_filename)
    if os.path.isfile(path):
        return path

    try:
        result = await db.execute(
            select(
                ApplicationDocument.document_id,
                ApplicationDocument.content_bytes,
            ).where(ApplicationDocument.stored_filename == stored_filename)
        )
        row = result.first()
    except Exception:
        logger.exception(
            "Could not read document '%s' for materialization", stored_filename
        )
        return None

    if row is None or not row[1]:
        return None

    return write_local_copy(stored_filename, row[1])


__all__ = [
    "KEEP_ORIGINALS",
    "UPLOADS_DIR",
    "local_path",
    "materialize",
    "materialize_stored",
    "write_local_copy",
]
