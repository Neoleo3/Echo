
from echolib.di import container
from echolib.adapters import KafkaEventBus, OTelLogger
from echolib.services import TemplateRepository, AgentService, WorkflowService

# Import new orchestrator services
from .validator.validator import WorkflowValidator
from .storage.filesystem import WorkflowStorage
from .designer.designer import WorkflowDesigner
from .designer.compiler import WorkflowCompiler
from .runtime.executor import WorkflowExecutor
from .runtime.guards import RuntimeGuards
from .runtime.hitl import HITLManager, HITLDBManager
from .runtime.ws_manager import ws_manager  # ✅ Singleton import for DI
from .visualization.graph_mapper import GraphMapper
from .visualization.graph_editor import GraphEditor
from .visualization.node_mapper import NodeMapper

# Import agent registry from agent app
from apps.agent.registry.registry import AgentRegistry

# Phase 2: StorageGateway — DB-primary read layer
from echolib.repositories.storage_gateway import StorageGateway

# Existing services (keep for backward compatibility)
_bus = KafkaEventBus()
_tpl = TemplateRepository()
_agentsvc = AgentService(_tpl)
_wfsvc = WorkflowService(_agentsvc, _bus)

# New orchestrator services
_storage = WorkflowStorage()
_agent_registry = AgentRegistry()


def _get_tool_registry():
    """Lazily get tool registry from DI container to avoid circular imports."""
    return container.resolve('tool.registry')


def _get_tool_storage():
    """Lazily get tool storage from DI container to avoid circular imports."""
    try:
        return container.resolve('tool.storage')
    except Exception:
        return None


def _get_tool_registry_dict():
    """Get tool registry as dict for validator (tool_id -> tool_def)."""
    try:
        registry = _get_tool_registry()
        return {t.tool_id: t.model_dump() for t in registry.list_all()}
    except Exception:
        return {}


# Phase 2: StorageGateway instance — single source for all read paths
# Note: tool_storage is resolved lazily via _get_tool_storage() at gateway
# construction time. If tool.storage is not yet registered in DI, it will
# be None and the gateway will skip FS fallback for tools (safe default).
_storage_gateway = StorageGateway(
    workflow_storage=_storage,
    agent_registry=_agent_registry,
    tool_storage=_get_tool_storage(),
)

# Wire gateway into the agent registry for centralized DB-first reads
_agent_registry.set_storage_gateway(_storage_gateway)

_validator = WorkflowValidator(tool_registry_provider=_get_tool_registry_dict)
_designer = WorkflowDesigner(agent_registry=_agent_registry)
_compiler = WorkflowCompiler()
_guards = RuntimeGuards()
_hitl = HITLDBManager()  # Extends HITLManager with DB persistence for HITL Node system
_graph_mapper = GraphMapper(storage=_storage)
_graph_editor = GraphEditor()
_node_mapper = NodeMapper(tool_registry=_get_tool_registry())
_executor = WorkflowExecutor(
    storage=_storage,
    compiler=_compiler,
    agent_registry=_agent_registry,
    guards=_guards,
    storage_gateway=_storage_gateway,
    ws_manager=ws_manager,  # ✅ Injected singleton (FIX #2)
)

# Register existing services
container.register('event.bus', lambda: _bus)
container.register('agent.service', lambda: _agentsvc)
container.register('workflow.service', lambda: _wfsvc)
container.register('logger', lambda: OTelLogger())

# Register new orchestrator services
container.register('workflow.storage', lambda: _storage)
container.register('workflow.storage_gateway', lambda: _storage_gateway)
container.register('workflow.validator', lambda: _validator)
container.register('workflow.designer', lambda: _designer)
container.register('workflow.compiler', lambda: _compiler)
container.register('workflow.guards', lambda: _guards)
container.register('workflow.hitl', lambda: _hitl)
container.register('workflow.graph_mapper', lambda: _graph_mapper)
container.register('workflow.graph_editor', lambda: _graph_editor)
container.register('workflow.node_mapper', lambda: _node_mapper)
container.register('workflow.executor', lambda: _executor)
