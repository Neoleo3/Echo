from fastapi import APIRouter, Depends, HTTPException, Query, Body, Request, BackgroundTasks
from fastapi.responses import StreamingResponse
from typing import Optional
import json as _sse_json
from echolib.di import container
from echolib.security import get_current_user, require_user, require_admin_or_above, user_context, resolve_user_id
from echolib.types import UserContext
from echolib.types import *

from echolib.services import WorkflowService
from echolib.types import (
    Agent,
    Workflow,
    WorkflowValidationRequest,
    SaveFinalRequest,
    CloneWorkflowRequest,
    ExecuteWorkflowRequest,
    ExecuteWorkflowByIdRequest
)

# Phase 2: DB-first read imports
from echolib.id_utils import normalize_to_uuid, uuid_to_prefixed
from echolib.repositories.workflow_repo import WorkflowRepository
from echolib.repositories.session_repo import SessionRepository
from echolib.repositories.storage_gateway import StorageGateway
from echolib.database import get_db_session
from echolib.generated_files import validate_generated_file_path

from echolib.config import settings as _settings
from echolib.repositories.base import DEFAULT_USER_ID

import asyncio
import logging
import os
import traceback
from apps.analytics.token_limit import TokenLimitExceededException
from apps.analytics.token_governance_handler import handle_token_limit_exception

_db_logger = logging.getLogger(__name__)

# Phase 2: Module-level repository singletons for DB reads
_workflow_repo = WorkflowRepository()
_session_repo = SessionRepository()


def _get_storage_gateway() -> StorageGateway:
    """Get the StorageGateway singleton from the DI container."""
    return container.resolve('workflow.storage_gateway')


def _collect_unsaved_draft_agent_refs(workflow_def: dict) -> list[str]:
    """Collect workflow agent references that still look like unsaved draft contracts."""
    violations: list[str] = []
    agents = workflow_def.get("agents", []) if isinstance(workflow_def, dict) else []

    for idx, entry in enumerate(agents):
        if isinstance(entry, str):
            if entry.startswith("draft_"):
                violations.append(f"agents[{idx}] references unsaved draft id '{entry}'")
            continue

        if not isinstance(entry, dict):
            continue

        if entry.get("schema_version") == "agent_builder_v2":
            violations.append(f"agents[{idx}] uses AgentDraft schema_version")

        if any(k in entry for k in ("draftId", "draft_id", "event", "next_actions", "state_from", "state_to")):
            violations.append(f"agents[{idx}] contains draft/event metadata")

        agent_id = str(entry.get("agent_id") or "").strip()
        if not agent_id:
            violations.append(f"agents[{idx}] is missing saved agent_id")
        elif agent_id.startswith("draft_"):
            violations.append(f"agents[{idx}] uses unsaved draft agent_id '{agent_id}'")

    return violations


def _enforce_workflow_runtime_guard(workflow_def: dict, workflow_id: str) -> None:
    """Fail fast when workflow payload attempts to execute unsaved draft agent contracts."""
    violations = _collect_unsaved_draft_agent_refs(workflow_def)
    if not violations:
        return

    detail = (
        "Workflow execution blocked: workflow must reference saved agents only. "
        + " ; ".join(violations)
    )
    _db_logger.warning(
        "workflow_runtime_guard_blocked",
        extra={
            "workflow_id": workflow_id,
            "violations": violations,
        },
    )
    raise HTTPException(status_code=400, detail=detail)


def _prefixed_id_to_uuid(prefixed_id: str) -> str:
    """
    Convert a prefixed hex ID (e.g., wf_xxx, agt_xxx) to a proper UUID string.

    The application uses IDs like 'wf_550e8400e29b41d4a716446655440000'
    but the database expects UUIDs like '550e8400-e29b-41d4-a716-446655440000'.

    Args:
        prefixed_id: ID with prefix (wf_, agt_, session_, etc.)

    Returns:
        Properly formatted UUID string with hyphens

    Raises:
        ValueError: If the hex portion is not exactly 32 characters
    """
    # Remove any known prefix
    hex_part = prefixed_id
    for prefix in ("wf_", "agt_", "session_", "run_", "tool_"):
        if prefixed_id.startswith(prefix):
            hex_part = prefixed_id[len(prefix):]
            break

    # Validate hex length
    if len(hex_part) != 32:
        raise ValueError(f"Invalid ID format: {prefixed_id} (hex part must be 32 chars)")

    # Insert hyphens: 8-4-4-4-12
    return f"{hex_part[:8]}-{hex_part[8:12]}-{hex_part[12:16]}-{hex_part[16:20]}-{hex_part[20:]}"


def _repair_definition_ids(definition: dict) -> dict:
    """
    Repair ID format mismatches in a workflow definition.

    Handles THREE kinds of mismatch:

    1. **UUID ↔ prefixed format** — Earlier save code converted
       agents[].agent_id to UUID but left connections in agt_xxx format.

    2. **Integer canvas node IDs** — ``map_backend_to_frontend()`` assigns
       1-based sequential integers when rendering the canvas.  If the
       canvas state is written back to the DB without going through
       ``map_frontend_to_backend()`` (e.g. via ``save_final``), connections
       retain those integers.  Integer N maps to agents[N-1].

    3. **String-coerced integers** — Same as (2) after JSON round-trip.

    Args:
        definition: Workflow definition dict (modified in-place).

    Returns:
        The repaired definition dict.
    """
    agents = definition.get("agents", [])
    connections = definition.get("connections", [])

    if not agents or not connections:
        return definition

    # Build ordered list and set of canonical agent_ids (strings)
    ordered_agent_ids: list[str] = []
    agent_id_set: set[str] = set()
    for entry in agents:
        if isinstance(entry, dict):
            aid = entry.get("agent_id")
            if aid is not None:
                s = str(aid)
                agent_id_set.add(s)
                ordered_agent_ids.append(s)
        elif isinstance(entry, str):
            agent_id_set.add(entry)
            ordered_agent_ids.append(entry)
        elif entry is not None:
            s = str(entry)
            agent_id_set.add(s)
            ordered_agent_ids.append(s)

    # Quick-check: do connections already use canonical IDs?
    all_conn_ids: set[str] = set()
    for conn in connections:
        fr = conn.get("from")
        to = conn.get("to")
        all_conn_ids.add(str(fr) if fr is not None else "")
        all_conn_ids.add(str(to) if to is not None else "")

    if all_conn_ids.issubset(agent_id_set):
        return definition  # No mismatch

    # ---------- build variant → canonical mapping ----------
    variant_map: dict[str | int, str] = {}

    for aid in agent_id_set:
        variant_map[aid] = aid
        try:
            uuid_form = normalize_to_uuid(aid)
            variant_map[uuid_form] = aid
            from echolib.id_utils import uuid_to_prefixed
            for prefix in ("agt_", "wf_"):
                prefixed = uuid_to_prefixed(uuid_form, prefix)
                variant_map[prefixed] = aid
            variant_map[uuid_form.replace("-", "")] = aid
        except (ValueError, Exception):
            pass

    # 1-based canvas-ID mapping (matches map_backend_to_frontend logic)
    for idx, agent_id in enumerate(ordered_agent_ids):
        canvas_id = idx + 1
        variant_map[canvas_id] = agent_id        # int key
        variant_map[str(canvas_id)] = agent_id   # str key

    # ---------- rewrite connections ----------
    for conn in connections:
        for field in ("from", "to"):
            val = conn.get(field)
            if val is None:
                continue
            # Direct lookup (int or str key)
            if val in variant_map:
                conn[field] = variant_map[val]
                continue
            # Coerce to string and retry
            val_str = str(val)
            if val_str in variant_map:
                conn[field] = variant_map[val_str]
                continue
            # Fallback: at least ensure string type
            if not isinstance(val, str):
                conn[field] = val_str

    _db_logger.debug("Repaired ID format mismatch in workflow definition")
    return definition


async def _owned_agent_ids(canvas_nodes: list, user_id: str) -> set:
    """
    Which of the agent ids named by a canvas the acting user actually owns.

    WHAT: Reads the ids off the nodes, resolves them against the ``agents``
          table scoped to ``user_id``, and returns the normalized UUIDs that
          came back.
    WHY:  ``map_frontend_to_backend`` preserves any well-formed ``agt_<uuid>``
          it finds on a node, on the assumption that an id present is an agent
          being updated. That assumption breaks on import: an exported workflow
          carries the *source* workspace's id on every node, so a save either
          wrote over another tenant's agent or -- once the repository refused
          that -- stored references the importer could not read, which is the
          "Agent not found" reported against an otherwise correct canvas.

          Ownership is resolved here rather than inside the mapper because the
          mapper is a pure, synchronous translator with no database access, and
          the route already holds both the session and the resolved user.

    INPUT: The canvas nodes as posted, and the acting user.
    OUTPUT: A set of normalized UUID strings. Empty when nothing resolves --
            in which case every id is treated as unowned and the save creates
            fresh agents, which is the safe direction: a new agent is
            recoverable, a cross-tenant write is not.
    """
    from sqlalchemy import select

    from echolib.models.agent import Agent as AgentModel
    from echolib.repositories.base import safe_uuid

    candidates: set = set()
    for node in canvas_nodes or []:
        if not isinstance(node, dict):
            continue
        raw = node.get("backend_id") or (node.get("config") or {}).get("agent_id")
        if not raw or not isinstance(raw, str):
            continue
        try:
            candidates.add(normalize_to_uuid(raw))
        except ValueError:
            continue  # A semantic name, never an agents-table id.

    if not candidates:
        return set()

    user_uuid = safe_uuid(user_id)
    if user_uuid is None:
        return set()

    uuids = [u for u in (safe_uuid(c) for c in candidates) if u is not None]
    if not uuids:
        return set()

    try:
        async with get_db_session() as db:
            rows = await db.execute(
                select(AgentModel.agent_id).where(
                    AgentModel.agent_id.in_(uuids),
                    AgentModel.user_id == user_uuid,
                    AgentModel.is_deleted == False,  # noqa: E712
                )
            )
            return {str(r) for r in rows.scalars().all()}
    except Exception:
        # Unresolvable ownership must not silently become "owns everything".
        _db_logger.warning(
            "Could not resolve agent ownership for this save; every node id "
            "will be treated as unowned and its agent created fresh.",
            exc_info=True,
        )
        return set()


async def _load_workflow_from_db(
    workflow_id: str,
    user_id: str,
    state: str = None
) -> dict | None:
    """
    Load workflow definition via the StorageGateway (DB-primary + FS-fallback).

    Phase 2 DB-first read path delegated to the central StorageGateway.
    Applies ID format repair to the returned definition before returning.

    Args:
        workflow_id: Workflow ID (prefixed like wf_xxx or raw UUID).
        user_id: Resolved user UUID string for multi-tenant scoping.
        state: Optional state hint for filesystem fallback.

    Returns:
        Workflow definition dict if found, None otherwise.
    """
    try:
        gateway = _get_storage_gateway()
        definition = await gateway.load_workflow(
            workflow_id, user_id, state=state
        )
    except Exception as exc:
        _db_logger.warning(
            "StorageGateway load failed for workflow '%s': %s",
            workflow_id, exc,
        )
        definition = None

    if definition:
        return _repair_definition_ids(definition)

    return None


router = APIRouter(prefix='/workflows', tags=['WorkflowApi'])

def svc() -> WorkflowService:
    return container.resolve('workflow.service')


def hitl_manager():
    """Get the singleton HITLManager (or HITLDBManager) from DI container."""
    return container.resolve('workflow.hitl')


async def _hydrate_hitl(hitl, run_id: str) -> None:
    """
    Make sure the worker serving this request knows about ``run_id``.

    The API runs four uvicorn worker processes (see the Dockerfile). A workflow
    pauses inside whichever worker served ``/chat/send``, but the reviewer's
    decision is a fresh HTTP request and is balanced to any of them -- so three
    times out of four it arrived at a process whose HITL state had never heard
    of the run. ``_validate_state`` raised, and the handlers below turn a
    ValueError into a 400. That is the "Approve and Reject both return 400"
    defect, and this is the single call that closes it.

    Best-effort by design: if neither the database nor the storage directory
    knows the run, the decision proceeds and fails with the same message it did
    before. This never turns a working decision into a broken one.
    """
    if not run_id:
        return

    try:
        loader = getattr(hitl, "ensure_loaded_async", None)
        if loader is not None:
            await loader(run_id)
        else:
            hitl.ensure_loaded(run_id)
    except Exception as exc:
        _db_logger.warning(
            "Could not rehydrate HITL state for run '%s': %s", run_id, exc
        )

# ==================== EXISTING ROUTES (UNCHANGED) ====================

@router.post('/create/prompt')
async def create_prompt(prompt: str, agents: list[Agent], user: UserContext = Depends(require_admin_or_above)):
    """Simple workflow creation (existing API)."""
    return svc().createFromPrompt(prompt, agents).model_dump()

@router.post('/create/canvas')
async def create_canvas(canvasJSON: dict, user: UserContext = Depends(require_admin_or_above)):
    """Canvas-based workflow creation (existing API)."""
    return svc().createFromCanvas(canvasJSON).model_dump()

@router.post('/validate')
async def validate(workflow: Workflow, user: UserContext = Depends(require_admin_or_above)):
    """Simple workflow validation (existing API)."""
    return svc().validate(workflow).model_dump()

# ==================== NEW ORCHESTRATOR ROUTES ====================

# Workflow Design
async def _design_prompt_sse(prompt: str, user_id, catalog: dict):
    """Stream AURA pipeline stage events as SSE (opt-in via ?stream=true).

    Emits: validation_start/result -> planning_start/result ->
    recruitment_start/agent_recruited*/recruitment_result -> dag_evaluation ->
    result (with echo_spec + catalog). Backward-compatible: the default JSON
    response is unchanged when stream is not requested.
    """
    from .aura_pipeline.orchestrator import iter_pipeline
    loop = asyncio.get_event_loop()
    queue: asyncio.Queue = asyncio.Queue()

    def _produce():
        try:
            for event_type, data in iter_pipeline(prompt, user_id=user_id):
                if event_type == "result":
                    data = {**data, "catalog": catalog}
                loop.call_soon_threadsafe(queue.put_nowait, (event_type, data))
        except Exception as e:
            loop.call_soon_threadsafe(queue.put_nowait, ("error", {"message": str(e)}))
        finally:
            loop.call_soon_threadsafe(queue.put_nowait, None)

    loop.run_in_executor(None, _produce)
    while True:
        item = await queue.get()
        if item is None:
            break
        event_type, data = item
        yield f"event: {event_type}\ndata: {_sse_json.dumps(data, default=str)}\n\n"


@router.post('/design/prompt')
async def design_from_prompt(
    request: Request,
    prompt: str = Query(None, description="Natural language prompt for workflow design"),
    stream: bool = Query(False, description="Stream AURA pipeline stages as SSE"),
    catalog_only: bool = Query(False, description="Return only the skills+tools catalog (no generation)"),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Design workflow from natural language prompt.
    Returns draft workflow + agent definitions.

    Accepts TWO formats:
    1. Query parameters: POST /workflows/design/prompt?prompt=...
    2. Request body: POST /workflows/design/prompt with {"prompt": "...", "default_llm": {...}}

    Query parameters take precedence over body if both are provided.
    """
    try:
        # Determine prompt and default_llm from either query params or body
        final_prompt = prompt  # from query param
        final_llm = None

        # If no query param, try to parse body
        if not final_prompt:
            try:
                body = await request.json()
                if isinstance(body, dict):
                    final_prompt = body.get("prompt")
                    final_llm = body.get("default_llm")
                    # Body may also request catalog-only mode.
                    catalog_only = catalog_only or bool(body.get("catalog_only"))
            except Exception:
                # No valid JSON body, that's okay if we have query params
                pass

        # AURA engine: validate -> plan -> recruit -> judge (the prior single-LLM
        # designer is no longer used). Returns the assembled spec + the AURA DAG.
        from .aura_pipeline import skills as _aura_skills, tools as _aura_tools
        # Skills+tools catalog (for the canvas node editor) so no extra endpoint
        # is required. Built up-front so it can be served standalone for manually
        # built workflows (catalog_only) as well as alongside a generated spec.
        _catalog = {
            "skills": [
                {"id": sid, "name": s.get("name", sid),
                 "description": s.get("description", ""), "category": s.get("category", "General")}
                for sid, s in _aura_skills.SKILL_REGISTRY.items()
            ],
            "tools": [
                {"id": tid, "name": info.get("name", tid), "description": info.get("description", "")}
                for tid, info in _aura_tools.get_tool_catalog().items()
            ],
        }

        # Catalog-only: serve the skills+tools catalog without running the
        # pipeline. Lets manually-built workflows populate the node editor's
        # Skills/Tools pickers (reuses this existing endpoint, no new route).
        if catalog_only:
            return {"catalog": _catalog}

        if not final_prompt:
            raise HTTPException(
                status_code=400,
                detail="Prompt is required. Provide via query parameter (?prompt=...) or request body ({\"prompt\": \"...\"})"
            )

        effective_user_id = resolve_user_id(user)
        # Live stage feedback (opt-in): stream pipeline stages as SSE.
        if stream:
            return StreamingResponse(
                _design_prompt_sse(final_prompt, effective_user_id, _catalog),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
            )
        from .aura_pipeline.orchestrator import run_pipeline
        try:
            result = await asyncio.to_thread(run_pipeline, final_prompt, effective_user_id)
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "WORKFLOW_DESIGN_PROMPT", effective_user_id)
        result["catalog"] = _catalog
        return result
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        error_detail = f"{str(e)}\n\nTraceback:\n{traceback.format_exc()}"
        raise HTTPException(status_code=400, detail=error_detail)

@router.post('/design/modify')
async def modify_workflow_from_prompt(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Modify existing workflow via natural language.

    Uses LLM-based intent detection (not keyword matching) to understand the user's
    request and apply appropriate modifications to the workflow.

    Request:
    {
        "prompt": "user's natural language request",
        "existing_workflow": {...current workflow...},
        "existing_agents": {...current agents...},
        "conversation_history": [...] (optional)
    }

    Supported intents (detected by LLM from natural language):
    - add: Add a new agent (e.g., "I think we need someone to check the code")
    - remove: Remove an agent (e.g., "The executor seems redundant")
    - modify: Modify agent config (e.g., "Make the analyzer focus on security")
    - add_tool: Add tool to agent (e.g., "Add web search to the reviewer")
    - remove_tool: Remove tool (e.g., "Remove calculator from the first agent")
    - reorder: Change agent order (e.g., "Switch the order of last two agents")
    - change_topology: Change execution model (e.g., "Run them all at once")
    - create_new: Signal to create fresh workflow (e.g., "Let's start over")
    - execute: Signal execution request, not modification (e.g., "Run this analysis")

    Response:
    {
        "intent": "add|remove|modify|...",
        "confidence": 0.0-1.0,
        "reasoning": "LLM's interpretation explanation",
        "changes": {...specific changes...},
        "updated_workflow": {...} or null,
        "updated_agents": {...} or null,
        "success": true|false,
        "message": "Human-readable status message"
    }
    """
    try:
        # AURA "Enhance" path: when AURA-shape agents + an instruction are sent,
        # refine the DAG with the AURA engine. (The legacy intent-based path
        # below is retained only for older callers.)
        if isinstance(request.get("agents"), list) and (
            request.get("instruction") or request.get("prompt")
        ):
            from .aura_pipeline.refine import refine_agents
            effective_user_id = resolve_user_id(user)
            _instr = request.get("instruction") or request.get("prompt") or ""
            _res = await asyncio.to_thread(
                refine_agents, request["agents"], _instr, effective_user_id
            )
            # echo_spec is OPTIONAL here — the canvas only consumes `agents` +
            # `dag_levels`. Never let spec adaptation failure sink the whole
            # Enhance (it would surface as a silent "Enhance failed" on the UI).
            try:
                from .aura_pipeline.spec_adapter import to_echo_spec
                _wf, _ea = to_echo_spec(_res.get("agents", []), workflow_name="refined_workflow")
                _res["echo_spec"] = {"workflow": _wf, "agents": _ea}
            except Exception as _spec_err:
                logging.getLogger(__name__).warning(
                    "enhance: echo_spec adaptation skipped (%s)", _spec_err
                )
            return _res

        prompt = request.get("prompt")
        existing_workflow = request.get("existing_workflow")
        existing_agents = request.get("existing_agents")
        conversation_history = request.get("conversation_history", [])

        if not prompt:
            raise HTTPException(
                status_code=400,
                detail="prompt is required"
            )

        if not existing_workflow:
            raise HTTPException(
                status_code=400,
                detail="existing_workflow is required"
            )

        if existing_agents is None:
            raise HTTPException(
                status_code=400,
                detail="existing_agents is required (can be empty dict)"
            )

        designer = container.resolve('workflow.designer')
        effective_user_id = resolve_user_id(user)
        try:
            result = await asyncio.to_thread(
                designer.modify_from_prompt,
                user_prompt=prompt,
                existing_workflow=existing_workflow,
                existing_agents=existing_agents,
                conversation_history=conversation_history,
                user_id=effective_user_id,
            )
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "WORKFLOW_DESIGN_MODIFY", effective_user_id)

        return result

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        error_detail = f"{str(e)}\n\nTraceback:\n{traceback.format_exc()}"
        raise HTTPException(status_code=400, detail=error_detail)


@router.post('/build')
async def build_workflow_manual(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Build workflow manually with agent I/O schema specification.
    Allows reusing existing agents and defining their I/O schemas for this workflow.

    Request format:
    {
      "workflow": { ... },
      "agent_schemas": {
        "agt_001": {
          "input_schema": ["sales_data"],
          "output_schema": ["analysis"]
        },
        "agt_002": {
          "input_schema": ["analysis"],
          "output_schema": ["report"]
        }
      },
      "update_base_agents": false  // Optional: update base agent definitions
    }
    """
    try:
        workflow = request.get("workflow")
        agent_schemas = request.get("agent_schemas", {})
        update_base = request.get("update_base_agents", False)

        if not workflow:
            raise HTTPException(status_code=400, detail="workflow field required")

        # If update_base_agents is True, update the agent registry
        # (skipped when AGENT_DB_WRITE_ONLY — FS writes disabled)
        if update_base and agent_schemas and not _settings.AGENT_DB_WRITE_ONLY:
            registry = container.resolve('agent.registry')
            for agent_id, schemas in agent_schemas.items():
                try:
                    registry.update_agent(agent_id, schemas)
                except Exception as e:
                    print(f"Warning: Failed to update agent {agent_id}: {e}")

        # Store agent schema overrides in workflow metadata
        if agent_schemas:
            if "metadata" not in workflow:
                workflow["metadata"] = {}
            workflow["metadata"]["agent_schemas"] = agent_schemas

        return {"workflow": workflow, "agent_schemas": agent_schemas}

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Validation
@router.post('/validate/draft')
async def validate_draft(req: WorkflowValidationRequest, user: UserContext = Depends(require_admin_or_above)):
    """Validate draft workflow (sync only, before HITL)."""
    try:
        validator = container.resolve('workflow.validator')
        result = validator.validate_draft(req.workflow, req.agents)
        return result.to_dict()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/validate/final')
async def validate_final(req: WorkflowValidationRequest, user: UserContext = Depends(require_admin_or_above)):
    """Validate workflow after HITL (full async validation)."""
    try:
        validator = container.resolve('workflow.validator')
        result = await validator.validate_final(req.workflow, req.agents)

        if result.is_valid():
            # Mark as validated
            req.workflow["status"] = "validated"
            req.workflow["validation"] = {
                "validated_at": "placeholder_timestamp",  # TODO: Add real timestamp
                "validation_hash": "placeholder_hash"  # TODO: Add real hash
            }

        return result.to_dict()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Draft Listing
@router.get('/draft/list')
async def list_draft_workflows(
    page: int = Query(1, ge=1, description="Page number (1-based)"),
    page_size: int = Query(20, ge=1, le=1000, description="Items per page"),
    search: Optional[str] = Query(None, description="Search term for workflow name"),
    user: UserContext = Depends(require_admin_or_above),
):
    """List workflows in draft state with pagination and optional search."""
    from echolib.schemas.pagination import PaginatedResponse

    try:
        effective_user_id = resolve_user_id(user)
        gateway = _get_storage_gateway()

        # Keep draft semantics explicit and preserve DB-primary/FS-fallback
        # behavior while serving paginated envelopes.
        workflows = await gateway.list_workflows_by_status(
            effective_user_id,
            "draft",
        )

        if search:
            needle = search.strip().lower()
            if needle:
                workflows = [
                    w for w in workflows
                    if needle in str((w or {}).get("name", "")).lower()
                ]

        total = len(workflows)
        start = (page - 1) * page_size
        end = start + page_size
        page_items = workflows[start:end]

        # Apply ID repair to each definition
        repaired_workflows = []
        for w in page_items:
            w_dict = w if isinstance(w, dict) else (w.to_dict() if hasattr(w, 'to_dict') else vars(w))
            repaired = _repair_definition_ids(w_dict)
            repaired.setdefault("icon", "workflow")
            repaired_workflows.append(repaired)

        return PaginatedResponse(
            page=page,
            page_size=page_size,
            total=total,
            items=repaired_workflows,
        )
    except Exception as e:
        return {
            "page": page,
            "page_size": page_size,
            "total": 0,
            "items": [],
        }

@router.post('/final/save')
async def save_final(req: SaveFinalRequest, user: UserContext = Depends(require_admin_or_above)):
    """Save workflow as final (versioned, immutable).

    Phase 2: Filesystem + Database dual-write with version snapshot.
    """
    try:
        storage = container.resolve('workflow.storage')

        # Filesystem write (skipped when WORKFLOW_DB_WRITE_ONLY)
        result = {}
        if not _settings.WORKFLOW_DB_WRITE_ONLY:
            result = storage.save_final_workflow(req.workflow)
        else:
            _db_logger.info("Filesystem write skipped for workflow (WORKFLOW_DB_WRITE_ONLY=true)")
            result = {"path": "db_only", "workflow_id": req.workflow.get("workflow_id", "")}

        # Phase 2: Persist final workflow to database + create version row
        db_saved = False
        try:
            import copy as _copy

            effective_user_id = resolve_user_id(user)
            workflow_data = _copy.deepcopy(req.workflow)
            wf_id = workflow_data.get("workflow_id", "")
            db_uuid = normalize_to_uuid(wf_id)
            version = workflow_data.get("version", "1.0")
            notes = workflow_data.get("metadata", {}).get("save_notes")

            async with get_db_session() as db:
                await _workflow_repo.save_with_agents(
                    db=db,
                    user_id=effective_user_id,
                    workflow_data=workflow_data,
                    db_workflow_id=db_uuid,
                )
                await _workflow_repo.create_version(
                    db=db,
                    workflow_id=db_uuid,
                    version=version,
                    created_by=effective_user_id,
                    notes=notes,
                )
            db_saved = True
            _db_logger.info(f"Workflow {wf_id} saved to DB as final (version={version})")
        except Exception as db_err:
            _db_logger.warning(f"Database save failed for final workflow: {db_err}")

        result["db_saved"] = db_saved
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get('/{workflow_id}/final/{version}')
async def load_final(workflow_id: str, version: str, user: UserContext = Depends(require_user)):
    """Load specific final version.

    Phase 2: Reads via StorageGateway (DB-primary, FS-fallback).
    """
    try:
        gateway = _get_storage_gateway()
        definition = await gateway.load_workflow_version(workflow_id, version)

        if definition:
            return definition

        raise HTTPException(status_code=404, detail="Workflow version not found")
    except HTTPException:
        raise
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Workflow version not found")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get('/{workflow_id}/versions')
async def list_versions(workflow_id: str, user: UserContext = Depends(require_user)):
    """List all final versions of a workflow.

    Phase 2: Reads via StorageGateway (DB-primary, FS-fallback).
    """
    try:
        gateway = _get_storage_gateway()
        versions = await gateway.list_workflow_versions(workflow_id)

        if not versions:
            raise HTTPException(status_code=404, detail="No versions found")

        return {
            "workflow_id": workflow_id,
            "versions": versions
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/clone')
async def clone_final(req: CloneWorkflowRequest, user: UserContext = Depends(require_admin_or_above)):
    """Clone final workflow to draft for editing.

    Phase 2: Loads source workflow via StorageGateway (DB-primary, FS-fallback).
    """
    try:
        effective_user_id = resolve_user_id(user)

        # Load the specific version via gateway
        gateway = _get_storage_gateway()
        source_def = await gateway.load_workflow_version(
            req.workflow_id, req.from_version
        )

        storage = container.resolve('workflow.storage')

        draft = None
        if source_def:
            import copy as _copy
            draft = _copy.deepcopy(source_def)
            draft["status"] = "draft"
            draft.setdefault("metadata", {})["cloned_from_version"] = req.from_version
            # Filesystem write (skipped when WORKFLOW_DB_WRITE_ONLY)
            if not _settings.WORKFLOW_DB_WRITE_ONLY:
                storage.save_workflow(draft, state="draft")
            else:
                _db_logger.info("Filesystem write skipped for workflow clone (WORKFLOW_DB_WRITE_ONLY=true)")
        else:
            # Source not found via gateway (DB and FS both missed)
            _db_logger.info(
                "Clone source %s@%s not found via gateway",
                req.workflow_id, req.from_version,
            )

        # Phase 2: Persist cloned draft to database
        db_saved = False
        if draft:
            try:
                import copy as _copy

                db_draft = _copy.deepcopy(draft)
                draft_wf_id = db_draft.get("workflow_id", req.workflow_id)
                db_uuid = normalize_to_uuid(draft_wf_id)

                async with get_db_session() as db:
                    await _workflow_repo.save_with_agents(
                        db=db,
                        user_id=effective_user_id,
                        workflow_data=db_draft,
                        db_workflow_id=db_uuid,
                    )
                db_saved = True
                _db_logger.info(
                    f"Cloned workflow {draft_wf_id} saved to DB as draft"
                )
            except Exception as db_err:
                _db_logger.warning(
                    f"Database save failed for cloned draft {req.workflow_id}: {db_err}"
                )

        return {
            "message": "Workflow cloned to draft",
            "workflow_id": req.workflow_id,
            "base_version": req.from_version,
            "db_saved": db_saved,
        }
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Final workflow not found")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Load workflow by ID (DB-first)
@router.get('/{workflow_id}')
async def load_workflow(workflow_id: str, user: UserContext = Depends(require_user)):
    """Load a workflow by ID, searching across draft/final states.

    Phase 2: DB is the primary source.
    """
    try:
        effective_user_id = resolve_user_id(user)
        agent_registry = container.resolve('agent.registry')

        # DB-first: load from database (covers draft + validated + final states)
        workflow = await _load_workflow_from_db(workflow_id, effective_user_id)

        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        # Resolve every entry to the agent's current definition.
        #
        # Since Phase 8 the workflow stores *references*, not copies: the
        # agents table is the source of truth and `save_with_agents` strips
        # agent state out of the definition after upserting it. This route used
        # to hand those entries straight back, so a reopened canvas received a
        # stub carrying only `agent_id` and `name` -- no instructions, no
        # tools, no model -- and rendered an empty node. The runtime read path
        # was migrated at the time; this one was missed.
        #
        # `resolve_workflow_agents` is the same resolver the executor uses, so
        # the canvas now shows exactly what a run would execute. It falls back
        # to the embedded copy when a record no longer exists, which keeps a
        # workflow whose agent was deleted openable, and handles bare-string
        # entries through the filesystem registry.
        #
        # Off-thread: it bridges to async internally, and awaiting the loop
        # from the loop stalls until the resolution timeout (Phase 5b.1).
        from .runtime.agent_resolution import resolve_workflow_agents

        agents = await asyncio.to_thread(
            resolve_workflow_agents,
            workflow,
            effective_user_id,
            agent_registry=agent_registry,
        )

        # The resolver drops an entry whose record is gone and which carries no
        # embedded copy. That is right for a run -- there is nothing to
        # execute -- but wrong for a canvas: the node would disappear and its
        # connections would dangle, silently editing the user's graph. Put the
        # stored entry back so the node still renders and the author can see
        # what needs re-pointing.
        for entry in workflow.get("agents", []):
            if not isinstance(entry, dict):
                continue
            entry_id = entry.get("agent_id") or entry.get("id")
            if entry_id and entry_id not in agents:
                agents[entry_id] = entry

        return {
            "workflow": workflow,
            "agents": agents
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Execution
@router.post('/execute')
async def execute_workflow(req: ExecuteWorkflowRequest, user: UserContext = Depends(require_admin_or_above)):
    """Execute workflow (test or final mode)."""
    try:
        effective_user_id = resolve_user_id(user)
        # Inject authenticated user_id into input_payload so that
        # executor._stamp_runtime_user_id() picks up the server-side
        # identity instead of relying on untrusted client data.
        input_payload = req.input_payload if req.input_payload is not None else {}
        input_payload["user_id"] = effective_user_id
        input_payload["_enable_runtime_resilience_guards"] = True

        workflow_def = await _load_workflow_from_db(req.workflow_id, effective_user_id)
        if workflow_def:
            _enforce_workflow_runtime_guard(workflow_def, req.workflow_id)

        executor = container.resolve('workflow.executor')
        # Off-thread: the executor compiles and runs the graph synchronously, so
        # calling it here held the event loop for the whole run. It also blocked
        # connector resolution, which awaits the connector services on that loop.
        # The sibling route at execute_workflow_by_id already did this.
        try:
            result = await asyncio.to_thread(
                executor.execute_workflow,
                workflow_id=req.workflow_id,
                execution_mode=req.mode,
                version=req.version,
                input_payload=input_payload,
            )
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "WORKFLOW_EXECUTE", effective_user_id)

        # Format user-facing output fields so raw JSON never leaks to the UI.
        # The formatter is safe: if it cannot parse JSON it returns text as-is.
        if isinstance(result, dict) and "output" in result:
            from apps.workflow.runtime.response_formatter import format_output_for_ui
            from apps.workflow.runtime.generated_file_links import register_generated_files
            _output = result["output"]
            if isinstance(_output, dict):
                for _fmt_key in ("crew_result", "_last_agent_output", "parallel_output", "result"):
                    _val = _output.get(_fmt_key)
                    if _val and isinstance(_val, str):
                        _val = format_output_for_ui(_val)
                        # Register any [GENERATED_FILE:...] markers as standalone
                        # downloads and swap them for a clickable download link.
                        _output[_fmt_key] = await register_generated_files(_val)

        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post('/{workflow_id}/execute')
async def execute_workflow_by_id(
    workflow_id: str,
    req: ExecuteWorkflowByIdRequest,
    user: UserContext = Depends(require_admin_or_above)
):
    """Execute workflow by ID in URL path (for agentic app integration).
    
    Parameterized endpoint to support frontend patterns that pass workflow_id
    as a path parameter rather than in the request body. Delegates to the
    same execution logic as POST /execute.
    """
    try:
        _db_logger.info(f"[AGENTIC_EXEC] START: workflow_id={workflow_id}, request_mode={req.mode}, request_payload_keys={list((req.input_payload or {}).keys())}")
        
        # Override workflow_id from path parameter (takes precedence over body)
        req.workflow_id = workflow_id
        
        effective_user_id = resolve_user_id(user)
        _db_logger.info(f"[AGENTIC_EXEC] User resolved: {effective_user_id}")
        
        # Inject authenticated user_id into input_payload so that
        # executor._stamp_runtime_user_id() picks up the server-side
        # identity instead of relying on untrusted client data.
        input_payload = req.input_payload if req.input_payload is not None else {}
        input_payload["user_id"] = effective_user_id
        input_payload["_enable_runtime_resilience_guards"] = True

        workflow_def = await _load_workflow_from_db(req.workflow_id, effective_user_id)
        if workflow_def:
            _enforce_workflow_runtime_guard(workflow_def, req.workflow_id)
        
        _db_logger.info(f"[AGENTIC_EXEC] Resolving workflow executor from DI container...")
        executor = container.resolve('workflow.executor')
        
        _db_logger.info(f"[AGENTIC_EXEC] Calling execute_workflow: workflow_id={req.workflow_id}, mode={req.mode}, version={req.version}")
        # Run sync executor in thread pool to avoid deadlock between async context and sync-to-async bridge.
        # This prevents TimeoutError in run_db_coro_sync() by ensuring the sync code runs in its own thread
        # where the event loop can properly handle database operations without blocking.
        try:
            result = await asyncio.to_thread(
                executor.execute_workflow,
                workflow_id=req.workflow_id,
                execution_mode=req.mode,
                version=req.version,
                input_payload=input_payload
            )
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "WORKFLOW_EXECUTE_BY_ID", effective_user_id)
        
        _db_logger.info(f"[AGENTIC_EXEC] Workflow execution completed successfully")

        # Format user-facing output fields so raw JSON never leaks to the UI.
        # The formatter is safe: if it cannot parse JSON it returns text as-is.
        if isinstance(result, dict) and "output" in result:
            from apps.workflow.runtime.response_formatter import format_output_for_ui
            from apps.workflow.runtime.generated_file_links import register_generated_files
            _output = result["output"]
            if isinstance(_output, dict):
                for _fmt_key in ("crew_result", "_last_agent_output", "parallel_output", "result"):
                    _val = _output.get(_fmt_key)
                    if _val and isinstance(_val, str):
                        _val = format_output_for_ui(_val)
                        # Register any [GENERATED_FILE:...] markers as standalone
                        # downloads and swap them for a clickable download link.
                        _output[_fmt_key] = await register_generated_files(_val)

        _db_logger.info(f"[AGENTIC_EXEC] SUCCESS: Returning result")
        return result
    except Exception as e:
        error_trace = traceback.format_exc()
        _db_logger.error(f"[AGENTIC_EXEC] FAILED - Exception: {type(e).__name__}: {str(e)}")
        _db_logger.error(f"[AGENTIC_EXEC] TRACEBACK:\n{error_trace}")
        raise HTTPException(
            status_code=400,
            detail=f"Workflow execution failed: {type(e).__name__}: {str(e)}"
        )


@router.get('/generated-files/{download_key}')
async def download_workflow_generated_file(
    download_key: str,
    user: UserContext = Depends(require_user),
):
    """Download a file produced by a workflow run, by its URL-safe key.

    Workflow-generated files are registered standalone (no owning chat session /
    application), so they cannot be served by the application-scoped download
    route. This serves them by ``download_key`` alone — possession of the random
    key is the authorization credential, the same model as the appmgr route.
    """
    import os as _os
    from datetime import datetime as _dt, timezone as _tz
    from fastapi.responses import FileResponse
    from echolib.repositories.generated_file_repo import GeneratedFileRepository

    user_id = resolve_user_id(user)
    _db_logger.info(
        "workflow_generated_file_download_attempt",
        extra={
            "download_key": download_key,
            "user_id": user_id,
        },
    )

    async with get_db_session() as db:
        record = await GeneratedFileRepository().get_by_download_key(db, download_key)

    if record is None:
        _db_logger.warning(
            "workflow_generated_file_download_missing_record",
            extra={
                "download_key": download_key,
                "user_id": user_id,
            },
        )
        raise HTTPException(status_code=404, detail="Generated file not found.")
    if record.expires_at and record.expires_at < _dt.now(_tz.utc):
        _db_logger.info(
            "workflow_generated_file_download_expired",
            extra={
                "download_key": download_key,
                "user_id": user_id,
            },
        )
        raise HTTPException(status_code=410, detail="This file has expired and is no longer available.")
    is_valid_path, path_reason, normalized_path, _size_bytes = validate_generated_file_path(
        record.file_path,
        require_exists=True,
        require_non_empty=False,
    )
    if not is_valid_path:
        _db_logger.warning(
            "workflow_generated_file_download_missing_disk_file",
            extra={
                "download_key": download_key,
                "file_path": record.file_path,
                "resolved_file_path": normalized_path,
                "validation_reason": path_reason,
                "file_path_is_absolute": _os.path.isabs(record.file_path),
                "cwd": _os.getcwd(),
                "app_uploads_dir": _os.getenv("APP_UPLOADS_DIR"),
                "record_expires_at": record.expires_at.isoformat() if record.expires_at else None,
                "user_id": user_id,
            },
        )
        raise HTTPException(status_code=410, detail="The generated file is no longer available on disk.")

    _db_logger.info(
        "workflow_generated_file_download_success",
        extra={
            "download_key": download_key,
            "file_path": record.file_path,
            "user_id": user_id,
        },
    )

    return FileResponse(
        path=normalized_path,
        media_type=record.mime_type or "application/octet-stream",
        filename=record.original_filename,
    )

# Visualization
@router.get('/{workflow_id}/graph')
async def get_graph(workflow_id: str, state: str = "draft", user: UserContext = Depends(require_user)):
    """Get graph representation of workflow.

    Phase 2: Loads workflow definition via StorageGateway (DB-primary)
    and passes the pre-loaded dict to the graph mapper.
    """
    try:
        effective_user_id = resolve_user_id(user)
        graph_mapper = container.resolve('workflow.graph_mapper')

        # DB-primary via gateway helper (already handles FS fallback)
        workflow_def = await _load_workflow_from_db(
            workflow_id, effective_user_id, state=state
        )

        if workflow_def:
            graph = graph_mapper.get_graph(
                workflow_id, state, workflow_def=workflow_def
            )
        else:
            raise HTTPException(status_code=404, detail="Workflow not found")

        return graph
    except HTTPException:
        raise
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Workflow not found")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ==================== NODE MAPPER ROUTES ====================

@router.post('/canvas/to-backend')
async def canvas_to_backend(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Convert frontend canvas to backend workflow format.

    Request:
    {
      "canvas_nodes": [...],
      "connections": [...],
      "workflow_name": "Optional explicit name"
    }
    """
    try:
        node_mapper = container.resolve('workflow.node_mapper')

        canvas_nodes = request.get("canvas_nodes", [])
        connections = request.get("connections", [])
        workflow_name = request.get("workflow_name")

        if not canvas_nodes:
            raise HTTPException(status_code=400, detail="canvas_nodes required")

        workflow, agents = node_mapper.map_frontend_to_backend(
            canvas_nodes=canvas_nodes,
            connections=connections,
            workflow_name=workflow_name,
            auto_generate_name=True,
            icon=request.get("icon"),
            owned_agent_ids=await _owned_agent_ids(
                canvas_nodes, resolve_user_id(user)
            ),
        )

        return {
            "workflow": workflow,
            "agents": agents
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/backend/to-canvas')
async def backend_to_canvas(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Convert backend workflow to frontend canvas format.

    Request:
    {
      "workflow": {...},
      "agents": {...}
    }
    """
    try:
        node_mapper = container.resolve('workflow.node_mapper')

        workflow = request.get("workflow")
        agents = request.get("agents")

        # Check workflow exists (required)
        if not workflow:
            raise HTTPException(
                status_code=400,
                detail="workflow is required"
            )

        # agents can be empty dict {} but must be present
        if agents is None:
            raise HTTPException(
                status_code=400,
                detail="agents is required (can be empty dict)"
            )

        canvas_nodes, connections = node_mapper.map_backend_to_frontend(
            workflow=workflow,
            agents_dict=agents
        )

        return {
            "canvas_nodes": canvas_nodes,
            "connections": connections,
            "workflow_name": workflow.get("name", "Untitled Workflow"),
            "workflow_icon": workflow.get("icon", "workflow")
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        error_detail = f"{str(e)}\n\nTraceback:\n{traceback.format_exc()}"
        print(f"ERROR in backend_to_canvas: {error_detail}")
        raise HTTPException(status_code=500, detail=error_detail)


@router.post('/canvas/save')
async def save_canvas_workflow(
    request: dict,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Save canvas workflow directly (converts + validates + saves).

    Implements write strategy:
    - DRAFT save: Filesystem + Database
    - FINAL save: Filesystem + Database (handled by /save-final endpoint)

    Request:
    {
      "canvas_nodes": [...],
      "connections": [...],
      "workflow_name": "Optional",
      "save_as": "draft|temp",
      "workflow_id": "Optional - preserves existing ID if provided"
    }
    """
    try:
        node_mapper = container.resolve('workflow.node_mapper')
        validator = container.resolve('workflow.validator')
        storage = container.resolve('workflow.storage')
        agent_registry = container.resolve('agent.registry')

        # Convert to backend format (preserve existing workflow_id if provided).
        #
        # Ownership is resolved first so a node naming an agent this user does
        # not own is treated as a definition to create rather than a record to
        # update. Without it an imported canvas re-references the exporting
        # workspace's agents on every save.
        _canvas_nodes = request.get("canvas_nodes", [])
        workflow, agents = node_mapper.map_frontend_to_backend(
            canvas_nodes=_canvas_nodes,
            connections=request.get("connections", []),
            workflow_name=request.get("workflow_name"),
            execution_model=request.get("execution_model"),
            workflow_id=request.get("workflow_id"),
            icon=request.get("icon"),
            owned_agent_ids=await _owned_agent_ids(
                _canvas_nodes, resolve_user_id(user)
            ),
        )

        # Validate
        validation_result = validator.validate_draft(workflow, agents)
        if not validation_result.is_valid():
            return {
                "success": False,
                "errors": validation_result.errors,
                "warnings": validation_result.warnings
            }

        # Register agents (skipped when AGENT_DB_WRITE_ONLY)
        if not _settings.AGENT_DB_WRITE_ONLY:
            for agent_id, agent in agents.items():
                agent["agent_id"] = agent_id
                agent_registry.register_agent(agent)
        else:
            _db_logger.info("Filesystem agent registration skipped (AGENT_DB_WRITE_ONLY=true)")

        # Save workflow
        save_as = request.get("save_as", "draft")
        if save_as == "temp":
            # "temp" is no longer a filesystem state; treat as validated draft
            workflow["status"] = "validated"
            workflow.setdefault("metadata", {})["testing"] = True
            save_as = "draft"

        # Filesystem save (skipped when WORKFLOW_DB_WRITE_ONLY)
        result = {}
        if not _settings.WORKFLOW_DB_WRITE_ONLY:
            result = storage.save_workflow(workflow, state=save_as)
        else:
            _db_logger.info("Filesystem write skipped for workflow (WORKFLOW_DB_WRITE_ONLY=true)")

        # Database save for DRAFT and FINAL states
        db_saved = False
        if save_as in ("draft", "final"):
            try:
                import copy as _copy

                # Prepare workflow data for database
                # Compute UUID for DB primary key separately so the
                # definition JSONB preserves the original wf_ prefixed ID
                db_workflow_data = _copy.deepcopy(workflow)
                try:
                    db_uuid = normalize_to_uuid(workflow["workflow_id"])
                except ValueError as e:
                    _db_logger.warning(f"Cannot convert workflow_id for DB save: {e}")
                    raise

                # NOTE: Do NOT convert agent_ids inside the definition.
                # The definition JSONB must store the exact same JSON as
                # the filesystem (prefixed IDs like agt_xxx). The agent_repo
                # upsert method handles the UUID conversion for the PK column
                # internally. Converting here broke connections (which still
                # reference prefixed IDs), causing LangGraph node lookup errors.

                effective_user_id = resolve_user_id(user)
                async with get_db_session() as db:
                    await _workflow_repo.save_with_agents(
                        db=db,
                        user_id=effective_user_id,
                        workflow_data=db_workflow_data,
                        db_workflow_id=db_uuid
                    )
                db_saved = True
                _db_logger.info(f"Workflow {workflow['workflow_id']} saved to database")
            except Exception as e:
                # Deliberately not fatal, but no longer quiet. The "filesystem
                # save already succeeded" this degraded to does not happen any
                # more: WORKFLOW_DB_WRITE_ONLY defaults on, so there is no
                # filesystem copy, and LEGACY_FILE_READ_ENABLED defaults off,
                # so the list reads only the database. A failure here means the
                # workflow was persisted nowhere, which is worth a traceback.
                # `db_saved` stays False and the caller must not report a save.
                _db_logger.error(
                    f"Database save failed for workflow {workflow['workflow_id']} "
                    f"- it was persisted nowhere: {e}",
                    exc_info=True,
                )

        return {
            "success": True,
            "workflow_id": workflow["workflow_id"],
            "workflow_name": workflow["name"],
            "workflow_icon": workflow.get("icon", "workflow"),
            "state": save_as,
            "db_saved": db_saved,
            **result
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ==================== WORKFLOW CHAT (RUNTIME TESTING) ====================

@router.post('/chat/start')
async def start_chat_session(
    request: dict,
    user: UserContext = Depends(require_user),
):
    """
    Start a new chat session for workflow testing.

    Creates both a filesystem session (for chat operations) and a database
    session (for history listing). Dual-write ensures history is visible
    while maintaining filesystem-based chat functionality.

    Request:
    {
      "workflow_id": "wf_xxx",
      "mode": "test",  // or "workflow_mode" for backward compatibility
      "version": null,
      "initial_context": {}  // or "context" for backward compatibility
    }
    """
    try:
        from .runtime.chat_session import ChatSessionManager

        session_manager = ChatSessionManager()

        workflow_id = request.get("workflow_id")
        # Accept both 'mode' and 'workflow_mode' for backward compatibility
        mode = request.get("mode") or request.get("workflow_mode", "test")
        version = request.get("version")
        # Accept both 'initial_context' and 'context' for backward compatibility
        initial_context = request.get("initial_context") or request.get("context", {})

        if not workflow_id:
            raise HTTPException(status_code=400, detail="workflow_id required")

        # Create filesystem session (for chat operations)
        session = session_manager.create_session(
            workflow_id=workflow_id,
            workflow_mode=mode,
            workflow_version=version,
            initial_context=initial_context
        )

        # Also create database session for history/listing
        # This enables the History button to show workflow sessions
        db_session_created = False
        try:
            # Convert workflow_id to UUID for context_id if possible
            context_id_uuid = None
            try:
                context_id_uuid = normalize_to_uuid(workflow_id)
            except ValueError:
                # If conversion fails, leave context_id as None
                _db_logger.warning(f"Could not convert workflow_id to UUID: {workflow_id}")

            # Prepare session data for database
            db_session_data = {
                "session_id": session.session_id,  # Already a proper UUID from ChatSessionManager
                "title": f"Workflow Test: {workflow_id}",
                "context_type": "workflow",
                "context_id": context_id_uuid,
                "workflow_mode": mode,
                "workflow_version": version,
                "messages": [],  # Will be populated by chat operations
                "context_data": initial_context or {},
                "variables": session.variables,
                "state_schema": session.state_schema,
            }

            effective_user_id = resolve_user_id(user)
            async with get_db_session() as db:
                await _session_repo.create(
                    db=db,
                    user_id=effective_user_id,
                    data=db_session_data
                )
            db_session_created = True
            _db_logger.info(f"Database session created for workflow chat: {session.session_id}")
        except Exception as e:
            # Log with full traceback for debugging FK constraint issues
            _db_logger.error(f"Database session creation failed: {e}", exc_info=True)
            # Chat will still work via filesystem session

        return {
            "session_id": session.session_id,
            "workflow_id": session.workflow_id,
            "mode": session.workflow_mode,
            "created_at": session.created_at.isoformat(),
            "message": "Chat session started. Send messages to test workflow.",
            "db_session_created": db_session_created
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/chat/send')
async def send_chat_message(
    request: dict,
    background_tasks: BackgroundTasks,
    user: UserContext = Depends(require_user),
):
    """
    Send message and execute workflow with real-time transparency.

    This endpoint implements the "dual endpoint" pattern:
    1. Returns run_id immediately (before execution)
    2. Client connects to WebSocket for real-time updates
    3. Execution runs in background

    Request:
    {
      "session_id": "session_xxx",
      "message": "Analyze this feedback: Great product!",
      "execute_workflow": true
    }

    Response (immediate):
    {
      "session_id": "session_xxx",
      "run_id": "run_xxx",
      "status": "executing",
      "message": "Connect to WebSocket for real-time updates."
    }

    WebSocket: ws://host/ws/execution/{run_id}
    """
    from .runtime.chat_session import ChatSessionManager
    from echolib.utils import new_id
    from echolib.config import settings
    from datetime import datetime, timezone

    try:
        session_manager = ChatSessionManager()
        executor = container.resolve('workflow.executor')

        session_id = request.get("session_id")
        message = request.get("message")
        execute_workflow = request.get("execute_workflow", True)

        if not session_id or not message:
            raise HTTPException(
                status_code=400,
                detail="session_id and message required"
            )

        # Phase 2: Try DB first, then fall back to filesystem session manager
        session = None
        effective_user_id = resolve_user_id(user)

        # DB read for session
        try:
            async with get_db_session() as db:
                db_session = await _session_repo.get_by_id(
                    db, session_id, effective_user_id
                )
        except Exception as db_err:
            _db_logger.warning(f"DB session read failed for {session_id}: {db_err}")
            db_session = None

        # Filesystem session is still needed for the ChatSessionManager's
        # in-memory operations (add_user_message, add_assistant_message, etc.)
        session = session_manager.get_session(session_id)
        if not session and not db_session:
            raise HTTPException(status_code=404, detail="Session not found")

        # If filesystem session is missing but DB has it, try reconstructing
        # runtime session from DB before failing.
        if not session and db_session:
            try:
                from .runtime.chat_session import ChatSession, ChatMessage

                if isinstance(db_session, dict):
                    db_session_data = db_session
                elif hasattr(db_session, "to_dict"):
                    db_session_data = db_session.to_dict()
                else:
                    db_session_data = {
                        "session_id": str(getattr(db_session, "session_id", "") or ""),
                        "context_id": str(getattr(db_session, "context_id", "") or ""),
                        "workflow_mode": getattr(db_session, "workflow_mode", None),
                        "workflow_version": getattr(db_session, "workflow_version", None),
                        "messages": getattr(db_session, "messages", []) or [],
                        "context_data": getattr(db_session, "context_data", {}) or {},
                    }

                workflow_id = db_session_data.get("workflow_id") or db_session_data.get("context_id")
                if workflow_id and isinstance(workflow_id, str) and not workflow_id.startswith("wf_"):
                    try:
                        workflow_id = uuid_to_prefixed(workflow_id, "wf_")
                    except Exception:
                        workflow_id = str(workflow_id)

                if not workflow_id:
                    raise ValueError("missing workflow identifier in DB session")

                recovered = ChatSession(
                    session_id=session_id,
                    workflow_id=str(workflow_id),
                    workflow_mode=db_session_data.get("workflow_mode") or "test",
                    workflow_version=db_session_data.get("workflow_version"),
                    context=db_session_data.get("context_data") or {},
                )

                recovered.messages = []
                for msg in db_session_data.get("messages") or []:
                    if not isinstance(msg, dict):
                        continue
                    msg_ts = msg.get("timestamp")
                    parsed_ts = None
                    if isinstance(msg_ts, str) and msg_ts:
                        try:
                            parsed_ts = datetime.fromisoformat(msg_ts.replace("Z", "+00:00"))
                        except Exception:
                            parsed_ts = None
                    recovered.messages.append(ChatMessage(
                        role=msg.get("role", "assistant"),
                        content=str(msg.get("content", "")),
                        timestamp=parsed_ts or datetime.now(timezone.utc),
                        agent_id=msg.get("agent_id"),
                        metadata=msg.get("metadata") or {},
                    ))

                recovered.run_ids = [
                    str(m.get("run_id"))
                    for m in (db_session_data.get("messages") or [])
                    if isinstance(m, dict) and m.get("run_id")
                ]

                session_manager.restore_session(recovered)
                session = recovered
                _db_logger.warning(
                    f"Session {session_id} missing in runtime; recovered from DB for workflow {workflow_id}"
                )
            except Exception as recover_err:
                _db_logger.error(
                    f"Session {session_id} found in DB but runtime recovery failed: {recover_err}",
                    exc_info=True,
                )
                raise HTTPException(
                    status_code=404,
                    detail="Session not found in runtime. Please start a new session."
                )

        # Add user message to filesystem session
        session_manager.add_user_message(session_id, message)

        # Sync user message to database session and update title if first user message
        try:
            # Build message dict for database
            db_message = {
                "id": f"msg_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')[:18]}",
                "role": "user",
                "content": message,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "agent_id": None,
                "run_id": None,
                "metadata": {}
            }

            async with get_db_session() as db:
                # Add user message to database session
                await _session_repo.add_message(
                    db=db,
                    session_id=session_id,
                    user_id=effective_user_id,
                    message=db_message
                )

                # Check if this is the first user message by counting user messages
                # in the filesystem session (excluding system messages)
                user_messages = [m for m in session.messages if m.role == "user"]
                is_first_user_message = len(user_messages) == 1  # Just added one

                if is_first_user_message:
                    # Truncate message to 50 chars for title
                    truncated_title = message[:50] + "..." if len(message) > 50 else message
                    await _session_repo.update(
                        db=db,
                        id=session_id,
                        user_id=effective_user_id,
                        updates={"title": truncated_title}
                    )
                    _db_logger.info(f"Updated session title to first message: {truncated_title}")

            _db_logger.debug(f"Synced user message to database for session {session_id}")
        except Exception as e:
            # Log with traceback for debugging
            _db_logger.warning(f"Failed to sync user message to database: {e}", exc_info=True)

        # Execute workflow if requested
        if execute_workflow:
            # Generate run_id BEFORE execution (dual endpoint pattern)
            run_id = new_id("run_")

            # Initialize step tracker if transparency is enabled
            if settings.transparency_enabled:
                from .runtime.transparency import step_tracker
                step_tracker.create_run(run_id, session.workflow_id)

            # Schedule background execution
            background_tasks.add_task(
                _execute_workflow_with_transparency,
                run_id=run_id,
                session=session,
                message=message,
                session_id=session_id,
                session_manager=session_manager,
                executor=executor,
                user_id=effective_user_id,
            )

            # Return immediately with run_id
            return {
                "session_id": session_id,
                "run_id": run_id,
                "status": "executing",
                "message": "Connect to WebSocket for real-time updates.",
                "ws_url": f"/ws/execution/{run_id}"
            }
        else:
            # Just acknowledge message
            return {
                "session_id": session_id,
                "status": "message_added",
                "message": "Message added to session"
            }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


async def _execute_workflow_with_transparency(
    run_id: str,
    session,
    message: str,
    session_id: str,
    session_manager,
    executor,
    user_id: str = None,
):
    """
    Execute workflow with transparency event emission.

    This runs in a background task after /chat/send returns.
    Emits run_started, run_completed, or run_failed events.
    """
    import asyncio
    import logging
    from echolib.config import settings

    logger = logging.getLogger(__name__)

    try:
        # Give the frontend time to connect to WebSocket before starting execution
        # This ensures real-time streaming instead of replaying all events at once
        await asyncio.sleep(0.5)  # 500ms delay for WebSocket connection

        # Emit run_started event
        if settings.transparency_enabled:
            from .runtime.transparency import step_tracker
            from .runtime.event_publisher import publish_run_started, publish_run_completed, publish_run_failed
            await publish_run_started(run_id, session.workflow_id)

        # Detect if workflow has HITL nodes — use HITL-aware executor if so
        # Phase 2: Load workflow definition from DB first, filesystem fallback
        _has_hitl_nodes = False
        try:
            # Resolve user_id; background tasks receive it as a plain string
            _bg_user_id = user_id or DEFAULT_USER_ID

            _wf_def = await _load_workflow_from_db(
                session.workflow_id, _bg_user_id
            )

            if _wf_def:
                _has_hitl_nodes = any(
                    (a.get("metadata", {}).get("node_type") == "HITL")
                    for a in _wf_def.get("agents", [])
                    if isinstance(a, dict)
                )
        except Exception:
            pass  # If detection fails, use standard executor

        # Execute workflow in a SEPARATE THREAD to keep event loop free
        # This is CRITICAL for real-time WebSocket streaming - without this,
        # the sync workflow blocks the event loop and WebSocket sends timeout
        _input_payload = {
            "message": message,
            "context": session.context,
            "run_id": run_id,  # Pass run_id for transparency
            "user_id": user_id,
            "_enable_runtime_resilience_guards": (
                str(os.getenv("WORKFLOW_ENABLE_EXISTING_RESILIENCE_GUARDS", "false")).strip().lower()
                in {"1", "true", "yes", "on"}
            ),
        }

        # DB-first execution: if we loaded the definition from DB, pass it
        # directly to the executor via execute_from_definition /
        # execute_hitl_from_definition to avoid redundant filesystem reads.
        if _wf_def:
            # No status transition happens here any more. Test mode used to
            # demand status="validated", which nothing in the product writes, so
            # this call re-ran full DAG validation on every message purely to
            # flip a field in memory -- and it validated the *reference* entries
            # a Phase 8 definition stores, which carry no prompt, model or tools
            # for validate_agent_schemas to inspect. The mode now accepts the
            # status the canvas actually saves; see RUNNABLE_DRAFT_STATUSES.
            _enforce_workflow_runtime_guard(_wf_def, session.workflow_id)
            _exec_method = (
                executor.execute_hitl_from_definition if _has_hitl_nodes
                else executor.execute_from_definition
            )
            result = await asyncio.to_thread(
                _exec_method,
                workflow_def=_wf_def,
                execution_mode=session.workflow_mode,
                input_payload=_input_payload,
            )
        else:
            # Fallback: no DB definition available, use original
            # filesystem-based execution path
            _exec_method = (
                executor.execute_workflow_hitl if _has_hitl_nodes
                else executor.execute_workflow
            )
            result = await asyncio.to_thread(
                _exec_method,
                workflow_id=session.workflow_id,
                execution_mode=session.workflow_mode,
                version=session.workflow_version,
                input_payload=_input_payload,
            )

        # Handle HITL interrupt — workflow paused, notify frontend
        if result.get("status") == "interrupted":
            interrupt_payload = result.get("interrupt", {})
            logger.info(
                f"Workflow paused at HITL node for run {run_id}"
            )
            if settings.transparency_enabled:
                from .runtime.transparency import step_tracker
                from .runtime.event_publisher import publish_run_completed
                # Emit a completion event with interrupted status so frontend
                # can switch to HITL review UI
                await publish_run_completed(run_id, {
                    "status": "interrupted",
                    "interrupt": interrupt_payload,
                })

            # Add a message to the session indicating HITL pause
            session_manager.add_assistant_message(
                session_id=session_id,
                message="Workflow paused for human review. Please check the HITL review panel.",
                run_id=run_id,
                metadata={
                    "execution_status": "interrupted",
                    "interrupt": interrupt_payload,
                }
            )
            return  # Do NOT continue — workflow is paused

        # Check if execution failed BEFORE processing output
        if result.get("status") == "failed":
            error_msg = result.get("error", "Unknown workflow execution error")
            logger.error(f"Workflow execution failed for run {run_id}: {error_msg}")

            if settings.transparency_enabled:
                from .runtime.transparency import step_tracker
                from .runtime.event_publisher import publish_run_failed
                step_tracker.fail_run(run_id)
                await publish_run_failed(run_id, error_msg)

            # Still add a message to the session with the error
            session_manager.add_assistant_message(
                session_id=session_id,
                message=f"⚠️ Workflow execution failed: {error_msg}",
                run_id=run_id,
                metadata={"execution_status": "failed", "error": error_msg}
            )
            return

        # Extract response from workflow output
        output = result.get("output", {})

        # Imported here, not inside the transparency branch above: this runs on
        # every turn, and the response must be extracted whether or not
        # transparency is enabled.
        from .runtime.event_publisher import extract_final_response

        # One extractor, shared with the two ``run_completed`` emitters.
        #
        # This cascade existed in three places -- here, in
        # ``event_publisher.publish_run_completed`` and implicitly in the
        # executor -- and they had already drifted: the publisher's copy tested
        # ``"result" in output`` rather than whether the value said anything, so
        # a present-but-empty ``result`` ended its search and produced no answer
        # at all. Sharing it is what stops the browser and the database
        # disagreeing about what a run returned.
        response_text, extraction_source = extract_final_response(output)

        if not response_text:
            response_text = (
                "I could not generate a response for this workflow run. "
                "Please try again or adjust the workflow inputs."
            )
            extraction_source = "friendly_fallback"
            logger.warning(
                "Empty workflow output for run %s, session %s; using friendly fallback",
                run_id,
                session_id,
            )
        else:
            logger.info(
                "Workflow response extracted for run %s from source '%s'",
                run_id,
                extraction_source,
            )

        # Filter out INTERNAL prefixed intermediate task outputs
        # and standalone JSON blobs.  Only the final user-facing content
        # (executive summary, report, etc.) should be stored and displayed.
        if isinstance(response_text, str) and "INTERNAL" in response_text:
            import re as _re
            # Phase 1: Remove INTERNAL-prefixed sections (multi-line safe).
            # Matches both INTERNAL and __INTERNAL__ variants.
            _cleaned = _re.sub(
                r'(?:^|\n)_*INTERNAL_*.*?(?=\n_*INTERNAL_*|\n-{3,}\s*\n|\Z)',
                '', response_text, flags=_re.DOTALL,
            )
            # Phase 2: Remove standalone top-level JSON objects.
            _cleaned = _re.sub(
                r'(?:^|\n\s*\n)\s*\{[\s\S]*?\}\s*(?=\n\s*\n|\Z)',
                '', _cleaned, flags=_re.DOTALL,
            )
            # Phase 3: Clean separators and blank lines.
            _cleaned = _re.sub(r'\n-{3,}\s*\n', '\n\n', _cleaned)
            _cleaned = _re.sub(r'\n{3,}', '\n\n', _cleaned)
            _cleaned = _cleaned.strip()
            if _cleaned:
                response_text = _cleaned
            else:
                # Edge case: everything removed — use last INTERNAL block.
                _last = None
                for _m in _re.finditer(
                    r'_*INTERNAL_*\s*(.*?)(?=\n_*INTERNAL_*|\Z)',
                    response_text, _re.DOTALL,
                ):
                    _last = _m
                if _last:
                    response_text = _last.group(1).strip()

        # Add assistant response to filesystem session
        session_manager.add_assistant_message(
            session_id=session_id,
            message=response_text,
            run_id=run_id,
            metadata={
                "execution_status": result.get("status"),
                "empty_output": extraction_source == "friendly_fallback",
                "extraction_source": extraction_source,
            }
        )

        # Sync assistant response to database session
        try:
            from datetime import datetime, timezone

            # Build assistant message dict for database
            db_assistant_message = {
                "id": f"msg_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')[:18]}",
                "role": "assistant",
                "content": response_text,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "agent_id": None,
                "run_id": run_id,
                "metadata": {
                    "execution_status": result.get("status"),
                    "empty_output": extraction_source == "friendly_fallback",
                    "extraction_source": extraction_source,
                }
            }

            async with get_db_session() as db:
                await _session_repo.add_message(
                    db=db,
                    session_id=session_id,
                    user_id=user_id,
                    message=db_assistant_message
                )

            logger.debug(f"Synced assistant message to database for session {session_id}")
        except Exception as e:
            # Log with traceback for debugging
            logger.warning(f"Failed to sync assistant message to database: {e}", exc_info=True)

        # Emit run_completed event
        if settings.transparency_enabled:
            step_tracker.complete_run(run_id, response_text)
            await publish_run_completed(run_id, output)

    except Exception as e:
        # Emit run_failed event
        if settings.transparency_enabled:
            from .runtime.transparency import step_tracker
            from .runtime.event_publisher import publish_run_failed
            step_tracker.fail_run(run_id)
            await publish_run_failed(run_id, str(e))

        # Log the error (background task can't raise to client)
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Background workflow execution failed for run {run_id}: {e}")
        import traceback
        logger.error(traceback.format_exc())


@router.get('/chat/history/{session_id}')
async def get_chat_history(session_id: str, user: UserContext = Depends(require_user)):
    """
    Get chat history for a session.

    Phase 2: Reads from database first, filesystem fallback.

    Returns:
    {
      "session_id": "...",
      "workflow_id": "...",
      "messages": [...],
      "context": {...}
    }
    """
    try:
        effective_user_id = resolve_user_id(user)

        # DB-first read
        try:
            async with get_db_session() as db:
                session_dict = await _session_repo.get_by_id_dict(
                    db, session_id, effective_user_id
                )
            if session_dict:
                return session_dict
        except Exception as db_err:
            _db_logger.warning(
                f"DB read failed for chat history {session_id}: {db_err}"
            )

        # Filesystem fallback (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            from .runtime.chat_session import ChatSessionManager

            session_manager = ChatSessionManager()
            session = session_manager.get_session(session_id)

            if not session:
                raise HTTPException(status_code=404, detail="Session not found")

            return session.to_dict()

        _db_logger.info(f"Filesystem fallback read skipped for chat history {session_id} (LEGACY_FILE_READ_ENABLED=false)")
        raise HTTPException(status_code=404, detail="Session not found")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== EXECUTION TRANSPARENCY ====================

@router.get('/execution/{run_id}/steps')
async def get_execution_steps(run_id: str, user: UserContext = Depends(require_user)):
    """
    Get current step state for a running or recently completed execution.

    This endpoint is for late-joining clients who connect to a run already
    in progress. It returns the current state of all steps.

    Response:
    {
      "run_id": "run_xxx",
      "workflow_id": "wf_xxx",
      "started_at": "ISO 8601",
      "completed_at": "ISO 8601" | null,
      "steps": [
        {
          "step_id": "step_xxx",
          "step_name": "Agent Name",
          "step_type": "agent",
          "status": "completed",
          "input_summary": {...},
          "output_summary": {...},
          "started_at": "ISO 8601",
          "completed_at": "ISO 8601",
          "error": null
        }
      ]
    }
    """
    from .runtime.transparency import step_tracker

    context = step_tracker.get_run(run_id)
    if not context:
        raise HTTPException(
            status_code=404,
            detail="Run not found or expired. Runs are kept in memory for 60 seconds after completion."
        )

    return {
        "run_id": run_id,
        "workflow_id": context.workflow_id,
        "started_at": context.started_at.isoformat(),
        "completed_at": context.completed_at.isoformat() if context.completed_at else None,
        "steps": [context.steps[sid].to_dict() for sid in context.step_order]
    }


@router.get('/debug/buffer/{run_id}')
async def debug_buffer_status(run_id: str, user: UserContext = Depends(require_user)):
    """
    Debug endpoint to check WebSocket event buffer status.

    Use this to verify that events are being buffered correctly
    and to check the state of the buffer for a specific run.

    NOTE: This endpoint is for debugging only. Remove in production.
    """
    from .runtime.ws_manager import ws_manager
    from .runtime.transparency import step_tracker

    # Get buffer info
    has_buffered = ws_manager.has_buffered_events(run_id)
    buffer_size = ws_manager.get_buffer_size(run_id)
    connection_count = ws_manager.get_connection_count(run_id)

    # Get run context info
    context = step_tracker.get_run(run_id)
    run_status = "not_found"
    step_count = 0
    if context:
        run_status = "completed" if context.completed_at else "running"
        step_count = len(context.step_order)

    return {
        "run_id": run_id,
        "buffer": {
            "has_events": has_buffered,
            "event_count": buffer_size
        },
        "websocket": {
            "connection_count": connection_count,
            "has_connections": connection_count > 0
        },
        "run_context": {
            "status": run_status,
            "step_count": step_count
        }
    }


@router.get('/chat/sessions')
async def list_chat_sessions(workflow_id: str = None, limit: int = 50, user: UserContext = Depends(require_user)):
    """
    List chat sessions.

    Phase 2: Reads from database first, filesystem fallback.

    Query params:
    - workflow_id: Filter by workflow
    - limit: Max sessions to return
    """
    try:
        effective_user_id = resolve_user_id(user)

        # DB-first read
        try:
            # Convert workflow_id to UUID for context_id filter if provided
            context_id = None
            if workflow_id:
                try:
                    context_id = normalize_to_uuid(workflow_id)
                except ValueError:
                    pass  # Leave context_id as None if conversion fails

            async with get_db_session() as db:
                db_sessions = await _session_repo.list_by_context(
                    db=db,
                    user_id=effective_user_id,
                    context_type="workflow",
                    context_id=context_id,
                    limit=limit
                )

            if db_sessions:
                return {
                    "sessions": [
                        {
                            "session_id": str(s.session_id),
                            "workflow_id": str(s.context_id) if s.context_id else None,
                            "mode": s.workflow_mode,
                            "message_count": len(s.messages) if s.messages else 0,
                            "created_at": s.created_at.isoformat() if s.created_at else None,
                            "last_activity": s.last_activity.isoformat() if s.last_activity else None
                        }
                        for s in db_sessions
                    ],
                    "count": len(db_sessions)
                }
        except Exception as db_err:
            _db_logger.warning(
                f"DB read failed for chat sessions list: {db_err}"
            )

        # Filesystem fallback (disabled when LEGACY_FILE_READ_ENABLED=false)
        if _settings.LEGACY_FILE_READ_ENABLED:
            from .runtime.chat_session import ChatSessionManager

            session_manager = ChatSessionManager()
            sessions = session_manager.list_sessions(
                workflow_id=workflow_id,
                limit=limit
            )

            return {
                "sessions": [
                    {
                        "session_id": s.session_id,
                        "workflow_id": s.workflow_id,
                        "mode": s.workflow_mode,
                        "message_count": len(s.messages),
                        "created_at": s.created_at.isoformat(),
                        "last_activity": s.last_activity.isoformat()
                    }
                    for s in sessions
                ],
                "count": len(sessions)
            }

        _db_logger.info("Filesystem fallback read skipped for chat sessions (LEGACY_FILE_READ_ENABLED=false)")
        return {"sessions": [], "count": 0}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/{workflow_id}/chat/history')
async def get_workflow_chat_history(
    workflow_id: str,
    limit: int = Query(default=20, le=100),
    user: UserContext = Depends(require_user),
):
    """
    Get chat history for a specific workflow.

    Returns sessions that are bound to this workflow (context_type='workflow').
    This enables workflow-scoped chat history in the UI.

    Args:
        workflow_id: Workflow ID (e.g., wf_xxx)
        limit: Maximum sessions to return (default 20, max 100)

    Returns:
        {
            "sessions": [...],  # List of session summaries
            "count": int,       # Number of sessions returned
            "workflow_id": str  # The workflow ID queried
        }
    """
    try:
        # Convert workflow_id to UUID format for database query
        try:
            context_uuid = normalize_to_uuid(workflow_id)
        except ValueError as e:
            _db_logger.warning(f"Invalid workflow_id format: {workflow_id} - {e}")
            # Return empty result for invalid IDs instead of error
            return {
                "sessions": [],
                "count": 0,
                "workflow_id": workflow_id
            }

        effective_user_id = resolve_user_id(user)
        async with get_db_session() as db:
            sessions = await _session_repo.list_by_context(
                db=db,
                user_id=effective_user_id,
                context_type="workflow",
                context_id=context_uuid,
                limit=limit
            )

        return {
            "sessions": [s.to_summary_dict() for s in sessions],
            "count": len(sessions),
            "workflow_id": workflow_id
        }

    except Exception as e:
        _db_logger.error(f"Failed to get workflow chat history: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== WORKFLOW DELETE ====================


@router.delete('/{workflow_id}')
async def delete_workflow(workflow_id: str, user: UserContext = Depends(require_admin_or_above)):
    """Delete a workflow from database and optionally filesystem.

    Ordering: DB soft-delete first (authoritative store), then FS soft-delete.
    If DB fails, FS is NOT modified and an error is returned.
    If DB succeeds but FS fails, the deletion is still considered successful
    because the database is the source of truth.
    """
    effective_user_id = resolve_user_id(user)
    agents_deleted = []

    # ------------------------------------------------------------------
    # Step 1: DB soft-delete FIRST (authoritative store)
    # ------------------------------------------------------------------
    try:
        db_workflow_id = normalize_to_uuid(workflow_id)
        async with get_db_session() as db:
            result = await _workflow_repo.delete_with_agents(db, db_workflow_id, effective_user_id)
            db_deleted = result["workflow_deleted"]
            agents_deleted = result["agents_deleted"]

        if db_deleted:
            _db_logger.info(f"Workflow {workflow_id} soft-deleted from database (agents cascade-deleted: {len(agents_deleted)})")
        else:
            _db_logger.info(
                f"Workflow {workflow_id} not found in database (may be FS-only workflow)"
            )
    except (ValueError, Exception) as db_err:
        _db_logger.error(
            f"Database delete failed for workflow {workflow_id}: {db_err}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail=(
                f"Failed to delete workflow {workflow_id}: database operation failed. "
                "Filesystem was not modified. Please retry."
            ),
        )

    # ------------------------------------------------------------------
    # Step 2: FS soft-delete (best-effort; DB is already authoritative)
    #         Skipped when WORKFLOW_DB_WRITE_ONLY is enabled.
    # ------------------------------------------------------------------
    if not _settings.WORKFLOW_DB_WRITE_ONLY:
        try:
            storage = container.resolve('workflow.storage')
            storage.delete_workflow(workflow_id, state="draft")
        except ValueError:
            _db_logger.info(
                f"Workflow {workflow_id} not found in filesystem storage (DB-only workflow)"
            )
        except Exception as fs_err:
            _db_logger.warning(
                f"Filesystem soft-delete failed for workflow {workflow_id} after "
                f"successful DB delete: {fs_err}. DB is authoritative; "
                "the FS file will be cleaned up later.",
                exc_info=True,
            )
    else:
        _db_logger.info("Filesystem delete skipped for workflow (WORKFLOW_DB_WRITE_ONLY=true)")

    return {
        "message": "Workflow deleted",
        "workflow_id": workflow_id,
        "agents_deleted": agents_deleted,
        "agents_deleted_count": len(agents_deleted),
    }


@router.delete('/chat/{session_id}')
async def delete_chat_session(session_id: str, user: UserContext = Depends(require_user)):
    """
    Delete a chat session.

    Phase 2: Soft-deletes from DB AND removes from filesystem.
    """
    try:
        effective_user_id = resolve_user_id(user)

        # DB soft-delete
        db_deleted = False
        try:
            async with get_db_session() as db:
                db_deleted = await _session_repo.delete(
                    db, session_id, effective_user_id
                )
        except Exception as db_err:
            _db_logger.warning(
                f"DB delete failed for session {session_id}: {db_err}"
            )

        # Filesystem cleanup (always attempt, even if DB delete succeeded)
        fs_deleted = False
        try:
            from .runtime.chat_session import ChatSessionManager
            session_manager = ChatSessionManager()
            session_manager.delete_session(session_id)
            fs_deleted = True
        except Exception as fs_err:
            _db_logger.warning(
                f"Filesystem delete failed for session {session_id}: {fs_err}"
            )

        # Direct file cleanup as safety net if ChatSessionManager failed
        if not fs_deleted:
            try:
                from pathlib import Path
                session_path = (
                    Path(__file__).parent / "storage" / "sessions" / f"{session_id}.json"
                )
                if session_path.exists():
                    session_path.unlink()
                    _db_logger.info(
                        f"Direct file cleanup succeeded for session {session_id}"
                    )
            except Exception as direct_err:
                _db_logger.warning(
                    f"Direct file cleanup also failed for session {session_id}: {direct_err}"
                )

        return {
            "success": True,
            "session_id": session_id,
            "message": "Session deleted",
            "db_deleted": db_deleted,
            "fs_deleted": fs_deleted,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== WORKFLOW SAVE (AFTER TESTING) ====================

@router.post('/save-final')
async def save_tested_workflow(request: dict, user: UserContext = Depends(require_admin_or_above)):
    """
    Save workflow as final after testing.

    Promotes a validated draft directly to final status.

    Request:
    {
      "workflow_id": "wf_xxx",
      "version": "1.0",
      "notes": "Tested and approved"
    }
    """
    try:
        storage = container.resolve('workflow.storage')

        workflow_id = request.get("workflow_id")
        version = request.get("version", "1.0")
        notes = request.get("notes", "")

        if not workflow_id:
            raise HTTPException(status_code=400, detail="workflow_id required")

        # Load validated draft from DB
        effective_user_id = resolve_user_id(user)
        workflow = await _load_workflow_from_db(workflow_id, effective_user_id)

        if not workflow:
            raise HTTPException(
                status_code=404,
                detail="Validated draft workflow not found"
            )

        if workflow.get("status") != "validated":
            raise HTTPException(
                status_code=400,
                detail=f"Workflow must be in validated state to promote to final "
                       f"(current status: {workflow.get('status')})"
            )

        # Update version and notes
        workflow["version"] = version
        workflow.setdefault("metadata", {})["save_notes"] = notes
        # Clear testing marker now that we are promoting to final
        workflow.get("metadata", {}).pop("testing", None)

        # Save as final on filesystem (skipped when WORKFLOW_DB_WRITE_ONLY)
        result = {}
        if not _settings.WORKFLOW_DB_WRITE_ONLY:
            result = storage.save_final_workflow(workflow)
        else:
            _db_logger.info("Filesystem write skipped for workflow (WORKFLOW_DB_WRITE_ONLY=true)")
            result = {"path": "db_only"}

        # Persist final workflow to database + create version row
        db_saved = False
        try:
            import copy as _copy

            db_workflow_data = _copy.deepcopy(workflow)
            db_uuid = normalize_to_uuid(workflow_id)

            async with get_db_session() as db:
                await _workflow_repo.save_with_agents(
                    db=db,
                    user_id=effective_user_id,
                    workflow_data=db_workflow_data,
                    db_workflow_id=db_uuid,
                )
                # Create immutable version snapshot
                await _workflow_repo.create_version(
                    db=db,
                    workflow_id=db_uuid,
                    version=version,
                    created_by=effective_user_id,
                    notes=notes or None,
                )
            db_saved = True
            _db_logger.info(
                f"Workflow {workflow_id} saved to DB as final (version={version})"
            )
        except Exception as db_err:
            # Filesystem save already succeeded -- graceful degradation
            _db_logger.warning(
                f"Database save failed for final workflow {workflow_id}: {db_err}"
            )

        return {
            "success": True,
            "workflow_id": workflow_id,
            "version": version,
            "path": result["path"],
            "message": "Workflow saved as final",
            "db_saved": db_saved,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== HITL (HUMAN-IN-THE-LOOP) ====================

@router.get('/hitl/status/{run_id}')
async def get_hitl_status(run_id: str, user: UserContext = Depends(require_user)):
    """
    Get HITL status for a run.

    Returns:
    {
      "run_id": "run_xxx",
      "state": "waiting_for_human",
      "blocked_at": "agent_id",
      "allowed_actions": ["approve", "reject", "modify"],
      "has_pending_review": true
    }
    """
    try:
        hitl = hitl_manager()
        await _hydrate_hitl(hitl, run_id)
        status = hitl.get_status(run_id)

        return status

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/hitl/context/{run_id}')
async def get_hitl_context(run_id: str, user: UserContext = Depends(require_user)):
    """
    Get full HITL context for decision-making.

    Returns:
    {
      "workflow_id": "wf_xxx",
      "run_id": "run_xxx",
      "blocked_at": "agent_id",
      "agent_output": {...},
      "tools_used": [...],
      "execution_metrics": {...},
      "state_snapshot": {...},
      "previous_decisions": [...]
    }
    """
    try:
        hitl = hitl_manager()
        await _hydrate_hitl(hitl, run_id)
        context = hitl.get_context(run_id)

        if not context:
            raise HTTPException(status_code=404, detail="HITL context not found")

        return context.to_dict()

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/hitl/approve')
async def approve_hitl(request: dict, user: UserContext = Depends(require_user)):
    """
    Approve workflow execution at HITL checkpoint.

    Request:
    {
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "rationale": "Looks good, proceed"
    }

    Response:
    {
      "action": "approve",
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "status": "approved",
      "can_resume": true
    }
    """
    try:
        hitl = hitl_manager()

        run_id = request.get("run_id")
        actor = request.get("actor", "unknown")
        rationale = request.get("rationale")

        if not run_id:
            raise HTTPException(status_code=400, detail="run_id required")

        await _hydrate_hitl(hitl, run_id)
        result = hitl.approve(run_id=run_id, actor=actor, rationale=rationale)

        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/hitl/reject')
async def reject_hitl(request: dict, user: UserContext = Depends(require_user)):
    """
    Reject workflow execution at HITL checkpoint.

    Request:
    {
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "rationale": "Output doesn't meet requirements"
    }

    Response:
    {
      "action": "reject",
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "status": "rejected",
      "can_resume": false,
      "terminated": true
    }
    """
    try:
        hitl = hitl_manager()

        run_id = request.get("run_id")
        actor = request.get("actor", "unknown")
        rationale = request.get("rationale")

        if not run_id:
            raise HTTPException(status_code=400, detail="run_id required")

        await _hydrate_hitl(hitl, run_id)
        result = hitl.reject(run_id=run_id, actor=actor, rationale=rationale)

        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/hitl/modify')
async def modify_hitl(request: dict, user: UserContext = Depends(require_user)):
    """
    Modify workflow/agent configuration at HITL checkpoint (validated draft workflows only).

    Request:
    {
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "changes": {
        "agent_id": "agt_001",
        "llm": {"temperature": 0.5},
        "prompt": "Updated prompt"
      },
      "rationale": "Need higher temperature for creativity"
    }

    Response:
    {
      "action": "modify",
      "run_id": "run_xxx",
      "actor": "user@example.com",
      "status": "modified",
      "changes": {...},
      "validation_required": true,
      "can_resume": false
    }
    """
    try:
        hitl = hitl_manager()

        run_id = request.get("run_id")
        actor = request.get("actor", "unknown")
        changes = request.get("changes", {})
        rationale = request.get("rationale")

        if not run_id:
            raise HTTPException(status_code=400, detail="run_id required")

        if not changes:
            raise HTTPException(status_code=400, detail="changes required")

        await _hydrate_hitl(hitl, run_id)
        result = hitl.modify(
            run_id=run_id,
            actor=actor,
            changes=changes,
            rationale=rationale
        )

        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/hitl/pending')
async def list_pending_hitl_reviews(user: UserContext = Depends(require_user)):
    """
    List all workflows waiting for HITL review.

    Response:
    [
      {
        "run_id": "run_xxx",
        "workflow_id": "wf_xxx",
        "blocked_at": "agent_id",
        "created_at": "2026-01-17T10:00:00Z"
      }
    ]
    """
    try:
        hitl = hitl_manager()
        pending = hitl.list_pending_reviews()

        return {"pending_reviews": pending, "count": len(pending)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/hitl/decisions/{run_id}')
async def get_hitl_decisions(run_id: str, user: UserContext = Depends(require_user)):
    """
    Get HITL decision audit trail for a run.

    Response:
    [
      {
        "decision_id": "hitl_dec_xxx",
        "run_id": "run_xxx",
        "action": "approve",
        "actor": "user@example.com",
        "timestamp": "2026-01-17T10:05:00Z",
        "rationale": "Looks good"
      }
    ]
    """
    try:
        hitl = hitl_manager()
        await _hydrate_hitl(hitl, run_id)
        decisions = hitl.get_decisions(run_id)

        return {
            "run_id": run_id,
            "decisions": [d.to_dict() for d in decisions],
            "count": len(decisions)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== HITL RESUME (Direct, no Celery) ====================

def _spawn_resume(
    *,
    run_id: str,
    workflow_id: str,
    action: str,
    payload: dict,
    user_id: str,
) -> None:
    """
    Start the resume as a tracked background task.

    ``asyncio.ensure_future`` was used here and the returned task discarded.
    The event loop keeps only a weak reference, so a task nobody holds can be
    collected part-way through -- and nothing ever retrieved its result, so a
    resume that raised did so silently. A resume that vanishes leaves the graph
    parked at ``interrupt()`` while the decision has already been committed,
    and every later decision on that run is then refused.

    ``track_task`` holds the reference and logs any failure against this run.
    """
    import asyncio

    from .runtime.hitl import track_task

    track_task(
        asyncio.ensure_future(
            _resume_workflow_direct(
                run_id=run_id,
                workflow_id=workflow_id,
                action=action,
                payload=payload,
                user_id=user_id,
            )
        ),
        f"HITL resume for run '{run_id}' (action={action})",
    )


async def _resume_workflow_direct(
    run_id: str,
    workflow_id: str,
    action: str,
    payload: dict = None,
    user_id: str = "system",
):
    """
    Resume a HITL-paused workflow directly (without Celery).

    Runs executor.resume_workflow in a background thread so the event loop
    stays free for WebSocket streaming of transparency events.

    Pre-loads the workflow definition in the current async context (where
    DB sessions are valid) and passes it to ``resume_workflow`` via the
    ``workflow_def`` parameter.  This prevents cross-event-loop errors
    that occur when ``_load_workflow`` uses sync-to-async bridges inside
    the ``asyncio.to_thread`` background thread.

    After resume completes, publishes the result (completed or another
    interrupt) via the event publisher.
    """
    import asyncio
    import logging
    from echolib.config import settings

    logger = logging.getLogger(__name__)

    if not workflow_id:
        logger.error(f"[HITL-RESUME] Cannot resume run '{run_id}': no workflow_id")
        return

    logger.info(
        f"[HITL-RESUME] Directly resuming workflow '{workflow_id}' "
        f"(run_id={run_id}, action={action})"
    )

    try:
        executor = container.resolve('workflow.executor')

        # Pre-load workflow definition in the async context where the
        # DB session is bound to the current event loop.  This avoids
        # "Task got Future attached to a different loop" errors when
        # StorageGateway.load_workflow_sync() tries to bridge
        # async DB calls from the background thread.
        workflow_def = None
        try:
            gateway = _get_storage_gateway()
            workflow_def = await gateway.load_workflow(
                workflow_id, user_id or DEFAULT_USER_ID, state="draft",
            )
            if workflow_def:
                logger.debug(
                    f"[HITL-RESUME] Pre-loaded workflow definition for "
                    f"'{workflow_id}' in async context"
                )
        except Exception as preload_err:
            logger.warning(
                f"[HITL-RESUME] Could not pre-load workflow '{workflow_id}': "
                f"{preload_err}. Falling back to executor._load_workflow()."
            )

        # Run in background thread to keep event loop free
        result = await asyncio.to_thread(
            executor.resume_workflow,
            workflow_id=workflow_id,
            run_id=run_id,
            action=action,
            payload=payload or {},
            execution_mode="draft",
            user_id=user_id,
            workflow_def=workflow_def,
        )

        logger.info(
            f"[HITL-RESUME] Resume result for run '{run_id}': "
            f"status={result.get('status')}"
        )

        # Publish result via transparency events
        if settings.transparency_enabled:
            from .runtime.event_publisher import publish_run_completed, publish_run_failed

            if result.get("status") == "failed":
                await publish_run_failed(run_id, result.get("error", "Unknown error"))
            elif result.get("status") == "interrupted":
                # Chained HITL: resume hit another interrupt node.
                # Pass status + interrupt payload so publish_run_completed
                # emits the correct HITL event to the frontend.
                await publish_run_completed(run_id, {
                    "status": "interrupted",
                    "interrupt": result.get("interrupt", {}),
                })
            else:
                await publish_run_completed(run_id, result.get("output", result))

    except Exception as e:
        logger.error(
            f"[HITL-RESUME] Direct resume failed for run '{run_id}': {e}",
            exc_info=True,
        )


# ==================== HITL UNIFIED DECIDE ROUTE ====================

@router.post('/hitl/decide')
async def hitl_decide(request: dict, user: UserContext = Depends(require_user)):
    """
    Unified HITL decision endpoint.

    Dispatches to approve/reject/edit based on the action field.
    Validates that the action is allowed per the workflow's hitl_config
    (allowed_decisions enforcement).

    Request:
    {
      "run_id": "run_xxx",
      "action": "approve" | "reject" | "edit",
      "actor": "user@example.com",
      "rationale": "Optional comment",
      "payload": {}  // For edit: a changes dict.
    }

    Response varies by action (same as individual endpoints).

    Raises:
        403: If action is not in allowed_decisions for this HITL node.
        400: If run_id or action is missing.
    """
    try:
        from .runtime.hitl import HITLStateError, derive_allowed_decisions

        hitl = hitl_manager()
        effective_user_id = resolve_user_id(user)

        run_id = request.get("run_id")
        action = request.get("action")
        actor = request.get("actor", "unknown")
        rationale = request.get("rationale")
        payload = request.get("payload", {})

        if not run_id:
            raise HTTPException(status_code=400, detail="run_id required")
        if not action:
            raise HTTPException(status_code=400, detail="action required")

        # Normalize action
        action = action.strip().lower()

        # Load the checkpoint into this worker before anything reads it.
        await _hydrate_hitl(hitl, run_id)

        # The reviewer's identity and comment travel to the workflow node in the
        # resume payload, because that is where the node reads them from
        # (`compiler._create_hitl_node`: `decision_payload.get("actor")`). Sent
        # only at the top level, as the reviewer UI sends them, they never
        # arrived -- so every decision the node recorded was attributed to
        # "human_reviewer" with no rationale, in the one record that is meant to
        # be an audit trail.
        resume_payload = dict(payload) if isinstance(payload, dict) else {}
        resume_payload.setdefault("actor", actor)
        if rationale:
            resume_payload.setdefault("rationale", rationale)

        # Validate action is allowed
        # Try to get hitl_config from the HITL context
        context = hitl.get_context(run_id)
        if context and context.state_snapshot:
            hitl_config = context.state_snapshot.get("hitl_config", {})
            allowed = derive_allowed_decisions(hitl_config)
            if action not in allowed:
                raise HTTPException(
                    status_code=403,
                    detail=f"Action '{action}' is not allowed. Permitted: {allowed}"
                )

        # Record the decision. This is the decision boundary: it validates that
        # the run is actually waiting, and the graph node downstream only
        # carries the decision out (`compiler._close_pause`).
        if action == "approve":
            result = hitl.approve(run_id=run_id, actor=actor, rationale=rationale)
        elif action == "reject":
            # A rejection resumes the graph exactly as an approval does.
            #
            # It reads as a contradiction and is not: the run is parked inside
            # `interrupt()`, and the only code that ends it cleanly is the HITL
            # node's own reject branch, which records the decision, writes the
            # "rejected by <reviewer>" result and routes to END. Never resuming
            # meant that branch never ran -- the thread stayed parked forever,
            # the run was never closed, and the UI never received a terminal
            # event.
            result = hitl.reject(run_id=run_id, actor=actor, rationale=rationale)
        elif action in ("edit", "modify"):
            changes = payload.get("changes", payload)
            if not changes:
                raise HTTPException(
                    status_code=400,
                    detail="payload.changes required for edit action",
                )
            result = hitl.modify(
                run_id=run_id, actor=actor, changes=changes, rationale=rationale
            )
            action = "edit"
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown action: '{action}'. Valid: approve, reject, edit",
            )

        # Commit the decision before the graph is allowed to see it.
        #
        # The write was fire-and-forget and the resume was dispatched on the
        # next line, so the graph could re-enter the HITL node while
        # ``hitl_states`` still read ``waiting_for_human`` -- and the decision
        # then landed on top of a run that had already moved past it. Three
        # writes contended for one row per click, and whichever settled last
        # decided what every *subsequent* click saw. That is why a second
        # decision on the same run returned 400 whatever button was pressed.
        flush = getattr(hitl, "flush_state", None)
        if flush is not None:
            await flush(run_id)

        if hasattr(hitl, "trigger_resume"):
            resume_info = hitl.trigger_resume(
                run_id=run_id, action=action, payload=resume_payload
            )
            result["resume_info"] = resume_info

            # Celery is not installed on this deployment, so this is the live
            # path rather than the fallback.
            if resume_info.get("status") == "resume_pending":
                _spawn_resume(
                    run_id=run_id,
                    workflow_id=resume_info.get("workflow_id"),
                    action=action,
                    payload=resume_payload,
                    user_id=effective_user_id,
                )

        return result

    except HTTPException:
        raise
    except HITLStateError as e:
        # Three different situations used to arrive at the reviewer as one
        # indistinguishable 400, which is the reason this defect outlived
        # several attempts to fix it. They are now told apart.
        _db_logger.info(
            "[HITL] Decision '%s' refused for run '%s': %s",
            request.get("action"), request.get("run_id"), e,
        )
        raise HTTPException(
            status_code=404 if not e.known else 409,
            detail=str(e),
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
