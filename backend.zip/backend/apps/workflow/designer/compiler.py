"""
Workflow compiler.
Compiles workflow JSON definitions into executable LangGraph.

ARCHITECTURAL RULES (STRICTLY ENFORCED):
=========================================
1. LangGraph OWNS: Workflow topology, execution order, branching, merging, state
2. Every workflow is MATERIALIZED AS: LangGraph StateGraph
3. Agents are INVOKED: Inside LangGraph nodes, through AgentFactory.build()
4. An agent NEVER: Controls graph traversal or state transitions
5. Workflow type: Inferred by designer, compiled here into LangGraph structure

Rules 3 and 4 used to name CrewAI, which ran agents inside nodes while
LangGraph owned the graph. Phase 9 removed CrewAI platform-wide; the boundary is
unchanged, but the thing on the inside of it is now a LangChain agent compiled by
``apps.agent.factory``.

SUPPORTED NODE TYPES:
=====================
- Agent: LLM-powered agent execution via AgentFactory
- Conditional/Router: Branch routing based on conditions
- HITL: Human-in-the-loop approval checkpoints
- API: HTTP API calls (Managed connector or Ad-hoc) — SYNC, wrapped in asyncio.to_thread()
- MCP: Model Context Protocol calls (Managed or Ad-hoc) — ASYNC, awaited directly
- Code: Sandboxed Python code execution
- Self-Review: LLM-based output validation against review criteria
"""
from typing import Dict, Any, TypedDict, List, Annotated, Optional
import asyncio
import operator
import os
import json
import logging

# ``importlib``, ``secrets``, ``resolve_llm_credential_sync`` and
# ``OLLAMA_DUMMY_API_KEY`` were imported here for the hand-rolled provider
# switch behind the Self-Review node. That switch is gone -- the node now builds
# its model through ``llm_resolver`` like every other component -- and these
# were its only consumers in this module.
from echolib.type_resolver import TypeResolver  # ✅ For type validation in convergence nodes
from ..runtime.hitl import derive_allowed_decisions
from ..runtime.node_outputs import (
    TYPE_API,
    TYPE_CODE,
    TYPE_HITL,
    TYPE_MCP,
    TYPE_REVIEW,
    merge_node_outputs,
    node_output_entry,
    render_outputs,
)

logger = logging.getLogger(__name__)


def _merge_review_attempts(
    existing: Optional[Dict[str, int]],
    new: Optional[Dict[str, int]],
) -> Dict[str, int]:
    """
    Reducer for the Self-Review retry counter: highest count per node wins.

    WHAT: Merges two ``{node_id: attempts}`` maps, keeping the larger value.
    WHY:  A retry budget is a safety ceiling, so its reducer must fail towards
          stopping. Plain last-writer-wins would let one parallel branch's
          write erase another's, and the erased node would then be handed a
          fresh budget and could loop past its ceiling. Taking the maximum
          means a lost update can only end a loop early.
    OUTPUT: A new dict. Neither input is mutated -- both may be held by
            LangGraph's checkpointer.
    """
    merged = dict(existing or {})
    for node_id, count in (new or {}).items():
        if not isinstance(count, int):
            continue
        if count > merged.get(node_id, 0):
            merged[node_id] = count
    return merged


def _render_review_feedback(
    review_data: Dict[str, Any],
    *,
    attempt: int,
    of: int,
) -> str:
    """
    Turn a failed review into instructions the reviewed node can act on.

    WHAT: Renders the reviewer's verdict, its specific issues and the attempt
          count into the ``_edit_feedback`` channel.
    WHY:  Sending a node back with "you failed" and nothing else invites the
          same output again. The reviewer already produced ``issues`` -- a list
          it was asked for and which, until the retry loop existed, nothing
          read. This is what makes the loop converge rather than repeat.
    OUTPUT: Plain text. Deliberately shaped like the human reviewer's feedback
            that ``build_agent_task`` already appends, because it arrives on the
            same channel and an agent should read the two the same way.

    The attempt count is stated so a model on its final try knows it is the
    final try, rather than deferring the fix again.
    """
    lines = [
        "[AUTOMATED QUALITY REVIEW -- your previous output did not pass "
        "(attempt {} of {}). Correct the following and produce the full "
        "output again, not a description of the changes.]".format(attempt, of)
    ]

    feedback = review_data.get("feedback")
    if isinstance(feedback, str) and feedback.strip():
        lines.append("Reviewer's assessment: {}".format(feedback.strip()))

    issues = review_data.get("issues")
    if isinstance(issues, (list, tuple)):
        rendered = [str(issue).strip() for issue in issues if str(issue).strip()]
        if rendered:
            lines.append("Specific issues to fix:")
            lines.extend("- {}".format(issue) for issue in rendered)

    return "\n".join(lines)


class WorkflowCompiler:
    """
    Compiles workflow JSON to executable LangGraph.

    This compiler creates LangGraph StateGraph structures where:
    - Graph topology is defined by this compiler (NOT by the agents it runs)
    - Nodes execute agents through AgentFactory (an agent never decides flow)
    - State management is controlled by LangGraph
    """

    def __init__(
        self,
        execution_repo=None,
        ws_manager=None,
        workflow_id: str = None
    ):
        """
        Initialize compiler with all dependencies.
        
        Args:
            execution_repo: ExecutionRunRepository for persistence
            ws_manager: WebSocket manager for event publishing
            workflow_id: Current workflow ID for logging context
        """
        self._compiled_cache = {}
        self.execution_repo = execution_repo
        self.ws_manager = ws_manager
        self.workflow_id = workflow_id
        self.hitl_manager = None  # Lazy initialization
        logger.info(
            "WorkflowCompiler initialized",
            extra={
                "execution_repo_available": execution_repo is not None,
                "ws_manager_available": ws_manager is not None,
                "workflow_id": workflow_id
            }
        )

    def _detect_start_end_nodes(
        self,
        agents_raw: list,
        agent_registry: Dict[str, Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Detect Start and End nodes in the agents list.

        Scans agent configs for type="Start" or type="End" and separates
        them from the working agents list. Used by parallel, hierarchical,
        and hybrid compile methods to wrap their internal logic.

        Args:
            agents_raw: Raw agents list from workflow (strings or dicts)
            agent_registry: Agent definitions

        Returns:
            dict with keys: start_id, start_config, end_id, end_config,
            working_agents (filtered list without Start/End)
        """
        result = {
            "start_id": None, "start_config": None,
            "end_id": None, "end_config": None,
            "working_agents": []
        }

        for agent_entry in agents_raw:
            if isinstance(agent_entry, str):
                aid = agent_entry
            elif isinstance(agent_entry, dict):
                aid = agent_entry.get("agent_id")
            else:
                continue

            if not aid:
                continue

            config = agent_registry.get(aid, {})
            node_type = (
                config.get("type", "")
                or config.get("metadata", {}).get("node_type", "")
            ).strip().lower()

            if node_type == "start":
                result["start_id"] = aid
                result["start_config"] = config
                logger.debug(f"Detected Start node: {aid}")
            elif node_type == "end":
                result["end_id"] = aid
                result["end_config"] = config
                logger.debug(f"Detected End node: {aid}")
            else:
                result["working_agents"].append(aid)

        return result

    def compile_to_langgraph(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]]
    ) -> Any:
        """
        Compile workflow JSON to executable LangGraph using LangChain agents.
        
        Routes to execution model-specific compilation methods based on
        workflow.execution_model:
        - "sequential": Linear workflow (A→B→C)
        - "parallel": All agents execute concurrently
        - "hierarchical": Coordinator delegates to sub-agents
        - "hybrid": Mix of sequential and parallel sections

        Args:
            workflow: Workflow definition
            agent_registry: Agent definitions

        Returns:
            Compiled LangGraph instance (runnable)
        """
        try:
            from langgraph.graph import StateGraph, END
            from langgraph.checkpoint.memory import MemorySaver
        except ImportError:
            raise ImportError(
                "LangGraph not installed. Run: pip install langgraph langchain-core"
            )

        execution_model = workflow.get("execution_model", "sequential")
        workflow_id = workflow.get("workflow_id", "unknown")
        
        logger.info(
            f"[COMPILER] Compiling workflow '{workflow_id}' "
            f"(execution_model='{execution_model}') to LangGraph DAG"
        )

        # Create state schema
        WorkflowState = self._create_state_class(workflow, agent_registry)

        # A stored "parallel" that is contradicted by the graph's own edges is
        # not honoured.
        #
        # ``_compile_parallel_dag`` runs every node concurrently straight from
        # START and ignores ``connections`` entirely, so it is only correct for
        # a set of genuinely independent agents. ``_infer_execution_model``
        # used to classify any fan-out that way -- convergence was detected
        # solely by a literal "Merge" node type, never by counting incoming
        # edges -- so a canvas that fanned out to reviewers and rejoined on a
        # consolidating Agent was persisted as "parallel". Every such workflow
        # ran its consolidator at the same instant as the reviewers it was
        # meant to read, and returned their independent answers concatenated.
        #
        # The inference is fixed, but ``execution_model`` is read from the
        # stored definition, so workflows saved before that fix would keep the
        # wrong value until re-saved. Deciding from the edges here repairs them
        # in place, and costs nothing for a workflow that is genuinely parallel.
        if execution_model == "parallel" and self._has_agent_connections(workflow):
            logger.warning(
                "[COMPILER] Workflow '%s' is stored as execution_model='parallel' "
                "but its nodes are wired together; compiling as a DAG so those "
                "connections are honoured. Re-save the workflow to update the "
                "stored value.",
                workflow_id,
            )
            execution_model = "hybrid"

        # Route to execution model-specific compiler
        # Phase B: Restore execution model routing
        if execution_model == "hierarchical":
            return self._compile_hierarchical_dag(workflow, agent_registry, WorkflowState)
        elif execution_model == "parallel":
            return self._compile_parallel_dag(workflow, agent_registry, WorkflowState)
        elif execution_model == "hybrid":
            return self._compile_hybrid_dag(workflow, agent_registry, WorkflowState)
        else:  # "sequential" (default)
            return self._compile_sequential_dag(workflow, agent_registry, WorkflowState)

    @staticmethod
    def _has_agent_connections(workflow: Dict[str, Any]) -> bool:
        """
        True when the definition wires at least two of its own nodes together.

        Resolution mirrors ``_compile_sequential_dag``: a connection endpoint is
        either an agent id or the canvas's 1-based position, and only an edge
        whose *both* ends resolve to distinct known nodes counts. A definition
        whose connections reference nothing real is not treated as wired, which
        keeps this from overriding a genuinely parallel workflow that happens to
        carry stale edges.
        """
        agent_ids: List[str] = []
        for entry in workflow.get("agents", []) or []:
            if isinstance(entry, str):
                agent_ids.append(entry)
            elif isinstance(entry, dict) and entry.get("agent_id") is not None:
                agent_ids.append(str(entry["agent_id"]))
            elif entry is not None:
                agent_ids.append(str(entry))

        if len(agent_ids) < 2:
            return False

        agent_id_set = set(agent_ids)
        canvas = {str(i + 1): aid for i, aid in enumerate(agent_ids)}

        def _resolve(raw: Any) -> Optional[str]:
            if raw is None:
                return None
            value = str(raw)
            return value if value in agent_id_set else canvas.get(value)

        for conn in workflow.get("connections", []) or []:
            if not isinstance(conn, dict):
                continue
            source = _resolve(conn.get("from"))
            target = _resolve(conn.get("to"))
            if source and target and source != target:
                return True

        return False

    def _compile_sequential_dag(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]],
        WorkflowState: type
    ) -> Any:
        """
        Compile a workflow into a sequential DAG (linear execution).
        
        Agents execute in the order defined by workflow connections.
        Each agent waits for its predecessor to complete before starting.
        Uses LangGraph's native state propagation for agent chaining.
        """
        from langgraph.graph import StateGraph, START, END

        logger.info("Compiling sequential DAG (linear execution)...")
        graph = StateGraph(WorkflowState)

        # Extract agent IDs (handle embedded dicts or string IDs)
        agent_ids: list[str] = []
        for entry in workflow.get("agents", []):
            if isinstance(entry, str):
                agent_ids.append(entry)
            elif isinstance(entry, dict) and entry.get("agent_id") is not None:
                agent_ids.append(str(entry["agent_id"]))
            elif entry is not None:
                agent_ids.append(str(entry))
        agent_id_set = set(agent_ids)

        # Canvas 1-based ID resolver (defence-in-depth, mirrors other compile paths)
        canvas = {str(i + 1): aid for i, aid in enumerate(agent_ids)}

        def _resolve(raw):
            if raw is None:
                return None
            s = str(raw)
            return s if s in agent_id_set else canvas.get(s, s)

        # Build adjacency from connections
        incoming: Dict[str, int] = {aid: 0 for aid in agent_ids}
        outgoing: Dict[str, int] = {aid: 0 for aid in agent_ids}
        edges: list[tuple[str, str]] = []
        for conn in workflow.get("connections", []) or []:
            frm = _resolve(conn.get("from"))
            to = _resolve(conn.get("to"))
            if frm in agent_id_set and to in agent_id_set and frm != to:
                edges.append((frm, to))
                outgoing[frm] += 1
                incoming[to] += 1

        # Predecessor / successor maps for type-aware node creation (HITL etc.)
        preceding: Dict[str, str] = {}
        successors: Dict[str, list] = {}
        for frm, to in edges:
            preceding[to] = frm
            successors.setdefault(frm, []).append(to)

        # HITL and Conditional nodes own their outgoing edges (see
        # _wire_hitl_conditional_edge and _wire_conditional_edge), so they are
        # identified before any edge is wired.
        hitl_node_ids = [
            aid for aid in agent_ids
            if self._is_hitl_node(agent_registry.get(aid, {}))
        ]
        hitl_set = set(hitl_node_ids)
        conditional_node_ids = [
            aid for aid in agent_ids
            if self._is_conditional_node(agent_registry.get(aid, {}))
        ]
        # A Self-Review node owns its outgoing edge too, for the same reason:
        # a failed review routes backwards, and a node carrying both a static
        # edge and a dynamic one fires both destinations.
        review_node_ids = [
            aid for aid in agent_ids
            if self._is_review_node(agent_registry.get(aid, {}))
        ]
        dynamic_set = hitl_set | set(conditional_node_ids) | set(review_node_ids)

        # Create one node per agent (type dispatch: agent -> create_react_agent).
        # ``seq`` is the node's position in this walk, which for a sequential DAG
        # is topological order. It travels on every accumulator entry so a
        # fan-in presents its branches in graph order instead of alphabetically.
        for index, aid in enumerate(agent_ids):
            cfg = agent_registry.get(aid, {})
            node_func = self._create_node_for_type(
                aid, cfg,
                preceding_node_id=preceding.get(aid),
                successor_node_ids=successors.get(aid, []),
                seq=index,
            )
            graph.add_node(aid, node_func)

        # Wire edges; de-duplicate (LangGraph add_edge is not idempotent).
        # An edge *out of* a HITL or Conditional node is deliberately not added:
        # those nodes get a conditional edge instead, and a node carrying both a
        # static edge and a dynamic one fires both destinations.
        #
        # For a Conditional node this was the whole defect: it evaluated its
        # branches, wrote ``_conditional_route``, and then every one of its
        # static outgoing edges fired anyway. Every branch ran, on every input,
        # and the decision changed nothing.
        seen = set()
        for frm, to in edges:
            if frm in dynamic_set:
                continue
            if (frm, to) not in seen:
                graph.add_edge(frm, to)
                seen.add((frm, to))

        # Roots (no upstream) start in parallel from START; sinks go to END
        roots = [aid for aid in agent_ids if incoming.get(aid, 0) == 0]
        sinks = [aid for aid in agent_ids if outgoing.get(aid, 0) == 0]
        if not roots and agent_ids:        # fully-cyclic safety net
            roots = [agent_ids[0]]
        if not sinks and agent_ids:
            sinks = [agent_ids[-1]]
        for r in roots:
            graph.add_edge(START, r)
        for s in sinks:
            if s in dynamic_set:
                continue  # its conditional edge already reaches END
            graph.add_edge(s, END)

        logger.info(
            "Sequential DAG: %d nodes, %d edges, %d parallel root(s), %d sink(s)",
            len(agent_ids), len(seen), len(roots), len(sinks),
        )

        # Add HITL conditional edges: edit loops back, reject reaches END
        if hitl_node_ids:
            self._add_hitl_conditional_edges(
                graph, hitl_node_ids, successors, preceding_map=preceding
            )

        # Add Self-Review conditional edges: a failed review loops back to the
        # node it reviewed, a passing one continues forward.
        if review_node_ids:
            self._add_review_conditional_edges(
                graph, review_node_ids, successors, preceding_map=preceding
            )

        # Add Conditional/Router edges so the branch the node chose is the only
        # branch that runs.
        for cid in conditional_node_ids:
            self._wire_conditional_edge(
                graph, cid, agent_registry.get(cid, {}), successors.get(cid, [])
            )

        checkpointer = self._get_checkpointer(workflow)
        compiled = graph.compile(checkpointer=checkpointer)
        logger.info("Sequential DAG compiled successfully")
        return compiled

    @staticmethod
    def _is_hitl_node(node_config: Dict[str, Any]) -> bool:
        """
        True when this canvas node is a HITL checkpoint.

        Checks the same three places ``_create_node_for_type`` does. The edge
        wiring used to test only ``config["type"]``, so a node that declared
        itself through ``metadata.node_type`` got a checkpoint node with no
        conditional edge -- it could pause, but its decision could not route.
        """
        for value in (
            node_config.get("type"),
            (node_config.get("metadata") or {}).get("node_type"),
            (node_config.get("config") or {}).get("type"),
        ):
            if isinstance(value, str) and value.strip().lower() == "hitl":
                return True
        return False

    @staticmethod
    def _is_review_node(node_config: Dict[str, Any]) -> bool:
        """
        True when this canvas node is a Self-Review quality gate.

        Checks the same three places ``_create_node_for_type`` does, and accepts
        the same spellings the dispatcher does.
        """
        for value in (
            node_config.get("type"),
            (node_config.get("metadata") or {}).get("node_type"),
            (node_config.get("config") or {}).get("type"),
        ):
            if isinstance(value, str) and value.strip().lower() in (
                "self-review", "self_review", "selfreview"
            ):
                return True
        return False

    @staticmethod
    def _is_conditional_node(node_config: Dict[str, Any]) -> bool:
        """True when this canvas node is a Conditional/Router branch point."""
        for value in (
            node_config.get("type"),
            (node_config.get("metadata") or {}).get("node_type"),
            (node_config.get("config") or {}).get("type"),
        ):
            if isinstance(value, str) and value.strip().lower() in ("conditional", "router"):
                return True
        return False

    def _wire_conditional_edge(
        self,
        graph,
        node_id: str,
        node_config: Dict[str, Any],
        branch_targets: List[str],
    ) -> None:
        """
        Wire a Conditional node's dynamic outgoing edge.

        WHAT: Replaces the node's static edges with one conditional edge driven
              by the decision the node wrote to ``_conditional_route``.
        WHY:  ``_create_conditional_routing_function`` existed and was never
              called, and no ``add_conditional_edges`` was wired for a
              conditional node anywhere. The node evaluated its branches and
              stored a decision that nothing read, while its static edges sent
              execution down *every* branch at once. A workflow with an
              if/else ran both sides.

        Args:
            graph: StateGraph being built.
            node_id: The conditional node's LangGraph ID.
            node_config: Its configuration, carrying ``config.branches``.
            branch_targets: Connection-derived target IDs.
        """
        from langgraph.graph import END

        branches_config = (
            (node_config.get("config") or {}).get("branches")
            or (node_config.get("metadata") or {}).get("branches")
            or []
        )

        routing_function = self._create_conditional_routing_function(
            node_id, node_config, branch_targets, branches_config
        )

        # LangGraph resolves a returned value through path_map, so every value
        # the router can return has to appear here or it raises KeyError.
        path_map: Dict[str, str] = {target: target for target in branch_targets}
        path_map[END] = END

        graph.add_conditional_edges(node_id, routing_function, path_map)

        logger.info(
            "Wired conditional edge: %s -> targets=%s + END (%d branch rules)",
            node_id, branch_targets, len(branches_config),
        )

    def _add_hitl_conditional_edges(
        self,
        graph,
        hitl_nodes: List[str],
        successor_map: Dict[str, List[str]],
        preceding_map: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Wire each HITL node's dynamic outgoing edge.

        Every one of the four decisions ends up as a routing target:

            approve  -> the node's first successor, or END
            edit     -> back to the preceding agent, which re-executes
            reject   -> END, with the run recorded as rejected

        The routing itself lives in ``_wire_hitl_conditional_edge``, which reads
        the ``_hitl_route`` key the node writes and maps it through a path_map.

        This method previously built its own routing function that could return
        ``None`` -- never a valid LangGraph destination -- and called
        ``add_conditional_edges(..., default=None)``. ``add_conditional_edges``
        takes ``(source, path, path_map)`` and has no ``default`` parameter, so
        **every workflow containing a HITL node raised TypeError at compile
        time**. Nothing routed because nothing compiled.

        Args:
            graph: StateGraph being built.
            hitl_nodes: HITL node IDs.
            successor_map: node_id -> [successor_ids], for the forward path.
            preceding_map: node_id -> predecessor_id, for the edit loop.
        """
        if not hitl_nodes:
            return

        preceding_map = preceding_map or {}

        for hitl_node_id in hitl_nodes:
            self._wire_hitl_conditional_edge(
                graph,
                hitl_node_id,
                preceding_map.get(hitl_node_id),
                successor_map.get(hitl_node_id, []),
            )

    def _add_review_conditional_edges(
        self,
        graph,
        review_nodes: List[str],
        successor_map: Dict[str, List[str]],
        preceding_map: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Wire each Self-Review node's dynamic outgoing edge.

        The mirror of ``_add_hitl_conditional_edges``: a review node now decides
        its own destination, so its static edge is replaced by a conditional
        one. Passing forwards; failing routes back to the reviewed node.

        Args:
            graph: StateGraph being built.
            review_nodes: Self-Review node IDs.
            successor_map: node_id -> [successor_ids], for the forward path.
            preceding_map: node_id -> predecessor_id, for the retry loop.
        """
        if not review_nodes:
            return

        preceding_map = preceding_map or {}

        for review_node_id in review_nodes:
            self._wire_review_conditional_edge(
                graph,
                review_node_id,
                preceding_map.get(review_node_id),
                successor_map.get(review_node_id, []),
            )

    def _wire_review_conditional_edge(
        self,
        graph,
        review_node_id: str,
        preceding_node_id: Optional[str],
        successor_node_ids: List[str],
    ) -> None:
        """
        Wire one Self-Review node's outgoing edge to the route it chose.

        WHAT: Replaces the node's static outgoing edge with a conditional one
              driven by ``_review_route``.
        WHY:  A static edge and a dynamic destination both fire, so a node that
              wants to route backwards must own its outgoing edge outright.
              This is the same constraint that made the HITL edit loop need
              ``_wire_hitl_conditional_edge``; see that method for the detail.

        Args:
            graph: StateGraph being built.
            review_node_id: The Self-Review node's LangGraph ID.
            preceding_node_id: The reviewed node, and the retry destination.
            successor_node_ids: Where a passing review continues to.
        """
        from langgraph.graph import END

        valid_targets = set()
        if preceding_node_id:
            valid_targets.add(preceding_node_id)
        for sid in successor_node_ids:
            valid_targets.add(sid)

        _successors = list(successor_node_ids)
        _default_target = _successors[0] if _successors else None

        def review_routing_function(state: Dict[str, Any]) -> str:
            """Route on ``_review_route``, written by the review node."""
            route = state.get("_review_route", "")

            if route and route in valid_targets:
                logger.info("[REVIEW-ROUTE] %s -> %s", review_node_id, route)
                return route

            if route == "__end__":
                logger.info("[REVIEW-ROUTE] %s -> END (sentinel)", review_node_id)
                return END

            # No usable decision. Forward is the safe default: it is what this
            # node did before it could route at all.
            if _default_target:
                logger.info(
                    "[REVIEW-ROUTE] %s -> %s (default)",
                    review_node_id, _default_target,
                )
                return _default_target

            logger.info("[REVIEW-ROUTE] %s -> END (no successor)", review_node_id)
            return END

        path_map: Dict[str, str] = {t: t for t in valid_targets}
        path_map[END] = END
        path_map["__end__"] = END

        graph.add_conditional_edges(
            review_node_id,
            review_routing_function,
            path_map,
        )

        logger.info(
            "Wired Self-Review conditional edge: %s -> targets=%s + END "
            "(reviewed=%s)",
            review_node_id, list(valid_targets), preceding_node_id,
        )

    def _compile_parallel_dag(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]],
        WorkflowState: type
    ) -> Any:
        """
        Compile a workflow into a parallel DAG (all agents concurrent).
        
        All agents execute simultaneously regardless of connections.
        Useful for independent analysis workflows that don't depend on
        each other's outputs. Still respects explicit connections if defined.
        
        Topology:
            START → [agent1, agent2, ..., agentN] (all parallel)
                  ↓        ↓              ↓
            CONVERGENCE (aggregates results)
                  ↓
                 END
        """
        from langgraph.graph import StateGraph, START, END
        
        logger.info("Compiling parallel DAG (all agents concurrent)...")
        graph = StateGraph(WorkflowState)
        
        # Extract agent IDs
        agent_ids: list[str] = []
        for entry in workflow.get("agents", []):
            if isinstance(entry, str):
                agent_ids.append(entry)
            elif isinstance(entry, dict) and entry.get("agent_id") is not None:
                agent_ids.append(str(entry["agent_id"]))
            elif entry is not None:
                agent_ids.append(str(entry))
        agent_id_set = set(agent_ids)
        
        # HITL and Self-Review nodes own their outgoing edge; identify them
        # before wiring.
        hitl_node_ids = [
            aid for aid in agent_ids
            if self._is_hitl_node(agent_registry.get(aid, {}))
        ]
        review_node_ids = [
            aid for aid in agent_ids
            if self._is_review_node(agent_registry.get(aid, {}))
        ]
        # In a pure fan-out a review node has no predecessor, so it can never
        # retry -- it reviews and continues. The conditional edge is still
        # wired, so the routing is decided in one place for every topology.
        hitl_set = set(hitl_node_ids) | set(review_node_ids)

        # Create nodes. In a pure fan-out there is no topological order to
        # follow, so ``seq`` is declaration order -- the only stable ordering a
        # set of concurrent branches has, and the order the canvas lists them in.
        for index, aid in enumerate(agent_ids):
            cfg = agent_registry.get(aid, {})
            node_func = self._create_node_for_type(
                aid, cfg,
                preceding_node_id=None,  # No predecessors in pure parallel
                successor_node_ids=(
                    ["convergence"] if len(agent_ids) > 1 else None
                ),
                seq=index,
            )
            graph.add_node(aid, node_func)
        
        # All agents start in parallel from START
        for aid in agent_ids:
            graph.add_edge(START, aid)
        
        # Add convergence node if multiple agents exist
        if len(agent_ids) > 1:
            # Phase 8 replaced the previous convergence node with the shared
            # merge node. The old one read ``state[f"{aid}_output"]`` -- a key
            # no node has ever written, since an agent node writes
            # ``{key: output for key in output_schema}`` and output_schema
            # defaults to ["output"]. Its ``aggregated_outputs`` was therefore
            # always empty and the ``_convergence_result`` it produced was read
            # by nothing. It also returned the whole mutated ``state``, which
            # re-wrote every key through the last-writer-wins reducer.
            #
            # The merge node reads ``all_node_outputs`` instead -- the
            # accumulator API, MCP and Code nodes already wrote to, and which
            # agent nodes now write to as well.
            convergence_node = self._create_parallel_merge_node(
                "convergence", expected_count=len(agent_ids)
            )
            graph.add_node("convergence", convergence_node)
            
            # All agents feed into convergence, except HITL nodes, whose
            # conditional edge reaches convergence on approve and END on
            # reject.
            for aid in agent_ids:
                if aid in hitl_set:
                    continue
                graph.add_edge(aid, "convergence")
            
            # Convergence feeds to END
            graph.add_edge("convergence", END)
            
            logger.info(
                "Parallel DAG: %d agents → convergence node → END",
                len(agent_ids),
            )
        else:
            # Single agent: directly to END
            if agent_ids and agent_ids[0] not in hitl_set:
                graph.add_edge(agent_ids[0], END)
            
            logger.info("Parallel DAG: single agent (no convergence needed)")
        
        # Add HITL conditional edges for edit-loop support in parallel execution
        if hitl_node_ids:
            # For parallel execution, successors are the convergence node or END
            successor_map = {}
            for aid in agent_ids:
                if len(agent_ids) > 1:
                    successor_map[aid] = ["convergence"]
                else:
                    successor_map[aid] = [END]
            # No predecessor in a pure fan-out, so an edit decision has nothing
            # to route back to; the node logs that and continues forward.
            self._add_hitl_conditional_edges(graph, hitl_node_ids, successor_map)
            logger.info(f"Parallel DAG: wired HITL conditional edges for {len(hitl_node_ids)} HITL nodes")

        if review_node_ids:
            successor_map = {
                aid: (["convergence"] if len(agent_ids) > 1 else [END])
                for aid in agent_ids
            }
            self._add_review_conditional_edges(
                graph, review_node_ids, successor_map
            )
            logger.info(
                "Parallel DAG: wired Self-Review conditional edges for %d node(s)",
                len(review_node_ids),
            )
        
        checkpointer = self._get_checkpointer(workflow)
        compiled = graph.compile(checkpointer=checkpointer)
        logger.info("Parallel DAG compiled successfully")
        return compiled

    def _compile_hierarchical_dag(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]],
        WorkflowState: type
    ) -> Any:
        """
        Compile a workflow into a hierarchical DAG (coordinator pattern).
        
        A coordinator agent delegates work to sub-agents and aggregates results.
        The coordinator is the entry point; sub-agents are dependencies.
        Requires workflow to define coordinator_id in execution_config.
        """
        from langgraph.graph import StateGraph, START, END
        
        logger.info("Compiling hierarchical DAG (coordinator pattern)...")
        graph = StateGraph(WorkflowState)
        
        # Extract agent IDs
        agent_ids: list[str] = []
        for entry in workflow.get("agents", []):
            if isinstance(entry, str):
                agent_ids.append(entry)
            elif isinstance(entry, dict) and entry.get("agent_id") is not None:
                agent_ids.append(str(entry["agent_id"]))
            elif entry is not None:
                agent_ids.append(str(entry))
        agent_id_set = set(agent_ids)
        
        # Get coordinator ID from execution_config or use first agent
        execution_config = workflow.get("execution_config", {})
        coordinator_id = execution_config.get("coordinator_id", agent_ids[0] if agent_ids else None)
        
        # HITL and Self-Review nodes own their outgoing edge; identify them
        # before wiring.
        hitl_node_ids = [
            aid for aid in agent_ids
            if self._is_hitl_node(agent_registry.get(aid, {}))
        ]
        review_node_ids = [
            aid for aid in agent_ids
            if self._is_review_node(agent_registry.get(aid, {}))
        ]
        hitl_set = set(hitl_node_ids) | set(review_node_ids)

        # Create nodes. The coordinator runs first, so ``seq`` follows the
        # declaration order of the sub-agents beneath it.
        for index, aid in enumerate(agent_ids):
            cfg = agent_registry.get(aid, {})
            node_func = self._create_node_for_type(
                aid, cfg,
                preceding_node_id=coordinator_id if aid != coordinator_id else None,
                successor_node_ids=None,
                seq=index,
            )
            graph.add_node(aid, node_func)
        
        # Wire coordinator at START; sub-agents after coordinator
        if coordinator_id:
            graph.add_edge(START, coordinator_id)
            sub_agent_ids = [aid for aid in agent_ids if aid != coordinator_id]
            for aid in sub_agent_ids:
                graph.add_edge(coordinator_id, aid)
            
            # ✅ FIX #5: Add hierarchical convergence node with Coordinator aggregation
            if sub_agent_ids:
                def hierarchical_convergence(state: Dict[str, Any]) -> Dict[str, Any]:
                    """
                    Hierarchical convergence node using CoordinatorAgent aggregation.
                    Aggregates outputs from all sub-agents using configured strategy.
                    """
                    from apps.workflow.runtime.coordinator import CoordinatorAgent, SubAgentOutput
                    import asyncio
                    
                    logger.info(
                        "Hierarchical convergence: aggregating %d sub-agent outputs",
                        len(sub_agent_ids),
                        extra={"agent_count": len(sub_agent_ids), "node_name": "hierarchical_convergence"}
                    )
                    
                    # Collect outputs from all sub-agents with type validation
                    sub_outputs = []
                    state_schema = workflow.get("state_schema", {})
                    
                    for aid in sub_agent_ids:
                        output = state.get(f"{aid}_output", {})
                        exec_time = state.get(f"{aid}_execution_time_ms", 0)
                        status = state.get(f"{aid}_status", "completed")
                        
                        # ✅ Add type validation before aggregating (FIX #6)
                        # Validate output type according to state schema if defined
                        output_schema = state_schema.get(f"{aid}_output", {})
                        if output_schema and output:
                            try:
                                validated_output = TypeResolver.coerce_value(output, output_schema)
                                logger.debug(
                                    f"Type-validated sub-agent output '{aid}' (type: {output_schema.get('type', 'unknown')})",
                                    extra={"agent": aid, "type": output_schema.get("type", "unknown")}
                                )
                            except Exception as e:
                                logger.warning(
                                    f"Type validation failed for sub-agent '{aid}' output, using raw value",
                                    extra={"agent": aid, "error": str(e)}
                                )
                                validated_output = output
                        else:
                            validated_output = output
                        
                        sub_outputs.append(
                            SubAgentOutput(
                                agent_name=aid,
                                agent_id=aid,
                                output=validated_output,
                                execution_time_ms=exec_time,
                                status=status
                            )
                        )
                    
                    # Aggregate using coordinator strategy
                    aggregation_strategy = execution_config.get("coordinator_strategy", "merge")
                    
                    # Bridge async aggregation to sync context using proper async bridge
                    from ..runtime.async_util import run_coro_blocking
                    coordinator = CoordinatorAgent()
                    aggregated = run_coro_blocking(
                        lambda: coordinator.aggregate_sub_agent_outputs(
                            sub_outputs=sub_outputs,
                            strategy=aggregation_strategy,
                            coordinator_context={"workflow_id": workflow.get("workflow_id", "unknown")}
                        ),
                        timeout=30.0
                    )
                    
                    state["_coordinator_result"] = aggregated
                    logger.debug(
                        "Hierarchical convergence complete using strategy '%s'",
                        aggregation_strategy,
                        extra={"strategy": aggregation_strategy}
                    )
                    
                    return state
                
                graph.add_node("hierarchical_convergence", hierarchical_convergence)
                
                # All sub-agents feed into convergence, except HITL nodes,
                # whose conditional edge decides their own destination.
                for aid in sub_agent_ids:
                    if aid in hitl_set:
                        continue
                    graph.add_edge(aid, "hierarchical_convergence")
                
                # Convergence feeds to END
                graph.add_edge("hierarchical_convergence", END)
                logger.info("Hierarchical DAG: added coordinator convergence node")
            else:
                # No sub-agents, coordinator to END directly
                graph.add_edge(coordinator_id, END)
        else:
            # Fallback: linear execution if no coordinator defined
            for aid in agent_ids:
                graph.add_edge(START, aid)
                graph.add_edge(aid, END)
        
        logger.info(
            "Hierarchical DAG: %d nodes with coordinator '%s'",
            len(agent_ids), coordinator_id,
        )
        
        # Add HITL conditional edges for edit-loop support in hierarchical execution
        if hitl_node_ids:
            # For hierarchical execution, successors are END (HITL nodes don't chain in hierarchical)
            successor_map = {}
            for aid in agent_ids:
                successor_map[aid] = [END]
            # A sub-agent's predecessor is the coordinator, so an edit decision
            # re-runs the coordinator's delegation.
            preceding_map = {
                aid: coordinator_id
                for aid in agent_ids
                if aid != coordinator_id
            }
            self._add_hitl_conditional_edges(
                graph, hitl_node_ids, successor_map, preceding_map=preceding_map
            )
            logger.info(f"Hierarchical DAG: wired HITL conditional edges for {len(hitl_node_ids)} HITL nodes")

        # Self-Review nodes: a failed review re-runs the coordinator that
        # delegated the work, which is the only node upstream of a sub-agent.
        if review_node_ids:
            successor_map = {aid: [END] for aid in agent_ids}
            preceding_map = {
                aid: coordinator_id
                for aid in agent_ids
                if aid != coordinator_id
            }
            self._add_review_conditional_edges(
                graph, review_node_ids, successor_map, preceding_map=preceding_map
            )
            logger.info(
                "Hierarchical DAG: wired Self-Review conditional edges for %d node(s)",
                len(review_node_ids),
            )
        
        checkpointer = self._get_checkpointer(workflow)
        compiled = graph.compile(checkpointer=checkpointer)
        logger.info("Hierarchical DAG compiled successfully")
        return compiled

    def _compile_hybrid_dag(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]],
        WorkflowState: type
    ) -> Any:
        """
        Compile a workflow into a hybrid DAG (mixed topology).
        
        Supports mixed sequential and parallel sections. Uses topological
        levels from workflow connections to determine execution strategy:
        agents at same level execute in parallel, different levels sequential.
        Falls back to sequential DAG compilation if no explicit levels defined.
        """
        from langgraph.graph import StateGraph, START, END
        
        logger.info("Compiling hybrid DAG (mixed topology)...")
        
        # For now, hybrid delegates to sequential (most conservative)
        # In production, would implement topological level detection
        logger.info("Hybrid DAG: delegating to sequential compilation")
        return self._compile_sequential_dag(workflow, agent_registry, WorkflowState)

    def _create_state_class(
        self,
        workflow: Dict[str, Any],
        agent_registry: Dict[str, Dict[str, Any]]
    ) -> type:
        """
        Create TypedDict state class for workflow.

        Args:
            workflow: Workflow definition
            agent_registry: Agent definitions

        Returns:
            TypedDict class for state
        """
        # Collect all state keys from agents
        state_keys = set()

        # Handle both embedded agent objects and ID-referenced agents
        for agent_entry in workflow.get("agents", []):
            if isinstance(agent_entry, str):
                agent_id = agent_entry
                agent = agent_registry.get(agent_id, {})
            elif isinstance(agent_entry, dict):
                agent_id = agent_entry.get("agent_id")
                agent = agent_entry
            else:
                continue

            state_keys.update(agent.get("input_schema", []))
            state_keys.update(agent.get("output_schema", []))

            # Extract state keys from agent variables (config.variables or top-level variables)
            agent_vars = (
                agent.get("config", {}).get("variables", [])
                or agent.get("variables", [])
            )
            for var in agent_vars:
                var_name = var.get("name") if isinstance(var, dict) else None
                if var_name:
                    state_keys.add(var_name)

            # Extract variable names referenced in conditional branch conditions
            branches = (
                agent.get("config", {}).get("branches", [])
                or agent.get("metadata", {}).get("branches", [])
            )
            if branches:
                import re as _re
                _ignore = {
                    'and', 'or', 'not', 'True', 'False', 'None', 'true', 'false',
                    'null', 'len', 'str', 'int', 'float', 'bool', 'abs', 'min',
                    'max', 'isinstance', 'list', 'dict', 'in', 'is', 'if', 'else',
                    'AND', 'OR', 'NOT',
                }
                for branch in branches:
                    condition = branch.get("condition", "") if isinstance(branch, dict) else ""
                    if condition:
                        identifiers = set(_re.findall(r'\b([a-zA-Z_]\w*)\b', condition))
                        identifiers -= _ignore
                        state_keys.update(identifiers)

        # Add workflow-level state keys
        state_keys.update(workflow.get("state_schema", {}).keys())

        # Create TypedDict dynamically
        # Use Annotated[Any, _last_writer_wins] for data fields so that
        # concurrent writes from parallel branches don't raise
        # INVALID_CONCURRENT_GRAPH_UPDATE.  Only messages uses operator.add.
        def _last_writer_wins(existing, new):
            """Reducer: last writer wins (accepts concurrent writes)."""
            return new

        _LWW = Annotated[Any, _last_writer_wins]

        fields = {key: _LWW for key in state_keys}

        # Add standard workflow fields
        fields["user_input"] = _LWW
        fields["task_description"] = _LWW
        # Named after the framework that used to write it. Kept as the agent
        # node's primary output key because the canvas reads it
        # (``workflow-ide``: ``snapshot.crew_result``); renaming it is a
        # coordinated frontend change, tracked as a Phase 9 frontend TODO.
        fields["crew_result"] = _LWW

        # FIXED: Add original_user_input to preserve user query throughout workflow
        # This ensures all agents have access to the original request
        fields["original_user_input"] = _LWW

        # Parallel execution fields
        fields["parallel_output"] = _LWW
        fields["individual_outputs"] = _LWW
        fields["hierarchical_output"] = _LWW

        # Execution context fields - required for transparency tracking
        # These fields are set by executor.py and must be preserved across all nodes
        fields["run_id"] = _LWW
        fields["workflow_id"] = _LWW

        # --- Universal Integration Layer: Node output fields ---
        # last_node_output: carries the FULL output from the previous node
        # so that subsequent nodes (Agent, API, MCP, Code) receive complete context.
        # This is overwritten each step (no reducer) — only the latest output is kept.
        fields["last_node_output"] = _LWW
        # Typed result fields for specific node kinds
        fields["api_result"] = _LWW       # Latest API node response (full body + metadata)
        fields["mcp_result"] = _LWW       # Latest MCP node response
        fields["code_result"] = _LWW      # Latest Code node execution output
        fields["review_result"] = _LWW    # Latest Self-Review validation result
        # Last LLM agent output — set ONLY by Agent nodes (sequential/parallel/hierarchical).
        # API, MCP, Code, and Self-Review nodes do NOT write this key, so the End node
        # can always distinguish the last real agent output from raw API/code responses.
        fields["_last_agent_output"] = _LWW
        # Conditional routing helper (already used by _create_conditional_node)
        fields["_conditional_route"] = _LWW
        fields["_conditional_node"] = _LWW

        # Self-Review retry loop: where the review node sends execution next,
        # and how many attempts each review node has spent on its subject.
        #
        # The attempt counter is NOT last-writer-wins. Two review nodes on
        # parallel branches write it in the same superstep, and under LWW one
        # of those counts would be dropped -- the loop would then run past its
        # own ceiling. ``_merge_review_attempts`` keeps the highest count seen
        # per node, so a lost update can only ever end the loop early, never
        # extend it. A retry budget must fail towards stopping.
        fields["_review_route"] = _LWW
        fields["_review_attempts"] = Annotated[
            Dict[str, int], _merge_review_attempts
        ]

        # HITL edit-loop routing: when a HITL node routes back to the
        # preceding agent for re-execution, the target node ID is stored
        # here so the conditional edge routing function can read it.
        fields["_hitl_route"] = _LWW
        # Edit feedback injected by HITL edit action for the preceding agent
        fields["_edit_feedback"] = _LWW
        # The reviewer's decision at the last HITL checkpoint: approved,
        # rejected, editing. Read by the executor to record the run's
        # final status, so a rejection is reported as a rejection rather than as
        # a failure. Not prefixed with "_" because it is a run outcome the
        # caller is entitled to see.
        fields["hitl_outcome"] = _LWW

        # Document upload capability fields (set by Start node file upload)
        fields["document_context"] = _LWW
        fields["document_metadata"] = _LWW

        # Execution context: AURA primitives, and the application's contributed
        # datasources (connectors, knowledge bases, uploaded session documents).
        #
        # ``WorkflowExecutor`` has always seeded this into ``initial_state`` and
        # ``langchain_adapter`` has always read it back as an agent's
        # ``exec_context`` -- but it was never DECLARED here, and LangGraph
        # propagates only the keys its state schema declares as channels. Every
        # other key in ``initial_state`` is silently discarded before the first
        # node runs.
        #
        # So ``state.get("_aura_exec")`` returned ``{}`` on every workflow run,
        # and the merge in ``AgentFactory._merge_application_context`` was a
        # no-op. That is why every agent in every workflow built with
        # ``connector_tools=0 context_tools=0 session_doc_tools=0`` no matter
        # what the user attached to the application: an uploaded document was
        # resolved, bound into a contribution, threaded through the definition
        # -- and then dropped by the graph one step before the agent that needed
        # it. Declaring the channel is what makes that whole path live.
        fields["_aura_exec"] = _LWW

        # Accumulating field for node outputs, keyed by node so a re-run
        # replaces its own entry instead of appending a second one.
        #
        # Phase 8 replaced operator.add here. operator.add is not idempotent,
        # and this graph re-runs nodes by design: the HITL edit action routes
        # back to the preceding agent (``_hitl_route``, see
        # _add_hitl_conditional_edges), and ModelRetryMiddleware re-invokes a
        # model call on a retryable failure. With plain append, an edited agent
        # would appear twice at the merge and be summarised twice.
        #
        # Ordering is carried by ``seq`` on each entry rather than by arrival:
        # a reducer guarantees merging, never order, so the sink sorts.
        fields["all_node_outputs"] = Annotated[
            List[Dict[str, Any]], merge_node_outputs
        ]

        # Messages field accumulates across nodes
        fields["messages"] = Annotated[List[Dict[str, Any]], operator.add]

        WorkflowState = TypedDict("WorkflowState", fields)
        return WorkflowState

    def _create_conditional_node(
        self,
        node_id: str,
        agent_config: Dict[str, Any],
        branch_targets: List[str] = None
    ):
        """
        Create a conditional/router node function.

        This node evaluates conditions and stores the routing decision in state.
        The actual routing is handled by LangGraph's add_conditional_edges.

        Args:
            node_id: Node identifier
            agent_config: Node configuration with branches
            branch_targets: Connection-derived list of valid target node IDs.
                Used to log warnings when branches_config targetNodeIds
                do not match registered LangGraph edge targets.

        Returns:
            Callable node function that evaluates conditions
        """
        node_name = agent_config.get("name", node_id)
        branches_config = agent_config.get("config", {}).get("branches", [])
        # Snapshot for use inside the closure; default to empty list
        _valid_targets = list(branch_targets) if branch_targets else []

        def conditional_node(state: Dict[str, Any]) -> Dict[str, Any]:
            """
            Conditional node that evaluates branch conditions.

            The routing decision is stored in state for the routing function
            to use when LangGraph invokes add_conditional_edges.
            """
            # Log non-internal state keys for debugging conditional evaluation
            user_state_keys = {
                k: (type(v).__name__, repr(v)[:100])
                for k, v in state.items()
                if not k.startswith("_") and k != "messages"
            }
            logger.info(
                f"Conditional node '{node_name}' evaluating branches. "
                f"State vars: {{{', '.join(f'{k}({t})={val}' for k, (t, val) in user_state_keys.items())}}}"
            )

            # Evaluate each branch condition against current state
            selected_branch = None
            selected_target = None

            for branch in branches_config:
                branch_type = branch.get("type", "")
                condition = branch.get("condition", "")
                target_node_id = branch.get("targetNodeId")

                if branch_type == "else":
                    # Else branch is the fallback - save it but continue checking
                    if selected_branch is None:
                        selected_branch = branch
                        selected_target = str(target_node_id) if target_node_id else None
                        if selected_target and _valid_targets and selected_target not in _valid_targets:
                            logger.warning(
                                f"Conditional node '{node_name}': else branch targetNodeId "
                                f"'{selected_target}' not in connection-derived targets "
                                f"{_valid_targets}. Routing function will handle fallback."
                            )
                    continue

                if branch_type in ("if", "elif") and condition:
                    # For elif: only evaluate if no earlier branch has already matched
                    if branch_type == "elif" and selected_branch is not None:
                        continue
                    # Evaluate the condition against state
                    try:
                        # Create evaluation context from state
                        eval_context = dict(state)
                        # Safe evaluation of simple conditions
                        result = self._evaluate_condition(condition, eval_context)
                        if result:
                            selected_branch = branch
                            selected_target = str(target_node_id) if target_node_id else None
                            if selected_target and _valid_targets and selected_target not in _valid_targets:
                                logger.warning(
                                    f"Conditional node '{node_name}': {branch_type} branch "
                                    f"targetNodeId '{selected_target}' not in connection-derived "
                                    f"targets {_valid_targets}. Routing function will handle fallback."
                                )
                            logger.info(f"Condition '{condition}' ({branch_type}) evaluated to True, routing to {selected_target}")
                            break
                    except Exception as e:
                        logger.warning(f"Failed to evaluate condition '{condition}': {e}")
                        continue

            # If no condition matched and we have an else branch, use it
            if selected_target is None and branches_config:
                # Find the else branch
                for branch in branches_config:
                    if branch.get("type") == "else":
                        selected_target = str(branch.get("targetNodeId"))
                        if selected_target and _valid_targets and selected_target not in _valid_targets:
                            logger.warning(
                                f"Conditional node '{node_name}': else fallback targetNodeId "
                                f"'{selected_target}' not in connection-derived targets "
                                f"{_valid_targets}. Routing function will handle fallback."
                            )
                        logger.info(f"No conditions matched, using else branch to {selected_target}")
                        break

            # Store routing decision in state for the routing function
            return {
                "_conditional_route": selected_target,
                "_conditional_node": node_id,
                "messages": [{
                    "node": node_id,
                    "type": "conditional",
                    "name": node_name,
                    "selected_route": selected_target,
                    "action": "branch_evaluated"
                }]
            }

        return conditional_node

    def _create_conditional_routing_function(
        self,
        node_id: str,
        agent_config: Dict[str, Any],
        branch_targets: List[str],
        branches_config: List[Dict[str, Any]]
    ):
        """
        Create the routing function for a conditional node's outgoing edges.

        LangGraph calls this to pick the next node. It reads the decision the
        conditional node already made and wrote to ``_conditional_route``.

        One decision, one evaluator
        ---------------------------
        This used to re-evaluate every branch condition itself whenever
        ``_conditional_route`` was missing. That fallback was dead when the node
        had run (the key is always present then), and actively wrong when it had
        not: it re-decided against a state the node never saw, so the graph could
        take a branch the node would not have chosen. A condition is evaluated
        in the node, and nowhere else.

        When the key is absent, the node did not run -- a graph-construction
        problem, not a routing one. The router says so and takes the else
        branch rather than inventing a decision.

        Args:
            node_id: Conditional node identifier.
            agent_config: Node configuration.
            branch_targets: Valid target node IDs, derived from connections.
            branches_config: Branch configurations, read only for the else target.

        Returns:
            Callable routing function returning a target node ID.
        """
        from langgraph.graph import END

        # Determine default target (else branch or last target)
        default_target = None
        for branch in branches_config:
            if branch.get("type") == "else":
                target = branch.get("targetNodeId")
                default_target = str(target) if target else None
                break

        # Validate default_target is a registered edge target.
        # The else branch targetNodeId (from branches_config) may reference a
        # node that is not in branch_targets (derived from connections).
        # LangGraph only knows about branch_targets via path_map, so returning
        # an unknown target causes a KeyError in langgraph/graph/_branch.py.
        # Fall back to the last branch target when there is a mismatch.
        if default_target not in branch_targets:
            if default_target is not None:
                logger.warning(
                    f"Conditional node {node_id}: else branch targetNodeId "
                    f"'{default_target}' is not in connection-derived branch_targets "
                    f"{branch_targets}. Falling back to last branch target."
                )
            if branch_targets:
                default_target = branch_targets[-1]
            else:
                default_target = None

        def routing_function(state: Dict[str, Any]) -> str:
            """Return the target node ID this conditional decided on."""
            selected_route = state.get("_conditional_route")
            decided_by = state.get("_conditional_node")

            # Two conditional nodes in one superstep share ``_conditional_route``
            # under a last-writer-wins reducer. Routing on a sibling's decision
            # would be worse than falling back, so the writer is checked.
            if decided_by and decided_by != node_id:
                logger.warning(
                    f"Conditional node {node_id}: the routing decision in state was "
                    f"written by '{decided_by}'. Using the else branch instead of "
                    f"another node's decision."
                )
                selected_route = None

            if selected_route and selected_route in branch_targets:
                logger.info(f"Routing from {node_id} to {selected_route}")
                return selected_route

            if selected_route:
                logger.warning(
                    f"Conditional node {node_id}: decided on '{selected_route}', which "
                    f"is not a wired target {branch_targets}. Check that the branch's "
                    f"targetNodeId matches a connection on the canvas."
                )
            elif decided_by is None:
                logger.error(
                    f"Conditional node {node_id}: no routing decision found in state. "
                    f"The node did not run before its edge was evaluated, which is a "
                    f"graph-construction problem. Taking the else branch."
                )

            if default_target and default_target in branch_targets:
                logger.info(f"Using default route from {node_id} to {default_target}")
                return default_target

            if branch_targets:
                fallback = branch_targets[-1]
                logger.warning(
                    f"Conditional node {node_id}: no usable default target. "
                    f"Falling back to '{fallback}'."
                )
                return fallback

            # A conditional with no wired targets is a dead end; ending the
            # branch is the only valid destination.
            logger.error(
                f"Conditional node {node_id}: no branch targets are wired. Routing to END."
            )
            return END

        return routing_function


    def _evaluate_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """
        Safely evaluate a condition string against a context.

        Supports both Python and JavaScript-style conditions:
        - Python:     "risk_score > 70 and status == 'approved'"
        - JavaScript: "extractionConfidence >= 0.9 && missingFields.length === 0"
        - Mixed:      "total_days <= 3 AND coverage_risk !== 'high'"

        Handles:
        - && / ||           → and / or
        - === / !==         → == / !=
        - .length           → len()
        - !variable         → not variable
        - AND / OR          → and / or (case-insensitive)
        - Numeric coercion  → string "42" becomes int 42

        Args:
            condition: Condition string to evaluate
            context: Dictionary of variable values

        Returns:
            Boolean result of condition evaluation
        """
        import re as _re

        if not condition or not condition.strip():
            return False

        normalized = condition.strip()

        # ─── JavaScript → Python syntax translation ───

        # Strict equality / inequality BEFORE loose equality
        normalized = normalized.replace("!==", "!=").replace("===", "==")

        # Logical operators
        normalized = normalized.replace("&&", " and ").replace("||", " or ")

        # Case-insensitive AND / OR (word boundaries)
        normalized = _re.sub(r'\bAND\b', 'and', normalized)
        normalized = _re.sub(r'\bOR\b', 'or', normalized)
        normalized = _re.sub(r'\bNOT\b', 'not', normalized)

        # .length → len() — e.g. "missingFields.length" → "len(missingFields)"
        normalized = _re.sub(
            r'(\w+)\.length\b',
            r'len(\1)',
            normalized
        )

        # JavaScript negation: "!varName" → "not varName"
        # Only match "!" that is NOT part of "!=" and is followed by a word char
        normalized = _re.sub(r'(?<!=)!(\w)', r'not \1', normalized)

        logger.info(
            f"[CONDITION EVAL] Original: '{condition}' → Normalized: '{normalized}'"
        )

        # ─── Extract variable names referenced in the condition ───
        # This helps debug which variables are present/missing in state
        referenced_vars = set(_re.findall(r'\b([a-zA-Z_]\w*)\b', normalized))
        # Remove Python keywords and builtins from the set
        _ignore = {
            'and', 'or', 'not', 'True', 'False', 'None', 'true', 'false',
            'null', 'len', 'str', 'int', 'float', 'bool', 'abs', 'min',
            'max', 'isinstance', 'list', 'dict', 'in', 'is', 'if', 'else'
        }
        referenced_vars -= _ignore

        # ─── Build safe evaluation environment ───
        safe_globals = {"__builtins__": {}}
        safe_locals = {}

        for k, v in context.items():
            # Skip internal keys for logging clarity
            if k.startswith("_"):
                safe_locals[k] = v
                continue
            # Coerce string values to their natural Python types
            if isinstance(v, str):
                stripped = v.strip()
                # Try JSON parse first (handles arrays, objects, booleans, null)
                if stripped and stripped[0] in ('[', '{'):
                    try:
                        import json as _json
                        v = _json.loads(stripped)
                    except (ValueError, TypeError):
                        pass
                elif stripped.lower() in ('true', 'yes'):
                    v = True
                elif stripped.lower() in ('false', 'no'):
                    v = False
                elif stripped.lower() in ('null', 'none'):
                    v = None
                else:
                    # Try numeric coercion
                    try:
                        v = int(stripped)
                    except ValueError:
                        try:
                            v = float(stripped)
                        except ValueError:
                            pass
            safe_locals[k] = v

        # Log which referenced variables are present/missing in state
        present_vars = {}
        missing_vars = []
        for var in referenced_vars:
            if var in safe_locals:
                present_vars[var] = safe_locals[var]
            else:
                missing_vars.append(var)

        # Try to recover missing variables from crew_result (often contains
        # structured JSON output from the upstream agent)
        if missing_vars:
            crew_result = context.get("crew_result", "")
            if isinstance(crew_result, str) and crew_result.strip():
                try:
                    import json as _json
                    # Try parsing the whole output as JSON
                    parsed_cr = _json.loads(crew_result.strip())
                    if isinstance(parsed_cr, dict):
                        for var in list(missing_vars):
                            if var in parsed_cr:
                                safe_locals[var] = parsed_cr[var]
                                missing_vars.remove(var)
                except (ValueError, TypeError):
                    # Try extracting a JSON block from within the text
                    json_block = _re.search(r'\{[^{}]*\}', crew_result)
                    if json_block:
                        try:
                            parsed_cr = _json.loads(json_block.group())
                            if isinstance(parsed_cr, dict):
                                for var in list(missing_vars):
                                    if var in parsed_cr:
                                        safe_locals[var] = parsed_cr[var]
                                        missing_vars.remove(var)
                        except (ValueError, TypeError):
                            pass

        # Coerce empty-string variables to sensible defaults so that
        # comparisons against numeric/boolean values don't raise TypeError
        for var in referenced_vars:
            val = safe_locals.get(var)
            if val == '' or val is None:
                # Default missing/empty vars to 0 so numeric comparisons work
                safe_locals[var] = 0

        # Rebuild present/missing lists after recovery
        present_vars = {}
        missing_vars = []
        for var in referenced_vars:
            if var in safe_locals:
                present_vars[var] = safe_locals[var]
            else:
                missing_vars.append(var)

        if present_vars:
            logger.info(
                f"[CONDITION EVAL] Variables found in state: "
                f"{{{', '.join(f'{k}={v!r}' for k, v in present_vars.items())}}}"
            )
        if missing_vars:
            logger.warning(
                f"[CONDITION EVAL] Variables NOT in state: {missing_vars} — "
                f"condition will likely evaluate to False. "
                f"Ensure the upstream agent sets these variables."
            )

        # Common boolean / null literals
        safe_locals["True"] = True
        safe_locals["False"] = False
        safe_locals["true"] = True
        safe_locals["false"] = False
        safe_locals["None"] = None
        safe_locals["null"] = None

        # Safe builtins needed for translated expressions
        safe_locals["len"] = len
        safe_locals["str"] = str
        safe_locals["int"] = int
        safe_locals["float"] = float
        safe_locals["bool"] = bool
        safe_locals["abs"] = abs
        safe_locals["min"] = min
        safe_locals["max"] = max
        safe_locals["isinstance"] = isinstance
        safe_locals["list"] = list
        safe_locals["dict"] = dict

        try:
            result = eval(normalized, safe_globals, safe_locals)
            bool_result = bool(result)
            logger.info(
                f"[CONDITION EVAL] Result: '{normalized}' → {bool_result}"
            )
            return bool_result
        except TypeError as e:
            # Handle comparison between incompatible types (e.g. str vs int)
            # by extracting numeric values from string operands.
            # This is centralized here so ALL conditional branches across
            # ALL workflows benefit automatically.
            if "not supported between" in str(e):
                logger.info(
                    f"[CONDITION EVAL] TypeError for '{normalized}': {e}. "
                    f"Retrying with numeric coercion of string operands."
                )
                for var in referenced_vars:
                    val = safe_locals.get(var)
                    if isinstance(val, str):
                        if val.strip() == '':
                            safe_locals[var] = 0
                        else:
                            num = _re.search(r'-?\d+(?:\.\d+)?', val)
                            if num:
                                safe_locals[var] = float(num.group()) if '.' in num.group() else int(num.group())
                try:
                    result = eval(normalized, safe_globals, safe_locals)
                    bool_result = bool(result)
                    logger.info(
                        f"[CONDITION EVAL] Result after coercion: '{normalized}' → {bool_result}"
                    )
                    return bool_result
                except Exception as inner_e:
                    logger.warning(
                        f"[CONDITION EVAL] Coercion retry also failed for '{normalized}': {inner_e}"
                    )
                    return False
            else:
                logger.warning(
                    f"[CONDITION EVAL] TypeError for '{condition}' "
                    f"(normalized: '{normalized}'): {e}"
                )
                return False
        except NameError as e:
            # Variable not found in context — treat as False
            logger.warning(
                f"[CONDITION EVAL] NameError for '{condition}': {e}. "
                f"Variable is missing from workflow state."
            )
            return False
        except Exception as e:
            logger.warning(
                f"[CONDITION EVAL] Error for '{condition}' "
                f"(normalized: '{normalized}'): {e}"
            )
            return False

    def _create_agent_node(
        self,
        agent_id: str,
        agent_config: Dict[str, Any],
        seq: int = 0,
    ):
        """
        Create an LLM agent node for LangGraph.

        Every agent -- on any node type that is not a purpose-built one -- is
        compiled by ``AgentFactory.build`` through ``create_react_agent_node``.
        That is the single instantiation path: the prompt, model, tools,
        connectors, attached context, readiness gate and budgets all come from
        the agent definition, so an agent behaves identically on a canvas and on
        its standalone page.

        This method used to carry a second branch for nodes whose
        ``metadata.node_type`` was "HITL". That branch called
        ``request_approval()`` and then immediately ``get_status()`` -- which
        naturally still read ``waiting_for_human`` -- and then executed the
        agent regardless. It never called ``interrupt()``, so it never paused
        for anyone. HITL is a node type, not an agent modifier, and it is now
        dispatched to ``_create_hitl_node`` by ``_create_node_for_type`` before
        this method is reached.

        Args:
            agent_id: Agent identifier.
            agent_config: Agent configuration.
            seq: Compile-order position, carried on the node's
                ``all_node_outputs`` entry so a fan-in orders branches by graph
                position rather than by name.

        Returns:
            Callable node function compatible with LangGraph.
        """
        logger.info(f"Creating LangChain node for agent: {agent_id}")
        from ..runtime.langchain_adapter import create_react_agent_node

        return create_react_agent_node(agent_config, seq=seq)


    # =====================================================================
    # UNIVERSAL INTEGRATION LAYER — New Node Types
    # =====================================================================

    def _create_api_node(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        seq: int = 0,
    ):
        """
        Create an API node function for LangGraph.

        Supports two modes:
        - Managed Mode: References a stored connector via connector_id and
          invokes it through ``apps/connector/middleware`` -- the same
          user-scoped, permission-checked path an agent's connector call takes.
          See ``runtime/connector_nodes.py`` for why this replaced the direct
          ``ConnectorManager().get_manager("api").invoke()`` call, which took no
          ``user_id`` and let a workflow reach any user's connector.
        - Ad-hoc Mode: Uses inline config (url, method, auth, headers, body)
          to create an ephemeral HTTPConnector for a single execution. There is
          no stored connector to own an ad-hoc call, so no permission model
          applies to it.

        IMPORTANT: APIConnector.invoke() and HTTPConnector.execute() are both
        SYNCHRONOUS. We wrap them with asyncio.to_thread() to avoid blocking
        the async event loop.

        The FULL response data is stored in state['last_node_output'] and
        state['api_result'] so the next node receives complete context.

        Args:
            node_id: Unique node identifier in the workflow graph.
            node_config: Node configuration dict. May contain:
                - connector_id (str): For Managed Mode
                - url/base_url (str): For Ad-hoc Mode
                - method (str): HTTP method (default GET)
                - headers (dict): Custom headers
                - query_params (dict): URL query parameters
                - body (dict): Request body
                - authentication/auth_config (dict): Auth configuration
                - payload (dict): For Managed Mode invocation payload

        Returns:
            Async callable node function compatible with LangGraph StateGraph.
        """
        config = node_config.get("config", node_config)
        # Fallback: resolve config from metadata for pre-fix workflows
        if (
            not config.get("url")
            and not config.get("base_url")
            and not config.get("connector_id")
            and not config.get("connectorId")
        ):
            config = node_config.get("metadata", {}).get("api_config", config)
        node_name = node_config.get("name", node_id)

        def _interpolate_template(template: str, state: Dict[str, Any]) -> str:
            """Replace {variable} and {{variable}} placeholders with values from state."""
            import re
            def _replacer(m):
                # group(1) captures from {{var}}, group(2) from {var}
                key = m.group(1) or m.group(2)
                val = state.get(key)
                if val is not None:
                    return str(val)
                return m.group(0)  # leave unreplaced if not in state
            # Match both {{var}} (double-brace) and {var} (single-brace).
            # Double-brace is tried first so it is consumed as a whole unit;
            # single-brace serves as fallback for templates that use only one.
            return re.sub(r"\{\{(\w+)\}\}|\{(\w+)\}", _replacer, template)

        def _interpolate_dict(d: Any, state: Dict[str, Any]) -> Any:
            """Recursively interpolate {variable}/{{variable}} placeholders in dicts/lists/strings."""
            if isinstance(d, str):
                return _interpolate_template(d, state)
            if isinstance(d, dict):
                return {k: _interpolate_dict(v, state) for k, v in d.items()}
            if isinstance(d, list):
                return [_interpolate_dict(item, state) for item in d]
            return d

        def api_node(state: Dict[str, Any]) -> Dict[str, Any]:
            from echolib.config import settings
            from echolib.utils import new_id

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # ─── Interpolate template variables from state ───
            # URLs like "https://api.example.com/v1/users/{employee_id}/balance"
            # and body/headers/query_params containing {variable} placeholders
            # are resolved against current workflow state before the HTTP call.
            live_config = _interpolate_dict(config, state)

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync,
                    publish_step_failed_sync
                )
                input_summary = {
                    "node_name": node_name,
                    "node_type": "API",
                    "mode": "managed" if live_config.get("connector_id") else "ad-hoc",
                    "method": live_config.get("method", "GET"),
                    "url": live_config.get("url") or live_config.get("base_url", ""),
                }
                step_tracker.start_step(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)
                publish_step_started_sync(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)

            try:
                from ..runtime.connector_nodes import (
                    as_dict,
                    auth_connector_id_of,
                    connector_id_of,
                    invoke_adhoc_api_with_borrowed_auth,
                )

                # Reads both spellings. The canvas writes ``connectorId``;
                # reading only ``connector_id`` here was half of why choosing a
                # stored connector never took effect -- the other half was
                # ``node_mapper`` dropping the key on save.
                connector_id = connector_id_of(live_config)

                if connector_id:
                    # ─── MANAGED MODE ───
                    # Resolved against the acting user and authorized against
                    # the connector's permission set before anything leaves the
                    # process. A connector belonging to someone else resolves to
                    # "not found for this user" and the node records a named
                    # refusal instead of executing.
                    from ..runtime.connector_nodes import invoke_api_connector

                    result = invoke_api_connector(
                        live_config,
                        user_id=node_config.get("_runtime_user_id"),
                        node_id=node_id,
                    )
                elif auth_connector_id_of(live_config):
                    # ─── AD-HOC, CREDENTIALS BY REFERENCE ───
                    # The node owns the request; a stored connector owns the
                    # credentials, and they are only ever sent to the host that
                    # connector was registered for. Nothing secret is held in the
                    # workflow definition.
                    result = invoke_adhoc_api_with_borrowed_auth(
                        live_config,
                        user_id=node_config.get("_runtime_user_id"),
                        node_id=node_id,
                    )
                else:
                    # ─── AD-HOC MODE ───
                    # Build an ephemeral HTTPConnector from inline config.
                    from echolib.Get_connector.Get_API.connectors.factory import ConnectorFactory
                    from echolib.Get_connector.Get_API.models.config import ConnectorConfig

                    auth_config = (
                        live_config.get("auth_config")
                        or live_config.get("authentication")
                        or live_config.get("auth")
                        or {"type": "none"}
                    )
                    # If authentication is a simple string (e.g. "bearer"), normalize it
                    if isinstance(auth_config, str):
                        auth_config = {"type": auth_config}

                    # Normalize type=None to type="none"
                    if isinstance(auth_config, dict):
                        auth_type = auth_config.get("type")
                        if auth_type is None or (isinstance(auth_type, str) and auth_type.lower() == "none"):
                            auth_config = {"type": "none"}

                    # Separate base_url from path for proper URL construction.
                    # The user may configure a full URL like
                    #   "https://api.hris.com/v1/employees/123/pto-balance"
                    # ConnectorConfig expects base_url (scheme+host) and execute()
                    # takes the endpoint path separately.
                    raw_url = live_config.get("base_url") or live_config.get("url", "")
                    endpoint = live_config.get("endpoint", "")
                    if raw_url and not endpoint:
                        # Split full URL into base (scheme+host) and path
                        from urllib.parse import urlparse
                        parsed = urlparse(raw_url)
                        base_url = f"{parsed.scheme}://{parsed.netloc}"
                        endpoint = parsed.path or "/"
                        if parsed.query:
                            endpoint += f"?{parsed.query}"
                    else:
                        base_url = raw_url

                    # ConnectorConfig may use "auth" or "auth_config" depending
                    # on the installed version of echolib — detect at runtime.
                    # The canvas renders these three as JSON textareas, so they
                    # arrive as strings. They used to be handed to
                    # ConnectorConfig and execute() unparsed, which is why an
                    # ad-hoc node with any of them set did not work.
                    _headers = as_dict(live_config.get("headers"))
                    _query_params = as_dict(
                        live_config.get("query_params")
                        or live_config.get("queryParams")
                    )
                    _body = as_dict(live_config.get("body"))

                    auth_field = "auth_config" if "auth_config" in ConnectorConfig.model_fields else "auth"
                    temp_config = ConnectorConfig(
                        name=f"adhoc_{node_id}",
                        base_url=base_url,
                        default_headers=_headers,
                        **{auth_field: auth_config},
                    )
                    connector = ConnectorFactory.create(temp_config)

                    # HTTPConnector.execute() is SYNC — call directly
                    raw_response = connector.execute(
                        method=live_config.get("method", "GET"),
                        endpoint=endpoint,
                        headers=_headers,
                        query_params=_query_params,
                        body=_body,
                    )

                    # Normalize ExecuteResponse to a plain dict for state storage
                    result = {
                        "success": raw_response.success,
                        "status_code": raw_response.status_code,
                        "data": raw_response.body,
                        "headers": dict(raw_response.headers) if raw_response.headers else {},
                        "error": raw_response.error,
                        "elapsed_seconds": raw_response.elapsed_seconds,
                    }

                # === Build full context for the next node ===
                api_data = result.get("data") if isinstance(result, dict) else result
                _api_ok = result.get("success") if isinstance(result, dict) else True
                _api_error = result.get("error") if isinstance(result, dict) else None

                # A refused managed call never left the process, so it carries a
                # reason and no data. Surfacing that reason as the node's text
                # output is the difference between "this workflow may not use
                # that connector" and an empty result the next node treats as a
                # legitimate answer.
                if not _api_ok and api_data is None and _api_error:
                    api_data = {"success": False, "error": _api_error, "node": node_id}

                # ─── Map API response fields into workflow state ───
                # Namespace API result under node ID to prevent parallel collision.
                # When 2+ API nodes run in parallel, overlapping response keys
                # (like "status", "data", "id") would overwrite each other if
                # promoted directly into global state.
                state_updates: Dict[str, Any] = {}

                # Namespaced storage: safe for parallel execution
                node_key = f"api_result_{node_id}"
                state_updates[node_key] = api_data

                # Also promote fields into global state for backward compatibility
                # (single API node workflows rely on direct field access).
                if isinstance(api_data, dict):
                    state_updates.update(api_data)
                elif isinstance(api_data, str):
                    try:
                        parsed_data = json.loads(api_data)
                        if isinstance(parsed_data, dict):
                            state_updates.update(parsed_data)
                    except (json.JSONDecodeError, TypeError):
                        pass

                # === TRANSPARENCY: Step completed ===
                if settings.transparency_enabled:
                    output_summary = {
                        "node_name": node_name,
                        "success": result.get("success") if isinstance(result, dict) else True,
                        "status_code": result.get("status_code") if isinstance(result, dict) else None,
                        "data_preview": str(api_data)[:500] if api_data else "",
                    }
                    step_tracker.complete_step(run_id, step_id, output_summary)
                    publish_step_completed_sync(run_id, step_id, output_summary)

                # Data integrity logging for API node output
                _api_success = result.get("success") if isinstance(result, dict) else True
                logger.info(
                    f"[DATA_INTEGRITY] API node '{node_name}' output: "
                    f"success={_api_success}, data_size={len(str(api_data))} chars"
                )

                state_updates.update({
                    "last_node_output": api_data,
                    "api_result": result,
                    # Avoid json.dumps(None) → 'null' which is truthy and
                    # poisons the End node's or-chain fallback logic.
                    "crew_result": (
                        json.dumps(api_data)
                        if api_data is not None and not isinstance(api_data, str)
                        else (api_data or "")
                    ),
                    # Accumulate output for parallel merge aggregation.
                    # For sequential workflows this list stays empty because
                    # downstream nodes never read it unless a merge node exists.
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        api_data,
                        node_type=TYPE_API,
                        node_name=node_name,
                        seq=seq,
                        success=bool(_api_ok),
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "api",
                        "name": node_name,
                        "mode": "managed" if connector_id else "ad-hoc",
                        "success": _api_ok,
                        "status_code": result.get("status_code") if isinstance(result, dict) else None,
                        "data": api_data,
                    }],
                })
                return state_updates

            except Exception as e:
                logger.error(f"API node '{node_name}' failed: {e}")
                if settings.transparency_enabled:
                    step_tracker.fail_step(run_id, step_id, str(e))
                    publish_step_failed_sync(run_id, step_id, str(e))

                error_result = {"success": False, "error": str(e), "node": node_id}
                return {
                    "last_node_output": error_result,
                    "api_result": error_result,
                    f"api_result_{node_id}": error_result,
                    "crew_result": f"API Error in {node_name}: {e}",
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        error_result,
                        node_type=TYPE_API,
                        node_name=node_name,
                        seq=seq,
                        success=False,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "api",
                        "name": node_name,
                        "error": str(e),
                    }],
                }

        return api_node

    def _create_mcp_node(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        seq: int = 0,
    ):
        """
        Create an MCP (Model Context Protocol) node function for LangGraph.

        Supports two modes:
        - Managed Mode: References a stored MCP connector via connector_id and
          invokes it through ``apps/connector/middleware`` -- user-scoped, and
          authorized by *tool name* rather than merely by operation, because
          ``call_tool`` alone says nothing about which tool is being called.
        - Ad-hoc Mode: Uses inline config to create an ephemeral
          HTTPMCPConnector, or a STDIO session for command-based servers. No
          stored connector owns an ad-hoc call, so no permission model applies.

        IMPORTANT: MCPConnector.invoke_async() is ASYNC — await it directly.
        No thread wrapping needed.

        The FULL response data is stored in state['last_node_output'] and
        state['mcp_result'] so the next node receives complete context.

        Args:
            node_id: Unique node identifier.
            node_config: Node configuration dict. May contain:
                - connector_id (str): For Managed Mode
                - tool_name / toolName (str): MCP tool to call (Managed Mode)
                - arguments (dict): Tool arguments (Managed Mode)
                - resource_uri (str): Read a resource instead of calling a tool
                - access_level / allowed_operations: Narrow the node's grant
                - endpoint_url (str): For Ad-hoc Mode
                - method (str): HTTP method (default POST)
                - name, description, auth_config, input_schema, output_schema
                - headers, query_params, payload
            seq: Compile-order position, carried on the accumulator entry so a
                fan-in orders branches by graph position rather than by name.

        Returns:
            Async callable node function compatible with LangGraph StateGraph.
        """
        config = node_config.get("config", node_config)
        # Fallback: resolve config from metadata for pre-fix workflows
        if (
            not config.get("endpoint_url")
            and not config.get("connector_id")
            and not config.get("connectorId")
            and not config.get("serverName")
        ):
            config = node_config.get("metadata", {}).get("mcp_config", config)
        node_name = node_config.get("name", node_id)

        def _interpolate_template(template: str, state: Dict[str, Any]) -> str:
            """Replace {variable} and {{variable}} placeholders with values from state."""
            import re
            def _replacer(m):
                # group(1) captures from {{var}}, group(2) from {var}
                key = m.group(1) or m.group(2)
                val = state.get(key)
                if val is not None:
                    return str(val)
                return m.group(0)
            # Match both {{var}} (double-brace) and {var} (single-brace).
            # Double-brace is tried first so it is consumed as a whole unit;
            # single-brace serves as fallback for templates that use only one.
            return re.sub(r"\{\{(\w+)\}\}|\{(\w+)\}", _replacer, template)

        def _interpolate_dict(d: Any, state: Dict[str, Any]) -> Any:
            """Recursively interpolate {variable}/{{variable}} placeholders in dicts/lists/strings."""
            if isinstance(d, str):
                return _interpolate_template(d, state)
            if isinstance(d, dict):
                return {k: _interpolate_dict(v, state) for k, v in d.items()}
            if isinstance(d, list):
                return [_interpolate_dict(item, state) for item in d]
            return d

        def mcp_node(state: Dict[str, Any]) -> Dict[str, Any]:
            import asyncio
            from echolib.config import settings
            from echolib.utils import new_id
            from ..runtime.async_util import run_coro_blocking

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # ─── Interpolate template variables from state ───
            live_config = _interpolate_dict(config, state)

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync,
                    publish_step_failed_sync
                )
                input_summary = {
                    "node_name": node_name,
                    "node_type": "MCP",
                    "mode": "managed" if live_config.get("connector_id") else "ad-hoc",
                }
                step_tracker.start_step(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)
                publish_step_started_sync(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)

            try:
                from ..runtime.connector_nodes import (
                    as_dict,
                    auth_connector_id_of,
                    connector_id_of,
                    invoke_adhoc_api_with_borrowed_auth,
                )

                # Reads both spellings. The canvas writes ``connectorId``;
                # reading only ``connector_id`` here was half of why choosing a
                # stored connector never took effect -- the other half was
                # ``node_mapper`` dropping the key on save.
                connector_id = connector_id_of(live_config)

                if connector_id:
                    # ─── MANAGED MODE ───
                    # Resolved against the acting user and authorized by tool
                    # name before the call leaves the process. A connector this
                    # user does not own resolves to "not found for this user"
                    # and the node records a named refusal.
                    from ..runtime.connector_nodes import invoke_mcp_connector

                    result = invoke_mcp_connector(
                        live_config,
                        user_id=node_config.get("_runtime_user_id"),
                        node_id=node_id,
                    )
                else:
                    # ─── AD-HOC MODE ───
                    # Detect transport: STDIO (Azure MCP / command-based) vs HTTP
                    raw_command = live_config.get("command", "")
                    transport_type = live_config.get("transport_type", "http")

                    if raw_command or transport_type == "stdio":
                        # ─── STDIO MODE (Azure MCP Server via mcp Python library) ───
                        import os as _os
                        import sys as _sys
                        from mcp import ClientSession, StdioServerParameters
                        from mcp.client.stdio import stdio_client

                        # NOTE: a Proactor loop (needed on Windows for subprocess
                        # STDIO) is applied per-call inside run_coro_blocking, so we
                        # do NOT mutate the global event-loop policy here (which would
                        # race across parallel nodes).

                        # Parse "npx -y @azure/mcp@latest server start" → command + args list
                        parts = raw_command.strip().split() if raw_command.strip() else ["npx", "-y", "@azure/mcp@latest", "server", "start"]
                        cmd = parts[0]
                        cmd_args = parts[1:] if len(parts) > 1 else []

                        tool_name = live_config.get("toolName") or live_config.get("tool_name", "")
                        tool_arguments = live_config.get("arguments") or live_config.get("payload") or {}

                        server_params = StdioServerParameters(
                            command=cmd,
                            args=cmd_args,
                            env=_os.environ.copy()
                        )

                        async def _run_stdio_mcp():
                            async with stdio_client(server_params) as (read, write):
                                async with ClientSession(read, write) as session:
                                    await session.initialize()

                                    # Always discover available tools first
                                    tools_response = await session.list_tools()
                                    available_tools = [t.name for t in tools_response.tools] if tools_response.tools else []

                                    _tool_name = tool_name
                                    if not _tool_name:
                                        # Auto-select first available tool
                                        if available_tools:
                                            _tool_name = available_tools[0]
                                        else:
                                            return {
                                                "success": False,
                                                "output": "MCP server returned no tools. Check az login and server startup.",
                                                "tool_name": "",
                                                "available_tools": [],
                                                "metadata": {"transport": "stdio", "command": raw_command}
                                            }
                                    elif _tool_name not in available_tools:
                                        # Specified tool not found — report available tools
                                        tools_list = "\n".join(f"  - {t}" for t in available_tools) if available_tools else "  (none)"
                                        return {
                                            "success": False,
                                            "output": (
                                                f"Tool '{_tool_name}' not found in MCP server.\n"
                                                f"Available tools:\n{tools_list}"
                                            ),
                                            "tool_name": _tool_name,
                                            "available_tools": available_tools,
                                            "metadata": {"transport": "stdio", "command": raw_command}
                                        }

                                    call_result = await session.call_tool(_tool_name, tool_arguments)

                                    # Extract text content from MCP result
                                    output_text = ""
                                    if call_result.content:
                                        output_text = "\n".join(
                                            item.text for item in call_result.content
                                            if hasattr(item, "text") and item.text
                                        )
                                    is_error = getattr(call_result, "isError", False)
                                    return {
                                        "success": not is_error,
                                        "output": output_text,
                                        "tool_name": _tool_name,
                                        "available_tools": available_tools,
                                        "metadata": {"transport": "stdio", "command": raw_command}
                                    }

                        try:
                            result = run_coro_blocking(_run_stdio_mcp, windows_proactor=True)
                        except BaseException as _eg:
                            # Unwrap anyio ExceptionGroup to surface the real error
                            subs = getattr(_eg, "exceptions", None)
                            if subs:
                                real_msgs = "; ".join(
                                    f"{type(e).__name__}: {e}" for e in subs
                                )
                                logger.error(
                                    f"MCP STDIO sub-exceptions: {real_msgs}",
                                    exc_info=_eg
                                )
                                raise RuntimeError(
                                    f"MCP STDIO failed — {real_msgs}"
                                ) from _eg
                            raise

                    else:
                        # ─── HTTP MODE (existing path — unchanged) ───
                        from echolib.Get_connector.Get_MCP.http_script import HTTPMCPConnector

                        adhoc_config = {
                            "name": live_config.get("name", f"adhoc_mcp_{node_id}"),
                            "description": live_config.get("description", f"Ad-hoc MCP call from node {node_id}"),
                            "auth_config": live_config.get("auth_config") or live_config.get("authentication") or {"type": "none"},
                            "input_schema": live_config.get("input_schema", {}),
                            "output_schema": live_config.get("output_schema", {}),
                            "endpoint_url": live_config.get("endpoint_url") or live_config.get("url", ""),
                            "method": live_config.get("method", "POST"),
                            "headers": live_config.get("headers"),
                            "query_params": live_config.get("query_params"),
                            "timeout": live_config.get("timeout", 30),
                        }
                        connector = HTTPMCPConnector(**adhoc_config)

                        # HTTPMCPConnector.test() is ASYNC — isolated, parallel-safe loop
                        payload = live_config.get("payload", {})
                        result = run_coro_blocking(lambda: connector.test(payload=payload))

                # === Build full context for the next node ===
                mcp_data = result.get("output") if isinstance(result, dict) else result
                _mcp_ok = result.get("success") if isinstance(result, dict) else True
                _mcp_error = result.get("error") if isinstance(result, dict) else None

                # A refused managed call never reached the server, so it carries
                # a reason and no output. Surfacing the reason is the difference
                # between "this workflow may not call that tool" and an empty
                # result the next node treats as a legitimate answer.
                if not _mcp_ok and mcp_data is None and _mcp_error:
                    mcp_data = {"success": False, "error": _mcp_error, "node": node_id}

                # ─── Map MCP response fields into workflow state ───
                state_updates: Dict[str, Any] = {}
                if isinstance(mcp_data, dict):
                    state_updates.update(mcp_data)
                elif isinstance(mcp_data, str):
                    try:
                        parsed_data = json.loads(mcp_data)
                        if isinstance(parsed_data, dict):
                            state_updates.update(parsed_data)
                    except (json.JSONDecodeError, TypeError):
                        pass

                # === TRANSPARENCY: Step completed ===
                if settings.transparency_enabled:
                    output_summary = {
                        "node_name": node_name,
                        "success": result.get("success") if isinstance(result, dict) else True,
                        "data_preview": str(mcp_data)[:500] if mcp_data else "",
                    }
                    step_tracker.complete_step(run_id, step_id, output_summary)
                    publish_step_completed_sync(run_id, step_id, output_summary)

                # Data integrity logging for MCP node output
                _mcp_success = result.get("success") if isinstance(result, dict) else True
                logger.info(
                    f"[DATA_INTEGRITY] MCP node '{node_name}' output: "
                    f"success={_mcp_success}, data_size={len(str(mcp_data))} chars"
                )

                state_updates.update({
                    "last_node_output": mcp_data,
                    "mcp_result": result,
                    "crew_result": (
                        json.dumps(mcp_data)
                        if mcp_data is not None and not isinstance(mcp_data, str)
                        else (mcp_data or "")
                    ),
                    # Accumulate output for parallel merge aggregation
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        mcp_data,
                        node_type=TYPE_MCP,
                        node_name=node_name,
                        seq=seq,
                        success=bool(_mcp_ok),
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "mcp",
                        "name": node_name,
                        "mode": "managed" if connector_id else "ad-hoc",
                        "success": result.get("success") if isinstance(result, dict) else True,
                        "data": mcp_data,
                    }],
                })
                return state_updates

            except Exception as e:
                logger.error(f"MCP node '{node_name}' failed: {e}")
                if settings.transparency_enabled:
                    step_tracker.fail_step(run_id, step_id, str(e))
                    publish_step_failed_sync(run_id, step_id, str(e))

                error_result = {"success": False, "error": str(e), "node": node_id}
                return {
                    "last_node_output": error_result,
                    "mcp_result": error_result,
                    "crew_result": f"MCP Error in {node_name}: {e}",
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        error_result,
                        node_type=TYPE_MCP,
                        node_name=node_name,
                        seq=seq,
                        success=False,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "mcp",
                        "name": node_name,
                        "error": str(e),
                    }],
                }

        return mcp_node

    def _create_code_node(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        seq: int = 0,
    ):
        """
        Create a Code execution node for LangGraph.

        Executes user-provided Python code in a sandboxed environment.
        The code has access to:
        - All current state variables (read-only injection)
        - A captured `result` variable for output
        - Standard library modules only (no arbitrary imports unless in packages list)

        stdout output and the `result` variable are captured and passed to the
        next node via state['last_node_output'] and state['code_result'].

        Args:
            node_id: Unique node identifier.
            node_config: Node configuration dict. May contain:
                - code (str): Python source code to execute
                - language (str): Programming language (currently only "python")
                - packages (list): Optional list of allowed packages

        Returns:
            Async callable node function compatible with LangGraph StateGraph.
        """
        config = node_config.get("config", node_config)
        # Fallback: resolve config from metadata for pre-fix workflows
        if not config.get("code"):
            config = node_config.get("metadata", {}).get("code_config", config)
        node_name = node_config.get("name", node_id)

        def code_node(state: Dict[str, Any]) -> Dict[str, Any]:
            from echolib.config import settings
            from echolib.utils import new_id

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync,
                    publish_step_failed_sync
                )
                input_summary = {
                    "node_name": node_name,
                    "node_type": "Code",
                    "language": config.get("language", "python"),
                }
                step_tracker.start_step(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)
                publish_step_started_sync(run_id, step_id, node_name, StepType.TOOL_CALL, input_summary)

            try:
                code = config.get("code", "")
                language = config.get("language", "python")

                from ..runtime.code_executor import CodeExecutor
                code_result = CodeExecutor.execute(code, language, state)

                code_output = code_result["output"]
                stdout_output = code_result.get("stdout", "")

                if not code_result["success"]:
                    raise RuntimeError(code_result.get("error", "Code execution failed"))

                # === TRANSPARENCY: Step completed ===
                if settings.transparency_enabled:
                    output_summary = {
                        "node_name": node_name,
                        "success": True,
                        "stdout_preview": stdout_output[:500] if stdout_output else "",
                        "result_preview": str(code_output)[:500] if code_output else "",
                    }
                    step_tracker.complete_step(run_id, step_id, output_summary)
                    publish_step_completed_sync(run_id, step_id, output_summary)

                # Data integrity logging for Code node output
                logger.info(
                    f"[DATA_INTEGRITY] Code node '{node_name}' output: "
                    f"success=True, data_size={len(str(code_output))} chars"
                )

                # ─── Promote the code's own variables into workflow state ───
                # CodeExecutor already collects them (`variables`), filtered to
                # serializable non-callables that were not passed in. They were
                # then dropped on the floor, while API and MCP nodes promote
                # their response fields into state.
                #
                # That broke the most ordinary pattern there is: a Code node
                # computing a value and a Conditional branching on it. The
                # state schema even declares those keys -- `_create_state_class`
                # parses the identifiers out of every branch condition -- so the
                # graph was built expecting a writer that did not exist, and the
                # conditional silently took `else` every time.
                state_updates: Dict[str, Any] = {}
                code_variables = code_result.get("variables")
                if isinstance(code_variables, dict):
                    state_updates.update(code_variables)
                if isinstance(code_output, dict):
                    state_updates.update(code_output)

                return {
                    **state_updates,
                    "last_node_output": code_output,
                    "code_result": code_result,
                    "crew_result": str(code_output) if code_output else stdout_output,
                    # Accumulate output for parallel merge aggregation
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        code_output,
                        node_type=TYPE_CODE,
                        node_name=node_name,
                        seq=seq,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "code",
                        "name": node_name,
                        "success": True,
                        "output": code_output,
                        "stdout": stdout_output,
                    }],
                }

            except Exception as e:
                logger.error(f"Code node '{node_name}' failed: {e}")
                if settings.transparency_enabled:
                    step_tracker.fail_step(run_id, step_id, str(e))
                    publish_step_failed_sync(run_id, step_id, str(e))

                error_result = {"success": False, "error": str(e), "node": node_id}
                return {
                    "last_node_output": error_result,
                    "code_result": error_result,
                    "crew_result": f"Code Error in {node_name}: {e}",
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        error_result,
                        node_type=TYPE_CODE,
                        node_name=node_name,
                        seq=seq,
                        success=False,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "code",
                        "name": node_name,
                        "error": str(e),
                    }],
                }

        return code_node

    # Criteria the canvas offers as tick-boxes, in the order it renders them,
    # with the instruction each one contributes to the review prompt.
    #
    # The canvas has always written these keys -- `New Front`'s nodeCatalog and
    # the older workflow-ide inspector agree on the spelling -- and the node has
    # always read `reviewPrompt`/`minConfidence`, which nothing writes. So every
    # Self-Review node in the platform ran one hardcoded generic prompt and a
    # fixed 0.8 threshold, and the criteria the author ticked changed nothing.
    REVIEW_CRITERIA = (
        ("checkCompleteness", "Completeness: does the output cover everything "
                              "the task asked for, with nothing important left out?"),
        ("checkAccuracy", "Accuracy: is every factual claim correct and supported "
                          "by the material provided? Flag anything unverifiable."),
        ("checkTone", "Tone: is the register appropriate for the intended audience "
                      "and consistent throughout?"),
    )

    DEFAULT_REVIEW_PROMPT = "Review the output for quality and completeness."
    DEFAULT_MIN_CONFIDENCE = 0.8

    # How many times a failed review may send its subject back to be redone,
    # when the node itself states no ceiling. The canvas offers `maxIterations`
    # and has defaulted it to 3 since the node was introduced.
    DEFAULT_REVIEW_MAX_ITERATIONS = 3

    # A ceiling on the ceiling. Every retry is a full re-execution of the
    # reviewed node plus another review call, so an author who types a large
    # number is asking for an unbounded spend on a loop that has already failed
    # several times. Twenty-five is far past any legitimate use and still
    # finite.
    REVIEW_MAX_ITERATIONS_CEILING = 25

    @classmethod
    def _resolve_review_criteria(cls, config: Dict[str, Any]) -> str:
        """
        Build the review prompt from what the node's author actually configured.

        WHAT: Renders the ticked criteria as an instruction list.
        WHY:  See ``REVIEW_CRITERIA``. An explicit ``reviewPrompt`` still wins --
              it is a direct instruction and more specific than any tick-box --
              so nothing already relying on it changes.
        OUTPUT: The prompt text. Falls back to the previous hardcoded default
                when the node states no criteria at all, because an empty
                criteria list is not a meaningful thing to ask a model.
        """
        authored = config.get("reviewPrompt") or config.get("review_prompt")
        if isinstance(authored, str) and authored.strip():
            return authored.strip()

        selected = [
            text for key, text in cls.REVIEW_CRITERIA if config.get(key)
        ]
        if not selected:
            return cls.DEFAULT_REVIEW_PROMPT

        return "Assess the output against each of these criteria:\n" + "\n".join(
            f"- {text}" for text in selected
        )

    @classmethod
    def _resolve_min_confidence(cls, config: Dict[str, Any]) -> float:
        """
        The confidence floor this node's author set, honouring either spelling.

        ``confidenceThreshold`` is what both canvases write; ``minConfidence`` is
        what this node has always read. Reading only the latter meant the slider
        moved and the gate did not.
        """
        for key in ("minConfidence", "min_confidence", "confidenceThreshold",
                    "confidence_threshold"):
            value = config.get(key)
            if value is None:
                continue
            try:
                return float(value)
            except (TypeError, ValueError):
                logger.warning(
                    "Self-Review node has a non-numeric %s (%r); using %.2f",
                    key, value, cls.DEFAULT_MIN_CONFIDENCE,
                )
                break
        return cls.DEFAULT_MIN_CONFIDENCE

    @classmethod
    def _resolve_max_iterations(cls, config: Dict[str, Any]) -> int:
        """
        How many redo attempts a failed review may demand of its subject.

        ``maxIterations`` is authored on the canvas -- it has been in the
        Self-Review node's default config since the node existed -- and was read
        by nothing, because until now a failed review did nothing at all.

        Zero is a legitimate answer and means "review but never retry", which is
        exactly the node's previous behaviour. Anything unreadable falls back to
        the default rather than to an unbounded loop.
        """
        for key in ("maxIterations", "max_iterations"):
            value = config.get(key)
            if value is None:
                continue
            try:
                resolved = int(value)
            except (TypeError, ValueError):
                logger.warning(
                    "Self-Review node has a non-numeric %s (%r); using %d",
                    key, value, cls.DEFAULT_REVIEW_MAX_ITERATIONS,
                )
                break
            if resolved < 0:
                return 0
            return min(resolved, cls.REVIEW_MAX_ITERATIONS_CEILING)
        return cls.DEFAULT_REVIEW_MAX_ITERATIONS

    def _create_self_review_node(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        preceding_node_id: Optional[str] = None,
        successor_node_ids: Optional[List[str]] = None,
        seq: int = 0,
    ):
        """
        Create a Self-Review node for LangGraph.

        Uses an LLM to validate the output from the previous node against
        the configured criteria and minimum confidence threshold. The LLM acts
        as a quality gate, assessing whether the prior output meets criteria.

        The verdict is stored in ``state['review_result']``. It is deliberately
        **not** written to ``crew_result`` or ``last_node_output``: a gate does
        not replace what it is gating.

        Failing the gate
        ----------------
        A failed review routes back to the node it reviewed, which re-executes
        with the reviewer's own ``issues`` and ``feedback`` injected as
        instructions, and then returns here to be judged again. This reuses the
        HITL edit loop wholesale -- ``_review_route`` mirrors ``_hitl_route``,
        and the feedback travels on ``_edit_feedback``, the channel
        ``langchain_adapter.build_agent_task`` already reads.

        Before this, ``passed`` was computed against the threshold and
        discarded: a review that failed changed nothing, so the node was an
        expensive way to add a sentence to the trace.

        Termination is enforced here, in code, and never left to the model:

        * each review node counts its own attempts, in ``_review_attempts``;
        * at ``maxIterations`` the run proceeds forward carrying the failure,
          rather than looping again;
        * a node with nothing upstream to re-run proceeds immediately;
        * a review that could not run at all (see the except block) does **not**
          retry -- retrying a call that just failed on a timeout or a bad
          credential would spend the whole budget re-failing.

        Args:
            node_id: Unique node identifier.
            node_config: Node configuration dict. May contain:
                - checkCompleteness / checkAccuracy / checkTone (bool)
                - confidenceThreshold (float): Minimum confidence (0.0–1.0)
                - maxIterations (int): Redo attempts allowed on failure
                - reviewPrompt (str): Explicit criteria, overriding the above
                - model (dict): Optional LLM model override
            preceding_node_id: LangGraph node ID of the node under review. A
                failed review routes back to it.
            successor_node_ids: LangGraph node IDs of successor nodes, used by
                the conditional outgoing edge.
            seq: Compile-order position, carried on the accumulator entry.

        Returns:
            Callable node function compatible with LangGraph StateGraph.
        """
        config = node_config.get("config", node_config)

        # Fall back to metadata for the same reason the API node does: the
        # canvas stores this node's settings under `metadata.review_config`
        # (`node_mapper._convert_node_to_agent`) and only Code, API and MCP get
        # their config copied to the top level. So `config` here was either an
        # empty dict or the whole agent definition -- neither of which holds a
        # criterion -- and the settings could not have been read even once the
        # node started looking for them.
        if not any(
            key in config
            for key, _ in (*self.REVIEW_CRITERIA,
                           ("reviewPrompt", None), ("confidenceThreshold", None),
                           ("minConfidence", None), ("maxIterations", None))
        ):
            config = node_config.get("metadata", {}).get("review_config", config)

        node_name = node_config.get("name", node_id)

        # Snapshot for the retry loop's routing decision.
        _preceding_node_id = preceding_node_id
        _successor_node_ids = list(successor_node_ids or [])
        _forward_target = _successor_node_ids[0] if _successor_node_ids else "__end__"

        def self_review_node(state: Dict[str, Any]) -> Dict[str, Any]:
            # Synchronous, like every other node in this compiler.
            #
            # This was ``async def``, and the executor invokes the compiled
            # graph with ``compiled_graph.invoke()`` -- the sync API. LangGraph
            # then raises ``TypeError: No synchronous function provided``, and
            # with OTel tracing on (the default) ``_wrap_node_with_tracing``
            # wrapped it in a sync function that returned the coroutine
            # unawaited, producing ``InvalidUpdateError: Expected dict, got
            # <coroutine>``. Either way, **any workflow containing a
            # Self-Review node failed at runtime.**
            #
            # Nothing here needs a loop: ``_execute_llm_call`` is synchronous,
            # and LangGraph already runs sync nodes in a thread pool, so the
            # ``asyncio.to_thread`` hop this used to make bought nothing.
            from echolib.config import settings
            from echolib.utils import new_id

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync,
                    publish_step_failed_sync
                )
                input_summary = {
                    "node_name": node_name,
                    "node_type": "Self-Review",
                    "min_confidence": self._resolve_min_confidence(config),
                }
                step_tracker.start_step(run_id, step_id, node_name, StepType.LLM_CALL, input_summary)
                publish_step_started_sync(run_id, step_id, node_name, StepType.LLM_CALL, input_summary)

            try:
                # Composed from the criteria the author ticked, at the threshold
                # they set. Both were previously unreachable; see
                # ``_resolve_review_criteria``.
                review_prompt = self._resolve_review_criteria(config)
                min_confidence = self._resolve_min_confidence(config)
                max_iterations = self._resolve_max_iterations(config)
                # Read from both schemas for self-review node
                _sr_settings = config.get("settings", config)
                # ``max_tokens`` is carried only when the node states one.
                # It used to fall back to a literal 1000 -- the lowest output
                # ceiling anywhere in the platform -- so a Self-Review verdict
                # was truncated at a limit no operator set and no setting could
                # raise. Absent, ``_execute_llm_call`` lets the resolver apply
                # the credential's registered ceiling and then a provider-aware
                # floor, the same chain every agent uses.
                _sr_max_tokens = _sr_settings.get("max_token") or config.get("maxTokens")
                llm_config = {
                    "provider": _sr_settings.get("provider") or config.get("provider") or "",
                    "model": config.get("model") if isinstance(config.get("model"), str) else (config.get("model", {}).get("modelName") or ""),
                    "temperature": float(_sr_settings.get("temperature") or config.get("temperature") or 0.2),
                    "max_tokens": int(_sr_max_tokens) if _sr_max_tokens else None,
                    "top_p": float(_sr_settings.get("top_p") or config.get("topP") or 0.9),
                }

                # Gather the output from the previous node to review
                previous_output = (
                    state.get("last_node_output")
                    or state.get("crew_result")
                    or ""
                )
                previous_output_str = (
                    json.dumps(previous_output, default=str)
                    if not isinstance(previous_output, str)
                    else previous_output
                )

                # Build the LLM prompt for self-review
                llm_prompt = f"""You are a quality assurance reviewer. Evaluate the following output against the review criteria.

REVIEW CRITERIA:
{review_prompt}

OUTPUT TO REVIEW:
{previous_output_str[:4000]}

Respond in the following JSON format ONLY (no other text):
{{
  "passed": true or false,
  "confidence": 0.0 to 1.0,
  "feedback": "Brief explanation of your assessment",
  "issues": ["list of specific issues found, if any"]
}}"""

                # _execute_llm_call is synchronous; LangGraph runs this node in
                # its own thread, so calling it directly blocks nothing.
                _sr_user_id = node_config.get("_runtime_user_id")
                _sr_credential_id = node_config.get("credential_id")
                llm_response = self._execute_llm_call(
                    llm_config, llm_prompt, _sr_user_id, _sr_credential_id
                )

                # Parse the LLM response
                try:
                    # Try to extract JSON from the response
                    review_data = json.loads(llm_response)
                except json.JSONDecodeError:
                    # If JSON parsing fails, treat as a textual review
                    review_data = {
                        "passed": True,
                        "confidence": 0.7,
                        "feedback": llm_response,
                        "issues": [],
                    }

                # Apply the confidence threshold
                confidence = review_data.get("confidence", 0.0)
                passed = review_data.get("passed", False) and confidence >= min_confidence

                review_result = {
                    "success": True,
                    "passed": passed,
                    "confidence": confidence,
                    "min_confidence": min_confidence,
                    "feedback": review_data.get("feedback", ""),
                    "issues": review_data.get("issues", []),
                }

                # ─── Route: pass forward, or send it back to be redone ───
                #
                # Attempts already spent by THIS review node on THIS run. Keyed
                # by node so two reviewers in one workflow hold separate
                # budgets, and so a re-entry increments rather than resets.
                attempts = dict(state.get("_review_attempts") or {})
                spent = int(attempts.get(node_id, 0) or 0)

                retry = (
                    not passed
                    and max_iterations > 0
                    and spent < max_iterations
                    and bool(_preceding_node_id)
                )

                # Cleared on every pass through, so feedback from a previous
                # round cannot survive into a re-run that did not earn it.
                routing: Dict[str, Any] = {"_edit_feedback": None}

                if retry:
                    attempts[node_id] = spent + 1
                    routing["_review_attempts"] = attempts
                    routing["_review_route"] = _preceding_node_id
                    routing["_edit_feedback"] = _render_review_feedback(
                        review_data, attempt=spent + 1, of=max_iterations
                    )
                    review_result["retrying"] = True
                    review_result["attempt"] = spent + 1
                    review_result["max_iterations"] = max_iterations
                    logger.info(
                        "[REVIEW-ROUTE] '%s' failed (confidence %.2f < %.2f); "
                        "sending '%s' back to be redone (attempt %d of %d)",
                        node_name, float(confidence or 0.0), float(min_confidence),
                        _preceding_node_id, spent + 1, max_iterations,
                    )
                else:
                    routing["_review_route"] = _forward_target
                    if not passed:
                        # Proceeding with a known-failed output. Which of the
                        # three reasons applies decides what the trace says, and
                        # they are genuinely different situations: a spent
                        # budget is a quality problem, no upstream node is a
                        # mis-wired canvas, and a zero ceiling is a deliberate
                        # choice to observe without intervening.
                        if not _preceding_node_id:
                            reason = "no preceding node to re-run"
                            logger.warning(
                                "[REVIEW-ROUTE] '%s' failed but has nothing "
                                "upstream to send back; continuing forward.",
                                node_name,
                            )
                        elif max_iterations <= 0:
                            reason = "retries disabled for this node"
                            logger.info(
                                "[REVIEW-ROUTE] '%s' failed; retries are "
                                "disabled (maxIterations=0), continuing forward.",
                                node_name,
                            )
                        else:
                            reason = "retry budget exhausted"
                            logger.warning(
                                "[REVIEW-ROUTE] '%s' still failing after %d "
                                "attempt(s); continuing forward with the "
                                "output as it stands.",
                                node_name, spent,
                            )
                        review_result["retrying"] = False
                        review_result["proceeded_despite_failure"] = reason
                        review_result["attempt"] = spent
                        review_result["max_iterations"] = max_iterations

                # === TRANSPARENCY: Step completed ===
                if settings.transparency_enabled:
                    output_summary = {
                        "node_name": node_name,
                        "passed": passed,
                        "confidence": confidence,
                        "feedback_preview": review_data.get("feedback", "")[:300],
                        "retrying": bool(review_result.get("retrying")),
                        "attempt": review_result.get("attempt", 0),
                        "max_iterations": max_iterations,
                    }
                    step_tracker.complete_step(run_id, step_id, output_summary)
                    publish_step_completed_sync(run_id, step_id, output_summary)

                return {
                    # A gate does not replace what it is gating.
                    #
                    # This used to write the verdict to BOTH `last_node_output`
                    # and `crew_result`. `crew_result` is the first entry in
                    # `event_publisher.RESPONSE_KEYS` and is what the End node
                    # collects, so the workflow's answer became the review
                    # commentary -- "Looks complete and accurate." was returned
                    # to the user in place of the report it was describing. And
                    # because `last_node_output` was overwritten too, the next
                    # node downstream received the verdict instead of the work,
                    # so a reviewed document could not be consumed by anything
                    # after the reviewer.
                    #
                    # Neither key is written now. The reviewed content stays
                    # exactly where the producing node left it; the verdict
                    # travels in `review_result` and in the accumulator entry
                    # below, which is where a fan-in already reads it from.
                    "review_result": review_result,
                    **routing,
                    # A review is a result like any other. Without this entry a
                    # Self-Review sitting on a parallel branch contributed
                    # nothing to the fan-in: its verdict reached the next
                    # sequential node through last_node_output and was lost at
                    # any merge.
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        review_result,
                        node_type=TYPE_REVIEW,
                        node_name=node_name,
                        seq=seq,
                        success=True,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "self_review",
                        "name": node_name,
                        "passed": passed,
                        "confidence": confidence,
                        "feedback": review_data.get("feedback", ""),
                        "issues": review_data.get("issues", []),
                    }],
                }

            except Exception as e:
                # A review that could not run has not passed. It used to return
                # `{"success": False}` with no `passed` key at all, so anything
                # asking "did this pass?" read `None` -- falsy by luck rather
                # than by statement. Said explicitly now.
                logger.error(
                    "Self-Review node '%s' failed: %s", node_name, e, exc_info=True
                )
                if settings.transparency_enabled:
                    step_tracker.fail_step(run_id, step_id, str(e))
                    publish_step_failed_sync(run_id, step_id, str(e))

                error_result = {
                    "success": False,
                    "passed": False,
                    "error": str(e),
                    "node": node_id,
                }
                return {
                    # Same reasoning as the success path, and it mattered more
                    # here: writing the error text to `crew_result` made a
                    # 48-character "Self-Review Error in ..." string the entire
                    # user-facing output of a run that had otherwise succeeded.
                    # The failure is reported through the failed step and the
                    # accumulator entry; it does not get to be the answer.
                    "review_result": error_result,
                    # Forward, never back. A review that could not run has
                    # judged nothing, so there is no finding to act on -- and
                    # the cause is almost always a timeout, an unreachable model
                    # or a bad credential, none of which re-running the reviewed
                    # node would change. Retrying here would spend the whole
                    # budget re-failing and turn one broken call into several.
                    "_review_route": _forward_target,
                    "_edit_feedback": None,
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        error_result,
                        node_type=TYPE_REVIEW,
                        node_name=node_name,
                        seq=seq,
                        success=False,
                    )],
                    "messages": [{
                        "node": node_id,
                        "type": "self_review",
                        "name": node_name,
                        "error": str(e),
                    }],
                }

        return self_review_node

    # =====================================================================
    # Node Type Dispatcher
    # =====================================================================

    def _create_start_node(
        self,
        node_id: str,
        node_config: Dict[str, Any]
    ):
        """
        Create a Start node function for LangGraph.

        The Start node is a PASSTHROUGH — it does NOT call an LLM.
        It reads the user's input from state, maps it to the defined
        input variables (from the canvas inputVariables config), and
        forwards everything to the next node.

        When file_upload_config is present and enabled, the Start node
        emits a HITL-style interrupt() after the passthrough logic to
        pause the graph and wait for a file upload from the user.

        Input variables (e.g., "query") are already initialized by the
        executor, but this node explicitly sets them in state and
        populates last_node_output so downstream nodes receive context.

        Args:
            node_id: Node identifier.
            node_config: Agent config dict containing input_schema from
                         the canvas Start node's inputVariables.

        Returns:
            Callable node function compatible with LangGraph.
        """
        agent_name = node_config.get("name", "Start")
        input_schema = node_config.get("input_schema", [])
        file_upload_config = node_config.get("metadata", {}).get("file_upload_config", {})

        def start_node(state: Dict[str, Any]) -> Dict[str, Any]:
            from langgraph.types import interrupt
            from echolib.config import settings
            from echolib.utils import new_id

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync
                )
                input_summary = {
                    "node_name": agent_name,
                    "node_type": "Start",
                    "input_variables": input_schema,
                }
                step_tracker.start_step(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )
                publish_step_started_sync(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )

            # === Core Logic: Passthrough with variable injection ===
            user_input = (
                state.get("original_user_input")
                or state.get("user_input")
                or state.get("task_description")
                or ""
            )

            # Map user_input to each defined input variable
            # e.g., input_schema=["query"] → {"query": user_input}
            outputs = {}
            for var_name in input_schema:
                # Use the value already in state if set (executor may have mapped it),
                # otherwise default to user_input
                outputs[var_name] = state.get(var_name) or user_input

            logger.info(
                f"Start node '{agent_name}' passed through. "
                f"Input variables: {list(outputs.keys())}, "
                f"user_input length: {len(user_input)}"
            )

            # === File Upload Interrupt ===
            document_context = ""
            document_metadata = {}

            # Inside an application the upload is a precondition checked
            # *before* the workflow starts: the Evidence Gate stops the turn and
            # asks for the document when the conversation has none. Documents
            # the user uploaded reach the agents through the application's
            # contribution (session-document tools), so pausing here would ask
            # for a file already provided -- and a paused run then waits for a
            # separate upload-resume call that an ordinary chat message never
            # makes, which is how the run got stuck.
            application_context = (state.get("_aura_exec") or {}).get(
                "application_context"
            )
            if file_upload_config.get("enabled") and isinstance(
                application_context, dict
            ) and application_context:
                documents = [
                    str(doc.get("name") or doc.get("document_id") or "")
                    for doc in (application_context.get("session_documents") or [])
                    if isinstance(doc, dict)
                ]
                document_metadata = {
                    "source": "application_session",
                    "documents": [name for name in documents if name],
                }
                logger.info(
                    "Start node '%s': file upload satisfied by the application "
                    "session (%d document(s)); not pausing",
                    agent_name, len(document_metadata["documents"]),
                )
            elif file_upload_config.get("enabled"):
                interrupt_payload = {
                    "run_id": run_id,
                    "workflow_id": state.get("workflow_id", ""),
                    "node_id": node_id,
                    "interrupt_type": "file_upload",
                    "title": file_upload_config.get("title", "Document Upload Required"),
                    "message": file_upload_config.get("message", "Please upload the required document."),
                    "accepted_types": file_upload_config.get("acceptedTypes", [".pdf", ".docx", ".txt", ".csv", ".md"]),
                    "max_size_mb": file_upload_config.get("maxSizeMb", 50),
                    "optional": file_upload_config.get("optional", False),
                    "query_prompt": file_upload_config.get("queryPrompt", ""),
                    "allowed_actions": ["upload_file", "skip"] if file_upload_config.get("optional") else ["upload_file"],
                    "node_name": agent_name,
                    "state_snapshot": {k: v for k, v in state.items() if not k.startswith("_") and k != "messages"},
                }

                human_decision = interrupt(interrupt_payload)
                action = human_decision.get("action", "")
                payload = human_decision.get("payload", {})

                if action == "upload_file":
                    document_context = payload.get("document_context", "")
                    document_metadata = payload.get("document_metadata", {})
                elif action == "skip":
                    document_context = ""
                    document_metadata = {"skipped": True}
                else:
                    document_context = ""
                    document_metadata = {}

            # === TRANSPARENCY: Step completed ===
            if settings.transparency_enabled:
                output_summary = {
                    "node_name": agent_name,
                    "node_type": "Start",
                    "variables_set": list(outputs.keys()),
                    "output_preview": user_input[:200] if user_input else "",
                }
                step_tracker.complete_step(run_id, step_id, output_summary)
                publish_step_completed_sync(run_id, step_id, output_summary)

            return {
                **outputs,
                "last_node_output": user_input,
                "crew_result": user_input,
                "document_context": document_context,
                "document_metadata": document_metadata,
                "messages": [{
                    "agent": node_id,
                    "role": "Start",
                    "node_type": "Start",
                    "inputs": {"user_input": user_input},
                    "outputs": outputs,
                }]
            }

        return start_node

    def _create_end_node(
        self,
        node_id: str,
        node_config: Dict[str, Any]
    ):
        """
        Create an End node function for LangGraph.

        The End node is a PASSTHROUGH — it does NOT call an LLM.
        It collects the final output from the previous node(s) and maps
        it to the defined output variables (from the canvas outputVariables
        config).

        It reads from crew_result / last_node_output (the accumulated result
        from the last processing node) and sets the output variables.

        Args:
            node_id: Node identifier.
            node_config: Agent config dict containing output_schema from
                         the canvas End node's outputVariables.

        Returns:
            Callable node function compatible with LangGraph.
        """
        agent_name = node_config.get("name", "End")
        output_schema = node_config.get("output_schema", [])

        def end_node(state: Dict[str, Any]) -> Dict[str, Any]:
            from echolib.config import settings
            from echolib.utils import new_id

            run_id = state.get("run_id", "unknown")
            step_id = new_id("step_")

            # === TRANSPARENCY: Step started ===
            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync, publish_step_completed_sync
                )
                input_summary = {
                    "node_name": agent_name,
                    "node_type": "End",
                    "output_variables": output_schema,
                }
                step_tracker.start_step(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )
                publish_step_started_sync(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )

            # === Core Logic: Collect final output ===
            # Prefer _last_agent_output (set only by LLM agent nodes, never by API/MCP/Code).
            # This prevents raw HTTP responses or code output from polluting output variables.
            # Fall back to crew_result only if no agent has run yet.
            #
            # NOTE: json.dumps(None) produces the string 'null', which is truthy
            # in Python and would short-circuit the or-chain.  We filter out
            # serialized-None values ('null', 'None') so the chain falls through
            # to a real result (e.g. api_result dict).
            _sentinel_strings = {'null', 'None', ''}

            def _meaningful(val):
                """Return val only if it carries real content."""
                if val is None:
                    return None
                if isinstance(val, str) and val.strip() in _sentinel_strings:
                    return None
                return val

            # Check for namespaced API results from parallel API nodes.
            # These are stored as api_result_<node_id> keys by _create_api_node.
            _namespaced_api_results = {
                k: v for k, v in state.items()
                if k.startswith("api_result_")
            }
            _combined_api_output = None
            if _namespaced_api_results:
                import json as _json_mod
                _combined_api_output = _json_mod.dumps(
                    _namespaced_api_results, indent=2, default=str
                )

            final_output = ""
            selected_source = "default_empty"
            candidate_sources = (
                ("_last_agent_output", _meaningful(state.get("_last_agent_output"))),
                ("crew_result", _meaningful(state.get("crew_result"))),
                ("last_node_output", _meaningful(state.get("last_node_output"))),
                ("review_result", _meaningful(state.get("review_result"))),
                ("code_result", _meaningful(state.get("code_result"))),
                ("combined_api_output", _meaningful(_combined_api_output)),
                ("api_result", _meaningful(state.get("api_result"))),
                ("mcp_result", _meaningful(state.get("mcp_result"))),
            )

            for source_name, source_value in candidate_sources:
                if source_value is not None:
                    final_output = source_value
                    selected_source = source_name
                    break

            # If final_output is a dict, convert to human-readable markdown
            # instead of raw JSON so the UI never displays unformatted JSON.
            if isinstance(final_output, dict):
                from apps.workflow.runtime.response_formatter import _json_to_markdown
                final_output_str = _json_to_markdown(final_output)
            else:
                final_output_str = str(final_output) if final_output else ""

            # Extraction of output variables from state and agent output
            # AURA2Echo is LangChain-exclusive
            # Priority: (1) values already in state, (2) full agent output as fallback
            extracted_vars: Dict[str, Any] = {}

            # Map to defined output variables
            # Priority: (1) intelligently extracted value, (2) value explicitly set in state
            # by a prior node, (3) full agent output text as fallback.
            outputs = {}
            for var_name in output_schema:
                if var_name in extracted_vars:
                    outputs[var_name] = extracted_vars[var_name]
                else:
                    existing = state.get(var_name)
                    if existing not in (None, ""):
                        outputs[var_name] = existing
                    else:
                        outputs[var_name] = final_output_str

            logger.info(
                f"End node '{agent_name}' collected output. "
                f"source={selected_source}, "
                f"Output variables: {list(outputs.keys())}, "
                f"output length: {len(final_output_str)}"
            )
            if not final_output_str.strip():
                candidate_lengths = {
                    k: len(str(v)) if v is not None else 0
                    for k, v in candidate_sources
                }
                logger.warning(
                    "End node '%s' produced empty final output. "
                    "source=%s, candidate_lengths=%s",
                    agent_name,
                    selected_source,
                    candidate_lengths,
                )

            # === TRANSPARENCY: Step completed ===
            if settings.transparency_enabled:
                output_summary = {
                    "node_name": agent_name,
                    "node_type": "End",
                    "variables_collected": list(outputs.keys()),
                    "output_preview": final_output_str[:500] if final_output_str else "",
                }
                step_tracker.complete_step(run_id, step_id, output_summary)
                publish_step_completed_sync(run_id, step_id, output_summary)

            return {
                **outputs,
                "crew_result": final_output_str,
                "last_node_output": final_output_str,
                "messages": [{
                    "agent": node_id,
                    "role": "End",
                    "node_type": "End",
                    "inputs": {"final_output": final_output_str[:200]},
                    "outputs": outputs,
                }]
            }

        return end_node

    # ========================================================================
    # HITL NODE SUPPORT (Additive — does NOT modify existing methods)
    # ========================================================================

    # Shared MemorySaver instances for HITL workflows.
    # Key = workflow_id, Value = MemorySaver instance.
    # This ensures the same checkpointer survives across compile calls
    # (initial execution + resume), so LangGraph can restore state.
    _hitl_checkpointers: Dict[str, Any] = {}

    def _get_checkpointer(self, workflow: Dict[str, Any]):
        """
        Return the appropriate checkpointer for this workflow.

        - Workflows with HITL nodes -> PostgresSaver (persistent) or shared MemorySaver
        - All other workflows -> new MemorySaver() (existing behavior, unchanged)

        For HITL workflows, the checkpointer MUST be the same instance across
        the initial execution and resume calls. Otherwise the checkpoint
        (graph state at the interrupt point) is lost and resume re-executes
        from scratch.

        Args:
            workflow: Workflow definition dict.

        Returns:
            A LangGraph checkpointer instance.
        """
        from langgraph.checkpoint.memory import MemorySaver

        # Check if workflow has any HITL nodes
        has_hitl = False
        for agent in workflow.get("agents", []):
            if isinstance(agent, dict):
                node_type = agent.get("metadata", {}).get("node_type", "")
                if node_type == "HITL":
                    has_hitl = True
                    break

        if not has_hitl:
            return MemorySaver()  # Existing behavior preserved

        workflow_id = workflow.get("workflow_id", "unknown")

        # HITL workflow -> try PostgresSaver first (persistent across restarts)
        # Cache the PostgresSaver instance so the same connection is reused
        try:
            if "_postgres_checkpointer" not in self._hitl_checkpointers:
                from apps.workflow.runtime.checkpointer import get_postgres_checkpointer
                self._hitl_checkpointers["_postgres_checkpointer"] = get_postgres_checkpointer()
                logger.info("Using PostgresSaver checkpointer for HITL-enabled workflow")
            else:
                logger.info("Reusing cached PostgresSaver checkpointer")
            return self._hitl_checkpointers["_postgres_checkpointer"]
        except Exception as e:
            logger.warning(
                f"PostgresSaver unavailable ({e}), using shared MemorySaver "
                f"for workflow '{workflow_id}'."
            )
            # Shared MemorySaver — same instance for this workflow_id
            if workflow_id not in self._hitl_checkpointers:
                self._hitl_checkpointers[workflow_id] = MemorySaver()
                logger.info(f"Created shared MemorySaver for HITL workflow '{workflow_id}'")
            else:
                logger.info(f"Reusing shared MemorySaver for HITL workflow '{workflow_id}'")
            return self._hitl_checkpointers[workflow_id]

    def _wire_hitl_conditional_edge(
        self,
        graph,
        hitl_node_id: str,
        preceding_node_id: Optional[str],
        successor_node_ids: List[str],
    ) -> None:
        """
        Wire a conditional outgoing edge for a HITL node.

        Instead of a static edge (HITL -> next_node), this creates a
        conditional edge that reads ``_hitl_route`` from state:
        - If ``_hitl_route`` matches the preceding agent, route BACK to it
          (edit-loop re-execution).
        - Otherwise, route FORWARD to the normal successor or END.

        This is necessary because LangGraph static edges are NOT overridden
        by ``Command(goto=...)``. Both destinations fire when a node has
        a static edge AND returns a Command.  Conditional edges avoid this
        by making the outgoing path entirely dynamic.

        Args:
            graph: LangGraph StateGraph being built.
            hitl_node_id: The HITL node's LangGraph ID.
            preceding_node_id: The preceding agent node's LangGraph ID.
            successor_node_ids: The successor node(s) after the HITL node.
        """
        from langgraph.graph import END

        # Build the set of valid routing targets
        valid_targets = set()
        if preceding_node_id:
            valid_targets.add(preceding_node_id)
        for sid in successor_node_ids:
            valid_targets.add(sid)

        # Snapshot for closure
        _preceding = preceding_node_id
        _successors = list(successor_node_ids)
        _default_target = _successors[0] if _successors else None

        def hitl_routing_function(state: Dict[str, Any]) -> str:
            """Route based on _hitl_route set by the HITL node function."""
            route = state.get("_hitl_route", "")

            if route and route in valid_targets:
                logger.info(
                    f"[HITL-ROUTE] {hitl_node_id} -> {route}"
                )
                return route

            if route == "__end__":
                logger.info(
                    f"[HITL-ROUTE] {hitl_node_id} -> END (sentinel)"
                )
                return END

            # Default: forward to first successor or END
            if _default_target:
                logger.info(
                    f"[HITL-ROUTE] {hitl_node_id} -> {_default_target} (default)"
                )
                return _default_target

            logger.info(
                f"[HITL-ROUTE] {hitl_node_id} -> END (no successor)"
            )
            return END

        # Build path_map for add_conditional_edges
        path_map: Dict[str, str] = {}
        for t in valid_targets:
            path_map[t] = t
        path_map[END] = END
        # Also map the __end__ sentinel string to END
        path_map["__end__"] = END

        graph.add_conditional_edges(
            hitl_node_id,
            hitl_routing_function,
            path_map,
        )

        logger.info(
            f"Wired HITL conditional edge: {hitl_node_id} -> "
            f"targets={list(valid_targets)} + END "
            f"(preceding={preceding_node_id})"
        )

    @staticmethod
    def _extract_preceding_output(state: dict) -> str:
        """Extract the most recent agent output from state for HITL review.

        Checks the keys an agent node uses to store results, in priority
        order. Falls back to the last message content if none of the dedicated
        keys are populated.
        """
        for key in (
            "crew_result",
            "result",
            "hierarchical_output",
            "parallel_output",
            "merged_output",
        ):
            val = state.get(key)
            if val and isinstance(val, str) and val.strip():
                return val
        # Fallback: last message content
        msgs = state.get("messages", [])
        if msgs:
            last = msgs[-1]
            if isinstance(last, dict):
                return last.get("outputs", {}).get("result", str(last))
        return ""

    @staticmethod
    def _get_preceding_node_name(state: dict) -> str:
        """Get the name of the most recent agent that produced output."""
        msgs = state.get("messages", [])
        if msgs:
            last = msgs[-1]
            if isinstance(last, dict):
                return last.get("agent", last.get("node", ""))
        return ""

    @staticmethod
    def _close_pause(
        hitl: Any,
        run_id: str,
        action: str,
        actor: str,
        rationale: Optional[str] = None,
        changes: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Tell the HITL manager the graph has carried out the reviewer's decision.

        WHAT: One call replacing the node's own ``approve`` / ``reject`` /
              ``modify``.
        WHY:  Those re-decided a checkpoint the ``/hitl/decide`` route had
              already decided. Every review therefore wrote two audit rows and
              two ``hitl_states`` updates, on top of the one the replayed
              ``request_approval`` wrote before the interrupt returned -- three
              unordered writes to a single row per click. The log shows both
              audit writes failing in the same second against the same
              ``checkpoint_id``.

              The route is the decision boundary: it validates that the run is
              waiting, records the decision and only then dispatches the
              resume. By the time the graph reaches this line the decision is
              settled; the node's job is to act on it and say so.

        Falls back to the old per-action calls on a manager that predates
        ``consume_decision``, so a partially deployed build still resumes
        rather than failing the node.
        """
        closer = getattr(hitl, "consume_decision", None)
        if closer is not None:
            closer(
                run_id=run_id,
                action=action,
                actor=actor,
                rationale=rationale,
                changes=changes,
            )
            return

        try:
            if action == "reject":
                hitl.reject(run_id=run_id, actor=actor, rationale=rationale)
            elif action == "edit":
                hitl.modify(
                    run_id=run_id, actor=actor, changes=changes or {}, rationale=rationale
                )
            else:
                hitl.approve(run_id=run_id, actor=actor, rationale=rationale)
        except Exception as e:  # noqa: BLE001 -- bookkeeping must not fail a node
            logger.warning(
                "[HITL] Could not close the pause for run '%s': %s", run_id, e
            )

    def _create_hitl_node(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        preceding_node_id: Optional[str] = None,
        successor_node_ids: Optional[List[str]] = None,
        seq: int = 0,
    ):
        """
        Create the workflow's Human-In-The-Loop checkpoint node.

        This is the single HITL implementation. Three existed before phase 8.1
        and the two that ran were both broken:

        * ``hitl_manager.create_hitl_router_node`` -- interrupted with a bare
          string, so the reviewer UI received no payload: no title, no allowed
          decisions, no output to review. It read ``state["agent_output"]``,
          which no node has ever written; it never set ``_hitl_route``, so the
          edit loop could not fire; and it returned ``state.copy()``, which
          re-appended the entire ``messages`` history through that key's
          ``operator.add`` reducer.
        * ``_create_agent_node``'s HITL branch -- called ``request_approval()``
          then immediately ``get_status()``, which of course still read
          ``waiting_for_human``, and carried on executing. It never called
          ``interrupt()`` at all, so that HITL node never paused.

        Both are gone. ``_create_node_for_type`` dispatches every HITL node
        here.

        The three decisions
        -------------------
        ``approve``  record, pass the reviewed output through, continue forward.
        ``reject``   record, stop the run cleanly at END with outcome
                     ``rejected``. A rejection is a business outcome, not an
                     exception: raising ``RuntimeError`` -- what this used to do
                     -- marked the run *failed*, lost downstream state, and
                     reached the user as a crash.
        ``edit``     record, inject the reviewer's feedback and route BACK to
                     the preceding agent, which re-executes and returns here.

        There is deliberately no ``defer``. It had no clean runtime answer: a
        deferred run either ends -- so "postponed" means re-running the whole
        workflow and paying for every model call again -- or parks at an
        interrupt nothing sweeps, which is an abandoned thread by another name.
        A reviewer who simply does not answer already leaves the run paused and
        resumable, which is the same outcome without a second concept.

        An action outside the node's ``allowed_decisions`` is treated as a
        rejection, never as an approval. This is an approval gate: it fails
        closed -- so a stale client still sending ``defer`` stops the run
        rather than approving it.

        Idempotency across resume
        -------------------------
        LangGraph restarts the *whole node* when a run resumes -- it does not
        continue from the line after ``interrupt()``. Anything before the
        interrupt therefore runs again on every resume.

        The documented remedy is to put ``interrupt()`` first, but a checkpoint
        has to be recorded *while* the run is paused or the reviewer has
        nothing to open. So the pre-interrupt work is made idempotent instead:

        * ``request_approval`` is keyed by ``run_id`` in memory, on disk and in
          the DB (``_persist_hitl_state_to_db`` upserts on ``run_id``), so a
          second call updates the checkpoint rather than creating another one;
        * the transparency step uses a **deterministic** step id derived from
          the run and node, so a resume re-uses that step instead of opening a
          second one. It used to call ``new_id("step_")``, which is precisely
          what produced a duplicate step per resume.

        Args:
            node_id: Node identifier.
            node_config: Full node configuration dict.
            preceding_node_id: LangGraph node ID of the preceding agent. The
                edit action routes back to it.
            successor_node_ids: LangGraph node IDs of successor nodes, used by
                the conditional outgoing edge.
            seq: Compile-order position, carried on the accumulator entry.

        Returns:
            Callable node function compatible with LangGraph.
        """
        # Extract HITL configuration from node metadata
        metadata = node_config.get("metadata", {})
        hitl_config = metadata.get("hitl_config", {})
        config_section = node_config.get("config", {})

        # Merge config sources (config section may also carry hitl fields)
        merged_hitl_config = {
            "title": hitl_config.get("title") or config_section.get("title", ""),
            "message": hitl_config.get("message") or config_section.get("message", ""),
            "priority": hitl_config.get("priority") or config_section.get("priority", "medium"),
        }
        # Preserve allowed_decisions / allowEdit for derive_allowed_decisions.
        # ``allowDefer`` is not read: deferral is no longer a decision, and a
        # canvas still carrying that flag simply has no effect.
        for key in ("allowed_decisions", "allowEdit"):
            if key in hitl_config:
                merged_hitl_config[key] = hitl_config[key]
            elif key in config_section:
                merged_hitl_config[key] = config_section[key]

        agent_name = node_config.get("name", node_id)
        output_schema = node_config.get("output_schema", [])

        # Snapshot closure variables for edit-loop routing
        _preceding_node_id = preceding_node_id
        _successor_node_ids = list(successor_node_ids or [])
        _close_pause = WorkflowCompiler._close_pause

        def hitl_node(state: Dict[str, Any]) -> Dict[str, Any]:
            """
            Pause the graph for a human decision, then act on it.

            Returns the decision outcome plus the routing key the conditional
            outgoing edge reads. Never returns the whole state: every key it
            names passes through a reducer, and ``messages`` accumulates.
            """
            from langgraph.types import interrupt
            from langgraph.errors import GraphInterrupt
            from echolib.config import settings

            run_id = state.get("run_id", "unknown")
            workflow_id = state.get("workflow_id", "unknown")

            # Deterministic, so a resume updates this step instead of opening a
            # second one for the same checkpoint. See the idempotency note.
            step_id = "step_hitl_{}_{}".format(run_id, node_id)

            # Clear any previous edit feedback on entry so a fresh agent
            # re-execution does not carry stale feedback from a prior loop.
            state_updates_base = {"_edit_feedback": None}

            # --- Pure reads: no side effects, safe to repeat on resume -------
            allowed = derive_allowed_decisions(merged_hitl_config)
            preceding_output = WorkflowCompiler._extract_preceding_output(state)
            preceding_node_name = WorkflowCompiler._get_preceding_node_name(state)

            interrupt_payload = {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "node_id": node_id,
                "node_name": agent_name,
                "interrupt_type": "hitl_review",
                "title": merged_hitl_config.get("title", ""),
                "message": merged_hitl_config.get("message", ""),
                "priority": merged_hitl_config.get("priority", "medium"),
                "allowed_decisions": allowed,
                "preceding_output": preceding_output,
                "preceding_node_name": preceding_node_name,
                "state_snapshot": {
                    k: v for k, v in state.items()
                    if not k.startswith("_") and k != "messages"
                },
            }

            if settings.transparency_enabled:
                from ..runtime.transparency import step_tracker, StepType
                from ..runtime.event_publisher import (
                    publish_step_started_sync,
                    publish_step_completed_sync,
                    publish_step_failed_sync,
                )

                input_summary = {
                    "user_input": str(state.get("original_user_input", ""))[:200],
                    "agent_name": agent_name,
                    "agent_role": "HITL Review",
                    "is_hitl": True,
                    "allowed_decisions": allowed,
                }
                step_tracker.start_step(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )
                publish_step_started_sync(
                    run_id, step_id, agent_name, StepType.AGENT, input_summary
                )

            try:
                # Resolve the HITL manager. The DI singleton is preferred so the
                # checkpoint this node writes is the one the /hitl routes read.
                try:
                    from echolib.di import container
                    hitl = container.resolve('workflow.hitl')
                except Exception:
                    from ..runtime.hitl import HITLManager
                    hitl = HITLManager()

                # Idempotent: keyed by run_id in memory, on disk and in the DB.
                hitl.request_approval(
                    run_id=run_id,
                    workflow_id=workflow_id,
                    blocked_at=node_id,
                    context={
                        "agent_output": preceding_output,
                        "preceding_node_name": preceding_node_name,
                        "state_snapshot": dict(state),
                        "hitl_config": merged_hitl_config,
                    },
                )

                # === INTERRUPT: pause here until a decision arrives ===
                # Saves state via the checkpointer and returns to the caller.
                # On Command(resume=value) this node restarts and interrupt()
                # returns that value.
                human_decision = interrupt(interrupt_payload)

                # === RESUMED ===
                action = "approve"
                decision_payload: Dict[str, Any] = {}
                if isinstance(human_decision, dict):
                    action = str(human_decision.get("action", "approve")).strip().lower()
                    decision_payload = human_decision.get("payload", {}) or {}
                elif isinstance(human_decision, str) and human_decision.strip():
                    action = human_decision.strip().lower()

                actor = str(decision_payload.get("actor") or "human_reviewer")
                rationale = (
                    decision_payload.get("rationale")
                    or decision_payload.get("comment")
                    or None
                )

                # Fail closed. An unrecognised or disallowed decision must never
                # be read as consent -- that is the whole point of the gate.
                if action not in allowed:
                    logger.error(
                        "[HITL] Node '%s' received decision '%s', which is not in "
                        "allowed_decisions %s. Treating it as a rejection.",
                        node_id, action, allowed,
                    )
                    rationale = (
                        "Decision '{}' is not permitted at this checkpoint "
                        "(allowed: {}).".format(action, ", ".join(allowed))
                    )
                    action = "reject"

                outputs = {k: state.get(k) for k in output_schema if k in state}
                outputs.update(state_updates_base)

                decision_record: Dict[str, Any] = {
                    "node_id": node_id,
                    "node_name": agent_name,
                    "action": action,
                    "actor": actor,
                    "rationale": rationale,
                    "reviewed_node": preceding_node_name or _preceding_node_id or "",
                }

                # -------------------------------------------------------
                # REJECT: terminate the run cleanly; never raise
                # -------------------------------------------------------
                if action == "reject":
                    _close_pause(hitl, run_id, "reject", actor, rationale)
                    outputs["_hitl_route"] = "__end__"
                    outputs["hitl_outcome"] = "rejected"
                    outputs["crew_result"] = (
                        "Workflow rejected at '{}' by {}.".format(agent_name, actor)
                        + (" Reason: {}".format(rationale) if rationale else "")
                    )
                    logger.info("[HITL] '%s' rejected by %s -> END", node_id, actor)

                # -------------------------------------------------------
                # EDIT: route back to the preceding agent with feedback
                # -------------------------------------------------------
                elif action == "edit":
                    _close_pause(
                        hitl, run_id, "edit", actor, rationale,
                        changes=decision_payload,
                    )
                    # The reviewer UI sends {"changes": {"edit_feedback": ...}};
                    # a flat payload is accepted too.
                    changes = decision_payload.get("changes", decision_payload)
                    edit_feedback = (
                        changes.get("edit_feedback")
                        or changes.get("prompt")
                        or ""
                    )
                    if edit_feedback:
                        outputs["_edit_feedback"] = (
                            "[HUMAN REVIEWER FEEDBACK -- you MUST incorporate "
                            "this feedback into your response]: {}".format(edit_feedback)
                        )
                        # Belt and braces, and only that: `task_description` is
                        # the *third* choice in `build_agent_task`, behind
                        # `original_user_input`, which every executor entry
                        # point always sets -- so this branch never reaches a
                        # model on its own. `_edit_feedback` above is what
                        # actually delivers the reviewer's words; see
                        # `langchain_adapter._with_reviewer_feedback`.
                        existing_task = state.get("task_description", "")
                        if existing_task:
                            outputs["task_description"] = (
                                "{}\n\nAdditional instructions: {}".format(
                                    existing_task, edit_feedback
                                )
                            )
                    decision_record["edit_feedback"] = edit_feedback

                    if _preceding_node_id:
                        outputs["_hitl_route"] = _preceding_node_id
                        outputs["hitl_outcome"] = "editing"
                        logger.info(
                            "[HITL] '%s' edit -> routing back to '%s'",
                            node_id, _preceding_node_id,
                        )
                    else:
                        # Nothing to route back to. Continuing forward with the
                        # feedback recorded beats looping to nowhere, but the
                        # canvas is mis-wired and that is worth saying out loud.
                        outputs["_hitl_route"] = (
                            _successor_node_ids[0] if _successor_node_ids else "__end__"
                        )
                        outputs["hitl_outcome"] = "edited_no_target"
                        logger.warning(
                            "[HITL] '%s' received an edit decision but has no "
                            "preceding node to re-run. Continuing forward.",
                            node_id,
                        )

                # -------------------------------------------------------
                # APPROVE: pass the reviewed output through, continue
                # -------------------------------------------------------
                else:
                    _close_pause(hitl, run_id, "approve", actor, rationale)
                    outputs["_hitl_route"] = (
                        _successor_node_ids[0] if _successor_node_ids else "__end__"
                    )
                    outputs["hitl_outcome"] = "approved"
                    # Deliberately does NOT overwrite crew_result with the
                    # decision: the next node needs the content that was
                    # approved, not the fact that it was approved.
                    if preceding_output:
                        outputs["last_node_output"] = preceding_output
                    logger.info("[HITL] '%s' approved by %s", node_id, actor)

                if settings.transparency_enabled:
                    output_summary = {
                        "output_preview": "HITL {}: {}".format(action, agent_name),
                        "agent_name": agent_name,
                        "agent_role": "HITL Review",
                        "hitl_action": action,
                        "hitl_actor": actor,
                    }
                    step_tracker.complete_step(run_id, step_id, output_summary)
                    publish_step_completed_sync(run_id, step_id, output_summary)

                return {
                    **outputs,
                    # A checkpoint is a result like any other. Without this entry
                    # the HITL node contributed nothing to a fan-in, and a
                    # reviewer's decision was invisible to every downstream merge.
                    "all_node_outputs": [node_output_entry(
                        node_id,
                        decision_record,
                        node_type=TYPE_HITL,
                        node_name=agent_name,
                        seq=seq,
                        success=(action != "reject"),
                    )],
                    "messages": [{
                        "agent": node_id,
                        "role": "HITL Review",
                        "inputs": {"hitl_config": merged_hitl_config},
                        "outputs": decision_record,
                        "hitl_checkpoint": True,
                        "hitl_action": action,
                    }],
                }

            except GraphInterrupt:
                # interrupt() raises GraphInterrupt to halt the graph. That is a
                # pause, not a failure -- emit a completed step carrying paused
                # metadata so the UI shows "waiting for review", not "failed".
                if settings.transparency_enabled:
                    paused_summary = {
                        "output_preview": (
                            "Waiting for human review: {}".format(
                                merged_hitl_config.get("title", node_id)
                            )
                        ),
                        "agent_name": agent_name,
                        "agent_role": "HITL Review",
                        "hitl_paused": True,
                        "hitl_config": {
                            "title": merged_hitl_config.get("title", ""),
                            "priority": merged_hitl_config.get("priority", "medium"),
                        },
                        "allowed_decisions": allowed,
                        "preceding_output": preceding_output,
                        "preceding_node_name": preceding_node_name,
                    }
                    step_tracker.complete_step(run_id, step_id, paused_summary)
                    publish_step_completed_sync(run_id, step_id, paused_summary)
                raise  # Re-raise so LangGraph handles the interrupt
            except Exception as e:
                logger.error("HITL node '%s' failed: %s", node_id, e, exc_info=True)
                if settings.transparency_enabled:
                    step_tracker.fail_step(run_id, step_id, str(e))
                    publish_step_failed_sync(run_id, step_id, str(e))
                raise

        return hitl_node



    def _wrap_node_with_tracing(self, node_fn, node_name: str):
        """
        Wrap a LangGraph node function to trace state transitions via OTel.

        Creates an OpenTelemetry span for each node execution, logging
        input state keys and modified output keys.

        An async node keeps its async-ness. Wrapping one in a synchronous
        closure returns the coroutine unawaited, and LangGraph rejects it with
        ``InvalidUpdateError: Expected dict, got <coroutine>`` -- so tracing
        silently broke any node that happened to be ``async def``. The wrapper
        must preserve the callable's shape, not just its behaviour.

        Args:
            node_fn: The original node function to wrap.
            node_name: Human-readable name for the node (used in span).

        Returns:
            Wrapped function of the same kind (sync or async) as ``node_fn``.
        """
        try:
            from opentelemetry import trace

            tracer = trace.get_tracer("echoai")

            def _annotate(span, state):
                span.set_attribute("node.name", node_name)
                span.set_attribute("node.input_keys", str(list(state.keys())))

            def _record(span, result):
                if isinstance(result, dict):
                    span.set_attribute("node.output_keys", str(list(result.keys())))
                return result

            if asyncio.iscoroutinefunction(node_fn):
                async def traced_async_node(state):
                    with tracer.start_as_current_span(f"node:{node_name}") as span:
                        _annotate(span, state)
                        return _record(span, await node_fn(state))

                return traced_async_node

            def traced_node(state):
                with tracer.start_as_current_span(f"node:{node_name}") as span:
                    _annotate(span, state)
                    return _record(span, node_fn(state))

            return traced_node
        except Exception:
            return node_fn

    def _create_parallel_merge_node(
        self,
        merge_node_id: str,
        expected_count: int,
    ):
        """
        Create a synthetic merge/aggregation node for parallel branches.

        This node reads the accumulated ``all_node_outputs`` list from state,
        aggregates them into a single ``parallel_output`` / ``crew_result``
        string with clear section headers, and logs data integrity information
        (how many outputs collected vs expected).

        Downstream LLM agents can then consume the aggregated text as context
        without relying on last-writer-wins fields.

        Wired into ``_compile_parallel_dag`` by Phase 8. Before that it was
        defined and never called, and the convergence node that ran instead
        read a state key nothing wrote.

        Sequential and hybrid graphs need no merge node: a downstream agent
        reads the accumulator directly through ``build_agent_task``, so a
        fan-in expressed as connections is handled without a synthetic node.

        Args:
            merge_node_id: Unique identifier for this merge node in LangGraph.
            expected_count: Number of parallel branches whose output we expect.

        Returns:
            Callable node function compatible with LangGraph StateGraph.
        """
        def merge_node(state: Dict[str, Any]) -> Dict[str, Any]:
            """Aggregate all_node_outputs from parallel branches into a single result."""
            all_outputs = state.get("all_node_outputs", []) or []
            logger.info(
                f"[MERGE] Node '{merge_node_id}' collecting outputs: "
                f"{len(all_outputs)} received, {expected_count} expected"
            )

            if len(all_outputs) < expected_count:
                # Still a real signal after Phase 8, but it now means a branch
                # genuinely produced nothing -- not that its write was silently
                # overwritten by a sibling.
                logger.warning(
                    f"[MERGE][DATA_INTEGRITY] Expected {expected_count} parallel outputs "
                    f"but only {len(all_outputs)} arrived at merge node '{merge_node_id}'"
                )

            # Ordered by ``seq``, not arrival: the reducer guarantees that
            # concurrent writes merge, never the order in which they do, so a
            # summary built from arrival order would differ between runs of the
            # same workflow on the same input.
            aggregated = render_outputs(all_outputs)

            # Namespaced API results are a separate legacy surface written by
            # parallel API nodes. Used only when the accumulator is empty, so a
            # workflow that predates the accumulator still merges.
            if not aggregated:
                api_results = {
                    k: v for k, v in state.items()
                    if k.startswith("api_result_")
                }
                if api_results:
                    aggregated = json.dumps(api_results, indent=2, default=str)

            return {
                "parallel_output": aggregated,
                "crew_result": aggregated,
                "last_node_output": aggregated,
                "messages": [{
                    "node": merge_node_id,
                    "type": "merge",
                    "output_count": len(all_outputs),
                    "expected_count": expected_count,
                }],
            }

        return merge_node

    def _create_node_for_type(
        self,
        node_id: str,
        node_config: Dict[str, Any],
        preceding_node_id: Optional[str] = None,
        successor_node_ids: Optional[List[str]] = None,
        seq: int = 0,
    ):
        """
        Dispatch to the correct node creation method based on node type.

        This is the central router that the compile methods call instead of
        directly calling _create_agent_node. It inspects the node's type
        field and delegates accordingly.

        Supported types:
            - "Agent" (default) → _create_agent_node
            - "API"             → _create_api_node
            - "MCP"             → _create_mcp_node
            - "Code"            → _create_code_node
            - "Self-Review"     → _create_self_review_node
            - "Conditional"/"Router" → _create_conditional_node (handled separately in BFS)
            - "HITL"            → _create_hitl_node (LangGraph interrupt checkpoint)
            - "Start"           → _create_start_node (passthrough, maps inputVariables)
            - "End"             → _create_end_node (passthrough, collects outputVariables)

        A node whose ``type`` is unset but whose ``metadata.node_type`` is
        "HITL" is a HITL node too. That form used to fall through to
        ``_create_agent_node``, which ran a checkpoint that never paused.

        Args:
            node_id: Node identifier.
            node_config: Full node configuration dict.
            preceding_node_id: LangGraph node ID of the preceding node
                (used by HITL nodes to route back on edit).
            successor_node_ids: LangGraph node IDs of successor nodes
                (used by HITL conditional routing).
            seq: The node's position in compile order. Carried on every
                ``all_node_outputs`` entry so a fan-in orders its branches by
                graph position instead of alphabetically by name.

        Returns:
            Callable node function compatible with LangGraph.
        """
        # A node with no configuration is an unresolved reference, not a node.
        #
        # Every compile path reaches this method through
        # ``agent_registry.get(aid, {})``, so a node whose agent could not be
        # resolved arrives here as ``{}``. It used to be compiled anyway: the
        # type lookup below defaults to "Agent", ``create_react_agent_node({})``
        # builds an agent with no instructions and no tools, and the LLM
        # resolver -- given no credential -- drops to the platform fallback
        # model. The run then "succeeded" while producing text no configured
        # agent had written, which is worse than not running at all.
        #
        # ``resolve_workflow_agents`` has already logged which reference failed
        # and why. This is the point at which that stops being survivable.
        if not node_config:
            raise ValueError(
                f"Workflow node '{node_id}' references an agent that could not "
                f"be resolved, so there is nothing to execute for it. Check the "
                f"agent resolution errors logged above; "
                f"scripts/audit_workflow_agent_references.py reports whether "
                f"this workflow's references point at agents that exist."
            )

        # Determine node type from config — check multiple locations
        node_type = (
            node_config.get("type")
            or node_config.get("metadata", {}).get("node_type")
            or node_config.get("config", {}).get("type")
            or "Agent"
        )

        node_type_normalized = node_type.strip().lower()

        node_fn = None

        if node_type_normalized == "api":
            logger.info(f"Creating API node: {node_id} ('{node_config.get('name', node_id)}')")
            node_fn = self._create_api_node(node_id, node_config, seq=seq)

        elif node_type_normalized == "mcp":
            logger.info(f"Creating MCP node: {node_id} ('{node_config.get('name', node_id)}')")
            node_fn = self._create_mcp_node(node_id, node_config, seq=seq)

        elif node_type_normalized == "code":
            logger.info(f"Creating Code node: {node_id} ('{node_config.get('name', node_id)}')")
            node_fn = self._create_code_node(node_id, node_config, seq=seq)

        elif node_type_normalized in ("self-review", "self_review", "selfreview"):
            # The neighbours are needed for the same reason a HITL node needs
            # them: a failed review routes back to the node it reviewed.
            logger.info(f"Creating Self-Review node: {node_id} ('{node_config.get('name', node_id)}')")
            node_fn = self._create_self_review_node(
                node_id,
                node_config,
                preceding_node_id=preceding_node_id,
                successor_node_ids=successor_node_ids,
                seq=seq,
            )

        elif node_type_normalized in ("conditional", "router"):
            # The node only *decides*; its outgoing edge is wired separately by
            # _wire_conditional_edge, which is what makes the decision take
            # effect. The successors are handed over here too so the node can
            # warn when a branch names a target no connection reaches.
            logger.info(f"Creating Conditional node: {node_id}")
            node_fn = self._create_conditional_node(
                node_id, node_config, branch_targets=list(successor_node_ids or [])
            )

        elif node_type_normalized == "start":
            logger.info(f"Creating Start node: {node_id} (passthrough, no LLM)")
            node_fn = self._create_start_node(node_id, node_config)

        elif node_type_normalized == "end":
            logger.info(f"Creating End node: {node_id} (passthrough, no LLM)")
            node_fn = self._create_end_node(node_id, node_config)

        elif node_type_normalized == "hitl":
            # One HITL implementation, reached by every HITL node. See
            # _create_hitl_node for what the two previous ones got wrong -- in
            # short, neither of them could pause and act on all four decisions.
            logger.info(
                f"Creating HITL checkpoint node: {node_id}",
                extra={"node_type": "hitl", "node_name": node_config.get("name")}
            )
            node_fn = self._create_hitl_node(
                node_id,
                node_config,
                preceding_node_id=preceding_node_id,
                successor_node_ids=successor_node_ids,
                seq=seq,
            )

        else:
            # Default: Agent node. HITL is dispatched above, never here.
            logger.info(f"Creating Agent node: {node_id} (type='{node_type}')")
            node_fn = self._create_agent_node(node_id, node_config, seq=seq)

        # Wrap node function with OTel tracing for state transition visibility
        try:
            from echolib.config import settings as _cfg
            if _cfg.OTEL_ENABLED:
                node_fn = self._wrap_node_with_tracing(
                    node_fn, node_config.get("name", node_id)
                )
        except Exception:
            pass  # Tracing wrapper is best-effort

        return node_fn

    def _execute_llm_call(self, llm_config: Dict[str, Any], prompt: str, user_id: Optional[str] = None, credential_id: Optional[str] = None) -> str:
        """
        Execute one LLM call for a Self-Review node, through the canonical resolver.

        WHAT: Builds a chat model with ``resolve_and_build_llm_sync`` -- the same
              entry point every agent uses -- invokes it once, records token
              usage, and returns the text.
        WHY:  This used to hand-roll its own provider switch: ``AzureChatOpenAI``,
              ``ChatOpenAI``, the raw ``anthropic`` SDK, Gemini and Ollama were
              each constructed here from either resolved credentials or platform
              secrets, across roughly 350 lines. It was a complete second copy of
              ``llm_client_builder_v2`` and it drifted, because nothing kept the
              two in step.

              What that copy silently did not have:

              - **Tier 1b and Tier 2.5.** ``resolve_llm_credential_sync`` was
                called with the user id only, so a deployment whose users hold no
                personal credential fell through to platform secrets rather than
                to the platform's own registered credential.
              - **The output-token resolution chain.** It read
                ``llm_config["max_tokens"]`` with a literal default of **1000** --
                lower than anywhere else in the platform -- so a Self-Review node
                truncated its verdict at a limit no operator ever set and no
                setting could raise.
              - **Attribution.** Nothing recorded which credential answered, so a
                Self-Review step was the one step in a run whose model could not
                be traced.

              ``Plan_1-done.md`` recorded this as a known deviation to collapse
              "before Phase 10". This is that collapse.

        INPUT: The node's ``llm_config``, the prompt, and the run's user and
               pinned credential. Signature unchanged; the only caller is the
               Self-Review node.
        OUTPUT: The model's reply as text.
        RAISES: Whatever the resolver raises when no credential tier resolves --
                the node's own handler turns that into a failed review rather
                than a failed workflow.

        Routing, edges and node topology are untouched by this: the Conditional
        node evaluates conditions without a model, and HITL routing is wired in
        ``_wire_hitl_conditional_edge``. Neither passes through here.
        """
        from echolib.llm_resolver import resolve_and_build_llm_sync

        provider = (llm_config.get("provider") or "").strip() or None
        model = (llm_config.get("model") or "").strip() or None

        # ``max_tokens`` is forwarded only when the node actually states one.
        # Absent, the resolver applies the credential's registered ceiling and
        # then a provider-aware floor -- the same chain every agent now uses.
        raw_max_tokens = llm_config.get("max_tokens")
        max_tokens = int(raw_max_tokens) if raw_max_tokens is not None else None

        llm = resolve_and_build_llm_sync(
            user_id=user_id,
            credential_id=credential_id,
            component="workflow_self_review",
            temperature=float(llm_config.get("temperature", 0.2)),
            allow_platform_fallback=True,
            framework="langchain",
            model=model,
            provider=provider,
            max_tokens=max_tokens,
        )

        response = llm.invoke(prompt)

        try:
            from echolib.llm_resolver import describe_resolution

            resolution = describe_resolution(llm) or {}
        except Exception:  # noqa: BLE001 -- telemetry must not fail the node
            resolution = {}

        self._record_workflow_llm_usage(
            response,
            str(resolution.get("model") or model or "unknown"),
            str(resolution.get("provider") or provider or "unknown"),
        )

        content = getattr(response, "content", response)
        if isinstance(content, list):
            # Some providers answer with content blocks rather than a string.
            content = "".join(
                part.get("text", "") if isinstance(part, dict) else str(part)
                for part in content
            )
        return content if isinstance(content, str) else str(content)

    def _record_workflow_llm_usage(self, response: Any, model: str, provider: str) -> None:
        """Record workflow LLM token usage from raw SDK/langchain response objects."""
        try:
            from echolib.otel import _extract_token_usage, get_metrics_collector, _get_user_id

            usage = _extract_token_usage(response)
            get_metrics_collector().record_llm_call(
                model=model or "unknown",
                provider=provider or "unknown",
                feature="workflow",
                method="invoke",
                duration_ms=0,
                input_tokens=usage["input_tokens"],
                output_tokens=usage["output_tokens"],
                total_tokens=usage["total_tokens"],
                status="success",
                user_id=_get_user_id(),
            )
        except Exception:
            pass

    def _determine_graph_type(self, execution_model: str) -> str:
        """
        Determine LangGraph graph type from execution model.

        Args:
            execution_model: Execution model

        Returns:
            LangGraph graph type
        """
        mapping = {
            "sequential": "StateGraph",
            "parallel": "StateGraph",
            "hierarchical": "StateGraph",
            "hybrid": "StateGraph"
        }
        return mapping.get(execution_model, "StateGraph")
