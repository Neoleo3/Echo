"""
AURA-style prompt-based generation routes (NEW endpoints, additive only).

These live on their own router so Echo's existing 1,900-line ``routes.py`` —
and all of its DB/session/keyword logic — is left completely untouched. The
existing ``/workflows/design/prompt`` (single-LLM-call designer with keyword
tool-selection) keeps working as-is; this exposes the stronger AURA pipeline
under ``/workflows/.../aura`` so the two can be compared and rolled out safely.

Auth and user-id plumbing reuse Echo's standard dependencies, so RBAC/session
behaviour is identical to the existing routes. GENERATION-ONLY: these endpoints
produce a workflow/agent spec + quality score; persistence and execution are
unchanged Echo concerns wired in later steps.
"""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import StreamingResponse

from echolib.security import require_admin_or_above, resolve_user_id
from echolib.types import UserContext

from .aura_pipeline.validation_agent import validate_workflow_request
from .aura_pipeline.orchestrator import iter_pipeline, run_pipeline

logger = logging.getLogger(__name__)

# Same prefix/tag family as the main workflow router, mounted separately.
router = APIRouter(prefix="/workflows", tags=["WorkflowAuraApi"])


def _sse(event_type: str, data: dict) -> str:
    return f"event: {event_type}\ndata: {json.dumps(data, default=str)}\n\n"


@router.post("/design/prompt/aura/validate")
async def design_prompt_aura_validate(
    body: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """Stage-1 only — quick BYO-LLM validation of a workflow request."""
    prompt = (body.get("prompt") or "").strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt is required")
    effective_user_id = resolve_user_id(user)
    validation = await asyncio.to_thread(validate_workflow_request, prompt, effective_user_id)
    return {"stage": "validation", "status": "completed", "prompt": prompt, "validation": validation}


@router.post("/design/prompt/aura")
async def design_prompt_aura(
    body: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Full AURA pipeline (non-streaming): validate -> plan -> recruit -> judge.

    Body: {"prompt": "<natural language workflow request>"}

    Returns the assembled spec (validation, plan, agents DAG, dag_evaluation).
    Does not persist or execute — that is wired in a later step via Echo's
    existing repositories.
    """
    prompt = (body.get("prompt") or "").strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt is required")
    execution_mode = (body.get("execution_mode") or "autonomous").strip()
    effective_user_id = resolve_user_id(user)
    try:
        result = await asyncio.to_thread(run_pipeline, prompt, effective_user_id, execution_mode)
    except Exception as e:
        logger.error("aura design/prompt pipeline failed: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    return result


@router.post("/design/prompt/aura/stream")
async def design_prompt_aura_stream(
    body: dict = Body(...),
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Full AURA pipeline (SSE streaming): emits stage events in order
    (validation -> planning -> recruitment -> agent_recruited* -> dag_evaluation
    -> result), mirroring AURA's builder UX.
    """
    prompt = (body.get("prompt") or "").strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt is required")
    execution_mode = (body.get("execution_mode") or "autonomous").strip()
    effective_user_id = resolve_user_id(user)

    async def event_stream():
        # iter_pipeline is sync (LLM calls block); run it in a thread and pump
        # events out one at a time so the SSE response stays responsive.
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def _produce():
            try:
                for event_type, data in iter_pipeline(prompt, user_id=effective_user_id, execution_mode=execution_mode):
                    loop.call_soon_threadsafe(queue.put_nowait, (event_type, data))
            except Exception as e:  # surface as an error event
                loop.call_soon_threadsafe(queue.put_nowait, ("error", {"message": str(e)}))
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        asyncio.get_event_loop().run_in_executor(None, _produce)

        while True:
            item = await queue.get()
            if item is None:
                break
            event_type, data = item
            yield _sse(event_type, data)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )
