"""
Tool catalogue adapter — bridges the AURA pipeline to ECHO's ToolRegistry.

AURA's meta-agents validated tools against AURA's in-process ``TOOL_REGISTRY``.
Here we read Echo's real ToolRegistry instead (built-in + connector-synced
tools), honouring the project's GLOBAL connector-visibility decision by listing
all tools rather than user-scoping them. No tool is invented: the recruiter is
shown these exact ``tool_id`` values and its output is filtered against them.
"""

from __future__ import annotations

import logging
from typing import Dict, Set

logger = logging.getLogger(__name__)


def _get_registry():
    """Resolve Echo's ToolRegistry from the DI container (best-effort)."""
    try:
        from echolib.di import container
        return container.resolve("tool.registry")
    except Exception:
        try:
            from apps.tool.container import container as tool_container
            return tool_container.resolve("tool.registry")
        except Exception:
            return None


def get_tool_catalog() -> Dict[str, dict]:
    """Return {tool_id: {name, description, tags}} for every registered tool."""
    reg = _get_registry()
    catalog: Dict[str, dict] = {}
    if reg is None:
        return catalog
    try:
        tools = reg.list_all()
    except Exception as e:
        logger.warning("aura pipeline: tool catalogue load failed: %s", e)
        return catalog
    for t in tools:
        try:
            catalog[t.tool_id] = {
                "name": getattr(t, "name", t.tool_id),
                "description": getattr(t, "description", "") or "",
                "tags": list(getattr(t, "tags", []) or []),
            }
        except Exception:
            continue
    return catalog


def valid_tool_ids() -> Set[str]:
    return set(get_tool_catalog().keys())


def build_tool_menu(catalog: Dict[str, dict] | None = None) -> str:
    """Human-readable menu of exact tool IDs for the recruiter prompt."""
    catalog = catalog if catalog is not None else get_tool_catalog()
    if not catalog:
        return "(No tools available — assign empty tool lists.)"
    lines = []
    for tid, info in sorted(catalog.items()):
        desc = (info.get("description") or "")[:100]
        lines.append(f"  - {tid}: {info.get('name', '')} - {desc}")
    return "\n".join(lines)
