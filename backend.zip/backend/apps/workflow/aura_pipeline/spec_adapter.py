"""
Spec adapter — AURA agent DAG  ->  Echo-native workflow + agent dicts.

The AURA pipeline produces agents shaped like
``{agent_name, role, goal, skills, tools, connections, node_type, human_gate}``.
Echo's workflow layer expects the same shape ``WorkflowDesigner`` emits:
``(workflow_dict, {agent_id: agent_dict})`` with ``execution_model``,
``agents: [ids]``, ``connections: [{from, to}]``, ``topology``/``hierarchy``,
``human_in_loop``. Producing that shape means the EXISTING Echo save endpoints
persist these workflows unchanged — no new DB writes, no schema changes.

GENERATION-ONLY + constraints: this only reshapes data. It does not touch the
DB, sessions, or keyword logic. ``new_id`` comes from echolib.utils (id helper,
not persistence).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from echolib.utils import new_id

from .dag import compute_dag_levels, infer_execution_model


def _is_gate(a: dict) -> bool:
    return a.get("node_type") == "human_gate" or bool(a.get("human_gate"))


def to_echo_spec(
    agents: List[dict],
    workflow_name: str,
    workflow_type: str = "general",
    description: str = "",
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    execution_mode: str = "autonomous",
) -> Tuple[Dict[str, Any], Dict[str, Dict[str, Any]]]:
    """Convert AURA agents into an Echo (workflow, agents) pair.

    Human-gate nodes are NOT emitted as Echo agents; instead they become
    ``human_in_loop`` review points, and the DAG edges are rewired to bypass the
    gate so the remaining agent graph stays connected and runnable.
    """
    timestamp = datetime.utcnow().isoformat()

    # ── Partition gates vs real agents ──
    gate_names = {a["agent_name"] for a in agents if isinstance(a, dict) and _is_gate(a)}
    real_agents = [a for a in agents if isinstance(a, dict) and a.get("agent_name") and not _is_gate(a)]

    # name -> resolved upstream names, with gates transparently bypassed
    def _resolve_ups(conns: List[str]) -> List[str]:
        out: List[str] = []
        stack = list(conns or [])
        seen = set()
        while stack:
            c = stack.pop()
            if c in seen:
                continue
            seen.add(c)
            if c in gate_names:
                # replace the gate with whatever the gate depended on
                gate = next((g for g in agents if g.get("agent_name") == c), {})
                stack.extend(gate.get("connections") or [])
            else:
                out.append(c)
        return out

    # ── Build Echo agent dicts + name->id map ──
    name_to_id: Dict[str, str] = {}
    echo_agents: Dict[str, Dict[str, Any]] = {}
    for a in real_agents:
        agent_id = new_id("agt_")
        name_to_id[a["agent_name"]] = agent_id
        skills = list(a.get("skills") or [])
        # NOTE: skill methodology is baked at EXECUTION (runtime/langgraph_agent
        # ._build_system_prompt) from metadata.skills, so it stays a single source
        # of truth and edits to skills in the node editor take effect. We keep the
        # goal clean here (no pre-baked methodology) to avoid double-baking.
        goal = a.get("goal", "") or ""
        agent: Dict[str, Any] = {
            "agent_id": agent_id,
            "name": a.get("agent_name"),
            "role": a.get("role", "Processing"),
            "goal": goal,
            "description": (a.get("goal", "") or "")[:200],
            "llm": {"temperature": 0.3},
            "tools": list(a.get("tools") or []),
            "input_schema": ["input"],
            "output_schema": ["output"],
            "constraints": {"max_steps": 10, "timeout_seconds": 60},
            "permissions": {"can_call_agents": False},
            "metadata": {
                "created_at": timestamp,
                "created_by": "aura_pipeline",
                "skills": list(a.get("skills") or []),
            },
        }
        if credential_id:
            agent["credential_id"] = credential_id
        echo_agents[agent_id] = agent

    # ── Connections (gates bypassed), in Echo {from,to} form ──
    connections: List[Dict[str, str]] = []
    for a in real_agents:
        to_id = name_to_id[a["agent_name"]]
        for up in _resolve_ups(a.get("connections") or []):
            if up in name_to_id:
                connections.append({"from": name_to_id[up], "to": to_id})

    # ── Execution model from DAG shape (over the real agents, with gates
    # bypassed so a gate-dependent node isn't mistaken for a parallel root) ──
    resolved_agents = [
        {
            "agent_name": a["agent_name"],
            "connections": [u for u in _resolve_ups(a.get("connections") or []) if u in name_to_id],
        }
        for a in real_agents
    ]
    levels = compute_dag_levels(resolved_agents)
    execution_model = infer_execution_model(levels, len(real_agents))

    # ── Human-in-loop review points from gates ──
    review_points = []
    for g in agents:
        if isinstance(g, dict) and _is_gate(g):
            cfg = g.get("human_gate") or {}
            review_points.append({
                "name": g.get("agent_name"),
                "approver_role": cfg.get("approver_role", "operator"),
                "decision_options": cfg.get("decision_options", ["approve", "reject"]),
                "after": _resolve_ups(g.get("connections") or []),
            })

    workflow = {
        "workflow_id": new_id("wf_"),
        "name": workflow_name,
        "icon": "workflow",
        "description": description or workflow_name,
        "status": "draft",
        "version": "0.1",
        "execution_model": execution_model,
        "agents": [name_to_id[a["agent_name"]] for a in real_agents],
        "connections": connections,
        "hierarchy": None,
        "topology": None,
        "state_schema": {},
        "human_in_loop": {
            "enabled": bool(review_points),
            "review_points": review_points,
        },
        "metadata": {
            "created_by": "aura_pipeline",
            "created_at": timestamp,
            "workflow_type": workflow_type,
            "tags": ["auto-generated", "aura"],
        },
        # AURA execution primitives config (consumed at runtime via tool context).
        # mode: "autonomous" | "simulation"; policy gates tools; fallback_tools
        # power self-healing. Empty defaults = behaviour unchanged.
        "execution": {
            "mode": execution_mode,
            "policy": {"allowed": None, "denied": []},
            "fallback_tools": {},
        },
    }
    return workflow, echo_agents
