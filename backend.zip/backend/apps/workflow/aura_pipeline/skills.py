"""
Skill registry for the AURA pipeline.

Ports AURA's folder-based skill registry: each skill is ``skill_defs/<id>/SKILL.md``
with YAML frontmatter (name, description, category, tools, method, ...) + body.
The FULL set of SKILL.md files is added in Step 3; until then ``skill_defs/`` is
empty, ``SKILL_REGISTRY`` is ``{}`` and every helper degrades to a no-op, so the
planner/recruiter simply assign no skills.

IMPORTANT for Step 3: a skill's ``tools:`` frontmatter must use ECHO tool IDs
(validated here against Echo's ToolRegistry via ``tools.valid_tool_ids()``),
NOT AURA tool names.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Set

logger = logging.getLogger(__name__)

SKILLS_DIR = Path(__file__).resolve().parent / "skill_defs"


def _split_frontmatter(text: str) -> tuple[str, str]:
    stripped = text.lstrip()
    if stripped.startswith("---"):
        parts = stripped.split("---", 2)
        if len(parts) >= 3:
            return parts[1], parts[2]
    return "", text


def _load_registry() -> Dict[str, Dict[str, Any]]:
    registry: Dict[str, Dict[str, Any]] = {}
    if not SKILLS_DIR.exists():
        return registry
    try:
        import yaml
    except Exception:
        logger.warning("aura pipeline: PyYAML unavailable — skills disabled")
        return registry

    for child in sorted(SKILLS_DIR.iterdir()):
        if not child.is_dir() or child.name.startswith(("__", ".")):
            continue
        md = child / "SKILL.md"
        if not md.exists():
            continue
        try:
            text = md.read_text(encoding="utf-8")
            fm_text, body = _split_frontmatter(text)
            data = yaml.safe_load(fm_text) or {}
        except Exception as e:
            logger.warning("aura pipeline: failed to load skill %s: %s", md, e)
            continue
        skill_id = (data.get("name") or child.name).strip()
        registry[skill_id] = {
            "name": data.get("display_name") or data.get("name") or skill_id,
            "description": (data.get("description") or "").strip(),
            "category": data.get("category") or "General",
            "tools": list(data.get("tools") or []),
            "method": (data.get("method") or "").strip(),
            "example_use_cases": list(data.get("example_use_cases") or []),
            "body": body.strip(),
        }
    return registry


SKILL_REGISTRY: Dict[str, Dict[str, Any]] = _load_registry()


def valid_skill_ids() -> Set[str]:
    return set(SKILL_REGISTRY)


def get_skill_menu() -> str:
    """Compact skill catalogue grouped by category for planner/recruiter prompts."""
    if not SKILL_REGISTRY:
        return "(No skills available)"
    by_category: Dict[str, list] = {}
    for skill_id, s in SKILL_REGISTRY.items():
        by_category.setdefault(s["category"], []).append((skill_id, s))
    lines: List[str] = []
    for cat, items in by_category.items():
        lines.append(f"\n[{cat}]")
        for skill_id, s in items:
            lines.append(f"  - {skill_id}: {s['description'][:90]}")
    return "\n".join(lines)


# AURA tool names (used in the ported SKILL.md frontmatter) -> Echo tool IDs.
# Wildcards (tool_api_*, tool_mcp_*) are expanded against the live registry.
# ``None`` means "no Echo equivalent" -> the grant is dropped.
_AURA_TO_ECHO_TOOL: Dict[str, str | None] = {
    "web_search_tool": "tool_web_search",
    "calculator_tool": "tool_calculator",
    "analysis_tool": "data_analyst",
    "report_tool": "tool_docx_generator",
    "document_report_tool": "tool_docx_generator",
    "db_*_tool": "tool_convo_bi",
    "db_schema_tool": "tool_convo_bi",
    "api_*_tool": "tool_api_*",
    "mcp_*": "tool_mcp_*",
    # No Echo equivalent — dropped (AURA-specific fixtures / no email tool):
    "email_tool": None,
    "sap_read_tool": None,
    "sharepoint_read_tool": None,
    "local_invoice_fixture_tool": None,
}


# Echo-specific tools (file_reader, doc generators, ocr...) are not part of the
# ported AURA SKILL.md tool lists, so no skill would bundle them and document
# workflows (e.g. RFPs) would depend on the recruiter LLM happening to pick them.
# This explicit, conservative map bundles the right Echo tool with the skills
# that genuinely need it — restoring AURA's "tools inside skills" reliability.
_SKILL_EXTRA_ECHO_TOOLS: Dict[str, List[str]] = {
    # document/file-consuming skills -> read the source files
    "document-processing": ["tool_file_reader", "tool_document_analysis", "tool_ocr"],
    "data-extraction": ["tool_file_reader", "tool_document_analysis"],
    "invoice-parsing": ["tool_file_reader", "tool_document_analysis", "tool_ocr"],
    "entity-recognition": ["tool_file_reader", "tool_document_analysis"],
    "contract-review": ["tool_file_reader", "tool_document_analysis"],
    "financial-statement-review": ["tool_file_reader"],
    "vendor-due-diligence": ["tool_file_reader"],
    "quality-review": ["tool_file_reader"],
    "audit-planning": ["tool_file_reader"],
    # reporting / writing -> Word document
    "document-reporting": ["tool_docx_generator", "tool_pdf_generator"],
    "report-generation": ["tool_docx_generator", "tool_pdf_generator"],
    "proposal-writing": ["tool_docx_generator", "tool_pdf_generator", "tool_file_reader"],
    # presentation -> PowerPoint
    "result-presentation": ["tool_ppt_generator"],
    # knowledge-base lookups
    "market-research": ["tool_knowledge_search"],
}


def get_tools_for_skills(skill_ids) -> List[str]:
    """Echo tool IDs granted by the given skills.

    Translates AURA skill tool names -> Echo tool IDs via ``_AURA_TO_ECHO_TOOL``,
    expands wildcards (e.g. ``tool_mcp_*``) against the live Echo ToolRegistry,
    adds the Echo-specific supplemental tools each skill needs
    (``_SKILL_EXTRA_ECHO_TOOLS``), and only returns tools that actually exist —
    mirroring AURA's 'tools inside skills' behaviour for Echo's registry.
    """
    import fnmatch
    from .tools import get_tool_catalog

    catalog = get_tool_catalog()
    registered = list(catalog.keys())
    out: List[str] = []

    def _add(tool_id: str) -> None:
        if tool_id and tool_id in registered and tool_id not in out:
            out.append(tool_id)

    def _tags(tid: str) -> set:
        return {str(t).lower() for t in (catalog.get(tid, {}).get("tags") or [])}

    def _grant_by_tags(*needed: str, require: str | None = None) -> None:
        """Grant every LIVE registry tool whose tags match — dynamic connector
        bundling by type, so newly-added connectors are picked up with no code
        change and no hardcoded connector IDs."""
        want = {n.lower() for n in needed}
        for tid in registered:
            tags = _tags(tid)
            if want & tags and (require is None or require in tags):
                _add(tid)

    for sid in skill_ids or []:
        skill = SKILL_REGISTRY.get(sid)
        if not skill:
            continue
        raw_tools = list(skill.get("tools", []))
        for raw in raw_tools:
            mapped = _AURA_TO_ECHO_TOOL.get(raw, raw)  # passthrough if already an Echo id
            if not mapped:
                continue
            if "*" in mapped or "?" in mapped:
                for m in fnmatch.filter(registered, mapped):
                    _add(m)
            else:
                _add(mapped)

        # Dynamic connector bundling BY TYPE, keyed off the skill's OWN declared
        # tool patterns (db_*/api_*/mcp_*) + live registry tags. Nothing is
        # hardcoded — a new DB/API/MCP connector is granted automatically.
        joined = " ".join(str(r).lower() for r in raw_tools)
        if "db" in joined:            # db_*_tool / db_schema_tool
            _grant_by_tags("database", "sql")
        if "api" in joined:           # api_*_tool
            _grant_by_tags("api", require="connector")
        if "mcp" in joined:           # mcp_* / mcp tools
            _grant_by_tags("mcp", require="connector")

        # Supplemental built-in tools for document/file/reporting/presentation
        # skills (stable built-in IDs — kept as code per design decision).
        for extra in _SKILL_EXTRA_ECHO_TOOLS.get(sid, []):
            _add(extra)
    return out


def get_skill_methodology(skill_ids, max_chars: int = 600) -> str:
    """Compact methodology block baked into an agent's system prompt at
    EXECUTION time (runtime/langgraph_agent), so the agent's assigned skills
    drive its behaviour and edits in the node editor take effect. Returns
    name + method (+ first lines of body) per skill."""
    known = [sid for sid in (skill_ids or []) if sid in SKILL_REGISTRY]
    if not known:
        return ""
    parts = ["SKILL METHODOLOGY (apply each):"]
    for sid in known:
        s = SKILL_REGISTRY[sid]
        method = s.get("method") or ""
        if not method:
            body = s.get("body") or ""
            method = " ".join(body.split())[:max_chars]
        parts.append(f"- {s['name']}: {method[:max_chars]}")
    return "\n".join(parts)


def get_skill_index(skill_ids) -> str:
    """One-line-per-skill index baked into an agent's prompt (generation-only:
    we inject methodology at build time rather than via a runtime load_skill tool)."""
    known = [sid for sid in (skill_ids or []) if sid in SKILL_REGISTRY]
    if not known:
        return ""
    lines = ["Assigned skills (apply each skill's methodology):"]
    for sid in known:
        s = SKILL_REGISTRY[sid]
        lines.append(f"- {sid}: {s['description']}")
    return "\n".join(lines)


def get_skill_body(skill_id: str) -> str:
    s = SKILL_REGISTRY.get(skill_id)
    if not s:
        return ""
    return s.get("body") or s.get("method") or s.get("description", "")
