"""
BYO-LLM shim for the AURA pipeline.

This is the single seam that replaces AURA's hardcoded ``get_client_for_role``
(which pinned a provider/base-URL/model per orchestration role). Here every
orchestration call resolves the model from the USER's own configuration via
Echo's ``llm_resolver`` — so the orchestration agent is never hardcoded and the
platform's bring-your-own-LLM contract is preserved.

Notes:
  * ``component`` defaults to ``"orchestrator"`` which is a real role recognised
    by ``llm_resolver`` for app-tier credential resolution. Unknown components
    fall through safely (role = component) to Tier 1 (user) / Tier 3 (platform).
  * Returns a LangChain chat model (``framework="langchain"``) used via
    ``.invoke()`` — matching how Echo's existing designers already call it.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from echolib.llm_resolver import resolve_and_build_llm_sync

logger = logging.getLogger(__name__)

# Semantic default: the generation pipeline IS the orchestrator. Kept as a
# constant so every meta-agent resolves through the same credential role.
DEFAULT_COMPONENT = "orchestrator"


def get_orchestration_llm(
    user_id: Optional[str],
    component: str = DEFAULT_COMPONENT,
    temperature: float = 0.2,
    max_tokens: int = 4000,
):
    """Resolve a per-user LangChain chat model for an orchestration meta-agent.

    Raises whatever ``resolve_and_build_llm_sync`` raises when no credential can
    be resolved; callers degrade to a deterministic fallback rather than crash.
    """
    return resolve_and_build_llm_sync(
        user_id=user_id,
        component=component,
        temperature=temperature,
        max_tokens=max_tokens,
        allow_platform_fallback=True,
        framework="langchain",
    )


def invoke_text(llm: Any, prompt: str) -> str:
    """Invoke a LangChain chat model and return its text content (best-effort)."""
    response = llm.invoke(prompt)
    content = getattr(response, "content", None)
    if content is None:
        content = str(response)
    return content or ""
