"""
Stage 3 of the AURA pipeline: recruitment (plan -> concrete agent DAG).

Ported from AURA's ``recruiter_agent`` and rewired to Echo's BYO-LLM resolver
and Echo's ToolRegistry. Builds the minimal multi-agent DAG (parallel branches,
fan-in, human gates), assigns skills + Echo tool IDs, then applies the
deterministic enrichers.

Adaptation note: AURA's prompt hard-coded connector tool-naming conventions
(``db_*_tool`` etc.). Echo's connector tools have their own IDs and are shown in
the AVAILABLE TOOLS menu, so the prompt here instructs the model to use ONLY the
exact tool IDs from that menu — keeping the same DAG-design brain while staying
correct for Echo's registry.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional

from .llm import get_orchestration_llm, invoke_text
from .json_extract import extract_json
from . import skills as skills_mod
from . import tools as tools_mod
from .enrichers import enrich_agent_goals, apply_connector_hook

logger = logging.getLogger(__name__)


def recruit_agents(workflow_plan: Dict[str, Any], user_id: Optional[str] = None) -> List[dict]:
    """Turn a planner output into a concrete, runnable agent DAG. Never raises."""
    catalog = tools_mod.get_tool_catalog()
    valid_tools = set(catalog.keys())
    valid_skills = skills_mod.valid_skill_ids()
    tool_menu = tools_mod.build_tool_menu(catalog)
    skill_menu = skills_mod.get_skill_menu()

    system_prompt = f"""
You are the recruiter / orchestration agent.

Your job is to build the optimal MINIMAL multi-agent DAG for a given workflow plan.

========================================
AVAILABLE TOOLS (use ONLY these exact tool IDs — never invent names):
========================================
{tool_menu}

========================================
AVAILABLE SKILLS (assign from this list):
========================================
{skill_menu}

NOTE: Each skill automatically grants its own tools to the agent. If you assign a
skill you do NOT need to also list that skill's tools.

========================================
CORE PHILOSOPHY
========================================
- Create the MINIMUM viable number of agents
- Each agent must have a clear, distinct responsibility
- Assign skills that match the agent's role; assign tools the agent actually needs
- Connections define execution order: if B needs A's output -> B.connections = ["agent_a"]
- Data-fetch / research agents -> empty connections (they start the DAG)
- Analysis agents -> depend on data agents; write/report/notify agents -> come last

========================================
DAG STRUCTURE — PARALLELISM & DECISIONS
========================================
- If two or more steps are INDEPENDENT, give them NO dependency on each other so
  they run CONCURRENTLY.
- FAN-IN: a synthesis/analysis agent that needs several parallel outputs lists ALL
  of them in its connections (e.g. connections: ["source_a","source_b"]).
- Prefer parallel branches over a long single chain whenever steps are independent.

CONNECTOR / DATA TOOLS:
- Any database/API/connector tools the user configured appear in the AVAILABLE
  TOOLS menu above with their exact tool IDs. Assign those IDs to agents that
  query real data. Never invent a tool ID that is not in the menu.

HUMAN GATES (human control over risky actions):
- Insert a node with node_type "human_gate" BEFORE any irreversible/high-impact
  action (payments, external emails, deletes/publishes, sign-off). The risky
  action node then depends on the gate.
- Decision options are typically ["approve","reject","escalate"].

========================================
OUTPUT FORMAT
========================================
Return ONLY a valid JSON array. No markdown. No explanation.

[
  {{
    "agent_name": "snake_case_name",
    "role": "Human Readable Role",
    "goal": "Specific, actionable goal with an explicit OUTPUT CONTRACT",
    "skills": ["skill_id_from_list"],
    "tools": ["tool_id_from_menu"],
    "connections": ["agent_name_this_agent_depends_on"],
    "node_type": "tool_agent",
    "human_gate": null
  }}
]

A human_gate node looks like this (node_type "human_gate"):
  {{
    "agent_name": "manager_approval",
    "role": "Manager Approval Gate",
    "goal": "Approve before the irreversible action runs.",
    "skills": [], "tools": [],
    "connections": ["upstream_agent"],
    "node_type": "human_gate",
    "human_gate": {{"enabled": true, "gate_type": "approval",
                    "approver_role": "operator",
                    "decision_options": ["approve", "reject", "escalate"]}}
  }}

CRITICAL:
- skills must be IDs from the AVAILABLE SKILLS list (or [])
- tools must be exact tool IDs from the AVAILABLE TOOLS menu (or [])
- Never invent tool or skill names
- Use parallel branches when steps are independent; add a human_gate before risky actions
- Write DETAILED goals (3-6 sentences) including an explicit OUTPUT CONTRACT describing
  the exact structure each agent must return, so the next agent can parse it reliably
- The best workflow is minimal, efficient, structurally correct, and tool-precise
"""

    try:
        llm = get_orchestration_llm(user_id=user_id, temperature=0.2)
        content = invoke_text(
            llm,
            f"{system_prompt}\n\nWORKFLOW PLAN (JSON):\n{json.dumps(workflow_plan)}\n\nReturn ONLY the JSON array.",
        )
    except Exception as e:
        logger.warning("recruiter: llm failed, using stage-based fallback: %s", e)
        return _finalize(_fallback_agents(workflow_plan, valid_skills))

    agents = extract_json(content, kind="array")
    if isinstance(agents, dict):
        agents = agents.get("agents") or agents.get("workflow") or agents.get("nodes") or []

    if not isinstance(agents, list) or not agents:
        logger.warning("recruiter: no agent array found — using stage-based fallback DAG")
        return _finalize(_fallback_agents(workflow_plan, valid_skills))

    normalized = _normalize(agents, valid_skills, valid_tools)
    if not normalized:
        logger.warning("recruiter: no valid agents after normalization — using fallback DAG")
        return _finalize(_fallback_agents(workflow_plan, valid_skills))

    return _finalize(normalized)


def _normalize(agents: list, valid_skills: set, valid_tools: set) -> List[dict]:
    normalized: List[dict] = []
    for agent in agents:
        if not isinstance(agent, dict):
            continue
        name = (
            agent.get("agent_name") or agent.get("name")
            or agent.get("agent") or agent.get("id")
        )
        if not name:
            continue
        agent["agent_name"] = name
        agent.pop("name", None)
        agent.setdefault("role", str(name).replace("_", " ").title())
        agent.setdefault("goal", "")
        agent["skills"] = [s for s in (agent.get("skills") or []) if s in valid_skills]
        agent["tools"] = [t for t in (agent.get("tools") or []) if t in valid_tools]
        agent.setdefault("connections", [])

        gate = agent.get("human_gate")
        if gate or agent.get("node_type") == "human_gate":
            agent["node_type"] = "human_gate"
            if not isinstance(gate, dict):
                gate = {}
            gate.setdefault("enabled", True)
            gate.setdefault("gate_type", "approval")
            gate.setdefault("approver_role", "operator")
            gate.setdefault("decision_options", ["approve", "reject", "escalate"])
            agent["human_gate"] = gate
            agent["tools"] = []  # gates never run tools
        else:
            agent.setdefault("node_type", "tool_agent")

        normalized.append(agent)
    return normalized


def _fallback_agents(workflow_plan: Dict[str, Any], valid_skills: set) -> List[dict]:
    """Build a runnable linear DAG straight from the planner's stages."""
    stages = workflow_plan.get("workflow_stages") or []
    agents: List[dict] = []
    used: set[str] = set()
    prev: str | None = None

    for i, stage in enumerate(stages):
        if not isinstance(stage, dict):
            continue
        label = stage.get("name") or f"Stage {i + 1}"
        slug = re.sub(r"[^a-z0-9_]+", "_", label.strip().lower().replace(" ", "_")).strip("_") or f"stage_{i + 1}"
        while slug in used:
            slug = f"{slug}_{i}"
        used.add(slug)

        skills = [s for s in (stage.get("required_skills") or []) if s in valid_skills]
        tools = skills_mod.get_tools_for_skills(skills) if skills else []

        agents.append({
            "agent_name": slug,
            "role": label,
            "goal": stage.get("description") or stage.get("expected_output") or label,
            "skills": skills,
            "tools": tools,
            "connections": [prev] if prev else [],
            "node_type": "tool_agent",
        })
        prev = slug

    return agents


def _finalize(agents: List[dict]) -> List[dict]:
    """Apply the deterministic enrichment passes (connector wiring + contracts)."""
    return enrich_agent_goals(apply_connector_hook(agents))
