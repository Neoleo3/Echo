"""
Stage 2 of the AURA pipeline: workflow planning.

Ported from AURA's ``planner_agent`` and rewired to Echo's BYO-LLM resolver.
Designs a staged plan (workflow_stages with required_skills) that the recruiter
then turns into a concrete agent DAG. Model is resolved per-user; degrades to a
deterministic 4-stage fallback on any LLM failure.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .llm import get_orchestration_llm, invoke_text
from .json_extract import extract_json
from . import skills as skills_mod

logger = logging.getLogger(__name__)


def plan_workflow(goal: str, user_id: Optional[str] = None) -> Dict[str, Any]:
    """Design a staged workflow plan for ``goal``. Never raises."""
    skill_menu = skills_mod.get_skill_menu()
    valid_skills = skills_mod.valid_skill_ids()

    prompt = f"""
You are an elite AI workflow architect.
Your task is to design a multi-agent workflow to achieve the following goal.

USER GOAL:
{goal}

AVAILABLE SKILLS (use these when defining required_capabilities and stage skills):
{skill_menu}

Return ONLY valid JSON matching this schema exactly:

{{
    "workflow_goal": "string — precise restatement of the goal",
    "required_capabilities": ["skill_id_from_list", ...],
    "workflow_stages": [
        {{
            "name": "string",
            "description": "string",
            "required_skills": ["skill_id_from_list"],
            "expected_output": "string — what this stage produces"
        }}
    ]
}}

Rules:
- Return ONLY raw JSON, no markdown, no explanation
- Always create at least 4 workflow stages
- required_capabilities must only reference skill IDs from the AVAILABLE SKILLS list (use [] if none fit)
- required_skills inside each stage must also be from the AVAILABLE SKILLS list (use [] if none fit)
- expected_output should be concrete (e.g. "list of matched invoices with variance %")
"""

    try:
        llm = get_orchestration_llm(user_id=user_id, temperature=0.2)
        content = invoke_text(llm, prompt)
    except Exception as e:
        logger.warning("planner: llm failed, using fallback: %s", e)
        return _fallback(goal)

    if not content:
        return _fallback(goal)

    parsed = extract_json(content, kind="object")
    if not isinstance(parsed, dict):
        logger.warning("planner: could not extract JSON, using fallback")
        return _fallback(goal)

    stages = parsed.get("workflow_stages") or parsed.get("stages") or parsed.get("steps")
    if not stages:
        return _fallback(goal)
    parsed["workflow_stages"] = stages
    parsed.setdefault("workflow_goal", goal)

    # Validate skill IDs — strip unknown ones (empty registry => all stripped)
    parsed["required_capabilities"] = [
        s for s in parsed.get("required_capabilities", []) if s in valid_skills
    ]
    for i, stage in enumerate(parsed["workflow_stages"]):
        if isinstance(stage, dict):
            name = (
                stage.get("name") or stage.get("title")
                or stage.get("stage") or stage.get("step")
            )
            if not name:
                desc = stage.get("description") or stage.get("expected_output") or ""
                name = (desc.strip()[:40] or f"Stage {i + 1}")
            stage["name"] = name
            stage["required_skills"] = [
                s for s in stage.get("required_skills", []) if s in valid_skills
            ]

    return parsed


def _fallback(goal: str) -> Dict[str, Any]:
    # _degraded marks a generic, LLM-free template so the pipeline can tell the
    # user their workflow wasn't tailored (no model resolvable). Not a crash —
    # the user still gets a real, editable workflow.
    return {
        "_degraded": True,
        "workflow_goal": goal,
        "required_capabilities": [],
        "workflow_stages": [
            {"name": "Research", "description": "Collect relevant information",
             "required_skills": [], "expected_output": "Structured research findings"},
            {"name": "Analysis", "description": "Analyze collected data",
             "required_skills": [], "expected_output": "Analysis with key insights and risks"},
            {"name": "Planning", "description": "Generate strategic recommendations",
             "required_skills": [], "expected_output": "Action plan with priorities"},
            {"name": "Reporting", "description": "Prepare final report",
             "required_skills": [], "expected_output": "Structured professional report"},
        ],
    }
