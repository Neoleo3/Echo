"""
Execution primitives ported from AURA: policy gates, simulation, self-healing.

ADDITIVE + OPT-IN. These engage only when the execution ``context`` carries the
relevant flags (see keys below), so default Echo tool execution is byte-identical
when they are absent. Nothing here touches DB or session management.

Context keys (all optional):
  aura_simulation: bool                 -> skip real execution, return a no-op result
  aura_policy: {"allowed":[...], "denied":[...]}  -> allow/deny a tool before it runs
  aura_fallbacks: {tool_id: [fallback_tool_id, ...]}  -> self-healing fallback chain

P3 (Progressive Trust / simulation), P4 (Governed Autonomy / policy), and
P5 (Self-Healing / retry+fallback) from AURA, mapped onto Echo's ToolExecutor.
"""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── P4: Policy gate (governed autonomy) ─────────────────────────────
class PolicyGate:
    """Allow/deny tool execution. ``allowed=None`` means 'no allowlist' (allow
    all except denied). Denied always wins."""

    def __init__(self, allowed: Optional[List[str]] = None, denied: Optional[List[str]] = None):
        self.allowed = set(allowed) if allowed else None
        self.denied = set(denied or [])

    def is_allowed(self, tool_id: str) -> bool:
        if tool_id in self.denied:
            return False
        if self.allowed is not None and tool_id not in self.allowed:
            return False
        return True

    @classmethod
    def from_context(cls, context: Optional[Dict[str, Any]]) -> Optional["PolicyGate"]:
        pol = (context or {}).get("aura_policy")
        if not isinstance(pol, dict):
            return None
        return cls(allowed=pol.get("allowed"), denied=pol.get("denied"))


# ── P3: Simulation (no-op execution) ────────────────────────────────
def is_simulation(context: Optional[Dict[str, Any]]) -> bool:
    ctx = context or {}
    return bool(ctx.get("aura_simulation") or ctx.get("execution_mode") == "simulation")


def simulated_result(tool_id: str, input_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Deterministic stand-in returned instead of really running a tool."""
    return {
        "simulated": True,
        "tool_id": tool_id,
        "note": f"[SIMULATION] '{tool_id}' was not executed (progressive-trust mode).",
        "input_echo": input_data or {},
    }


# ── P5: Self-healing (retry + fallback tools) ───────────────────────
def _is_success(result: Any) -> bool:
    if result is None:
        return False
    success = getattr(result, "success", None)
    if success is None and isinstance(result, dict):
        success = result.get("success", True)  # dicts without a flag are assumed ok
    return bool(success) if success is not None else True


async def self_healing_invoke(
    invoke_fn: Callable[[str, Dict[str, Any], Optional[Dict[str, Any]]], Awaitable[Any]],
    tool_id: str,
    input_data: Dict[str, Any],
    context: Optional[Dict[str, Any]] = None,
    max_attempts: int = 2,
) -> Any:
    """Invoke ``tool_id`` with retry, then fall back to alternate tools.

    ``invoke_fn`` is any async ``(tool_id, input_data, context) -> result``
    (e.g. ``ToolExecutor.invoke``). Fallback chain comes from
    ``context['aura_fallbacks'][tool_id]``. Returns the first successful result,
    else the last result/error seen. Never raises.
    """
    fallbacks: List[str] = list(((context or {}).get("aura_fallbacks") or {}).get(tool_id, []))
    order = [tool_id] + fallbacks
    last: Any = None

    for tid in order:
        for attempt in range(max(1, max_attempts)):
            try:
                result = await invoke_fn(tid, input_data, context)
                if _is_success(result):
                    if tid != tool_id:
                        logger.info("self-healing: '%s' recovered via fallback '%s'", tool_id, tid)
                        _annotate(result, "self_healed_from", tool_id)
                    return result
                last = result
            except Exception as e:  # treat exceptions as a failed attempt
                logger.warning("self-healing: '%s' attempt %d failed: %s", tid, attempt + 1, e)
                last = {"success": False, "tool_id": tid, "error": str(e)}
        if fallbacks:
            logger.info("self-healing: '%s' exhausted, trying next fallback", tid)
    return last


def _annotate(result: Any, key: str, value: Any) -> None:
    try:
        if isinstance(result, dict):
            result.setdefault("metadata", {})[key] = value
        elif hasattr(result, "metadata") and isinstance(result.metadata, dict):
            result.metadata[key] = value
    except Exception:
        pass


def tool_context_from_exec(exec_config: Optional[Dict[str, Any]], base_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Merge a workflow's ``execution`` config into a tool-call context as AURA
    flags. Returns ``base_context`` unchanged when the config is empty/default,
    so execution stays byte-identical unless primitives are actually configured.
    """
    ctx = dict(base_context or {})
    if not exec_config:
        return ctx
    if exec_config.get("mode") == "simulation":
        ctx["aura_simulation"] = True
    policy = exec_config.get("policy")
    if isinstance(policy, dict) and (policy.get("denied") or policy.get("allowed")):
        ctx["aura_policy"] = policy
    fallbacks = exec_config.get("fallback_tools")
    if isinstance(fallbacks, dict) and fallbacks:
        ctx["aura_fallbacks"] = fallbacks
    return ctx


# ── Composed guard for the ToolExecutor seam ────────────────────────
def precheck(tool_id: str, input_data: Dict[str, Any], context: Optional[Dict[str, Any]]):
    """Run before real execution. Returns a (short_circuit, payload) tuple:
      (True, simulated_output_dict)  -> simulation: return this as the result
      (True, None)                   -> policy DENY: caller should fail the call
      (False, None)                  -> proceed with normal execution
    """
    if is_simulation(context):
        return True, simulated_result(tool_id, input_data)
    gate = PolicyGate.from_context(context)
    if gate is not None and not gate.is_allowed(tool_id):
        logger.info("policy gate: denied tool '%s'", tool_id)
        return True, None
    return False, None
