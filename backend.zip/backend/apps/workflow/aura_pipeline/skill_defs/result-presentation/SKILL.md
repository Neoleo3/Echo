---
name: result-presentation
display_name: Result Presentation
description: Renders a workflow's final merged results into clean, scannable Markdown
  for the end user — clear headings, ordered steps, best answer first — and produces
  a formal report document when one is required.
category: Operations
tools:
- report_tool
- document_report_tool
method: Take the merged upstream result as the single source of truth and render it
  as user-facing Markdown — best solution first, steps as numbered lists — without
  adding new facts.
example_use_cases:
- Display ranked IT solutions to the end user
- Render a reconciliation outcome as a readable summary
- Produce a downloadable report of the final results
---

# Result Presentation

Renders a workflow's final merged results into clean, scannable Markdown for the end user — clear headings, ordered steps, best answer first — and produces a formal report document when one is required.

## When to use
Assign this skill to the last agent of a workflow — the display/report node that turns the merged result into what the user actually reads.

## How to apply
Take the merged upstream result as the single source of truth and render it as user-facing Markdown — best solution first, steps as numbered lists — without adding new facts.

## Methodology
1. Use ONLY the upstream merged result — do not invent additional solutions or alter rankings.
2. Lead with the single best answer/recommendation in one or two sentences.
3. Render each item under a clear `###` heading with its steps as a numbered list and its source noted.
4. Keep it scannable: short lines, bold key actions, no filler prose.
5. If a formal deliverable is required, generate it with report_tool / document_report_tool after the Markdown.

## Tools this skill grants
- report_tool
- document_report_tool

## Example use cases
- Display ranked IT solutions to the end user
- Render a reconciliation outcome as a readable summary
- Produce a downloadable report of the final results
