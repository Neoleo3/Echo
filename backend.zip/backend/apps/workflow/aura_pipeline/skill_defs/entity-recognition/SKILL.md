---
name: entity-recognition
display_name: Entity Recognition
description: Identifies and extracts named entities — organisations, persons, locations,
  dates, monetary values — from text, and maps relationships between them.
category: Operations
tools:
- analysis_tool
method: Extract entities into typed groups (orgs, persons, dates, amounts) and note
  the relationships between them.
example_use_cases:
- Extract company names from filings
- Identify key persons in corporate documents
- Map entity relationships in transactions
---

# Entity Recognition

Identifies and extracts named entities — organisations, persons, locations, dates, monetary values — from text, and maps relationships between them.

## When to use
Assign this skill to an agent that must extract company names from filings, or related work in the Operations domain.

## How to apply
Extract entities into typed groups (orgs, persons, dates, amounts) and note the relationships between them.

## Methodology
1. Read the source text.
2. Extract named entities and group them by type (analysis_tool).
3. Normalise values (dates, amounts, names).
4. Map relationships between entities.
5. Return a structured entity/relationship summary.

## Tools this skill grants
- analysis_tool

## Example use cases
- Extract company names from filings
- Identify key persons in corporate documents
- Map entity relationships in transactions
