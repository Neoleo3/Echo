---
name: mcp-integration
display_name: MCP Integration
description: Uses tools exposed by connected MCP (Model Context Protocol) servers —
  external capability providers like file systems, ticketing bridges, or custom
  enterprise services — invoking the right MCP tool with correct arguments.
category: Operations
tools:
- mcp_*
method: Identify which connected MCP server tool matches the task, call it with
  arguments that match its schema, and relay the server's actual response into
  the workflow.
example_use_cases:
- Invoke a custom enterprise MCP service from a workflow
- Use an MCP file-system or document server as a data source
- Bridge to external systems exposed over MCP
---

# MCP Integration

Uses tools exposed by connected MCP (Model Context Protocol) servers — external capability providers like file systems, ticketing bridges, or custom enterprise services — invoking the right MCP tool with correct arguments.

## When to use
Assign this skill to an agent that must use capabilities provided by an MCP server connector. It automatically grants every registered MCP tool (mcp_*).

## How to apply
Identify which connected MCP server tool matches the task, call it with arguments that match its schema, and relay the server's actual response into the workflow.

## Methodology
1. Read each granted mcp_* tool description — it states which MCP server it belongs to and what it does.
2. Choose the single tool that matches the task; do not chain MCP tools speculatively.
3. Build the arguments exactly as the tool's schema describes (names and types matter).
4. Invoke the tool and read the server's response; treat it as the source of truth.
5. On an error response, correct the arguments and retry once, then report the failure honestly.

## Tools this skill grants
- mcp_* (every tool from connected MCP servers)

## Example use cases
- Invoke a custom enterprise MCP service from a workflow
- Use an MCP file-system or document server as a data source
- Bridge to external systems exposed over MCP
