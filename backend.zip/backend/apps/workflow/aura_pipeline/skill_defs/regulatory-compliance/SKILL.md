---
name: regulatory-compliance
display_name: Regulatory Compliance
description: Evaluates organisational adherence to applicable laws, regulations, and
  industry standards (GDPR, SOX, HIPAA, etc.) and produces a gap assessment with prioritised
  remediation.
category: Risk & Compliance
tools:
- web_search_tool
- analysis_tool
method: Identify the regulations in scope, then assess adherence control-by-control
  and produce a list of concrete gaps ranked by severity, each with a remediation
  action.
example_use_cases:
- Assess GDPR data-processing compliance
- Review SOX internal-control requirements
- Map regulatory obligations by jurisdiction
---

# Regulatory Compliance

Evaluates organisational adherence to applicable laws, regulations, and industry standards (GDPR, SOX, HIPAA, etc.) and produces a gap assessment with prioritised remediation.

## When to use
Assign this skill to an agent that must assess GDPR data-processing compliance, or related work in the Risk & Compliance domain.

## How to apply
Identify the regulations in scope, then assess adherence control-by-control and produce a list of concrete gaps ranked by severity, each with a remediation action.

## Methodology
1. Identify the regulations and standards that apply to the entity and activity.
2. Map each requirement to the controls/evidence that should satisfy it.
3. Assess adherence point-by-point and record gaps (research current rules with web_search_tool).
4. Rank gaps by severity and regulatory exposure (analysis_tool).
5. Recommend prioritised remediation with owners and a clear rationale.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Assess GDPR data-processing compliance
- Review SOX internal-control requirements
- Map regulatory obligations by jurisdiction
