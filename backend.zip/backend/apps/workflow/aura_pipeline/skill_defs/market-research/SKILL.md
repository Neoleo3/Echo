---
name: market-research
display_name: Market Research
description: Gathers and analyses market data, industry trends, competitive landscape,
  and growth opportunities, with claims tied to sources.
category: Data & Analytics
tools:
- web_search_tool
- analysis_tool
method: Search for current market data, then synthesise sizing, trends, and opportunities
  with a source cited for every material claim.
example_use_cases:
- Analyse market size and growth projections
- Map competitive positioning
- Identify emerging market opportunities
---

# Market Research

Gathers and analyses market data, industry trends, competitive landscape, and growth opportunities, with claims tied to sources.

## When to use
Assign this skill to an agent that must analyse market size and growth projections, or related work in the Data & Analytics domain.

## How to apply
Search for current market data, then synthesise sizing, trends, and opportunities with a source cited for every material claim.

## Methodology
1. Define the market, segment, and questions to answer.
2. Search for current data — size, growth, trends, players (web_search_tool).
3. Synthesise market sizing and growth projections (analysis_tool).
4. Identify trends, opportunities, and threats.
5. Summarise with sources cited for each material claim.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Analyse market size and growth projections
- Map competitive positioning
- Identify emerging market opportunities
