---
name: project-management
display_name: Project & Engagement Management
description: Plans and tracks delivery — building a work breakdown with milestones
  and dependencies, maintaining a RAID log (risks/assumptions/issues/dependencies),
  and producing concise status reports.
category: Advisory
tools:
- analysis_tool
- document_report_tool
method: Break the goal into a sequenced work plan with milestones and owners, maintain
  the RAID log, and produce a status report with progress, risks and next actions.
example_use_cases:
- Build a work plan with milestones and dependencies
- Maintain a RAID log for an engagement
- Produce a weekly delivery status report
---

# Project & Engagement Management

Plans and tracks delivery — building a work breakdown with milestones and dependencies, maintaining a RAID log (risks/assumptions/issues/dependencies), and producing concise status reports.

## When to use
Assign to a planning/PMO agent that structures an engagement or tracks delivery against a plan.

## How to apply
Break the goal into a sequenced work plan with milestones and owners, maintain the RAID log, and produce a status report with progress, risks and next actions.

## Methodology
1. Decompose the objective into a work breakdown structure with deliverables, owners and dependencies.
2. Sequence tasks into milestones with realistic durations and flag the critical path.
3. Maintain a RAID log: risks (with mitigation), assumptions, issues, and dependencies.
4. Assess current progress against plan (on track / at risk / slipped) per workstream.
5. Output a concise status report: progress, key risks/issues, decisions needed, and next actions.

## Tools this skill grants
- analysis_tool
- document_report_tool

## Example use cases
- Build a work plan with milestones and dependencies
- Maintain a RAID log for an engagement
- Produce a weekly delivery status report
