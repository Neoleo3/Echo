---
name: employee-onboarding
display_name: Employee Onboarding
description: Drives the new-hire onboarding lifecycle — account/system provisioning,
  equipment assignment, orientation scheduling, and stakeholder notification — producing
  a complete, sequenced checklist with owners and due dates.
category: People & HR
tools:
- analysis_tool
- document_report_tool
- email_tool
method: Build the onboarding checklist from the role and start date, sequence the
  provisioning and orientation tasks with owners and dates, and draft the notifications
  to each stakeholder.
example_use_cases:
- Generate a full onboarding checklist for a new analyst with owners and dates
- Determine the systems and access a role requires on day one
- Draft day-one welcome and stakeholder notification emails
---

# Employee Onboarding

Drives the new-hire onboarding lifecycle — account/system provisioning, equipment assignment, orientation scheduling, and stakeholder notification — producing a complete, sequenced checklist with owners and due dates.

## When to use
Assign to the agent that coordinates a new joiner: HR onboarding, IT provisioning hand-off, or the 'Employee Onboarding' workflow template.

## How to apply
Build the onboarding checklist from the role and start date, sequence the provisioning and orientation tasks with owners and dates, and draft the notifications to each stakeholder.

## Methodology
1. Read the new hire's role, department, start date and location from the request/upstream.
2. Derive the required accounts, systems and equipment for that role (least-privilege by default).
3. Sequence tasks across HR, IT and facilities with an owner and due date for each, gating anything that needs approval.
4. Schedule orientation/induction sessions and assign a buddy/manager check-in.
5. Draft notifications to each stakeholder and output a structured checklist (task, owner, due_date, status).

## Tools this skill grants
- analysis_tool
- document_report_tool
- email_tool

## Example use cases
- Generate a full onboarding checklist for a new analyst with owners and dates
- Determine the systems and access a role requires on day one
- Draft day-one welcome and stakeholder notification emails
