---
name: vendor-due-diligence
display_name: Vendor Due Diligence
description: Assesses third-party vendors for financial stability, compliance, security
  posture, and operational risk, producing an overall risk rating.
category: Operations
tools:
- web_search_tool
- sap_read_tool
- analysis_tool
method: Pull vendor records, assess financial, compliance, and security posture, then
  assign an overall risk rating with the evidence behind it.
example_use_cases:
- Evaluate vendor SOC 2 compliance
- Assess vendor financial-health indicators
- Review vendor data-handling practices
---

# Vendor Due Diligence

Assesses third-party vendors for financial stability, compliance, security posture, and operational risk, producing an overall risk rating.

## When to use
Assign this skill to an agent that must evaluate vendor SOC 2 compliance, or related work in the Operations domain.

## How to apply
Pull vendor records, assess financial, compliance, and security posture, then assign an overall risk rating with the evidence behind it.

## Methodology
1. Gather vendor records and public information (sap_read_tool, web_search_tool).
2. Assess financial health and stability.
3. Review compliance and security posture (e.g. SOC 2, data handling).
4. Evaluate operational and concentration risk (analysis_tool).
5. Assign an overall risk rating with supporting evidence.

## Tools this skill grants
- web_search_tool
- sap_read_tool
- analysis_tool

## Example use cases
- Evaluate vendor SOC 2 compliance
- Assess vendor financial-health indicators
- Review vendor data-handling practices
