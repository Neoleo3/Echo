---
name: procurement-sourcing
display_name: Procurement & Sourcing
description: Runs sourcing analysis — comparing supplier quotes on total cost of ownership,
  normalizing bids, scoring against weighted criteria, and recommending an award with
  spend and savings rationale.
category: Finance Operations
tools:
- web_search_tool
- calculator_tool
- analysis_tool
method: Normalize supplier quotes to a common basis, score them on weighted criteria
  with the calculator, and recommend an award with the total-cost-of-ownership and
  savings rationale.
example_use_cases:
- Compare supplier quotes on total cost of ownership
- Score RFQ responses against weighted award criteria
- Recommend a vendor award with savings rationale
---

# Procurement & Sourcing

Runs sourcing analysis — comparing supplier quotes on total cost of ownership, normalizing bids, scoring against weighted criteria, and recommending an award with spend and savings rationale.

## When to use
Assign to a sourcing/RFQ-evaluation agent that compares vendor bids before a procurement decision.

## How to apply
Normalize supplier quotes to a common basis, score them on weighted criteria with the calculator, and recommend an award with the total-cost-of-ownership and savings rationale.

## Methodology
1. Extract each supplier's price, terms, lead time and scope from the quotes/RFQ responses.
2. Normalize to total cost of ownership (unit price, freight, taxes, payment terms) with calculator_tool.
3. Score suppliers against weighted criteria (cost, quality, risk, delivery); research supplier viability if needed.
4. Quantify savings vs. the baseline/incumbent and note single-source or concentration risk.
5. Recommend an award with a transparent scoring table and the rationale for the chosen supplier.

## Tools this skill grants
- web_search_tool
- calculator_tool
- analysis_tool

## Example use cases
- Compare supplier quotes on total cost of ownership
- Score RFQ responses against weighted award criteria
- Recommend a vendor award with savings rationale
