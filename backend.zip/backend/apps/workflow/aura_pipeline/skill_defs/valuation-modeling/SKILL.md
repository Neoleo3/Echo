---
name: valuation-modeling
display_name: Valuation Modeling
description: Builds enterprise and equity valuations using discounted cash flow (DCF),
  comparable-company, and precedent-transaction methods, producing a defensible valuation
  range with explicit assumptions.
category: Advisory
tools:
- calculator_tool
- analysis_tool
method: Compute the valuation numerically with the calculator (cash flows, WACC, terminal
  value, multiples), state every assumption explicitly, then triangulate methods into
  a range rather than a single point.
example_use_cases:
- Build a DCF model for an acquisition target
- Derive WACC and terminal value
- Benchmark valuation multiples against peers
---

# Valuation Modeling

Builds enterprise and equity valuations using discounted cash flow (DCF), comparable-company, and precedent-transaction methods, producing a defensible valuation range with explicit assumptions.

## When to use
Assign this skill to an agent that must build a DCF model for an acquisition target, or related work in the Advisory domain.

## How to apply
Compute the valuation numerically with the calculator (cash flows, WACC, terminal value, multiples), state every assumption explicitly, then triangulate methods into a range rather than a single point.

## Methodology
1. Gather the target's financials and the relevant market comparables / precedent transactions.
2. Build a DCF: project free cash flows, derive WACC, and compute terminal value (use calculator_tool).
3. Cross-check with comparable-company and precedent-transaction multiples.
4. Run sensitivity on the key drivers (growth, margin, discount rate).
5. Reconcile the methods into a valuation range and document every assumption.

## Tools this skill grants
- calculator_tool
- analysis_tool

## Example use cases
- Build a DCF model for an acquisition target
- Derive WACC and terminal value
- Benchmark valuation multiples against peers
