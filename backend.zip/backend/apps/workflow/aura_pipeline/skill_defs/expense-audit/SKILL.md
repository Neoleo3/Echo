---
name: expense-audit
display_name: Expense Report Audit (T&E)
description: Audits employee expense reports against T&E policy — checking category
  limits, required receipts, duplicates, out-of-policy items and approval thresholds,
  and routing exceptions for review.
category: Finance Operations
tools:
- calculator_tool
- analysis_tool
method: Check each expense line against the T&E policy limits and receipt rules with
  the calculator, detect duplicates and policy breaches, and output a per-line verdict
  with the exact rule cited.
example_use_cases:
- Flag out-of-policy and missing-receipt expense lines
- Detect duplicate or split expense claims
- Route an expense report to the correct approval level
---

# Expense Report Audit (T&E)

Audits employee expense reports against T&E policy — checking category limits, required receipts, duplicates, out-of-policy items and approval thresholds, and routing exceptions for review.

## When to use
Assign to the policy-check agent in an expense-approval pipeline (the 'Expense Report Approval' template); pair with a human gate before reimbursement.

## How to apply
Check each expense line against the T&E policy limits and receipt rules with the calculator, detect duplicates and policy breaches, and output a per-line verdict with the exact rule cited.

## Methodology
1. Read the expense report lines (date, category, amount, merchant, receipt flag) and the applicable T&E policy.
2. Check each line against its category limit and required-receipt rule; recompute totals with calculator_tool.
3. Detect duplicate submissions, split charges to evade limits, weekend/personal items and missing receipts.
4. Compare the report total against the approver's authority threshold to determine the routing level.
5. Output per-line verdicts (pass / flag) with the exact policy rule cited, plus an overall recommendation.

## Tools this skill grants
- calculator_tool
- analysis_tool

## Example use cases
- Flag out-of-policy and missing-receipt expense lines
- Detect duplicate or split expense claims
- Route an expense report to the correct approval level
