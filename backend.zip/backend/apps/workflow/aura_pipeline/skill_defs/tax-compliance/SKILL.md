---
name: tax-compliance
display_name: Tax Compliance (VAT/GST)
description: Verifies the tax treatment on an invoice — recomputing VAT/GST from
  the stated rate and taxable base, checking rate plausibility for the jurisdiction,
  and confirming required tax fields (tax IDs, rate, amount) are present and consistent.
category: Risk & Compliance
tools:
- calculator_tool
- analysis_tool
method: Recompute the tax from the invoice's taxable base and stated rate with the
  calculator, compare it to the tax amount on the invoice, and verify required tax
  fields and rate plausibility — reporting any mismatch precisely.
example_use_cases:
- Recompute VAT/GST and compare with the invoiced tax amount
- Check that tax registration numbers are present
- Flag implausible tax rates for the jurisdiction
---

# Tax Compliance (VAT/GST)

Verifies the tax treatment on an invoice — recomputing VAT/GST from the stated rate and taxable base, checking rate plausibility for the jurisdiction, and confirming required tax fields (tax IDs, rate, amount) are present and consistent.

## When to use
Assign this skill to the tax-check agent in an invoice pipeline — it validates the tax math and required tax metadata on the parsed invoice.

## How to apply
Recompute the tax from the invoice's taxable base and stated rate with the calculator, compare it to the tax amount on the invoice, and verify required tax fields and rate plausibility — reporting any mismatch precisely.

## Methodology
1. Read the parsed invoice's taxable base, stated tax rate and tax amount from upstream.
2. Recompute tax = base × rate with calculator_tool and compare against the invoiced tax amount (note rounding tolerance).
3. Check required fields: supplier tax/VAT/GST registration number, tax rate shown, tax amount itemised.
4. Sanity-check the rate against common jurisdiction rates (e.g. 5/12/18/28% GST, 0–27% VAT); flag implausible rates.
5. Output a compliance verdict: computed vs invoiced tax, field checklist, and each issue stated exactly — never guess missing values.

## Tools this skill grants
- calculator_tool
- analysis_tool

## Example use cases
- Recompute VAT/GST and compare with the invoiced tax amount
- Check that tax registration numbers are present
- Flag implausible tax rates for the jurisdiction
