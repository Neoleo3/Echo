---
name: deal-structuring
display_name: Deal Structuring
description: Designs optimal transaction structures for mergers, acquisitions, divestitures,
  and joint ventures, balancing tax, legal, risk, and cash considerations.
category: Advisory
tools:
- analysis_tool
- calculator_tool
method: Compare structural options (asset vs share, earn-outs, escrows) on tax, risk,
  and cash impact; quantify the trade-offs with the calculator before recommending
  a structure.
example_use_cases:
- Evaluate asset vs share purchase options
- Model earn-out and escrow mechanisms
- Assess cross-border deal implications
---

# Deal Structuring

Designs optimal transaction structures for mergers, acquisitions, divestitures, and joint ventures, balancing tax, legal, risk, and cash considerations.

## When to use
Assign this skill to an agent that must evaluate asset vs share purchase options, or related work in the Advisory domain.

## How to apply
Compare structural options (asset vs share, earn-outs, escrows) on tax, risk, and cash impact; quantify the trade-offs with the calculator before recommending a structure.

## Methodology
1. Clarify the deal objective, parties, and constraints.
2. Enumerate viable structures (asset vs share purchase, merger, JV, earn-out/escrow).
3. Quantify each option's tax, cash, and risk impact (calculator_tool).
4. Assess cross-border, regulatory, and integration implications.
5. Recommend the structure that best meets the objective and explain the trade-offs.

## Tools this skill grants
- analysis_tool
- calculator_tool

## Example use cases
- Evaluate asset vs share purchase options
- Model earn-out and escrow mechanisms
- Assess cross-border deal implications
