---
name: financial-close
display_name: Financial Close & Reconciliation
description: Supports the period-end close — account reconciliations, accruals/prepayments,
  journal-entry review and close-checklist tracking — reconciling sub-ledger to GL
  and flagging unexplained differences.
category: Finance Operations
tools:
- db_*_tool
- db_schema_tool
- calculator_tool
- analysis_tool
method: Reconcile sub-ledger balances to the GL with the database and calculator,
  validate accruals and journal entries, and report every unexplained difference with
  its evidence.
example_use_cases:
- Reconcile a sub-ledger to the general ledger for month-end
- Validate period-end accrual and prepayment journals
- Track outstanding items on the close checklist
---

# Financial Close & Reconciliation

Supports the period-end close — account reconciliations, accruals/prepayments, journal-entry review and close-checklist tracking — reconciling sub-ledger to GL and flagging unexplained differences.

## When to use
Assign to a month-end/period-close agent that reconciles accounts and validates entries before sign-off.

## How to apply
Reconcile sub-ledger balances to the GL with the database and calculator, validate accruals and journal entries, and report every unexplained difference with its evidence.

## Methodology
1. Check the schema, then pull the relevant GL and sub-ledger balances for the period via the database tool.
2. Reconcile sub-ledger to GL per account; compute differences with calculator_tool and apply a materiality threshold.
3. Validate accruals, prepayments and reclass journals for completeness and correct period.
4. Flag unreconciled items, unusual manual journals (round numbers, period-end timing) and missing support.
5. Output a close status: reconciled accounts, exceptions with evidence, and outstanding checklist items.

## Tools this skill grants
- db_*_tool
- db_schema_tool
- calculator_tool
- analysis_tool

## Example use cases
- Reconcile a sub-ledger to the general ledger for month-end
- Validate period-end accrual and prepayment journals
- Track outstanding items on the close checklist
