---
name: po-matching
display_name: PO / GRN Matching
description: Performs accounts-payable 2-way and 3-way matching — comparing an
  invoice against its purchase order (and goods-receipt note when available) on
  vendor, quantities and amounts, classifying each line as matched or discrepant.
category: Operations
tools:
- db_*_tool
- db_schema_tool
- calculator_tool
method: Look up the invoice's purchase order in the connected database, compare
  vendor, amounts and quantities line by line (2-way; include the GRN for 3-way),
  and classify each comparison as matched, within tolerance, or discrepant.
example_use_cases:
- 2-way match an invoice against its purchase order
- 3-way match invoice, PO and goods-receipt note
- Flag price or quantity discrepancies beyond tolerance
---

# PO / GRN Matching

Performs accounts-payable 2-way and 3-way matching — comparing an invoice against its purchase order (and goods-receipt note when available) on vendor, quantities and amounts, classifying each line as matched or discrepant.

## When to use
Assign this skill to the matching agent in an invoice-processing pipeline — the step that validates a parsed invoice against procurement records in the connected database.

## How to apply
Look up the invoice's purchase order in the connected database, compare vendor, amounts and quantities line by line (2-way; include the GRN for 3-way), and classify each comparison as matched, within tolerance, or discrepant.

## Methodology
1. Check the schema (db_schema_tool) and query the purchase-orders table for the invoice's PO reference or vendor (db_*_tool).
2. 2-way match: compare invoice vendor, currency, line quantities, unit prices and totals against the PO.
3. 3-way match (when a goods-receipt table exists): also compare received quantities against billed quantities.
4. Quantify each difference with calculator_tool (amount and percentage) and classify: matched / within tolerance / discrepant.
5. Output a per-line match table plus an overall verdict, citing the actual PO values returned by the database.

## Tools this skill grants
- db_*_tool (connected procurement databases)
- db_schema_tool
- calculator_tool

## Example use cases
- 2-way match an invoice against its purchase order
- 3-way match invoice, PO and goods-receipt note
- Flag price or quantity discrepancies beyond tolerance
