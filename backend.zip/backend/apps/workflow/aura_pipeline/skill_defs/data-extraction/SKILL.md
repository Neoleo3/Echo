---
name: data-extraction
display_name: Data Extraction
description: Extracts structured data from documents, databases, APIs, and unstructured
  sources using parsing and NLP, returning clean, source-cited records.
category: Data & Analytics
tools:
- web_search_tool
- sharepoint_read_tool
- sap_read_tool
method: Pull from the appropriate source tool (SharePoint, SAP, web), normalise the
  output into clean structured records, and cite where each value came from.
example_use_cases:
- Extract key terms from contracts
- Parse financial data from PDF reports
- Pull data from regulatory filings
---

# Data Extraction

Extracts structured data from documents, databases, APIs, and unstructured sources using parsing and NLP, returning clean, source-cited records.

## When to use
Assign this skill to an agent that must extract key terms from contracts, or related work in the Data & Analytics domain.

## How to apply
Pull from the appropriate source tool (SharePoint, SAP, web), normalise the output into clean structured records, and cite where each value came from.

## Methodology
1. Identify what data is needed and which source holds it.
2. Retrieve it via the right tool (sharepoint_read_tool, sap_read_tool, or web_search_tool).
3. Parse and normalise into consistent structured fields.
4. Validate completeness and flag missing/ambiguous values.
5. Return clean records with the source of each value cited.

## Tools this skill grants
- web_search_tool
- sharepoint_read_tool
- sap_read_tool

## Example use cases
- Extract key terms from contracts
- Parse financial data from PDF reports
- Pull data from regulatory filings
