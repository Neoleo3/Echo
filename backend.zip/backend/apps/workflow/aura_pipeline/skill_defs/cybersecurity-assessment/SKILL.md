---
name: cybersecurity-assessment
display_name: Cybersecurity Assessment
description: Assesses security posture against a framework (NIST CSF, ISO 27001, CIS)
  — mapping controls, identifying gaps and vulnerabilities, rating risk, and prioritizing
  remediation.
category: IT & Security
tools:
- analysis_tool
- web_search_tool
- report_tool
method: Map the environment's controls to the chosen framework, identify and risk-rate
  gaps, and produce a prioritized remediation plan citing the specific control reference.
example_use_cases:
- Assess controls against NIST CSF or ISO 27001
- Risk-rate and prioritize security gaps for remediation
- Map an environment's controls and flag what's missing
---

# Cybersecurity Assessment

Assesses security posture against a framework (NIST CSF, ISO 27001, CIS) — mapping controls, identifying gaps and vulnerabilities, rating risk, and prioritizing remediation.

## When to use
Assign to a security-review/assessment agent evaluating controls or findings against a recognized framework.

## How to apply
Map the environment's controls to the chosen framework, identify and risk-rate gaps, and produce a prioritized remediation plan citing the specific control reference.

## Methodology
1. Identify the in-scope assets/systems and the assessment framework (NIST CSF, ISO 27001 Annex A, CIS).
2. Map existing controls to the framework's requirements; mark each implemented / partial / missing.
3. Identify vulnerabilities and control gaps; rate each by likelihood x impact.
4. Reference current threat/advisory information for relevant vulnerabilities when needed.
5. Output a prioritized remediation plan: gap, control reference, risk rating, and recommended fix.

## Tools this skill grants
- analysis_tool
- web_search_tool
- report_tool

## Example use cases
- Assess controls against NIST CSF or ISO 27001
- Risk-rate and prioritize security gaps for remediation
- Map an environment's controls and flag what's missing
