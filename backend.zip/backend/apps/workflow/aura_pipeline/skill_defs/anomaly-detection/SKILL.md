---
name: anomaly-detection
display_name: Anomaly Detection
description: Identifies statistical outliers and unusual patterns in datasets using
  analytical techniques, quantifying how far each anomaly deviates from the norm.
category: Data & Analytics
tools:
- analysis_tool
- calculator_tool
method: Establish a baseline, flag deviations with their magnitude, and explain why
  each is anomalous so downstream agents can act on it.
example_use_cases:
- Detect unusual transaction patterns
- Identify revenue-recognition outliers
- Flag procurement-spend anomalies
---

# Anomaly Detection

Identifies statistical outliers and unusual patterns in datasets using analytical techniques, quantifying how far each anomaly deviates from the norm.

## When to use
Assign this skill to an agent that must detect unusual transaction patterns, or related work in the Data & Analytics domain.

## How to apply
Establish a baseline, flag deviations with their magnitude, and explain why each is anomalous so downstream agents can act on it.

## Methodology
1. Define the expected baseline/distribution for the data.
2. Detect outliers and unusual patterns (calculator_tool + analysis_tool).
3. Quantify each anomaly's magnitude and direction.
4. Explain the likely cause and whether it signals risk or opportunity.
5. Rank anomalies by significance.

## Tools this skill grants
- analysis_tool
- calculator_tool

## Example use cases
- Detect unusual transaction patterns
- Identify revenue-recognition outliers
- Flag procurement-spend anomalies
