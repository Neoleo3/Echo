---
name: audit-planning
display_name: Audit Planning
description: 'Develops risk-based audit plans: defines scope, sets materiality, identifies
  high-risk areas, and allocates resources for internal or external engagements.'
category: Audit
tools:
- analysis_tool
method: Assess risk and materiality first, then scope the audit around the highest-risk
  areas and lay out a resourced timeline.
example_use_cases:
- Assess materiality thresholds
- Identify high-risk audit areas
- Build an audit timeline and resource allocation
---

# Audit Planning

Develops risk-based audit plans: defines scope, sets materiality, identifies high-risk areas, and allocates resources for internal or external engagements.

## When to use
Assign this skill to an agent that must assess materiality thresholds, or related work in the Audit domain.

## How to apply
Assess risk and materiality first, then scope the audit around the highest-risk areas and lay out a resourced timeline.

## Methodology
1. Understand the entity, its processes, and the engagement objective.
2. Perform a risk assessment and set materiality thresholds (analysis_tool).
3. Identify and prioritise high-risk audit areas.
4. Define scope, sampling approach, and required evidence.
5. Produce a resourced audit plan and timeline.

## Tools this skill grants
- analysis_tool

## Example use cases
- Assess materiality thresholds
- Identify high-risk audit areas
- Build an audit timeline and resource allocation
