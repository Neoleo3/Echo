---
name: fraud-detection
display_name: Fraud Detection
description: Identifies indicators of fraud through data analysis, pattern recognition,
  and forensic-accounting techniques such as duplicate detection and Benford's-law
  analysis.
category: Risk & Compliance
tools:
- analysis_tool
- calculator_tool
method: Establish a baseline, surface anomalies (duplicates, ghost vendors, Benford
  deviations), quantify each indicator, and rank findings by likelihood of fraud.
example_use_cases:
- Analyse journal entries for anomalies
- Detect duplicate payments or ghost vendors
- Apply Benford's-law analysis
---

# Fraud Detection

Identifies indicators of fraud through data analysis, pattern recognition, and forensic-accounting techniques such as duplicate detection and Benford's-law analysis.

## When to use
Assign this skill to an agent that must analyse journal entries for anomalies, or related work in the Risk & Compliance domain.

## How to apply
Establish a baseline, surface anomalies (duplicates, ghost vendors, Benford deviations), quantify each indicator, and rank findings by likelihood of fraud.

## Methodology
1. Establish the normal baseline for the dataset (volumes, vendors, amounts).
2. Detect anomalies: duplicate payments, ghost/unusual vendors, round-number bias, Benford deviations (calculator_tool + analysis_tool).
3. Quantify the magnitude and frequency of each indicator.
4. Rank findings by fraud likelihood and potential impact.
5. Recommend investigation steps for the highest-risk items.

## Tools this skill grants
- analysis_tool
- calculator_tool

## Example use cases
- Analyse journal entries for anomalies
- Detect duplicate payments or ghost vendors
- Apply Benford's-law analysis
