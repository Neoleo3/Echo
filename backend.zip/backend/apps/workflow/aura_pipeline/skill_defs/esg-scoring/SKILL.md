---
name: esg-scoring
display_name: ESG Scoring
description: Assesses Environmental, Social, and Governance performance against established
  frameworks (GRI, SASB, TCFD), producing justified sub-scores.
category: Data & Analytics
tools:
- web_search_tool
- analysis_tool
method: Score E, S, and G separately against a named framework and justify each sub-score
  with evidence and the data source.
example_use_cases:
- Score carbon-emission performance
- Evaluate board-diversity metrics
- Assess supply-chain labour practices
---

# ESG Scoring

Assesses Environmental, Social, and Governance performance against established frameworks (GRI, SASB, TCFD), producing justified sub-scores.

## When to use
Assign this skill to an agent that must score carbon-emission performance, or related work in the Data & Analytics domain.

## How to apply
Score E, S, and G separately against a named framework and justify each sub-score with evidence and the data source.

## Methodology
1. Select the applicable ESG framework (GRI/SASB/TCFD).
2. Gather ESG data and disclosures (web_search_tool).
3. Score Environmental, Social, and Governance dimensions separately (analysis_tool).
4. Justify each sub-score with evidence.
5. Produce an overall rating and flag the biggest gaps.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Score carbon-emission performance
- Evaluate board-diversity metrics
- Assess supply-chain labour practices
