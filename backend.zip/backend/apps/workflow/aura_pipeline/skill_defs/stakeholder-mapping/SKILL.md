---
name: stakeholder-mapping
display_name: Stakeholder Mapping
description: Identifies, categorises, and analyses stakeholders by influence, interest,
  and relationship to the engagement, and recommends engagement approaches.
category: Operations
tools:
- web_search_tool
- analysis_tool
method: Identify the stakeholders, plot each by influence and interest, and recommend
  how to engage each group.
example_use_cases:
- Map decision-makers in acquisition targets
- Identify key regulatory stakeholders
- Assess stakeholder sentiment and alignment
---

# Stakeholder Mapping

Identifies, categorises, and analyses stakeholders by influence, interest, and relationship to the engagement, and recommends engagement approaches.

## When to use
Assign this skill to an agent that must map decision-makers in acquisition targets, or related work in the Operations domain.

## How to apply
Identify the stakeholders, plot each by influence and interest, and recommend how to engage each group.

## Methodology
1. Identify all relevant stakeholders (research with web_search_tool).
2. Categorise each by influence, interest, and relationship.
3. Plot them on an influence/interest grid (analysis_tool).
4. Assess sentiment and alignment.
5. Recommend a tailored engagement approach per group.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Map decision-makers in acquisition targets
- Identify key regulatory stakeholders
- Assess stakeholder sentiment and alignment
