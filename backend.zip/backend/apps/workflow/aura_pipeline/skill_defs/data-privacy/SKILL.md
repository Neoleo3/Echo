---
name: data-privacy
display_name: Data Privacy & GDPR Compliance
description: Assesses personal-data handling against privacy law (GDPR, DPDP, CCPA)
  — identifying PII and lawful basis, checking retention and cross-border transfer,
  and handling data-subject requests (DSARs).
category: Risk & Compliance
tools:
- analysis_tool
- report_tool
method: Identify the personal data and its lawful basis, check processing against
  the applicable privacy regime (purpose, retention, transfer), and report gaps or
  fulfil the DSAR precisely.
example_use_cases:
- Assess a process for GDPR/DPDP compliance gaps
- Identify PII and its lawful basis in a dataset
- Scope and structure a data-subject access request response
---

# Data Privacy & GDPR Compliance

Assesses personal-data handling against privacy law (GDPR, DPDP, CCPA) — identifying PII and lawful basis, checking retention and cross-border transfer, and handling data-subject requests (DSARs).

## When to use
Assign to a privacy-review or DSAR-handling agent assessing how personal data is collected, stored or shared.

## How to apply
Identify the personal data and its lawful basis, check processing against the applicable privacy regime (purpose, retention, transfer), and report gaps or fulfil the DSAR precisely.

## Methodology
1. Identify the personal/sensitive data elements in scope and the data subjects involved.
2. Determine the lawful basis and purpose for each processing activity; check it is documented.
3. Check retention periods, minimization and cross-border transfer safeguards against the applicable law.
4. For a DSAR, scope the request type (access/erasure/rectification) and the records that fall in scope.
5. Output findings: data inventory, lawful basis, gaps with the article/section cited, and required actions.

## Tools this skill grants
- analysis_tool
- report_tool

## Example use cases
- Assess a process for GDPR/DPDP compliance gaps
- Identify PII and its lawful basis in a dataset
- Scope and structure a data-subject access request response
