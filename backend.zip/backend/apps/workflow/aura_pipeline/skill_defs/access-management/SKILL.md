---
name: access-management
display_name: Identity & Access Management
description: Handles access provisioning/deprovisioning and reviews — applying least-privilege
  and segregation-of-duties rules, detecting toxic role combinations and orphaned/stale
  accounts, and recommending grants or revocations.
category: IT & Security
tools:
- analysis_tool
- db_*_tool
- db_schema_tool
method: Evaluate each access request or review against least-privilege and segregation-of-duties
  rules, detect SoD conflicts and stale accounts, and recommend grant/revoke decisions
  with the rule cited.
example_use_cases:
- Review an access request against least-privilege rules
- Detect segregation-of-duties conflicts in a role assignment
- Find orphaned or over-privileged accounts in an access review
---

# Identity & Access Management

Handles access provisioning/deprovisioning and reviews — applying least-privilege and segregation-of-duties rules, detecting toxic role combinations and orphaned/stale accounts, and recommending grants or revocations.

## When to use
Assign to an access-request approval or periodic user-access-review agent; pair revocations/grants to privileged systems with a human gate.

## How to apply
Evaluate each access request or review against least-privilege and segregation-of-duties rules, detect SoD conflicts and stale accounts, and recommend grant/revoke decisions with the rule cited.

## Methodology
1. Read the user, role/entitlements requested (or under review) and the relevant access policy.
2. Apply least privilege: confirm each entitlement is justified by the job function.
3. Check segregation-of-duties matrices for toxic combinations (e.g. create + approve payments).
4. Detect orphaned, dormant or over-privileged accounts when reviewing existing access.
5. Recommend grant/revoke per entitlement with the rule cited; route privileged changes to approval.

## Tools this skill grants
- analysis_tool
- db_*_tool
- db_schema_tool

## Example use cases
- Review an access request against least-privilege rules
- Detect segregation-of-duties conflicts in a role assignment
- Find orphaned or over-privileged accounts in an access review
