---
name: kyc-verification
display_name: KYC Verification
description: 'Conducts Know-Your-Customer due diligence: identity verification, beneficial-ownership
  analysis, PEP/sanctions checks, and customer risk categorisation.'
category: Risk & Compliance
tools:
- web_search_tool
- analysis_tool
method: Verify identity and beneficial ownership, screen against PEP/sanctions lists,
  then assign a risk tier with the evidence that supports it.
example_use_cases:
- Verify corporate ownership structures
- Classify customer risk tiers
- Check PEP and sanctions exposure
---

# KYC Verification

Conducts Know-Your-Customer due diligence: identity verification, beneficial-ownership analysis, PEP/sanctions checks, and customer risk categorisation.

## When to use
Assign this skill to an agent that must verify corporate ownership structures, or related work in the Risk & Compliance domain.

## How to apply
Verify identity and beneficial ownership, screen against PEP/sanctions lists, then assign a risk tier with the evidence that supports it.

## Methodology
1. Collect and verify the customer's identity and corporate ownership structure.
2. Trace beneficial owners and controllers (research with web_search_tool).
3. Screen individuals/entities against PEP and sanctions lists.
4. Assign a KYC risk tier (low/medium/high) with documented evidence (analysis_tool).
5. Flag any item requiring enhanced due diligence.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Verify corporate ownership structures
- Classify customer risk tiers
- Check PEP and sanctions exposure
