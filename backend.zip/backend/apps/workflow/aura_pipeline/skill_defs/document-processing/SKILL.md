---
name: document-processing
display_name: Document Processing
description: Ingests, classifies, and organises documents by type, relevance, and
  metadata to prepare them for downstream analysis.
category: Operations
tools:
- sharepoint_read_tool
- local_invoice_fixture_tool
method: Retrieve documents from the source, classify and tag each by type and relevance,
  and structure them for downstream agents.
example_use_cases:
- Classify legal vs financial documents
- Tag documents with metadata and relevance
- Build document inventories for data rooms
---

# Document Processing

Ingests, classifies, and organises documents by type, relevance, and metadata to prepare them for downstream analysis.

## When to use
Assign this skill to an agent that must classify legal vs financial documents, or related work in the Operations domain.

## How to apply
Retrieve documents from the source, classify and tag each by type and relevance, and structure them for downstream agents.

## Methodology
1. Retrieve the documents from their source (sharepoint_read_tool / local fixture).
2. Classify each by type (legal, financial, operational).
3. Tag with metadata and a relevance score.
4. Organise into a structured inventory.
5. Hand the structured set to downstream analysis agents.

## Tools this skill grants
- sharepoint_read_tool
- local_invoice_fixture_tool

## Example use cases
- Classify legal vs financial documents
- Tag documents with metadata and relevance
- Build document inventories for data rooms
