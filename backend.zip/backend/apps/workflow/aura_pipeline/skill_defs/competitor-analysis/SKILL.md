---
name: competitor-analysis
display_name: Competitor Analysis
description: Researches and benchmarks competitors on strategy, financials, products,
  market share, and operational efficiency.
category: Data & Analytics
tools:
- web_search_tool
- analysis_tool
method: Gather competitor data, then benchmark side-by-side on consistent metrics
  and highlight relative strengths and weaknesses.
example_use_cases:
- Compare revenue growth across competitors
- Analyse competitor product portfolios
- Benchmark operational KPIs
---

# Competitor Analysis

Researches and benchmarks competitors on strategy, financials, products, market share, and operational efficiency.

## When to use
Assign this skill to an agent that must compare revenue growth across competitors, or related work in the Data & Analytics domain.

## How to apply
Gather competitor data, then benchmark side-by-side on consistent metrics and highlight relative strengths and weaknesses.

## Methodology
1. Identify the competitor set and benchmarking metrics.
2. Gather data on each competitor (web_search_tool).
3. Benchmark side-by-side on consistent, comparable metrics (analysis_tool).
4. Highlight relative strengths, weaknesses, and gaps.
5. Draw strategic implications.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Compare revenue growth across competitors
- Analyse competitor product portfolios
- Benchmark operational KPIs
