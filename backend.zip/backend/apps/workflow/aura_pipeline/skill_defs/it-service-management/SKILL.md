---
name: it-service-management
display_name: IT Service Management (Incidents)
description: Triages IT incidents/tickets — classifying and prioritizing by impact/urgency,
  matching against past incidents and known-error/KB records, and proposing the next
  action or resolution with evidence.
category: IT & Security
tools:
- db_*_tool
- db_schema_tool
- analysis_tool
method: Classify and prioritize the ticket, query past incidents and KB articles for
  matches via the database, and propose the resolution or routing with the cited supporting
  records.
example_use_cases:
- Triage and prioritize an inbound IT incident
- Match a new ticket to past incidents and KB articles
- Recommend a resolution or routing group with evidence
---

# IT Service Management (Incidents)

Triages IT incidents/tickets — classifying and prioritizing by impact/urgency, matching against past incidents and known-error/KB records, and proposing the next action or resolution with evidence.

## When to use
Assign to a service-desk/incident-triage agent; it grants the connected incident databases so it can match against real historical tickets.

## How to apply
Classify and prioritize the ticket, query past incidents and KB articles for matches via the database, and propose the resolution or routing with the cited supporting records.

## Methodology
1. Parse the incident: symptom, affected service, user, and any error text.
2. Classify category and set priority from impact x urgency.
3. Query the incident/KB database for similar past tickets and known errors; read the rows actually returned.
4. Propose the most likely resolution (or the correct assignment group) citing the matching records.
5. Output a triage record: category, priority, matched incidents, recommended action, and confidence.

## Tools this skill grants
- db_*_tool
- db_schema_tool
- analysis_tool

## Example use cases
- Triage and prioritize an inbound IT incident
- Match a new ticket to past incidents and KB articles
- Recommend a resolution or routing group with evidence
