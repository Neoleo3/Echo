---
name: invoice-parsing
display_name: Invoice Parsing
description: Extracts structured fields from a raw invoice (attached PDF text or
  pasted content) — vendor, invoice number, dates, line items, subtotals, tax and
  total — into a clean, machine-usable record for downstream validation.
category: Operations
tools:
- analysis_tool
method: Read the raw invoice content, locate each standard field (vendor, number,
  dates, line items, tax, total), normalise amounts and dates, and output one
  structured record — flagging any field that is missing or ambiguous.
example_use_cases:
- Parse an attached PDF invoice into structured fields
- Extract line items and totals from pasted invoice text
- Flag missing invoice numbers or unreadable amounts
---

# Invoice Parsing

Extracts structured fields from a raw invoice (attached PDF text or pasted content) — vendor, invoice number, dates, line items, subtotals, tax and total — into a clean, machine-usable record for downstream validation.

## When to use
Assign this skill to the first agent of an invoice pipeline — the reader/parser that turns an attached or pasted invoice into structured data every later step depends on.

## How to apply
Read the raw invoice content, locate each standard field (vendor, number, dates, line items, tax, total), normalise amounts and dates, and output one structured record — flagging any field that is missing or ambiguous.

## Methodology
1. Read the full invoice content from the attachment or message — never invent fields that are not present.
2. Extract header fields: vendor name, invoice number, invoice date, due date, currency, PO reference if present.
3. Extract every line item (description, quantity, unit price, line total) and the subtotal, tax amount, and grand total.
4. Normalise: numbers as plain decimals, dates as ISO (YYYY-MM-DD); verify line items sum to the subtotal and subtotal + tax = total.
5. Output one structured record and explicitly list any missing/ambiguous fields so downstream agents know the data quality.

## Tools this skill grants
- analysis_tool

## Example use cases
- Parse an attached PDF invoice into structured fields
- Extract line items and totals from pasted invoice text
- Flag missing invoice numbers or unreadable amounts
