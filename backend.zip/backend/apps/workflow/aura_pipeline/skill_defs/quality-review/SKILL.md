---
name: quality-review
display_name: Engagement Quality Review
description: Performs a quality / EQCR-style review of a deliverable — checking it
  against requirements, methodology and evidence, verifying internal consistency and
  that conclusions are supported, and logging review notes for clearance.
category: Audit
tools:
- analysis_tool
method: Review the deliverable against its requirements and methodology, verify every
  conclusion is supported by cited evidence and internally consistent, and log specific
  review notes to clear.
example_use_cases:
- Quality-review a report before release
- Verify every conclusion is supported by evidence
- Produce EQCR-style review notes for clearance
---

# Engagement Quality Review

Performs a quality / EQCR-style review of a deliverable — checking it against requirements, methodology and evidence, verifying internal consistency and that conclusions are supported, and logging review notes for clearance.

## When to use
Assign as a final reviewer node before a report or recommendation is released to the client/stakeholder.

## How to apply
Review the deliverable against its requirements and methodology, verify every conclusion is supported by cited evidence and internally consistent, and log specific review notes to clear.

## Methodology
1. Confirm the deliverable addresses every requirement/objective in scope.
2. Check that each conclusion is supported by evidence actually present upstream — flag unsupported claims.
3. Verify internal consistency: figures, totals and cross-references agree throughout.
4. Check compliance with the applicable methodology/standard and presentation quality.
5. Log specific, actionable review notes (location, issue, required change) and an overall clear/return verdict.

## Tools this skill grants
- analysis_tool

## Example use cases
- Quality-review a report before release
- Verify every conclusion is supported by evidence
- Produce EQCR-style review notes for clearance
