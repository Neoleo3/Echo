---
name: sanctions-screening
display_name: Sanctions Screening
description: Screens entities and transactions against global sanctions lists (OFAC,
  EU, UN) and assesses primary and secondary sanctions exposure.
category: Risk & Compliance
tools:
- web_search_tool
- analysis_tool
method: Match counterparties and transactions against sanctions lists, report each
  potential hit with a confidence level, and recommend block/escalate/clear actions.
example_use_cases:
- Screen counterparties against the OFAC SDN list
- Assess secondary-sanctions risk
- Review sanctions clauses in contracts
---

# Sanctions Screening

Screens entities and transactions against global sanctions lists (OFAC, EU, UN) and assesses primary and secondary sanctions exposure.

## When to use
Assign this skill to an agent that must screen counterparties against the OFAC SDN list, or related work in the Risk & Compliance domain.

## How to apply
Match counterparties and transactions against sanctions lists, report each potential hit with a confidence level, and recommend block/escalate/clear actions.

## Methodology
1. Identify the counterparties, jurisdictions, and transactions to screen.
2. Match names/entities against OFAC SDN, EU, and UN lists (research with web_search_tool).
3. Assess fuzzy matches and assign a confidence level to each potential hit.
4. Evaluate secondary-sanctions and ownership (50%-rule) exposure (analysis_tool).
5. Recommend block, escalate, or clear with documented rationale.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Screen counterparties against the OFAC SDN list
- Assess secondary-sanctions risk
- Review sanctions clauses in contracts
