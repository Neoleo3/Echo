---
name: contract-review
display_name: Contract Review
description: Analyses contracts for key terms, obligations, risks, and compliance
  with organisational policy, flagging non-standard or high-risk clauses.
category: Operations
tools:
- analysis_tool
method: Extract the key clauses, then flag risks and non-standard terms together with
  the obligation each one creates.
example_use_cases:
- Identify termination and liability clauses
- Review indemnification provisions
- Flag non-standard contract terms
---

# Contract Review

Analyses contracts for key terms, obligations, risks, and compliance with organisational policy, flagging non-standard or high-risk clauses.

## When to use
Assign this skill to an agent that must identify termination and liability clauses, or related work in the Operations domain.

## How to apply
Extract the key clauses, then flag risks and non-standard terms together with the obligation each one creates.

## Methodology
1. Read the contract and identify the parties and purpose.
2. Extract key clauses — termination, liability, indemnity, IP, payment (analysis_tool).
3. Compare against standard/policy positions.
4. Flag risks, non-standard terms, and missing protections.
5. Summarise obligations and recommended redlines.

## Tools this skill grants
- analysis_tool

## Example use cases
- Identify termination and liability clauses
- Review indemnification provisions
- Flag non-standard contract terms
