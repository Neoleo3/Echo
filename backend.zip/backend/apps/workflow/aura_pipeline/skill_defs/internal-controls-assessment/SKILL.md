---
name: internal-controls-assessment
display_name: Internal Controls Assessment
description: Evaluates the design and operating effectiveness of internal controls
  over financial reporting and operations, and documents deficiencies with their impact.
category: Audit
tools:
- analysis_tool
method: Test control design first, then operating effectiveness, and document each
  deficiency with its root cause and impact rating.
example_use_cases:
- Test segregation-of-duties controls
- Assess IT general controls (ITGC)
- Evaluate management-review controls
---

# Internal Controls Assessment

Evaluates the design and operating effectiveness of internal controls over financial reporting and operations, and documents deficiencies with their impact.

## When to use
Assign this skill to an agent that must test segregation-of-duties controls, or related work in the Audit domain.

## How to apply
Test control design first, then operating effectiveness, and document each deficiency with its root cause and impact rating.

## Methodology
1. Identify the controls relevant to the process and assertions.
2. Evaluate control design adequacy.
3. Test operating effectiveness using samples/walkthroughs (analysis_tool).
4. Document deficiencies with severity and impact.
5. Recommend remediation and compensating controls.

## Tools this skill grants
- analysis_tool

## Example use cases
- Test segregation-of-duties controls
- Assess IT general controls (ITGC)
- Evaluate management-review controls
