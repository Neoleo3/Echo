---
name: it-general-controls
display_name: IT General Controls (ITGC) Audit
description: Tests IT general controls supporting financial reporting — logical access,
  change management, and IT operations — evaluating control design and operating effectiveness
  and documenting exceptions.
category: Audit
tools:
- analysis_tool
- db_*_tool
- db_schema_tool
method: For each ITGC area, evaluate control design then test operating effectiveness
  against the evidence, and document each exception with its impact on reliance.
example_use_cases:
- Test logical access controls for a financial system
- Evaluate change-management controls over a key application
- Document ITGC exceptions and their impact on reliance
---

# IT General Controls (ITGC) Audit

Tests IT general controls supporting financial reporting — logical access, change management, and IT operations — evaluating control design and operating effectiveness and documenting exceptions.

## When to use
Assign to an IT-audit agent supporting a financial-statement or SOX audit; complements internal-controls-assessment with the IT layer.

## How to apply
For each ITGC area, evaluate control design then test operating effectiveness against the evidence, and document each exception with its impact on reliance.

## Methodology
1. Scope the in-scope systems and the three ITGC domains: logical access, change management, IT operations.
2. Logical access: test provisioning/deprovisioning, privileged access and periodic reviews against evidence.
3. Change management: test that changes are authorized, tested and approved before production.
4. IT operations: test backup, job scheduling and incident handling for completeness.
5. Document control design vs. operating effectiveness and each exception's impact on control reliance.

## Tools this skill grants
- analysis_tool
- db_*_tool
- db_schema_tool

## Example use cases
- Test logical access controls for a financial system
- Evaluate change-management controls over a key application
- Document ITGC exceptions and their impact on reliance
