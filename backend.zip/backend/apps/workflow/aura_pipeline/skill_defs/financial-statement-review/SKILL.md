---
name: financial-statement-review
display_name: Financial Statement Review
description: Analyses financial statements for accuracy, completeness, and compliance
  with accounting standards (IFRS, GAAP), recomputing key figures and checking recognition
  and disclosure.
category: Audit
tools:
- analysis_tool
- calculator_tool
method: Recompute key figures and ratios with the calculator, then check recognition,
  measurement, and disclosure against the relevant standard.
example_use_cases:
- Review revenue-recognition policies
- Assess lease accounting under IFRS 16
- Validate consolidation adjustments
---

# Financial Statement Review

Analyses financial statements for accuracy, completeness, and compliance with accounting standards (IFRS, GAAP), recomputing key figures and checking recognition and disclosure.

## When to use
Assign this skill to an agent that must review revenue-recognition policies, or related work in the Audit domain.

## How to apply
Recompute key figures and ratios with the calculator, then check recognition, measurement, and disclosure against the relevant standard.

## Methodology
1. Obtain the financial statements and supporting schedules.
2. Recompute key totals, subtotals, and ratios (calculator_tool).
3. Check revenue recognition, leases, and consolidation against IFRS/GAAP.
4. Identify misstatements, inconsistencies, or disclosure gaps (analysis_tool).
5. Summarise findings with their materiality.

## Tools this skill grants
- analysis_tool
- calculator_tool

## Example use cases
- Review revenue-recognition policies
- Assess lease accounting under IFRS 16
- Validate consolidation adjustments
