---
name: supply-chain-analysis
display_name: Supply Chain Analysis
description: Evaluates supply-chain operations, maps vendor dependencies and concentration,
  and ranks risks by likelihood and impact.
category: Operations
tools:
- web_search_tool
- analysis_tool
method: Map dependencies and concentration, then rank supply-chain risks by likelihood
  and impact with mitigations.
example_use_cases:
- Map tier-1 and tier-2 supplier dependencies
- Assess geopolitical supply-chain risk
- Evaluate supplier financial stability
---

# Supply Chain Analysis

Evaluates supply-chain operations, maps vendor dependencies and concentration, and ranks risks by likelihood and impact.

## When to use
Assign this skill to an agent that must map tier-1 and tier-2 supplier dependencies, or related work in the Operations domain.

## How to apply
Map dependencies and concentration, then rank supply-chain risks by likelihood and impact with mitigations.

## Methodology
1. Map the supply chain — tier-1/tier-2 suppliers and dependencies (web_search_tool).
2. Assess concentration and single-points-of-failure.
3. Evaluate geopolitical, financial, and operational risks (analysis_tool).
4. Rank risks by likelihood and impact.
5. Recommend mitigations and diversification.

## Tools this skill grants
- web_search_tool
- analysis_tool

## Example use cases
- Map tier-1 and tier-2 supplier dependencies
- Assess geopolitical supply-chain risk
- Evaluate supplier financial stability
