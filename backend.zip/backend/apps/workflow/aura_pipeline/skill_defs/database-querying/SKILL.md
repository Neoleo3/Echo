---
name: database-querying
display_name: Database Querying
description: Writes and executes precise SQL against connected databases (incidents,
  invoices, ERP records, any connector) — translating a natural-language need into
  correct SELECT queries and returning real rows for downstream agents.
category: Data & Analytics
tools:
- db_*_tool
- db_schema_tool
method: Inspect the schema first, translate the user's need into a targeted SQL query
  using the exact tables/columns, execute it via the database connector tool, and
  return the real rows — never invented data.
example_use_cases:
- Find past incidents matching a user's IT issue
- Pull pending vendor invoices and matching purchase orders
- Retrieve knowledge-base articles by topic or category
---

# Database Querying

Writes and executes precise SQL against connected databases (incidents, invoices, ERP records, any connector) — translating a natural-language need into correct SELECT queries and returning real rows for downstream agents.

## When to use
Assign this skill to any agent whose job involves reading from a connected database: SQL agents, record fetchers, incident/KB lookups, invoice/PO retrieval. It automatically grants every connected database tool (db_*_tool) plus schema introspection.

## How to apply
Inspect the schema first, translate the user's need into a targeted SQL query using the exact tables/columns, execute it via the database connector tool, and return the real rows — never invented data.

## Methodology
1. Call db_schema_tool (or read the schema hint in the tool description) to learn the exact tables and columns available.
2. Translate the user's request into a targeted SQL SELECT — filter with WHERE/LIKE on the relevant columns; never query blindly.
3. Execute the query with the matching db_*_tool connector and read the returned rows.
4. If the query errors or returns nothing, refine it (broaden the LIKE pattern, drop a filter) and retry once.
5. Return the actual rows in your output so downstream agents can use the real data — quote values exactly as returned.

## Tools this skill grants
- db_*_tool (every connected database)
- db_schema_tool

## Example use cases
- Find past incidents matching a user's IT issue
- Pull pending vendor invoices and matching purchase orders
- Retrieve knowledge-base articles by topic or category
