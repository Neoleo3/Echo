---
name: aml-screening
display_name: AML Screening
description: 'Performs anti-money-laundering checks: transaction monitoring, suspicious-pattern
  detection (structuring, layering), and suspicious-activity-report (SAR) preparation.'
category: Risk & Compliance
tools:
- analysis_tool
- web_search_tool
method: Scan transactions for AML red flags and structuring/layering patterns, classify
  each finding by risk level, and recommend SAR filing where the evidence warrants
  it.
example_use_cases:
- Screen transactions against AML red flags
- Identify structuring or layering patterns
- Draft suspicious-activity-report narratives
---

# AML Screening

Performs anti-money-laundering checks: transaction monitoring, suspicious-pattern detection (structuring, layering), and suspicious-activity-report (SAR) preparation.

## When to use
Assign this skill to an agent that must screen transactions against AML red flags, or related work in the Risk & Compliance domain.

## How to apply
Scan transactions for AML red flags and structuring/layering patterns, classify each finding by risk level, and recommend SAR filing where the evidence warrants it.

## Methodology
1. Review the transaction set and counterparties in scope.
2. Scan for AML red flags — structuring, layering, rapid movement, high-risk geographies (analysis_tool).
3. Classify each finding low / medium / high risk with the supporting evidence.
4. Recommend escalation and draft SAR narratives where warranted.
5. Record the rationale for both flagged and cleared items for audit.

## Tools this skill grants
- analysis_tool
- web_search_tool

## Example use cases
- Screen transactions against AML red flags
- Identify structuring or layering patterns
- Draft suspicious-activity-report narratives
