---
name: financial-analysis
display_name: Financial Analysis
description: Performs quantitative analysis of financial data — ratio, trend, and
  variance analysis — turning raw figures into decision-ready insight.
category: Data & Analytics
tools:
- calculator_tool
- analysis_tool
method: Compute ratios and variances with the calculator before interpreting; never
  state a number you have not derived, then explain what the numbers mean.
example_use_cases:
- Calculate profitability and liquidity ratios
- Perform year-over-year variance analysis
- Build financial forecasting models
---

# Financial Analysis

Performs quantitative analysis of financial data — ratio, trend, and variance analysis — turning raw figures into decision-ready insight.

## When to use
Assign this skill to an agent that must calculate profitability and liquidity ratios, or related work in the Data & Analytics domain.

## How to apply
Compute ratios and variances with the calculator before interpreting; never state a number you have not derived, then explain what the numbers mean.

## Methodology
1. Gather the financial data and the comparison basis (period, budget, peer).
2. Compute profitability, liquidity, leverage, and efficiency ratios (calculator_tool).
3. Run trend and variance analysis across periods.
4. Interpret the drivers behind the numbers (analysis_tool).
5. Summarise the financial story and its implications.

## Tools this skill grants
- calculator_tool
- analysis_tool

## Example use cases
- Calculate profitability and liquidity ratios
- Perform year-over-year variance analysis
- Build financial forecasting models
