---
name: proposal-writing
display_name: Proposal & RFP Response
description: Drafts proposals and RFP responses — parsing the client's requirements,
  structuring a compliant response that addresses each one with win themes and proof
  points, and producing a polished document.
category: Advisory
tools:
- web_search_tool
- report_tool
- document_report_tool
method: Parse every RFP requirement, draft a structured response addressing each with
  win themes and evidence, and produce a compliant, professional proposal document.
example_use_cases:
- Draft a compliant response to a client RFP
- Build a requirement-to-response compliance matrix
- Write win themes and proof points for a proposal
---

# Proposal & RFP Response

Drafts proposals and RFP responses — parsing the client's requirements, structuring a compliant response that addresses each one with win themes and proof points, and producing a polished document.

## When to use
Assign to a bid/proposal-drafting agent responding to a client RFP or producing an engagement proposal.

## How to apply
Parse every RFP requirement, draft a structured response addressing each with win themes and evidence, and produce a compliant, professional proposal document.

## Methodology
1. Parse the RFP into a requirement checklist (mandatory, scored, and evaluation criteria with weights).
2. Draft a compliant structure that maps a response section to each requirement (a compliance matrix).
3. Write each section with clear win themes, the approach, and proof points/credentials as evidence.
4. Research client/sector context to tailor the value proposition where it strengthens the bid.
5. Produce the polished proposal document and a compliance matrix confirming every requirement is addressed.

## Tools this skill grants
- web_search_tool
- report_tool
- document_report_tool

## Example use cases
- Draft a compliant response to a client RFP
- Build a requirement-to-response compliance matrix
- Write win themes and proof points for a proposal
