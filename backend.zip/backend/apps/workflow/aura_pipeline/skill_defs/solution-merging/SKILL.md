---
name: solution-merging
display_name: Solution Merging
description: Combines outputs from multiple parallel upstream agents (e.g. incident
  solutions + KB articles, or multi-source research) into one deduplicated, ranked,
  coherent result — the fan-in step of a parallel workflow.
category: Data & Analytics
tools:
- analysis_tool
method: Collect every upstream output, deduplicate overlapping items, rank what
  remains by relevance to the original request, and produce one merged result that
  preserves source attribution.
example_use_cases:
- Merge incident-DB solutions with knowledge-base articles
- Combine parallel research streams into one brief
- Reconcile two data sources into a single ranked list
---

# Solution Merging

Combines outputs from multiple parallel upstream agents (e.g. incident solutions + KB articles, or multi-source research) into one deduplicated, ranked, coherent result — the fan-in step of a parallel workflow.

## When to use
Assign this skill to the merge/fan-in agent in any parallel workflow — the node whose connections list two or more upstream agents and whose job is to unify their outputs.

## How to apply
Collect every upstream output, deduplicate overlapping items, rank what remains by relevance to the original request, and produce one merged result that preserves source attribution.

## Methodology
1. Read EVERY upstream agent's output from the context — do not ignore a branch, even if it is empty (note that it was empty).
2. Normalize the items into a common shape (title, content/steps, source).
3. Deduplicate: where two sources describe the same fix/finding, merge them into one item and keep both source labels.
4. Rank items by how directly they address the user's original request — most relevant first.
5. Output the merged, ranked list with source attribution so the display step can render it without re-interpreting.

## Tools this skill grants
- analysis_tool

## Example use cases
- Merge incident-DB solutions with knowledge-base articles
- Combine parallel research streams into one brief
- Reconcile two data sources into a single ranked list
