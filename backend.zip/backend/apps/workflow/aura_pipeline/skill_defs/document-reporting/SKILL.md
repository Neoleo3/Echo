---
name: document-reporting
display_name: Document Reporting
description: Produces polished, downloadable reports as PDF and Word (.docx) documents
  from workflow outputs, ready to share with stakeholders.
category: Operations
tools:
- document_report_tool
- report_tool
method: Compile upstream outputs into a titled report with clear sections, then call
  document_report_tool to generate downloadable PDF and Word files.
example_use_cases:
- Export a due-diligence report as PDF
- Generate a Word document of reconciliation results
- Produce a downloadable executive summary
---

# Document Reporting

Produces polished, downloadable reports as PDF and Word (.docx) documents from workflow outputs, ready to share with stakeholders.

## When to use
Assign this skill to an agent that must export a due-diligence report as PDF, or related work in the Operations domain.

## How to apply
Compile upstream outputs into a titled report with clear sections, then call document_report_tool to generate downloadable PDF and Word files.

## Methodology
1. Gather the workflow's outputs and key results.
2. Structure a titled report with clear sections.
3. Generate downloadable PDF + Word files (document_report_tool).
4. Optionally compile a text summary first (report_tool).
5. Return the download links for the documents.

## Tools this skill grants
- document_report_tool
- report_tool

## Example use cases
- Export a due-diligence report as PDF
- Generate a Word document of reconciliation results
- Produce a downloadable executive summary
