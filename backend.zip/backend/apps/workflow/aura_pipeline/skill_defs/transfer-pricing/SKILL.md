---
name: transfer-pricing
display_name: Transfer Pricing
description: Analyses intercompany transactions for arm's-length compliance and prepares
  transfer-pricing documentation aligned to OECD/BEPS guidance.
category: Advisory
tools:
- analysis_tool
- web_search_tool
method: Benchmark intercompany pricing against independent comparables, test it against
  the arm's-length standard, and flag deviations with the rationale and documentation
  required to defend the policy.
example_use_cases:
- Benchmark intercompany service fees
- Prepare local-file documentation
- Assess BEPS impact on pricing policy
---

# Transfer Pricing

Analyses intercompany transactions for arm's-length compliance and prepares transfer-pricing documentation aligned to OECD/BEPS guidance.

## When to use
Assign this skill to an agent that must benchmark intercompany service fees, or related work in the Advisory domain.

## How to apply
Benchmark intercompany pricing against independent comparables, test it against the arm's-length standard, and flag deviations with the rationale and documentation required to defend the policy.

## Methodology
1. Map the intercompany transactions, entities, and functions/risks involved.
2. Select the appropriate transfer-pricing method and comparable set (research with web_search_tool).
3. Benchmark the intercompany price against the comparables (analysis_tool).
4. Flag arm's-length deviations and BEPS exposure.
5. Outline the local-file / master-file documentation needed to support the policy.

## Tools this skill grants
- analysis_tool
- web_search_tool

## Example use cases
- Benchmark intercompany service fees
- Prepare local-file documentation
- Assess BEPS impact on pricing policy
