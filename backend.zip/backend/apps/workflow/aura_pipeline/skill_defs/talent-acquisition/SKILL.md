---
name: talent-acquisition
display_name: Talent Acquisition & Screening
description: Screens CVs/resumes against a job description — scoring candidates on
  must-have and nice-to-have criteria, surfacing gaps and red flags, and producing
  a ranked, evidence-cited shortlist.
category: People & HR
tools:
- analysis_tool
- web_search_tool
method: Extract the JD's requirements, score each candidate against them with cited
  evidence, and return a ranked shortlist with rationale and interview focus areas
  — never inventing experience.
example_use_cases:
- Rank applicants for a role against its job description
- Identify which candidates meet every must-have requirement
- Produce interview focus areas from each CV's gaps
---

# Talent Acquisition & Screening

Screens CVs/resumes against a job description — scoring candidates on must-have and nice-to-have criteria, surfacing gaps and red flags, and producing a ranked, evidence-cited shortlist.

## When to use
Assign to a recruitment-screening agent that evaluates applicants against an open role before human interview decisions.

## How to apply
Extract the JD's requirements, score each candidate against them with cited evidence, and return a ranked shortlist with rationale and interview focus areas — never inventing experience.

## Methodology
1. Parse the job description into must-have and nice-to-have requirements (skills, experience, certifications).
2. For each candidate, extract relevant experience and map it to the requirements with cited evidence.
3. Score must-haves first; a missing must-have caps the candidate's rank regardless of extras.
4. Flag gaps, inconsistencies and unexplained employment gaps as items for the interviewer, never as rejections.
5. Output a ranked shortlist: candidate, score, evidence, gaps, and suggested interview focus areas.

## Tools this skill grants
- analysis_tool
- web_search_tool

## Example use cases
- Rank applicants for a role against its job description
- Identify which candidates meet every must-have requirement
- Produce interview focus areas from each CV's gaps
