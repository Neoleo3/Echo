---
name: api-integration
display_name: API Integration
description: Calls connected external REST APIs (ticketing systems, data services,
  webhooks) with the right parameters, interprets the JSON responses, and surfaces
  the relevant fields for the workflow.
category: Operations
tools:
- api_*_tool
method: Pick the connected API that matches the need, send a well-formed request
  with the user's argument, parse the JSON response, and extract only the fields
  the workflow actually needs.
example_use_cases:
- Create or look up tickets in an external ITSM system
- Fetch live data from a third-party data service
- Push a result to a webhook or downstream system
---

# API Integration

Calls connected external REST APIs (ticketing systems, data services, webhooks) with the right parameters, interprets the JSON responses, and surfaces the relevant fields for the workflow.

## When to use
Assign this skill to an agent that must talk to an external HTTP service that has been added as an API connector — lookups, creations, notifications, enrichment. It automatically grants every connected API tool (api_*_tool).

## How to apply
Pick the connected API that matches the need, send a well-formed request with the user's argument, parse the JSON response, and extract only the fields the workflow actually needs.

## Methodology
1. Read each granted api_*_tool description to identify which connected API serves this request.
2. Form the input argument precisely (ID, search term, or payload value) — the connector handles auth and URL building.
3. Call the tool and parse the JSON response; check the success flag first.
4. On failure (error, timeout, empty body), retry once with a corrected argument, then report the failure honestly.
5. Extract only the relevant fields and pass them downstream in a clean, labelled structure.

## Tools this skill grants
- api_*_tool (every connected REST API)

## Example use cases
- Create or look up tickets in an external ITSM system
- Fetch live data from a third-party data service
- Push a result to a webhook or downstream system
