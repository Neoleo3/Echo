---
name: report-generation
display_name: Report Generation
description: Compiles structured, professional reports from analysis outputs, with
  an executive summary and clear, well-organised findings.
category: Operations
tools:
- report_tool
- email_tool
method: Use the report tool to compile upstream outputs into a structured report with
  an executive summary and clearly organised findings.
example_use_cases:
- Generate due-diligence summary reports
- Create audit-finding reports
- Produce risk-assessment summaries
---

# Report Generation

Compiles structured, professional reports from analysis outputs, with an executive summary and clear, well-organised findings.

## When to use
Assign this skill to an agent that must generate due-diligence summary reports, or related work in the Operations domain.

## How to apply
Use the report tool to compile upstream outputs into a structured report with an executive summary and clearly organised findings.

## Methodology
1. Collect the outputs from upstream agents.
2. Organise them into a logical report structure.
3. Write a concise executive summary.
4. Compile the full report with the report tool (report_tool).
5. If a notification is needed, send it (email_tool).

## Tools this skill grants
- report_tool
- email_tool

## Example use cases
- Generate due-diligence summary reports
- Create audit-finding reports
- Produce risk-assessment summaries
