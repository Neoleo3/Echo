---
name: payroll-processing
display_name: Payroll Processing & Validation
description: Calculates and validates payroll — gross-to-net with statutory deductions
  and contributions, checking variances against the prior period and flagging anomalies
  before pay run sign-off.
category: People & HR
tools:
- calculator_tool
- analysis_tool
method: Recompute gross-to-net pay with the calculator, apply statutory deductions/contributions,
  reconcile against the prior period, and flag every variance or anomaly precisely.
example_use_cases:
- Validate a monthly pay run against the prior period
- Recompute gross-to-net and flag calculation mismatches
- Surface payroll anomalies before disbursement sign-off
---

# Payroll Processing & Validation

Calculates and validates payroll — gross-to-net with statutory deductions and contributions, checking variances against the prior period and flagging anomalies before pay run sign-off.

## When to use
Assign to a payroll-prep or pre-payrun validation agent; a human gate should sit before the actual pay disbursement.

## How to apply
Recompute gross-to-net pay with the calculator, apply statutory deductions/contributions, reconcile against the prior period, and flag every variance or anomaly precisely.

## Methodology
1. Read each employee's base pay, hours, allowances and one-off adjustments from upstream.
2. Compute gross pay, then statutory deductions and employer contributions with calculator_tool (note the jurisdiction's rates).
3. Derive net pay and compare each line against the prior period; compute the variance %.
4. Flag new joiners, leavers, large swings (>X%), negative net pay and missing tax IDs as exceptions.
5. Output a validation summary: totals, exceptions with evidence, and a clear go/no-go for the pay run.

## Tools this skill grants
- calculator_tool
- analysis_tool

## Example use cases
- Validate a monthly pay run against the prior period
- Recompute gross-to-net and flag calculation mismatches
- Surface payroll anomalies before disbursement sign-off
