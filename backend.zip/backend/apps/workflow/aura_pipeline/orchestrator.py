"""
The AURA generation pipeline, sequenced.

Runs validation -> planning -> recruitment -> judge and yields stage events so
the route layer can either stream them (SSE) or collect the final assembled
spec (JSON). GENERATION-ONLY: this produces the agent DAG + quality score; it
does NOT execute, persist, or touch DB/session. Persistence via Echo's existing
repositories is wired in a later step (spec adapter).

Every model call inside the stages resolves per-user via ``llm.py`` (BYO-LLM).
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Iterator, Optional, Tuple

from .validation_agent import validate_workflow_request
from .planner_agent import plan_workflow
from .recruiter_agent import recruit_agents
from .judge_agent import judge_dag
from .dag import compute_dag_levels
from .spec_adapter import to_echo_spec

logger = logging.getLogger(__name__)

# Mirror AURA's clarification gate (FR-1.1): below this, ask instead of build.
_CONFIDENCE_THRESHOLD = 0.75


def iter_pipeline(prompt: str, user_id: Optional[str] = None, execution_mode: str = "autonomous") -> Iterator[Tuple[str, Dict[str, Any]]]:
    """Yield (event_type, data) tuples for each stage; last event is 'result' or a stop event."""

    # ── Stage 1: validation ──
    yield "validation_start", {"stage": "validation", "status": "running"}
    validation = validate_workflow_request(prompt, user_id=user_id)
    yield "validation_result", {"stage": "validation", "status": "completed", "data": validation}

    if not validation.get("valid", True):
        yield "workflow_rejected", {
            "status": "rejected",
            "reason": validation.get("reason", "Request rejected"),
        }
        return

    # Clarification is NON-BLOCKING: we still generate a workflow even if the
    # request looked ambiguous. If confidence is low we just carry the questions
    # through so the UI can offer them as a friendly, optional refinement note —
    # the user gets a real, editable workflow either way (and a missing/blocked
    # LLM, which falls back to mid confidence, no longer dead-ends generation).
    clarification_questions: list = []
    if validation.get("clarification_needed") or validation.get("confidence", 1.0) < _CONFIDENCE_THRESHOLD:
        clarification_questions = validation.get("clarification_questions", []) or []

    normalized_goal = validation.get("normalized_goal") or prompt
    workflow_type = validation.get("workflow_type", "general")

    # ── Stage 2: planning ──
    yield "planning_start", {"stage": "planning", "status": "running"}
    plan = plan_workflow(normalized_goal, user_id=user_id)
    # When no LLM is resolvable the planner returns a generic template. Surface
    # that so the UI can tell the user (instead of silently degrading).
    degraded = bool(plan.pop("_degraded", False))
    yield "planning_result", {"stage": "planning", "status": "completed", "data": plan}

    # ── Stage 3: recruitment ──
    yield "recruitment_start", {"stage": "recruitment", "status": "running"}
    agents = recruit_agents(plan, user_id=user_id)
    for agent in agents:
        yield "agent_recruited", {"stage": "recruitment", "agent": agent}
    dag_levels = compute_dag_levels(agents)
    yield "recruitment_result", {
        "stage": "recruitment",
        "status": "completed",
        "agent_count": len(agents),
        "agents": agents,
        "dag_levels": dag_levels,
    }

    # ── Stage 4: LLM-as-judge ──
    dag_eval = judge_dag(normalized_goal, agents, user_id=user_id)
    yield "dag_evaluation", {
        "stage": "dag_evaluation",
        "status": "completed",
        "evaluation": dag_eval,
        "message": f"DAG scored {dag_eval.get('score', 0):.1f}/100 — {dag_eval.get('verdict', 'N/A')}",
    }

    # ── Echo-native spec (ready for the existing save flow) ──
    echo_workflow, echo_agents = to_echo_spec(
        agents, workflow_name=normalized_goal, workflow_type=workflow_type,
        execution_mode=execution_mode,
    )

    # ── Final assembled spec (not yet persisted) ──
    yield "result", {
        "status": "completed",
        "workflow_name": normalized_goal,
        "workflow_type": workflow_type,
        "validation": validation,
        "plan": plan,
        "agents": agents,          # AURA shape — for the DAG visualization
        "dag_levels": dag_levels,  # topological layout for the graph
        "agent_count": len(agents),
        "dag_evaluation": dag_eval,
        "degraded": degraded,  # True => generic template (no LLM resolvable)
        "notice": (
            "No LLM is configured, so a generic template was generated. "
            "Configure a model to get a workflow tailored to your prompt."
            if degraded else None
        ),
        "clarification_questions": clarification_questions,  # optional, non-blocking
        "echo_spec": {             # Echo shape — feed to the existing save flow
            "workflow": echo_workflow,
            "agents": echo_agents,
        },
    }


def run_pipeline(prompt: str, user_id: Optional[str] = None, execution_mode: str = "autonomous") -> Dict[str, Any]:
    """Run the whole pipeline and return the final result (or a stop payload)."""
    last_event, last_data = "result", {}
    for event_type, data in iter_pipeline(prompt, user_id=user_id, execution_mode=execution_mode):
        last_event, last_data = event_type, data
    return {"final_event": last_event, **last_data}
