"""
AURA-style prompt-based workflow/agent generation pipeline, embedded in Echo.

This package ports AURA's multi-stage generation brain (validate -> plan ->
recruit -> judge -> enrich) into Echo. It is GENERATION-ONLY: it produces
Echo-native workflow/agent specs and never replaces Echo's LangGraph
runtime, its DB/session management, or its keyword tool-selection.

Hard constraints honoured here:
  * BYO-LLM: every model call goes through Echo's per-user ``llm_resolver``
    (see ``llm.py``). No provider/model/base-URL is ever hardcoded.
  * No DB/session changes: persistence happens only via Echo's existing
    repositories, invoked from the route layer — not from this package.
  * Keyword functionality stays intact: Echo's existing designers are
    untouched; this pipeline is exposed on NEW routes only.
"""
