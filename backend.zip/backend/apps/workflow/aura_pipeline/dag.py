"""
DAG utilities — topological levels for visualization + Echo execution-model hint.

``compute_dag_levels`` groups agents into left-to-right levels (longest-path
layering) so the frontend can lay out parallel branches and fan-in exactly like
AURA's WorkflowGraph. Pure, deterministic, cycle-safe.
"""

from __future__ import annotations

from typing import Dict, List


def compute_dag_levels(agents: List[dict]) -> List[List[str]]:
    """Return topological levels (lists of agent_name) for a DAG of agents.

    Each agent has ``agent_name`` and ``connections`` (names it depends on).
    Level(node) = 0 if it has no in-DAG dependencies, else max(level(dep)) + 1.
    Unknown/dangling dependencies are ignored; cycles are broken defensively.
    """
    names = [a.get("agent_name") for a in agents if isinstance(a, dict) and a.get("agent_name")]
    nameset = set(names)
    deps: Dict[str, List[str]] = {}
    for a in agents:
        if not isinstance(a, dict):
            continue
        n = a.get("agent_name")
        if not n:
            continue
        deps[n] = [d for d in (a.get("connections") or []) if d in nameset and d != n]

    level: Dict[str, int] = {}
    # Iteratively resolve levels; cap iterations to guard against cycles.
    for _ in range(len(names) + 1):
        changed = False
        for n in names:
            d = deps.get(n, [])
            new_level = 0 if not d else (max((level.get(x, 0) for x in d)) + 1)
            if level.get(n) != new_level:
                # Only raise levels (avoid oscillation on cycles)
                if new_level > level.get(n, -1):
                    level[n] = new_level
                    changed = True
        if not changed:
            break

    for n in names:
        level.setdefault(n, 0)

    max_level = max(level.values(), default=-1)
    levels: List[List[str]] = [[] for _ in range(max_level + 1)]
    for n in names:
        levels[level[n]].append(n)
    return [lvl for lvl in levels if lvl]


def infer_execution_model(dag_levels: List[List[str]], agent_count: int) -> str:
    """Map a DAG shape onto Echo's execution_model vocabulary."""
    if agent_count <= 1:
        return "sequential"
    if len(dag_levels) <= 1:
        return "parallel"  # all independent, one level
    if any(len(lvl) > 1 for lvl in dag_levels):
        return "hybrid"   # mix of parallel branches + sequential stages
    return "sequential"
