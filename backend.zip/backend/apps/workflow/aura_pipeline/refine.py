"""
AURA-style workflow refinement ("Enhance"): edit an existing agent DAG from a
natural-language instruction.

Ported from AURA's refine_workflow (_refine_plan + _apply_refine_plan), rewired
to Echo's BYO-LLM resolver and Echo's tool/skill registries. STATELESS: takes
the current agents (AURA shape) + an instruction, returns the edited agents +
a change summary. The canvas holds state; nothing is persisted here.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from .llm import get_orchestration_llm, invoke_text
from .json_extract import extract_json
from . import tools as tools_mod
from . import skills as skills_mod
from .enrichers import enrich_agent_goals, apply_connector_hook
from .dag import compute_dag_levels

logger = logging.getLogger(__name__)


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", str(text).strip().lower().replace(" ", "_")).strip("_")


def _refine_plan(instruction: str, agents: List[dict], user_id: Optional[str]) -> Dict[str, Any]:
    """One focused LLM call → a change plan {add, update, remove} vs current agents."""
    valid_tools = tools_mod.valid_tool_ids()
    valid_skills = skills_mod.valid_skill_ids()
    current = json.dumps([
        {"agent_name": a.get("agent_name"), "role": a.get("role"),
         "goal": (a.get("goal") or "")[:200], "skills": a.get("skills", []),
         "tools": a.get("tools", []), "connections": a.get("connections", []),
         "node_type": a.get("node_type", "tool_agent")}
        for a in agents
    ], indent=1)

    prompt = f"""You are an expert multi-agent workflow OPTIMIZER. Analyze the existing
workflow and make it measurably better while preserving the user's original
intent. This is an optimization pass — produce real improvements, not a cosmetic
no-op.

CURRENT WORKFLOW AGENTS (with their goals, skills, tools, dependencies):
{current}

USER'S ENHANCEMENT REQUEST:
{instruction}

AVAILABLE TOOLS (exact ids only): {', '.join(sorted(valid_tools))}
AVAILABLE SKILLS: {', '.join(sorted(valid_skills)) or '(none)'}

OPTIMIZE ALONG THESE AXES (apply every one that improves this workflow):
1. Sequencing & dependencies — reorder/rewire so independent work runs in
   parallel (multiple agents depending on the same upstream) and dependent work
   is correctly chained. Remove dependencies that aren't needed.
2. Redundancy — MERGE or REMOVE agents whose responsibilities overlap; one agent
   should not duplicate another's job.
3. Agent selection — add a missing capability as a new agent, or drop an agent
   that adds no value to the goal.
4. Tools & skills — assign the most relevant tool ids / skill ids to each agent
   (from the available lists); remove tools/skills an agent doesn't need.
5. Prompts/goals — sharpen each goal so it is specific, measurable, and states
   the exact expected output and the format consumed by downstream agents.
If the user's request is specific, prioritize it; if it is generic (e.g.
"enhance", "make it better", "optimize"), perform a full holistic optimization
across all axes above.

Return ONLY a JSON object (no markdown, no commentary):
{{
  "add":    [{{"agent_name":"new_snake_case","role":"...","goal":"specific, measurable goal incl. expected output",
               "skills":["skill_id"],"tools":["tool_id"],
               "connections":["upstream_agent_name"]}}],
  "update": [{{"agent_name":"existing_name","goal":"sharper goal (optional)",
               "role":"(optional)","skills":["..."],"tools":["..."],
               "connections":["..."]}}],
  "remove": ["redundant_or_obsolete_agent_name"]
}}
Rules:
- Preserve the original intent — do not change WHAT the workflow achieves.
- In "update", include an agent only if you are changing it; include only the
  fields you change (but DO update goals/tools/connections where they improve).
- tools/skills must come from the available lists (or []).
- connections must reference agents that exist after the change (existing names
  not removed, or names you add). No self-loops, no cycles.
- Leave a section as [] only if nothing there genuinely improves the workflow.
"""
    try:
        llm = get_orchestration_llm(user_id=user_id, temperature=0.2)
        content = invoke_text(llm, prompt)
    except Exception as e:
        logger.warning("refine: llm failed: %s", e)
        return {}
    plan = extract_json(content, kind="object")
    return plan if isinstance(plan, dict) else {}


def _apply_refine_plan(agents: List[dict], plan: Dict[str, Any]) -> Tuple[List[dict], Dict[str, list]]:
    valid_tools = tools_mod.valid_tool_ids()
    valid_skills = skills_mod.valid_skill_ids()
    by_name = {a["agent_name"]: dict(a) for a in agents if a.get("agent_name")}
    changes = {"added": [], "updated": [], "removed": []}

    # 1) updates
    for upd in plan.get("update") or []:
        if not isinstance(upd, dict):
            continue
        name = _slug(upd.get("agent_name") or "")
        if name not in by_name:
            continue
        target = by_name[name]
        for field in ("role", "goal"):
            if isinstance(upd.get(field), str) and upd[field].strip():
                target[field] = upd[field].strip()
        if isinstance(upd.get("skills"), list):
            target["skills"] = [s for s in upd["skills"] if s in valid_skills]
        if isinstance(upd.get("tools"), list):
            target["tools"] = [t for t in upd["tools"] if t in valid_tools]
        if isinstance(upd.get("connections"), list):
            target["connections"] = list(upd["connections"])
        changes["updated"].append(name)

    # 2) removals (strip from others' connections)
    for raw in plan.get("remove") or []:
        name = _slug(str(raw))
        if name in by_name:
            by_name.pop(name)
            changes["removed"].append(name)
    for a in by_name.values():
        a["connections"] = [c for c in a.get("connections", []) if c in by_name or
                            any(_slug(n.get("agent_name", "")) == c for n in (plan.get("add") or []) if isinstance(n, dict))]

    # 3) additions
    for new in plan.get("add") or []:
        if not isinstance(new, dict):
            continue
        name = _slug(new.get("agent_name") or "")
        if not name or name in by_name:
            continue
        by_name[name] = {
            "agent_name": name,
            "role": new.get("role") or name.replace("_", " ").title(),
            "goal": new.get("goal", ""),
            "skills": [s for s in (new.get("skills") or []) if s in valid_skills],
            "tools": [t for t in (new.get("tools") or []) if t in valid_tools],
            "connections": list(new.get("connections") or []),
            "node_type": new.get("node_type", "tool_agent"),
            **({"human_gate": new["human_gate"]} if new.get("human_gate") else {}),
        }
        changes["added"].append(name)

    # final connection validation (drop dangling / self loops)
    final = list(by_name.values())
    names = set(by_name.keys())
    for a in final:
        a["connections"] = [c for c in a.get("connections", []) if c in names and c != a["agent_name"]]
    return final, changes


def refine_agents(agents: List[dict], instruction: str, user_id: Optional[str] = None) -> Dict[str, Any]:
    """Apply a natural-language enhancement to an agent DAG. Never raises.

    Returns {agents, dag_levels, changes, message} — agents are the edited DAG
    (AURA shape), ready to re-render in the canvas.
    """
    instruction = (instruction or "").strip()
    if len(instruction) < 4:
        return {"agents": agents, "dag_levels": compute_dag_levels(agents),
                "changes": {"added": [], "updated": [], "removed": []},
                "message": "Describe the change you want (a short sentence)."}

    plan = _refine_plan(instruction, agents, user_id)
    if not plan or not any(plan.get(k) for k in ("add", "update", "remove")):
        return {"agents": agents, "dag_levels": compute_dag_levels(agents),
                "changes": {"added": [], "updated": [], "removed": []},
                "message": "Couldn't derive a concrete change — try being more specific."}

    final, changes = _apply_refine_plan(agents, plan)
    if not final:
        return {"agents": agents, "dag_levels": compute_dag_levels(agents),
                "changes": {"added": [], "updated": [], "removed": []},
                "message": "Refusing to remove every agent."}

    final = enrich_agent_goals(apply_connector_hook(final))
    return {
        "agents": final,
        "dag_levels": compute_dag_levels(final),
        "changes": changes,
        "message": (f"Updated — added {len(changes['added'])}, "
                    f"updated {len(changes['updated'])}, removed {len(changes['removed'])}."),
    }
