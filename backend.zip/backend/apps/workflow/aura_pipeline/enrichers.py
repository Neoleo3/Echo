"""
Deterministic, model-independent enrichment of generated agents.

Ported from AURA's recruiter post-processing. These passes run AFTER the LLM and
do not depend on which BYO model produced the DAG — they are pure reliability
wins:

  * ``enrich_agent_goals`` — appends data-flow notes + strict OUTPUT CONTRACTs so
    each agent knows what it receives, what it must emit, and the exact format,
    making node-to-node hand-off machine-parseable.
  * ``auto_attach_connector_tools`` — PLUGGABLE hook. In AURA this wired DB/API/MCP
    connector tools onto data agents. The real Echo implementation arrives with
    Change 3 (the connector auto-exposure overlay); until then it is a safe no-op,
    because the recruiter already sees Echo's connector-synced tools in its menu.
"""

from __future__ import annotations

from typing import Callable, List

# Archetype -> output contract appended to thin goals (verbatim from AURA).
_ARCHETYPE_CONTRACTS: list[tuple[tuple[str, ...], str]] = [
    (("pars", "reader", "extract", "ocr"),
     "OUTPUT CONTRACT: Return STRICT JSON only — the structured record(s) with every "
     "extracted field; list absent fields in \"missing_fields\". Never invent values. "
     "No prose, no markdown, no code fences."),
    (("retriev",),
     "RULES: Use ONLY the ids/references produced by the upstream agent. Fetch the "
     "COMPLETE records with your database tool — never truncate, summarize, or modify "
     "the content. OUTPUT CONTRACT: STRICT JSON array of the full records, each with "
     "its id, source label, and complete text."),
    (("sql", "query", "fetch", "lookup"),
     "RULES: Check the schema first, then execute a targeted SQL query with your "
     "database tool and use the rows it actually returns. OUTPUT CONTRACT: STRICT JSON "
     "only: {\"ids\": [...], \"rows\": [...]} containing the real query results. No "
     "commentary, no SQL text in the output."),
    (("merge", "combine", "consolidat", "synthes"),
     "RULES: Read EVERY upstream agent's output — do not drop a branch. OUTPUT CONTRACT: "
     "STRICT JSON — one combined, deduplicated, ranked array; preserve each item's text "
     "verbatim and keep its source label and id."),
    (("display", "render", "present", "binder", "format"),
     "OUTPUT CONTRACT: Clean Markdown ONLY (no JSON, no code fences around the whole "
     "answer). Group items by source, label each with its id, best answer first, and "
     "never truncate the content provided by upstream agents."),
    (("risk", "fraud", "anomal"),
     "OUTPUT CONTRACT: STRICT JSON: {\"overall_score\": 0-10, \"recommendation\": "
     "\"approve|hold|reject\", \"issues\": [{\"severity\": \"low|medium|high|critical\", "
     "\"description\", \"evidence\", \"remediation\"}]} based only on the provided data."),
    (("tax", "vat", "gst", "compliance"),
     "OUTPUT CONTRACT: STRICT JSON: {\"status\": \"compliant|partial|non_compliant\", "
     "\"checks\": [{\"name\", \"pass\", \"detail\"}], \"issues\": [...]} — recompute the "
     "math; never guess missing values."),
    (("match", "reconcil",),
     "OUTPUT CONTRACT: STRICT JSON: {\"line_matches\": [...], \"overall_status\": "
     "\"pass|manual_review|fail\", \"exceptions\": [...]} — cite the actual values "
     "returned by the database, with computed variance percentages."),
    (("report",),
     "OUTPUT CONTRACT: A professional narrative report (no raw JSON): executive summary "
     "first, then sections per check/source with exact figures from upstream — omit any "
     "figure you don't have rather than guessing."),
]


def enrich_agent_goals(agents: List[dict]) -> List[dict]:
    """Append data-flow + output contracts to thin agent goals (deterministic)."""
    by_name = {a.get("agent_name"): a for a in agents if isinstance(a, dict)}
    downstream: dict[str, list[str]] = {n: [] for n in by_name}
    for a in agents:
        if not isinstance(a, dict):
            continue
        for dep in a.get("connections", []) or []:
            if dep in downstream:
                downstream[dep].append(a.get("agent_name"))

    for a in agents:
        if not isinstance(a, dict) or a.get("node_type") == "human_gate":
            continue
        goal = a.get("goal", "") or ""
        if "OUTPUT CONTRACT" in goal or "OUTPUT FORMAT" in goal or "STRICT JSON" in goal:
            continue  # already contract-style

        text = f"{a.get('agent_name','')} {a.get('role','')} {goal}".lower()
        contract = ""
        for keys, c in _ARCHETYPE_CONTRACTS:
            if any(k in text for k in keys):
                contract = c
                break

        flow_bits = []
        ups = a.get("connections", []) or []
        if ups:
            flow_bits.append(f"INPUT: the outputs of {', '.join(ups)} are provided as upstream context.")
        downs = downstream.get(a.get("agent_name"), [])
        if downs:
            flow_bits.append(f"Your output is consumed by {', '.join(downs)} — keep the format exact and machine-readable.")

        extras = " ".join(flow_bits)
        if contract or extras:
            a["goal"] = f"{goal.rstrip('.')}.\n{extras}\n{contract}".strip()
    return agents


def auto_attach_connector_tools(agents: List[dict]) -> List[dict]:
    """No-op placeholder until Change 3 provides Echo's connector auto-exposure.

    Replaced by the unified-registry overlay; kept as a seam so the recruiter
    call-site does not change when Change 3 lands.
    """
    return agents


# Allow Change 3 to inject the real implementation without editing the recruiter.
_connector_hook: Callable[[List[dict]], List[dict]] = auto_attach_connector_tools


def set_connector_hook(fn: Callable[[List[dict]], List[dict]]) -> None:
    global _connector_hook
    _connector_hook = fn


def apply_connector_hook(agents: List[dict]) -> List[dict]:
    try:
        return _connector_hook(agents)
    except Exception:
        return agents
