"""
Stage 4 of the AURA pipeline: LLM-as-judge DAG evaluation.

Ported from AURA's ``judge_dag`` and rewired to Echo's BYO-LLM resolver. A
separate model pass scores the generated DAG against the goal (coverage,
efficiency, tool alignment, structure, human gates). Degrades to an
"acceptable/approved" default on any failure so generation is never blocked.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

from .llm import get_orchestration_llm, invoke_text
from .json_extract import extract_json

logger = logging.getLogger(__name__)


_SYSTEM_PROMPT = """
You are an expert AI workflow quality judge.

Your job is to evaluate whether a generated agent DAG correctly addresses the user's workflow goal.

EVALUATION CRITERIA:

1. COVERAGE (0-30 pts): Does the DAG cover all required steps to achieve the goal?
2. EFFICIENCY (0-25 pts): Are agents minimal and non-redundant? No unnecessary agents?
3. TOOL ALIGNMENT (0-20 pts): Are the right tools assigned to each agent?
4. DAG STRUCTURE (0-15 pts): Are dependencies (connections) logical? Is the execution order correct?
5. HUMAN GATES (0-10 pts): Are approval gates present where required (writes, financial decisions)?

SCORING:
- 90-100: excellent
- 75-89:  good
- 60-74:  acceptable
- Below 60: poor

Return ONLY JSON:

{
    "score": 82.5,
    "verdict": "good",
    "criteria_scores": {
        "coverage": 28, "efficiency": 20, "tool_alignment": 16,
        "dag_structure": 12, "human_gates": 6
    },
    "issues": ["Missing a reporting agent to summarize final results"],
    "suggestions": ["Add a report agent at the end of the DAG"],
    "approved": true
}
"""


def judge_dag(workflow_goal: str, agents: List[dict], user_id: Optional[str] = None) -> Dict[str, Any]:
    """Evaluate the generated agent DAG against the workflow goal. Never raises."""
    dag_summary = json.dumps(
        [
            {
                "agent_name": a.get("agent_name"),
                "role": a.get("role"),
                "goal": a.get("goal"),
                "skills": a.get("skills", []),
                "tools": a.get("tools", []),
                "connections": a.get("connections", []),
                "type": a.get("node_type", "tool_agent"),
            }
            for a in agents
        ],
        indent=2,
    )

    user_message = f"""
WORKFLOW GOAL:
{workflow_goal}

GENERATED AGENT DAG:
{dag_summary}

Evaluate this DAG and return your assessment as JSON.
"""

    try:
        llm = get_orchestration_llm(user_id=user_id, temperature=0.1)
        content = invoke_text(llm, f"{_SYSTEM_PROMPT}\n{user_message}")
        result = extract_json(content, kind="object")
        if not isinstance(result, dict):
            raise ValueError("no JSON object found")

        criteria_keys = [
            "coverage", "efficiency", "tool_alignment", "dag_structure", "human_gates",
            "tool", "structure",
        ]
        criteria = result.get("criteria_scores")
        if not isinstance(criteria, dict) or not criteria:
            criteria = {k: result[k] for k in criteria_keys if isinstance(result.get(k), (int, float))}
        result["criteria_scores"] = criteria

        if isinstance(result.get("score"), (int, float)):
            score = float(result["score"])
        elif criteria:
            score = float(sum(float(v) for v in criteria.values()))
        else:
            score = 70.0

        result["score"] = max(0.0, min(100.0, score))
        result["verdict"] = result.get("verdict") or _verdict(result["score"])
        result.setdefault("issues", [])
        result.setdefault("suggestions", [])
        result["approved"] = result.get("approved", result["score"] >= 60.0)
        return result

    except Exception as e:
        logger.warning("judge: evaluation failed, using default: %s", e)
        return {
            "score": 70.0,
            "verdict": "acceptable",
            "criteria_scores": {},
            "issues": [],
            "suggestions": [],
            "approved": True,
            "error": str(e),
        }


def _verdict(score: float) -> str:
    if score >= 90:
        return "excellent"
    if score >= 75:
        return "good"
    if score >= 60:
        return "acceptable"
    return "poor"
