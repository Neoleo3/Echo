"""Robust JSON extraction from LLM output.

Ported verbatim from AURA (provider-agnostic, no external deps). Small/local
models rarely return clean JSON — they wrap it in prose preambles, markdown
fences, or reasoning <think> blocks. These helpers recover the JSON payload
regardless, which matters because Echo is a BYO-LLM platform where the user's
own model may be a weak local one.
"""

from __future__ import annotations

import json
import re
from typing import Any


def _strip_noise(text: str) -> str:
    if not text:
        return ""
    # Remove reasoning blocks emitted by models like qwen3 (<think>...</think>)
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<think>.*", "", text, flags=re.DOTALL | re.IGNORECASE)  # unclosed

    # gpt-oss "harmony" format — if the server leaked raw channel markers, keep
    # only the FINAL channel and drop the analysis/reasoning channel.
    if "<|channel|>final<|message|>" in text:
        m = re.search(
            r"<\|channel\|>final<\|message\|>(.*?)(?:<\|return\|>|<\|end\|>|$)",
            text, flags=re.DOTALL,
        )
        if m:
            text = m.group(1)
    # Plain-text harmony leak: "...analysis... assistantfinal <answer>"
    if "assistantfinal" in text:
        text = text.split("assistantfinal")[-1]
    # Remove any remaining harmony control tokens like <|start|>, <|channel|>, etc.
    text = re.sub(r"<\|[a-zA-Z0-9_]+\|>", "", text)

    # Strip markdown code fences
    text = re.sub(r"```[a-zA-Z]*", "", text)
    return text.strip()


def _balanced_span(text: str, open_ch: str, close_ch: str) -> str | None:
    """Return the substring from the first open_ch to its matching close_ch."""
    start = text.find(open_ch)
    if start == -1:
        return None
    depth = 0
    in_str = False
    escape = False
    for i in range(start, len(text)):
        ch = text[i]
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


def extract_json(text: str, kind: str = "auto") -> Any | None:
    """
    Extract and parse JSON from arbitrary LLM text.

    kind: "array" -> prefer a top-level [...]
          "object" -> prefer a top-level {...}
          "auto" -> try whichever appears first
    Returns the parsed value, or None if nothing parses.
    """
    cleaned = _strip_noise(text)
    if not cleaned:
        return None

    # 1) Direct parse (best case — model returned clean JSON)
    try:
        return json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        pass

    # 2) Determine bracket preference order
    if kind == "array":
        order = [("[", "]"), ("{", "}")]
    elif kind == "object":
        order = [("{", "}"), ("[", "]")]
    else:
        # auto — pick whichever opening bracket comes first
        first_arr = cleaned.find("[")
        first_obj = cleaned.find("{")
        if first_obj == -1:
            order = [("[", "]")]
        elif first_arr == -1:
            order = [("{", "}")]
        elif first_arr < first_obj:
            order = [("[", "]"), ("{", "}")]
        else:
            order = [("{", "}"), ("[", "]")]

    # 3) Balanced-bracket extraction
    for open_ch, close_ch in order:
        span = _balanced_span(cleaned, open_ch, close_ch)
        if span:
            try:
                return json.loads(span)
            except (json.JSONDecodeError, TypeError):
                # Last resort: greedy first-open to last-close
                start = cleaned.find(open_ch)
                end = cleaned.rfind(close_ch)
                if start != -1 and end > start:
                    try:
                        return json.loads(cleaned[start : end + 1])
                    except (json.JSONDecodeError, TypeError):
                        continue

    return None
