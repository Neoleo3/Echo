"""
Stage 1 of the AURA pipeline: workflow-request validation.

Ported from AURA's ``validation_agent`` and rewired to Echo's BYO-LLM resolver.
Decides whether a natural-language request is a valid/achievable workflow,
scores how clear it is (confidence), and proposes clarification questions when
ambiguous. It also assigns a reusable ``workflow_type`` category.

The model is resolved per-user (no hardcoding). On any LLM failure the function
degrades to a permissive deterministic fallback so the pipeline never crashes
on a weak BYO model.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .llm import get_orchestration_llm, invoke_text
from .json_extract import extract_json

logger = logging.getLogger(__name__)


_SYSTEM_PROMPT = """
You are a validation agent.

Your job is to determine whether a workflow request is logically valid and achievable,
AND to score how clear and well-defined the request is.

ACCEPT requests that:
- can theoretically be automated
- involve monitoring information
- sending emails
- generating reports
- searching information
- scheduling actions
- notifications
- workflow orchestration

REJECT requests that are:
- physically impossible
- illegal
- harmful
- require supernatural abilities
- violate system safety

IMPORTANT:
A request does NOT need to be currently implemented in tools to be considered valid.

Example VALID:
- email me when GTA 6 releases for PS5
- monitor AI startup news weekly
- send daily stock reports
- reconcile vendor invoices against purchase orders

Example INVALID:
- predict lottery numbers perfectly
- hack bank servers
- time travel workflow

CONFIDENCE SCORE RULES (0.0 to 1.0):
- 1.0: Crystal clear goal, specific domain, actionable steps obvious
- 0.8: Clear goal, minor ambiguity in scope or frequency
- 0.6: Moderately clear, some ambiguity in how to proceed
- 0.4: Vague goal, multiple possible interpretations
- 0.2: Very ambiguous, hard to determine intent
- Below 0.75: Clarification should be requested

Return ONLY JSON:

{
    "valid": true,
    "confidence": 0.85,
    "reason": "brief explanation",
    "normalized_goal": "clear restatement of the goal",
    "workflow_type": "short_snake_case_category",
    "clarification_needed": false,
    "clarification_questions": []
}

workflow_type should be a short reusable category name (snake_case).
Examples:
- Due diligence tasks -> due_diligence
- Market research tasks -> market_research
- Invoice reconciliation -> invoice_reconciliation
- Hiring tasks -> hiring
- Sales outreach -> sales_outreach

If confidence < 0.75, set clarification_needed=true and populate clarification_questions
with 1-3 specific questions to resolve the ambiguity.
"""


def validate_workflow_request(
    user_prompt: str,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Validate a workflow request and score its clarity. Never raises."""
    try:
        llm = get_orchestration_llm(user_id=user_id, temperature=0.2)
    except Exception as e:  # no resolvable credential / provider down
        logger.warning("validation: llm resolve failed, using fallback: %s", e)
        return _fallback(user_prompt, reason="LLM unavailable — permissive fallback used")

    full_prompt = f"{_SYSTEM_PROMPT}\n\nWORKFLOW REQUEST:\n{user_prompt}\n\nReturn ONLY the JSON object."

    try:
        content = invoke_text(llm, full_prompt)
    except Exception as e:
        logger.warning("validation: llm invoke failed, using fallback: %s", e)
        return _fallback(user_prompt, reason="LLM call failed — permissive fallback used")

    if not content:
        return _fallback(user_prompt, reason="Empty response from LLM")

    parsed = extract_json(content, kind="object")
    if not isinstance(parsed, dict):
        logger.warning("validation: could not extract JSON, using fallback")
        return _fallback(user_prompt)

    # Ensure all fields exist with sensible defaults
    parsed.setdefault("valid", True)
    parsed.setdefault("confidence", 0.75)
    parsed.setdefault("reason", "")
    parsed.setdefault("normalized_goal", user_prompt)
    parsed.setdefault("workflow_type", "general")
    parsed.setdefault("clarification_needed", False)
    parsed.setdefault("clarification_questions", [])

    # Clamp confidence to [0.0, 1.0]
    try:
        parsed["confidence"] = max(0.0, min(1.0, float(parsed["confidence"])))
    except (TypeError, ValueError):
        parsed["confidence"] = 0.75

    return parsed


def _fallback(user_prompt: str, reason: str = "Fallback validation used") -> Dict[str, Any]:
    return {
        "valid": True,
        "confidence": 0.6,
        "reason": reason,
        "normalized_goal": user_prompt,
        "workflow_type": "general",
        "clarification_needed": False,
        "clarification_questions": [],
    }
