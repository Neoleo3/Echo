"""
LangChain Agent Adapter for Echo Workflows

This module adapts the single agent instantiation path to LangGraph nodes. It
owns workflow concerns only -- task assembly from graph state, transparency
event emission, and the node return contract. Agent construction itself belongs
to ``apps.agent.factory``.

Architecture:
- LangGraph OWNS: workflow topology, execution order, state management
- Agents are compiled by ``AgentFactory.build`` and invoked INSIDE node functions
- Execution model (sequential/parallel/hierarchical) is encoded in DAG topology

Execution Models:
- Sequential: Linear DAG edges (A->B->C)
- Parallel: Multiple agents at same topological level execute concurrently
- Hierarchical: Coordinator node with subgraph delegation
- Hybrid: Mixed topology (parallel stages + sequential connections)
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from apps.agent.factory.completion import TRUNCATION_NOTE
from apps.agent.streaming import stream_agent_sync
from apps.tool.async_bridge import get_main_loop, set_main_loop
from echolib.agent_contract import (
    collaboration_context_limit,
    collaboration_inherits,
    collaboration_publishes,
)
from apps.tool.langchain_tools import (
    build_langchain_tools as _build_langchain_tools,
    format_tool_success_output,
    invoke_tool_with_compat,
    resolve_tool_executor,
)
from echolib.llm_errors import (
    extract_retry_after_seconds,
    is_rate_limit_error,
)

from .node_outputs import (
    TYPE_AGENT,
    node_output_entry,
    ordered_outputs,
    render_outputs,
    render_within_budget,
    protected_tail_count as _protected_tail_count,
)

logger = logging.getLogger(__name__)

# Phase 10 removed ``MAX_UPSTREAM_CONTEXT_CHARS`` and ten underscore-prefixed
# aliases into ``apps.tool`` and ``echolib``. The constant was superseded by the
# per-agent ``collaboration_context.max_context_chars`` in Phase 8, and a sweep
# found no production reference to any of the names. The one remaining caller is
# ``tests/test_langchain_adapter_budget.py``, which monkeypatched
# ``_resolve_tool_executor``; that patch stopped affecting execution in Phase 2
# when the implementation moved, so the correct target is
# ``apps.tool.langchain_tools.resolve_tool_executor``.


# ---------------------------------------------------------------------------
# Transparency
# ---------------------------------------------------------------------------


def _transparency_on() -> bool:
    """Check if transparency/step tracking is enabled."""
    try:
        from echolib.config import settings

        return bool(getattr(settings, "transparency_enabled", False))
    except Exception:
        return False


def _emit_tool_started(run_id, tool_id, tool_name, kwargs) -> Optional[str]:
    """Emit a TOOL_CALL started event; returns the step id (or None)."""
    if not run_id or not _transparency_on():
        return None
    try:
        from echolib.utils import new_id

        from .event_publisher import publish_step_started_sync
        from .transparency import StepType

        step = new_id("tool_")
        publish_step_started_sync(
            run_id,
            step,
            str(tool_name or tool_id),
            StepType.TOOL_CALL,
            {"tool": tool_id, "args_preview": str(kwargs)[:200]},
        )
        return step
    except Exception as e:
        logger.warning(f"Failed to emit tool started event: {e}")
        return None


def _emit_tool_completed(run_id, step_id, result) -> None:
    """Emit a TOOL_CALL completed event."""
    if not run_id or not step_id or not _transparency_on():
        return
    try:
        from .event_publisher import publish_step_completed_sync

        publish_step_completed_sync(
            run_id,
            step_id,
            {"result_preview": str(result)[:500]},
        )
    except Exception as e:
        logger.warning(f"Failed to emit tool completed event: {e}")


def tool_transparency_hooks(run_id: Optional[str]):
    """Bind transparency emission to a run id for injection into the tool builder."""

    def on_start(tool_id: str, tool_name: str, kwargs: Dict[str, Any]) -> Optional[str]:
        return _emit_tool_started(run_id, tool_id, tool_name, kwargs)

    def on_end(step_id: Optional[str], result: Any) -> None:
        _emit_tool_completed(run_id, step_id, result)

    return on_start, on_end


def agent_token_publisher(
    run_id: Optional[str], step_id: str, step_name: str
) -> Optional[Any]:
    """
    Build the event consumer that streams an agent node's output to the canvas.

    WHAT: Coalesces token events and publishes each batch as a ``step_token``
          frame on the run's WebSocket.
    WHY:  A node used to be visible only at its boundaries -- started, then much
          later completed -- so a long agent step was indistinguishable from a
          stalled one. The events already existed for tool calls; the model's own
          output had no channel.
    INPUT: Run id, the step this agent occupies, and its display name.
    OUTPUT: A callable for ``stream_agent_sync(on_event=...)``, or ``None`` when
            transparency is off -- in which case the stream is still consumed but
            nothing is published, so there is no cost to leaving it wired.

    Returns ``None`` rather than a no-op callable so the caller can skip
    coalescing entirely when nobody is listening.
    """
    if not run_id or not _transparency_on():
        return None

    from apps.agent.streaming import (
        EVENT_FINAL,
        EVENT_TOKEN,
        TokenCoalescer,
    )

    from .event_publisher import publish_step_token_sync

    coalescer = TokenCoalescer()

    def _publish(text: str) -> None:
        if not text:
            return
        try:
            publish_step_token_sync(run_id, step_id, text, coalescer.seq, step_name)
        except Exception:
            logger.debug("Failed to publish agent token event", exc_info=True)

    def on_event(event: Any) -> None:
        if event.type == EVENT_TOKEN:
            batch = coalescer.add(event.text)
            if batch:
                _publish(batch)
        elif event.type == EVENT_FINAL:
            # Whatever is still buffered, so the last words of an answer are not
            # withheld waiting for a flush threshold that will never be reached.
            _publish(coalescer.flush() or "")

    return on_event


def build_langchain_tools(
    tool_specs: List[Dict[str, Any]],
    exec_context: Dict[str, Any],
    user_id: str,
    run_id: str,
    tool_budget_state: Optional[Dict[str, Any]] = None,
):
    """Build LangChain tools for a workflow node, wired to transparency events.

    Thin wrapper over ``apps.tool.langchain_tools.build_langchain_tools`` that
    supplies the workflow-specific observability hooks.
    """
    on_start, on_end = tool_transparency_hooks(run_id)
    return _build_langchain_tools(
        tool_specs,
        exec_context,
        user_id,
        run_id,
        tool_budget_state,
        on_tool_start=on_start,
        on_tool_end=on_end,
    )


# ---------------------------------------------------------------------------
# Agent nodes
# ---------------------------------------------------------------------------


def _explain_failure(exc: BaseException) -> str:
    """
    Turn a provider failure into something the reader can act on.

    WHAT: Recognises failures the platform knows how to explain and returns a
          sentence naming the setting to change; falls back to the original
          message for everything else.
    WHY:  A node's error becomes the workflow's user-facing output. A raw
          ``400 - {'error': {'message': "Function tools with reasoning_effort
          are not supported..."}}`` was shown verbatim to the person who had
          simply set Reasoning Effort to High in the LLM form, with nothing
          connecting the two.
    OUTPUT: A message. Never raises, and never hides the original text when it
            has nothing better to offer.

    Keyed on the provider's own words rather than on a model name, so it keeps
    working for models this platform has never seen.
    """
    try:
        from echolib.model_capabilities import (
            MIN_RESPONSES_API_VERSION,
            is_tool_reasoning_conflict,
        )

        if is_tool_reasoning_conflict(exc):
            return (
                "this model does not accept a reasoning effort together with "
                "tools on the Chat Completions API. Set the credential's API "
                f"Version to {MIN_RESPONSES_API_VERSION} or later so the "
                "Responses API can be used, or set Reasoning Effort to 'none' "
                "in the model's settings."
            )
    except Exception:  # noqa: BLE001 -- explanation must never mask the error
        pass
    return str(exc)


def resolve_agent_factory():
    """Resolve the shared AgentFactory, constructing a stateless one if DI is cold."""
    try:
        from echolib.di import container

        return container.resolve("agent.factory")
    except Exception:
        logger.debug("agent.factory not registered; using a local factory", exc_info=True)
        from apps.agent.factory import AgentFactory

        try:
            from apps.tool.container import get_registry

            return AgentFactory(tool_registry=get_registry())
        except Exception:
            return AgentFactory()


def build_agent_task(agent_config: Dict[str, Any], state: Dict[str, Any]) -> str:
    """Assemble the agent's task from the original request plus upstream output."""
    task = (
        state.get("original_user_input")
        or state.get("user_input")
        or state.get("task_description")
        or ""
    )

    # ``inherit_upstream`` is the per-agent switch from the Phase 1 contract:
    # an agent can be configured to answer from the original request alone,
    # ignoring whatever ran before it.
    if not collaboration_inherits(agent_config):
        return _with_reviewer_feedback(task, state)

    input_schema = agent_config.get("input_schema", []) or []

    # Every executed node's output, in deterministic order, when a fan-in has
    # accumulated one. Falls back to ``last_node_output`` for sequential graphs,
    # where the accumulator is empty and "the previous node" is the whole of
    # the upstream context.
    accumulated = _accumulated_upstream(state)
    upstream = accumulated or state.get("last_node_output")
    if not upstream and input_schema:
        upstream = {k: state.get(k) for k in input_schema if state.get(k) is not None} or None

    if upstream:
        # Ceiling comes from the agent's own collaboration_context rather than
        # a module constant. The hardcoded 4000 truncated a multi-branch
        # summary far more aggressively than a single upstream output, which is
        # exactly backwards.
        limit = resolve_upstream_limit(agent_config)
        if accumulated:
            # Every contributing node keeps a share of the budget.
            rendered = render_within_budget(accumulated, limit)
            full_length = len(render_outputs(accumulated))
            if full_length > limit:
                name = (
                    agent_config.get("name")
                    or agent_config.get("agent_id")
                    or "unknown"
                )
                protected = _protected_tail_count(accumulated, limit)
                # Indented block rather than one long sentence: this is read
                # while diagnosing a bad report, and the three numbers that
                # matter -- what was produced, what was delivered, and which
                # nodes survived whole -- were previously buried mid-paragraph.
                logger.info(
                    "\n"
                    "  ┌─ UPSTREAM CONTEXT ─ agent: %s\n"
                    "  │  nodes contributing : %d\n"
                    "  │  produced           : %s chars\n"
                    "  │  delivered          : %s chars  (budget %s)\n"
                    "  │  delivered COMPLETE : the %d most recent node(s)\n"
                    "  │  abbreviated        : the %d older node(s)\n"
                    "  └─ raise settings.agent_upstream_context_chars, or register a\n"
                    "     larger Context Window on this agent's model, to widen it.",
                    name,
                    len(accumulated),
                    f"{full_length:,}",
                    f"{len(rendered):,}",
                    f"{limit:,}",
                    protected,
                    max(0, len(accumulated) - protected),
                )
            task = f"{task}\n\nUpstream context:\n{rendered}"
            return _with_reviewer_feedback(task, state)

        rendered = str(upstream)
        if len(rendered) > limit:
            rendered = (
                rendered[:limit].rstrip()
                + f"\n… upstream context truncated at {limit} characters."
            )
            logger.info(
                "Upstream context for agent '%s' cut from %d to %d characters. "
                "Register a larger Context Window against this agent's model, "
                "or raise settings.agent_upstream_context_chars, to widen it.",
                agent_config.get("name") or agent_config.get("agent_id") or "unknown",
                len(str(upstream)), limit,
            )
        task = f"{task}\n\nUpstream context:\n{rendered}"

    return _with_reviewer_feedback(task, state)


def resolve_upstream_limit(agent_config: Dict[str, Any]) -> int:
    """
    How much upstream context this agent may be handed, in characters.

    WHAT: The contract's per-agent allowance, bounded by what the agent's model
          can actually hold.
    WHY:  The allowance has to grow -- 8,000 characters is a fraction of what
          fifteen agents produce, and cutting there is why a downstream writer
          never saw the analysis it was meant to build on. But it cannot grow
          blind: a large prompt sent to a small-context model fails the run
          outright, and this function is called before the model is built, so
          the window is read from the credential's registered capability rather
          than from a live client.
    INPUT: The agent definition.
    OUTPUT: A positive character count. Never raises.

    When the window is unknown -- a self-hosted endpoint, or a deployment name
    LangChain has no profile for and no Context Window registered against the
    credential -- the smaller ``agent_upstream_context_chars_unverified`` applies.
    Guessing high there trades a shallow answer for a failed run, which is a
    worse trade. Registering a Context Window is what unlocks the full value.
    """
    limit = collaboration_context_limit(agent_config)

    try:
        from echolib.config import settings

        window = _model_context_window(agent_config)
        if window is None:
            unverified = int(
                getattr(settings, "agent_upstream_context_chars_unverified", 24000)
            )
            return max(1, min(limit, unverified))

        share = float(getattr(settings, "agent_upstream_context_window_share", 0.5))
        # Four characters per token, the same rough conversion the descriptor
        # budgets in ``agent/factory/factory.py`` use. Exact tokenization varies
        # per model and is not worth a tokenizer dependency for a bound whose
        # purpose is to stop growth, not to measure it.
        allowed = int(window * max(0.05, min(share, 0.9)) * 4)
        return max(1, min(limit, allowed))
    except Exception:  # noqa: BLE001 -- a bad tuning value must not fail a node
        logger.debug("Upstream limit resolution fell back to the contract value", exc_info=True)
        return limit


# Credential id -> (context window in tokens, or None). Populated on first use
# and held for the process.
#
# A credential's deployment and its registered context window do not change
# during a run, and this is consulted once per agent node -- fifteen times for a
# fifteen-agent workflow. Caching turns that into one lookup per credential
# while keeping the answer correct; re-reading it every time was the reason the
# original implementation avoided the lookup altogether and read the wrong name
# instead.
_CREDENTIAL_WINDOWS: Dict[str, Optional[int]] = {}


def _credential_context_window(credential_id: str, user_id: Optional[str]) -> Optional[int]:
    """
    The input window of the model a credential actually points at, or ``None``.

    Reads the credential's registered ``context_window`` first -- the
    registrar's own statement, which outranks any table -- and otherwise
    classifies its **deployment name**, which for Azure is the only name that
    identifies the model.
    """
    if credential_id in _CREDENTIAL_WINDOWS:
        return _CREDENTIAL_WINDOWS[credential_id]

    window: Optional[int] = None
    try:
        from echolib.credential_resolver import resolve_llm_credential_sync
        from echolib.model_capabilities import context_window_for

        creds = resolve_llm_credential_sync(
            str(user_id or ""), credential_id=str(credential_id)
        )
        if isinstance(creds, dict):
            window = context_window_for(
                creds.get("deployment_name"),
                creds.get("model"),
                declared=creds.get("context_window"),
            )
    except Exception:  # noqa: BLE001 -- a lookup must never fail a node
        logger.debug("Credential window lookup failed", exc_info=True)

    _CREDENTIAL_WINDOWS[credential_id] = window
    return window


def _model_context_window(agent_config: Dict[str, Any]) -> Optional[int]:
    """
    The input window this agent's model is known to accept, or ``None``.

    WHY THE CREDENTIAL IS CONSULTED FIRST: an agent's ``model_config.model`` is
    what its author typed, and it is frequently **not** the model the run lands
    on. A production credential named and deployed as ``gpt-5.6-terra`` carried
    ``model_name: gpt-4o`` in its metadata, so this function answered 128,000
    for a model whose real window is 1,050,000 -- and the upstream allowance was
    sized against the wrong model by a factor of eight. Reading the agent's name
    alone cannot detect that; the credential is the only thing that knows which
    deployment the request actually reaches.

    Order: the credential the agent is pinned to, then the names the definition
    carries. ``None`` means the platform does not know, and the caller must then
    be conservative -- the same rule ``build_summarization_middleware`` applies
    before it will attach at all.
    """
    try:
        from echolib.model_capabilities import context_window_for

        model_config = agent_config.get("model_config")
        candidates = []
        if isinstance(model_config, dict):
            candidates.append(model_config.get("model"))
        if isinstance(agent_config.get("model"), str):
            candidates.append(agent_config.get("model"))
        settings_block = agent_config.get("settings")
        if isinstance(settings_block, dict):
            candidates.append(settings_block.get("model"))

        credential_id = agent_config.get("credential_id")
        if credential_id:
            user_id = (
                agent_config.get("_runtime_user_id")
                or agent_config.get("user_id")
                or ""
            )
            from_credential = _credential_context_window(str(credential_id), user_id)
            if from_credential:
                # Larger of the two. The agent's own name is still consulted
                # because an agent may deliberately override the model on a
                # shared credential, and the intent here is only ever to stop
                # under-sizing against a name that does not identify the run.
                declared = context_window_for(*candidates)
                return max(from_credential, declared or 0)

        return context_window_for(*candidates)
    except Exception:  # noqa: BLE001 -- a lookup must never fail a node
        return None


def _with_reviewer_feedback(task: str, state: Dict[str, Any]) -> str:
    """
    Append the HITL reviewer's requested changes to an agent's task.

    WHAT: Adds ``_edit_feedback`` -- set by the HITL node when a reviewer
          chooses "Request changes" -- to the end of the assembled task.
    WHY:  The edit loop routed correctly and delivered nothing. The HITL node
          wrote the reviewer's text to ``_edit_feedback``
          (``compiler._create_hitl_node``) and to ``task_description``, and
          neither reached a model: nothing read ``_edit_feedback``, and
          ``task_description`` is the third choice in the assembly above, behind
          ``original_user_input``, which every executor entry point always sets.
          So the re-run agent received byte-identical input and produced the
          same answer. A reviewer could ask for changes indefinitely and nothing
          would change.
    INPUT: The task assembled so far, and the workflow state.
    OUTPUT: The task with the feedback appended, or unchanged when there is
            none -- which is every run that is not a re-run after an edit.

    Appended **last**, after the upstream context, so it is the final thing the
    model reads and sits next to the output it is correcting. The text arrives
    already framed by the node ("you MUST incorporate this feedback…"), so it is
    passed through rather than wrapped a second time.

    ``_hitl_route``-driven re-entry clears the key on the way back into the
    checkpoint, so feedback from one round cannot leak into the next.
    """
    feedback = state.get("_edit_feedback")
    if not isinstance(feedback, str):
        return task

    feedback = feedback.strip()
    if not feedback:
        return task

    return f"{task}\n\n{feedback}" if task else feedback


def _accumulated_upstream(state: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
    """
    Render every node output collected so far, ordered deterministically.

    WHAT: Reads the ``all_node_outputs`` accumulator and formats it with a
          heading per contributing node.
    WHY:  On a parallel branch ``last_node_output`` holds whichever node
          happened to write last -- the other branches are simply absent from
          it. This is what hands a downstream agent the whole fan-in instead of
          one arbitrary slice of it.
    OUTPUT: The usable **entries**, or ``None`` when fewer than two nodes have
            contributed -- so sequential graphs fall through to their existing
            behaviour untouched, since one contributor is not a fan-in and
            ``last_node_output`` already says the same thing more directly.

    Entries rather than rendered text: the caller divides its character budget
    across the nodes, and it can only do that if it can still see where one
    node's output ends and the next begins.
    """
    entries = state.get("all_node_outputs") if isinstance(state, dict) else None
    if not entries or not isinstance(entries, list):
        return None

    # ``ordered_outputs`` owns the definition of a usable entry, so the count
    # below cannot drift from what was actually rendered.
    usable = ordered_outputs(entries)
    if len(usable) < 2:
        return None

    # The entries are returned rather than rendered text so the caller can
    # divide its budget across nodes. Rendering here and trimming there is what
    # discarded whole agents: a single cut at N characters keeps the earliest
    # nodes and drops every later one.
    return usable


def create_react_agent_node(agent_config: Dict[str, Any], seq: int = 0) -> Callable:
    """Create a LangGraph node function that executes this agent.

    The agent is compiled by ``AgentFactory.build`` -- the same call standalone
    chat and application components use -- so a workflow node and a direct chat
    produce identical behaviour for the same definition.

    Args:
        agent_config: Agent configuration dict
        seq: The node's position in compile order, assigned by the compiler and
            carried on this node's ``all_node_outputs`` entry. It is what makes
            a fan-in order its branches by graph position. This used to be read
            from ``state["_node_seq"]``, a key no node has ever written, so
            every entry sorted at 0 and ties broke alphabetically.

    Returns:
        Node function (state: Dict) -> Dict that executes the agent
    """

    def node(state: Dict[str, Any]) -> Dict[str, Any]:
        from echolib.config import settings
        from echolib.utils import new_id

        agent_id = agent_config.get("agent_id") or agent_config.get("name", "agent")
        agent_name = agent_config.get("name", agent_id)
        agent_role = agent_config.get("role", "Processing")
        output_schema = agent_config.get("output_schema", []) or ["output"]
        user_id = agent_config.get("_runtime_user_id")
        exec_context = state.get("_aura_exec") or {}

        task = build_agent_task(agent_config, state)
        run_id = state.get("run_id", "unknown")
        step_id = new_id("step_")
        _transparency = getattr(settings, "transparency_enabled", False)

        if _transparency:
            try:
                from .event_publisher import publish_step_started_sync
                from .transparency import StepType, step_tracker

                summary = {"agent_name": agent_name, "agent_role": agent_role, "engine": "langchain"}
                step_tracker.start_step(run_id, step_id, agent_name, StepType.AGENT, summary)
                publish_step_started_sync(run_id, step_id, agent_name, StepType.AGENT, summary)
            except Exception:
                logger.debug("Failed to emit agent started event", exc_info=True)

        # Recorded on the step so a run is attributable to the credential and
        # model that produced it, and to the connectors it could reach. Only
        # known after the agent is built, so it is attached at step completion
        # rather than at step start.
        step_metadata: Dict[str, Any] = {}

        try:
            on_start, on_end = tool_transparency_hooks(run_id)
            build = resolve_agent_factory().build_with_context(
                agent_config,
                user_id=user_id,
                exec_context=exec_context,
                run_id=run_id,
                on_tool_start=on_start,
                on_tool_end=on_end,
                component="agent_executor",
                request=task or "",
                readiness_state=state,
            )
            step_metadata = {"llm": build.llm_metadata()}
            connector_metadata = build.connector_metadata()
            if connector_metadata:
                step_metadata["connectors"] = connector_metadata
            context_metadata = build.context_metadata()
            if context_metadata:
                step_metadata["context"] = context_metadata
            readiness_metadata = build.readiness_metadata()
            if readiness_metadata:
                step_metadata["readiness"] = readiness_metadata

            # Context Readiness Gate (spec 4.3). Reached only in ``block`` mode:
            # in ``warn`` -- the default -- the same findings are already in the
            # system prompt and this is skipped, and in ``off`` there are none.
            #
            # The node returns normally with the explanation as its output. It
            # does NOT raise: one unready agent must not fail an entire workflow
            # run, and downstream nodes are entitled to see why this one
            # produced no result. ``step_metadata.readiness`` records the codes.
            if build.blocked:
                logger.info(
                    "Readiness gate blocked agent '%s' in workflow node", agent_id
                )
                output = build.readiness_message(agent_name)
            else:
                # Model-call ceiling, tool budget and retry are enforced by the
                # factory's middleware stack; no loop or counter belongs here.
                #
                # Streamed rather than invoked, so the canvas shows the answer as
                # it is written. The final text is identical to what
                # ``invoke_agent`` returned -- ``stream_agent_sync`` aggregates
                # the same messages and falls back to the completed message when
                # a provider does not stream -- so the node's return contract is
                # unchanged.
                output = stream_agent_sync(
                    build.agent,
                    task or agent_config.get("description") or agent_name,
                    on_event=agent_token_publisher(run_id, step_id, agent_name),
                )

                # A node that stopped at its output ceiling hands a half-written
                # result to everything downstream. ``stream_agent_sync`` marks
                # the text; recording it here is what makes a shallow run
                # answerable from the run record rather than only from the text.
                if TRUNCATION_NOTE in output:
                    step_metadata["output_truncated"] = True
                    logger.warning(
                        "Agent '%s' stopped at its output ceiling. Its result is "
                        "incomplete and every downstream node receives it that "
                        "way. Raise Max Tokens on this agent.",
                        agent_name,
                    )
        except Exception as e:
            if is_rate_limit_error(e):
                retry_after = extract_retry_after_seconds(e)
                logger.error(
                    "LangChain agent '%s' failed with rate limit (retry_after=%s): %s",
                    agent_id,
                    retry_after,
                    e,
                    exc_info=True,
                )
                retry_hint = (
                    f" Retry after approximately {retry_after} seconds."
                    if retry_after is not None
                    else ""
                )
                output = f"Error in {agent_name}: rate limit exceeded on model provider.{retry_hint}"
            else:
                logger.error("LangChain agent '%s' failed: %s", agent_id, e, exc_info=True)
                output = f"Error in {agent_name}: {_explain_failure(e)}"

        if _transparency:
            try:
                from .event_publisher import publish_step_completed_sync
                from .transparency import step_tracker

                out_summary = {"output_preview": str(output)[:500], "agent_name": agent_name}
                step_tracker.complete_step(run_id, step_id, out_summary, metadata=step_metadata or None)
                publish_step_completed_sync(run_id, step_id, out_summary)
            except Exception:
                logger.debug("Failed to emit agent completed event", exc_info=True)

        outputs = {key: output for key in output_schema}

        # Contribute to the shared accumulator (Phase 8).
        #
        # This one entry is what stops parallel agent outputs being destroyed.
        # API, MCP and Code nodes have always written ``all_node_outputs``;
        # agent nodes never did, so on a parallel branch each agent wrote only
        # ``last_node_output`` -- a last-writer-wins field -- and N agents
        # produced N answers of which exactly one survived to the fan-in. No
        # error was raised, because the reducer accepts concurrent writes.
        #
        # ``publish_downstream`` is the per-agent switch from the Phase 1
        # contract: an agent can be told to run without contributing its output
        # to the shared context that later nodes read.
        contributions: Dict[str, Any] = {}
        if collaboration_publishes(agent_config):
            contributions["all_node_outputs"] = [
                node_output_entry(
                    agent_id,
                    output,
                    node_type=TYPE_AGENT,
                    node_name=agent_name,
                    seq=seq,
                )
            ]

        return {
            **outputs,
            **contributions,
            "crew_result": output,  # Keep for backward compat
            "_last_agent_output": output,
            "last_node_output": output,
            "messages": [
                {
                    "agent": agent_id,
                    "role": agent_role,
                    "engine": "langchain",
                    "outputs": outputs,
                }
            ],
        }

    return node


def create_tool_node(tool_spec: Dict[str, Any], exec_context: Dict[str, Any]) -> Callable:
    """Create a LangGraph node function for direct tool execution.

    Args:
        tool_spec: Tool specification
        exec_context: Execution context

    Returns:
        Node function (state: Dict) -> Dict
    """

    def node(state: Dict[str, Any]) -> Dict[str, Any]:
        from echolib.config import settings
        from echolib.utils import new_id

        tool_id = tool_spec.get("tool_id") or tool_spec.get("id")
        tool_name = tool_spec.get("name", tool_id)
        run_id = state.get("run_id", "unknown")
        user_id = state.get("_runtime_user_id")
        step_id = new_id("step_")
        _transparency = getattr(settings, "transparency_enabled", False)

        if _transparency:
            try:
                from .event_publisher import publish_step_started_sync
                from .transparency import StepType, step_tracker

                summary = {"tool": tool_id, "tool_name": tool_name, "engine": "langchain"}
                step_tracker.start_step(run_id, step_id, tool_name, StepType.TOOL_CALL, summary)
                publish_step_started_sync(run_id, step_id, tool_name, StepType.TOOL_CALL, summary)
            except Exception:
                logger.debug("Failed to emit tool node started event", exc_info=True)

        try:
            executor = resolve_tool_executor()
            if executor is None:
                raise RuntimeError("Tool system unavailable")
            input_data = {
                k: state.get(k) for k in tool_spec.get("input_schema", []) if state.get(k) is not None
            }
            output = invoke_tool_with_compat(
                executor,
                tool_id=tool_id,
                input_data=input_data,
                user_id=user_id,
                exec_context=exec_context,
                timeout_seconds=300,
            )
            output = format_tool_success_output(output)
        except Exception as e:
            logger.error("Tool '%s' execution failed: %s", tool_name, e, exc_info=True)
            output = f"Error in {tool_name}: {e}"

        if _transparency:
            try:
                from .event_publisher import publish_step_completed_sync
                from .transparency import step_tracker

                out_summary = {"output_preview": str(output)[:500]}
                step_tracker.complete_step(run_id, step_id, out_summary)
                publish_step_completed_sync(run_id, step_id, out_summary)
            except Exception:
                logger.debug("Failed to emit tool node completed event", exc_info=True)

        output_schema = tool_spec.get("output_schema", []) or ["output"]
        outputs = {key: output for key in output_schema}
        return {
            **outputs,
            "_last_tool_output": output,
            "last_node_output": output,
        }

    return node


def create_coordinator_node(
    agents: List[Dict[str, Any]], exec_context: Dict[str, Any]
) -> Callable:
    """Create a coordinator node for hierarchical execution.

    The coordinator delegates work to multiple agents and aggregates results.

    Args:
        agents: List of agent configs
        exec_context: Execution context

    Returns:
        Node function (state: Dict) -> Dict
    """

    def node(state: Dict[str, Any]) -> Dict[str, Any]:
        """Coordinator delegates to agents and aggregates results."""
        from echolib.config import settings
        from echolib.utils import new_id

        run_id = state.get("run_id", "unknown")
        step_id = new_id("step_")
        _transparency = getattr(settings, "transparency_enabled", False)

        if _transparency:
            try:
                from .event_publisher import publish_step_started_sync
                from .transparency import StepType, step_tracker

                summary = {
                    "coordinator": "hierarchical",
                    "num_agents": len(agents),
                    "engine": "langchain",
                }
                step_tracker.start_step(run_id, step_id, "Coordinator", StepType.COORDINATOR, summary)
                publish_step_started_sync(run_id, step_id, "Coordinator", StepType.COORDINATOR, summary)
            except Exception:
                logger.debug("Failed to emit coordinator started event", exc_info=True)

        outputs = {"delegated_results": [], "coordinator_output": ""}

        try:
            # Execute each agent
            for agent_config in agents:
                agent_node = create_react_agent_node(agent_config)
                agent_state = {**state, "_aura_exec": exec_context}
                result = agent_node(agent_state)
                outputs["delegated_results"].append(
                    {
                        "agent": agent_config.get("name"),
                        "result": result.get("last_node_output"),
                    }
                )

            outputs["coordinator_output"] = str(outputs["delegated_results"])

        except Exception as e:
            logger.error("Coordinator failed: %s", e, exc_info=True)
            outputs["coordinator_output"] = f"Coordinator error: {e}"

        if _transparency:
            try:
                from .event_publisher import publish_step_completed_sync
                from .transparency import step_tracker

                out_summary = {"results_count": len(outputs["delegated_results"])}
                step_tracker.complete_step(run_id, step_id, out_summary)
                publish_step_completed_sync(run_id, step_id, out_summary)
            except Exception:
                logger.debug("Failed to emit coordinator completed event", exc_info=True)

        return {
            "last_node_output": outputs["coordinator_output"],
            "delegated_results": outputs["delegated_results"],
        }

    return node


__all__ = [
    "build_agent_task",
    "build_langchain_tools",
    "create_coordinator_node",
    "create_react_agent_node",
    "create_tool_node",
    "get_main_loop",
    "resolve_agent_factory",
    "set_main_loop",
    "tool_transparency_hooks",
]
