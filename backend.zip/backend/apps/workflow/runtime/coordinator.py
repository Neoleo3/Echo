"""
Hierarchical Workflow Coordinator for Sub-Agent Aggregation.

Manages aggregation of outputs from parallel sub-agents in hierarchical
workflow topologies. Supports multiple aggregation strategies:
- merge: Deep merge of dictionaries
- list: Collect outputs as array with agent metadata
- summary: Aggregate into a summary report

Phase: D (Production Integration)
"""

import logging
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class AggregationStrategy(str, Enum):
    """Strategy for aggregating sub-agent outputs."""
    MERGE = "merge"      # Deep merge outputs (for object outputs)
    LIST = "list"        # Collect as array with metadata
    SUMMARY = "summary"  # Generate aggregated summary report


@dataclass
class SubAgentOutput:
    """Represents output from a sub-agent in hierarchical workflow."""
    agent_name: str              # Name of the sub-agent
    agent_id: str                # Unique agent ID
    output: Dict[str, Any]       # Agent output dict
    execution_time_ms: int = 0   # Execution duration
    status: str = "completed"    # Status: completed, failed, cancelled
    error: Optional[str] = None  # Error message if failed


class CoordinatorAgent:
    """
    Hierarchical coordinator for sub-agent output aggregation.
    
    Responsibilities:
    - Collect outputs from parallel sub-agents
    - Apply aggregation strategy (merge/list/summary)
    - Combine with coordinator context
    - Return aggregated result
    
    Usage in LangGraph:
        coordinator = CoordinatorAgent()
        aggregated = await coordinator.aggregate_sub_agent_outputs(
            sub_outputs=[
                SubAgentOutput("agent1", "id1", {...}),
                SubAgentOutput("agent2", "id2", {...}),
            ],
            strategy="merge",
            coordinator_context={...}
        )
    """
    
    def __init__(self, coordinator_id: str = "coordinator", name: str = "Coordinator"):
        """
        Initialize coordinator agent.
        
        Args:
            coordinator_id: Unique ID for this coordinator
            name: Display name for the coordinator
        """
        self.coordinator_id = coordinator_id
        self.name = name
        self._execution_history: List[Dict[str, Any]] = []
    
    @staticmethod
    async def aggregate_sub_agent_outputs(
        sub_outputs: List[SubAgentOutput],
        strategy: str = "merge",
        coordinator_context: Optional[Dict[str, Any]] = None,
        aggregation_rules: Optional[Dict[str, Callable]] = None
    ) -> Dict[str, Any]:
        """
        Aggregate outputs from multiple sub-agents.
        
        Applies the specified aggregation strategy to combine outputs
        from parallel sub-agents. Supports three strategies:
        
        1. merge: Deep merge all outputs into single dict
           Use for: Combining feature extraction, analysis results
           Example: agent1 extracts metrics, agent2 extracts sentiment
                   → merged dict with both keys
        
        2. list: Collect outputs as array with agent metadata
           Use for: Parallel processing with tracking
           Example: 10 document analyzers produce 10 outputs
                   → array of {agent_name, agent_id, output, status}
        
        3. summary: Generate aggregated summary report
           Use for: High-level overview across agents
           Example: Multiple data processors
                   → single summary doc with stats and highlights
        
        Args:
            sub_outputs: List of SubAgentOutput from parallel agents
            strategy: Aggregation strategy - "merge", "list", or "summary"
            coordinator_context: Additional context (e.g., {"domain": "finance"})
            aggregation_rules: Custom rules for merge strategy
                Example: {"metrics": "combine_numeric", "tags": "union"}
        
        Returns:
            Aggregated output dict with structure depending on strategy
        
        Raises:
            ValueError: If strategy is unknown
            TypeError: If sub_outputs format is invalid
        
        Example:
            >>> outputs = [
            ...     SubAgentOutput("sentiment", "s1", {"polarity": 0.8}),
            ...     SubAgentOutput("entities", "e1", {"entities": ["PERSON", "ORG"]})
            ... ]
            >>> result = await CoordinatorAgent.aggregate_sub_agent_outputs(
            ...     outputs, strategy="merge"
            ... )
            >>> # result = {
            ... #     "polarity": 0.8,
            ... #     "entities": ["PERSON", "ORG"],
            ... #     "_aggregation_metadata": {...}
            ... # }
        """
        if not sub_outputs:
            logger.warning("aggregate_sub_agent_outputs called with empty sub_outputs")
            return {
                "aggregated": {},
                "_aggregation_metadata": {
                    "strategy": strategy,
                    "agent_count": 0,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "context": coordinator_context or {}
                }
            }
        
        strategy_lower = strategy.lower()
        
        if strategy_lower == AggregationStrategy.MERGE.value:
            return await CoordinatorAgent._merge_outputs(
                sub_outputs, coordinator_context, aggregation_rules
            )
        elif strategy_lower == AggregationStrategy.LIST.value:
            return await CoordinatorAgent._list_outputs(
                sub_outputs, coordinator_context
            )
        elif strategy_lower == AggregationStrategy.SUMMARY.value:
            return await CoordinatorAgent._summary_outputs(
                sub_outputs, coordinator_context
            )
        else:
            raise ValueError(
                f"Unknown aggregation strategy: {strategy}. "
                f"Valid options: {', '.join(s.value for s in AggregationStrategy)}"
            )
    
    @staticmethod
    async def _merge_outputs(
        sub_outputs: List[SubAgentOutput],
        coordinator_context: Optional[Dict[str, Any]],
        aggregation_rules: Optional[Dict[str, Callable]]
    ) -> Dict[str, Any]:
        """
        Merge sub-agent outputs into single flattened dictionary.
        
        Deep merges outputs, handling conflicts based on aggregation rules.
        For dict values, recursively merges. For arrays, unions them.
        
        Args:
            sub_outputs: List of SubAgentOutput to merge
            coordinator_context: Additional context
            aggregation_rules: Custom merge rules per key
        
        Returns:
            Merged dictionary with all outputs combined
        """
        merged = {}
        agent_errors = []
        
        for sub_output in sub_outputs:
            if sub_output.status != "completed":
                agent_errors.append({
                    "agent": sub_output.agent_name,
                    "status": sub_output.status,
                    "error": sub_output.error
                })
                continue
            
            # Deep merge agent output
            for key, value in sub_output.output.items():
                if key not in merged:
                    merged[key] = value
                elif aggregation_rules and key in aggregation_rules:
                    # Apply custom merge rule
                    merge_fn = aggregation_rules[key]
                    try:
                        merged[key] = merge_fn(merged[key], value)
                    except Exception as e:
                        logger.warning(
                            f"Custom aggregation rule failed for key '{key}': {e}. "
                            f"Keeping existing value."
                        )
                elif isinstance(merged[key], dict) and isinstance(value, dict):
                    # Recursive merge for nested dicts
                    merged[key] = {**merged[key], **value}
                elif isinstance(merged[key], list) and isinstance(value, list):
                    # Union arrays
                    merged[key] = list(set(merged[key] + value))
                else:
                    # Default: last-write-wins
                    logger.debug(
                        f"Merge conflict for key '{key}': "
                        f"overwriting {merged[key]!r} with {value!r}"
                    )
                    merged[key] = value
        
        # Add metadata
        merged["_aggregation_metadata"] = {
            "strategy": AggregationStrategy.MERGE.value,
            "agent_count": len([s for s in sub_outputs if s.status == "completed"]),
            "failed_agents": len(agent_errors),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "context": coordinator_context or {},
            "errors": agent_errors if agent_errors else None
        }
        
        logger.info(
            f"Merged {len(sub_outputs)} sub-agent outputs",
            extra={
                "successful_agents": len(sub_outputs) - len(agent_errors),
                "failed_agents": len(agent_errors),
                "merged_keys": len(merged) - 1  # exclude metadata key
            }
        )
        
        return merged
    
    @staticmethod
    async def _list_outputs(
        sub_outputs: List[SubAgentOutput],
        coordinator_context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Collect sub-agent outputs as array with metadata.
        
        Each output includes agent name, ID, execution time, and status
        for tracking and debugging.
        
        Args:
            sub_outputs: List of SubAgentOutput to collect
            coordinator_context: Additional context
        
        Returns:
            Dict with outputs array and metadata
        """
        outputs_list = [
            {
                "agent_name": sub_output.agent_name,
                "agent_id": sub_output.agent_id,
                "output": sub_output.output,
                "execution_time_ms": sub_output.execution_time_ms,
                "status": sub_output.status,
                "error": sub_output.error
            }
            for sub_output in sub_outputs
        ]
        
        successful_count = sum(1 for s in sub_outputs if s.status == "completed")
        
        result = {
            "outputs": outputs_list,
            "_aggregation_metadata": {
                "strategy": AggregationStrategy.LIST.value,
                "agent_count": len(sub_outputs),
                "successful_agents": successful_count,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "context": coordinator_context or {}
            }
        }
        
        logger.info(
            f"Collected {len(sub_outputs)} sub-agent outputs as list",
            extra={"successful_agents": successful_count}
        )
        
        return result
    
    @staticmethod
    async def _summary_outputs(
        sub_outputs: List[SubAgentOutput],
        coordinator_context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate aggregated summary report from sub-agent outputs.
        
        Creates a high-level summary with statistics, highlights, and
        any error information.
        
        Args:
            sub_outputs: List of SubAgentOutput to summarize
            coordinator_context: Additional context
        
        Returns:
            Dict with summary report
        """
        # Collect statistics
        total_agents = len(sub_outputs)
        successful_agents = sum(1 for s in sub_outputs if s.status == "completed")
        failed_agents = total_agents - successful_agents
        total_execution_ms = sum(s.execution_time_ms for s in sub_outputs)
        
        # Collect errors
        errors = [
            {"agent": s.agent_name, "error": s.error}
            for s in sub_outputs
            if s.status != "completed" and s.error
        ]
        
        # Extract highlights from outputs
        highlights = []
        for sub_output in sub_outputs:
            if sub_output.output:
                highlights.append({
                    "agent": sub_output.agent_name,
                    "output_size": len(str(sub_output.output)),
                    "key_count": len(sub_output.output) if isinstance(sub_output.output, dict) else "N/A"
                })
        
        result = {
            "summary": {
                "total_agents": total_agents,
                "successful_agents": successful_agents,
                "failed_agents": failed_agents,
                "success_rate": successful_agents / total_agents if total_agents > 0 else 0,
                "total_execution_ms": total_execution_ms,
                "average_execution_ms": total_execution_ms / successful_agents if successful_agents > 0 else 0,
                "errors": errors if errors else None,
                "highlights": highlights
            },
            "_aggregation_metadata": {
                "strategy": AggregationStrategy.SUMMARY.value,
                "agent_count": total_agents,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "context": coordinator_context or {}
            }
        }
        
        logger.info(
            f"Generated summary for {total_agents} sub-agents",
            extra={
                "successful": successful_agents,
                "failed": failed_agents,
                "total_time_ms": total_execution_ms
            }
        )
        
        return result
