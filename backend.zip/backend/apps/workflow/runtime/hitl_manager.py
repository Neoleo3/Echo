"""
Human-In-The-Loop (HITL) Management for LangGraph Workflows.

Manages approval checkpoints in workflow execution using LangGraph's native
interrupt() mechanism, with three decision actions: approve, reject and edit.

``HITLManager`` here is live and is what the compiler's HITL node calls. Only
the node factory that used to live in this module was superseded, by
``WorkflowCompiler._create_hitl_node``; it was removed in Phase 10.

Phases:
- Phase C: Separates HITL logic from agent execution
- Future: Extend with feedback loops and audit trails
"""

import logging
from enum import Enum
from dataclasses import dataclass
from typing import Dict, Any, Optional, Callable
from datetime import datetime, timezone
import uuid
import asyncio

logger = logging.getLogger(__name__)


class HITLAction(str, Enum):
    """Human decision actions for HITL checkpoints."""
    
    APPROVE = "approve"  # Continue with agent output as-is
    REJECT = "reject"    # Reject agent output and terminate workflow
    EDIT = "edit"        # Provide feedback for re-execution
    DEFER = "defer"      # historical only -- deferral was removed as a decision


@dataclass
class HITLDecision:
    """Represents a human decision at an HITL checkpoint."""
    
    action: HITLAction
    feedback: Optional[str] = None        # Feedback message (for edit/reject)
    edited_output: Optional[Dict[str, Any]] = None  # Edited output (for edit)
    timestamp: Optional[datetime] = None  # When decision was made
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc)


class HITLManager:
    """
    Manages human-in-the-loop checkpoints in LangGraph workflows.
    
    Features:
    - Pause execution at designated HITL nodes
    - Collect human decisions (approve/reject/edit)
    - Re-execute nodes with feedback
    - Maintain execution history
    
    Integration with LangGraph:
    - Uses interrupt() to pause execution
    - Uses Command(resume=...) to resume with decision
    - Integrates with execution persistence
    """
    
    def __init__(self, execution_repo=None, ws_manager=None):
        """
        Initialize HITL Manager.
        
        Args:
            execution_repo: ExecutionRunRepository for persistence
            ws_manager: WebSocket manager for real-time notifications
        """
        self.execution_repo = execution_repo
        self.ws_manager = ws_manager
        self._hitl_decisions: Dict[str, HITLDecision] = {}
    
    def should_require_approval(
        self,
        state: Dict[str, Any],
        node_config: Dict[str, Any]
    ) -> bool:
        """
        Determine if a node requires human approval.
        
        Args:
            state: Current workflow state
            node_config: Node configuration from workflow
        
        Returns:
            True if node requires HITL approval, False otherwise
        """
        # Check if node is marked as HITL in config
        if node_config.get("type") == "HITL":
            return True
        
        # Check if approval is required in node settings
        node_settings = node_config.get("settings", {})
        if node_settings.get("require_approval"):
            return True
        
        # Check if approval is required based on output conditions
        execution_config = node_config.get("execution_config", {})
        if execution_config.get("approval_required"):
            return True
        
        return False
    
    async def publish_approval_request(
        self,
        run_id: str,
        step_id: str,
        node_name: str,
        agent_output: Dict[str, Any],
        node_config: Dict[str, Any]
    ) -> None:
        """
        Publish an approval request with multi-tier delivery strategy.
        
        Implements resilient 3-tier delivery model:
        1. Try WebSocket (5s timeout) - Real-time notification preferred
        2. Fallback to database persistence - Ensures audit trail
        3. Alert on complete failure - Log for manual intervention
        
        This ensures no approval request is lost, even if frontend disconnects.
        
        Args:
            run_id: Execution run ID
            step_id: Step ID for this approval
            node_name: Name of the node requiring approval
            agent_output: Output from agent awaiting approval
            node_config: Node configuration
        
        Raises:
            RuntimeError: If both WebSocket and database persistence fail
        """
        request_id = str(uuid.uuid4())
        approval_request = {
            "request_id": request_id,
            "run_id": run_id,
            "step_id": step_id,
            "node_name": node_name,
            "agent_output": agent_output,
            "possible_actions": [a.value for a in HITLAction],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        ws_success = False
        db_success = False
        
        # Tier 1: Try WebSocket (with timeout for resilience)
        if self.ws_manager:
            try:
                logger.info(
                    f"Publishing HITL approval request via WebSocket",
                    extra={
                        "run_id": run_id,
                        "step_id": step_id,
                        "request_id": request_id,
                        "delivery_tier": "websocket"
                    }
                )
                
                # Timeout ensures we don't wait forever if frontend is unreachable
                await asyncio.wait_for(
                    self.ws_manager.broadcast_event(
                        event_type="hitl_required",
                        run_id=run_id,
                        data=approval_request
                    ),
                    timeout=5.0  # 5 second timeout for WebSocket publish
                )
                
                ws_success = True
                logger.info(
                    f"HITL approval request published successfully via WebSocket",
                    extra={"run_id": run_id, "request_id": request_id}
                )
            
            except asyncio.TimeoutError:
                logger.warning(
                    f"WebSocket publish timed out (5s) for HITL request",
                    extra={"run_id": run_id, "request_id": request_id}
                )
            except Exception as e:
                logger.warning(
                    f"Failed to publish HITL request via WebSocket: {e}",
                    extra={
                        "run_id": run_id,
                        "request_id": request_id,
                        "error_type": type(e).__name__
                    }
                )
        
        # Tier 2: Fallback to database persistence (always attempted if repo available)
        if not ws_success and self.execution_repo:
            try:
                logger.info(
                    f"Falling back to database persistence for HITL request",
                    extra={
                        "run_id": run_id,
                        "step_id": step_id,
                        "request_id": request_id,
                        "delivery_tier": "database"
                    }
                )
                
                # Convert to dict format for database storage
                decision_dict = {
                    "request_id": request_id,
                    "node_name": node_name,
                    "agent_output": agent_output,
                    "possible_actions": approval_request["possible_actions"],
                    "timestamp": approval_request["timestamp"],
                    "status": "pending"  # Waiting for human decision
                }
                
                # Save HITL request to execution_steps for fallback retrieval
                # This enables database polling if WebSocket disconnects
                await self.execution_repo.save_hitl_decision(
                    db=None,  # Will be passed by caller in production
                    run_id=run_id,
                    step_id=step_id,
                    decision=decision_dict,
                    attempt=1
                )
                
                db_success = True
                logger.info(
                    f"HITL approval request persisted to database",
                    extra={"run_id": run_id, "request_id": request_id}
                )
            
            except Exception as e:
                logger.warning(
                    f"Failed to persist HITL request to database: {e}",
                    extra={
                        "run_id": run_id,
                        "request_id": request_id,
                        "error_type": type(e).__name__
                    }
                )
        
        # Tier 3: Alert if both delivery methods failed
        if not ws_success and not db_success:
            error_msg = (
                f"CRITICAL: HITL approval request {request_id} could not be delivered "
                f"via WebSocket or database for run {run_id}, step {step_id}. "
                f"Manual intervention required."
            )
            logger.critical(error_msg, extra={"run_id": run_id, "request_id": request_id})
            # Note: We don't raise here to avoid crashing the workflow.
            # The UI will eventually poll or retry.
    
    def process_decision(
        self,
        decision: HITLDecision,
        agent_output: Dict[str, Any],
        state: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Process a human decision and return updated state.
        
        Implements 4 action types:
        - APPROVE: Continue with agent output unchanged
        - REJECT: Raise RuntimeError to terminate workflow
        - EDIT: Inject feedback for re-execution
        - DEFER: Skip node output, continue to next
        
        Args:
            decision: HITLDecision with action and metadata
            agent_output: Output from agent awaiting decision
            state: Current workflow state
        
        Returns:
            Updated state based on decision action
        
        Raises:
            RuntimeError: If decision is REJECT
            ValueError: If decision action is unknown
        """
        action = decision.action
        
        logger.info(
            f"Processing HITL decision: action={action}, "
            f"timestamp={decision.timestamp}"
        )
        
        if action == HITLAction.APPROVE:
            # Continue with agent output unchanged
            logger.info("HITL Decision: APPROVE - continuing with agent output")
            return state
        
        elif action == HITLAction.REJECT:
            # Terminate workflow with error
            error_msg = (
                f"HITL Decision: REJECT - Workflow terminated by human. "
                f"Feedback: {decision.feedback or 'None'}"
            )
            logger.warning(error_msg)
            raise RuntimeError(error_msg)
        
        elif action == HITLAction.EDIT:
            # Re-execute with edited output or feedback
            logger.info(
                f"HITL Decision: EDIT - Re-executing with feedback: {decision.feedback}"
            )
            
            # If edited output provided, use it as new agent output
            if decision.edited_output:
                logger.info("HITL Decision: Using edited output from human")
                # Update state with edited output
                state.update(decision.edited_output)
            else:
                # Mark state for re-execution with feedback injected
                state["_hitl_feedback"] = decision.feedback
                state["_hitl_redo"] = True
                logger.info("HITL Decision: Marked for re-execution with feedback")
            
            return state
        
        elif action == HITLAction.DEFER:
            # Skip node output, continue to next without applying changes
            logger.info("HITL Decision: DEFER - Skipping node output, continuing to next")
            state["_hitl_deferred"] = True
            return state
        
        else:
            raise ValueError(f"Unknown HITL action: {action}")
    
    def store_decision(
        self,
        run_id: str,
        step_id: str,
        decision: HITLDecision
    ) -> None:
        """
        Store an HITL decision in memory and database.
        
        Args:
            run_id: Execution run ID
            step_id: Step ID where decision was made
            decision: HITLDecision object
        """
        decision_key = f"{run_id}:{step_id}"
        self._hitl_decisions[decision_key] = decision
        
        logger.info(
            f"Stored HITL decision for {decision_key}: action={decision.action}"
        )
    
    def get_decision(
        self,
        run_id: str,
        step_id: str
    ) -> Optional[HITLDecision]:
        """
        Retrieve a stored HITL decision.
        
        Args:
            run_id: Execution run ID
            step_id: Step ID to retrieve decision for
        
        Returns:
            HITLDecision if found, None otherwise
        """
        decision_key = f"{run_id}:{step_id}"
        return self._hitl_decisions.get(decision_key)


# ``create_hitl_router_node`` was removed in Phase 10. Phase 8.1 replaced it
# with ``WorkflowCompiler._create_hitl_node``, which is what every HITL node
# now dispatches to. The removed version interrupted with a bare string (so the
# reviewer UI had no payload), read ``state['agent_output']`` -- a key nothing
# writes -- and never set ``_hitl_route``, so the edit loop could not route. It
# was marked superseded, raised a warning when called, and had no caller.

