"""
Register workflow-generated files and turn their markers into download links.

Agent tools (docx/excel/ppt generators, data_analyst charts) write a file to disk
and embed a ``[GENERATED_FILE:<abs_path>:<filename>]`` marker in their output.
The appmgr/chat path registers those via skill_executor; the **workflow** path
previously did not, so workflow-run files never produced a downloadable link.

This module closes that gap. Files are registered *standalone* — no owning chat
session / application (those FKs are nullable as of migration 046) — and the
marker is replaced with a markdown download link served by the workflow download
route (``/api/workflows/generated-files/{download_key}``).

The marker payload is split with ``rsplit(":", 1)`` so Windows drive letters
(``D:\\...``) in the path do not break parsing.
"""

from __future__ import annotations

import logging
import os
import re

from echolib.generated_files import validate_generated_file_path

logger = logging.getLogger(__name__)

_GENERATED_FILE_MARKER_RE = re.compile(r"\[GENERATED_FILE:(?P<payload>[^\]]+)\]")

# Path component of the workflow download route (see apps/workflow/routes.py).
# The workflow router is mounted at "/workflows" (no extra /api at the gateway).
DOWNLOAD_BASE = "/workflows/generated-files"

_MIME_MAP = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".pdf": "application/pdf",
    ".csv": "text/csv",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
}


async def register_generated_files(text: str) -> str:
    """Scan ``text`` for [GENERATED_FILE:...] markers, register each file
    standalone, and replace the marker with a markdown download link.

    Returns the rewritten text. Never raises — on any failure the original text
    is returned unchanged (so execution output is never lost).
    """
    if not text or "[GENERATED_FILE:" not in text:
        return text

    from echolib.database import get_db_session
    from echolib.repositories.generated_file_repo import GeneratedFileRepository

    repo = GeneratedFileRepository()
    result_text = text
    try:
        async with get_db_session() as db:
            for match in _GENERATED_FILE_MARKER_RE.finditer(text):
                payload = match.group("payload")
                if ":" not in payload:
                    logger.warning("workflow: malformed generated-file marker: %s", payload)
                    continue
                # rsplit so a Windows path's drive-letter colon is preserved.
                file_path, filename = payload.rsplit(":", 1)
                is_valid_path, path_reason, normalized_path, _size_bytes = validate_generated_file_path(
                    file_path,
                    require_exists=True,
                    require_non_empty=True,
                )
                file_path = normalized_path
                filename = filename.strip()
                if not file_path or not filename:
                    continue
                if not is_valid_path:
                    logger.warning(
                        "workflow_generated_file_registration_rejected",
                        extra={
                            "reason": path_reason,
                            "filename": filename,
                            "file_path": file_path,
                            "cwd": os.getcwd(),
                            "app_uploads_dir": os.getenv("APP_UPLOADS_DIR"),
                        },
                    )
                    replacement = (
                        f"Your file **{filename}** was generated, but is not available for download."
                    )
                    result_text = result_text.replace(match.group(0), replacement, 1)
                    continue
                ext = os.path.splitext(filename)[1].lower()
                mime_type = _MIME_MAP.get(ext, "application/octet-stream")
                try:
                    record = await repo.register(
                        db,
                        chat_session_id=None,   # standalone workflow run
                        application_id=None,
                        original_filename=filename,
                        file_path=file_path,
                        mime_type=mime_type,
                    )
                    url = f"{DOWNLOAD_BASE}/{record.download_key}"
                    replacement = (
                        f"Your file **{filename}** is ready. "
                        f"[Click here to download]({url})"
                    )
                    logger.info(
                        "workflow: registered generated file '%s' (key=%s)",
                        filename, record.download_key,
                    )
                except Exception as exc:
                    logger.warning(
                        "workflow: failed to register generated file '%s': %s",
                        filename, exc,
                    )
                    replacement = f"Your file **{filename}** was generated."
                result_text = result_text.replace(match.group(0), replacement, 1)
            await db.commit()
    except Exception:
        logger.exception("workflow: generated-file registration failed")
        return text
    return result_text
