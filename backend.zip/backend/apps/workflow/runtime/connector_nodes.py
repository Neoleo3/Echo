"""
Managed-mode connector invocation for workflow API and MCP nodes.

WHAT: Turns an API or MCP canvas node's configuration into one authorized,
      user-scoped connector call, and normalizes the outcome into the result
      shape those nodes have always written to state.
WHY:  Before this module the nodes called ``ConnectorManager().get_manager(
      "api").invoke(connector_id, payload)``. That signature takes no
      ``user_id`` and resolves against a process-global registry, so a workflow
      could reach *any* user's connector by naming its id, and none of the
      phase 5b permission model applied: no ownership check, no access level,
      no allowed-operations list, no refusal message. An agent calling the same
      connector went through ``apps/connector/middleware``; a node calling it
      went around. Two paths to one connector with different auth semantics is
      exactly the defect phase 5a removed for tool synthesis.

Every managed call now takes the same path an agent's connector call takes:

    node config ──► attachment entry ──► refs.resolve_connector(entry, user_id)
                                          └─► invoker.invoke_connector(...)

Resolution is user-scoped at the service layer, so a connector belonging to
another user resolves to "not found for this user" and the node fails with a
named reason rather than silently executing or silently returning nothing.

**Ad-hoc mode is deliberately untouched.** An ad-hoc node carries its own URL
and auth inline; there is no stored connector to own it and therefore no
permission model to honour. That is documented rather than quietly ignored.

Access level for a workflow node
--------------------------------
An agent attachment defaults to ``read_only`` because a *model* chooses which
tool to call, and least privilege is the only defence against that choice going
wrong. A canvas node is the opposite: the operation is fixed at design time by
the workflow author, who owns the connector. Ownership is the security boundary
there, not the level.

So a node whose config states ``access_level`` or ``allowed_operations`` is held
to exactly that; a node that states neither is expanded against the connector's
*current* capabilities. That is still a real check -- for MCP the permitted set
is the server's currently advertised tools, so a canvas that names a tool the
server no longer exposes is refused with a message naming it, instead of failing
somewhere inside the transport.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Mapping, Optional

from echolib.connector_permissions import LEVEL_FULL_ACCESS

logger = logging.getLogger(__name__)

# Matches the resolver's own bound; a borrowed-credential call resolves the
# connector and then performs one HTTP request.
RESOLUTION_TIMEOUT_SECONDS = 60

# See the module docstring: a canvas node's operation is chosen by a person at
# design time, not by a model at run time.
WORKFLOW_NODE_ACCESS_LEVEL = LEVEL_FULL_ACCESS

# Config keys that carry a managed connector reference. ``connectorId`` is the
# camelCase form the canvas emits.
_CONNECTOR_ID_KEYS = ("connector_id", "connectorId")


def connector_id_of(config: Mapping[str, Any]) -> str:
    """Return the managed connector id in a node config, or an empty string."""
    for key in _CONNECTOR_ID_KEYS:
        value = config.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def is_managed(config: Mapping[str, Any]) -> bool:
    """True when this node references a stored connector rather than inline config."""
    return bool(connector_id_of(config))


def _attachment_entry(config: Mapping[str, Any], kind: str) -> Dict[str, Any]:
    """
    Build the connector attachment entry ``resolve_connector`` expects.

    Deliberately the same shape an agent's ``definition.connectors[]`` entry
    has, so node and agent resolution cannot drift apart.
    """
    connector_id = connector_id_of(config)
    allowed = [
        str(op).strip()
        for op in (config.get("allowed_operations") or config.get("allowedOperations") or [])
        if str(op).strip()
    ]
    return {
        "connector_id": connector_id,
        "kind": kind,
        "alias": str(
            config.get("alias")
            or config.get("name")
            or config.get("serverName")
            or connector_id
        ),
        "allowed_operations": allowed,
        "access_level": (
            config.get("access_level")
            or config.get("accessLevel")
            or WORKFLOW_NODE_ACCESS_LEVEL
        ),
    }


def as_dict(value: Any) -> Optional[Dict[str, Any]]:
    """
    Coerce a config value to a dict, parsing a JSON object string if needed.

    Public because the ad-hoc path needs it too. The canvas renders headers,
    query parameters and bodies as JSON **textareas**, so every one of them
    arrives as a string. The managed path has always parsed them here; the
    ad-hoc path passed them straight into ``ConnectorConfig(default_headers=…)``
    and ``connector.execute(body=…)``, where a string is not what either expects.
    """
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return None
        if isinstance(parsed, dict):
            return parsed
    return None


# Retained for the existing internal call sites below.
_as_dict = as_dict


def auth_connector_id_of(config: Mapping[str, Any]) -> str:
    """
    The stored connector whose credentials an ad-hoc node borrows, if any.

    Reference only: the workflow definition holds an id, never a secret. See
    ``APIConnectorService.invoke_borrowed_auth`` for the same-origin rule that
    stops the reference becoming a way to send someone else's key anywhere.
    """
    for key in ("auth_connector_id", "authConnectorId"):
        value = config.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def invoke_adhoc_api_with_borrowed_auth(
    config: Mapping[str, Any],
    *,
    user_id: Optional[str],
    node_id: str,
) -> Dict[str, Any]:
    """
    Run an ad-hoc API call authenticated by a referenced stored connector.

    INPUT: The node's interpolated config, the acting user, and the node id.
    OUTPUT: The same ``{success, status_code, data, headers, error}`` shape the
            API node already writes to state.

    The node owns the URL, method, headers, query parameters and body. The
    referenced connector owns the credentials, and they are only ever sent to
    the host that connector was registered for.
    """
    from apps.connector.middleware import refs
    from apps.tool.async_bridge import run_async

    credential_connector_id = auth_connector_id_of(config)

    # Ownership first, through the same resolver a managed call uses: a
    # connector belonging to someone else is "not found for this user", so a
    # pasted id from another tenant refuses here rather than at the transport.
    entry = _attachment_entry(
        {"connector_id": credential_connector_id}, refs.KIND_API
    )
    connector = refs.resolve_connector(entry, str(user_id or ""))
    if not connector.resolved:
        return _refusal(
            node_id,
            "API",
            credential_connector_id,
            connector.error or "credential connector could not be resolved",
        )

    from echolib.connectors.api_service import APIConnectorService

    result = run_async(
        APIConnectorService().invoke_borrowed_auth(
            credential_connector_id,
            user_id=str(user_id or ""),
            url=str(config.get("url") or config.get("base_url") or ""),
            method=str(config.get("method") or "GET"),
            headers=as_dict(config.get("headers")),
            query_params=as_dict(
                config.get("query_params") or config.get("queryParams")
            ),
            body=as_dict(config.get("body")),
        ),
        timeout=RESOLUTION_TIMEOUT_SECONDS,
    )

    payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)

    if not payload.get("success"):
        logger.warning(
            "API node '%s' failed borrowing credentials from '%s': %s",
            node_id, credential_connector_id, payload.get("error"),
        )

    return {
        "success": bool(payload.get("success")),
        "status_code": payload.get("status_code"),
        "data": payload.get("data") if payload.get("success") else None,
        "headers": {},
        "error": payload.get("error"),
        "error_type": payload.get("error_type"),
        "connector_name": connector.name,
    }


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def invoke_api_connector(
    config: Mapping[str, Any],
    *,
    user_id: Optional[str],
    node_id: str,
) -> Dict[str, Any]:
    """
    Invoke a managed API connector for an API node.

    INPUT: The node's interpolated config, the acting user, and the node id.
    OUTPUT: The dict shape the API node already stores in state --
            ``{success, status_code, data, headers, error}`` -- so the node's
            downstream handling is unchanged.

    The stored connector owns its endpoint, method, auth and default headers.
    The node supplies only ``query_params`` and ``body``: it cannot redirect the
    call or replace its credentials, which is the property that makes a managed
    connector safe to reference from a canvas.
    """
    from apps.connector.middleware import refs
    from apps.connector.middleware.invoker import OP_API_INVOKE, invoke_connector

    entry = _attachment_entry(config, refs.KIND_API)
    connector = refs.resolve_connector(entry, str(user_id or ""))

    if not connector.resolved:
        return _refusal(
            node_id,
            "API",
            entry["connector_id"],
            connector.error or "connector could not be resolved",
        )

    # ``payload`` is the legacy single-field form the node used to hand to
    # ConnectorManager.invoke(). Treated as the request body so existing
    # canvases keep working.
    body = (
        _as_dict(config.get("body"))
        or _as_dict(config.get("payload"))
        or None
    )
    params: Dict[str, Any] = {
        "query_params": _as_dict(config.get("query_params") or config.get("queryParams")),
        "body": body,
    }

    result = invoke_connector(connector, OP_API_INVOKE, params, user_id=str(user_id or ""))

    if not result.success:
        logger.warning(
            "API node '%s' refused or failed on connector '%s': %s",
            node_id, connector.connector_id, result.error,
        )
        return {
            "success": False,
            "status_code": result.metadata.get("status_code"),
            "data": None,
            "headers": {},
            "error": result.error,
            "error_type": result.error_type,
            "connector_name": connector.name,
        }

    return {
        "success": True,
        "status_code": result.metadata.get("status_code"),
        "data": result.data,
        "headers": {},
        "error": None,
        "connector_name": connector.name,
    }


# ---------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------

def invoke_mcp_connector(
    config: Mapping[str, Any],
    *,
    user_id: Optional[str],
    node_id: str,
) -> Dict[str, Any]:
    """
    Invoke a managed MCP connector for an MCP node.

    INPUT: The node's interpolated config, the acting user, and the node id.
    OUTPUT: ``{success, output, tool_name, error}`` -- the shape the MCP node
            already reads, so its state mapping is unchanged.

    Two operations are reachable, matching what the connector itself exposes:
    ``call_tool`` (the default) and ``read_resource`` when the node names a
    resource URI. The tool name is authorized by name, not merely by operation:
    ``call_tool`` alone says nothing about *which* tool.
    """
    from apps.connector.middleware import refs
    from apps.connector.middleware.invoker import (
        OP_MCP_CALL_TOOL,
        OP_MCP_READ_RESOURCE,
        invoke_connector,
    )

    entry = _attachment_entry(config, refs.KIND_MCP)
    connector = refs.resolve_connector(entry, str(user_id or ""))

    if not connector.resolved:
        return _refusal(
            node_id,
            "MCP",
            entry["connector_id"],
            connector.error or "connector could not be resolved",
            output_key="output",
        )

    resource_uri = str(
        config.get("resource_uri") or config.get("resourceUri") or ""
    ).strip()

    if resource_uri:
        operation = OP_MCP_READ_RESOURCE
        params: Dict[str, Any] = {"resource_uri": resource_uri}
        described = f"resource '{resource_uri}'"
    else:
        tool_name = str(
            config.get("tool_name") or config.get("toolName") or ""
        ).strip()
        arguments = (
            _as_dict(config.get("arguments"))
            or _as_dict(config.get("payload"))
            or {}
        )
        operation = OP_MCP_CALL_TOOL
        params = {"tool_name": tool_name, "arguments": arguments}
        described = f"tool '{tool_name}'"

    result = invoke_connector(connector, operation, params, user_id=str(user_id or ""))

    if not result.success:
        logger.warning(
            "MCP node '%s' refused or failed calling %s on connector '%s': %s",
            node_id, described, connector.connector_id, result.error,
        )
        return {
            "success": False,
            "output": None,
            "tool_name": params.get("tool_name", ""),
            "error": result.error,
            "error_type": result.error_type,
            "connector_name": connector.name,
        }

    return {
        "success": True,
        "output": result.data,
        "tool_name": params.get("tool_name", ""),
        "error": None,
        "connector_name": connector.name,
    }


# ---------------------------------------------------------------------------
# Refusals
# ---------------------------------------------------------------------------

def _refusal(
    node_id: str,
    kind: str,
    connector_id: str,
    reason: str,
    *,
    output_key: str = "data",
) -> Dict[str, Any]:
    """
    Build the result for a call that never left the process.

    A refusal is a value, not an exception: the node records it, the run
    continues, and the reason names the connector. Never a silent empty result
    -- a workflow that used to reach another user's connector must stop with an
    explanation, not appear to succeed with nothing.
    """
    message = (
        f"{kind} connector '{connector_id}' is not available to this workflow: {reason}"
    )
    logger.warning("%s node '%s' refused: %s", kind, node_id, message)
    return {
        "success": False,
        output_key: None,
        "status_code": None,
        "error": message,
        "error_type": "unavailable",
    }


__all__ = [
    "WORKFLOW_NODE_ACCESS_LEVEL",
    "as_dict",
    "auth_connector_id_of",
    "connector_id_of",
    "invoke_adhoc_api_with_borrowed_auth",
    "invoke_api_connector",
    "invoke_mcp_connector",
    "is_managed",
]
