"""
Resolving a workflow's agents to their live records.

WHAT: Turns the entries in ``workflows.definition["agents"]`` into the agent
      definitions a run actually executes, by reading the ``agents`` table.
WHY:  Until Phase 8 the executor read the *embedded copy* stored inside the
      workflow, and consulted the ``agents`` table only when the entry was a
      bare string -- which the canvas never emits
      (``executor._load_agent_defs:933-946``). The write path was already
      aligned: ``workflow_repo.save_with_agents`` upserts every embedded agent
      through the Phase 1 boundary. So the agent was one entity on write and
      two on read, and editing an agent on the standalone page never reached a
      workflow that had embedded it. That is Finding 8.

**Latest-wins** (locked in ``Plan_1.md`` §1): a workflow resolves the *current*
definition of every agent it references. Editing an agent once changes it
everywhere -- every workflow that uses it, and standalone chat -- because there
is only one record. This is the model n8n uses: workflow JSON holds references,
credentials and their equivalents are separate entities updated in one place.

The embedded copy is retained as a **fallback only**, for the case where the
referenced agent no longer exists. That keeps a workflow whose agent was
deleted running on its last known configuration instead of failing outright,
and logs loudly so the divergence is visible rather than silent.

Nothing here writes. Resolution is read-only; the write path is unchanged.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Mapping, Optional

logger = logging.getLogger(__name__)

RESOLUTION_TIMEOUT_SECONDS = 30

# How each agent in a run was resolved, recorded per run so a behaviour change
# is attributable rather than mysterious.
SOURCE_RECORD = "agent_record"
SOURCE_EMBEDDED = "embedded_fallback"
SOURCE_REGISTRY = "filesystem_registry"


# ---------------------------------------------------------------------------
# Extension point -- documented, not built
# ---------------------------------------------------------------------------
#
# ``resolver_hook`` is where a future *dynamic* resolver would go: a runtime
# expression choosing which credential or model an agent uses based on
# execution context -- per tenant, per environment, per caller. n8n solves
# "different behaviour per workflow" that way, by resolving *which* credential
# id to use at run time, and never by letting a node's saved definition fork
# away from the canonical entity.
#
# It is deliberately not implemented. Phase 8's decision (§13 item 4, option a)
# is that there is no stored per-workflow override. If per-context behaviour is
# ever genuinely needed, it arrives here -- as a resolution rule evaluated at
# run time -- without reopening that decision or reintroducing a second source
# of truth for ``credential_id``.
#
# Signature a future implementation would satisfy:
#
#     def resolver_hook(
#         definition: Dict[str, Any],      # the resolved agent record
#         *,
#         entry: Mapping[str, Any],        # its workflow entry (wiring metadata)
#         context: Mapping[str, Any],      # run context: user, tenant, env
#     ) -> Dict[str, Any]:                 # the definition to execute
#
# It must return a definition, never mutate its input, and never persist.
# ---------------------------------------------------------------------------

ResolverHook = Callable[..., Dict[str, Any]]


def entry_agent_id(entry: Any) -> str:
    """Read the agent id out of a workflow entry, whatever shape it takes."""
    if isinstance(entry, str):
        return entry.strip()
    if isinstance(entry, Mapping):
        for key in ("agent_id", "id"):
            value = entry.get(key)
            if value:
                return str(value).strip()
    return ""


async def _fetch_records(agent_ids: List[str]) -> Dict[str, Any]:
    """
    Read the current definition of every referenced agent.

    One batched query rather than one per agent: a six-agent workflow would
    otherwise open six round trips on the run's critical path.

    Ids are normalized before the lookup and the result is keyed back by the
    id the workflow used. The canvas writes ``agt_<hex>`` while the column is a
    UUID, so a raw match would find nothing and every agent would silently fall
    back to its embedded copy -- exactly the staleness this phase removes.

    **Deliberately not scoped to the acting user.** The boundary was already
    cleared before this runs: an application chat passes
    ``get_accessible_application`` (owner, or published with a matching
    designation *and* business unit), and the designer loads the workflow
    through the user-scoped ``storage_gateway.load_workflow``. Re-checking row
    ownership here asked a second, different question -- "did *you* create these
    agents?" -- which no user of a published application can answer yes to, so
    every agent resolved to nothing and every node compiled empty. The agent
    path reached the same conclusion first; see
    ``agent.standalone._load_definition``.

    ``user_id`` still governs what it should: which LLM credential the agent
    runs on, and which connectors and documents it can reach. Those flow through
    ``_stamp_runtime_user_id``, not through this lookup.
    """
    from echolib.database import get_db_session
    from echolib.id_utils import normalize_to_uuid
    from echolib.repositories.agent_repo import AgentRepository

    canonical: Dict[str, str] = {}
    for agent_id in agent_ids:
        try:
            canonical[normalize_to_uuid(agent_id)] = agent_id
        except (ValueError, TypeError):
            logger.debug("Agent id '%s' is not resolvable to a UUID", agent_id)

    if not canonical:
        return {}

    async with get_db_session() as db:
        definitions = await AgentRepository().get_definitions(
            db, list(canonical.keys())
        )

    found: Dict[str, Any] = {}
    for definition in definitions or []:
        try:
            resolved_uuid = normalize_to_uuid(str(definition.get("agent_id") or ""))
        except (ValueError, TypeError):
            continue
        original = canonical.get(resolved_uuid)
        if original:
            found[original] = definition

    return found


def resolve_workflow_agents(
    workflow: Optional[Mapping[str, Any]],
    user_id: Optional[str],
    *,
    agent_registry: Any = None,
    resolver_hook: Optional[ResolverHook] = None,
) -> Dict[str, Dict[str, Any]]:
    """
    Resolve every agent a workflow references to its current definition.

    WHAT: For each entry, read the live record from the ``agents`` table; fall
          back to the embedded copy only when the agent no longer exists.
    WHY:  Latest-wins. A workflow must run the agent as it is now, not as it
          was when the canvas was last saved.
    INPUT: The workflow definition and the acting user. The user does **not**
           scope the lookup -- see ``_fetch_records`` for why that boundary
           belongs to the caller -- it selects the LLM credential and the
           reachable sources the resolved agent runs with. ``agent_registry`` is
           the filesystem registry, used only for bare-string entries on
           instances that still have filesystem-only agents.
    OUTPUT: ``{agent_id: definition}``. Each definition carries
            ``_resolution_source`` so the run record can state where it came
            from. Never raises -- a resolution failure degrades to the embedded
            copy rather than failing the run.

    Args:
        workflow: Workflow definition containing an ``agents`` list.
        user_id: The acting user. Stamped onto each resolved agent for
            credential and source resolution; it does not gate the read.
        agent_registry: Optional filesystem registry for bare-string entries.
        resolver_hook: Reserved. See the extension point above.
    """
    entries = list((workflow or {}).get("agents") or [])
    if not entries:
        return {}

    embedded: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []

    for entry in entries:
        agent_id = entry_agent_id(entry)
        if not agent_id:
            continue
        if agent_id not in embedded:
            order.append(agent_id)
        embedded[agent_id] = dict(entry) if isinstance(entry, Mapping) else {}

    if not order:
        return {}

    # Runs whether or not a user was supplied. It used to be skipped when
    # ``user_id`` was falsy, which left ``records`` empty with nothing logged --
    # indistinguishable from "every agent has been deleted", and the reason a
    # run with no user silently executed a workflow of empty agents.
    records: Dict[str, Any] = {}
    try:
        from apps.tool.async_bridge import run_async

        records = run_async(
            _fetch_records(order),
            timeout=RESOLUTION_TIMEOUT_SECONDS,
        )
    except Exception:
        logger.error(
            "Agent resolution failed for this run; every agent falls back to "
            "the copy embedded in the workflow. Edits made on the agent page "
            "will not be reflected.",
            exc_info=True,
        )
        records = {}

    resolved: Dict[str, Dict[str, Any]] = {}
    fell_back: List[str] = []
    unresolved: List[str] = []

    for agent_id in order:
        definition = records.get(agent_id)
        source = SOURCE_RECORD

        if not definition:
            definition, source = _fallback(agent_id, embedded[agent_id], agent_registry)
            if definition is None:
                unresolved.append(agent_id)
                logger.error(
                    "Agent '%s' is referenced by this workflow but no row exists "
                    "for it in the agents table, and since Phase 8 the workflow "
                    "stores a reference rather than a copy -- so there is nothing "
                    "to run. The agent was deleted, or the reference was written "
                    "against an id the agent was never stored under; "
                    "scripts/audit_workflow_agent_references.py reports which. "
                    "Compilation will fail on this node rather than run it empty.",
                    agent_id,
                )
                continue
            fell_back.append(agent_id)

        merged = _merge_wiring(definition, embedded[agent_id])
        merged["_resolution_source"] = source

        if resolver_hook is not None:
            try:
                merged = resolver_hook(merged, entry=embedded[agent_id], context={"user_id": user_id})
            except Exception:
                logger.warning(
                    "Agent resolver hook failed for '%s'; using the resolved record",
                    agent_id, exc_info=True,
                )

        resolved[agent_id] = merged

    if fell_back:
        logger.warning(
            "%d of %d workflow agents could not be resolved from the agents table "
            "and fell back to their embedded copy: %s. They will not reflect edits "
            "made on the agent page.",
            len(fell_back), len(order), ", ".join(fell_back),
        )

    logger.info(
        "Resolved %d of %d workflow agent(s): %d from the agent record, "
        "%d from an embedded copy, %d unresolved",
        len(resolved), len(order),
        len(resolved) - len(fell_back), len(fell_back), len(unresolved),
    )
    return resolved


def _fallback(
    agent_id: str, entry: Dict[str, Any], agent_registry: Any
) -> tuple:
    """
    Find something to run when the agent record is gone.

    The filesystem registry is tried first for entries that were bare strings
    to begin with -- those never had an embedded copy. Otherwise the embedded
    copy is the last known configuration and is better than failing the run.
    """
    if agent_registry is not None and not _has_definition(entry):
        try:
            found = agent_registry.get_agent(agent_id)
            if found is None:
                agent_registry._load_all()
                found = agent_registry.get_agent(agent_id)
            if found:
                return dict(found), SOURCE_REGISTRY
        except Exception:
            logger.debug("Filesystem registry lookup failed for '%s'", agent_id, exc_info=True)

    if _has_definition(entry):
        return dict(entry), SOURCE_EMBEDDED

    return None, SOURCE_EMBEDDED


def _has_definition(entry: Mapping[str, Any]) -> bool:
    """
    True when an entry carries agent *state*, not just a reference.

    After Phase 8 the workflow stores references plus wiring metadata, so a
    freshly-saved entry has none of these keys and there is nothing to fall
    back to. Entries written before Phase 8 still do.
    """
    return any(
        entry.get(key)
        for key in ("instructions", "prompt", "model", "model_config", "settings", "tools")
    )


# Keys the workflow owns. They describe the agent's place in the graph rather
# than the agent itself, so they survive resolution and override the record.
WIRING_KEYS = (
    "type",
    "position",
    "input_schema",
    "output_schema",
    "config",
    "connections",
    "depends_on",
    "node_id",
)

# The same, but nested inside ``metadata``.
#
# ``position`` above is aspirational -- the canvas has never written it. It
# writes ``metadata.ui_layout``, alongside ``metadata.node_type``. Both are
# per-workflow: one agent can sit at different coordinates in two workflows,
# so the entry's copy must win over the record's.
WIRING_METADATA_KEYS = ("node_type", "ui_layout")


def _merge_wiring(definition: Mapping[str, Any], entry: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Layer the workflow's wiring metadata over the resolved agent definition.

    The agent record owns what the agent *is* -- instructions, model, tools,
    connectors, attached documents. The workflow owns where it sits in the
    graph and what it is wired to. Only the latter is taken from the entry,
    which is exactly what stops a stale embedded copy overriding a live edit.
    """
    merged = dict(definition)

    for key in WIRING_KEYS:
        value = entry.get(key)
        if value not in (None, "", [], {}):
            merged[key] = value

    # Layer the entry's canvas placement over the record's, without discarding
    # the agent-owned rest of `metadata` (the config-chat transcript lives
    # there). Both dicts are copied rather than mutated: `definition` may be a
    # shared record and `entry` belongs to the caller's workflow.
    entry_metadata = entry.get("metadata")
    if isinstance(entry_metadata, dict):
        placement = {
            key: entry_metadata[key]
            for key in WIRING_METADATA_KEYS
            if entry_metadata.get(key)
        }
        if placement:
            base = merged.get("metadata")
            merged["metadata"] = {
                **(base if isinstance(base, dict) else {}),
                **placement,
            }

    # Node-level identity the canvas assigns. Falling back to the agent's own
    # name keeps a node labelled when the workflow entry carries none.
    if entry.get("name"):
        merged.setdefault("_node_label", entry["name"])

    return merged


def describe_resolution(agent_defs: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    """
    Summarize how each agent was resolved, for ``execution_runs.execution_metadata``.

    Latest-wins means a workflow that ran correctly yesterday can behave
    differently today with no workflow edit, so every run records which
    ``config_version`` of each agent it actually executed. Without this the
    change is real but unattributable.
    """
    return {
        agent_id: {
            "source": definition.get("_resolution_source", SOURCE_RECORD),
            "config_version": definition.get("config_version"),
            "name": definition.get("name"),
        }
        for agent_id, definition in (agent_defs or {}).items()
    }


__all__ = [
    "SOURCE_EMBEDDED",
    "SOURCE_RECORD",
    "SOURCE_REGISTRY",
    "WIRING_KEYS",
    "ResolverHook",
    "describe_resolution",
    "entry_agent_id",
    "resolve_workflow_agents",
]
