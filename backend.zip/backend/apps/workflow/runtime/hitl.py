"""
Human-in-the-Loop (HITL) Runtime Support

HITL is a first-class execution boundary with:
- Pause (deterministic checkpoint)
- Context (full decision info)
- Controlled action (approve/reject/modify)
- Re-validation (after changes)
- Audit (immutable trail)

This is NOT a UI feature - it's a workflow state enforced by runtime.

Architecture:
1. Design-time: Workflow declares HITL points
2. Compile-time: Validator enforces HITL rules
3. Run-time: Orchestrator manages HITL state
"""
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import json
import logging
from pathlib import Path

from echolib.utils import new_id

logger = logging.getLogger(__name__)


# ============================================================================
# HITL STATE MACHINE
# ============================================================================

class HITLState(str, Enum):
    """
    HITL execution states

    State transitions:
    RUNNING → WAITING_FOR_HUMAN → APPROVED/REJECTED/MODIFIED → RESUMED/TERMINATED

    ``DEFERRED`` is retained for **read-back only**. Deferral was removed as a
    decision (a checkpoint offers approve, reject and edit), but checkpoints
    persisted before that are loaded with ``HITLState(data["state"])``, which
    raises ``ValueError`` on a value the enum no longer knows. Nothing produces
    this state any more.
    """
    RUNNING = "running"
    WAITING_FOR_HUMAN = "waiting_for_human"
    APPROVED = "approved"
    REJECTED = "rejected"
    MODIFIED = "modified"
    DEFERRED = "deferred"
    RESUMED = "resumed"
    TERMINATED = "terminated"
    WAITING_FOR_FILE = "waiting_for_file"


class HITLAction(str, Enum):
    """
    Allowed human actions during HITL.

    A checkpoint offers three decisions: approve, reject and edit (``MODIFY``).

    ``DEFER`` is retained for **read-back only** -- decisions recorded before
    deferral was removed still carry it, and the DB's ``resolution`` check
    constraint still permits it. Nothing produces it any more.
    """
    APPROVE = "approve"
    REJECT = "reject"
    MODIFY = "modify"
    DEFER = "defer"  # historical only; see the class docstring
    RERUN = "rerun"
    UPLOAD_FILE = "upload_file"
    SKIP = "skip"


# The states a reviewer's decision puts a run into. A run sitting in one of
# these has been decided; what happens next is the graph consuming it.
DECIDED_STATES = frozenset({
    HITLState.APPROVED,
    HITLState.REJECTED,
    HITLState.MODIFIED,
    HITLState.DEFERRED,
})

# Which state each decision lands the run in. Used by ``consume_decision`` so
# the node and the route cannot disagree about what a decision means.
ACTION_STATES = {
    HITLAction.APPROVE: HITLState.APPROVED,
    HITLAction.REJECT: HITLState.REJECTED,
    HITLAction.MODIFY: HITLState.MODIFIED,
    HITLAction.DEFER: HITLState.DEFERRED,
}


# Strong references to in-flight background writes.
#
# ``asyncio.create_task`` returns the only strong reference the caller will
# ever get -- the loop itself keeps a weak one -- so a task nobody holds can be
# garbage-collected mid-await. Dropping the reference also means nothing ever
# retrieves the result, which is why the logs carry
#
#     ERROR [asyncio] Task exception was never retrieved
#     future: <Task finished coro=<_persist_decision_to_db.<locals>._persist()>
#             exception=DBAPIError(...)>
#
# for a write that failed silently as far as the request was concerned. Holding
# the task and attaching a callback makes both problems go away.
_BACKGROUND_TASKS: set = set()


def track_task(task: "asyncio.Task", description: str) -> "asyncio.Task":
    """Keep a background task alive and make sure its failure is reported."""
    _BACKGROUND_TASKS.add(task)

    def _done(finished: "asyncio.Task") -> None:
        _BACKGROUND_TASKS.discard(finished)
        if finished.cancelled():
            logger.warning("%s was cancelled before it completed", description)
            return
        error = finished.exception()
        if error is not None:
            logger.error("%s failed: %s", description, error, exc_info=error)

    task.add_done_callback(_done)
    return task


class HITLStateError(ValueError):
    """
    A decision was made against a run that is not waiting for one.

    Subclasses ``ValueError`` because ``/hitl/decide`` has always mapped that to
    a response, and every existing caller still behaves identically. What it
    adds is the ability to *tell the three cases apart*, which is the reason
    this defect survived three attempts to fix it: "this run was already
    approved", "this run finished" and "no worker has ever heard of this run"
    all arrived at the reviewer as one indistinguishable ``400 Bad Request``.

    ``known`` is False only when nothing -- memory, the storage directory, the
    ``hitl_states`` row, or the LangGraph checkpointer -- has any record of the
    run. That is a 404. A run that is known but already decided is a 409.
    """

    def __init__(
        self,
        run_id: str,
        expected: "HITLState",
        actual: "Optional[HITLState]",
    ) -> None:
        self.run_id = run_id
        self.expected = expected
        self.actual = actual
        self.known = actual is not None
        self.decided = actual in DECIDED_STATES if actual is not None else False

        if actual is None:
            message = (
                f"No checkpoint is recorded for run '{run_id}'. It was never "
                "paused for review, or its record has been removed."
            )
        elif self.decided:
            message = (
                f"This checkpoint was already {actual.value} and cannot be "
                "decided again."
            )
        else:
            message = (
                f"Run '{run_id}' is not waiting for a decision "
                f"(it is {actual.value})."
            )
        super().__init__(message)


# ============================================================================
# HITL DATA MODELS
# ============================================================================

@dataclass
class HITLContext:
    """
    Full decision context presented to human

    Attributes:
        workflow_id: Workflow being executed
        run_id: Execution run ID
        blocked_at: Where execution is paused (agent ID or step)
        agent_output: Output from the agent that triggered HITL
        tools_used: List of tools invoked
        execution_metrics: Cost, duration, tokens
        state_snapshot: Current workflow state
        previous_decisions: History of HITL decisions in this run
    """
    workflow_id: str
    run_id: str
    blocked_at: str
    agent_output: Optional[Dict[str, Any]] = None
    tools_used: List[str] = field(default_factory=list)
    execution_metrics: Dict[str, Any] = field(default_factory=dict)
    state_snapshot: Dict[str, Any] = field(default_factory=dict)
    previous_decisions: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "workflow_id": self.workflow_id,
            "run_id": self.run_id,
            "blocked_at": self.blocked_at,
            "agent_output": self.agent_output,
            "tools_used": self.tools_used,
            "execution_metrics": self.execution_metrics,
            "state_snapshot": self.state_snapshot,
            "previous_decisions": self.previous_decisions
        }


@dataclass
class HITLDecision:
    """
    Human decision record (audit trail)

    Attributes:
        decision_id: Unique decision ID
        run_id: Execution run ID
        action: Action taken
        actor: Who made the decision
        timestamp: When decision was made
        context_snapshot: State at decision time
        changes: What was changed (for modifications)
        rationale: Optional human comment
    """
    decision_id: str
    run_id: str
    action: HITLAction
    actor: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    context_snapshot: Optional[Dict[str, Any]] = None
    changes: Optional[Dict[str, Any]] = None
    rationale: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "decision_id": self.decision_id,
            "run_id": self.run_id,
            "action": self.action.value,
            "actor": self.actor,
            "timestamp": self.timestamp.isoformat(),
            "context_snapshot": self.context_snapshot,
            "changes": self.changes,
            "rationale": self.rationale
        }


@dataclass
class HITLCheckpoint:
    """
    HITL execution checkpoint

    Stored before entering WAITING_FOR_HUMAN state.
    Enables deterministic resume after human action.

    Attributes:
        checkpoint_id: Unique checkpoint ID
        run_id: Execution run ID
        state: HITL state
        workflow_state: Complete workflow state
        execution_position: Where execution paused
        created_at: Checkpoint creation time
        timeout_at: When this checkpoint expires
    """
    checkpoint_id: str
    run_id: str
    state: HITLState
    workflow_state: Dict[str, Any]
    execution_position: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    timeout_at: Optional[datetime] = None

    def is_expired(self) -> bool:
        """Check if checkpoint has expired"""
        if not self.timeout_at:
            return False
        return datetime.utcnow() > self.timeout_at

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "checkpoint_id": self.checkpoint_id,
            "run_id": self.run_id,
            "state": self.state.value,
            "workflow_state": self.workflow_state,
            "execution_position": self.execution_position,
            "created_at": self.created_at.isoformat(),
            "timeout_at": self.timeout_at.isoformat() if self.timeout_at else None
        }


# ============================================================================
# DESERIALISERS
# ============================================================================
#
# A HITL checkpoint is written by one process and read by another, so every
# model above needs a way back from the dict it was stored as. ``to_dict`` had
# no counterpart, which is why the only rehydration that existed -- the startup
# checkpoint sweep -- reconstructed the checkpoint inline and silently ignored
# the context and the decision trail.

def _as_json_object(raw: Any) -> Dict[str, Any]:
    """
    Read a JSONB column into a dict whichever way the driver hands it over.

    asyncpg returns ``jsonb`` as a string when the query carries no type
    information -- which a raw ``text()`` statement does not -- while other
    paths return it already decoded. Both are accepted; anything else is
    treated as empty rather than raising, because this sits on the decision
    path and an unreadable row must not cost the reviewer their decision.
    """
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, (str, bytes)):
        try:
            decoded = json.loads(raw)
        except (ValueError, TypeError):
            return {}
        return decoded if isinstance(decoded, dict) else {}
    return {}


def _context_from_dict(run_id: str, data: Dict[str, Any]) -> HITLContext:
    """Rebuild a ``HITLContext`` from its stored form."""
    return HITLContext(
        workflow_id=data.get("workflow_id") or "",
        run_id=data.get("run_id") or run_id,
        blocked_at=data.get("blocked_at") or "",
        agent_output=data.get("agent_output"),
        tools_used=data.get("tools_used") or [],
        execution_metrics=data.get("execution_metrics") or {},
        state_snapshot=data.get("state_snapshot") or {},
        previous_decisions=data.get("previous_decisions") or [],
    )


def _decision_from_dict(data: Any) -> Optional[HITLDecision]:
    """
    Rebuild a ``HITLDecision`` from one line of the audit log.

    Returns ``None`` rather than raising for a record this build cannot read: an
    audit trail is append-only and long-lived, and one unreadable entry must not
    cost the reviewer the decision they are trying to make.
    """
    if not isinstance(data, dict):
        return None

    try:
        action = HITLAction(data["action"])
    except (KeyError, ValueError):
        logger.debug("Skipping HITL decision with unknown action: %r", data)
        return None

    timestamp = data.get("timestamp")
    try:
        parsed_time = datetime.fromisoformat(timestamp) if timestamp else datetime.utcnow()
    except (TypeError, ValueError):
        parsed_time = datetime.utcnow()

    return HITLDecision(
        decision_id=data.get("decision_id") or new_id("hitl_dec_"),
        run_id=data.get("run_id") or "",
        action=action,
        actor=data.get("actor") or "unknown",
        timestamp=parsed_time,
        context_snapshot=data.get("context_snapshot"),
        changes=data.get("changes"),
        rationale=data.get("rationale"),
    )


# ============================================================================
# HITL MANAGER (Runtime Orchestrator)
# ============================================================================

class HITLManager:
    """
    Manages HITL lifecycle for workflow executions

    Responsibilities:
    - Create HITL checkpoints
    - Store execution context
    - Record human decisions
    - Manage timeouts
    - Enforce validation after modifications
    - Maintain audit trail

    Integration with LangGraph:
    - Uses LangGraph checkpointing for state persistence
    - Stateless - can survive restarts

    Usage:
        hitl = HITLManager()

        # In workflow - request approval
        hitl.request_approval(
            run_id="exec_123",
            workflow_id="wf_456",
            blocked_at="agent:analyst",
            context=context_data
        )

        # Human approves via API
        hitl.approve(run_id="exec_123", actor="user@example.com")

        # Check status
        status = hitl.get_status("exec_123")
    """

    def __init__(self, storage_dir: str = None):
        """
        Initialize HITL manager

        Args:
            storage_dir: Directory for persistent storage
        """
        if storage_dir is None:
            storage_dir = Path(__file__).parent.parent / "storage" / "hitl"

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # In-memory cache
        self._checkpoints: Dict[str, HITLCheckpoint] = {}
        self._contexts: Dict[str, HITLContext] = {}
        self._decisions: Dict[str, List[HITLDecision]] = {}
        self._states: Dict[str, HITLState] = {}
        # Has the graph acted on the decision this run currently carries?
        # False between the reviewer's POST and the node consuming it, which is
        # exactly the window LangGraph replays the node in. See
        # ``request_approval`` and ``consume_decision``.
        self._resume_consumed: Dict[str, bool] = {}

        # Load existing checkpoints
        self._load_checkpoints()

    # ========================================================================
    # CORE HITL OPERATIONS
    # ========================================================================

    def request_approval(
        self,
        run_id: str,
        workflow_id: str,
        blocked_at: str,
        context: Dict[str, Any],
        timeout_seconds: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Request human approval (pauses execution)

        This is called from within workflow execution to pause and wait
        for human decision.

        Args:
            run_id: Execution run ID
            workflow_id: Workflow ID
            blocked_at: Where execution is paused (e.g., "agent:analyst")
            context: Full decision context
            timeout_seconds: Optional timeout

        Returns:
            Interrupt info for frontend

        Behavior:
            1. Create checkpoint
            2. Store context
            3. Set state = WAITING_FOR_HUMAN
            4. Return interrupt info

        **Replay-safe.** LangGraph restarts the whole node when a run resumes;
        it does not continue from the line after ``interrupt()``. Everything
        the HITL node does before that call therefore runs a second time on
        every resume, and the framework's own guidance is that such work must
        be idempotent.

        This method was keyed by ``run_id``, which made it idempotent in
        *identity* -- no duplicate checkpoint -- but not in *state*: it reset
        the run to ``waiting_for_human`` unconditionally. So the replay that
        follows an approval put the run straight back into "awaiting a
        decision" and rewrote every durable copy saying so, racing the
        ``approved`` write the route had just scheduled. Whichever landed last
        won, and when that was ``approved`` the next click hit
        ``_validate_state`` and the route answered 400 -- for every button,
        because all three validate the same way.

        A run already carrying a decision that the graph has not consumed yet
        is therefore left exactly as it is: this call is the replay of the
        pause that decision belongs to. ``consume_decision`` marks it consumed
        once the node has acted on it, so a genuine second pause -- the edit
        loop returning here, or a second checkpoint later in the graph -- goes
        through the normal path below and correctly waits again.
        """
        current = self._states.get(run_id)
        if current in DECIDED_STATES and not self._resume_consumed.get(run_id, False):
            logger.info(
                "[HITL] Replay of the decided pause for run '%s' (state=%s); "
                "leaving the recorded decision intact.",
                run_id, current.value,
            )
            return self._pause_payload(run_id, workflow_id, blocked_at, current)

        # A fresh pause. Anything the previous decision left behind is spent.
        self._resume_consumed[run_id] = False

        # Create checkpoint
        checkpoint = self._create_checkpoint(
            run_id=run_id,
            state=HITLState.WAITING_FOR_HUMAN,
            workflow_state=context.get("state_snapshot", {}),
            execution_position=blocked_at,
            timeout_seconds=timeout_seconds
        )

        # Store context — include hitl_config inside state_snapshot so
        # derive_allowed_decisions can retrieve it in the /hitl/decide route.
        snapshot = dict(context.get("state_snapshot", {}))
        if "hitl_config" in context:
            snapshot["hitl_config"] = context["hitl_config"]

        hitl_context = HITLContext(
            workflow_id=workflow_id,
            run_id=run_id,
            blocked_at=blocked_at,
            agent_output=context.get("agent_output"),
            tools_used=context.get("tools_used", []),
            execution_metrics=context.get("execution_metrics", {}),
            state_snapshot=snapshot,
            previous_decisions=self._get_decisions(run_id)
        )

        self._contexts[run_id] = hitl_context
        self._states[run_id] = HITLState.WAITING_FOR_HUMAN

        # Save to disk
        self._save_checkpoint(checkpoint)
        self._save_context(run_id, hitl_context)

        # Return interrupt payload
        return {
            "interrupted": True,
            "run_id": run_id,
            "workflow_id": workflow_id,
            "blocked_at": blocked_at,
            "checkpoint_id": checkpoint.checkpoint_id,
            "context": hitl_context.to_dict(),
            "allowed_actions": [a.value for a in HITLAction],
            "status": "waiting_for_human"
        }

    def _pause_payload(
        self,
        run_id: str,
        workflow_id: str,
        blocked_at: str,
        state: HITLState,
    ) -> Dict[str, Any]:
        """The interrupt payload for a pause that already exists."""
        checkpoint = self._checkpoints.get(run_id)
        context = self._contexts.get(run_id)
        return {
            "interrupted": True,
            "run_id": run_id,
            "workflow_id": workflow_id,
            "blocked_at": blocked_at,
            "checkpoint_id": checkpoint.checkpoint_id if checkpoint else None,
            "context": context.to_dict() if context else None,
            "allowed_actions": [a.value for a in HITLAction],
            "status": state.value,
        }

    def consume_decision(
        self,
        run_id: str,
        action: str,
        actor: str = "human_reviewer",
        rationale: Optional[str] = None,
        changes: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Mark the decision the graph has just acted on as spent.

        WHAT: Closes the pause. Confirms the run's state matches the decision,
              records the audit entry if -- and only if -- nothing recorded it
              already, and clears the replay guard so the next pause can wait
              again.
        WHY:  The HITL node used to call ``approve`` / ``reject`` / ``modify``
              a second time after ``interrupt()`` returned, on top of the call
              the route had already made. That produced two audit rows and two
              ``hitl_states`` writes per decision, on top of the replay's
              ``request_approval`` -- three unordered writes to one row, which
              is the race that left a paused run marked ``approved``. The node
              does not need to re-decide anything: the route validated the
              transition and recorded it before the resume was dispatched. It
              only needs to say the decision has been carried out.
        INPUT: The run, and the decision the node actually executed.
        OUTPUT: A small summary. Never raises -- the graph is already past the
                point where refusing would help, and a failure here must not
                turn a completed review into a failed node.

        Deliberately does **not** validate state. Validation belongs at the
        reviewer's boundary, which has already happened by the time the graph
        reaches this line.
        """
        try:
            normalized = str(action or "").strip().lower()
            if normalized == "edit":
                normalized = HITLAction.MODIFY.value

            try:
                hitl_action = HITLAction(normalized)
            except ValueError:
                hitl_action = HITLAction.REJECT  # fail closed, as the node does

            target = ACTION_STATES.get(hitl_action, HITLState.REJECTED)
            current = self._states.get(run_id)

            # The route records the decision and moves the state before the
            # resume is dispatched, so in the normal path there is nothing to
            # record here. A resume arriving by some other route -- a replayed
            # Celery task, a manual resume -- still gets its audit entry.
            if current != target:
                self._transition(run_id, target)
                self._record_decision(
                    run_id=run_id,
                    action=hitl_action,
                    actor=actor,
                    changes=changes,
                    rationale=rationale,
                )

            self._resume_consumed[run_id] = True
            self._on_decision_consumed(run_id, target)

            return {"run_id": run_id, "action": hitl_action.value, "status": target.value}

        except Exception as e:  # noqa: BLE001 -- bookkeeping must not fail a node
            logger.warning(
                "[HITL] Could not close the pause for run '%s': %s", run_id, e
            )
            return {"run_id": run_id, "action": action, "status": "unknown"}

    def _on_decision_consumed(self, run_id: str, state: HITLState) -> None:
        """Hook for subclasses that keep a durable copy. No-op on the file store."""

    def approve(self, run_id: str, actor: str, rationale: Optional[str] = None) -> Dict[str, Any]:
        """
        Approve execution (resume without changes)

        Args:
            run_id: Execution run ID
            actor: Who approved
            rationale: Optional comment

        Returns:
            Resume info
        """
        # Validate state
        self._validate_state(run_id, HITLState.WAITING_FOR_HUMAN)

        # Update state
        self._transition(run_id, HITLState.APPROVED)

        # Record decision
        self._record_decision(
            run_id=run_id,
            action=HITLAction.APPROVE,
            actor=actor,
            rationale=rationale
        )

        return {
            "action": "approve",
            "run_id": run_id,
            "actor": actor,
            "status": "approved",
            "can_resume": True
        }

    def reject(self, run_id: str, actor: str, rationale: Optional[str] = None) -> Dict[str, Any]:
        """
        Reject execution (terminate workflow)

        Args:
            run_id: Execution run ID
            actor: Who rejected
            rationale: Optional comment

        Returns:
            Termination info
        """
        # Validate state
        self._validate_state(run_id, HITLState.WAITING_FOR_HUMAN)

        # Update state
        self._transition(run_id, HITLState.REJECTED)

        # Record decision
        self._record_decision(
            run_id=run_id,
            action=HITLAction.REJECT,
            actor=actor,
            rationale=rationale
        )

        return {
            "action": "reject",
            "run_id": run_id,
            "actor": actor,
            "status": "rejected",
            "can_resume": False,
            "terminated": True
        }

    def modify(
        self,
        run_id: str,
        actor: str,
        changes: Dict[str, Any],
        rationale: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Modify workflow/agent configuration (validated draft workflows only)

        Args:
            run_id: Execution run ID
            actor: Who made changes
            changes: Changes to apply
            rationale: Optional comment

        Returns:
            Modification info

        Behavior:
            1. Apply changes
            2. Invalidate validation
            3. Set state = MODIFIED
            4. Require re-validation before resume
        """
        # Validate state
        self._validate_state(run_id, HITLState.WAITING_FOR_HUMAN)

        # Update state
        self._transition(run_id, HITLState.MODIFIED)

        # Record decision with changes
        self._record_decision(
            run_id=run_id,
            action=HITLAction.MODIFY,
            actor=actor,
            changes=changes,
            rationale=rationale
        )

        return {
            "action": "modify",
            "run_id": run_id,
            "actor": actor,
            "status": "modified",
            "changes": changes,
            "validation_required": True,
            "can_resume": False  # Must re-validate first
        }

    def handle_timeout(self, run_id: str) -> Dict[str, Any]:
        """
        Handle HITL timeout (auto-reject)

        Args:
            run_id: Execution run ID

        Returns:
            Timeout result
        """
        self.ensure_loaded(run_id)

        checkpoint = self._checkpoints.get(run_id)
        if checkpoint and checkpoint.is_expired():
            # Update state
            self._transition(run_id, HITLState.REJECTED)

            # Record decision
            self._record_decision(
                run_id=run_id,
                action=HITLAction.REJECT,
                actor="system",
                rationale="HITL timeout - auto-rejected"
            )

            return {
                "action": "reject",
                "run_id": run_id,
                "status": "timeout",
                "terminated": True
            }

        return {"status": "not_expired"}

    # ========================================================================
    # STATUS & CONTEXT QUERIES
    # ========================================================================

    def get_status(self, run_id: str) -> Dict[str, Any]:
        """
        Get HITL status for run

        Returns:
            {
                "run_id": "...",
                "state": "waiting_for_human",
                "blocked_at": "agent:analyst",
                "allowed_actions": ["approve", "reject", ...]
            }
        """
        self.ensure_loaded(run_id)

        state = self._states.get(run_id, HITLState.RUNNING)
        context = self._contexts.get(run_id)

        return {
            "run_id": run_id,
            "state": state.value,
            "blocked_at": context.blocked_at if context else None,
            "allowed_actions": [a.value for a in HITLAction],
            "has_pending_review": state == HITLState.WAITING_FOR_HUMAN
        }

    def get_context(self, run_id: str) -> Optional[HITLContext]:
        """Get full HITL context for run"""
        self.ensure_loaded(run_id)
        return self._contexts.get(run_id)

    def get_decisions(self, run_id: str) -> List[HITLDecision]:
        """Get all decisions for run (audit trail)"""
        self.ensure_loaded(run_id)
        return self._decisions.get(run_id, [])

    def list_pending_reviews(self) -> List[Dict[str, Any]]:
        """List all runs waiting for human review"""
        # Runs paused by another worker are on disk but not in this process's
        # dicts. Without this sweep the list only ever showed the checkpoints
        # this particular worker happened to create.
        self._load_checkpoints()

        pending = []
        for run_id, state in self._states.items():
            if state == HITLState.WAITING_FOR_HUMAN:
                context = self._contexts.get(run_id)
                if context:
                    pending.append({
                        "run_id": run_id,
                        "workflow_id": context.workflow_id,
                        "blocked_at": context.blocked_at,
                        "created_at": self._checkpoints[run_id].created_at.isoformat() if run_id in self._checkpoints else None
                    })
        return pending

    # ========================================================================
    # INTERNAL HELPERS
    # ========================================================================

    def _create_checkpoint(
        self,
        run_id: str,
        state: HITLState,
        workflow_state: Dict[str, Any],
        execution_position: str,
        timeout_seconds: Optional[int] = None
    ) -> HITLCheckpoint:
        """Create HITL checkpoint"""
        checkpoint_id = new_id("hitl_cp_")

        timeout_at = None
        if timeout_seconds:
            timeout_at = datetime.utcnow() + timedelta(seconds=timeout_seconds)

        checkpoint = HITLCheckpoint(
            checkpoint_id=checkpoint_id,
            run_id=run_id,
            state=state,
            workflow_state=workflow_state,
            execution_position=execution_position,
            timeout_at=timeout_at
        )

        self._checkpoints[run_id] = checkpoint

        return checkpoint

    def _record_decision(
        self,
        run_id: str,
        action: HITLAction,
        actor: str,
        changes: Optional[Dict[str, Any]] = None,
        rationale: Optional[str] = None
    ):
        """Record human decision (audit trail)"""
        decision_id = new_id("hitl_dec_")

        context = self._contexts.get(run_id)

        decision = HITLDecision(
            decision_id=decision_id,
            run_id=run_id,
            action=action,
            actor=actor,
            context_snapshot=context.to_dict() if context else None,
            changes=changes,
            rationale=rationale
        )

        if run_id not in self._decisions:
            self._decisions[run_id] = []

        self._decisions[run_id].append(decision)

        # Save to disk
        self._save_decision(run_id, decision)

    def _get_decisions(self, run_id: str) -> List[Dict[str, Any]]:
        """Get decision history for context"""
        decisions = self._decisions.get(run_id, [])
        return [d.to_dict() for d in decisions]

    def _validate_state(self, run_id: str, expected_state: HITLState):
        """
        Validate current HITL state.

        ``ensure_loaded`` first, because this is the gate every decision passes
        through. The API runs several worker processes; the reviewer's POST
        almost never lands on the process that paused the run, and reading only
        this process's memory reported "no such checkpoint" for a run that was
        very much paused -- which the route turned into a 400.
        """
        self.ensure_loaded(run_id)

        current_state = self._states.get(run_id)
        if current_state != expected_state:
            raise HITLStateError(run_id, expected_state, current_state)

    def _transition(self, run_id: str, new_state: HITLState):
        """
        Move a run to a new state, and make that visible outside this process.

        The in-memory dict is not enough on its own: the next request may be
        served by a different worker. Rewriting the checkpoint keeps the durable
        copies -- file and database -- in step with memory, so a later
        ``ensure_loaded`` reads the state the run is *now* in rather than the one
        it paused in. Without this, a rehydrated run still looked like it was
        waiting and could be decided twice.
        """
        self._states[run_id] = new_state

        checkpoint = self._checkpoints.get(run_id)
        if checkpoint is None:
            return

        checkpoint.state = new_state
        self._save_checkpoint(checkpoint)

    # ========================================================================
    # REHYDRATION
    # ========================================================================

    def ensure_loaded(self, run_id: str) -> bool:
        """
        Make sure *this* process knows about ``run_id``, loading it if not.

        WHAT: Returns True when the run's checkpoint, context and decision trail
              are in memory -- loading them from the storage directory if this
              process has not seen the run before.
        WHY:  A paused run is state that outlives the request that created it,
              and the request that ends it is a different request, usually on a
              different worker. ``HITLDBManager`` extends this with a database
              read for the case where the workers do not share a filesystem.
        INPUT: The run id the caller is about to act on.
        OUTPUT: True if the run is known after this call, False if there is no
                record of it anywhere -- which is a genuinely unknown run.

        Cheap and idempotent: a run already in memory costs one dict lookup.
        """
        if not run_id:
            return False
        if run_id in self._states:
            return True
        return self._load_run(run_id)

    def _load_run(self, run_id: str) -> bool:
        """Load one run's checkpoint, context and decisions from the storage dir."""
        checkpoint_path = self.storage_dir / f"{run_id}_checkpoint.json"
        if not checkpoint_path.exists():
            return False

        try:
            with open(checkpoint_path) as f:
                data = json.load(f)

            checkpoint = HITLCheckpoint(
                checkpoint_id=data["checkpoint_id"],
                run_id=data["run_id"],
                state=HITLState(data["state"]),
                workflow_state=data.get("workflow_state") or {},
                execution_position=data.get("execution_position", ""),
                created_at=datetime.fromisoformat(data["created_at"]),
                timeout_at=(
                    datetime.fromisoformat(data["timeout_at"])
                    if data.get("timeout_at") else None
                ),
            )
        except Exception as e:
            logger.warning(
                "HITL checkpoint for run '%s' could not be read from %s: %s",
                run_id, checkpoint_path, e,
            )
            return False

        self._checkpoints[run_id] = checkpoint
        self._states[run_id] = checkpoint.state

        self._load_context(run_id)
        self._load_decisions(run_id)
        return True

    def _load_context(self, run_id: str) -> None:
        """Load a run's decision context from disk, if one was written."""
        path = self.storage_dir / f"{run_id}_context.json"
        if not path.exists():
            return

        try:
            with open(path) as f:
                data = json.load(f)
            self._contexts[run_id] = _context_from_dict(run_id, data)
        except Exception as e:
            logger.warning(
                "HITL context for run '%s' could not be read: %s", run_id, e
            )

    def _load_decisions(self, run_id: str) -> None:
        """Load a run's decision trail from its append-only audit log."""
        path = self.storage_dir / f"{run_id}_decisions.jsonl"
        if not path.exists():
            return

        decisions: List[HITLDecision] = []
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    decision = _decision_from_dict(line and json.loads(line))
                    if decision is not None:
                        decisions.append(decision)
        except Exception as e:
            logger.warning(
                "HITL decision trail for run '%s' could not be read: %s", run_id, e
            )
            return

        if decisions:
            self._decisions[run_id] = decisions

    # ========================================================================
    # PERSISTENCE
    # ========================================================================

    def _save_checkpoint(self, checkpoint: HITLCheckpoint):
        """Save checkpoint to disk, then best-effort persist to DB."""
        file_path = self.storage_dir / f"{checkpoint.run_id}_checkpoint.json"
        with open(file_path, 'w') as f:
            json.dump(checkpoint.to_dict(), f, indent=2)

        # Best-effort DB persistence using HITLCheckpoint model
        self._persist_checkpoint_to_db(checkpoint)

    def _save_context(self, run_id: str, context: HITLContext):
        """Save context to disk, then best-effort update DB checkpoint."""
        file_path = self.storage_dir / f"{run_id}_context.json"
        with open(file_path, 'w') as f:
            json.dump(context.to_dict(), f, indent=2)

        # Best-effort DB persistence: update the checkpoint row with context
        self._persist_context_to_db(run_id, context)

    def _save_decision(self, run_id: str, decision: HITLDecision):
        """Save decision to disk (append to audit log), then best-effort update DB."""
        file_path = self.storage_dir / f"{run_id}_decisions.jsonl"
        with open(file_path, 'a') as f:
            f.write(json.dumps(decision.to_dict()) + '\n')

        # Best-effort DB persistence: update checkpoint with decision
        self._persist_decision_to_db(run_id, decision)

    # ========================================================================
    # DB PERSISTENCE HELPERS (best-effort, non-blocking)
    # ========================================================================

    def _persist_checkpoint_to_db(self, checkpoint: HITLCheckpoint):
        """
        Persist checkpoint to the hitl_checkpoints table via SQLAlchemy model.

        This is a secondary persistence layer. The filesystem write is the
        primary store. DB failure is non-fatal and logged as a warning.
        """
        try:
            import asyncio
            from echolib.database import get_db_session
            from echolib.models.execution import HITLCheckpoint as HITLCheckpointModel
            from echolib.id_utils import normalize_to_uuid
            from sqlalchemy import select, update as sa_update

            # Attempt UUID conversions -- skip DB persist if IDs are not valid UUIDs
            try:
                run_uuid = normalize_to_uuid(checkpoint.run_id)
            except (ValueError, Exception):
                logger.debug(
                    f"HITL DB persist skipped: run_id '{checkpoint.run_id}' "
                    f"is not a valid UUID"
                )
                return

            try:
                blocked_uuid = normalize_to_uuid(checkpoint.execution_position)
            except (ValueError, Exception):
                # blocked_at may be a descriptive string like "agent:analyst"
                # -- cannot persist to UUID column, skip gracefully
                logger.debug(
                    f"HITL DB persist skipped: blocked_at '{checkpoint.execution_position}' "
                    f"is not a valid UUID"
                )
                return

            # Map runtime HITLState to DB status values
            status_map = {
                "running": "waiting_for_human",
                "waiting_for_human": "waiting_for_human",
                "approved": "approved",
                "rejected": "rejected",
                "modified": "modified",
                "deferred": "deferred",
            }
            db_status = status_map.get(checkpoint.state.value, "waiting_for_human")

            async def _persist():
                from uuid import UUID
                async with get_db_session() as db:
                    # Check if checkpoint already exists for this run
                    stmt = select(HITLCheckpointModel).where(
                        HITLCheckpointModel.run_id == UUID(run_uuid)
                    ).limit(1)
                    result = await db.execute(stmt)
                    existing = result.scalar_one_or_none()

                    if existing:
                        upd = (
                            sa_update(HITLCheckpointModel)
                            .where(HITLCheckpointModel.checkpoint_id == existing.checkpoint_id)
                            .values(
                                status=db_status,
                                state_snapshot=checkpoint.workflow_state,
                            )
                        )
                        await db.execute(upd)
                    else:
                        row = HITLCheckpointModel(
                            run_id=UUID(run_uuid),
                            status=db_status,
                            blocked_at=UUID(blocked_uuid),
                            state_snapshot=checkpoint.workflow_state,
                            previous_decisions=[],
                        )
                        db.add(row)
                    await db.flush()

            self._schedule_async(_persist)

        except Exception as e:
            logger.warning(f"HITL checkpoint DB persist failed: {e}")

    def _persist_context_to_db(self, run_id: str, context: HITLContext):
        """
        Update the DB checkpoint row with agent_output and context data.
        """
        try:
            import asyncio
            from echolib.database import get_db_session
            from echolib.models.execution import HITLCheckpoint as HITLCheckpointModel
            from echolib.id_utils import normalize_to_uuid
            from sqlalchemy import select, update as sa_update

            try:
                run_uuid = normalize_to_uuid(run_id)
            except (ValueError, Exception):
                return

            async def _persist():
                from uuid import UUID
                async with get_db_session() as db:
                    stmt = select(HITLCheckpointModel).where(
                        HITLCheckpointModel.run_id == UUID(run_uuid)
                    ).limit(1)
                    result = await db.execute(stmt)
                    existing = result.scalar_one_or_none()

                    if existing:
                        upd = (
                            sa_update(HITLCheckpointModel)
                            .where(HITLCheckpointModel.checkpoint_id == existing.checkpoint_id)
                            .values(
                                agent_output=context.agent_output,
                                tools_used={"tools": context.tools_used} if context.tools_used else None,
                                execution_metrics=context.execution_metrics or None,
                                state_snapshot=context.state_snapshot or None,
                            )
                        )
                        await db.execute(upd)
                        await db.flush()

            self._schedule_async(_persist)

        except Exception as e:
            logger.warning(f"HITL context DB persist failed: {e}")

    def _persist_decision_to_db(self, run_id: str, decision: HITLDecision):
        """
        Update the DB checkpoint row with the latest decision.
        """
        try:
            import asyncio
            from echolib.database import get_db_session
            from echolib.models.execution import HITLCheckpoint as HITLCheckpointModel
            from echolib.id_utils import normalize_to_uuid
            from sqlalchemy import select, update as sa_update
            from datetime import datetime as dt, timezone

            try:
                run_uuid = normalize_to_uuid(run_id)
            except (ValueError, Exception):
                return

            # Map action to resolution and status. ``defer`` stays in both maps
            # for read-back: decisions recorded before deferral was removed must
            # still resolve, and the DB check constraint still permits the value.
            action_to_resolution = {
                "approve": "approve",
                "reject": "reject",
                "modify": "modify",
                "defer": "defer",
                "rerun": "rerun",
            }
            action_to_status = {
                "approve": "approved",
                "reject": "rejected",
                "modify": "modified",
                "defer": "deferred",
                "rerun": "waiting_for_human",
            }

            resolution = action_to_resolution.get(decision.action.value, decision.action.value)
            new_status = action_to_status.get(decision.action.value, "approved")

            async def _persist():
                from uuid import UUID
                async with get_db_session() as db:
                    stmt = select(HITLCheckpointModel).where(
                        HITLCheckpointModel.run_id == UUID(run_uuid)
                    ).limit(1)
                    result = await db.execute(stmt)
                    existing = result.scalar_one_or_none()

                    if existing:
                        # Append to previous_decisions
                        prev = list(existing.previous_decisions or [])
                        prev.append({
                            "resolution": resolution,
                            "resolved_by": decision.actor,
                            "resolved_at": decision.timestamp.isoformat(),
                            "rationale": decision.rationale,
                            "changes": decision.changes,
                        })

                        upd = (
                            sa_update(HITLCheckpointModel)
                            .where(HITLCheckpointModel.checkpoint_id == existing.checkpoint_id)
                            .values(
                                status=new_status,
                                resolution=resolution,
                                resolution_data=decision.changes,
                                resolved_at=dt.now(timezone.utc),
                                previous_decisions=prev,
                            )
                        )
                        await db.execute(upd)
                        await db.flush()

            self._schedule_async(_persist)

        except Exception as e:
            logger.warning(f"HITL decision DB persist failed: {e}")

    @staticmethod
    def _schedule_async(coro_fn):
        """
        Run an async database write from synchronous code, on either side.

        The three ``_persist_*_to_db`` methods above reach this from two
        different places: an async route deciding a checkpoint, and the HITL
        node pausing a run inside ``asyncio.to_thread``. The second is a worker
        thread with no event loop of its own.

        This used to fall back to ``asyncio.get_event_loop()``, which raises
        ``RuntimeError`` in a non-main thread on Python 3.11 -- so from the
        worker thread it silently did nothing at all. ``run_db_coro_sync``
        schedules onto the loop registered at startup and waits, which is what
        that fallback was reaching for.

        Never raises: these are secondary records and the filesystem write has
        already happened by the time this is called.
        """
        import asyncio

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            # On the loop already. A task is correct, and ``run_db_coro_sync``
            # would refuse rather than deadlock on the loop it needs. Tracked,
            # so a failure is logged against this write instead of surfacing
            # later as a bare "Task exception was never retrieved".
            track_task(
                asyncio.get_running_loop().create_task(coro_fn()),
                "HITL checkpoint DB write",
            )
            return

        try:
            from echolib.database import run_db_coro_sync

            run_db_coro_sync(coro_fn, timeout=30.0)
        except Exception as exc:
            logger.warning("HITL DB persist skipped: %s", exc)

    def _load_checkpoints(self):
        """
        Load every checkpoint in the storage directory.

        Runs at startup and whenever the full pending list is asked for. Each
        run goes through ``_load_run``, so its context and decision trail come
        with it -- loading the checkpoint alone left ``list_pending_reviews``
        skipping every entry, because it reads the context to build a row.
        """
        if not self.storage_dir.exists():
            return

        for file_path in self.storage_dir.glob("*_checkpoint.json"):
            run_id = file_path.name[: -len("_checkpoint.json")]
            try:
                self._load_run(run_id)
            except Exception as e:
                logger.warning("Error loading HITL checkpoint %s: %s", file_path, e)


# ============================================================================
# HITL ALLOWED DECISIONS DERIVATION
# ============================================================================

# The decisions a checkpoint can offer. Deferral is deliberately absent: it had
# no clean runtime answer -- a deferred run either ends, so "postponed" means
# re-running the whole workflow and paying for every model call again, or parks
# at an interrupt nothing sweeps, which is an abandoned thread by another name.
# A reviewer who simply does not answer already leaves the run paused and
# resumable, which is the same outcome without a second concept.
SUPPORTED_DECISIONS = ("approve", "reject", "edit")


def derive_allowed_decisions(hitl_config: dict) -> list:
    """
    Derive allowed_decisions list from hitl_config.

    Supports BOTH formats:
    - New format: hitl_config has "allowed_decisions" list directly
    - Legacy format: hitl_config has "allowEdit" boolean

    Approve and Reject are ALWAYS allowed (non-negotiable safety constraint).

    A stored ``allowed_decisions`` naming a decision this build does not support
    -- ``defer`` on a canvas saved earlier -- is filtered out rather than
    honoured, so an old workflow offers the reviewer only buttons that work.

    Args:
        hitl_config: The hitl_config dict from node metadata.

    Returns:
        List of allowed action strings, e.g. ["approve", "reject", "edit"]
    """
    if not hitl_config:
        return ["approve", "reject"]

    # If new format exists, use it directly
    if "allowed_decisions" in hitl_config:
        decisions = [d for d in hitl_config["allowed_decisions"] if d in SUPPORTED_DECISIONS]
        # Enforce: approve and reject are always present
        for required in ("approve", "reject"):
            if required not in decisions:
                decisions.append(required)
        return decisions

    # Legacy boolean format -> derive list
    decisions = ["approve", "reject"]  # Always allowed
    if hitl_config.get("allowEdit", True):
        decisions.append("edit")
    return decisions


# ============================================================================
# HITL DB MANAGER (Database-Backed Persistence)
# ============================================================================

class HITLDBManager(HITLManager):
    """
    Database-backed HITL manager that extends HITLManager.

    Adds persistent storage via PostgreSQL for HITL state, checkpoints,
    contexts, and decisions. This ensures state survives process restarts
    and is consistent across multiple Celery workers.

    Drop-in replacement for HITLManager — all existing methods work unchanged.
    The file-based persistence from HITLManager is retained as a fallback
    and for backward compatibility. DB persistence is layered on top.

    Usage:
        hitl = HITLDBManager()

        # All existing HITLManager methods work identically:
        hitl.request_approval(run_id, workflow_id, blocked_at, context)
        hitl.approve(run_id, actor)
        hitl.get_status(run_id)

        # New method for triggering resume via Celery:
        hitl.trigger_resume(run_id, action, payload)
    """

    def __init__(self, storage_dir: str = None):
        """
        Initialize HITLDBManager.

        Calls parent HITLManager.__init__ to preserve file-based persistence.
        Adds database connection setup for persistent storage.

        Args:
            storage_dir: Directory for file-based storage (fallback).
        """
        super().__init__(storage_dir=storage_dir)

        # Database persistence flag - set to True once DB is verified available
        self._db_available = False
        # In-flight ``hitl_states`` write per run, awaited by ``flush_state``
        # before a resume is dispatched.
        self._pending_writes: Dict[str, Any] = {}
        self._init_db_persistence()

    def _init_db_persistence(self):
        """
        Initialize database persistence layer.

        Attempts to verify database connectivity. If the database is not
        available, falls back to file-based persistence (parent class behavior).

        It used to also capture the running event loop here, for
        ``_persist_hitl_state_to_db`` to schedule onto from a worker thread.
        That capture could never succeed: this class is instantiated at import
        time in ``apps/workflow/container.py``, before uvicorn has a loop, so it
        raised and left the reference ``None`` forever -- which is one of the
        three reasons a paused run was never recorded. ``run_db_coro_sync``
        resolves the loop registered at startup instead.
        """
        try:
            from echolib.config import settings
            # Verify we have a database URL configured
            if settings.database_url:
                self._db_available = True
                logger.info("HITLDBManager: Database persistence enabled")
            else:
                logger.warning(
                    "HITLDBManager: No database_url configured, "
                    "using file-based persistence only"
                )
        except Exception as e:
            logger.warning(
                f"HITLDBManager: Database init failed ({e}), "
                f"using file-based persistence only"
            )

    def request_approval(
        self,
        run_id: str,
        workflow_id: str,
        blocked_at: str,
        context: Dict[str, Any],
        timeout_seconds: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Request human approval with DB persistence.

        Extends parent method by also persisting to database.

        Args:
            run_id: Execution run ID
            workflow_id: Workflow ID
            blocked_at: Where execution is paused
            context: Full decision context
            timeout_seconds: Optional timeout

        Returns:
            Interrupt info for frontend
        """
        # Call parent for file-based persistence + in-memory state
        result = super().request_approval(
            run_id=run_id,
            workflow_id=workflow_id,
            blocked_at=blocked_at,
            context=context,
            timeout_seconds=timeout_seconds,
        )

        # Persist to DB if available
        if self._db_available:
            self._persist_hitl_state_to_db(run_id, "waiting_for_human", result)

        return result

    def approve(self, run_id: str, actor: str, rationale: Optional[str] = None) -> Dict[str, Any]:
        """Approve with DB persistence."""
        result = super().approve(run_id=run_id, actor=actor, rationale=rationale)
        if self._db_available:
            self._persist_hitl_state_to_db(run_id, "approved", result)
        return result

    def reject(self, run_id: str, actor: str, rationale: Optional[str] = None) -> Dict[str, Any]:
        """Reject with DB persistence."""
        result = super().reject(run_id=run_id, actor=actor, rationale=rationale)
        if self._db_available:
            self._persist_hitl_state_to_db(run_id, "rejected", result)
        return result

    def modify(
        self,
        run_id: str,
        actor: str,
        changes: Dict[str, Any],
        rationale: Optional[str] = None
    ) -> Dict[str, Any]:
        """Modify with DB persistence."""
        result = super().modify(run_id=run_id, actor=actor, changes=changes, rationale=rationale)
        if self._db_available:
            self._persist_hitl_state_to_db(run_id, "modified", result)
        return result

    async def flush_state(self, run_id: str) -> None:
        """
        Wait for this run's pending ``hitl_states`` write to commit.

        WHAT: Awaits the task ``_persist_hitl_state_to_db`` scheduled on the
              loop, if one is outstanding.
        WHY:  The decision write was fire-and-forget and the resume was
              dispatched immediately after it, so the graph could re-enter the
              HITL node while the row still read ``waiting_for_human`` -- and
              the decision would then land on top of a run that had already
              moved on. Committing before the resume is dispatched removes the
              window entirely; the monotonic guard in the upsert is the
              backstop, not the mechanism.
        OUTPUT: None. Never raises -- a write that failed is already logged by
                its own callback, and the reviewer's decision still stands in
                memory and on disk.
        """
        task = self._pending_writes.pop(run_id, None)
        if task is None:
            return
        try:
            await task
        except Exception as e:  # noqa: BLE001 -- already reported by track_task
            logger.warning(
                "HITL state write for run '%s' did not complete: %s", run_id, e
            )

    def _on_decision_consumed(self, run_id: str, state: HITLState) -> None:
        """
        Record that the graph has acted on this run's decision.

        Persisted rather than held in memory because the replay guard in
        ``request_approval`` reads it, and the worker that consumes a decision
        is not necessarily the one that will serve the next pause.
        """
        if self._db_available:
            self._persist_hitl_state_to_db(
                run_id, state.value, {"resume_consumed": True}
            )

    def trigger_resume(
        self,
        run_id: str,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Trigger workflow resume after a HITL decision.

        Dispatches a Celery task to resume the workflow from its
        interrupt point using LangGraph's Command(resume=...).

        A rejection is resumed too, and that is the correction rather than an
        oversight. This used to return ``terminated`` immediately and resume
        nothing, on the reading that a rejected run has nowhere to go. But the
        run is parked inside ``interrupt()``, and the only code that knows how
        to end it cleanly is the HITL node's own reject branch -- it records the
        decision, writes the "rejected by <reviewer>" result and routes to END.
        Never resuming meant that branch never ran: the thread stayed parked
        forever, the execution_runs row was never closed, and the reviewer saw
        their rejection acknowledged by an API that had not actually stopped
        anything.

        Args:
            run_id: The run_id of the paused workflow.
            action: The human decision ("approve", "reject", "edit").
            payload: Additional data for the resume (edit content, etc.).

        Returns:
            Dict with task dispatch status.
        """
        logger.info(f"Dispatching resume task for run '{run_id}', action='{action}'")

        # Resolve workflow_id from context. ``ensure_loaded`` first: on a worker
        # that did not run the workflow the context is not in memory, and
        # resuming without a workflow_id is not possible.
        self.ensure_loaded(run_id)
        context = self._contexts.get(run_id)
        workflow_id = context.workflow_id if context else None

        # Try Celery first, fall back to direct resume
        try:
            from echolib.celery.celery_tasks import resume_workflow_task

            task_result = resume_workflow_task.delay(
                run_id=run_id,
                action=action,
                payload=payload or {},
                workflow_id=workflow_id,
            )

            return {
                "run_id": run_id,
                "action": action,
                "status": "resume_dispatched",
                "resume_dispatched": True,
                "task_id": task_result.id,
            }

        except Exception as e:
            # Celery not installed, Redis not running, or any dispatch failure
            # — fall back to direct resume by caller
            logger.info(
                f"Celery dispatch unavailable for run '{run_id}' ({type(e).__name__}: {e}). "
                f"Falling back to direct resume."
            )
            return {
                "run_id": run_id,
                "action": action,
                "workflow_id": workflow_id,
                "status": "resume_pending",
                "resume_dispatched": False,
                "payload": payload or {},
            }

    def _durable_snapshot(
        self,
        run_id: str,
        state: str,
        result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Everything another process needs to answer for this run.

        WHAT: The state, the checkpoint, the decision context and the audit
              trail, in one JSON object.
        WHY:  ``hitl_states.data`` used to hold only the return value of
              whichever method had just run. That is enough to say *what* was
              decided and nothing else: an ``approve`` payload carries no
              context, so a worker that rehydrated from it could not tell the
              reviewer what they were approving, and ``trigger_resume`` could
              not find the ``workflow_id`` it needs to resume. One row per run
              now carries the whole picture.
        OUTPUT: A JSON-serialisable dict. ``result`` is preserved under its own
                key so a reader written against the old shape still finds it.
        """
        context = self._contexts.get(run_id)
        checkpoint = self._checkpoints.get(run_id)

        return {
            **(result if isinstance(result, dict) else {}),
            "state": state,
            "result": result,
            "context": context.to_dict() if context else None,
            "checkpoint": checkpoint.to_dict() if checkpoint else None,
            "decisions": [d.to_dict() for d in self._decisions.get(run_id, [])],
            # Whether the graph has already acted on the decision this run
            # carries. Read back by ``_load_run_from_db`` so the replay guard
            # in ``request_approval`` works on a worker that did not serve the
            # decision.
            "resume_consumed": bool(self._resume_consumed.get(run_id, False)),
        }

    async def ensure_loaded_async(self, run_id: str) -> bool:
        """
        Rehydrate a run from the database when this process has not seen it.

        WHAT: Reads the ``hitl_states`` row for ``run_id`` and repopulates this
              process's state, checkpoint, context and decision trail.
        WHY:  ``hitl_states`` has been written on every transition since it was
              introduced and read by nothing. The gate that decides whether an
              approval is allowed read process memory only, so the reviewer's
              POST -- served by whichever of the four uvicorn workers the load
              balancer picked -- reported "no such checkpoint" and the route
              answered 400. This is the missing read.
        INPUT: The run id. Safe to call for a run that is already loaded.
        OUTPUT: True when the run is known after this call.

        Async because the callers are async routes: a blocking database read
        from the synchronous ``_validate_state`` would sit on the event loop.
        The synchronous ``ensure_loaded`` inherited from ``HITLManager`` remains
        the fallback, and is what the workflow node itself uses.

        Never raises. A database that cannot be reached degrades to the
        file-based path rather than failing the decision.

        **The stored row wins over what this process already believes**, which
        is why there is no "already in memory, nothing to do" short-circuit
        here. A run can pause more than once -- the edit loop routes back to the
        preceding agent and returns to the same node, and a workflow may have
        several HITL nodes. Each pause is served by whichever worker is running
        the graph, while every other worker still holds the state from the
        *previous* decision. Trusting that cache reported ``approved`` for a run
        that was waiting again, and the gate answered 400. The row is rewritten
        on every transition, so it is the newer answer by construction; memory
        and the file are the fallbacks when it cannot be read.
        """
        if not run_id:
            return False

        if self._db_available:
            try:
                if await self._load_run_from_db(run_id):
                    return True
            except Exception as e:
                logger.warning(
                    "HITLDBManager: database rehydration failed for run '%s': %s. "
                    "Falling back to file-based state.",
                    run_id, e,
                )

        if run_id in self._states:
            return True

        if self.ensure_loaded(run_id):
            return True

        # Neither the state row nor the file knows this run. For a run paused
        # before the pause-time write was fixed -- or one whose container has
        # since been replaced, taking the storage directory with it -- there is
        # still one durable record: LangGraph's own checkpointer.
        return await self._recover_from_checkpointer(run_id)

    # ------------------------------------------------------------------
    # LAST-RESORT RECOVERY
    # ------------------------------------------------------------------

    async def _recover_from_checkpointer(self, run_id: str) -> bool:
        """
        Rebuild a paused run from LangGraph's checkpointer when nothing else has it.

        WHAT: Looks the run's workflow up in ``execution_runs``, recompiles its
              graph, and asks the checkpointer whether that thread is parked at
              an interrupt. If it is, this process is repopulated as
              ``WAITING_FOR_HUMAN`` from the interrupt payload, and the missing
              ``hitl_states`` row is written so no other worker has to repeat
              this.
        WHY:  ``hitl_states`` was never written at pause time, and the file it
              fell back to lives in the container. Every run paused before that
              was fixed is therefore undecidable -- ``_validate_state`` raises
              and the route answers 400 -- even though the run itself is
              perfectly resumable. The checkpointer is the one record that did
              survive: HITL workflows compile against ``PostgresSaver``
              (``compiler._get_checkpointer``), which is in the same database
              and outlives any container.
        INPUT: The run id a decision is about to be made on.
        OUTPUT: True when the run was recovered and is now decidable.

        Only reached on the path that currently fails, so a healthy decision
        pays nothing for it. Never raises: a run that cannot be recovered
        reports the same "unknown run" it does today.
        """
        try:
            workflow_id, owner_id = await self._run_owner(run_id)
            if not workflow_id:
                logger.info(
                    "HITL run '%s' is not in hitl_states, on disk, or in "
                    "execution_runs -- there is no record of it to recover.",
                    run_id,
                )
                return False

            snapshot = await asyncio.to_thread(
                self._read_checkpointer_state, workflow_id, run_id, owner_id
            )
            if snapshot is None:
                return False

            interrupt_value, state_values = snapshot

            payload = interrupt_value if isinstance(interrupt_value, dict) else {}
            blocked_at = str(payload.get("node_id") or "")
            hitl_config = {
                key: payload[key]
                for key in ("title", "message", "priority", "allowed_decisions")
                if key in payload
            }

            state_snapshot = dict(payload.get("state_snapshot") or state_values or {})
            if hitl_config:
                # `/hitl/decide` reads allowed_decisions from here.
                state_snapshot["hitl_config"] = hitl_config

            context = HITLContext(
                workflow_id=workflow_id,
                run_id=run_id,
                blocked_at=blocked_at,
                agent_output=payload.get("preceding_output"),
                state_snapshot=state_snapshot,
            )

            checkpoint = HITLCheckpoint(
                checkpoint_id=new_id("ckpt_"),
                run_id=run_id,
                state=HITLState.WAITING_FOR_HUMAN,
                workflow_state=state_snapshot,
                execution_position=blocked_at,
            )

            self._checkpoints[run_id] = checkpoint
            self._contexts[run_id] = context
            self._states[run_id] = HITLState.WAITING_FOR_HUMAN

            logger.warning(
                "HITL run '%s' had no state record and was recovered from the "
                "workflow checkpointer (workflow=%s, node=%s). Recording it so "
                "the next decision does not have to.",
                run_id, workflow_id, blocked_at or "unknown",
            )

            # Write what should have been written when the run paused, so this
            # recovery happens once rather than on every decision.
            self._save_checkpoint(checkpoint)
            self._save_context(run_id, context)
            if self._db_available:
                self._persist_hitl_state_to_db(
                    run_id,
                    HITLState.WAITING_FOR_HUMAN.value,
                    {"recovered_from": "checkpointer", "workflow_id": workflow_id},
                )

            return True

        except Exception as e:
            logger.warning(
                "HITL run '%s' could not be recovered from the checkpointer: %s",
                run_id, e, exc_info=True,
            )
            return False

    @staticmethod
    async def _run_owner(run_id: str):
        """
        The workflow and user a run belongs to, from ``execution_runs``.

        The runtime records every run there through ``save_run`` before it can
        reach a HITL node, so this answers for any run that actually started --
        including ones whose HITL state was never written. Returns
        ``(workflow_id, user_id)``, either of which may be ``None``.
        """
        from echolib.database import get_db_session
        from sqlalchemy import text

        try:
            async with get_db_session() as db:
                result = await db.execute(
                    text(
                        "SELECT workflow_id, user_id FROM execution_runs "
                        "WHERE run_id = :run_id LIMIT 1"
                    ),
                    {"run_id": run_id},
                )
                row = result.first()
        except Exception:
            logger.warning(
                "Could not read execution_runs for run '%s'", run_id, exc_info=True
            )
            return None, None

        if not row:
            return None, None
        return (
            str(row[0]) if row[0] else None,
            str(row[1]) if row[1] else None,
        )

    @staticmethod
    def _read_checkpointer_state(
        workflow_id: str, run_id: str, user_id: Optional[str] = None
    ):
        """
        Ask the compiled graph whether ``run_id`` is parked at an interrupt.

        Returns ``(interrupt_value, state_values)`` when it is, otherwise
        ``None``. Synchronous -- compiling a graph and reading the checkpointer
        both block -- so the caller runs it in a worker thread.

        ``get_state`` is LangGraph's supported read of a thread's saved state;
        ``.interrupts`` carries the payload the HITL node passed to
        ``interrupt()``, which is where the node id and the reviewer's options
        come from. Nothing is executed here -- the graph is compiled only so
        there is something to read the checkpoint through.
        """
        from echolib.di import container

        executor = container.resolve('workflow.executor')
        compiler = container.resolve('workflow.compiler')

        workflow = executor._load_workflow(workflow_id, "draft", None)
        if not workflow:
            logger.info(
                "Workflow '%s' could not be loaded to recover run '%s'",
                workflow_id, run_id,
            )
            return None

        agent_defs = executor._load_agent_defs(workflow, user_id)
        graph = compiler.compile_to_langgraph(workflow, agent_defs)

        state = graph.get_state({"configurable": {"thread_id": run_id}})
        if state is None:
            return None

        interrupts = getattr(state, "interrupts", None) or ()
        if not interrupts:
            # Parked at no interrupt: the run either finished or never paused.
            # Recovering it as "waiting" would invent a checkpoint, so it is
            # left unknown -- which is the honest answer.
            logger.info(
                "Run '%s' has checkpointer state but is not parked at an "
                "interrupt; it is not awaiting a decision.",
                run_id,
            )
            return None

        first = interrupts[0]
        value = getattr(first, "value", first)
        return value, dict(getattr(state, "values", None) or {})

    async def _load_run_from_db(self, run_id: str) -> bool:
        """Read one run's stored snapshot and repopulate this process from it."""
        from echolib.database import get_db_session
        from sqlalchemy import text

        async with get_db_session() as db:
            result = await db.execute(
                text(
                    "SELECT state, data FROM hitl_states WHERE run_id = :run_id"
                ),
                {"run_id": run_id},
            )
            row = result.first()

        if row is None:
            return False

        state_value, raw = row[0], row[1]
        payload = _as_json_object(raw)

        try:
            state = HITLState(state_value)
        except ValueError:
            logger.warning(
                "HITL run '%s' is stored with state '%s', which this build does "
                "not recognise; treating it as unknown.",
                run_id, state_value,
            )
            return False

        self._states[run_id] = state
        # Absent on a row written before this field existed. Defaulting to
        # False is the safe reading: an unconsumed decision only suppresses a
        # ``request_approval`` that is about to be replayed anyway.
        self._resume_consumed[run_id] = bool(payload.get("resume_consumed", False))

        checkpoint = payload.get("checkpoint")
        if isinstance(checkpoint, dict):
            try:
                self._checkpoints[run_id] = HITLCheckpoint(
                    checkpoint_id=checkpoint["checkpoint_id"],
                    run_id=checkpoint.get("run_id") or run_id,
                    state=state,
                    workflow_state=checkpoint.get("workflow_state") or {},
                    execution_position=checkpoint.get("execution_position", ""),
                    created_at=datetime.fromisoformat(checkpoint["created_at"]),
                    timeout_at=(
                        datetime.fromisoformat(checkpoint["timeout_at"])
                        if checkpoint.get("timeout_at") else None
                    ),
                )
            except Exception as e:
                logger.debug(
                    "HITL checkpoint for run '%s' could not be rebuilt: %s", run_id, e
                )

        # Written by `_durable_snapshot`; the pre-existing shape nested it one
        # level deeper, inside the `request_approval` payload.
        context = payload.get("context")
        if not isinstance(context, dict):
            nested = payload.get("result")
            if isinstance(nested, dict):
                context = nested.get("context")
        if isinstance(context, dict):
            self._contexts[run_id] = _context_from_dict(run_id, context)

        decisions = [
            decision
            for decision in (
                _decision_from_dict(entry) for entry in payload.get("decisions") or []
            )
            if decision is not None
        ]
        if decisions:
            self._decisions[run_id] = decisions

        logger.info(
            "HITL run '%s' rehydrated from the database (state=%s)",
            run_id, state.value,
        )
        return True

    def _persist_hitl_state_to_db(
        self,
        run_id: str,
        state: str,
        data: Dict[str, Any],
    ) -> None:
        """
        Persist HITL state to database.

        Uses a lightweight upsert into the ``hitl_states`` table -- the one
        record that lets a *different* worker process answer for this run.

        THE DEFECT THIS REPLACES
        ------------------------
        This method used to hunt for an event loop through three strategies,
        and at the one moment that matters -- when the run pauses -- all three
        missed:

        * ``asyncio.get_running_loop()`` raises, because the workflow is
          executed through ``await asyncio.to_thread(...)`` in ``routes.py`` and
          driven by the synchronous ``compiled_graph.invoke(...)``. The HITL node
          therefore calls ``request_approval`` from a worker thread with no loop.
        * ``self._main_loop`` was always ``None``: ``HITLDBManager()`` is
          constructed at import time in ``apps/workflow/container.py``, before
          uvicorn's loop exists, so the capture in ``_init_db_persistence``
          raised and left it unset.
        * ``asyncio.get_event_loop()`` raises ``RuntimeError`` in a non-main
          thread on Python 3.11.

        At *decide* time it worked, because ``/hitl/decide`` is an async route on
        the main loop and the first strategy succeeded. That asymmetry is the
        whole bug: ``hitl_states`` was written when a run was approved and never
        when it paused. A reviewer whose POST landed on another worker -- or on
        the same worker after a restart -- hit a manager that had no record of
        the run, ``_validate_state`` raised, and the route answered **400**. And
        because the stale ``approved`` row was never overwritten by the next
        pause, an ``edit`` loop or a second HITL node returned 400 every time,
        on every worker.

        THE FIX
        -------
        ``echolib.database.run_db_coro_sync`` is the platform's existing bridge
        for exactly this, and the main loop it needs is already registered at
        startup (``apps/gateway/main.py`` calls ``set_main_event_loop``). It
        schedules onto that loop from a worker thread and waits, so the row is
        committed *before* ``request_approval`` returns and long before the
        reviewer can act on the pause.

        Writing this row is no longer best-effort. It is the record that makes a
        paused run decidable from any worker, so a failure to write it is logged
        at ERROR -- the file write still happens, and remains the fallback, but a
        run that reaches this state is one restart away from being stuck.

        Args:
            run_id: Execution run ID.
            state: Current HITL state string.
            data: Full state data to persist.
        """
        try:
            import asyncio
            from echolib.database import get_db_session, run_db_coro_sync
            from sqlalchemy import text
            from datetime import datetime as dt, timezone

            record = {
                "run_id": run_id,
                "state": state,
                "data": json.dumps(
                    self._durable_snapshot(run_id, state, data), default=str
                ),
                "updated_at": dt.now(timezone.utc),
            }

            async def _persist():
                async with get_db_session() as db:
                    # ``WHERE hitl_states.updated_at <= EXCLUDED.updated_at``
                    # is the ordering guarantee.
                    #
                    # Three writes used to contend for this one row on a single
                    # decision -- the route's, the replay's, and the node's --
                    # scheduled independently and committing in whatever order
                    # the loop got to them. A stale one landing last left a
                    # paused run recorded as ``approved``, and since
                    # ``ensure_loaded_async`` treats the row as authoritative,
                    # every later decision on that run answered 400.
                    #
                    # The replay is gone (see ``request_approval``) and the
                    # route now flushes before dispatching the resume, so the
                    # contention should not arise. This makes it impossible
                    # rather than unlikely: an older write simply does not
                    # apply.
                    await db.execute(
                        text(
                            "INSERT INTO hitl_states (run_id, state, data, updated_at) "
                            "VALUES (:run_id, :state, :data, :updated_at) "
                            "ON CONFLICT (run_id) DO UPDATE SET "
                            "state = EXCLUDED.state, "
                            "data = EXCLUDED.data, "
                            "updated_at = EXCLUDED.updated_at "
                            "WHERE hitl_states.updated_at IS NULL "
                            "   OR hitl_states.updated_at <= EXCLUDED.updated_at"
                        ),
                        record,
                    )
                    await db.commit()

            # Already on the loop -- an async route deciding a checkpoint. A
            # task is correct here and ``run_db_coro_sync`` would refuse, since
            # blocking the loop it needs is a deadlock it detects rather than
            # hangs on.
            #
            # The task is retained on ``_pending_writes`` so the route can wait
            # for it before dispatching the resume. Dispatching first meant the
            # graph could re-enter the HITL node while this row still said
            # ``waiting_for_human``.
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                pass
            else:
                self._pending_writes[run_id] = track_task(
                    loop.create_task(_persist()),
                    f"HITL state write for run '{run_id}' ({state})",
                )
                return

            # A worker thread -- the workflow pausing. Scheduled onto the main
            # loop and awaited, so the row exists before the pause is visible.
            run_db_coro_sync(_persist, timeout=30.0)

        except Exception as e:
            # The file write in the parent class still happened, so a decision
            # on this same container still works. What is lost is the ability
            # for any *other* worker -- or this one after a restart -- to answer
            # for the run, which is why this is an error and not a warning.
            logger.error(
                "HITLDBManager: could not record run '%s' as '%s' in hitl_states: %s. "
                "File-based state is still active, but a decision served by another "
                "worker will not find this run.",
                run_id, state, e, exc_info=True,
            )
