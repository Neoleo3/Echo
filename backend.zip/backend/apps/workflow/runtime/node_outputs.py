"""
The shared accumulator every workflow node contributes its result to.

WHAT: The ``all_node_outputs`` state reducer, the entry shape nodes write, and
      the deterministic rendering the fan-in reads.
WHY:  LangGraph requires a reducer on any state key that more than one node
      writes in a superstep. Without one the last write silently wins, which is
      how a parallel branch loses every output but one -- no error is raised,
      because the previous ``_last_writer_wins`` reducer accepted concurrent
      writes and simply kept the newest.

Lives in ``runtime`` rather than beside the compiler because both the compiler
(which declares the state field and the merge node) and the adapter (whose
agent nodes write to it) need it, and ``designer -> runtime`` is the direction
this package already imports in. Putting it in the compiler would invert that
and make the runtime adapter depend on the designer.

**The entry shape is the one API, MCP and Code nodes already write** --
``{node_id, node_name, node_type, data, success}``. Phase 8 adds ``seq`` and
leaves the rest alone, so no existing writer changes.

**Why not ``operator.add``.** The obvious reducer for an accumulating list is
not idempotent, and this graph re-runs nodes deliberately:

* the HITL edit action routes back to the preceding agent
  (``_hitl_route`` / ``_add_hitl_conditional_edges``), and
* ``ModelRetryMiddleware`` re-invokes a model call on a retryable failure.

With plain append, an edited agent would appear twice at the fan-in and be
summarised twice. Keying by ``node_id`` makes a re-run replace its own entry.

**Why entries carry ``seq``.** A reducer guarantees that concurrent writes are
merged, never the order they merge in. Deterministic output therefore has to
come from a value on the entry, sorted at the sink -- not from arrival order.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

# Node kinds that contribute to the accumulator.
TYPE_AGENT = "agent"
TYPE_API = "api"
TYPE_MCP = "mcp"
TYPE_CODE = "code"
TYPE_REVIEW = "review"
TYPE_HITL = "hitl"


def merge_node_outputs(
    existing: Optional[List[Dict[str, Any]]],
    new: Optional[List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    """
    Accumulate node outputs across parallel branches, keyed by node.

    WHAT: Merges the ``all_node_outputs`` writes of concurrently-executing
          nodes into one list, replacing any earlier entry from the same node.
    WHY:  See the module docstring -- ``operator.add`` would double-count a
          retried or HITL-edited node.
    INPUT: The accumulated list and the incoming write. Either may be ``None``.
    OUTPUT: A new list. Neither input is mutated.

    Entries without a usable ``node_id`` are appended rather than dropped: an
    unrecognised shape is still a result, and discarding it here would be the
    exact failure this reducer exists to prevent.
    """
    merged: List[Dict[str, Any]] = list(existing or [])

    for entry in (new or []):
        if not isinstance(entry, dict):
            merged.append(entry)
            continue

        node_id = entry.get("node_id")
        if not node_id:
            merged.append(entry)
            continue

        for index, current in enumerate(merged):
            if isinstance(current, dict) and current.get("node_id") == node_id:
                # Same node again: a retry, or the HITL edit loop routing back.
                # The later result supersedes the earlier one, and the original
                # position is kept so ordering does not shift under a retry.
                merged[index] = entry
                break
        else:
            merged.append(entry)

    return merged


def node_output_entry(
    node_id: str,
    data: Any,
    *,
    node_type: str = TYPE_AGENT,
    node_name: str = "",
    seq: Optional[int] = None,
    success: bool = True,
) -> Dict[str, Any]:
    """
    Build one ``all_node_outputs`` entry.

    Deliberately the shape API, MCP and Code nodes have always written, so
    those six call sites are untouched and the merge node reads one format.
    ``seq`` is the only addition: it is what the sink sorts on, because a
    reducer guarantees merging but never ordering.

    Args:
        node_id: The graph node's id. This is the merge key.
        data: Whatever the node produced.
        node_type: Which kind of node wrote it, for the rendered heading.
        node_name: Display name; falls back to ``node_id``.
        seq: Ordering hint, sorted on at the sink.
        success: False when the entry records a failure rather than a result.
    """
    return {
        "node_id": node_id,
        "node_name": node_name or node_id,
        "node_type": node_type,
        "data": data,
        "success": bool(success),
        "seq": seq if seq is not None else 0,
    }


def ordered_outputs(entries: Optional[Sequence[Any]]) -> List[Dict[str, Any]]:
    """
    Return the usable accumulated entries in deterministic order.

    Sorted by ``seq`` then name, never by arrival. Entries carrying no ``data``
    are dropped -- a node that produced nothing has nothing to hand downstream.
    """
    if not entries or not isinstance(entries, (list, tuple)):
        return []

    usable = [
        entry for entry in entries
        if isinstance(entry, dict) and entry.get("data") is not None
    ]
    usable.sort(
        key=lambda e: (
            e.get("seq", 0),
            str(e.get("node_name") or e.get("node_id") or ""),
        )
    )
    return usable


def _as_text(value: Any) -> str:
    """Render one node's payload, keeping structure readable for a model."""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(value)


def _section_head(entry: Dict[str, Any]) -> str:
    """The heading one node contributes. One definition, two readers."""
    return "=== Output from {name} ({kind}) ===\n".format(
        name=entry.get("node_name") or entry.get("node_id"),
        kind=entry.get("node_type", "unknown"),
    )


_SECTION_SEPARATOR = "\n\n"


def render_within_budget(
    entries: Optional[Sequence[Any]],
    limit: int,
) -> str:
    """
    Render accumulated outputs so that **every** contributing node survives.

    WHAT: Splits the character budget across the contributing nodes and trims
          each one that exceeds its share, instead of cutting the rendered text
          at a single offset.
    WHY:  Head truncation kept whichever nodes happened to render first and
          discarded the rest entirely. Because ``ordered_outputs`` sorts by
          ``seq``, "first" meant *earliest*, so a fifteen-agent workflow handed
          its final agent the opening two agents in full and none of the
          thirteen that refined them -- measured in production at 363,633
          characters cut to 120,000, with two thirds of the run's work
          discarded. The agent then correctly reported that its inputs were
          incomplete and refused to produce a report.

          Every node keeping a share is strictly better for the reader: a
          summary of fifteen results answers "what did the review find" in a
          way that two complete results and thirteen absences cannot.
    INPUT: The accumulated entries and a character ceiling.
    OUTPUT: Sectioned text within the ceiling. Never raises.

    Nodes under their share are rendered whole, and the space they leave is
    redistributed to the nodes that need it -- so one large result is trimmed
    while five small ones stay complete. Each trimmed section says so inline,
    which is what lets a model tell "this section was shortened" apart from
    "this section said nothing".
    """
    usable = ordered_outputs(entries)
    if not usable:
        return ""
    if limit <= 0:
        return render_outputs(usable)

    rendered = [
        (
            "=== Output from {name} ({kind}) ===\n".format(
                name=entry.get("node_name") or entry.get("node_id"),
                kind=entry.get("node_type", "unknown"),
            ),
            _as_text(entry.get("data")),
        )
        for entry in usable
    ]

    separator = len("\n\n") * max(0, len(rendered) - 1)
    # The closing notice is reserved up front rather than appended afterwards.
    # Adding it after the split overran the ceiling by its own length, which is
    # the one thing a budget must never do.
    reserve = len(TRIM_NOTICE) + len("\n\n")
    body_budget = max(
        0, limit - separator - reserve - sum(len(h) for h, _ in rendered)
    )

    # The most recent contributor is protected from trimming outright.
    #
    # THIS IS THE FIX FOR A CLAIM THE CODE DID NOT HONOUR. ``TRIM_NOTICE`` told
    # the model "the most recent, most consolidated results are complete" while
    # the weighting still trimmed that node: measured in production at 13 nodes,
    # 425,831 characters against a 253,112 budget, the last node received 31,152
    # characters against an average node of 32,756 -- so the consolidator's
    # authoritative decision JSON was cut mid-structure.
    #
    # A reasoning model checks that claim, finds the JSON truncated, and stops
    # trusting the whole context. Its refusal named exactly that: "No
    # authoritative Final Decision and Report Specification JSON was supplied"
    # and "the consolidated register is abbreviated in the context". The
    # platform was lying to the model, and the model caught it.
    #
    # In a pipeline the last node has already read and reconciled everything
    # before it -- it IS the summary. Delivering it whole and abbreviating the
    # raw analysis beneath it is both more useful and, unlike the previous
    # arrangement, something that can be stated truthfully.
    protected: List[int] = []
    protected_chars = 0
    if len(rendered) > 1:
        ceiling = int(body_budget * PROTECTED_TAIL_SHARE)
        for index in range(len(rendered) - 1, -1, -1):
            length = len(rendered[index][1])
            if protected_chars + length > ceiling:
                break
            protected.append(index)
            protected_chars += length
            if len(protected) >= MAX_PROTECTED_TAIL_NODES:
                break

    remaining_budget = max(0, body_budget - protected_chars)
    trimmable = [i for i in range(len(rendered)) if i not in protected]

    # Recency-weighted shares.
    #
    # An equal split is the wrong division for a pipeline. Later nodes have
    # already read, reconciled and corrected the earlier ones -- a consolidator's
    # master register is the distilled form of everything upstream of it, so a
    # character of the last node is worth more than a character of the first.
    # Splitting evenly across fourteen analysts trimmed that register as hard as
    # the raw analysis it superseded, which is what left the report writer
    # without the one artifact it actually needed.
    #
    # Weight is by position only, never by node name or type, so this holds for
    # any workflow: an ARB review, a research pipeline, a data run.
    # Shares are computed over the TRIMMABLE nodes only; the protected tail has
    # already been paid for out of the budget above.
    weights = _recency_weights(len(rendered))
    trim_weight = sum(weights[i] for i in trimmable) or 1.0
    shares = [0] * len(rendered)
    for i in trimmable:
        shares[i] = max(0, int(remaining_budget * weights[i] / trim_weight))

    # Nodes under their share release the remainder to the nodes that are over,
    # so a short early summary funds the longest remaining one rather than
    # capping it. Two passes, because the surplus is only known once every node
    # has been measured against its own share.
    spare = sum(max(0, shares[i] - len(rendered[i][1])) for i in trimmable)
    over = [i for i in trimmable if len(rendered[i][1]) > shares[i]]
    bonus = (spare // len(over)) if over else 0

    sections: List[str] = []
    trimmed = 0
    for index, (head, body) in enumerate(rendered):
        if index in protected:
            # Delivered whole. This is what makes the closing notice truthful.
            sections.append(head + body)
            continue
        share = shares[index]
        allowance = share + (bonus if len(body) > share else 0)
        if len(body) <= allowance:
            sections.append(head + body)
            continue
        # No per-section warning. The wording used to be "this section was
        # shortened from N characters", repeated once per trimmed node -- and a
        # report agent under instructions never to invent findings read fourteen
        # of those as fourteen statements that its inputs were unreliable, then
        # correctly refused to produce anything. The marker was a caution token,
        # and it was the immediate cause of the refusal. What survives is stated
        # once, factually, by the caller.
        trimmed += 1
        sections.append(head + body[:allowance].rstrip())

    if trimmed:
        sections.append(TRIM_NOTICE)

    return "\n\n".join(sections)


# Stated once at the end, and deliberately phrased as an instruction rather than
# a warning. The agent must know its view is partial -- silently handing it a cut
# register would be worse -- but "some detail was omitted" invites a refusal
# where "work with what is here and say what is missing" invites an answer. The
# research on over-refusal is explicit that truncated-but-sufficient context
# should be treated as conditional, never as grounds to decline.
TRIM_NOTICE = (
    "=== Note on the context above ===\n"
    "Every contributing step is present. The most recent and most consolidated "
    "results -- including any final register, decision or specification -- are "
    "delivered COMPLETE and unabridged; only the older raw analysis they were "
    "derived from has been shortened. Treat the most recent results as "
    "authoritative and sufficient for the task. Produce the full deliverable "
    "and call whatever tools are required to produce it. If a specific detail "
    "is genuinely absent, record that inline in the deliverable rather than "
    "declining to produce one."
)
"""Stated once, and every sentence of it is now true.

The previous wording opened with "The longest sections were abbreviated to fit"
and then claimed the most recent results were complete -- while the weighting
still trimmed them. A reasoning model verified that claim, found the
consolidator's decision JSON cut mid-structure, and refused, quoting the word
back: "the consolidated register is abbreviated in the context". A promise the
allocation does not keep is worse than no promise at all, because it teaches the
model that nothing in its context can be relied on."""


def _recency_weights(count: int) -> List[float]:
    """
    Per-node share weights, rising toward the most recent node.

    A linear ramp from 1.0 to :data:`RECENCY_WEIGHT_MAX`. Linear rather than
    exponential on purpose: an exponential curve starves the early nodes to
    almost nothing, and an early analyst's findings are the evidence the later
    consolidation *cites*. The goal is to favour the consolidated view, not to
    erase the detail beneath it.
    """
    if count <= 1:
        return [1.0] * max(0, count)
    step = (RECENCY_WEIGHT_MAX - 1.0) / (count - 1)
    return [1.0 + step * i for i in range(count)]


RECENCY_WEIGHT_MAX = 4.0
"""Share multiplier of the newest trimmable node against the oldest."""

PROTECTED_TAIL_SHARE = 0.45
"""Share of the budget reserved to deliver the most recent nodes untouched.

Bounded so a single runaway node cannot consume the whole allowance and erase
the analysis it was derived from."""

MAX_PROTECTED_TAIL_NODES = 2
"""How many of the most recent nodes may be delivered whole.

Two rather than one because a consolidation step is often followed by a
decision or approval step, and the writer needs both intact."""
"""Share multiplier of the newest contributing node against the oldest."""


def render_outputs(
    entries: Optional[Sequence[Any]],
    *,
    limit: Optional[int] = None,
) -> str:
    """
    Render accumulated outputs as sectioned text for a downstream consumer.

    One heading per contributing node so the reader can tell which result came
    from where. A bare concatenation is close to useless to a model asked to
    reconcile two branches.
    """
    usable = ordered_outputs(entries)
    if not usable:
        return ""

    sections = [
        "=== Output from {name} ({kind}) ===\n{body}".format(
            name=entry.get("node_name") or entry.get("node_id"),
            kind=entry.get("node_type", "unknown"),
            body=_as_text(entry.get("data")),
        )
        for entry in usable
    ]
    rendered = "\n\n".join(sections)

    if limit and len(rendered) > limit:
        rendered = (
            rendered[:limit].rstrip()
            + f"\n… upstream context truncated at {limit} characters."
        )

    return rendered


__all__ = [
    "TYPE_AGENT",
    "TYPE_API",
    "TYPE_CODE",
    "TYPE_HITL",
    "TYPE_MCP",
    "TYPE_REVIEW",
    "merge_node_outputs",
    "render_within_budget",
    "protected_tail_count",
    "node_output_entry",
    "ordered_outputs",
    "render_outputs",
]


def protected_tail_count(entries: Optional[Sequence[Any]], limit: int) -> int:
    """
    How many of the most recent nodes will be delivered whole at this budget.

    Mirrors the reservation in :func:`render_within_budget` so logging can state
    the fact rather than restate the intent. Returns 0 when nothing is trimmed,
    because then every node is complete and the distinction is meaningless.
    """
    usable = ordered_outputs(entries)
    if len(usable) < 2 or limit <= 0:
        return 0

    rendered = [
        (
            _section_head(e),
            _as_text(e.get("data")),
        )
        for e in usable
    ]
    separator = len(_SECTION_SEPARATOR) * max(0, len(rendered) - 1)
    reserve = len(TRIM_NOTICE) + len(_SECTION_SEPARATOR)
    body_budget = max(0, limit - separator - reserve - sum(len(h) for h, _ in rendered))

    ceiling = int(body_budget * PROTECTED_TAIL_SHARE)
    count = used = 0
    for index in range(len(rendered) - 1, -1, -1):
        length = len(rendered[index][1])
        if used + length > ceiling:
            break
        used += length
        count += 1
        if count >= MAX_PROTECTED_TAIL_NODES:
            break
    return count
