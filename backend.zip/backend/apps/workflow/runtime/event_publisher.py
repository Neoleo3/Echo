"""
Event Publisher for Execution Transparency

Creates and broadcasts execution events via WebSocket.
All functions are async and designed for fire-and-forget usage.

CRITICAL: Node functions in LangGraph are synchronous but run inside an async context.
Use fire_and_forget() to properly schedule async events from sync code.
"""

from datetime import datetime
from typing import Dict, Any, Optional
from .transparency import StepType, EventType, ExecutionEvent
from .ws_manager import ws_manager
import asyncio
import re
import logging

logger = logging.getLogger(__name__)


def _strip_internal_blocks(text: str) -> str:
    """
    Remove intermediate ``INTERNAL`` prefixed blocks and standalone
    JSON blobs from output text.

    Multi-task agent runs produce intermediate outputs prefixed with
    ``INTERNAL`` (e.g., extraction results, risk assessments) that are
    meant for inter-agent communication, not end-user display.

    Strategy:
      1. Use regex to remove ``INTERNAL``-prefixed sections that may
         span multiple lines (including multi-line JSON bodies).
      2. Remove standalone top-level JSON objects that appear between
         or alongside INTERNAL blocks.
      3. Clean up leftover separators and excessive blank lines.
      4. If nothing user-facing remains, return the last INTERNAL
         block with the prefix stripped.

    Args:
        text: Raw output text potentially containing INTERNAL blocks.

    Returns:
        Cleaned text with only user-facing content.
    """
    if not text or "INTERNAL" not in text:
        return text

    # Phase 1: Remove INTERNAL-prefixed sections (may contain multi-line JSON).
    # Matches both INTERNAL and __INTERNAL__ variants.
    cleaned = re.sub(
        r'(?:^|\n)_*INTERNAL_*.*?(?=\n_*INTERNAL_*|\n-{3,}\s*\n|\Z)',
        '',
        text,
        flags=re.DOTALL,
    )

    # Phase 2: Remove standalone top-level JSON objects between blocks.
    cleaned = re.sub(
        r'(?:^|\n\s*\n)\s*\{[\s\S]*?\}\s*(?=\n\s*\n|\Z)',
        '',
        cleaned,
        flags=re.DOTALL,
    )

    # Phase 3: Clean up separators and excessive blank lines.
    cleaned = re.sub(r'\n-{3,}\s*\n', '\n\n', cleaned)
    cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
    cleaned = cleaned.strip()

    if cleaned:
        return cleaned

    # Edge case: everything removed — return last INTERNAL block content.
    last_match = None
    for m in re.finditer(
        r'_*INTERNAL_*\s*(.*?)(?=\n_*INTERNAL_*|\Z)', text, re.DOTALL
    ):
        last_match = m
    if last_match:
        return last_match.group(1).strip()

    return text


def fire_and_forget(coro):
    """
    Schedule a coroutine for fire-and-forget execution.
    Works from both sync and async contexts.
    Non-blocking - does not wait for result.

    CRITICAL: When called from sync code inside an async context (common in LangGraph),
    we must use run_coroutine_threadsafe to properly schedule the task.

    Usage:
        fire_and_forget(publish_step_started(run_id, step_id, ...))
    """
    try:
        # First, try to get the running loop (only works from async context)
        try:
            loop = asyncio.get_running_loop()
            # We're in an async context - create_task works directly
            loop.create_task(coro)
            logger.debug("Event scheduled via create_task (async context)")
            return
        except RuntimeError:
            # No running loop in current coroutine context - we're in sync code
            pass

        # We're in sync code - try to get the event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            logger.warning("No event loop available for transparency event")
            return

        if loop.is_running():
            # Loop is running (in another call frame) but we're in sync code
            # Use run_coroutine_threadsafe which is designed for this exact case
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            # Don't wait for result - fire and forget
            logger.debug("Event scheduled via run_coroutine_threadsafe (sync context)")
        else:
            # Loop exists but not running - run synchronously
            loop.run_until_complete(coro)
            logger.debug("Event executed via run_until_complete")
    except Exception as e:
        # Log but don't fail - transparency is optional enhancement
        logger.warning(f"Failed to schedule transparency event: {e}")


async def publish_run_started(run_id: str, workflow_id: str) -> None:
    """
    Publish run_started event.

    Args:
        run_id: Run identifier
        workflow_id: Workflow being executed
    """
    event = ExecutionEvent(
        event_type=EventType.RUN_STARTED,
        run_id=run_id,
        step_id=None,
        timestamp=datetime.utcnow().isoformat(),
        payload={"workflow_id": workflow_id}
    )
    await ws_manager.broadcast(run_id, event)
    logger.debug(f"Published run_started for {run_id}")


async def publish_step_started(
    run_id: str,
    step_id: str,
    step_name: str,
    step_type: StepType,
    input_summary: Optional[Dict[str, Any]] = None
) -> None:
    """
    Publish step_started event.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        step_name: Human-readable step name
        step_type: Type of step
        input_summary: Sanitized input data (no CoT)
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_STARTED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={
            "step_name": step_name,
            "step_type": step_type.value,
            "input_summary": input_summary or {}
        }
    )
    await ws_manager.broadcast(run_id, event)
    logger.debug(f"Published step_started for {step_id}")


async def publish_step_output(
    run_id: str,
    step_id: str,
    intermediate_output: Dict[str, Any]
) -> None:
    """
    Publish step_output event for intermediate results.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        intermediate_output: Partial output data
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_OUTPUT,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={"intermediate_output": intermediate_output}
    )
    await ws_manager.broadcast(run_id, event)
    logger.debug(f"Published step_output for {step_id}")


async def publish_step_completed(
    run_id: str,
    step_id: str,
    output_summary: Optional[Dict[str, Any]] = None
) -> None:
    """
    Publish step_completed event.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        output_summary: Sanitized output data (no CoT)
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_COMPLETED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={"output_summary": output_summary or {}}
    )
    await ws_manager.broadcast(run_id, event)
    logger.debug(f"Published step_completed for {step_id}")


async def publish_step_failed(
    run_id: str,
    step_id: str,
    error: str
) -> None:
    """
    Publish step_failed event.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        error: Error message
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_FAILED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={"error": error}
    )
    await ws_manager.broadcast(run_id, event)
    logger.debug(f"Published step_failed for {step_id}")


# Fallback ceiling on a single WebSocket payload, used when ``echolib.config``
# cannot be read. The live value is ``settings.workflow_response_payload_limit``.
#
# A response above it is truncated rather than dropped, so a very large run
# still delivers a readable answer. Presentation only: this bounds one payload,
# never what an agent may produce or write to a generated file.
RESPONSE_PAYLOAD_LIMIT = 50000


def _response_payload_limit() -> int:
    """The configured ceiling on one streamed response, in characters."""
    try:
        from echolib.config import settings

        value = int(
            getattr(settings, "workflow_response_payload_limit", RESPONSE_PAYLOAD_LIMIT)
        )
    except Exception:  # noqa: BLE001 -- tuning must never fail a publish
        return RESPONSE_PAYLOAD_LIMIT
    return value if value > 0 else RESPONSE_PAYLOAD_LIMIT

# Output channels a compiled graph may write, in the order they are trusted.
#
# ``crew_result`` is first because it is the agent node's primary output key.
# The framework it was named after was removed in Phase 9; the key was kept
# deliberately because the canvas reads ``snapshot.crew_result``
# (``compiler.py:877-881``), so it remains the channel that actually carries a
# run's answer.
RESPONSE_KEYS = (
    "crew_result",
    "result",
    "final_output",
    "hierarchical_output",
    "parallel_output",
    "message",
    "last_node_output",
)

# Values that are present but say nothing. Treated as absent so the cascade
# continues instead of settling on a placeholder.
_EMPTY_TOKENS = {"", "null", "none", "{}", "[]"}


def meaningful_text(value: Any) -> str:
    """
    The user-facing text inside a value, or ``""`` when it holds none.

    Recurses through dicts and lists because a node's output is frequently
    wrapped -- a dict whose ``content`` holds the answer, or a message list
    whose last entry does. A present-but-empty value is not an answer, so
    ``"null"``, ``"{}"`` and friends resolve to ``""`` and let the caller
    keep looking.
    """
    if value is None:
        return ""

    if isinstance(value, str):
        text = value.strip()
        return "" if text.lower() in _EMPTY_TOKENS else text

    if isinstance(value, dict):
        for key in ("final_output", *RESPONSE_KEYS, "output", "content", "text"):
            nested = meaningful_text(value.get(key))
            if nested:
                return nested
        return ""

    if isinstance(value, list):
        for item in reversed(value):
            nested = meaningful_text(item)
            if nested:
                return nested
        return ""

    text = str(value).strip()
    return text if text else ""


def extract_final_response(
    final_state: Optional[Dict[str, Any]],
) -> "tuple[str, str]":
    """
    The user-facing answer carried by a finished workflow's state.

    WHAT: Walks :data:`RESPONSE_KEYS` for the first channel holding real text,
          strips inter-agent ``INTERNAL`` blocks, and bounds the result.
    WHY:  ``run_completed`` is emitted from two places -- here, after ``routes``
          has the result, and from the executor the moment
          ``compiled_graph.invoke`` returns. The executor's copy carried only
          ``{"status", "workflow_id"}``, so the first event to reach the browser
          had no answer in it. ``useExecutionStream`` settles on the first
          ``run_completed`` it sees and ``useWorkflowChat.settle`` clears the
          pending row, so the correct event arriving milliseconds later was
          discarded and the turn rendered "the workflow finished without
          producing any output" over a run that had produced thousands of
          characters.

          There were three copies of this cascade -- here, in ``routes`` and in
          the executor's own result handling -- and they had already drifted:
          this module's tested ``"result" in output`` rather than whether the
          value said anything, so a present-but-empty ``result`` ended the
          search and returned nothing. One extractor, three callers, no drift.

    INPUT: A workflow's final state, or None.
    OUTPUT: ``(text, source)``. ``source`` names the channel the answer came
            from, or ``"none"``. Empty text is returned as empty -- deciding
            what to say instead belongs to the caller, which is the only layer
            that knows whether it is addressing a user or a socket.
    """
    output = final_state or {}
    if not isinstance(output, dict):
        return "", "none"

    final_response = ""
    source = "none"

    for key in RESPONSE_KEYS:
        candidate = meaningful_text(output.get(key))
        if candidate:
            final_response, source = candidate, key
            break

    if not final_response:
        candidate = meaningful_text(output.get("messages"))
        if candidate:
            final_response, source = candidate, "messages"

    if not final_response:
        return "", "none"

    # Filter out INTERNAL prefixed blocks from intermediate task outputs.
    # These are intermediate results (data extraction, risk scores, etc.) that
    # are meant for inter-agent communication, not end-user display.
    final_response = _strip_internal_blocks(final_response)

    # Truncate only extremely large responses (WebSocket payload limit)
    payload_limit = _response_payload_limit()
    if len(final_response) > payload_limit:
        final_response = (
            final_response[:payload_limit]
            + "\n\n[Response truncated due to size limit]"
        )

    return final_response, source


async def publish_run_completed(
    run_id: str,
    final_state: Dict[str, Any]
) -> None:
    """
    Publish run_completed event with final response.

    Extracts the final response from the workflow output state
    using the same logic as routes.py.

    Args:
        run_id: Run identifier
        final_state: Final workflow state dictionary
    """
    # CRITICAL: Flush all buffered events to clients BEFORE sending run_completed
    # This ensures step events (buffered from sync code) are delivered first
    await ws_manager.flush_to_clients(run_id)

    # Check if this is a HITL interrupt — pass through interrupt data directly
    if final_state.get("status") == "interrupted" and "interrupt" in final_state:
        event = ExecutionEvent(
            event_type=EventType.RUN_COMPLETED,
            run_id=run_id,
            step_id=None,
            timestamp=datetime.utcnow().isoformat(),
            payload={
                "status": "interrupted",
                "interrupt": final_state["interrupt"],
            }
        )
        await ws_manager.broadcast(run_id, event)
        # Do NOT clean up WebSocket — frontend needs it until decision is made
        return

    final_response, _source = extract_final_response(final_state)

    event = ExecutionEvent(
        event_type=EventType.RUN_COMPLETED,
        run_id=run_id,
        step_id=None,
        timestamp=datetime.utcnow().isoformat(),
        payload={
            "final_response": final_response,
            "status": "completed"
        }
    )
    await ws_manager.broadcast(run_id, event)

    # Clean up WebSocket connections for this run
    await ws_manager.async_cleanup_run(run_id)
    logger.debug(f"Published run_completed for {run_id}")


async def publish_run_failed(run_id: str, error: str) -> None:
    """
    Publish run_failed event.

    Args:
        run_id: Run identifier
        error: Error message
    """
    event = ExecutionEvent(
        event_type=EventType.RUN_FAILED,
        run_id=run_id,
        step_id=None,
        timestamp=datetime.utcnow().isoformat(),
        payload={
            "error": error,
            "status": "failed"
        }
    )
    await ws_manager.broadcast(run_id, event)

    # Clean up WebSocket connections for this run
    await ws_manager.async_cleanup_run(run_id)
    logger.debug(f"Published run_failed for {run_id}")


# ==============================================================================
# SYNCHRONOUS PUBLISH FUNCTIONS
# ==============================================================================
# Use these from synchronous code (LangGraph node functions)
# They buffer events immediately without async, ensuring correct event ordering.
# ==============================================================================

def publish_step_started_sync(
    run_id: str,
    step_id: str,
    step_name: str,
    step_type: StepType,
    input_summary: Optional[Dict[str, Any]] = None
) -> None:
    """
    Synchronously buffer step_started event.

    Use this from sync code (LangGraph node functions) to ensure events
    are buffered immediately in the correct order.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        step_name: Human-readable step name
        step_type: Type of step
        input_summary: Sanitized input data (no CoT)
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_STARTED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={
            "step_name": step_name,
            "step_type": step_type.value,
            "input_summary": input_summary or {}
        }
    )
    ws_manager.buffer_event_sync(run_id, event)
    logger.debug(f"Buffered step_started for {step_id}")


def publish_step_token_sync(
    run_id: str,
    step_id: str,
    text: str,
    seq: int,
    step_name: str = "",
) -> None:
    """
    Synchronously buffer a ``step_token`` event -- live model output.

    WHAT: One frame carrying a fragment of what the agent is currently writing.
    WHY:  The canvas could previously only show that a node had started and,
          much later, that it had finished. A multi-minute agent looked
          identical to a hung one. This is the channel that makes a workflow run
          legible while it runs, the way Copilot and ChatGPT show output as it
          is produced.

    Fragments, appended in ``seq`` order, not the running total: a cumulative
    payload would re-send the whole answer on every frame, and every event here
    is also retained in the replay buffer.

    Callers must coalesce before calling this -- see ``TokenCoalescer``. One
    frame per model token would flood both the socket and the buffer.

    Args:
        run_id: Run identifier.
        step_id: The step producing this output.
        text: The fragment to append.
        seq: Zero-based index of the fragment within this step.
        step_name: Human-readable step name, for readers that render a label.
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_TOKEN,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={"text": text, "seq": seq, "step_name": step_name},
    )
    ws_manager.buffer_event_sync(run_id, event)


def publish_step_completed_sync(
    run_id: str,
    step_id: str,
    output_summary: Optional[Dict[str, Any]] = None
) -> None:
    """
    Synchronously buffer step_completed event.

    Use this from sync code (LangGraph node functions) to ensure events
    are buffered immediately in the correct order.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        output_summary: Sanitized output data (should include output_preview)
    """
    # Extract output_preview for direct access in frontend
    output_preview = ""
    if output_summary:
        output_preview = output_summary.get("output_preview", "")
        # Truncate to 300 chars for WebSocket payload
        if len(output_preview) > 300:
            output_preview = output_preview[:300] + "..."

    event = ExecutionEvent(
        event_type=EventType.STEP_COMPLETED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={
            "output_summary": output_summary or {},
            "output_preview": output_preview  # Direct access for frontend
        }
    )
    ws_manager.buffer_event_sync(run_id, event)
    logger.debug(f"Buffered step_completed for {step_id} (preview: {len(output_preview)} chars)")


def publish_step_failed_sync(
    run_id: str,
    step_id: str,
    error: str
) -> None:
    """
    Synchronously buffer step_failed event.

    Use this from sync code (LangGraph node functions) to ensure events
    are buffered immediately in the correct order.

    Args:
        run_id: Run identifier
        step_id: Step identifier
        error: Error message
    """
    event = ExecutionEvent(
        event_type=EventType.STEP_FAILED,
        run_id=run_id,
        step_id=step_id,
        timestamp=datetime.utcnow().isoformat(),
        payload={"error": error}
    )
    ws_manager.buffer_event_sync(run_id, event)
    logger.debug(f"Buffered step_failed for {step_id}")
