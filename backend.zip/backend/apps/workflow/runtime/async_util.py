"""
Parallel-safe sync→async bridge for workflow nodes.

Workflow nodes are synchronous but some (MCP) must drive async I/O. Calling
``asyncio.run()`` inside a node breaks when a loop is already running and is
unsafe under the LangGraph parallel-DAG engine (concurrent nodes). It also
previously mutated the GLOBAL event-loop policy (Windows Proactor), which races
across parallel nodes and changes process-wide behaviour.

``run_coro_blocking`` instead runs each coroutine to completion in its OWN fresh
event loop on a dedicated thread — no running-loop collision, no global policy
mutation, safe when many nodes run concurrently.
"""

from __future__ import annotations

import asyncio
import sys
import threading
from typing import Any, Callable


def run_coro_blocking(coro_factory: Callable[[], Any], windows_proactor: bool = False, timeout: float = 300.0) -> Any:
    """Run an async coroutine from sync code, isolated per call.

    Args:
        coro_factory: zero-arg callable returning a FRESH coroutine. It is
            invoked inside the worker thread so the coroutine binds to that
            thread's loop (required for subprocess transports).
        windows_proactor: on Windows, use a Proactor loop for this call only
            (needed for subprocess STDIO, e.g. MCP stdio servers).
        timeout: max seconds to wait before raising TimeoutError.

    Returns the coroutine's result, or re-raises whatever it raised.
    """
    box: dict[str, Any] = {}

    def _runner() -> None:
        if sys.platform == "win32" and windows_proactor:
            loop = asyncio.ProactorEventLoop()
        else:
            loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)  # thread-local, not global policy
            box["result"] = loop.run_until_complete(coro_factory())
        except BaseException as e:  # surface real error (incl. ExceptionGroup)
            box["error"] = e
        finally:
            try:
                loop.close()
            except Exception:
                pass

    t = threading.Thread(target=_runner, daemon=True, name="mcp-coro")
    t.start()
    t.join(timeout)

    if t.is_alive():
        raise TimeoutError(f"Async node operation exceeded {timeout}s")
    if "error" in box:
        raise box["error"]
    if "result" not in box:
        raise RuntimeError("Async node operation produced no result")
    return box["result"]
