"""
HITL checkpoint persistence via LangGraph's PostgresSaver.

WHAT: Builds the durable checkpointer HITL-enabled workflows compile against,
      backed by a psycopg v3 connection pool.
WHY:  A paused workflow is state that outlives the request that created it. On
      an in-process ``MemorySaver`` that state dies with the worker and is
      invisible to every other replica, so a reviewer who opens the approval a
      minute later resumes nothing. Non-HITL workflows keep using MemorySaver;
      this module does not change that.

Connection handling follows the documented production pattern: a
``psycopg_pool.ConnectionPool`` with ``autocommit=True`` and
``row_factory=dict_row``, handed to ``PostgresSaver(pool)``.

    Why a pool and not ``from_conn_string``.  ``from_conn_string`` is a context
    manager that owns one connection and closes it on exit -- the graph has to
    run inside the ``with`` block. Echo compiles a graph in one request and
    resumes it in another, so there is no block to stay inside. The previous
    implementation worked around that by calling ``__enter__`` and pinning the
    context object onto the saver so the connection was never collected. That
    left one raw connection shared by four uvicorn workers and every thread
    inside them, with no recycling after a network drop. A pool is what that
    workaround was approximating.

    ``row_factory=dict_row`` is not optional: the saver reads rows as
    ``row["column"]``, and psycopg's default tuple factory raises ``TypeError``.

Connection string: echolib holds ``postgresql+asyncpg://...`` for SQLAlchemy;
psycopg needs the driver prefix removed and ``ssl=`` spelled ``sslmode=``.
"""
from __future__ import annotations

import logging
import os
import threading
from typing import Any, Optional
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

logger = logging.getLogger(__name__)

# The pool is process-wide: one HITL checkpointer serves every workflow, and
# LangGraph scopes state by thread_id rather than by connection.
_pool: Any = None
_checkpointer: Any = None
_lock = threading.Lock()

DEFAULT_MIN_SIZE = 1
DEFAULT_MAX_SIZE = 5


def get_hitl_checkpointer_uri() -> str:
    """
    Derive a psycopg-compatible URI from the configured SQLAlchemy database URL.

    WHAT: Strips the async driver prefix and normalises the TLS query parameter.
    WHY:  ``postgresql+asyncpg://`` is a SQLAlchemy dialect string, not a libpq
          one, and asyncpg spells the TLS option ``ssl`` where libpq -- and
          therefore psycopg -- spells it ``sslmode``. Passing the raw value
          through fails at connect time with an unhelpful error.
    OUTPUT: ``postgresql://user:pass@host:port/db?sslmode=require``
    """
    from echolib.config import settings

    url = settings.database_url or ""
    for driver in ("+asyncpg", "+psycopg2", "+psycopg"):
        url = url.replace(driver, "")

    split = urlsplit(url)
    if not split.query:
        return url

    params = [
        ("sslmode", value) if key == "ssl" else (key, value)
        for key, value in parse_qsl(split.query, keep_blank_values=True)
    ]
    return urlunsplit(split._replace(query=urlencode(params)))


def _build_pool() -> Any:
    """Open the psycopg connection pool the saver reads and writes through."""
    from psycopg.rows import dict_row
    from psycopg_pool import ConnectionPool

    max_size = int(os.getenv("HITL_CHECKPOINT_POOL_SIZE", str(DEFAULT_MAX_SIZE)))
    pool = ConnectionPool(
        conninfo=get_hitl_checkpointer_uri(),
        min_size=DEFAULT_MIN_SIZE,
        max_size=max(max_size, DEFAULT_MIN_SIZE),
        # Both are required by PostgresSaver, not preferences: it issues DDL and
        # DML outside an explicit transaction, and reads rows by column name.
        kwargs={"autocommit": True, "row_factory": dict_row},
        open=True,
    )
    return pool


def get_postgres_checkpointer() -> Any:
    """
    Return the process-wide ``PostgresSaver``, creating it on first use.

    WHAT: Opens the pool, constructs the saver, and runs the idempotent
          ``setup()`` that creates LangGraph's checkpoint tables.
    WHY:  A HITL workflow must compile against the *same* checkpointer on the
          initial run and on resume, or the interrupt state cannot be found.
    RAISES: Whatever psycopg or LangGraph raise when the driver is missing or
            the database is unreachable. The caller (``_get_checkpointer``)
            catches and degrades to a shared MemorySaver with a warning, so an
            unavailable database never takes a workflow down -- it only costs
            durability.
    """
    global _pool, _checkpointer

    if _checkpointer is not None:
        return _checkpointer

    with _lock:
        if _checkpointer is not None:
            return _checkpointer

        from langgraph.checkpoint.postgres import PostgresSaver

        _pool = _build_pool()
        checkpointer = PostgresSaver(_pool)
        # Idempotent: creates the checkpoint tables when they do not exist.
        checkpointer.setup()
        _checkpointer = checkpointer
        logger.info(
            "HITL PostgresSaver ready (pool max_size=%s)",
            getattr(_pool, "max_size", DEFAULT_MAX_SIZE),
        )
        return _checkpointer


def close_postgres_checkpointer() -> None:
    """
    Close the pool on shutdown.

    Idempotent and never raises: a failure to close during shutdown must not
    mask whatever else the process is doing.
    """
    global _pool, _checkpointer

    with _lock:
        pool, _pool, _checkpointer = _pool, None, None

    if pool is None:
        return
    try:
        pool.close()
        logger.info("HITL PostgresSaver pool closed")
    except Exception as exc:  # pragma: no cover - shutdown best effort
        logger.warning("Failed to close HITL checkpointer pool: %s", exc)


__all__ = [
    "close_postgres_checkpointer",
    "get_hitl_checkpointer_uri",
    "get_postgres_checkpointer",
]
