"""
Execution Transparency Module

Provides step-level visibility into workflow execution.
This module implements ephemeral in-memory tracking of execution steps
with WebSocket event emission for real-time visibility.

Key design principles:
- NO raw chain-of-thought exposure - only structured execution steps
- Ephemeral in-memory state (no persistent storage)
- 60-second cleanup after run completion
- Sanitized input/output summaries (truncated, no internal reasoning)
"""

from enum import Enum
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import asyncio
import logging
import json

logger = logging.getLogger(__name__)


class StepType(str, Enum):
    """Types of execution steps in a workflow."""
    AGENT = "agent"                          # Single agent execution
    TOOL_CALL = "tool_call"                  # Tool invocation
    LLM_CALL = "llm_call"                    # Direct LLM call
    TRANSFORM = "transform"                   # Data transformation
    COORDINATOR = "coordinator"               # Parallel/hybrid coordinator
    MERGE = "merge"                          # Parallel results merge
    # Deprecated. Nothing emits these: the CrewAI adapter that did was removed
    # in Phase 9, and parallel/hierarchical topologies are ordinary LangGraph
    # edges over AGENT steps. Kept because ``StepType(row.step_type)`` is used to
    # read stored rows, and dropping a value a historical row carries would make
    # that run unreadable -- the same reasoning that kept ``HITLAction.DEFER``.
    PARALLEL_CREW = "parallel_crew"
    HIERARCHICAL_CREW = "hierarchical_crew"


class StepStatus(str, Enum):
    """Status of an execution step."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class EventType(str, Enum):
    """Types of execution events emitted via WebSocket."""
    RUN_STARTED = "run_started"
    STEP_STARTED = "step_started"
    STEP_OUTPUT = "step_output"      # For intermediate results (optional)
    STEP_TOKEN = "step_token"        # Incremental model output while a step runs
    STEP_COMPLETED = "step_completed"
    STEP_FAILED = "step_failed"
    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"


@dataclass
class ExecutionStep:
    """
    Single step in workflow execution.

    Represents a discrete unit of work (agent, tool call, etc.)
    with sanitized input/output summaries for transparency.
    """
    step_id: str
    step_name: str
    step_type: StepType
    status: StepStatus = StepStatus.PENDING
    input_summary: Optional[Dict[str, Any]] = None
    output_summary: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert step to dictionary for JSON serialization."""
        return {
            "step_id": self.step_id,
            "step_name": self.step_name,
            "step_type": self.step_type.value,
            "status": self.status.value,
            "input_summary": self.input_summary,
            "output_summary": self.output_summary,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error": self.error,
            "metadata": self.metadata
        }


@dataclass
class RunContext:
    """
    In-memory execution context for a single workflow run.

    Tracks all steps, their order, and the final output.
    This is ephemeral - cleaned up 60 seconds after run completion.
    """
    run_id: str
    workflow_id: str
    steps: Dict[str, ExecutionStep] = field(default_factory=dict)
    step_order: List[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    final_output: Optional[str] = None


@dataclass
class ExecutionEvent:
    """
    WebSocket event payload.

    Represents an event to be broadcast to connected clients.
    """
    event_type: EventType
    run_id: str
    step_id: Optional[str]
    timestamp: str
    payload: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for JSON serialization."""
        return {
            "event": self.event_type.value,
            "run_id": self.run_id,
            "step_id": self.step_id,
            "timestamp": self.timestamp,
            "payload": self.payload
        }


class StepTracker:
    """
    Tracks step execution state in memory.

    Provides methods to:
    - Create and manage run contexts
    - Track step lifecycle (start, complete, fail)
    - Auto-cleanup after 60 seconds
    - Persist steps to database (Phase 2)
    """

    def __init__(self):
        self._runs: Dict[str, RunContext] = {}
        # Phase 2: Initialize database repository for persistence
        try:
            from echolib.repositories.execution_repo import ExecutionRunRepository
            self._execution_repo = ExecutionRunRepository()
        except Exception as e:
            logger.warning(f"Could not initialize ExecutionRunRepository: {e}")
            self._execution_repo = None

    def _save_step_sync(
        self,
        run_id: str,
        step_id: str,
        agent_name: str,
        step_type: str,
        input_summary: Optional[str] = None,
        output_summary: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Save step to database (sync bridge for transparency module).

        Args:
            run_id: Run identifier
            step_id: Step identifier
            agent_name: Name of agent/tool executing
            step_type: Type of step
            input_summary: Sanitized input
            output_summary: Sanitized output
            metadata: Structured step attribution (e.g. the resolved LLM
                credential and model). Credentials by reference only.
        """
        if not self._execution_repo:
            return

        try:
            from echolib.database import get_db_session, run_db_coro_sync

            async def _save():
                async with get_db_session() as db:
                    await self._execution_repo.save_step(
                        db=db,
                        run_id=run_id,
                        step_id=step_id,
                        agent_name=agent_name,
                        step_type=step_type,
                        input_summary=input_summary or "",
                        output_summary=output_summary or "",
                        metadata=metadata or None
                    )

            # Schedule on the app's main event loop instead of spinning up a new
            # loop per call. asyncpg pooled connections are bound to the loop that
            # created them, so asyncio.run() here caused "attached to a different
            # loop" / "Event loop is closed" errors.
            run_db_coro_sync(_save)
        except Exception as e:
            logger.debug(f"Failed to save step {step_id} to database: {e}")
            # Don't raise - in-memory tracking continues regardless

    def create_run(self, run_id: str, workflow_id: str) -> RunContext:
        """
        Create a new run context for tracking execution.

        Args:
            run_id: Unique run identifier
            workflow_id: ID of the workflow being executed

        Returns:
            New RunContext instance
        """
        context = RunContext(run_id=run_id, workflow_id=workflow_id)
        self._runs[run_id] = context
        logger.debug(f"Created run context for {run_id}")
        return context

    def get_run(self, run_id: str) -> Optional[RunContext]:
        """
        Get run context by ID from in-memory cache.

        Currently looks up from ephemeral in-memory cache only (60s TTL).
        Database fallback for expired runs will be added in Phase 2.

        Args:
            run_id: Run identifier

        Returns:
            RunContext if found in cache, None otherwise (or from DB in Phase 2)
        """
        return self._runs.get(run_id)

    def start_step(
        self,
        run_id: str,
        step_id: str,
        step_name: str,
        step_type: StepType,
        input_summary: Optional[Dict[str, Any]] = None
    ) -> ExecutionStep:
        """
        Start tracking a new step.

        Args:
            run_id: Run identifier
            step_id: Unique step identifier
            step_name: Human-readable step name
            step_type: Type of step (agent, tool_call, etc.)
            input_summary: Sanitized input data (no CoT)

        Returns:
            New ExecutionStep instance

        Raises:
            ValueError: If run context not found
        """
        context = self._runs.get(run_id)
        if not context:
            # Last-resort context so a step is never lost. Every caller that
            # supplies a run_id is expected to have registered it first --
            # ``routes.send_chat_message`` for the designer, and
            # ``SkillExecutor._register_run_context`` for an application. If
            # this fires, one of them did not, and the run will be attributed
            # to an unknown workflow for its whole lifetime rather than only
            # for this step.
            logger.warning(
                "Run %s was never registered with the step tracker; creating a "
                "context with an unknown workflow. Steps for this run will not "
                "be attributable to a workflow.",
                run_id,
            )
            context = self.create_run(run_id, "unknown")

        step = ExecutionStep(
            step_id=step_id,
            step_name=step_name,
            step_type=step_type,
            status=StepStatus.RUNNING,
            input_summary=input_summary,
            started_at=datetime.utcnow()
        )
        context.steps[step_id] = step
        # Only record the position the first time this step id is seen.
        #
        # ``steps`` is keyed and ``save_step`` upserts on (run_id, step_id), so
        # both were already idempotent -- but this list was appended to
        # unconditionally, and it is what ``routes.py`` builds the run's step
        # list from. A node that legitimately re-runs under the same step id
        # therefore appeared twice in the API response with an inflated
        # step_count, while the database held one row.
        #
        # HITL is where this shows: LangGraph restarts the whole node on
        # resume, so the checkpoint's start_step call runs again with the same
        # deterministic id.
        if step_id not in context.step_order:
            context.step_order.append(step_id)
        logger.debug(f"Started step {step_id} ({step_name}) in run {run_id}")
        
        # Phase 2: Persist step to database
        input_str = json.dumps(input_summary) if input_summary else ""
        self._save_step_sync(
            run_id=run_id,
            step_id=step_id,
            agent_name=step_name,
            step_type=step_type.value,
            input_summary=input_str
        )
        
        return step

    def complete_step(
        self,
        run_id: str,
        step_id: str,
        output_summary: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Mark a step as completed.

        Args:
            run_id: Run identifier
            step_id: Step identifier
            output_summary: Sanitized output data (no CoT)
            metadata: Structured step attribution merged onto the step's
                metadata, such as the LLM credential and model the agent
                actually resolved to. Recorded here rather than at step start
                because resolution only happens once the agent is built.
        """
        context = self._runs.get(run_id)
        if context and step_id in context.steps:
            step = context.steps[step_id]
            step.status = StepStatus.COMPLETED
            step.output_summary = output_summary
            step.completed_at = datetime.utcnow()
            if metadata:
                step.metadata = {**(step.metadata or {}), **metadata}
            logger.debug(f"Completed step {step_id} in run {run_id}")

            # Phase 2: Update step output in database
            output_str = json.dumps(output_summary) if output_summary else ""
            self._save_step_sync(
                run_id=run_id,
                step_id=step_id,
                agent_name=step.step_name,
                step_type=step.step_type.value,
                input_summary=json.dumps(step.input_summary) if step.input_summary else "",
                output_summary=output_str,
                metadata=step.metadata or None
            )

    def fail_step(self, run_id: str, step_id: str, error: str) -> None:
        """
        Mark a step as failed.

        Args:
            run_id: Run identifier
            step_id: Step identifier
            error: Error message
        """
        context = self._runs.get(run_id)
        if context and step_id in context.steps:
            step = context.steps[step_id]
            step.status = StepStatus.FAILED
            step.error = error
            step.completed_at = datetime.utcnow()
            logger.debug(f"Failed step {step_id} in run {run_id}: {error}")

    def complete_run(self, run_id: str, final_output: Optional[str] = None) -> None:
        """
        Mark run as completed and schedule cleanup.

        Args:
            run_id: Run identifier
            final_output: Final response text
        """
        context = self._runs.get(run_id)
        if context:
            context.completed_at = datetime.utcnow()
            context.final_output = final_output
            logger.debug(f"Completed run {run_id}")

        # Schedule cleanup after 60 seconds
        self._schedule_cleanup(run_id)

    def fail_run(self, run_id: str) -> None:
        """
        Mark run as failed and schedule cleanup.

        Args:
            run_id: Run identifier
        """
        context = self._runs.get(run_id)
        if context:
            context.completed_at = datetime.utcnow()
            logger.debug(f"Failed run {run_id}")

        # Schedule cleanup after 60 seconds
        self._schedule_cleanup(run_id)

    def _schedule_cleanup(self, run_id: str) -> None:
        """
        Schedule cleanup of run context after 60 seconds.

        Args:
            run_id: Run identifier to clean up
        """
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.call_later(60, lambda: self._cleanup(run_id))
            else:
                # Fallback: create task for cleanup
                asyncio.create_task(self._async_cleanup(run_id))
        except RuntimeError:
            # No event loop - cleanup immediately or skip
            logger.warning(f"No event loop for cleanup scheduling of run {run_id}")

    async def _async_cleanup(self, run_id: str) -> None:
        """Async cleanup after delay."""
        await asyncio.sleep(60)
        self._cleanup(run_id)

    def _cleanup(self, run_id: str) -> None:
        """
        Remove run context from memory.

        Args:
            run_id: Run identifier to remove
        """
        if run_id in self._runs:
            del self._runs[run_id]
            logger.debug(f"Cleaned up run context for {run_id}")


# Singleton instance for global access
step_tracker = StepTracker()
