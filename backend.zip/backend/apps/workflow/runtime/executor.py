"""
Workflow executor.
Executes workflows using LangGraph runtime.
"""
import re
import logging
from typing import Dict, Any, List, Optional
from echolib.utils import new_id
from echolib.config import settings
from echolib.id_utils import normalize_to_uuid
from echolib.repositories.workflow_repo import WorkflowRepository
from echolib.repositories.execution_repo import ExecutionRunRepository
from echolib.repositories.base import DEFAULT_USER_ID
from echolib.database import get_db_session, run_db_coro_sync
from echolib.type_resolver import TypeResolver
from apps.workflow.visualization.node_mapper import normalize_agent_config
from datetime import timezone
logger = logging.getLogger(__name__)

# The statuses a workflow may carry and still be run from the draft record,
# in either "draft" or "test" mode.
#
# "test" used to demand ``status == "validated"`` on the three DB-first paths
# below, while its own filesystem counterpart (``execute_workflow``, test
# branch) checked nothing at all. Nothing in the product ever persists
# "validated": ``designer`` writes "draft" and ``/workflows/canvas/save`` keeps
# it, so the designer's own chat -- which starts sessions in test mode -- could
# never satisfy the gate and every run failed with "Workflow not in validated
# state" before a single node executed.
#
# The lifecycle that actually exists is draft -> final. "validated" is an
# intermediate no surface writes. So the two draft-record modes now tolerate the
# same statuses, which is what ``execute_workflow`` already did, and the mode
# continues to decide *which record is loaded* -- the draft, or a pinned final
# version. Only "final" mode still requires "final".
RUNNABLE_DRAFT_STATUSES = ("draft", "validated", "final")


def _final_response_of(state: Any) -> str:
    """
    The answer a finished graph produced, for the ``run_completed`` event.

    Imported lazily and guarded because transparency must never be able to fail
    a run that has already succeeded: an event without the answer is a degraded
    UI, an exception here would be a lost result.

    Delegates to ``event_publisher.extract_final_response`` so the executor's
    event and the one ``routes`` publishes carry identical text. They are two
    emitters of one logical event, and the client settles on whichever arrives
    first.
    """
    try:
        from apps.workflow.runtime.event_publisher import extract_final_response

        text, _source = extract_final_response(state if isinstance(state, dict) else None)
        return text
    except Exception:  # noqa: BLE001 -- never fail a completed run on telemetry
        logger.debug("Could not extract final_response for run_completed", exc_info=True)
        return ""


class WorkflowExecutor:
    """
    Workflow execution service.
    Compiles and runs workflows via LangGraph.
    """

    def __init__(self, storage, compiler, agent_registry, guards=None, storage_gateway=None, ws_manager=None):
        """
        Initialize executor.

        Args:
            storage: WorkflowStorage instance (legacy filesystem)
            compiler: WorkflowCompiler instance
            agent_registry: AgentRegistry instance
            guards: RuntimeGuards instance (optional)
            storage_gateway: StorageGateway instance (DB-primary reads).
                If provided, all workflow loads go through the gateway.
                If None, falls back to direct filesystem reads (backward compat).
            ws_manager: WebSocketManager singleton (optional, for DI)
                If provided, used for real-time event streaming instead of inline imports.
        """
        self.storage = storage
        self.compiler = compiler
        self.agent_registry = agent_registry
        self.guards = guards
        self._workflow_repo = WorkflowRepository()
        self._execution_repo = ExecutionRunRepository()
        self._storage_gateway = storage_gateway
        self.ws_manager = ws_manager  # ✅ Store injected singleton (FIX #2)

    def _load_validated_draft_from_db(self, workflow_id: str) -> Dict[str, Any]:
        """
        Load a validated draft workflow from the database (sync bridge).

        Used by test execution mode to read the validated draft
        (status='validated', metadata.testing=true) from DB instead of
        the removed temp filesystem directory.

        Queries by workflow_id without user scoping because the executor
        is an internal component that runs after the authorization gate.

        Args:
            workflow_id: Workflow ID (prefixed or UUID).

        Returns:
            Workflow definition dict.

        Raises:
            FileNotFoundError: If no validated draft found in DB.
        """
        from sqlalchemy import select
        from echolib.models import Workflow
        from echolib.repositories.base import safe_uuid

        async def _fetch():
            uuid_id = safe_uuid(normalize_to_uuid(workflow_id))
            if uuid_id is None:
                raise FileNotFoundError(
                    f"Invalid workflow ID for DB lookup: {workflow_id}"
                )
            async with get_db_session() as db:
                # Direct query by PK without user scoping (internal executor call)
                stmt = select(Workflow).where(
                    Workflow.workflow_id == uuid_id,
                    Workflow.is_deleted == False,
                )
                result = await db.execute(stmt)
                row = result.scalar_one_or_none()

                if row is None:
                    raise FileNotFoundError(
                        f"Validated draft workflow not found in DB: {workflow_id}"
                    )
                definition = row.definition.copy() if row.definition else {}
                if definition.get("status") not in RUNNABLE_DRAFT_STATUSES:
                    raise RuntimeError(
                        f"Workflow {workflow_id} is not in a runnable state "
                        f"(found status='{definition.get('status')}')"
                    )
                return definition

        # Bridge async DB call into sync context on the owning DB event loop.
        return run_db_coro_sync(_fetch, timeout=30.0)

    def _extract_workflow_variables(self, workflow: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract input variables from workflow state_schema.

        The state_schema contains variable definitions from Start/End nodes.
        This method extracts input variables and their types.

        Args:
            workflow: Workflow definition

        Returns:
            Dict of variable names to their default values based on type
        """
        state_schema = workflow.get("state_schema", {})
        variables = {}

        for var_name, var_schema in state_schema.items():
            var_type, _ = TypeResolver._extract_type_info(var_schema)
            # Set default value based on type (aligned with _coerce_value groupings)
            if var_type in ("number", "integer", "int"):
                variables[var_name] = 0
            elif var_type == "float":
                variables[var_name] = 0.0
            elif var_type in ("boolean", "bool"):
                variables[var_name] = False
            elif var_type in ("array", "list", "string[]", "number[]", "object[]", "array[]", "file[]"):
                variables[var_name] = []
            elif var_type in ("object", "dict"):
                variables[var_name] = {}
            else:
                # Default to empty string for string and unknown types
                variables[var_name] = ""

        return variables

    def _substitute_variables(
        self,
        text: str,
        variables: Dict[str, Any]
    ) -> str:
        """
        Substitute variable placeholders in text with actual values.

        Supports formats: {variable_name}, {{variable_name}}, ${variable_name}

        Args:
            text: Text containing variable placeholders
            variables: Dict of variable names to values

        Returns:
            Text with variables substituted
        """
        if not text or not variables:
            return text

        result = text

        # Substitute {variable_name} format
        for var_name, var_value in variables.items():
            # Handle single brace format: {var_name}
            result = result.replace(f"{{{var_name}}}", str(var_value))
            # Handle double brace format: {{var_name}}
            result = result.replace(f"{{{{{var_name}}}}}", str(var_value))
            # Handle shell-style format: ${var_name}
            result = result.replace(f"${{{var_name}}}", str(var_value))

        return result

    def _extract_input_variables_via_llm(
        self,
        user_input: str,
        state_schema: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Use an LLM call to extract multiple input variable values from a
        natural-language user message.

        Called ONLY when the workflow defines 2+ input variables so that a
        message like "Review the performance of Shashank Singh for 2026" is
        parsed into {"employee_name": "Shashank Singh", "review_period": "2026"}.

        Uses LLM JSON extraction to parse variables from user input.
        Type coercion simplified for AURA2Echo LangChain exclusive.

        Args:
            user_input:   The raw user message string.
            state_schema: Dict of variable_name → type_string from the
                          workflow's state_schema (e.g. {"employee_name": "string",
                          "review_period": "string"}).

        Returns:
            Dict of successfully extracted variable values.  Keys that could
            not be determined are omitted (caller keeps defaults).
        """
        if not user_input or not state_schema:
            return {}

        try:
            from echolib.llm_resolver import resolve_and_build_llm_sync
            import json as _json

            llm = resolve_and_build_llm_sync(
                user_id=None,
                component="executor",
                temperature=0.0,
                max_tokens=500,
                allow_platform_fallback=True,
                framework="langchain",
            )

            # Build a clear extraction prompt listing every variable + its type
            vars_description = "\n".join(
                f'  - "{name}" (type: {TypeResolver._extract_type_info(vschema)[0]})'
                for name, vschema in state_schema.items()
                if not name.startswith("_")
            )

            prompt = (
                "Extract the following variable values from the user message below. "
                "Return ONLY a valid JSON object with the variable names as keys "
                "and their extracted values. If a variable's value cannot be "
                "determined from the message, use null.\n"
                "Do not include any explanation, markdown formatting, or extra text.\n\n"
                f"Variables to extract:\n{vars_description}\n\n"
                f"User message:\n{user_input[:3000]}\n\n"
                "JSON:"
            )

            response = llm.invoke(prompt)
            response_text = (
                response.content if hasattr(response, "content") else str(response)
            )

            # Strip markdown fences if present
            cleaned = re.sub(r"^```(?:json)?\s*", "", response_text.strip())
            cleaned = re.sub(r"\s*```$", "", cleaned)

            parsed = _json.loads(cleaned)
            if not isinstance(parsed, dict):
                logger.warning(
                    "[Executor] LLM input extraction returned non-dict, "
                    "falling back to single-var mapping."
                )
                return {}

            # Keep extracted values as-is (string conversion)
            # AURA2Echo uses LangChain exclusive - type coercion simplified
            result: Dict[str, Any] = {}
            for key, _ in state_schema.items():
                if key.startswith("_"):
                    continue
                value = parsed.get(key)
                if value is not None:
                    result[key] = str(value) if not isinstance(value, str) else value

            logger.info(
                f"[Executor] LLM input extraction successful: {list(result.keys())}"
            )
            return result

        except Exception as e:
            logger.warning(
                f"[Executor] LLM input variable extraction failed: {e}. "
                f"Falling back to single-variable mapping."
            )
            return {}

    def _map_user_input_to_variables(
        self,
        user_input: str,
        workflow_variables: Dict[str, Any],
        merged_variables: Dict[str, Any],
        state_schema: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Populate workflow state variables from the user's raw message.

        Strategy:
        - 0 variables  → no-op (nothing to map)
        - 1 variable   → fast path: assign entire user_input to the single
                          variable (preserves existing behaviour for calculator,
                          Q&A, code-review, … workflows — zero added latency)
        - 2+ variables → LLM extraction: call _extract_input_variables_via_llm
                          to parse individual values out of the natural-language
                          message.  On failure, falls back to the single-var
                          approach so nothing breaks.

        Args:
            user_input:         Raw user message string.
            workflow_variables: Variables from _extract_workflow_variables()
                                (names → typed defaults).
            merged_variables:   Variables merged with input_payload (mutable —
                                this dict is updated in-place).
            state_schema:       Variable type definitions from workflow
                                state_schema.

        Returns:
            The (possibly updated) merged_variables dict.
        """
        if not user_input or not workflow_variables:
            return merged_variables

        state_var_names = [
            k for k in workflow_variables.keys() if not k.startswith("_")
        ]
        if not state_var_names:
            return merged_variables

        if len(state_var_names) == 1:
            # ── Single-variable fast path with type coercion ──
            first_var = state_var_names[0]
            if not merged_variables.get(first_var):
                # Phase A: Apply type coercion for single variable
                var_schema = state_schema.get(first_var, {})
                var_type, _ = TypeResolver._extract_type_info(var_schema)
                value = TypeResolver.coerce_value(user_input, var_schema)
                merged_variables[first_var] = value
                logger.info(
                    f"Mapped user_input to workflow variable '{first_var}' with type coercion",
                    extra={"variable": first_var, "type": var_type}
                )
        else:
            # ── Multi-variable: LLM extraction ──
            extracted = self._extract_input_variables_via_llm(
                user_input, state_schema
            )
            if extracted:
                # Phase A: Apply type coercion to extracted variables
                extracted = TypeResolver.coerce_variables(extracted, state_schema)
                
                for var_name, var_value in extracted.items():
                    # Only overwrite if the variable is still at its default
                    if not merged_variables.get(var_name):
                        merged_variables[var_name] = var_value
                logger.info(
                    f"LLM extracted {len(extracted)} workflow variables",
                    extra={"extracted_variables": list(extracted.keys()), "count": len(extracted)}
                )
            else:
                # Fallback: assign entire message to first variable WITH type coercion
                # (same as single-var path — ensures at least one var is set, but now type-safe)
                first_var = state_var_names[0]
                if not merged_variables.get(first_var):
                    # ✅ Apply type coercion to fallback value (FIX #1)
                    var_schema = state_schema.get(first_var, {})
                    var_type, _ = TypeResolver._extract_type_info(var_schema)
                    value = TypeResolver.coerce_value(user_input, var_schema)
                    merged_variables[first_var] = value
                    logger.warning(
                        f"LLM extraction failed, falling back to mapping user_input to first variable '{first_var}' with type coercion",
                        extra={"variable": first_var, "type": var_type, "fallback_reason": "extraction_failed"}
                    )

        return merged_variables

    def _attach_langfuse(
        self,
        config: Dict[str, Any],
        run_id: str,
        workflow_id: str,
        execution_mode: str,
        user_id: str = "system",
        extra_tags: Optional[List[str]] = None,
    ) -> None:
        """Stub — Langfuse removed. No-op (tracing handled by OTel)."""
        pass

    @staticmethod
    def _agent_llm_bindings(agent_defs: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Describe the LLM each agent in this run is configured to use.

        WHAT: Maps agent id -> configured model, provider, sampling parameters
              and ``credential_id``, read through the canonical contract.
        WHY:  Per-agent LLM selection is honoured on every path from Phase 3
              onwards, which changes outputs and cost attribution on workflows
              that were silently running on the user's default credential. The
              run record must say which credential each agent was configured
              with so any change is attributable.
        INPUT: The agent definitions resolved for this run.
        OUTPUT: Dict keyed by agent id. Credentials by reference only -- no
                secret material, and no credential resolution is performed here.
        """
        if not agent_defs:
            return {}

        try:
            from apps.agent.factory import binding_metadata, resolve_model_binding
        except Exception:
            logger.debug("Agent factory unavailable; skipping LLM attribution", exc_info=True)
            return {}

        bindings: Dict[str, Any] = {}
        for agent_id, agent_def in agent_defs.items():
            if not isinstance(agent_def, dict):
                continue
            try:
                entry = binding_metadata(resolve_model_binding(agent_def))
            except Exception:
                logger.debug(
                    "Could not describe the LLM binding for agent '%s'", agent_id, exc_info=True
                )
                continue
            entry["name"] = agent_def.get("name")
            entry["config_version"] = agent_def.get("config_version")
            bindings[str(agent_id)] = entry

        return bindings

    def _save_execution_run_sync(
        self,
        run_id: str,
        workflow_id: str,
        user_id: str = "system",
        status: str = "running",
        agent_defs: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Save execution run to database (sync bridge).

        Wraps async save_run() in asyncio context for sync executor.

        Args:
            run_id: Unique run identifier
            workflow_id: Workflow being executed
            user_id: User executing the workflow
            status: Initial status ('running', 'completed', 'failed')
            agent_defs: Agent definitions for this run. When supplied, the LLM
                each agent is configured with is recorded on the run's metadata.
        """
        try:
            metadata: Dict[str, Any] = {}
            bindings = self._agent_llm_bindings(agent_defs)
            if bindings:
                metadata["agent_llm_bindings"] = bindings

            # Phase 8: latest-wins means a workflow can behave differently today
            # than yesterday with no workflow edit, because a shared agent was
            # edited elsewhere. Recording which config_version of each agent
            # actually ran is what makes that change attributable rather than
            # mysterious, and names any agent that fell back to an embedded copy.
            try:
                from .agent_resolution import describe_resolution

                resolution = describe_resolution(agent_defs)
                if resolution:
                    metadata["agent_resolution"] = resolution
            except Exception:
                logger.debug("Agent resolution attribution unavailable", exc_info=True)

            async def _save():
                async with get_db_session() as db:
                    await self._execution_repo.save_run(
                        db=db,
                        run_id=run_id,
                        workflow_id=workflow_id,
                        user_id=user_id,
                        status=status,
                        metadata=metadata or None
                    )

            run_db_coro_sync(_save, timeout=15.0)
        except Exception as e:
            logger.error(f"Failed to save execution run {run_id}: {e}")
            # Don't raise - persistence failure should not block execution

    @staticmethod
    def _hitl_run_status(final_state: Dict[str, Any]) -> str:
        """
        Derive a HITL run's final status from the graph state it ended in.

        WHAT: Maps the ``hitl_outcome`` a HITL checkpoint wrote onto the status
              recorded against the run.
        WHY:  The HITL paths used to record ``final_state.get("status",
              "failed")``. ``final_state`` is the LangGraph state, which has no
              ``status`` key, so **every completed HITL run was recorded as
              failed**. And a rejection has never been a failure: it is a
              decision a human made, and reporting it as a crash gives the
              reviewer no way to tell their own rejection from a broken run.

        The two HITL values are already permitted by the ``valid_exec_status``
        check constraint on ``executions``, so this needs no migration:

            rejected  -> hitl_rejected   the reviewer declined; run is over
            anything else -> completed   approved, edited, or no HITL at all

        ``deferred`` is still mapped, for read-back only: runs recorded before
        deferral was removed as a decision still carry that outcome, and
        reporting them as ``completed`` would misstate what happened.
        """
        outcome = ""
        if isinstance(final_state, dict):
            outcome = str(final_state.get("hitl_outcome") or "").strip().lower()

        if outcome == "rejected":
            return "hitl_rejected"
        if outcome == "deferred":
            return "hitl_waiting"
        return "completed"

    def _complete_execution_run_sync(self, run_id: str, status: str = "completed") -> None:
        """
        Mark execution run as completed in database (sync bridge).
        
        Args:
            run_id: Unique run identifier
            status: Final status ('completed', 'failed')
        """
        try:
            async def _complete():
                async with get_db_session() as db:
                    await self._execution_repo.complete_run(
                        db=db,
                        run_id=run_id,
                        status=status
                    )
            
            run_db_coro_sync(_complete, timeout=15.0)
        except Exception as e:
            logger.error(f"Failed to complete execution run {run_id}: {e}")
            # Don't raise - persistence failure should not block execution

    def execute_workflow(
        self,
        workflow_id: str,
        execution_mode: str,
        version: Optional[str] = None,
        input_payload: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Execute a workflow.

        Args:
            workflow_id: Workflow identifier
            execution_mode: "test" or "final"
            version: Version (required for final mode)
            input_payload: Input data for workflow

        Returns:
            Execution result

        Raises:
            RuntimeError: If workflow not in correct state
        """
        if input_payload is None:
            input_payload = {}

        # Load workflow based on mode.
        # When a StorageGateway is available, use it for DB-primary reads
        # with gated filesystem fallback.  Otherwise fall back to direct
        # filesystem reads for backward compatibility.
        if execution_mode == "draft":
            if self._storage_gateway:
                # DB-primary via gateway (no user scoping -- executor is
                # an internal component that runs after the auth gate).
                workflow = self._storage_gateway.load_workflow_sync(
                    workflow_id, DEFAULT_USER_ID,
                    state="draft",
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Workflow '{workflow_id}' not found (draft mode)"
                    )
            else:
                workflow = self.storage.load_workflow(
                    workflow_id=workflow_id,
                    state="draft"
                )
            if workflow.get("status") not in RUNNABLE_DRAFT_STATUSES:
                raise RuntimeError("Workflow not in usable state")

        elif execution_mode == "test":
            # Test mode reads draft workflow from DB
            if self._storage_gateway:
                # Extract authenticated user_id from input_payload if available.
                # Routes inject this when user is authenticated. Falls back to
                # DEFAULT_USER_ID for system/background execution.
                load_user_id = (input_payload or {}).get("user_id") or DEFAULT_USER_ID
                workflow = self._storage_gateway.load_workflow_sync(
                    workflow_id, load_user_id,
                    state="draft",
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Draft workflow not found: {workflow_id}"
                    )
            else:
                workflow = self._load_validated_draft_from_db(workflow_id)

        elif execution_mode == "final":
            if not version:
                # Auto-resolve latest version when none provided
                if self._storage_gateway:
                    versions = self._storage_gateway.list_workflow_versions_sync(
                        workflow_id
                    )
                else:
                    versions = self.storage.list_versions(workflow_id)
                if not versions:
                    raise ValueError(
                        f"No final versions found for workflow '{workflow_id}'"
                    )
                # versions may be dicts (DB) or strings (FS)
                if isinstance(versions[-1], dict):
                    version = versions[-1].get("version", versions[-1])
                else:
                    version = versions[-1]
                logger.info(f"Auto-resolved latest version: {version}")
            if self._storage_gateway:
                workflow = self._storage_gateway.load_workflow_version_sync(
                    workflow_id, version
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Final workflow version not found: "
                        f"{workflow_id}@{version}"
                    )
            else:
                workflow = self.storage.load_workflow(
                    workflow_id=workflow_id,
                    state="final",
                    version=version
                )
            if workflow.get("status") != "final":
                raise RuntimeError("Workflow not finalized")

        else:
            raise ValueError(f"Invalid execution mode: {execution_mode}")

        # Apply guards if available
        if self.guards:
            self.guards.check_before_execution(workflow)

        logger.info(
            "Loaded workflow '%s' with execution_model='%s'",
            workflow_id, workflow.get('execution_model'),
        )

        # Extract workflow variables from state_schema
        workflow_variables = self._extract_workflow_variables(workflow)

        # Load agent definitions - handle both embedded and ID-referenced formats
        agent_defs = {}
        for agent_entry in workflow.get("agents", []):
            # Handle both formats:
            # 1. New format: agent_entry is a full agent dict
            # 2. Old format: agent_entry is a string agent_id
            if isinstance(agent_entry, dict):
                # New format: agent is embedded in workflow
                agent_id = agent_entry.get("agent_id")
                if agent_id:
                    agent_defs[agent_id] = agent_entry
            elif isinstance(agent_entry, str):
                # Old format: agent_entry is an ID, load from registry
                agent_id = agent_entry
                try:
                    agent = self.agent_registry.get_agent(agent_id)
                    if agent is None:
                        # Agent not in cache - try reloading from disk
                        logger.warning("Agent '%s' not in cache, reloading registry...", agent_id)
                        self.agent_registry._load_all()  # Reload all agents from disk
                        agent = self.agent_registry.get_agent(agent_id)
                        if agent is None:
                            raise RuntimeError(f"Agent '{agent_id}' not found in registry after reload")
                    agent_defs[agent_id] = agent
                except FileNotFoundError:
                    raise RuntimeError(f"Agent '{agent_id}' not found in registry")

        # Normalize agent configs — ensures top-level 'config' key exists
        # for API/Code/MCP nodes, handling pre-fix workflows
        for agent_id in agent_defs:
            normalize_agent_config(agent_defs[agent_id])

        # Stamp user_id into agent defs for per-user LLM credential resolution
        if input_payload:
            self._stamp_runtime_user_id(agent_defs, str(input_payload.get("user_id", "")))

        # Compile workflow to LangGraph
        compiled_graph = self.compiler.compile_to_langgraph(workflow, agent_defs)

        # Execute workflow with LangGraph
        # Use run_id from input_payload if provided (for transparency tracking),
        # otherwise generate a new one
        if input_payload is None:
            input_payload = {}
        run_id = input_payload.get("run_id") or new_id("run_")

        # Save execution run to database (Phase 2: Database persistence)
        user_id = str(input_payload.get("user_id", "system"))
        self._save_execution_run_sync(
            run_id=run_id,
            workflow_id=workflow_id,
            user_id=user_id,
            status="running",
            agent_defs=agent_defs,
        )

        # New-workflow path defaults to ON for resilience safeguards.
        enable_resilience_guards = bool(
            input_payload.get("_enable_runtime_resilience_guards", True)
        )

        try:
            # Prepare initial state with workflow and run IDs

            # Normalize user input: ensure "user_input" key is set
            # Accept common key names from frontend
            # FIX: Handle structured payloads (code, language, etc.) that don't use standard keys
            user_input = (
                input_payload.get("user_input")
                or input_payload.get("message")
                or input_payload.get("question")
                or input_payload.get("input")
                or input_payload.get("task_description")
                or input_payload.get("prompt")
            )

            # FIX: If no standard key found but payload has data, serialize entire payload
            # This handles structured inputs like {"code": "...", "language": "python"}
            if not user_input and input_payload:
                import json
                # Check if there are any meaningful keys in the payload (not just metadata)
                meaningful_keys = {k for k in input_payload.keys()
                                   if k not in ("workflow_id", "run_id", "mode", "version", "context")}
                if meaningful_keys:
                    # Serialize the structured input as JSON string for agents to parse
                    user_input = json.dumps(input_payload, indent=2)
                    logger.debug(f"[Executor] Serialized structured payload as user_input: {user_input[:200]}...")

            # Final fallback to empty string
            if not user_input:
                user_input = ""

            # FIXED: Set initial state with original_user_input preserved
            # This ensures all agents throughout the workflow have access
            # to the original user request, not just the first agent

            # Merge workflow variables with input payload
            # Input payload values override default variable values
            merged_variables = {**workflow_variables}
            for key, value in input_payload.items():
                if key in merged_variables or key not in ["workflow_id", "run_id", "mode", "version"]:
                    merged_variables[key] = value

            # Map user message to workflow state variables.
            # Single-var workflows: entire message → the one variable (fast, no LLM).
            # Multi-var workflows:  LLM extracts individual values from natural language.
            merged_variables = self._map_user_input_to_variables(
                user_input, workflow_variables, merged_variables,
                workflow.get("state_schema", {}),
            )

            # Substitute variables in user_input if it contains placeholders
            user_input = self._substitute_variables(user_input, merged_variables)

            initial_state = {
                **merged_variables,  # Include all workflow variables
                **input_payload,
                "user_input": user_input,
                "original_user_input": user_input,  # CRITICAL: Preserve original
                "task_description": user_input,     # Alias for compatibility
                "messages": [],
                "workflow_id": workflow_id,
                "run_id": run_id,
                "_workflow_variables": workflow_variables,  # Track defined variables
                "_state_schema": workflow.get("state_schema", {}),
                "_aura_exec": workflow.get("execution") or {},  # AURA primitives config (simulation/policy/fallbacks)  # Track variable types
                "_aura_exec": workflow.get("execution") or {},  # AURA primitives config (simulation/policy/fallbacks)
                "_enable_runtime_resilience_guards": enable_resilience_guards,
            }

            # Audit log user input (prompt injection detection)
            try:
                from echolib.observability import audit_log_input
                audit_log_input(
                    run_id=run_id,
                    user_input=user_input,
                    user_id=str(input_payload.get("user_id", "system")),
                    workflow_id=workflow_id,
                )
            except Exception as _audit_err:
                logger.debug(f"Audit log skipped: {_audit_err}")

            # Run the compiled graph
            config = {"configurable": {"thread_id": run_id}}

            # Emit run_started transparency event so SSE consumers see
            # the preparation sub-step before agent execution begins.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_STARTED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_started event skipped: {_ev_err}")

            final_state = compiled_graph.invoke(initial_state, config)

            # Emit run_completed transparency event.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_COMPLETED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={
                            "status": "completed",
                            "workflow_id": workflow_id,
                            # The answer, not just the verdict. This event
                            # reaches the browser before the one routes
                            # publishes, and the client settles on the first
                            # run_completed it sees -- so an event carrying
                            # no response rendered the turn empty over a run
                            # that had produced thousands of characters.
                            "final_response": _final_response_of(final_state),
                        },
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_completed event skipped: {_ev_err}")

            result = {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "completed",
                "execution_mode": execution_mode,
                "output": final_state,
                "messages": final_state.get("messages", [])
            }

        except Exception as e:
            import traceback
            logger.error(f"[EXECUTOR] Workflow execution FAILED for {workflow_id}: {e}")
            logger.error(f"[EXECUTOR] Traceback:\n{traceback.format_exc()}")
            result = {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "failed",
                "execution_mode": execution_mode,
                "error": str(e),
                "output": {}
            }

        finally:
            # Phase 2: Mark execution as completed in database (both success and failure paths)
            final_status = result.get("status", "failed")
            self._complete_execution_run_sync(run_id=run_id, status=final_status)

        return result

    def load_for_execution(
        self,
        workflow_id: str,
        mode: str,
        version: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Load workflow for execution.

        Phase 2: Delegates to ``_load_workflow`` which uses the
        StorageGateway for DB-primary reads when available.

        Args:
            workflow_id: Workflow identifier
            mode: "draft", "test", or "final"
            version: Version (for final mode)

        Returns:
            Workflow definition
        """
        return self._load_workflow(workflow_id, mode, version)

    # ========================================================================
    # HITL-AWARE EXECUTION (Additive — does NOT modify existing methods)
    # ========================================================================

    def _load_workflow(
        self,
        workflow_id: str,
        mode: str,
        version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Load workflow definition by mode.

        Phase 2: Uses StorageGateway for DB-primary reads when available,
        falls back to direct FS reads for backward compatibility.

        Args:
            workflow_id: Workflow identifier.
            mode: "draft", "test", or "final".
            version: Version string (for final mode).

        Returns:
            Workflow definition dict.

        Raises:
            ValueError: If mode is invalid or no versions found.
            FileNotFoundError: If workflow not found.
        """
        if mode == "draft":
            if self._storage_gateway:
                workflow = self._storage_gateway.load_workflow_sync(
                    workflow_id, DEFAULT_USER_ID, state="draft",
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Workflow '{workflow_id}' not found (draft mode)"
                    )
                return workflow
            return self.storage.load_workflow(
                workflow_id=workflow_id, state="draft"
            )
        elif mode == "test":
            if self._storage_gateway:
                workflow = self._storage_gateway.load_workflow_sync(
                    workflow_id, DEFAULT_USER_ID, state="draft",
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Validated draft workflow not found: {workflow_id}"
                    )
                if workflow.get("status") not in RUNNABLE_DRAFT_STATUSES:
                    raise RuntimeError(
                        f"Workflow {workflow_id} is not in a runnable state "
                        f"(found status='{workflow.get('status')}')"
                    )
                return workflow
            # Fallback: direct DB query (no gateway)
            return self._load_validated_draft_from_db(workflow_id)
        elif mode == "final":
            if not version:
                # Auto-resolve latest version
                if self._storage_gateway:
                    versions = self._storage_gateway.list_workflow_versions_sync(
                        workflow_id
                    )
                else:
                    versions = self.storage.list_versions(workflow_id)
                if not versions:
                    raise ValueError(
                        f"No final versions found for workflow '{workflow_id}'"
                    )
                # versions may be dicts (DB) or strings (FS)
                if isinstance(versions[-1], dict):
                    version = versions[-1].get("version", versions[-1])
                else:
                    version = versions[-1]
            if self._storage_gateway:
                workflow = self._storage_gateway.load_workflow_version_sync(
                    workflow_id, version
                )
                if workflow is None:
                    raise FileNotFoundError(
                        f"Final workflow version not found: "
                        f"{workflow_id}@{version}"
                    )
                return workflow
            return self.storage.load_workflow(
                workflow_id=workflow_id, state="final", version=version
            )
        raise ValueError(f"Invalid execution mode: {mode}")

    def _load_agent_defs(
        self, workflow: Dict[str, Any], user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Load the agent definitions this run will execute.

        WHAT: Resolves every entry in ``workflow["agents"]`` against the
              ``agents`` table, falling back to the embedded copy only when the
              referenced agent no longer exists.
        WHY:  This method used to read the embedded copy and consult the
              ``agents`` table only for bare-string entries, which the canvas
              never emits. The write path was already aligned -- every embedded
              agent is upserted through the Phase 1 boundary by
              ``workflow_repo.save_with_agents`` -- so an agent was one entity
              on write and two on read: editing it on the agent page never
              reached a workflow that had embedded it (Finding 8).
        INPUT: The workflow definition and the acting user. Without a user no
               record can be read and every entry falls back, which is logged.
        OUTPUT: ``{agent_id: definition}``, each carrying ``_resolution_source``.

        Latest-wins is locked in ``Plan_1.md`` §1: a workflow runs the agent as
        it is now, not as it was when the canvas was last saved. That means a
        workflow can behave differently today than yesterday with no workflow
        edit, which is why ``describe_resolution`` records the resolved
        ``config_version`` of every agent on the run.
        """
        from .agent_resolution import resolve_workflow_agents

        agent_defs = resolve_workflow_agents(
            workflow, user_id, agent_registry=self.agent_registry
        )

        for agent_id in agent_defs:
            normalize_agent_config(agent_defs[agent_id])

        return agent_defs

    @staticmethod
    def _stamp_runtime_user_id(
        agent_defs: Dict[str, Any], user_id: Optional[str]
    ) -> None:
        """Inject ``_runtime_user_id`` into every agent definition so that
        downstream LLM builders can resolve per-user
        credentials without requiring the compiler to be user-aware."""
        if not user_id or user_id == "system":
            return
        for _def in agent_defs.values():
            if isinstance(_def, dict):
                _def["_runtime_user_id"] = user_id

    def _normalize_ids_for_compilation(
        self,
        workflow: Dict[str, Any],
        agent_defs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Ensure agent IDs in connections match the node IDs in agent_defs.

        Handles THREE types of ID mismatch:

        1. **UUID ↔ prefixed format** — DB-stored definitions may have
           agent_ids in UUID format while connections still reference the
           prefixed format ('agt_xxx'), or vice versa.

        2. **Integer canvas node IDs** — ``map_backend_to_frontend()``
           assigns 1-based sequential integer IDs when converting a
           workflow for the canvas.  If canvas state is saved back to the
           DB without going through ``map_frontend_to_backend()`` (e.g.
           via ``save_final``), connections retain integer ``from``/``to``
           values (1, 2, 3 …).  These correspond 1:1 to the ordered
           agents list by 1-based position.

        3. **String-coerced integers** — Same as (2) after a JSON
           round-trip where integers may arrive as ``"1"``, ``"2"``, etc.

        Args:
            workflow: Workflow definition (modified in-place).
            agent_defs: Dict of agent_id -> agent definition.

        Returns:
            The (possibly modified) workflow dict.
        """
        from echolib.id_utils import normalize_to_uuid, uuid_to_prefixed

        node_ids = set(agent_defs.keys())

        # Ordered agent_ids matching the embedded agents array.
        # This order corresponds to the 1-based integer IDs assigned by
        # ``map_backend_to_frontend()``.
        ordered_agent_ids: list[str] = []
        for agent_entry in workflow.get("agents", []):
            if isinstance(agent_entry, dict):
                aid = agent_entry.get("agent_id")
                if aid is not None:
                    ordered_agent_ids.append(str(aid))
            elif agent_entry is not None:
                ordered_agent_ids.append(str(agent_entry))

        # ---------- variant → canonical mapping ----------
        variant_to_canonical: Dict[str, str] = {}

        for nid in node_ids:
            canonical = str(nid)
            variant_to_canonical[nid] = canonical
            variant_to_canonical[canonical] = canonical
            try:
                uuid_form = normalize_to_uuid(canonical)
                variant_to_canonical[uuid_form] = canonical
                prefixed_form = uuid_to_prefixed(uuid_form, "agt_")
                variant_to_canonical[prefixed_form] = canonical
                raw_hex = uuid_form.replace("-", "")
                variant_to_canonical[raw_hex] = canonical
            except (ValueError, Exception):
                pass

        # 1-based canvas-ID mapping.
        # ``map_backend_to_frontend`` iterates the agents list and assigns
        # ``current_id`` starting at 1, so canvas node 1 = agents[0],
        # canvas node 2 = agents[1], etc.
        for idx, agent_id in enumerate(ordered_agent_ids):
            canvas_id = idx + 1
            variant_to_canonical[canvas_id] = agent_id        # int key
            variant_to_canonical[str(canvas_id)] = agent_id   # str key

        node_id_strs = {str(nid) for nid in node_ids}

        # Quick-check: do connections already use canonical IDs?
        connections = workflow.get("connections", [])
        needs_fix = False
        for conn in connections:
            from_id = conn.get("from", "")
            to_id = conn.get("to", "")
            if str(from_id) not in node_id_strs or str(to_id) not in node_id_strs:
                needs_fix = True
                break

        if not needs_fix:
            return workflow

        # ---------- rewrite connections ----------
        logger.info("[EXECUTOR] Normalizing connection IDs to match node IDs")
        for conn in connections:
            for field in ("from", "to"):
                val = conn.get(field)
                if val is None:
                    continue
                # Try the value as-is (int or str key)
                if val in variant_to_canonical:
                    conn[field] = variant_to_canonical[val]
                    continue
                # Coerce to string and retry
                val_str = str(val)
                if val_str in variant_to_canonical:
                    conn[field] = variant_to_canonical[val_str]
                    continue
                # Could not resolve — use string form to avoid TypeError
                logger.warning(
                    "[EXECUTOR] Connection %s value %r could not be "
                    "resolved to a known node — using str() fallback",
                    field, val,
                )
                conn[field] = val_str

        # Fix agents list entries if needed
        agents_list = workflow.get("agents", [])
        for i, agent_entry in enumerate(agents_list):
            if isinstance(agent_entry, dict):
                aid = agent_entry.get("agent_id", "")
                aid_str = str(aid) if aid is not None else ""
                if aid_str in variant_to_canonical and aid_str not in node_id_strs:
                    agent_entry["agent_id"] = variant_to_canonical[aid_str]
            elif isinstance(agent_entry, str):
                if agent_entry in variant_to_canonical and agent_entry not in node_id_strs:
                    agents_list[i] = variant_to_canonical[agent_entry]

        return workflow

    def execute_workflow_hitl(
        self,
        workflow_id: str,
        execution_mode: str,
        version: Optional[str] = None,
        input_payload: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        """
        Execute a workflow with HITL interrupt support.

        Same as execute_workflow but:
        1. Detects __interrupt__ in invoke() return value
        2. Returns status="interrupted" with interrupt payload
        3. Uses the HITL-aware checkpointer (PostgresSaver for HITL workflows)

        This method is used ONLY for workflows that contain HITL nodes.
        Non-HITL workflows continue using execute_workflow() unchanged.

        Args:
            workflow_id: Workflow identifier.
            execution_mode: "test" or "final".
            version: Version (required for final mode).
            input_payload: Input data for workflow.

        Returns:
            Execution result dict. If workflow pauses at HITL:
            {
                "run_id": "...",
                "status": "interrupted",
                "interrupt": {...},  # HITL context for frontend
                ...
            }
        """
        if input_payload is None:
            input_payload = {}

        # Load workflow
        workflow = self._load_workflow(workflow_id, execution_mode, version)

        # Apply guards if available
        if self.guards:
            self.guards.check_before_execution(workflow)

        logger.info(
            f"[EXECUTOR-HITL] Executing workflow '{workflow_id}' "
            f"(mode={execution_mode})"
        )

        # Extract workflow variables
        workflow_variables = self._extract_workflow_variables(workflow)

        # Load agent definitions
        # Resolved by reference against the agents table (Phase 8): the run
        # executes each agent as it is now, not as it was when the canvas was
        # last saved. user_id is required for the user-scoped read.
        agent_defs = self._load_agent_defs(
            workflow, str((input_payload or {}).get("user_id", "")) or None
        )

        # Stamp user_id into agent defs for per-user LLM credential resolution
        if input_payload:
            self._stamp_runtime_user_id(agent_defs, str(input_payload.get("user_id", "")))

        # Compile workflow to LangGraph
        compiled_graph = self.compiler.compile_to_langgraph(workflow, agent_defs)

        # Prepare run_id
        run_id = input_payload.get("run_id") or new_id("run_")

        # Persist parent run before any step-level persistence occurs.
        user_id = str(input_payload.get("user_id", "system"))
        self._save_execution_run_sync(
            run_id=run_id,
            workflow_id=workflow_id,
            user_id=user_id,
            status="running",
            agent_defs=agent_defs,
        )

        # DB-first/reused path defaults OFF unless caller explicitly enables.
        enable_resilience_guards = bool(
            input_payload.get("_enable_runtime_resilience_guards", False)
        )

        should_complete_run = True
        result: Dict[str, Any] = {}

        try:
            # Normalize user input (same logic as execute_workflow)
            import json as _json

            user_input = (
                input_payload.get("user_input")
                or input_payload.get("message")
                or input_payload.get("question")
                or input_payload.get("input")
                or input_payload.get("task_description")
                or input_payload.get("prompt")
            )

            if not user_input and input_payload:
                meaningful_keys = {
                    k for k in input_payload.keys()
                    if k not in ("workflow_id", "run_id", "mode", "version", "context")
                }
                if meaningful_keys:
                    user_input = _json.dumps(input_payload, indent=2)

            if not user_input:
                user_input = ""

            # Merge variables
            merged_variables = {**workflow_variables}
            for key, value in input_payload.items():
                if key in merged_variables or key not in [
                    "workflow_id", "run_id", "mode", "version"
                ]:
                    merged_variables[key] = value

            # Map user message to workflow state variables.
            # Single-var: entire message → the one variable (fast, no LLM).
            # Multi-var:  LLM extracts individual values from natural language.
            merged_variables = self._map_user_input_to_variables(
                user_input, workflow_variables, merged_variables,
                workflow.get("state_schema", {}),
            )

            user_input = self._substitute_variables(user_input, merged_variables)

            initial_state = {
                **merged_variables,
                **input_payload,
                "user_input": user_input,
                "original_user_input": user_input,
                "task_description": user_input,
                "messages": [],
                "workflow_id": workflow_id,
                "run_id": run_id,
                "_workflow_variables": workflow_variables,
                "_state_schema": workflow.get("state_schema", {}),
                "_aura_exec": workflow.get("execution") or {},  # AURA primitives config (simulation/policy/fallbacks)
                "_enable_runtime_resilience_guards": enable_resilience_guards,
            }

            # Audit log user input (prompt injection detection)
            try:
                from echolib.observability import audit_log_input
                audit_log_input(
                    run_id=run_id,
                    user_input=user_input,
                    user_id=str(input_payload.get("user_id", "system")),
                    workflow_id=workflow_id,
                )
            except Exception as _audit_err:
                logger.debug(f"Audit log skipped: {_audit_err}")

            # Run the compiled graph
            config = {"configurable": {"thread_id": run_id}}

            # Emit run_started transparency event so SSE consumers see
            # run lifecycle before agent execution begins.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_STARTED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_started event skipped: {_ev_err}")

            result = compiled_graph.invoke(initial_state, config)

            # CHECK: Did the graph pause at an interrupt?
            if "__interrupt__" in result:
                interrupt_data = result["__interrupt__"]
                # Extract the interrupt payload (HITL context)
                # interrupt_data is a list/tuple of Interrupt objects
                interrupt_payload = None
                if interrupt_data and len(interrupt_data) > 0:
                    first_interrupt = interrupt_data[0]
                    # Interrupt objects have a .value attribute
                    if hasattr(first_interrupt, 'value'):
                        interrupt_payload = first_interrupt.value
                    else:
                        interrupt_payload = first_interrupt

                logger.info(
                    f"[EXECUTOR-HITL] Workflow '{workflow_id}' interrupted "
                    f"at HITL node (run_id={run_id})"
                )

                # Emit terminal lifecycle event for interrupted status.
                if settings.transparency_enabled:
                    try:
                        from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                        from apps.workflow.runtime.ws_manager import ws_manager
                        from datetime import datetime as _dt
                        ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                            event_type=EventType.RUN_COMPLETED,
                            run_id=run_id,
                            step_id=None,
                            timestamp=_dt.now(timezone.utc).isoformat(),
                            payload={"status": "interrupted", "workflow_id": workflow_id},
                        ))
                    except Exception as _ev_err:
                        logger.debug(f"run_completed(interrupted) event skipped: {_ev_err}")

                # Interrupted runs are paused/resumable, not terminal.
                should_complete_run = False

                return {
                    "run_id": run_id,
                    "workflow_id": workflow_id,
                    "status": "interrupted",
                    "execution_mode": execution_mode,
                    "interrupt": interrupt_payload,
                    "output": result,
                    "messages": result.get("messages", []),
                }

            # Normal completion (no interrupt)
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_COMPLETED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={
                            "status": "completed",
                            "workflow_id": workflow_id,
                            # The answer, not just the verdict. This event
                            # reaches the browser before the one routes
                            # publishes, and the client settles on the first
                            # run_completed it sees -- so an event carrying
                            # no response rendered the turn empty over a run
                            # that had produced thousands of characters.
                            "final_response": _final_response_of(result),
                        },
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_completed event skipped: {_ev_err}")

            # A rejected run is not a completed one. The caller
            # sees the same value that is recorded against the run, so the UI
            # can show "rejected by <reviewer>" rather than a green tick or,
            # as before, a failure.
            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": self._hitl_run_status(result),
                "execution_mode": execution_mode,
                "hitl_outcome": result.get("hitl_outcome"),
                "output": result,
                "messages": result.get("messages", []),
            }

        except Exception as e:
            import traceback
            logger.error(
                f"[EXECUTOR-HITL] Workflow execution FAILED for "
                f"{workflow_id}: {e}"
            )
            logger.error(f"[EXECUTOR-HITL] Traceback:\n{traceback.format_exc()}")

            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_FAILED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"error": str(e), "workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_failed event skipped: {_ev_err}")

            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "failed",
                "execution_mode": execution_mode,
                "error": str(e),
                "output": {},
            }
        finally:
            if should_complete_run and result:
                self._complete_execution_run_sync(
                    run_id=run_id,
                    status=self._hitl_run_status(result),
                )

    # ========================================================================
    # DB-FIRST EXECUTION (accepts pre-loaded workflow definition dict)
    # ========================================================================

    def execute_from_definition(
        self,
        workflow_def: Dict[str, Any],
        execution_mode: str,
        input_payload: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        """
        Execute a workflow from a pre-loaded definition dict.

        This method is the DB-first counterpart of execute_workflow().
        The caller (async route handler) loads the workflow definition from
        the database and passes it directly, eliminating filesystem reads.

        The execution logic is identical to execute_workflow() but skips
        the storage.load_workflow() step entirely.

        Args:
            workflow_def: Complete workflow definition dict (from DB or filesystem).
            execution_mode: "draft", "test", or "final".
            input_payload: Input data for workflow.

        Returns:
            Execution result dict.
        """
        if input_payload is None:
            input_payload = {}

        workflow = workflow_def
        workflow_id = workflow.get("workflow_id", "unknown")

        # Validate workflow status based on execution mode
        status = workflow.get("status")
        if execution_mode in ("draft", "test"):
            if status not in RUNNABLE_DRAFT_STATUSES:
                raise RuntimeError(
                    f"Workflow not in a runnable state (found status='{status}')"
                )
        elif execution_mode == "final":
            if status != "final":
                raise RuntimeError("Workflow not finalized")
        else:
            raise ValueError(f"Invalid execution mode: {execution_mode}")

        # Apply guards if available
        if self.guards:
            self.guards.check_before_execution(workflow)

        print(f"[EXECUTOR] Loaded workflow '{workflow_id}' (from definition) with execution_model='{workflow.get('execution_model')}'")

        # Extract workflow variables from state_schema
        workflow_variables = self._extract_workflow_variables(workflow)

        # Load agent definitions
        # Resolved by reference against the agents table (Phase 8): the run
        # executes each agent as it is now, not as it was when the canvas was
        # last saved. user_id is required for the user-scoped read.
        agent_defs = self._load_agent_defs(
            workflow, str((input_payload or {}).get("user_id", "")) or None
        )

        # Stamp user_id into agent defs for per-user LLM credential resolution
        if input_payload:
            self._stamp_runtime_user_id(agent_defs, str(input_payload.get("user_id", "")))

        # FIX: Normalize agent_defs keys and connection references to be consistent.
        # DB definitions saved before the fix may have agent_ids in UUID format
        # (e.g., "454aff3b-7edf-4143-9094-0b27cb961223") while connections still
        # reference the prefixed format (e.g., "agt_454aff3b7edf414390940b27cb961223").
        # Build a mapping so connections can find their nodes regardless of format.
        workflow = self._normalize_ids_for_compilation(workflow, agent_defs)

        # Compile workflow to LangGraph
        compiled_graph = self.compiler.compile_to_langgraph(workflow, agent_defs)

        # Prepare run_id
        run_id = input_payload.get("run_id") or new_id("run_")

        # Persist parent run before any step-level persistence occurs.
        user_id = str(input_payload.get("user_id", "system"))
        self._save_execution_run_sync(
            run_id=run_id,
            workflow_id=workflow_id,
            user_id=user_id,
            status="running",
            agent_defs=agent_defs,
        )

        try:
            # Normalize user input (same logic as execute_workflow)
            import json as _json

            user_input = (
                input_payload.get("user_input")
                or input_payload.get("message")
                or input_payload.get("question")
                or input_payload.get("input")
                or input_payload.get("task_description")
                or input_payload.get("prompt")
            )

            if not user_input and input_payload:
                meaningful_keys = {
                    k for k in input_payload.keys()
                    if k not in ("workflow_id", "run_id", "mode", "version", "context")
                }
                if meaningful_keys:
                    user_input = _json.dumps(input_payload, indent=2)
                    print(f"[Executor] Serialized structured payload as user_input: {user_input[:200]}...")

            if not user_input:
                user_input = ""

            # Merge variables
            merged_variables = {**workflow_variables}
            for key, value in input_payload.items():
                if key in merged_variables or key not in ["workflow_id", "run_id", "mode", "version"]:
                    merged_variables[key] = value

            # Map user message to workflow state variables.
            # Single-var: entire message → the one variable (fast, no LLM).
            # Multi-var:  LLM extracts individual values from natural language.
            merged_variables = self._map_user_input_to_variables(
                user_input, workflow_variables, merged_variables,
                workflow.get("state_schema", {}),
            )

            user_input = self._substitute_variables(user_input, merged_variables)

            initial_state = {
                **merged_variables,
                **input_payload,
                "user_input": user_input,
                "original_user_input": user_input,
                "task_description": user_input,
                "messages": [],
                "workflow_id": workflow_id,
                "run_id": run_id,
                "_workflow_variables": workflow_variables,
                "_state_schema": workflow.get("state_schema", {}),
                "_aura_exec": workflow.get("execution") or {},  # AURA primitives config (simulation/policy/fallbacks)
            }

            # Audit log user input (prompt injection detection)
            try:
                from echolib.observability import audit_log_input
                audit_log_input(
                    run_id=run_id,
                    user_input=user_input,
                    user_id=str(input_payload.get("user_id", "system")),
                    workflow_id=workflow_id,
                )
            except Exception as _audit_err:
                logger.debug(f"Audit log skipped: {_audit_err}")

            config = {"configurable": {"thread_id": run_id}}

            # Emit run_started transparency event so SSE consumers see
            # the preparation sub-step before agent execution begins.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_STARTED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_started event skipped: {_ev_err}")

            final_state = compiled_graph.invoke(initial_state, config)

            # Emit run_completed transparency event.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_COMPLETED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={
                            "status": "completed",
                            "workflow_id": workflow_id,
                            # The answer, not just the verdict. This event
                            # reaches the browser before the one routes
                            # publishes, and the client settles on the first
                            # run_completed it sees -- so an event carrying
                            # no response rendered the turn empty over a run
                            # that had produced thousands of characters.
                            "final_response": _final_response_of(final_state),
                        },
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_completed event skipped: {_ev_err}")

            result = {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "completed",
                "execution_mode": execution_mode,
                "output": final_state,
                "messages": final_state.get("messages", []),
            }

        except Exception as e:
            import traceback
            logger.error(f"[EXECUTOR] Workflow execution FAILED for {workflow_id}: {e}")
            logger.error(f"[EXECUTOR] Traceback:\n{traceback.format_exc()}")
            result = {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "failed",
                "execution_mode": execution_mode,
                "error": str(e),
                "output": {},
            }

        finally:
            final_status = result.get("status", "failed")
            self._complete_execution_run_sync(
                run_id=run_id,
                status=final_status,
            )

        return result

    def execute_hitl_from_definition(
        self,
        workflow_def: Dict[str, Any],
        execution_mode: str,
        input_payload: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        """
        Execute a workflow with HITL interrupt support from a pre-loaded definition.

        This method is the DB-first counterpart of execute_workflow_hitl().
        The caller loads the workflow definition from the database and passes
        it directly, eliminating filesystem reads.

        Same as execute_workflow_hitl() but skips filesystem load.

        Args:
            workflow_def: Complete workflow definition dict (from DB or filesystem).
            execution_mode: "draft", "test", or "final".
            input_payload: Input data for workflow.

        Returns:
            Execution result dict. If workflow pauses at HITL:
            {
                "run_id": "...",
                "status": "interrupted",
                "interrupt": {...},
                ...
            }
        """
        if input_payload is None:
            input_payload = {}

        workflow = workflow_def
        workflow_id = workflow.get("workflow_id", "unknown")

        # Apply guards if available
        if self.guards:
            self.guards.check_before_execution(workflow)

        logger.info(
            f"[EXECUTOR-HITL] Executing workflow '{workflow_id}' "
            f"(mode={execution_mode}, source=definition)"
        )

        # Extract workflow variables
        workflow_variables = self._extract_workflow_variables(workflow)

        # Load agent definitions
        # Resolved by reference against the agents table (Phase 8): the run
        # executes each agent as it is now, not as it was when the canvas was
        # last saved. user_id is required for the user-scoped read.
        agent_defs = self._load_agent_defs(
            workflow, str((input_payload or {}).get("user_id", "")) or None
        )

        # Stamp user_id into agent defs for per-user LLM credential resolution
        if input_payload:
            self._stamp_runtime_user_id(agent_defs, str(input_payload.get("user_id", "")))

        # FIX: Normalize IDs for compilation (same as execute_from_definition)
        workflow = self._normalize_ids_for_compilation(workflow, agent_defs)

        # Compile workflow to LangGraph
        compiled_graph = self.compiler.compile_to_langgraph(workflow, agent_defs)

        # Prepare run_id
        run_id = input_payload.get("run_id") or new_id("run_")

        # Persist parent run before any step-level persistence occurs.
        user_id = str(input_payload.get("user_id", "system"))
        self._save_execution_run_sync(
            run_id=run_id,
            workflow_id=workflow_id,
            user_id=user_id,
            status="running",
            agent_defs=agent_defs,
        )

        should_complete_run = True
        result: Dict[str, Any] = {}

        try:
            import json as _json

            user_input = (
                input_payload.get("user_input")
                or input_payload.get("message")
                or input_payload.get("question")
                or input_payload.get("input")
                or input_payload.get("task_description")
                or input_payload.get("prompt")
            )

            if not user_input and input_payload:
                meaningful_keys = {
                    k for k in input_payload.keys()
                    if k not in ("workflow_id", "run_id", "mode", "version", "context")
                }
                if meaningful_keys:
                    user_input = _json.dumps(input_payload, indent=2)

            if not user_input:
                user_input = ""

            merged_variables = {**workflow_variables}
            for key, value in input_payload.items():
                if key in merged_variables or key not in [
                    "workflow_id", "run_id", "mode", "version"
                ]:
                    merged_variables[key] = value

            # Map user message to workflow state variables.
            # Single-var: entire message → the one variable (fast, no LLM).
            # Multi-var:  LLM extracts individual values from natural language.
            merged_variables = self._map_user_input_to_variables(
                user_input, workflow_variables, merged_variables,
                workflow.get("state_schema", {}),
            )

            user_input = self._substitute_variables(user_input, merged_variables)

            initial_state = {
                **merged_variables,
                **input_payload,
                "user_input": user_input,
                "original_user_input": user_input,
                "task_description": user_input,
                "messages": [],
                "workflow_id": workflow_id,
                "run_id": run_id,
                "_workflow_variables": workflow_variables,
                "_state_schema": workflow.get("state_schema", {}),
                "_aura_exec": workflow.get("execution") or {},  # AURA primitives config (simulation/policy/fallbacks)
            }

            # Audit log
            try:
                from echolib.observability import audit_log_input
                audit_log_input(
                    run_id=run_id,
                    user_input=user_input,
                    user_id=str(input_payload.get("user_id", "system")),
                    workflow_id=workflow_id,
                )
            except Exception as _audit_err:
                logger.debug(f"Audit log skipped: {_audit_err}")

            config = {"configurable": {"thread_id": run_id}}

            # Emit run_started transparency event so SSE consumers see
            # run lifecycle before agent execution begins.
            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_STARTED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_started event skipped: {_ev_err}")

            result = compiled_graph.invoke(initial_state, config)

            # Check for HITL interrupt
            if "__interrupt__" in result:
                interrupt_data = result["__interrupt__"]
                interrupt_payload = None
                if interrupt_data and len(interrupt_data) > 0:
                    first_interrupt = interrupt_data[0]
                    if hasattr(first_interrupt, 'value'):
                        interrupt_payload = first_interrupt.value
                    else:
                        interrupt_payload = first_interrupt

                logger.info(
                    f"[EXECUTOR-HITL] Workflow '{workflow_id}' interrupted "
                    f"at HITL node (run_id={run_id})"
                )

                # Emit terminal lifecycle event for interrupted status.
                if settings.transparency_enabled:
                    try:
                        from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                        from apps.workflow.runtime.ws_manager import ws_manager
                        from datetime import datetime as _dt
                        ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                            event_type=EventType.RUN_COMPLETED,
                            run_id=run_id,
                            step_id=None,
                            timestamp=_dt.now(timezone.utc).isoformat(),
                            payload={"status": "interrupted", "workflow_id": workflow_id},
                        ))
                    except Exception as _ev_err:
                        logger.debug(f"run_completed(interrupted) event skipped: {_ev_err}")

                # Interrupted runs are paused/resumable, not terminal.
                should_complete_run = False

                return {
                    "run_id": run_id,
                    "workflow_id": workflow_id,
                    "status": "interrupted",
                    "execution_mode": execution_mode,
                    "interrupt": interrupt_payload,
                    "output": result,
                    "messages": result.get("messages", []),
                }

            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_COMPLETED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={
                            "status": "completed",
                            "workflow_id": workflow_id,
                            # The answer, not just the verdict. This event
                            # reaches the browser before the one routes
                            # publishes, and the client settles on the first
                            # run_completed it sees -- so an event carrying
                            # no response rendered the turn empty over a run
                            # that had produced thousands of characters.
                            "final_response": _final_response_of(result),
                        },
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_completed event skipped: {_ev_err}")

            # A rejected run is not a completed one. The caller
            # sees the same value that is recorded against the run, so the UI
            # can show "rejected by <reviewer>" rather than a green tick or,
            # as before, a failure.
            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": self._hitl_run_status(result),
                "execution_mode": execution_mode,
                "hitl_outcome": result.get("hitl_outcome"),
                "output": result,
                "messages": result.get("messages", []),
            }

        except Exception as e:
            import traceback
            logger.error(
                f"[EXECUTOR-HITL] Workflow execution FAILED for "
                f"{workflow_id}: {e}"
            )
            logger.error(f"[EXECUTOR-HITL] Traceback:\n{traceback.format_exc()}")

            if settings.transparency_enabled:
                try:
                    from apps.workflow.runtime.transparency import ExecutionEvent, EventType
                    from apps.workflow.runtime.ws_manager import ws_manager
                    from datetime import datetime as _dt
                    ws_manager.buffer_and_send_sync(run_id, ExecutionEvent(
                        event_type=EventType.RUN_FAILED,
                        run_id=run_id,
                        step_id=None,
                        timestamp=_dt.now(timezone.utc).isoformat(),
                        payload={"error": str(e), "workflow_id": workflow_id},
                    ))
                except Exception as _ev_err:
                    logger.debug(f"run_failed event skipped: {_ev_err}")

            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "failed",
                "execution_mode": execution_mode,
                "error": str(e),
                "output": {},
            }
        finally:
            if should_complete_run and result:
                self._complete_execution_run_sync(
                    run_id=run_id,
                    status=self._hitl_run_status(result),
                )

    def resume_workflow(
        self,
        workflow_id: str,
        run_id: str,
        action: str,
        payload: Dict[str, Any] = None,
        execution_mode: str = "draft",
        version: Optional[str] = None,
        user_id: str = "system",
        workflow_def: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Resume a workflow that was paused at a HITL interrupt.

        Uses LangGraph's Command(resume=...) to continue execution
        from the exact point where interrupt() was called.

        The resume value becomes the return value of interrupt() inside
        the HITL node function, so the node can read the human's decision.

        Args:
            workflow_id: Workflow identifier.
            run_id: The original run_id (used as thread_id for checkpoint lookup).
            action: Human decision ("approve", "reject", "edit").
            payload: Additional data (edit content, rationale, etc.).
            execution_mode: "draft", "test", or "final".
            version: Version (for final mode).
            user_id: User performing the resume.
            workflow_def: Pre-loaded workflow definition dict.  When
                provided, ``_load_workflow()`` is skipped entirely.
                This avoids cross-event-loop errors when ``resume_workflow``
                runs inside ``asyncio.to_thread()`` -- the caller pre-loads
                the definition in the async context where the DB session
                is valid.

        Returns:
            Execution result dict (may be another interrupt or final completion).
        """
        from langgraph.types import Command

        logger.info(
            f"[EXECUTOR-HITL] Resuming workflow '{workflow_id}' "
            f"(run_id={run_id}, action={action})"
        )

        # Re-compile the graph (needed to get the same graph structure).
        # The checkpointer will restore state from the DB using thread_id=run_id.
        # If workflow_def was pre-loaded by the caller (in the async context
        # where DB access is safe), skip the potentially problematic
        # _load_workflow() call that uses sync-to-async bridges.
        if workflow_def is not None:
            workflow = workflow_def
            logger.debug(
                "[EXECUTOR-HITL] Using pre-loaded workflow definition "
                "(skipping _load_workflow)"
            )
        else:
            workflow = self._load_workflow(workflow_id, execution_mode, version)
        agent_defs = self._load_agent_defs(workflow, user_id)
        self._stamp_runtime_user_id(agent_defs, user_id)
        compiled_graph = self.compiler.compile_to_langgraph(workflow, agent_defs)

        # Build resume command
        resume_value = {
            "action": action,
            "payload": payload or {},
        }

        config = {"configurable": {"thread_id": run_id}}

        try:
            # Resume from interrupt -- Command(resume=...) becomes the return
            # value of the interrupt() call inside the HITL node
            result = compiled_graph.invoke(Command(resume=resume_value), config)

            # Check if we hit ANOTHER interrupt (chained HITL nodes)
            if "__interrupt__" in result:
                interrupt_data = result["__interrupt__"]
                interrupt_payload = None
                if interrupt_data and len(interrupt_data) > 0:
                    first_interrupt = interrupt_data[0]
                    if hasattr(first_interrupt, 'value'):
                        interrupt_payload = first_interrupt.value
                    else:
                        interrupt_payload = first_interrupt

                logger.info(
                    f"[EXECUTOR-HITL] Resumed workflow hit another interrupt "
                    f"(run_id={run_id})"
                )

                return {
                    "run_id": run_id,
                    "workflow_id": workflow_id,
                    "status": "interrupted",
                    "interrupt": interrupt_payload,
                    "output": result,
                    "messages": result.get("messages", []),
                }

            final_status = self._hitl_run_status(result)
            logger.info(
                f"[EXECUTOR-HITL] Workflow resumed and finished with status "
                f"'{final_status}' (run_id={run_id})"
            )
            self._complete_execution_run_sync(run_id=run_id, status=final_status)

            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": final_status,
                "hitl_outcome": result.get("hitl_outcome"),
                "output": result,
                "messages": result.get("messages", []),
            }

        except Exception as e:
            logger.error(
                f"[EXECUTOR-HITL] Resume failed for run '{run_id}': {e}",
                exc_info=True,
            )
            return {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "status": "failed",
                "error": str(e),
                "output": {},
            }