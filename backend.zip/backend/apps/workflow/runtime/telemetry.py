"""
Runtime telemetry.
OpenTelemetry instrumentation for workflow execution.
"""
import time
from typing import Dict, Any, Optional
from contextlib import contextmanager

# OTel — soft import so the module still works without OTel installed
try:
    from echolib.otel import get_tracer, get_metrics_collector
    _tracer = get_tracer("workflow.runtime")
except ImportError:
    _tracer = None
    get_metrics_collector = None


class WorkflowTelemetry:
    """
    Telemetry service for workflow execution.
    Provides OpenTelemetry-compatible tracing.
    """

    def __init__(self, enabled: bool = True):
        """
        Initialize telemetry.

        Args:
            enabled: Whether telemetry is enabled
        """
        self.enabled = enabled
        self.spans: Dict[str, Dict[str, Any]] = {}

    @contextmanager
    def workflow_span(
        self,
        workflow_id: str,
        version: str,
        execution_model: str
    ):
        """
        Create workflow-level span.

        Args:
            workflow_id: Workflow identifier
            version: Workflow version
            execution_model: Execution model

        Yields:
            Span context
        """
        if not self.enabled:
            yield None
            return

        start = time.time()
        span_id = f"workflow_{workflow_id}"

        span = {
            "span_id": span_id,
            "workflow_id": workflow_id,
            "version": version,
            "execution_model": execution_model,
            "start_time": start,
            "end_time": None,
        }

        self.spans[span_id] = span

        otel_span_ctx = None
        if _tracer:
            otel_span_ctx = _tracer.start_as_current_span(
                "workflow.execute",
                attributes={
                    "workflow.id": workflow_id,
                    "workflow.version": version,
                    "workflow.execution_model": execution_model,
                },
            )

        try:
            if otel_span_ctx:
                with otel_span_ctx:
                    yield span
            else:
                yield span
        finally:
            span["end_time"] = time.time()
            duration_ms = (span["end_time"] - start) * 1000
            if get_metrics_collector:
                try:
                    mc = get_metrics_collector()
                    mc.record_workflow_execution(
                        workflow_id=workflow_id,
                        execution_mode="canvas",
                        duration_ms=duration_ms,
                        status="success",
                    )
                except Exception:
                    pass

    @contextmanager
    def agent_span(
        self,
        agent_id: str,
        agent_role: str,
        llm_provider: str,
        llm_model: str
    ):
        """
        Create agent-level span.

        Args:
            agent_id: Agent identifier
            agent_role: Agent role
            llm_provider: LLM provider
            llm_model: LLM model

        Yields:
            Span context
        """
        if not self.enabled:
            yield None
            return

        start = time.time()
        span_id = f"agent_{agent_id}"

        span = {
            "span_id": span_id,
            "agent_id": agent_id,
            "agent_role": agent_role,
            "llm_provider": llm_provider,
            "llm_model": llm_model,
            "start_time": start,
            "end_time": None,
            "tokens_in": 0,
            "tokens_out": 0,
        }

        self.spans[span_id] = span

        otel_span_ctx = None
        if _tracer:
            otel_span_ctx = _tracer.start_as_current_span(
                "workflow.agent",
                attributes={
                    "agent.id": agent_id,
                    "agent.role": agent_role,
                    "llm.provider": llm_provider,
                    "llm.model": llm_model,
                },
            )

        try:
            if otel_span_ctx:
                with otel_span_ctx:
                    yield span
            else:
                yield span
        finally:
            span["end_time"] = time.time()

    @contextmanager
    def tool_span(self, tool_id: str, mcp_server: str):
        """
        Create tool-level span.

        Args:
            tool_id: Tool identifier
            mcp_server: MCP server

        Yields:
            Span context
        """
        if not self.enabled:
            yield None
            return

        start = time.time()
        span_id = f"tool_{tool_id}"

        span = {
            "span_id": span_id,
            "tool_id": tool_id,
            "mcp_server": mcp_server,
            "start_time": start,
            "end_time": None,
            "success": None,
        }

        self.spans[span_id] = span

        otel_span_ctx = None
        if _tracer:
            otel_span_ctx = _tracer.start_as_current_span(
                "workflow.tool",
                attributes={
                    "tool.id": tool_id,
                    "tool.mcp_server": mcp_server,
                },
            )

        try:
            if otel_span_ctx:
                with otel_span_ctx:
                    yield span
            else:
                yield span
            span["success"] = True
        except Exception as e:
            span["success"] = False
            span["error"] = str(e)
            if get_metrics_collector:
                try:
                    mc = get_metrics_collector()
                    mc.record_tool_call(
                        tool_name=tool_id,
                        tool_type="workflow",
                        duration_ms=(time.time() - start) * 1000,
                        status="error",
                    )
                except Exception:
                    pass
            raise
        finally:
            span["end_time"] = time.time()

    def get_metrics(self) -> Dict[str, Any]:
        """
        Get collected telemetry metrics.

        Returns:
            Telemetry metrics
        """
        return {
            "enabled": self.enabled,
            "spans": self.spans,
        }
