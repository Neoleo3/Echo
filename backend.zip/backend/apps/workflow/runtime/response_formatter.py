"""
Response formatter -- production-grade output sanitization layer.

Converts raw execution output (which may contain JSON, internal metadata,
or structured data) into clean, human-readable markdown for the UI.

This module is the SINGLE BOUNDARY between internal execution output
and user-facing responses. All response paths MUST route through here.

Why this exists:
    Agents frequently return structured JSON output (e.g.
    ``{"redline_summary": ..., "edits": [...]}``). Without a dedicated
    formatting layer, this raw JSON leaks directly into the chat UI.
    This module detects JSON content and converts it to clean markdown,
    preserving prose text and handling all edge cases safely.
"""

import json
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Keys that represent internal/metadata fields and should be excluded
# from user-facing formatted output.
_INTERNAL_KEYS = frozenset({
    "metadata", "raw_output", "internal", "_internal",
    "_metadata", "__internal__", "_raw",
})


def format_output_for_ui(text: str) -> str:
    """
    Format execution output for user-facing display.

    Detects JSON content and converts it to clean markdown.
    Preserves prose text. Never returns raw JSON to the UI.
    Falls back to returning text as-is if no JSON is detected
    or if parsing fails -- guarantees no data loss.

    Args:
        text: Raw output text from workflow/agent execution.

    Returns:
        Clean, formatted text suitable for UI display.
    """
    if not text or not isinstance(text, str):
        return text or ""

    stripped = text.strip()
    if not stripped:
        return ""

    # Quick check: if no brace or bracket characters exist, no JSON possible
    if "{" not in stripped and "[" not in stripped:
        return text

    # Case 1: Entire response is a JSON object or array
    if _looks_like_complete_json(stripped):
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, (dict, list)):
                formatted = _json_to_markdown(parsed)
                if formatted and formatted.strip():
                    return formatted
        except (json.JSONDecodeError, ValueError):
            pass  # Not valid JSON despite looking like it

    # Case 2: Text contains embedded JSON blocks
    result = _replace_embedded_json(stripped)
    if result != stripped:
        return result

    # Case 3: No JSON detected -- return as-is
    return text


def _looks_like_complete_json(text: str) -> bool:
    """
    Check whether text looks like it could be a complete JSON value.

    Only returns True if the text starts and ends with matching
    delimiters (``{}`` or ``[]``). This is a fast pre-check before
    attempting ``json.loads()``.

    Args:
        text: Stripped text to check.

    Returns:
        True if the text has matching JSON delimiters.
    """
    if not text:
        return False
    return (
        (text[0] == "{" and text[-1] == "}")
        or (text[0] == "[" and text[-1] == "]")
    )


def _replace_embedded_json(text: str) -> str:
    """
    Find and replace embedded JSON objects in text with markdown.

    Uses brace-counting (not regex) to correctly handle nested JSON.
    Only converts JSON blocks with 2+ keys to avoid false positives
    on simple expressions like ``{x}``.

    Args:
        text: Text that may contain embedded JSON blocks.

    Returns:
        Text with JSON blocks replaced by markdown formatting.
    """
    result_parts: list[str] = []
    i = 0
    length = len(text)
    found_any = False

    while i < length:
        if text[i] == "{":
            json_str = _extract_json_object(text, i)
            if json_str is not None:
                try:
                    parsed = json.loads(json_str)
                    if isinstance(parsed, dict) and len(parsed) >= 2:
                        markdown = _json_to_markdown(parsed)
                        result_parts.append(markdown)
                        i += len(json_str)
                        found_any = True
                        continue
                except (json.JSONDecodeError, ValueError):
                    pass
        result_parts.append(text[i])
        i += 1

    if found_any:
        return "".join(result_parts)
    return text


def _extract_json_object(text: str, start: int) -> Optional[str]:
    """
    Extract a complete JSON object from text starting at position ``start``.

    Uses brace-counting to find the matching closing brace,
    correctly handling nested objects, arrays, and string literals
    (including escaped quotes).

    Args:
        text: Full text containing potential JSON.
        start: Index of the opening ``{`` character.

    Returns:
        The complete JSON substring if balanced braces are found,
        None otherwise (unmatched or not starting with ``{``).
    """
    if start >= len(text) or text[start] != "{":
        return None

    depth = 0
    in_string = False
    escape_next = False
    i = start

    while i < len(text):
        ch = text[i]

        if escape_next:
            escape_next = False
            i += 1
            continue

        if ch == "\\" and in_string:
            escape_next = True
            i += 1
            continue

        if ch == '"':
            in_string = not in_string
        elif not in_string:
            if ch in ("{", "["):
                depth += 1
            elif ch in ("}", "]"):
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]

        i += 1

    return None  # Unmatched braces


def _json_to_markdown(data: Any, indent_level: int = 0) -> str:
    """
    Convert a JSON-parsed Python object to clean markdown text.

    Dispatches to type-specific formatters for dicts, lists,
    and primitive values.

    Args:
        data: Parsed JSON data (dict, list, or primitive).
        indent_level: Current nesting level for indentation.

    Returns:
        Human-readable markdown string.
    """
    if isinstance(data, dict):
        return _dict_to_markdown(data, indent_level)
    if isinstance(data, list):
        return _list_to_markdown(data, indent_level)
    if isinstance(data, bool):
        return "Yes" if data else "No"
    if data is None:
        return "N/A"
    return str(data)


def _dict_to_markdown(d: dict, indent_level: int = 0) -> str:
    """
    Convert a dict to markdown with bold keys and formatted values.

    Internal/metadata keys (prefixed with ``_`` or in ``_INTERNAL_KEYS``)
    are silently skipped. Long text values are placed on the next line
    for readability.

    Args:
        d: Dictionary to format.
        indent_level: Current nesting depth for indentation.

    Returns:
        Formatted markdown string.
    """
    lines: list[str] = []
    indent = "  " * indent_level

    for key, value in d.items():
        # Skip internal/metadata keys
        if key.startswith("_") or key.lower() in _INTERNAL_KEYS:
            continue

        # Format key as readable label
        label = _key_to_label(key)

        if isinstance(value, dict):
            lines.append(f"{indent}**{label}:**")
            lines.append(_dict_to_markdown(value, indent_level + 1))
        elif isinstance(value, list):
            lines.append(f"{indent}**{label}:**")
            lines.append(_list_to_markdown(value, indent_level + 1))
        elif isinstance(value, bool):
            lines.append(f"{indent}**{label}:** {'Yes' if value else 'No'}")
        elif value is None:
            lines.append(f"{indent}**{label}:** N/A")
        else:
            val_str = str(value)
            if len(val_str) > 100:
                lines.append(f"{indent}**{label}:**")
                lines.append(f"{indent}  {val_str}")
            else:
                lines.append(f"{indent}**{label}:** {val_str}")

    return "\n".join(lines)


def _list_to_markdown(lst: list, indent_level: int = 0) -> str:
    """
    Convert a list to markdown.

    Dicts are rendered as numbered items; primitives as bullet points.
    Blank lines are inserted between complex items for readability.

    Args:
        lst: List to format.
        indent_level: Current nesting depth for indentation.

    Returns:
        Formatted markdown string.
    """
    lines: list[str] = []
    indent = "  " * indent_level

    for idx, item in enumerate(lst, 1):
        if isinstance(item, dict):
            lines.append(f"{indent}{idx}.")
            lines.append(_dict_to_markdown(item, indent_level + 1))
            if idx < len(lst):
                lines.append("")  # Blank line between items
        elif isinstance(item, list):
            lines.append(f"{indent}- (nested list)")
            lines.append(_list_to_markdown(item, indent_level + 1))
        else:
            lines.append(f"{indent}- {item}")

    return "\n".join(lines)


def _key_to_label(key: str) -> str:
    """
    Convert a snake_case or kebab-case key to a human-readable title.

    Args:
        key: Raw dict key string.

    Returns:
        Title-cased, space-separated label.
    """
    return key.replace("_", " ").replace("-", " ").title()
