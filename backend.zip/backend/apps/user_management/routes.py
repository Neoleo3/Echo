"""
EchoAI User Management — API Routes

Admin endpoints for runtime user CRUD with role hierarchy enforcement.
Allows super_admins and admins to manage users, assign roles,
and link designations/business_units for ABAC app filtering.

Prefix: /api/admin/users
"""

import logging
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query

from echolib.database import get_db_session
from echolib.models import User
from echolib.repositories.user_repo import UserRepository
from echolib.security import (
    enforce_role_ceiling,
    require_admin_or_above,
    require_super_admin,
)
from echolib.types import UserContext

from .schemas import (
    CreateUserRequest,
    LookupItem,
    UpdateUserRequest,
    UserListResponse,
    UserResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin/users", tags=["user-management"])

_user_repo = UserRepository()


def _user_to_response(user: User, creator_email: Optional[str] = None) -> UserResponse:
    """Convert User ORM instance to UserResponse schema.

    Names come from the link's catalog relationship (``lazy="selectin"``, so
    one batched query for the whole page rather than one per row). A link
    whose catalog row has been deleted falls back to its id, which keeps the
    two lists the same length and the entry still identifiable.
    """
    designation_links = user.designation_links or []
    business_unit_links = user.business_unit_links or []

    return UserResponse(
        user_id=str(user.user_id),
        email=user.email,
        display_name=user.display_name,
        avatar_url=user.avatar_url,
        role=user.role,
        is_active=user.is_active,
        designation_ids=[
            str(link.designation_id) for link in designation_links
        ],
        business_unit_ids=[
            str(link.business_unit_id) for link in business_unit_links
        ],
        designations=[
            LookupItem(
                id=str(link.designation_id),
                name=(
                    link.designation.name
                    if link.designation is not None
                    else str(link.designation_id)
                ),
            )
            for link in designation_links
        ],
        business_units=[
            LookupItem(
                id=str(link.business_unit_id),
                name=(
                    link.business_unit.name
                    if link.business_unit is not None
                    else str(link.business_unit_id)
                ),
            )
            for link in business_unit_links
        ],
        created_at=user.created_at,
        updated_at=user.updated_at,
        last_login_at=user.last_login_at,
        created_by=str(user.created_by) if user.created_by else None,
        created_by_email=creator_email,
    )


# -------------------------------------------------------------------
# GET /api/admin/users — List users (paginated)
# -------------------------------------------------------------------
@router.get("", response_model=UserListResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None, description="Search email or name"),
    role: Optional[str] = Query(None, description="Filter by role"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    caller: UserContext = Depends(require_admin_or_above),
):
    """List all users with optional filters. Admin+ only."""
    async with get_db_session() as db:
        items, total = await _user_repo.list_users(
            db,
            page=page,
            page_size=page_size,
            search=search,
            role_filter=role,
            is_active=is_active,
        )
        # Fetch creator emails for users that have a creator
        creator_emails = {}
        for u in items:
            if u.created_by:
                creator = await _user_repo.get_by_id(db, str(u.created_by))
                if creator:
                    creator_emails[str(u.user_id)] = creator.email
        
        return UserListResponse(
            items=[_user_to_response(u, creator_email=creator_emails.get(str(u.user_id))) for u in items],
            total=total,
            page=page,
            page_size=page_size,
        )


# -------------------------------------------------------------------
# POST /api/admin/users — Create user
# -------------------------------------------------------------------
@router.post("", response_model=UserResponse, status_code=201)
async def create_user(
    payload: CreateUserRequest,
    caller: UserContext = Depends(require_admin_or_above),
):
    """
    Create a new user with role and designation/BU assignments.

    Role hierarchy enforced: admin cannot assign super_admin.
    """
    # Enforce role ceiling
    enforce_role_ceiling(caller.role, payload.role)

    async with get_db_session() as db:
        # Check if email already exists (including inactive users)
        existing = await _user_repo.get_by_email(db, payload.email)
        if existing:
            if not existing.is_active:
                raise HTTPException(
                    status_code=409,
                    detail=f"User with email '{payload.email}' already exists but is deactivated. Reactivate the existing user instead.",
                )
            raise HTTPException(
                status_code=409,
                detail=f"User with email '{payload.email}' already exists",
            )

        # Create user
        new_user = User(
            user_id=uuid4(),
            email=payload.email.lower().strip(),
            display_name=payload.display_name or payload.email.split("@")[0],
            role=payload.role,
            is_active=True,
            user_metadata={},
            created_by=caller.user_id,
        )
        db.add(new_user)
        await db.flush()

        # Sync designation links
        if payload.designation_ids:
            await _user_repo.sync_designation_links(
                db, str(new_user.user_id), payload.designation_ids
            )

        # Sync business unit links
        if payload.business_unit_ids:
            await _user_repo.sync_business_unit_links(
                db, str(new_user.user_id), payload.business_unit_ids
            )

        # Refresh to load relationships
        await db.refresh(new_user)
        logger.info(
            "User created by %s: email=%s role=%s",
            caller.email, payload.email, payload.role,
        )
        return _user_to_response(new_user, creator_email=caller.email)


# -------------------------------------------------------------------
# GET /api/admin/users/{user_id} — Get user detail
# -------------------------------------------------------------------
@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    caller: UserContext = Depends(require_admin_or_above),
):
    """Get a single user's details. Admin+ only."""
    async with get_db_session() as db:
        user = await _user_repo.get_by_id(db, user_id)
        if user is None:
            raise HTTPException(404, "User not found")
        
        # Fetch creator email if user has a creator
        creator_email = None
        if user.created_by:
            creator = await _user_repo.get_by_id(db, str(user.created_by))
            if creator:
                creator_email = creator.email
        
        return _user_to_response(user, creator_email=creator_email)


# -------------------------------------------------------------------
# PATCH /api/admin/users/{user_id} — Update user
# -------------------------------------------------------------------
@router.patch("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    payload: UpdateUserRequest,
    caller: UserContext = Depends(require_admin_or_above),
):
    """
    Update user role, designations, or business units.

    Role hierarchy enforced: admin cannot promote to super_admin.
    """
    async with get_db_session() as db:
        user = await _user_repo.get_by_id(db, user_id)
        if user is None:
            raise HTTPException(404, "User not found")

        # Role change — enforce ceiling
        if payload.role is not None and payload.role != user.role:
            enforce_role_ceiling(caller.role, payload.role)

        # Build updates dict for scalar fields
        updates = {}
        if payload.display_name is not None:
            updates["display_name"] = payload.display_name
        if payload.role is not None:
            updates["role"] = payload.role
        if payload.is_active is not None:
            updates["is_active"] = payload.is_active

        if updates:
            await _user_repo.update(db, user_id, updates)

        # Sync designation links
        if payload.designation_ids is not None:
            await _user_repo.sync_designation_links(
                db, user_id, payload.designation_ids
            )

        # Sync business unit links
        if payload.business_unit_ids is not None:
            await _user_repo.sync_business_unit_links(
                db, user_id, payload.business_unit_ids
            )

        # Refresh user with updated relationships
        await db.refresh(user)
        logger.info(
            "User updated by %s: user_id=%s changes=%s",
            caller.email, user_id, payload.model_dump(exclude_none=True),
        )
        
        # Fetch creator email if user has a creator
        creator_email = None
        if user.created_by:
            creator = await _user_repo.get_by_id(db, str(user.created_by))
            if creator:
                creator_email = creator.email
        
        return _user_to_response(user, creator_email=creator_email)


# -------------------------------------------------------------------
# DELETE /api/admin/users/{user_id} — Deactivate user (super_admin only)
# -------------------------------------------------------------------
@router.delete("/{user_id}", status_code=204)
async def delete_user(
    user_id: str,
    caller: UserContext = Depends(require_super_admin),
):
    """Soft-deactivate a user. Super_admin only."""
    # Prevent self-deactivation
    if caller.user_id == user_id:
        raise HTTPException(400, "Cannot deactivate your own account")

    async with get_db_session() as db:
        success = await _user_repo.deactivate(db, user_id)
        if not success:
            raise HTTPException(404, "User not found or already inactive")
    logger.info("User deactivated by %s: user_id=%s", caller.email, user_id)
