"""
EchoAI User Management — Pydantic Schemas

Request/response models for the admin user management API.
"""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field


class CreateUserRequest(BaseModel):
    """Request body for creating a new user."""
    email: EmailStr
    display_name: Optional[str] = None
    role: str = Field(default="user", pattern="^(super_admin|admin|user)$")
    designation_ids: List[str] = Field(default_factory=list)
    business_unit_ids: List[str] = Field(default_factory=list)


class UpdateUserRequest(BaseModel):
    """Request body for updating a user."""
    display_name: Optional[str] = None
    role: Optional[str] = Field(default=None, pattern="^(super_admin|admin|user)$")
    designation_ids: Optional[List[str]] = None
    business_unit_ids: Optional[List[str]] = None
    is_active: Optional[bool] = None


class LookupItem(BaseModel):
    """An assigned catalog entry, carrying both halves of its identity."""
    id: str
    name: str


class UserResponse(BaseModel):
    """Single user response.

    ``designation_ids`` / ``business_unit_ids`` are the raw links and are what
    the update endpoint accepts back. ``designations`` / ``business_units``
    add the resolved names: an identifier that only means something after a
    second catalog lookup renders as a bare UUID whenever that lookup is
    empty or still in flight, which is what clients were showing.
    Both are returned; neither replaces the other.
    """
    user_id: str
    email: str
    display_name: Optional[str] = None
    avatar_url: Optional[str] = None
    role: str
    is_active: bool
    designation_ids: List[str] = Field(default_factory=list)
    business_unit_ids: List[str] = Field(default_factory=list)
    designations: List[LookupItem] = Field(default_factory=list)
    business_units: List[LookupItem] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_login_at: Optional[datetime] = None
    created_by: Optional[str] = None
    created_by_email: Optional[str] = None


class UserListResponse(BaseModel):
    """Paginated user list response."""
    items: List[UserResponse]
    total: int
    page: int
    page_size: int
