"""
The embeddings client used to index attached sources.

WHAT: Resolves an embeddings model through the same platform credential
      cascade the rest of Echo uses, with the platform default behind it.
WHY:  Indexing is the second place this layer needs an LLM credential. Giving
      it its own resolution path would be a second source of truth for "which
      model does this user's work run on", which is the defect Phase 3 removed
      for chat models.

**The cascade is resolved at call time, not at build time.** Constructing an
embeddings client makes no network call, so it always succeeds — even when the
deployment does not exist on the user's resource. A user whose default LLM is a
*chat* credential (Azure ``gpt-4o``, with no embedding deployment recorded) would
otherwise get a client that builds cleanly and then 404s on the first document,
with the platform default never reached. ``apps/knowledge/tasks.py:348-362``
works around the same problem by wrapping the real indexing call in a retry;
``CascadingEmbeddings`` does it once, here, so no caller has to.

Key Vault behaviour is unchanged: user keys arrive inside the dict
``resolve_llm_credential_sync`` returns, which reads
``user-cred-{credential_id}`` with the existing DB fallback. The only direct
secret reads are the platform fallback keys, through ``secrets_provider`` — the
same source ``llm_resolver`` Tier 3 uses.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.embeddings import Embeddings

from echolib.credential_resolver import (
    resolve_embedding_credential_sync,
    resolve_llm_credential_sync,
)
from echolib.llm_client_builder_v2 import build_embeddings
from echolib.secrets_provider import secrets as secrets_provider

logger = logging.getLogger(__name__)

# The platform's system default embedding model, matching
# apps/knowledge/tasks.py and AgentTools/file_reader/vector_store.py.
DEFAULT_EMBEDDING_MODEL = "embedding_text"

# Providers with a usable embeddings API. Anthropic has none at all; the v2
# builder raises for it, so it is excluded here rather than attempted.
EMBEDDING_PROVIDERS = ("azure", "openai", "ollama", "gemini")

# The user's admin-designated default embedding credential -- the same one
# ``apps/knowledge/embeddings.py`` prefers, via the same resolver call. Tried
# ahead of TIER_USER so an explicit embedding default is not shadowed by a
# guess made from the chat default.
TIER_USER_EMBEDDING_DEFAULT = "user_embedding_default"
TIER_USER = "user_credential"
TIER_PLATFORM = "platform_default"

CACHE_TTL_SECONDS = 900

_lock = threading.Lock()
_cache: Dict[str, Tuple[float, Any]] = {}


class EmbeddingsUnavailable(RuntimeError):
    """No embeddings model could be resolved, or every tier failed."""


def _cached(key: str) -> Optional[Any]:
    with _lock:
        entry = _cache.get(key)
    if entry is None or time.time() - entry[0] > CACHE_TTL_SECONDS:
        return None
    return entry[1]


def _store(key: str, client: Any) -> None:
    with _lock:
        _cache[key] = (time.time(), client)


def reset_cache() -> None:
    """Drop every cached embeddings client. Used when a credential is rotated."""
    with _lock:
        _cache.clear()


# ---------------------------------------------------------------------------
# Candidate tiers
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _Candidate:
    """One tier of the cascade, described but not yet built."""

    tier: str
    provider: str
    model: str
    params: Dict[str, Any] = field(default_factory=dict)

    @property
    def key(self) -> str:
        return f"{self.tier}:{self.provider}:{self.model}"

    def build(self) -> Any:
        cached = _cached(self.key)
        if cached is not None:
            return cached
        client = build_embeddings(
            provider=self.provider, model=self.model, **self.params
        )
        _store(self.key, client)
        return client


def _embedding_model_name(creds: Dict[str, Any]) -> str:
    """
    Pick the embedding deployment for a credential.

    A credential's *chat* deployment is not an embeddings deployment, so only an
    explicit embedding field is honoured and the platform default name is used
    otherwise. ``apps/knowledge/tasks.py:439`` does guess from the chat
    deployment, which is what produces a 404 per document; the cascade below is
    what makes the wrong guess recoverable either way.
    """
    for key in ("embedding_model", "embedding_deployment"):
        value = str(creds.get(key) or "").strip()
        if value:
            return value
    return DEFAULT_EMBEDDING_MODEL


def _user_candidate(
    user_id: str,
    credential_id: Optional[str],
    model_override: Optional[str] = None,
) -> Optional[_Candidate]:
    """The user's own credential — their agent's, else their default LLM."""
    try:
        creds = resolve_llm_credential_sync(user_id, credential_id=credential_id)
    except Exception:
        logger.warning("Credential resolution failed for embeddings", exc_info=True)
        return None

    if not creds:
        return None

    provider = str(creds.get("provider") or "").strip().lower()
    provider = "azure" if provider == "azure_openai" else provider
    if provider not in EMBEDDING_PROVIDERS:
        logger.info(
            "Provider '%s' has no embeddings API; using the platform default", provider
        )
        return None

    base_url = str(creds.get("base_url") or creds.get("endpoint") or "").strip()
    if provider != "gemini" and not base_url:
        return None

    model = str(model_override or "").strip() or _embedding_model_name(creds)
    return _Candidate(
        tier=TIER_USER,
        provider=provider,
        model=model,
        params={
            "api_key": str(creds.get("api_key") or ""),
            "base_url": base_url,
            "api_version": str(creds.get("api_version") or "2024-12-01-preview"),
            "deployment_name": model,
        },
    )


def _embedding_default_candidate(
    user_id: str,
    model_override: Optional[str] = None,
) -> Optional[_Candidate]:
    """
    The user's admin-designated default embedding credential, if any.

    WHAT: Calls the same ``resolve_embedding_credential_sync`` that
          ``apps/knowledge/embeddings.py`` Tier 3 uses, so both cascades agree
          on which credential is "the" embedding default.
    WHY:  ``_user_candidate`` resolves the *chat* default and only then guesses
          whether it can embed. A credential the admin explicitly marked and
          promoted as the embedding default should not wait for that guess to
          fail first.
    """
    try:
        creds = resolve_embedding_credential_sync(user_id)
    except Exception:
        logger.warning("Embedding-default resolution failed", exc_info=True)
        return None

    if not creds:
        return None

    provider = str(creds.get("provider") or "").strip().lower()
    provider = "azure" if provider == "azure_openai" else provider
    if provider not in EMBEDDING_PROVIDERS:
        return None

    base_url = str(creds.get("base_url") or creds.get("endpoint") or "").strip()
    if provider != "gemini" and not base_url:
        return None

    model = (
        str(model_override or "").strip()
        or str(creds.get("embedding_model") or "").strip()
        or _embedding_model_name(creds)
    )
    return _Candidate(
        tier=TIER_USER_EMBEDDING_DEFAULT,
        provider=provider,
        model=model,
        params={
            "api_key": str(creds.get("api_key") or ""),
            "base_url": base_url,
            "api_version": str(creds.get("api_version") or "2024-12-01-preview"),
            "deployment_name": model,
        },
    )


def _platform_candidate() -> Optional[_Candidate]:
    """
    The platform's system default embedding model (``llm_resolver`` Tier 3).

    ``FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT`` is the same variable
    ``apps/knowledge/tasks.py`` and ``AgentTools/file_reader`` already use, so
    one setting is the system default for the whole platform.
    """
    api_key = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_KEY")
        or secrets_provider.get_secret("AZURE_OPENAI_API_KEY", "")
    )
    endpoint = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
        or secrets_provider.get_secret("AZURE_OPENAI_ENDPOINT", "")
    )
    if not (api_key and endpoint):
        return None

    deployment = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
        or DEFAULT_EMBEDDING_MODEL
    )
    return _Candidate(
        tier=TIER_PLATFORM,
        provider="azure",
        model=deployment,
        params={
            "api_key": api_key,
            "base_url": endpoint,
            "api_version": (
                secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_VERSION")
                or "2024-02-01"
            ),
            "deployment_name": deployment,
        },
    )


# ---------------------------------------------------------------------------
# The cascade
# ---------------------------------------------------------------------------

class CascadingEmbeddings(Embeddings):
    """
    An ``Embeddings`` that walks the credential tiers on the *call*, not the build.

    A real ``Embeddings`` subclass because it is handed to the knowledge app's
    retriever, which passes it to FAISS — FAISS rejects anything that is not one.

    The tier that answers first is remembered, so a document's passages are all
    embedded by one model and later calls skip the failed tiers.
    """

    def __init__(self, candidates: List[_Candidate]) -> None:
        self._candidates = list(candidates)
        self._active: Optional[_Candidate] = None
        self._client: Optional[Any] = None

    @property
    def model(self) -> str:
        """The model that actually answered, or the first one due to be tried."""
        if self._active is not None:
            return self._active.model
        return self._candidates[0].model if self._candidates else DEFAULT_EMBEDDING_MODEL

    @property
    def tier(self) -> str:
        if self._active is not None:
            return self._active.tier
        return self._candidates[0].tier if self._candidates else ""

    def _pending(self) -> List[_Candidate]:
        """The active tier first when one is known, otherwise every tier in order."""
        if self._active is None:
            return self._candidates
        return [self._active] + [c for c in self._candidates if c is not self._active]

    def _invoke(self, method: str, payload: Any) -> Any:
        errors: List[str] = []

        for candidate in self._pending():
            try:
                client = candidate.build() if candidate is not self._active else self._client
                if client is None:
                    client = candidate.build()
                result = getattr(client, method)(payload)
            except Exception as exc:
                # Build and call failures are treated alike: both mean this tier
                # cannot embed, and the reason is only knowable by trying.
                errors.append(f"{candidate.tier}({candidate.model}): {exc}")
                logger.warning(
                    "Embedding tier '%s' failed with model '%s': %s",
                    candidate.tier, candidate.model, exc,
                )
                if candidate is self._active:
                    self._active, self._client = None, None
                continue

            if candidate is not self._active:
                logger.info(
                    "Embeddings resolved to tier '%s' (model '%s')",
                    candidate.tier, candidate.model,
                )
                self._active, self._client = candidate, client
            return result

        raise EmbeddingsUnavailable(
            "No embedding model could be used. Add an LLM credential with an "
            "embedding deployment in Settings > LLM Credentials, or ask an "
            "administrator to configure the platform default. Tried: "
            + "; ".join(errors)
        )

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return self._invoke("embed_documents", texts)

    def embed_query(self, text: str) -> List[float]:
        return self._invoke("embed_query", text)


def describe(client: Any) -> str:
    """
    Name the embedding model a client is bound to.

    Recorded on every stored passage. Two vectors from different models occupy
    different spaces and a similarity computed across them is meaningless, so
    the model name is what lets retrieval detect the mismatch instead of ranking
    on noise. For a cascade this is the tier that actually answered, which is
    only known after the first call.
    """
    for attribute in ("model", "azure_deployment", "deployment"):
        value = getattr(client, attribute, None)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return DEFAULT_EMBEDDING_MODEL


def is_credential_id(value: Optional[str]) -> bool:
    """
    True when a value is a credential UUID rather than a model name.

    The knowledge base's ``embedding_model`` column holds either — the model
    picker writes a credential UUID, an API caller may write a plain name.
    ``apps/knowledge/service.py:85`` makes the same distinction; this is that
    rule, exposed so callers do not each reimplement it.
    """
    from uuid import UUID

    if not value:
        return False
    try:
        UUID(str(value))
        return True
    except (ValueError, TypeError, AttributeError):
        return False


def resolve_embeddings(
    user_id: Optional[str],
    credential_id: Optional[str] = None,
    model: Optional[str] = None,
) -> Embeddings:
    """
    Return an embeddings client for indexing and searching this user's sources.

    WHAT: An ``Embeddings`` that tries the user's credential, then the platform
          default, on every call until one answers.
    WHY:  A source that cannot be embedded cannot be retrieved, so this failing
          silently would leave an agent believing it has a document it can never
          read. Resolving at call time is what makes the platform default
          reachable — a client built against a chat-only credential succeeds at
          construction and fails at the first document.
    INPUT: ``model`` pins the embedding model by name, for a store that was
           indexed with a specific one. A query embedded by a different model
           than the passages it searches lands in a different vector space and
           ranks on noise, so this is not cosmetic.
    RAISES: ``EmbeddingsUnavailable`` when no tier is even configured; a tier
            that is configured but fails is reported on the call, naming every
            tier that was tried.
    """
    candidates: List[_Candidate] = []

    if user_id:
        embedding_default = _embedding_default_candidate(user_id, model_override=model)
        if embedding_default is not None:
            candidates.append(embedding_default)

        # The existing chat-credential guess, kept as a fallback tier: it is
        # only a duplicate of the embedding default when both resolved to the
        # same deployment on the same endpoint, in which case retrying it can
        # not produce a different answer.
        user_candidate = _user_candidate(user_id, credential_id, model_override=model)
        if user_candidate is not None and not any(
            c.provider == user_candidate.provider
            and c.model == user_candidate.model
            and c.params.get("base_url") == user_candidate.params.get("base_url")
            for c in candidates
        ):
            candidates.append(user_candidate)

    platform = _platform_candidate()
    if platform is not None:
        # A pinned model must not be silently swapped for the platform's own:
        # falling back would embed the query in a different space from the
        # passages and rank on noise. Better to fail and say so.
        if model and platform.model != model:
            platform = None
        elif any(
            c.provider == platform.provider
            and c.model == platform.model
            and c.params.get("base_url") == platform.params.get("base_url")
            for c in candidates
        ):
            # Retrying the same deployment on the same endpoint cannot produce
            # a different answer.
            platform = None

    if platform is not None:
        candidates.append(platform)

    if not candidates:
        raise EmbeddingsUnavailable(
            "No embedding model is configured. Add an LLM credential in "
            "Settings > LLM Credentials, or ask an administrator to configure "
            "the platform default (FALLBACK_AZURE_OPENAI_*)."
        )

    logger.info(
        "Embedding cascade: %s",
        " -> ".join(f"{c.tier}({c.provider}/{c.model})" for c in candidates),
    )
    return CascadingEmbeddings(candidates)


__all__ = [
    "DEFAULT_EMBEDDING_MODEL",
    "EMBEDDING_PROVIDERS",
    "TIER_PLATFORM",
    "TIER_USER",
    "CascadingEmbeddings",
    "EmbeddingsUnavailable",
    "describe",
    "is_credential_id",
    "reset_cache",
    "resolve_embeddings",
]
