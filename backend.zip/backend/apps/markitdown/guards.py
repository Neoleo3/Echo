"""
What this layer refuses before anything is opened.

WHAT: Filename sanitation, extension allow-list, size ceiling, archive refusal
      and the content hash used to skip repeated work.
WHY:  Conversion runs a large surface of third-party parsers over bytes a user
      supplied. Every one of these checks exists so a parser is never reached
      by input it cannot safely handle.

There is no path handling here. Nothing this package produces is written to
disk: converted sources are stored by the caller, in Postgres.

Refusals raise, with text written for the person who uploaded the file. They
never name a server path.
"""
from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path
from typing import Optional

from . import config
from .errors import SourceTooLargeError, UnsupportedSourceError

logger = logging.getLogger(__name__)

MAX_FILENAME_LENGTH = 180

_UNSAFE_NAME = re.compile(r"[^0-9A-Za-z._\- ]+")

# Extras that are pinned separately. Without them MarkItDown accepts the file
# and returns nothing, which is worse than refusing it.
_EXTRA_REQUIRED = {
    ".wav": "markitdown[audio-transcription]",
    ".mp3": "markitdown[audio-transcription]",
    ".m4a": "markitdown[audio-transcription]",
    ".flac": "markitdown[audio-transcription]",
    ".ogg": "markitdown[audio-transcription]",
}


def safe_filename(filename: Optional[str]) -> str:
    """
    Reduce a client-supplied filename to a display-safe basename.

    Only the name survives — never a directory component. Nothing here is
    written to disk, so this is not a path control; it exists so a crafted name
    cannot reach a log line, an API response or a descriptor with control
    characters or separators in it. The result is used for display and to derive
    the extension.
    """
    raw = Path(str(filename or "")).name
    cleaned = _UNSAFE_NAME.sub("_", raw).strip(" ._")
    cleaned = re.sub(r"_+", "_", cleaned)
    return (cleaned or "upload")[:MAX_FILENAME_LENGTH]


def extension_of(filename: str) -> str:
    return Path(safe_filename(filename)).suffix.lower()


def check_extension(filename: str) -> str:
    """
    Verify the extension is one this layer accepts.

    Returns the normalized extension. Raises ``UnsupportedSourceError`` with a
    message naming what is supported, so the refusal is actionable.
    """
    extension = extension_of(filename)

    if not extension:
        raise UnsupportedSourceError(
            "This file has no extension, so its type cannot be determined. "
            "Rename it with the correct extension and try again."
        )

    if extension in config.ARCHIVE_EXTENSIONS:
        raise UnsupportedSourceError(
            "Archives are not accepted. Extract the files you need and upload "
            "them individually."
        )

    if extension not in config.allowed_extensions():
        raise UnsupportedSourceError(
            f"'{extension}' files are not supported. Supported types include "
            "PDF, Word, Excel, PowerPoint, CSV, HTML, Markdown, text, EPUB, "
            "Outlook messages and images."
        )

    required_extra = _EXTRA_REQUIRED.get(extension)
    if required_extra and not _audio_support_installed():
        raise UnsupportedSourceError(
            f"Audio files are not supported on this server. Install "
            f"{required_extra} to enable transcription."
        )

    return extension


def _audio_support_installed() -> bool:
    try:
        import pydub  # noqa: F401
        import speech_recognition  # noqa: F401
    except Exception:
        return False
    return True


def check_size(size_bytes: int, label: str = "This file") -> None:
    """Raise when a source is larger than the configured ceiling."""
    ceiling = config.max_file_bytes()
    if size_bytes > ceiling:
        raise SourceTooLargeError(
            f"{label} is {size_bytes / (1024 * 1024):.1f} MB, which is over the "
            f"{ceiling // (1024 * 1024)} MB limit."
        )


def content_hash(data: bytes) -> str:
    """SHA-256 of the raw bytes — the identity used to skip repeated work."""
    return hashlib.sha256(data).hexdigest()


__all__ = [
    "check_extension",
    "check_size",
    "content_hash",
    "extension_of",
    "safe_filename",
]
