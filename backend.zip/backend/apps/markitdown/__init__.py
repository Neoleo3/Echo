"""
MarkItDown layer — every file and URL this platform reads becomes markdown here.

WHAT: A self-contained package that turns an uploaded file or a web address
      into markdown, splits it, embeds it, and ranks those embeddings against a
      query. Built on Microsoft MarkItDown (https://github.com/microsoft/markitdown).
WHY:  Before this, document text extraction was a per-extension function inside
      one app, reachable only from that app, and no agent could see a file at
      all. This package owns the whole path from bytes to retrievable passage
      and knows nothing about agents, so it can serve any caller.

**Nothing here performs I/O beyond conversion — no filesystem, no database.**
``ingest_file`` and ``ingest_url`` return an ``IngestResult`` carrying the
original bytes, the converted markdown and the embedded chunks; the caller
writes them wherever it keeps state. This platform writes them to Postgres,
because it runs on cloud containers with more than one replica and no shared
disk: a file written to local disk by one replica is invisible to the next and
gone after a restart.

Public surface — the only names anything outside this package should import::

    ingest_file (data=, filename=, user_id=, credential_id=)  -> IngestResult
    ingest_url  (url=, name=, user_id=, credential_id=)       -> IngestResult
    reingest    (record=, user_id=, credential_id=)           -> IngestResult
    embed_query (query, user_id=, credential_id=)             -> list[float]
    search_chunks(query_vector, rows, top_k=)                 -> list[ScoredChunk]
    read_text   (record, offset=, limit=)                     -> str
    backend_status(user_id=)                                  -> dict

Design notes worth knowing before changing anything in here:

* **MarkItDown never touches the network.** It is constructed with a session
  that refuses every request, and only ``convert_local`` / ``convert_stream`` /
  ``convert_response`` are called. URL fetching lives in ``fetcher``, behind an
  address guard, because ``convert_uri`` performs no such check.
* **Plugins are disabled.** ``markitdown-ocr`` requires PyMuPDF (AGPL-3.0);
  its three capabilities — OCR of embedded images, scanned-PDF OCR and
  malformed-PDF recovery — are reimplemented in ``ocr_fallback`` on PDFium,
  which is Apache-2.0 / BSD-3.
* **Credentials come from the platform cascade.** ``credentials`` and
  ``embeddings`` both resolve through ``echolib.credential_resolver``, so the
  agent's own model, then the user's default LLM, then the platform default
  apply here exactly as they do everywhere else. No key is read from the
  environment for a user credential, logged, or persisted.
* **Everything is synchronous and blocking.** Callers on an event loop must use
  ``asyncio.to_thread``.
"""
from __future__ import annotations

from .converter import ConversionResult, markitdown_available
from .credentials import VisionBinding, resolve_vision_binding
from .errors import (
    BlockedUrlError,
    ConversionError,
    MarkItDownError,
    MarkItDownUnavailable,
    SourceTooLargeError,
    UnsupportedSourceError,
)
from .service import (
    MODE_INLINE,
    MODE_RETRIEVAL,
    SOURCE_FILE,
    SOURCE_URL,
    STATUS_FAILED,
    STATUS_READY,
    EmbeddedChunk,
    IngestResult,
    backend_status,
    embed_query,
    ingest_file,
    ingest_url,
    new_source_id,
    read_text,
    reingest,
    search_chunks,
)
from .similarity import ScoredChunk

__all__ = [
    "MODE_INLINE",
    "MODE_RETRIEVAL",
    "SOURCE_FILE",
    "SOURCE_URL",
    "STATUS_FAILED",
    "STATUS_READY",
    "BlockedUrlError",
    "ConversionError",
    "ConversionResult",
    "EmbeddedChunk",
    "IngestResult",
    "MarkItDownError",
    "MarkItDownUnavailable",
    "ScoredChunk",
    "SourceTooLargeError",
    "UnsupportedSourceError",
    "VisionBinding",
    "backend_status",
    "embed_query",
    "ingest_file",
    "ingest_url",
    "markitdown_available",
    "new_source_id",
    "read_text",
    "reingest",
    "resolve_vision_binding",
    "search_chunks",
]
