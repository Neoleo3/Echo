"""
The one entry point: a file or a URL in, stored-ready context out.

WHAT: ``ingest_file`` and ``ingest_url`` — guard, convert, OCR, route, chunk and
      embed — returning everything the caller needs to persist. Plus
      ``embed_query`` and ``search_chunks`` for the retrieval side.
WHY:  Callers should not have to know that a PDF is guarded, hashed, converted,
      possibly OCR'd, split and embedded in that order. One call, one result
      object, one place where the order is decided.

**This module performs no I/O beyond conversion.** No filesystem, no database.
An ``IngestResult`` carries the original bytes, the converted markdown and the
embedded chunks, and the caller writes them wherever it keeps state — Postgres,
in this platform. That is what makes the package work on cloud containers with
more than one replica and no shared disk, and what keeps it reusable by any
caller with its own schema.

Everything here is synchronous and blocking: conversion parses documents, OCR
makes network calls and embedding makes more. Callers on an event loop must run
these inside ``asyncio.to_thread``.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from . import chunking, config, converter, embeddings, fetcher, guards, similarity
from .credentials import resolve_vision_binding
from .errors import MarkItDownError
from .similarity import ScoredChunk

logger = logging.getLogger(__name__)

SOURCE_FILE = "file"
SOURCE_URL = "url"

MODE_INLINE = "inline"
MODE_RETRIEVAL = "retrieval"

STATUS_READY = "ready"
STATUS_FAILED = "failed"


@dataclass(frozen=True)
class EmbeddedChunk:
    """One retrievable passage, ready to be written to a row."""

    chunk_index: int
    content: str
    embedding: bytes
    dimensions: int
    embedding_model: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chunk_index": self.chunk_index,
            "content": self.content,
            "embedding": self.embedding,
            "dimensions": self.dimensions,
            "embedding_model": self.embedding_model,
        }


@dataclass(frozen=True)
class IngestResult:
    """
    Everything the caller needs to persist and describe one attached source.

    ``content_bytes`` is the original, kept so the source can be converted
    again — that is how a newly-configured vision model reaches a document
    without asking the user to upload it twice. ``content_md`` is the converted
    markdown, kept for whole-document reads. ``chunks`` is empty for inline
    sources, which are injected whole instead of retrieved.

    No path, no handle, no secret.
    """

    source_id: str
    name: str
    source_type: str = SOURCE_FILE
    url: Optional[str] = None
    format: str = ""
    mime_type: Optional[str] = None
    size_bytes: int = 0
    content_hash: Optional[str] = None
    content_bytes: Optional[bytes] = None
    content_md: Optional[str] = None
    ingest_mode: str = MODE_RETRIEVAL
    status: str = STATUS_READY
    converted_by: Optional[str] = None
    ocr_skipped_reason: Optional[str] = None
    embedding_model: Optional[str] = None
    chunks: List[EmbeddedChunk] = field(default_factory=list)
    char_count: int = 0
    error_message: Optional[str] = None
    title: Optional[str] = None

    @property
    def succeeded(self) -> bool:
        return self.status == STATUS_READY

    @property
    def chunk_count(self) -> int:
        return len(self.chunks)

    def row(self) -> Dict[str, Any]:
        """
        The source's own columns, without the chunks.

        Chunks are a separate table, so they are handed over separately rather
        than nested in a payload the repository would have to unpick.
        """
        return {
            "name": self.name,
            "source_type": self.source_type,
            "url": self.url,
            "format": self.format,
            "mime_type": self.mime_type,
            "size_bytes": self.size_bytes,
            "content_hash": self.content_hash,
            "content_bytes": self.content_bytes,
            "content_md": self.content_md,
            "ingest_mode": self.ingest_mode,
            "status": self.status,
            "converted_by": self.converted_by,
            "ocr_skipped_reason": self.ocr_skipped_reason,
            "embedding_model": self.embedding_model,
            "char_count": self.char_count,
            "chunk_count": self.chunk_count,
            "error_message": self.error_message,
        }


def _failure(source_id: str, name: str, source_type: str, message: str, **extra: Any) -> IngestResult:
    logger.warning("Ingest failed for '%s': %s", name, message)
    return IngestResult(
        source_id=source_id,
        name=name,
        source_type=source_type,
        status=STATUS_FAILED,
        error_message=message,
        **extra,
    )


def new_source_id() -> str:
    from uuid import uuid4

    return str(uuid4())


# ---------------------------------------------------------------------------
# Shared tail: route, chunk, embed
# ---------------------------------------------------------------------------

def _embed_chunks(
    documents: Sequence[Any],
    *,
    user_id: Optional[str],
    credential_id: Optional[str],
) -> tuple:
    """
    Embed every chunk and pack the vectors for storage.

    Returns ``(chunks, model_name)``. Raises so the caller records the source as
    failed: a source that is stored as ready but has no vectors is retrievable
    by nothing, and the agent would be told it has a document it can never read.
    """
    texts = [document.page_content for document in documents]
    client = embeddings.resolve_embeddings(user_id, credential_id)

    # Embed first, name the model second. The cascade resolves on the call, so
    # which tier answered is only known afterwards -- naming it first would
    # stamp every passage with a model that never embedded it, and would then
    # mislead the dimension check that exists to catch exactly that.
    vectors = client.embed_documents(texts)
    model_name = embeddings.describe(client)
    if len(vectors) != len(texts):
        raise MarkItDownError(
            "The embedding model returned a different number of vectors than "
            "passages. This document was not indexed."
        )

    packed = [
        EmbeddedChunk(
            chunk_index=index,
            content=texts[index],
            embedding=similarity.encode(vector),
            dimensions=len(vector),
            embedding_model=model_name,
        )
        for index, vector in enumerate(vectors)
    ]
    return packed, model_name


def _complete(
    *,
    source_id: str,
    name: str,
    source_type: str,
    result: converter.ConversionResult,
    user_id: Optional[str],
    credential_id: Optional[str],
    **record: Any,
) -> IngestResult:
    """
    Route converted markdown to inline or retrieval and finish the result.

    Short sources are carried inline: they are injected into the agent's prompt
    whole, which is both cheaper and more faithful than retrieving three chunks
    of a two-page memo. Anything longer is chunked and embedded.

    The converted markdown is kept either way — whole-document reads need it,
    and re-indexing after an embedding-model change must not re-convert.
    """
    markdown = result.markdown

    common: Dict[str, Any] = {
        "source_id": source_id,
        "name": name,
        "source_type": source_type,
        "content_md": markdown,
        "converted_by": result.converted_by,
        "ocr_skipped_reason": result.ocr_skipped_reason,
        "char_count": result.char_count,
        "title": result.title,
        **record,
    }

    if result.char_count <= config.inline_max_chars():
        logger.info("Source '%s' attached inline (%d chars)", name, result.char_count)
        return IngestResult(ingest_mode=MODE_INLINE, status=STATUS_READY, **common)

    documents = chunking.split_markdown(markdown)
    if not documents:
        return IngestResult(ingest_mode=MODE_INLINE, status=STATUS_READY, **common)

    try:
        chunks, model_name = _embed_chunks(
            documents, user_id=user_id, credential_id=credential_id
        )
    except MarkItDownError as exc:
        return _failure(source_id, name, source_type, str(exc), content_md=markdown)
    except Exception as exc:
        return _failure(
            source_id, name, source_type,
            f"This document was read but could not be indexed: {exc}",
            content_md=markdown,
        )

    logger.info("Source '%s' embedded into %d chunk(s)", name, len(chunks))
    return IngestResult(
        ingest_mode=MODE_RETRIEVAL,
        status=STATUS_READY,
        chunks=chunks,
        embedding_model=model_name,
        **common,
    )


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------

def ingest_file(
    *,
    data: bytes,
    filename: str,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    source_id: Optional[str] = None,
    mime_type: Optional[str] = None,
    keep_original: bool = True,
) -> IngestResult:
    """
    Guard, convert and embed one uploaded file.

    WHAT: The whole file path, from raw bytes to storable context.
    WHY:  One call site means the order of the guards is decided once and
          cannot be skipped by a new caller.
    INPUT: The file's bytes and its client-supplied name.
    OUTPUT: An ``IngestResult``; failures are values, not exceptions, so one
            bad file in a multi-file upload does not abort the others.

    ``keep_original`` carries the source bytes back for storage. Turning it off
    halves what is written at the cost of losing the ability to re-convert
    without a re-upload.
    """
    identifier = source_id or new_source_id()
    name = guards.safe_filename(filename)

    try:
        extension = guards.check_extension(name)
        guards.check_size(len(data), f"'{name}'")
    except MarkItDownError as exc:
        return _failure(identifier, name, SOURCE_FILE, str(exc))

    content_hash = guards.content_hash(data)
    binding = resolve_vision_binding(user_id, credential_id)

    try:
        result = converter.convert_bytes(
            data, filename=name, mimetype=mime_type, binding=binding
        )
    except MarkItDownError as exc:
        return _failure(
            identifier, name, SOURCE_FILE, str(exc),
            format=extension.lstrip("."),
            size_bytes=len(data),
            content_hash=content_hash,
            content_bytes=data if keep_original else None,
        )

    return _complete(
        source_id=identifier,
        name=name,
        source_type=SOURCE_FILE,
        result=result,
        user_id=user_id,
        credential_id=credential_id,
        format=extension.lstrip("."),
        mime_type=mime_type,
        size_bytes=len(data),
        content_hash=content_hash,
        content_bytes=data if keep_original else None,
    )


# ---------------------------------------------------------------------------
# URLs
# ---------------------------------------------------------------------------

def ingest_url(
    *,
    url: str,
    name: Optional[str] = None,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    source_id: Optional[str] = None,
) -> IngestResult:
    """
    Fetch a URL under the SSRF guard, convert it and embed it.

    The fetched page body is not kept: for a web address the converted markdown
    *is* the retained copy, and re-fetching is what a refresh is for.
    """
    identifier = source_id or new_source_id()
    label = (name or url or "").strip() or url

    try:
        fetched = fetcher.fetch(url)
    except MarkItDownError as exc:
        return _failure(identifier, label, SOURCE_URL, str(exc), url=url)

    binding = resolve_vision_binding(user_id, credential_id)

    try:
        result = converter.convert_response(fetched.response, binding=binding)
    except MarkItDownError as exc:
        return _failure(
            identifier, label, SOURCE_URL, str(exc),
            url=fetched.final_url, size_bytes=fetched.size_bytes,
        )

    display = name.strip() if name and name.strip() else fetcher.display_name(
        fetched.final_url, result.title
    )

    return _complete(
        source_id=identifier,
        name=guards.safe_filename(display) or display,
        source_type=SOURCE_URL,
        result=result,
        user_id=user_id,
        credential_id=credential_id,
        url=fetched.final_url,
        format="url",
        mime_type=(fetched.content_type or "").split(";")[0] or None,
        size_bytes=fetched.size_bytes,
        content_hash=guards.content_hash(result.markdown.encode("utf-8")),
    )


def reingest(
    *,
    record: Dict[str, Any],
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
) -> IngestResult:
    """
    Convert and embed one source again, from what was stored.

    A URL is re-fetched, so refreshing picks up a changed page. A file is
    re-read from its stored bytes, so refreshing applies a newly-configured
    vision model without asking the user to upload it again.
    """
    source_id = str(record.get("source_id") or record.get("id") or new_source_id())
    name = str(record.get("name") or "source")

    if str(record.get("source_type")) == SOURCE_URL:
        return ingest_url(
            url=str(record.get("url") or ""),
            name=name,
            user_id=user_id,
            credential_id=credential_id,
            source_id=source_id,
        )

    data = record.get("content_bytes")
    if not data:
        return _failure(
            source_id, name, SOURCE_FILE,
            "The stored copy of this file is no longer available. Upload it again.",
        )

    return ingest_file(
        data=bytes(data),
        filename=name,
        user_id=user_id,
        credential_id=credential_id,
        source_id=source_id,
        mime_type=record.get("mime_type"),
    )


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

def embed_query(
    query: str,
    *,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
) -> List[float]:
    """
    Embed a search query with the same cascade used to embed the chunks.

    Returns an empty list when no embedding model resolves, which the caller
    reports as "nothing matched" rather than as an error: a retrieval that
    cannot run must not look like a retrieval that found nothing relevant, but
    it also must not fail an agent's turn.
    """
    text = str(query or "").strip()
    if not text:
        return []

    try:
        client = embeddings.resolve_embeddings(user_id, credential_id)
        return list(client.embed_query(text))
    except Exception:
        logger.warning("Query could not be embedded", exc_info=True)
        return []


def search_chunks(
    query_vector: Sequence[float],
    rows: Sequence[Dict[str, Any]],
    *,
    top_k: Optional[int] = None,
) -> List[ScoredChunk]:
    """
    Rank stored chunk rows against an embedded query.

    Rows come from the caller's own store, already scoped to the sources the
    agent may currently read.
    """
    return similarity.search_rows(
        query_vector, rows, top_k=int(top_k or config.search_top_k())
    )


def read_text(record: Dict[str, Any], *, offset: int = 0, limit: int = 8000) -> str:
    """
    Return a span of one source's converted text.

    WHAT: Reads the stored markdown.
    WHY:  Similarity search is the wrong retrieval for "summarize this
          document" — the agent needs the text in order, not the three passages
          closest to a query it had to invent.
    """
    text = record.get("content_md")
    if not isinstance(text, str) or not text:
        return ""

    start = max(0, int(offset))
    return text[start:start + max(1, int(limit))]


def backend_status(user_id: Optional[str] = None) -> Dict[str, Any]:
    """What this instance can convert right now, and why not if it cannot."""
    return converter.backend_status(user_id)


__all__ = [
    "MODE_INLINE",
    "MODE_RETRIEVAL",
    "SOURCE_FILE",
    "SOURCE_URL",
    "STATUS_FAILED",
    "STATUS_READY",
    "EmbeddedChunk",
    "IngestResult",
    "ScoredChunk",
    "backend_status",
    "embed_query",
    "ingest_file",
    "ingest_url",
    "new_source_id",
    "read_text",
    "reingest",
    "search_chunks",
]
