"""
Every knob the MarkItDown layer reads, in one place.

WHAT: Environment-backed configuration for conversion, OCR, URL fetching,
      storage, chunking and the agent-facing budgets.
WHY:  Phase 5b learned that scattering ``os.getenv`` through a package makes
      the effective configuration impossible to state. One module means one
      answer to "what is this instance actually doing".

Nothing here reads a credential. Credentials resolve through
``apps.markitdown.credentials``, which goes to the platform cascade and Key
Vault; no key is ever read from the environment by this package.
"""
from __future__ import annotations

import os
from typing import List, Optional, Set

# ---------------------------------------------------------------------------
# Size and shape limits
# ---------------------------------------------------------------------------

def _int_env(name: str, default: int, minimum: int = 0) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def _bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _setting(name: str, default: int) -> int:
    """Read a tuning value from ``echolib.config``, degrading to *default*.

    Imported lazily: ``echolib.config`` loads dotenv and initialises the secrets
    provider at import time, and this module is imported by the converter on
    paths that must not depend on that.
    """
    try:
        from echolib.config import settings

        return int(getattr(settings, name, default))
    except Exception:  # noqa: BLE001 -- tuning must never fail a conversion
        return default


def max_file_bytes() -> int:
    """Largest source this layer will accept, in bytes."""
    return _int_env("MARKITDOWN_MAX_FILE_MB", 25, minimum=1) * 1024 * 1024


def inline_max_chars() -> int:
    """
    Converted-markdown length below which a source is carried inline.

    Inline sources are injected into the agent's prompt whole and skip
    embedding entirely; anything larger is chunked and retrieved.
    """
    return _int_env("MARKITDOWN_INLINE_MAX_CHARS", 12000, minimum=500)


def chunk_size() -> int:
    return _int_env("MARKITDOWN_CHUNK_SIZE", 1000, minimum=100)


def chunk_overlap() -> int:
    return _int_env("MARKITDOWN_CHUNK_OVERLAP", 200, minimum=0)


# ---------------------------------------------------------------------------
# OCR
# ---------------------------------------------------------------------------

def ocr_enabled() -> bool:
    """Master switch for vision OCR. Off means text extraction only."""
    return _bool_env("MARKITDOWN_ENABLE_OCR", True)


def ocr_dpi() -> int:
    """
    Render resolution for scanned-PDF pages.

    200 rather than 300: a vision model reads a 200 DPI page as reliably as a
    300 DPI one for text, and the payload is roughly half the size, which is
    what the call actually costs.
    """
    return _int_env("MARKITDOWN_OCR_DPI", 200, minimum=72)


def ocr_max_pages() -> int:
    """Ceiling on rendered pages per PDF. Each page is one vision call."""
    return _int_env("MARKITDOWN_OCR_MAX_PAGES", 20, minimum=1)


def ocr_max_images() -> int:
    """Ceiling on embedded images OCR'd per document."""
    return _int_env("MARKITDOWN_OCR_MAX_IMAGES", 20, minimum=1)


def ocr_min_page_chars() -> int:
    """
    Characters of extractable text below which a PDF page counts as scanned.

    A page with a handful of stray glyphs from a header is still an image for
    every practical purpose, so the threshold is not zero.
    """
    return _int_env("MARKITDOWN_OCR_MIN_PAGE_CHARS", 40, minimum=0)


DEFAULT_VISION_MODELS = (
    "gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
    "gpt-5", "gpt-4-turbo", "gpt-4-vision", "o1", "o3", "o4-mini",
    "llama3.2-vision", "llava", "pixtral", "qwen2-vl", "qwen2.5-vl",
)


def vision_models() -> List[str]:
    """
    Model-name fragments treated as vision-capable.

    Checked as a substring against the resolved deployment or model name, so a
    deployment called ``prod-gpt-4o-eastus`` matches. Overridable because
    deployment naming is a customer decision, not a platform one.
    """
    configured = os.getenv("MARKITDOWN_VISION_MODELS", "").strip()
    if configured:
        return [part.strip().lower() for part in configured.split(",") if part.strip()]
    return list(DEFAULT_VISION_MODELS)


def docintel_endpoint() -> Optional[str]:
    """Azure Document Intelligence endpoint, when one is configured."""
    value = os.getenv("AZURE_DOCINTEL_ENDPOINT", "").strip()
    return value or None


# ---------------------------------------------------------------------------
# URL fetching
# ---------------------------------------------------------------------------

def url_timeout_seconds() -> int:
    return _int_env("MARKITDOWN_URL_TIMEOUT", 30, minimum=1)


def url_max_redirects() -> int:
    return _int_env("MARKITDOWN_URL_MAX_REDIRECTS", 3, minimum=0)


def allow_private_urls() -> bool:
    """
    Permit fetching private, loopback and link-local addresses.

    Off by default and intended only for a self-hosted deployment whose
    document sources genuinely live on an internal network. Turning it on
    removes the SSRF control.
    """
    return _bool_env("MARKITDOWN_ALLOW_PRIVATE_URLS", False)


USER_AGENT = "EchoAI-MarkItDown/1.0"


# ---------------------------------------------------------------------------
# Accepted sources
# ---------------------------------------------------------------------------

# Extensions MarkItDown's built-in converters handle. Kept explicit rather than
# probed: an unknown extension must be refused at the boundary with a message,
# not accepted and then silently converted to nothing.
DOCUMENT_EXTENSIONS = (
    ".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt",
    ".csv", ".tsv", ".json", ".xml", ".html", ".htm", ".md", ".markdown",
    ".txt", ".rst", ".log", ".ipynb", ".epub", ".msg", ".rtf", ".yaml", ".yml",
)

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif", ".webp")

# Requires the markitdown[audio-transcription] extra. Refused with a clear
# message when the extra is absent rather than yielding empty text.
AUDIO_EXTENSIONS = (".wav", ".mp3", ".m4a", ".flac", ".ogg")

# Refused outright: MarkItDown's ZipConverter iterates archive contents with no
# bound on entry count or expanded size.
ARCHIVE_EXTENSIONS = (".zip", ".tar", ".gz", ".tgz", ".bz2", ".7z", ".rar", ".xz")


def allowed_extensions() -> Set[str]:
    """Every extension this layer accepts."""
    return set(DOCUMENT_EXTENSIONS) | set(IMAGE_EXTENSIONS) | set(AUDIO_EXTENSIONS)


# ---------------------------------------------------------------------------
# Agent-facing budgets
# ---------------------------------------------------------------------------

def context_call_limit() -> int:
    """Per-run ceiling on retrieval calls made by an agent's context tools."""
    return _int_env("AGENT_MAX_CONTEXT_CALLS", 8, minimum=1)


def context_token_budget() -> int:
    """
    Combined descriptor allowance across connectors *and* attached sources.

    One budget, not one each: context exhaustion is a property of the prompt,
    so a wide database schema and a large document set have to compete for the
    same space rather than each claiming their own.

    Tuned in ``echolib.config`` as ``agent_context_token_budget``. This is how
    much of an uploaded document reaches the prompt directly -- at the previous
    3,000 an agent asked to analyse an architecture document saw roughly twelve
    thousand characters of it inline and had to spend tool calls retrieving the
    rest. The existing environment variable still overrides, so a deployment
    that already sets it is unaffected.
    """
    return _int_env("AGENT_CONTEXT_TOKEN_BUDGET", _setting("agent_context_token_budget", 3000), minimum=400)


def inline_content_chars() -> int:
    """
    Total characters of inline document text injected into one prompt.

    Kept separate from the descriptor budget on purpose. A descriptor is
    metadata the platform generates and can trim freely; inline content is a
    document the user deliberately attached, and silently trimming it would
    make the agent answer from half a memo without knowing. Sources that do not
    fit are still attached and still readable through ``files__read`` — they
    simply are not pre-loaded.
    """
    return _int_env("AGENT_INLINE_CONTENT_CHARS", 24000, minimum=1000)


def context_prefetch_enabled() -> bool:
    """
    Retrieve from the agent's own sources before the model's first turn.

    On. Without it retrieval is entirely model-elective: the agent is handed
    ``files__search`` / ``kb__<alias>`` and a descriptor, and asked to use them.
    Inside a workflow node the model receives a fully-formed task from upstream
    and answers it directly, so an attached knowledge base contributes nothing
    and the run record shows the source resolved with zero tool calls against
    it.

    One query-scoped retrieval per build restores the floor every production
    document-grounded assistant has -- OpenAI's File Search forces the first
    call and then drops to elective, and LangChain's own guidance for a
    guaranteed retrieval is to do it in middleware rather than to force a tool
    call, which also saves a model round trip. The tools stay bound, so the
    agent can still search again with better terms.
    """
    return _bool_env("AGENT_CONTEXT_PREFETCH", True)


def context_prefetch_chars() -> int:
    """
    Ceiling on the pre-retrieved evidence block injected into one prompt.

    Separate from ``inline_content_chars``: that is whole documents the user
    attached, this is passages the platform selected for one request.
    """
    return _int_env("AGENT_CONTEXT_PREFETCH_CHARS", 6000, minimum=500)


def context_prefetch_top_k() -> int:
    """Passages taken per source on the pre-retrieval pass."""
    return _int_env("AGENT_CONTEXT_PREFETCH_TOP_K", 5, minimum=1)


def search_top_k() -> int:
    return _int_env("MARKITDOWN_SEARCH_TOP_K", 5, minimum=1)


def max_search_chunks() -> int:
    """
    Ceiling on chunks loaded for one similarity search.

    Retrieval scores an agent's own passages in memory, which is bounded by
    construction — one agent's attachments, not a shared corpus. This is the
    guard against that assumption being wrong: past this many chunks the search
    is truncated and a warning names the agent, which is the signal that the
    store should move to a real vector index.
    """
    return _int_env("MARKITDOWN_MAX_SEARCH_CHUNKS", 2000, minimum=50)


def keep_originals() -> bool:
    """
    Retain each uploaded file's original bytes.

    On means a source can be converted again without a re-upload, which is how
    a newly-configured vision model reaches a document already attached. Off
    roughly halves what is stored per attachment.
    """
    return _bool_env("MARKITDOWN_KEEP_ORIGINALS", True)


__all__ = [
    "ARCHIVE_EXTENSIONS",
    "AUDIO_EXTENSIONS",
    "DOCUMENT_EXTENSIONS",
    "IMAGE_EXTENSIONS",
    "USER_AGENT",
    "allow_private_urls",
    "allowed_extensions",
    "chunk_overlap",
    "chunk_size",
    "context_call_limit",
    "context_token_budget",
    "docintel_endpoint",
    "inline_content_chars",
    "inline_max_chars",
    "keep_originals",
    "max_file_bytes",
    "max_search_chunks",
    "ocr_dpi",
    "ocr_enabled",
    "ocr_max_images",
    "ocr_max_pages",
    "ocr_min_page_chars",
    "search_top_k",
    "url_max_redirects",
    "url_timeout_seconds",
    "vision_models",
]
