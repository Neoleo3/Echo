"""
Converted markdown split into retrievable chunks.

WHAT: A two-stage split — by markdown heading, then by character count — that
      turns one document into ``Document`` objects carrying their source.
WHY:  MarkItDown emits structured markdown, so splitting on headings first
      keeps a table with its caption and a section with its title. Splitting on
      characters alone cuts through both and produces chunks that retrieve
      badly.

Self-contained on purpose: this package owns everything from bytes to
retrievable chunk, so it can be used outside agents later without importing
another app's internals.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from . import config

logger = logging.getLogger(__name__)

HEADERS_TO_SPLIT_ON = [
    ("#", "header_1"),
    ("##", "header_2"),
    ("###", "header_3"),
    ("####", "header_4"),
]

SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


def split_markdown(
    markdown: str,
    *,
    chunk_size: Optional[int] = None,
    chunk_overlap: Optional[int] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> List[Any]:
    """
    Split converted markdown into ``Document`` chunks.

    WHAT: Heading split, then recursive character split of anything still too
          large, in document order.
    WHY:  Chunk order is the retrieval unit's identity — the caller stores each
          chunk against its index, and that index is what lets a passage be
          traced back to its position in the document.
    INPUT: Markdown text and the chunk geometry (defaults from ``config``).
    OUTPUT: A list of LangChain ``Document`` objects, possibly empty.

    ``metadata`` is merged onto every chunk when given. The agent path does not
    use it — source identity lives in the chunk's database row rather than in
    the vector payload — but it is kept for callers that index into a store
    with no schema of their own.
    """
    text = (markdown or "").strip()
    if not text:
        return []

    from langchain_core.documents import Document
    from langchain_text_splitters import (
        MarkdownHeaderTextSplitter,
        RecursiveCharacterTextSplitter,
    )

    size = int(chunk_size or config.chunk_size())
    overlap = int(chunk_overlap or config.chunk_overlap())

    try:
        header_splits = MarkdownHeaderTextSplitter(
            headers_to_split_on=HEADERS_TO_SPLIT_ON,
            strip_headers=False,
        ).split_text(text)
    except Exception:
        # A document with no headings, or markdown the splitter cannot parse,
        # is still a document. Fall back to one span rather than losing it.
        logger.debug("Header split failed; using the whole document", exc_info=True)
        header_splits = [Document(page_content=text, metadata={})]

    recursive = RecursiveCharacterTextSplitter(
        chunk_size=size,
        chunk_overlap=overlap,
        separators=SEPARATORS,
    )

    chunks: List[Any] = []
    for document in recursive.split_documents(header_splits):
        merged = dict(document.metadata or {})
        merged["chunk_index"] = len(chunks)
        if metadata:
            merged.update(metadata)
        chunks.append(Document(page_content=document.page_content, metadata=merged))

    logger.info("Split %d characters into %d chunk(s)", len(text), len(chunks))
    return chunks


__all__ = ["HEADERS_TO_SPLIT_ON", "split_markdown"]
