"""
Failure modes of the MarkItDown layer, as types.

WHAT: One exception per way a source can fail to become markdown.
WHY:  The routes above this layer map failures to status codes, and the agent
      descriptor tells the model *why* a source is unusable. Both need the
      reason as a value, not as a string parsed out of a log line.

Every error carries text written for the person who attached the source. It is
safe to return verbatim in an API response — no path, no credential, no
internal identifier is ever interpolated into these messages.
"""
from __future__ import annotations


class MarkItDownError(Exception):
    """Base class for everything this package raises."""


class MarkItDownUnavailable(MarkItDownError):
    """
    The ``markitdown`` package is not installed.

    Raised rather than degraded deliberately: a source that silently converts
    to an empty string is worse than one that fails, because the agent then
    reasons from nothing while the UI reports success.
    """


class UnsupportedSourceError(MarkItDownError):
    """The extension is not one this layer accepts, or its extra is missing."""


class SourceTooLargeError(MarkItDownError):
    """The source exceeds the configured size ceiling."""


class BlockedUrlError(MarkItDownError):
    """The URL is malformed, uses a refused scheme, or resolves to a blocked address."""


class ConversionError(MarkItDownError):
    """Conversion ran and failed, or produced no text at all."""


class IndexError_(MarkItDownError):
    """Chunking or embedding failed. Named with a trailing underscore to avoid shadowing the builtin."""


__all__ = [
    "BlockedUrlError",
    "ConversionError",
    "IndexError_",
    "MarkItDownError",
    "MarkItDownUnavailable",
    "SourceTooLargeError",
    "UnsupportedSourceError",
]
