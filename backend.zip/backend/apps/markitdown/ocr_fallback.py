"""
Vision OCR for scanned pages and embedded images, without PyMuPDF.

WHAT: Replaces the three things the ``markitdown-ocr`` plugin adds on top of
      MarkItDown core — OCR of images embedded in PDF/DOCX/PPTX/XLSX,
      full-page OCR for scanned PDFs, and recovery of malformed PDFs.
WHY:  ``markitdown-ocr`` requires ``pymupdf>=1.24.0``. PyMuPDF is AGPL-3.0,
      which ``requirements.txt`` records a decision to move away from, and a
      commercial licence is a recurring cost for one narrow feature. MarkItDown
      core itself has no such dependency, so only the plugin is dropped.

The replacement uses the same mechanism production assistants use for PDFs —
render the page to an image and give it to a vision model — rather than
classical OCR:

    scanned / malformed PDF   pypdfium2 renders the page   (Apache-2.0 / BSD-3, PDFium)
    DOCX / PPTX / XLSX        images read from the OOXML zip container (stdlib)
    the vision call itself    the same llm_client MarkItDown would have used

This runs as its own pass beside ``md.convert_*()``, not as a registered
MarkItDown plugin, so MarkItDown's structure-preserving output is kept intact
and the OCR blocks are appended to it.

MarkItDown core still handles standalone images and PPTX slide pictures through
its own ``llm_client`` captioning; this module never duplicates that work.
"""
from __future__ import annotations

import base64
import io
import logging
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

from . import config
from .credentials import VisionBinding

logger = logging.getLogger(__name__)

OCR_PROMPT = (
    "Extract all text from this image exactly as written. Preserve table "
    "structure using markdown tables, and preserve headings and list "
    "structure. Return only the extracted text, with no commentary. If the "
    "image contains no readable text, reply with exactly: NO_TEXT"
)

NO_TEXT_SENTINEL = "NO_TEXT"

OCR_OPEN = "*[Image OCR]"
OCR_CLOSE = "[End OCR]*"

# Media folders inside each OOXML container.
OOXML_MEDIA_PREFIXES = ("word/media/", "ppt/media/", "xl/media/", "word/embeddings/")

OOXML_EXTENSIONS = (".docx", ".pptx", ".xlsx")

IMAGE_MEMBER_SUFFIXES = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp")

# Beyond this width a rendered page costs tokens without adding legibility.
MAX_IMAGE_WIDTH = 2000

MAX_VISION_TOKENS = 4000

# Whether a model needs ``max_completion_tokens`` instead of ``max_tokens`` is
# the same question the chat path asks, so it is answered in the same place:
# ``echolib.model_capabilities``. This module used to carry its own fragment
# list, which was the only GPT-5 awareness anywhere in the platform.
from echolib.model_capabilities import is_reasoning_model

# What a provider says when the output-token parameter is the wrong one. Matched
# on the message because the SDK raises the same exception class for every 400.
TOKEN_PARAMETER_MARKERS = (
    "max_tokens",
    "max_completion_tokens",
    "unsupported_parameter",
    "unrecognized request argument",
)


def _is_token_parameter_error(exc: Exception) -> bool:
    """True when a failure looks like the output-token parameter being refused."""
    message = str(exc).lower()
    if not any(marker in message for marker in TOKEN_PARAMETER_MARKERS):
        return False
    # A token *limit* being exceeded also names the parameter, and retrying that
    # under a different spelling would just fail again more slowly.
    return "exceeds" not in message and "too large" not in message


@dataclass(frozen=True)
class OcrOutcome:
    """What the OCR pass produced, and what it cost."""

    blocks: List[str] = field(default_factory=list)
    pages_rendered: int = 0
    images_read: int = 0
    calls: int = 0
    failures: int = 0
    reason: Optional[str] = None

    @property
    def text(self) -> str:
        return "\n\n".join(self.blocks)

    @property
    def produced_text(self) -> bool:
        return any(block.strip() for block in self.blocks)


def _wrap(text: str) -> str:
    return f"{OCR_OPEN}\n{text.strip()}\n{OCR_CLOSE}"


# ---------------------------------------------------------------------------
# The vision call
# ---------------------------------------------------------------------------

def _encode_png(image: Any) -> Optional[str]:
    """Downscale if needed and return a base64 PNG, or ``None`` on failure."""
    try:
        if image.width > MAX_IMAGE_WIDTH:
            ratio = MAX_IMAGE_WIDTH / float(image.width)
            image = image.resize((MAX_IMAGE_WIDTH, max(1, int(image.height * ratio))))
        buffer = io.BytesIO()
        image.convert("RGB").save(buffer, format="PNG", optimize=True)
        return base64.b64encode(buffer.getvalue()).decode("ascii")
    except Exception:
        logger.debug("Image encoding failed", exc_info=True)
        return None


def _token_limit_kwarg(model: str) -> str:
    """
    Which output-token parameter this model accepts.

    OpenAI deprecated ``max_tokens`` for reasoning-capable models: gpt-5 and the
    o-series reject it outright with ``unsupported_parameter`` and require
    ``max_completion_tokens``, while older chat models reject the new name with
    "unrecognized request argument". There is no spelling that works for both,
    so the name is chosen from the model and the call below recovers from a
    wrong guess rather than losing the page.
    """
    return "max_completion_tokens" if is_reasoning_model(model) else "max_tokens"


def _read_image(binding: VisionBinding, b64_png: str) -> Optional[str]:
    """
    Send one image to the vision model and return the extracted text.

    Returns ``None`` on an empty result, the no-text sentinel, or an API
    failure. A failed image never fails the document — the plugin behaved the
    same way, and a partial transcription is more useful than none.

    The output-token parameter is named per model and retried under the other
    name once if the provider refuses it. Deployment names are a customer
    decision, so a deployment called ``vision-prod`` gives no clue which family
    it is — and this used to fail every page silently, as a warning, on any
    deployment backed by gpt-5 or an o-series model.
    """
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": OCR_PROMPT},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{b64_png}"},
                },
            ],
        }
    ]

    primary = _token_limit_kwarg(binding.model)
    alternate = (
        "max_tokens" if primary == "max_completion_tokens" else "max_completion_tokens"
    )

    response = None
    for attempt, keyword in enumerate((primary, alternate)):
        try:
            response = binding.client.chat.completions.create(
                model=binding.model,
                messages=messages,
                **{keyword: MAX_VISION_TOKENS},
            )
            break
        except Exception as exc:
            if attempt == 0 and _is_token_parameter_error(exc):
                logger.info(
                    "Model '%s' refused '%s'; retrying with '%s'",
                    binding.model, keyword, alternate,
                )
                continue
            logger.warning("Vision OCR call failed: %s", exc)
            return None

    if response is None:
        return None

    try:
        text = (response.choices[0].message.content or "").strip()
    except (AttributeError, IndexError):
        return None

    if not text or text.upper().startswith(NO_TEXT_SENTINEL):
        return None
    return text


# ---------------------------------------------------------------------------
# PDF — page rendering via pypdfium2
# ---------------------------------------------------------------------------

def _open_pdf(source: bytes | Path) -> Any:
    import pypdfium2 as pdfium

    if isinstance(source, (str, Path)):
        return pdfium.PdfDocument(str(source))
    return pdfium.PdfDocument(source)


def _page_text_length(page: Any) -> int:
    """Characters of extractable text on a page. 0 when there is no text layer."""
    textpage = None
    try:
        textpage = page.get_textpage()
        return len((textpage.get_text_range() or "").strip())
    except Exception:
        return 0
    finally:
        if textpage is not None:
            try:
                textpage.close()
            except Exception:
                pass


def _page_has_images(page: Any) -> bool:
    try:
        import pypdfium2.raw as pdfium_c

        return any(True for _ in page.get_objects(filter=[pdfium_c.FPDF_PAGEOBJ_IMAGE]))
    except Exception:
        return False


def _pages_to_render(pdf: Any, *, force_all: bool) -> List[int]:
    """
    Decide which pages are worth a vision call.

    A page qualifies when it carries no usable text layer — the scanned case —
    or when it contains image objects, which is where a chart or a screenshot
    hides inside an otherwise-textual document. ``force_all`` covers the
    malformed-PDF path, where no text could be extracted by any means.
    """
    selected: List[int] = []
    limit = config.ocr_max_pages()
    minimum = config.ocr_min_page_chars()

    for index in range(len(pdf)):
        if len(selected) >= limit:
            break
        page = pdf[index]
        try:
            if force_all or _page_text_length(page) < minimum or _page_has_images(page):
                selected.append(index)
        finally:
            try:
                page.close()
            except Exception:
                pass

    return selected


def ocr_pdf(
    source: bytes | Path,
    binding: VisionBinding,
    *,
    force_all: bool = False,
) -> OcrOutcome:
    """
    OCR the pages of a PDF that a text extractor cannot read.

    WHAT: Renders qualifying pages with PDFium and transcribes them.
    WHY:  Covers scanned PDFs, images embedded in otherwise-textual PDFs, and
          malformed PDFs that pdfminer cannot open at all — the three PDF cases
          ``markitdown-ocr`` handled with PyMuPDF.
    INPUT: PDF bytes or a path, a resolved vision binding, and ``force_all``
           for the recovery path.
    OUTPUT: An ``OcrOutcome``. Never raises.
    """
    if not binding.available:
        return OcrOutcome(reason=binding.skipped_reason)

    try:
        pdf = _open_pdf(source)
    except Exception as exc:
        logger.warning("PDFium could not open the document: %s", exc)
        return OcrOutcome(reason="pdf_unreadable")

    blocks: List[str] = []
    calls = failures = 0
    scale = config.ocr_dpi() / 72.0

    try:
        indexes = _pages_to_render(pdf, force_all=force_all)
        for index in indexes:
            page = pdf[index]
            bitmap = None
            try:
                bitmap = page.render(scale=scale)
                encoded = _encode_png(bitmap.to_pil())
            except Exception:
                logger.debug("Page %d could not be rendered", index + 1, exc_info=True)
                encoded = None
            finally:
                for handle in (bitmap, page):
                    try:
                        if handle is not None:
                            handle.close()
                    except Exception:
                        pass

            if not encoded:
                failures += 1
                continue

            calls += 1
            text = _read_image(binding, encoded)
            if text:
                blocks.append(f"### Page {index + 1}\n\n{_wrap(text)}")
            else:
                failures += 1
    finally:
        try:
            pdf.close()
        except Exception:
            pass

    logger.info(
        "PDF OCR: %d page(s) transcribed, %d call(s), %d failure(s)",
        len(blocks), calls, failures,
    )
    return OcrOutcome(
        blocks=blocks, pages_rendered=calls, calls=calls, failures=failures
    )


def pdf_is_scanned(source: bytes | Path) -> bool:
    """True when no page of the PDF carries a usable text layer."""
    try:
        pdf = _open_pdf(source)
    except Exception:
        return False

    minimum = config.ocr_min_page_chars()
    try:
        for index in range(len(pdf)):
            page = pdf[index]
            try:
                if _page_text_length(page) >= minimum:
                    return False
            finally:
                try:
                    page.close()
                except Exception:
                    pass
        return True
    finally:
        try:
            pdf.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# OOXML — images inside the zip container
# ---------------------------------------------------------------------------

def _ooxml_images(source: bytes | Path, limit: int) -> List[Tuple[str, bytes]]:
    """
    Read embedded images out of a DOCX / PPTX / XLSX container.

    OOXML files are zip archives with their media under a known prefix, so this
    needs no document library and no PDF engine — only the standard library.
    """
    found: List[Tuple[str, bytes]] = []
    try:
        handle = zipfile.ZipFile(io.BytesIO(source) if isinstance(source, bytes) else str(source))
    except Exception:
        logger.debug("Container could not be opened as OOXML", exc_info=True)
        return found

    try:
        for name in sorted(handle.namelist()):
            if len(found) >= limit:
                break
            if not name.startswith(OOXML_MEDIA_PREFIXES):
                continue
            if not name.lower().endswith(IMAGE_MEMBER_SUFFIXES):
                continue
            try:
                found.append((name, handle.read(name)))
            except Exception:
                logger.debug("Embedded image '%s' could not be read", name, exc_info=True)
    finally:
        try:
            handle.close()
        except Exception:
            pass

    return found


def ocr_ooxml(source: bytes | Path, binding: VisionBinding) -> OcrOutcome:
    """
    OCR every image embedded in a DOCX, PPTX or XLSX file.

    Blocks are appended after the document's own converted text rather than
    interleaved: the container gives reliable ordering of media but not their
    position in the reading flow, and a wrongly-placed transcription is worse
    than a clearly-labelled appendix.
    """
    if not binding.available:
        return OcrOutcome(reason=binding.skipped_reason)

    images = _ooxml_images(source, config.ocr_max_images())
    if not images:
        return OcrOutcome()

    blocks: List[str] = []
    calls = failures = 0

    for name, payload in images:
        try:
            from PIL import Image

            image = Image.open(io.BytesIO(payload))
            encoded = _encode_png(image)
        except Exception:
            logger.debug("Embedded image '%s' could not be decoded", name, exc_info=True)
            encoded = None

        if not encoded:
            failures += 1
            continue

        calls += 1
        text = _read_image(binding, encoded)
        if text:
            blocks.append(f"### Image: {Path(name).name}\n\n{_wrap(text)}")
        else:
            failures += 1

    logger.info(
        "Embedded-image OCR: %d image(s) transcribed of %d, %d failure(s)",
        len(blocks), len(images), failures,
    )
    return OcrOutcome(
        blocks=blocks, images_read=len(images), calls=calls, failures=failures
    )


# ---------------------------------------------------------------------------
# Entry point used by the converter
# ---------------------------------------------------------------------------

def extract(
    source: bytes | Path,
    extension: str,
    binding: VisionBinding,
    *,
    force_all_pages: bool = False,
) -> OcrOutcome:
    """
    Run the OCR pass appropriate to this source type.

    WHAT: Dispatches to the PDF page renderer or the OOXML image reader.
    WHY:  One call site in ``converter`` rather than type branching there.
    OUTPUT: An ``OcrOutcome``; empty when the type needs no pass, when OCR is
            unavailable, or when nothing readable was found. Never raises.
    """
    ext = str(extension or "").lower()

    if not binding.available:
        return OcrOutcome(reason=binding.skipped_reason)

    if ext == ".pdf":
        return ocr_pdf(source, binding, force_all=force_all_pages)

    if ext in OOXML_EXTENSIONS:
        return ocr_ooxml(source, binding)

    # Standalone images are captioned by MarkItDown's own ImageConverter using
    # the same client; doing it again here would double the cost for one file.
    return OcrOutcome()


def merge(markdown: str, outcome: OcrOutcome) -> str:
    """Append the OCR section to converted markdown, if there is anything to add."""
    if not outcome.produced_text:
        return markdown

    section = "## Text extracted from images\n\n" + outcome.text
    base = (markdown or "").strip()
    return f"{base}\n\n{section}" if base else section


def available() -> bool:
    """True when the page-rendering engine is importable."""
    try:
        import pypdfium2  # noqa: F401
        from PIL import Image  # noqa: F401
    except Exception:
        return False
    return True


__all__ = [
    "OCR_CLOSE",
    "OCR_OPEN",
    "OCR_PROMPT",
    "OcrOutcome",
    "available",
    "extract",
    "merge",
    "ocr_ooxml",
    "ocr_pdf",
    "pdf_is_scanned",
]
