# `apps/markitdown` — document and URL context layer

Everything MarkItDown-related lives in this folder. Nothing outside it imports
`markitdown`.

Built on [microsoft/markitdown](https://github.com/microsoft/markitdown).

## What it does

Bytes or a web address go in; markdown, split into passages and embedded, comes
out. **Nothing is stored here** — the caller persists the result.

```
bytes / URL
  → guards      extension allow-list · size ceiling · archives refused
  → fetcher     (URL only) address guard · redirect re-check · size + time caps
  → converter   MarkItDown → markdown        (convert_stream / convert_response only)
  → ocr_fallback  scanned pages and embedded images, via PDFium + a vision model
  → routed by converted length
       ≤ MARKITDOWN_INLINE_MAX_CHARS   inline     prompt-injected whole, no embedding
       >  threshold                     retrieval  chunking → embeddings → IngestResult.chunks
```

## No filesystem, anywhere

This platform runs on cloud containers with more than one replica and no shared
disk. A file written to local disk by one replica is invisible to the next and
is gone after a restart, so this package does no filesystem I/O at all:

- there is **no path-based entry point** — `convert_local` is not exposed;
- `IngestResult` carries the original bytes, the converted markdown and the
  embedded passages, and the caller writes them wherever it keeps state;
- in this platform that is Postgres — `agent_files` and `agent_file_chunks`,
  migration `063`, following the pattern `agentic_uploaded_files.content`
  already established in migration `028`.

## Public surface

Import from the package, never from a submodule:

```python
from apps.markitdown import ingest_file, embed_query, search_chunks, read_text

result = ingest_file(data=payload, filename="report.pdf", user_id=uid)
# result.content_bytes / result.content_md / result.chunks  -> your tables

vector = embed_query("Q3 revenue", user_id=uid)
hits   = search_chunks(vector, rows_loaded_from_your_store, top_k=5)
```

Nothing here knows what an agent is. Everything is synchronous and blocking; on
an event loop, use `asyncio.to_thread`.

## Modules

| Module | Responsibility |
|---|---|
| `config.py` | Every environment knob, in one place |
| `errors.py` | One exception per failure mode; messages are safe to show a user |
| `credentials.py` | The OpenAI-compatible vision client, from the platform credential cascade |
| `embeddings.py` | The embeddings client, from the same cascade |
| `converter.py` | The MarkItDown instance and the two stream-based conversion calls |
| `ocr_fallback.py` | PDFium page rendering + vision OCR — the PyMuPDF-free replacement for `markitdown-ocr` |
| `fetcher.py` | The only place this platform fetches a URL for a document |
| `guards.py` | What is refused, and the content hash used to skip repeated work |
| `chunking.py` | Markdown → retrievable `Document` chunks |
| `similarity.py` | Embedding encode/decode and cosine ranking. No storage |
| `service.py` | Orchestration; the only module the outside world calls |

## Four decisions that are not obvious

**MarkItDown never touches the network.** It is constructed with a session that
raises on every request, and only `convert_stream` and `convert_response` are
called. `convert()` and `convert_uri()` are documented by the project as
"intentionally permissive" — they will open a path, follow a URL or decode a data
URI depending on what the string looks like. Passing user input to them turns a
document upload into an SSRF. `fetcher` owns fetching, resolves the address
first, and re-checks every redirect hop.

**Plugins are disabled, and `markitdown-ocr` is not installed.** That plugin
requires `pymupdf>=1.24.0`, which is AGPL-3.0. `ocr_fallback.py` reimplements its
three capabilities — OCR of images embedded in PDF/DOCX/PPTX/XLSX, full-page OCR
for scanned PDFs, and recovery of malformed PDFs — using `pypdfium2`
(Apache-2.0 / BSD-3, the PDFium engine behind Chrome's PDF viewer) plus the same
`llm_client` vision pipeline MarkItDown itself uses. MarkItDown core keeps
handling every format converter, structure preservation and its own image
captioning.

**Vectors are stored, not indexed.** There is no `pgvector` extension in this
deployment and none is required. Embeddings are normalized little-endian float32
in a `BYTEA` column, so cosine similarity is a plain dot product, and ranking
happens in the application over one caller's own passages. That is sound because
the corpus is bounded by construction — one agent's attachments, not a shared
library. `MARKITDOWN_MAX_SEARCH_CHUNKS` caps it and logs when the assumption
stops holding; `pgvector` is the upgrade path, and only `similarity.py` and the
chunk repository would change.

**Credentials are not a second system.** `credentials.py` and `embeddings.py`
both resolve through `echolib.credential_resolver`, so the order is the agent's
own credential, then the user's default LLM (`is_default`), then the system
credential, then `FALLBACK_AZURE_OPENAI_*`. Keys come from Key Vault
(`user-cred-{credential_id}`) and are never read from the environment for a user
credential, never logged, never persisted, and never placed in a prompt or a
descriptor. When no vision-capable model resolves, OCR is skipped and the reason
is recorded on the source — it is never a silent no-op.

## Configuration

| Variable | Default | Meaning |
|---|---|---|
| `MARKITDOWN_MAX_FILE_MB` | `25` | Size ceiling for a file or a fetched page |
| `MARKITDOWN_INLINE_MAX_CHARS` | `12000` | Below this, a source is carried inline |
| `MARKITDOWN_KEEP_ORIGINALS` | `true` | Return the original bytes so a source can be re-converted without a re-upload |
| `MARKITDOWN_CHUNK_SIZE` / `_OVERLAP` | `1000` / `200` | Chunk geometry |
| `MARKITDOWN_ENABLE_OCR` | `true` | Master switch for vision OCR |
| `MARKITDOWN_OCR_DPI` | `200` | Render resolution for scanned pages |
| `MARKITDOWN_OCR_MAX_PAGES` | `20` | Vision calls per PDF |
| `MARKITDOWN_OCR_MAX_IMAGES` | `20` | Vision calls per OOXML document |
| `MARKITDOWN_OCR_MIN_PAGE_CHARS` | `40` | Below this a page counts as scanned |
| `MARKITDOWN_VISION_MODELS` | built-in list | Model-name fragments treated as vision-capable |
| `MARKITDOWN_URL_TIMEOUT` | `30` | Seconds |
| `MARKITDOWN_URL_MAX_REDIRECTS` | `3` | Each hop is re-validated |
| `MARKITDOWN_ALLOW_PRIVATE_URLS` | `false` | Turning this on removes the SSRF control |
| `MARKITDOWN_SEARCH_TOP_K` | `5` | Default retrieval depth |
| `MARKITDOWN_MAX_SEARCH_CHUNKS` | `2000` | Passages loaded for one search, and the warning threshold |
| `AGENT_MAX_CONTEXT_CALLS` | `8` | Per-run retrieval calls an agent may make |
| `AGENT_CONTEXT_TOKEN_BUDGET` | `3000` | Descriptor budget shared with connectors |
| `AGENT_INLINE_CONTENT_CHARS` | `24000` | Inline document text injected into one prompt |
| `AZURE_DOCINTEL_ENDPOINT` | unset | Enables Azure Document Intelligence |

## Dependencies

Required: `markitdown[pdf,docx,pptx,xlsx,az-doc-intel,audio-transcription,youtube-transcription]`,
`pypdfium2`, `pillow`, `openai`, `numpy`, `langchain-text-splitters`,
`langchain-openai`.

Not used: `markitdown-ocr` (AGPL via PyMuPDF), `pymupdf`, `faiss` (agent
attachments rank in Postgres; the knowledge app's own FAISS use is untouched).

`GET /agents/markitdown/status` reports what is actually installed and whether a
vision model resolved.
