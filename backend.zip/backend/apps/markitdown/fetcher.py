"""
Guarded URL fetching — the only place this platform reaches out for a document.

WHAT: Validates a URL, resolves it, refuses addresses that are not public, and
      returns a ``requests.Response`` for ``converter.convert_response``.
WHY:  Attaching a URL to an agent lets a user make the server issue an HTTP
      request. Without an address check that is a server-side request forgery
      primitive pointed at the cloud metadata service, the database subnet, or
      anything else the pod can route to. MarkItDown's own ``convert_uri``
      performs no such check, which is why it is never called.

Every hop is checked, not just the first: a redirect to ``169.254.169.254`` is
the standard way past a naive check that only inspects the URL the user typed.
"""
from __future__ import annotations

import ipaddress
import logging
import socket
from dataclasses import dataclass
from typing import Any, List, Optional, Tuple
from urllib.parse import urlparse, urlsplit

from . import config
from .errors import BlockedUrlError, SourceTooLargeError

logger = logging.getLogger(__name__)

ALLOWED_SCHEMES = ("http", "https")

# Hostnames that resolve to the local machine on many platforms regardless of
# what DNS says, and the cloud metadata name used by several providers.
BLOCKED_HOSTNAMES = (
    "localhost",
    "metadata.google.internal",
    "metadata",
    "instance-data",
)

CHUNK_BYTES = 64 * 1024


@dataclass(frozen=True)
class FetchedSource:
    """A fetched URL, ready to convert."""

    response: Any
    final_url: str
    content_type: str
    size_bytes: int


def _is_public_address(host: str) -> Tuple[bool, str]:
    """
    Resolve a hostname and decide whether every address it maps to is public.

    All resolved addresses are checked, not just the first: a name that returns
    one public and one loopback address must be refused, because which one the
    connection uses is not ours to choose.
    """
    if host.lower() in BLOCKED_HOSTNAMES:
        return False, "this address is not reachable from the server"

    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False, "this address could not be resolved"

    addresses: List[str] = []
    for info in infos:
        sockaddr = info[4]
        if sockaddr and sockaddr[0] not in addresses:
            addresses.append(sockaddr[0])

    if not addresses:
        return False, "this address could not be resolved"

    for raw in addresses:
        try:
            address = ipaddress.ip_address(raw)
        except ValueError:
            return False, "this address could not be understood"

        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_multicast
            or address.is_reserved
            or address.is_unspecified
        ):
            return False, "this address is on a private or internal network"

    return True, ""


def validate_url(url: str) -> str:
    """
    Check a URL is well-formed, uses an allowed scheme, and is publicly routable.

    Returns the normalized URL. Raises ``BlockedUrlError`` otherwise.
    """
    candidate = str(url or "").strip()
    if not candidate:
        raise BlockedUrlError("A URL is required.")

    parsed = urlparse(candidate)
    if parsed.scheme.lower() not in ALLOWED_SCHEMES:
        raise BlockedUrlError("Only http and https addresses can be attached.")

    if not parsed.hostname:
        raise BlockedUrlError("This does not look like a valid web address.")

    if config.allow_private_urls():
        return candidate

    allowed, reason = _is_public_address(parsed.hostname)
    if not allowed:
        logger.warning("Refused URL '%s': %s", parsed.hostname, reason)
        raise BlockedUrlError(f"This address cannot be attached — {reason}.")

    return candidate


def fetch(url: str) -> FetchedSource:
    """
    Fetch a URL under the guard and return the response for conversion.

    WHAT: Follows redirects manually, re-validating each hop, streams the body
          under a size ceiling, and returns the response with its content
          already buffered.
    WHY:  ``requests``' own redirect following would resolve and connect to
          each hop before this code sees it, so the guard has to own the loop.
    OUTPUT: A ``FetchedSource``.
    RAISES: ``BlockedUrlError`` for a refused address or a failed request,
            ``SourceTooLargeError`` past the size ceiling.
    """
    import requests

    current = validate_url(url)
    timeout = config.url_timeout_seconds()
    ceiling = config.max_file_bytes()
    session = requests.Session()
    session.max_redirects = 1

    try:
        for hop in range(config.url_max_redirects() + 1):
            try:
                response = session.get(
                    current,
                    stream=True,
                    timeout=timeout,
                    allow_redirects=False,
                    headers={"User-Agent": config.USER_AGENT},
                )
            except requests.RequestException as exc:
                raise BlockedUrlError(f"This address could not be reached: {exc}") from exc

            if response.is_redirect or response.is_permanent_redirect:
                location = response.headers.get("Location", "")
                response.close()
                if not location:
                    raise BlockedUrlError("This address redirected without a destination.")
                current = validate_url(_absolute(current, location))
                continue

            if response.status_code >= 400:
                response.close()
                raise BlockedUrlError(
                    f"This address returned status {response.status_code}."
                )

            declared = response.headers.get("Content-Length")
            if declared and declared.isdigit() and int(declared) > ceiling:
                response.close()
                raise SourceTooLargeError(
                    f"This page is larger than the "
                    f"{ceiling // (1024 * 1024)} MB limit."
                )

            payload = _read_capped(response, ceiling)
            # convert_response reads response.content, so the buffered body is
            # written back onto the response object rather than re-requested.
            response._content = payload  # noqa: SLF001 - requests' documented cache slot
            response._content_consumed = True  # noqa: SLF001

            return FetchedSource(
                response=response,
                final_url=current,
                content_type=response.headers.get("Content-Type", ""),
                size_bytes=len(payload),
            )

        raise BlockedUrlError("This address redirected too many times.")
    finally:
        session.close()


def _absolute(base: str, location: str) -> str:
    """Resolve a possibly-relative redirect target against the current URL."""
    if location.startswith(("http://", "https://")):
        return location
    parts = urlsplit(base)
    if location.startswith("/"):
        return f"{parts.scheme}://{parts.netloc}{location}"
    trimmed = parts.path.rsplit("/", 1)[0]
    return f"{parts.scheme}://{parts.netloc}{trimmed}/{location}"


def _read_capped(response: Any, ceiling: int) -> bytes:
    """Read a streamed body, stopping the moment it exceeds the ceiling."""
    buffer = bytearray()
    for chunk in response.iter_content(chunk_size=CHUNK_BYTES):
        if not chunk:
            continue
        buffer.extend(chunk)
        if len(buffer) > ceiling:
            response.close()
            raise SourceTooLargeError(
                f"This page is larger than the {ceiling // (1024 * 1024)} MB limit."
            )
    return bytes(buffer)


def display_name(url: str, title: Optional[str] = None) -> str:
    """A readable label for an attached URL: its title, else its host and path."""
    if title and title.strip():
        return title.strip()[:200]

    parts = urlsplit(url)
    path = (parts.path or "").rstrip("/")
    if path:
        return f"{parts.netloc}{path}"[:200]
    return (parts.netloc or url)[:200]


__all__ = ["ALLOWED_SCHEMES", "FetchedSource", "display_name", "fetch", "validate_url"]
