"""
The MarkItDown instance, and the only two ways this platform converts a source.

WHAT: Wraps ``markitdown.MarkItDown`` with Echo's credentials, Echo's network
      policy and Echo's OCR pass, exposing ``convert_bytes`` and
      ``convert_response``.
WHY:  MarkItDown's ``convert()`` and ``convert_uri()`` are documented by the
      project itself as "intentionally permissive": they will open a local
      path, follow a URL, or decode a data URI depending on what the string
      looks like. Passing user input to them is how a document upload becomes
      an SSRF. This module calls only the narrow methods and gives MarkItDown a
      session that cannot reach the network at all, so URL fetching stays in
      ``fetcher``, behind the guard.

There is deliberately no path-based entry point. ``convert_local`` is not
exposed and nothing is read from or written to disk: the platform runs on cloud
containers with more than one replica and no shared filesystem, so document
bytes live in Postgres and reach conversion as a stream.

Plugins are explicitly disabled. ``markitdown-ocr`` is the plugin this would
otherwise load, and it requires PyMuPDF (AGPL-3.0); its three capabilities are
reimplemented in ``ocr_fallback`` on PDFium instead. Disabling plugins also
means an unrelated plugin installed in the environment cannot silently join the
conversion path.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from . import config, ocr_fallback
from .credentials import VisionBinding, resolve_vision_binding
from .errors import ConversionError, MarkItDownUnavailable

logger = logging.getLogger(__name__)

BACKEND_MARKITDOWN = "markitdown"
BACKEND_MARKITDOWN_OCR = "markitdown+ocr"
BACKEND_OCR_ONLY = "ocr_only"

# Prompt used by MarkItDown's own image captioning (standalone images, PPTX
# pictures). Deliberately the same instruction the OCR pass uses so a picture
# reads the same however it reached the model.
CAPTION_PROMPT = ocr_fallback.OCR_PROMPT


@dataclass(frozen=True)
class ConversionResult:
    """Converted markdown plus how it was produced."""

    markdown: str
    title: Optional[str] = None
    converted_by: str = BACKEND_MARKITDOWN
    ocr_skipped_reason: Optional[str] = None
    ocr_calls: int = 0

    @property
    def char_count(self) -> int:
        return len(self.markdown or "")

    def describe(self) -> Dict[str, Any]:
        """Non-secret summary for the source record and the logs."""
        return {
            "converted_by": self.converted_by,
            "ocr_skipped_reason": self.ocr_skipped_reason,
            "ocr_calls": self.ocr_calls,
            "char_count": self.char_count,
        }


# ---------------------------------------------------------------------------
# Network policy
# ---------------------------------------------------------------------------

class _OfflineSession:
    """
    A stand-in for ``requests.Session`` that refuses every request.

    Handed to MarkItDown so no converter can fetch on its own behalf. Every
    outbound request this platform makes for a document goes through
    ``fetcher``, which resolves and checks the address first.
    """

    headers: Dict[str, str] = {}

    def get(self, *args: Any, **kwargs: Any) -> Any:
        raise ConversionError(
            "This converter tried to fetch a URL directly. Network access is "
            "handled by the platform's guarded fetcher, not by the converter."
        )

    request = get
    post = get

    def close(self) -> None:
        return None


# ---------------------------------------------------------------------------
# Instance construction and caching
# ---------------------------------------------------------------------------

_instance_lock = threading.Lock()
_instances: Dict[str, Any] = {}


def markitdown_available() -> bool:
    """True when the ``markitdown`` package is importable."""
    try:
        import markitdown  # noqa: F401
    except Exception:
        return False
    return True


def _build_instance(binding: VisionBinding) -> Any:
    """Construct a MarkItDown configured for this vision binding."""
    try:
        from markitdown import MarkItDown
    except ImportError as exc:
        raise MarkItDownUnavailable(
            "Document conversion is unavailable because the 'markitdown' package "
            "is not installed on the server. Install "
            "markitdown[pdf,docx,pptx,xlsx,az-doc-intel] to enable it."
        ) from exc

    kwargs: Dict[str, Any] = {
        "enable_builtins": True,
        # See the module docstring: never enable plugins.
        "enable_plugins": False,
        "requests_session": _OfflineSession(),
    }

    if binding.available:
        kwargs["llm_client"] = binding.client
        kwargs["llm_model"] = binding.model
        kwargs["llm_prompt"] = CAPTION_PROMPT

    endpoint = config.docintel_endpoint()
    if endpoint:
        kwargs["docintel_endpoint"] = endpoint

    logger.info(
        "Building MarkItDown: vision=%s model=%s docintel=%s",
        binding.available, binding.model or "-", bool(endpoint),
    )
    return MarkItDown(**kwargs)


def get_instance(binding: VisionBinding) -> Any:
    """
    Return the MarkItDown instance for this binding, building it once.

    Cached per binding fingerprint because construction registers eighteen
    converters and loads Magika's model, which is far too expensive to repeat
    per uploaded file.
    """
    key = binding.fingerprint()
    with _instance_lock:
        instance = _instances.get(key)
        if instance is None:
            instance = _build_instance(binding)
            _instances[key] = instance
    return instance


def reset_instances() -> None:
    """Drop every cached instance. Used when credentials change."""
    with _instance_lock:
        _instances.clear()


# ---------------------------------------------------------------------------
# Conversion
# ---------------------------------------------------------------------------

def _stream_info(filename: str, mimetype: Optional[str] = None) -> Any:
    from markitdown import StreamInfo

    suffix = Path(filename or "").suffix
    return StreamInfo(
        extension=suffix or None,
        filename=Path(filename or "").name or None,
        mimetype=mimetype or None,
    )


def _finish(
    markdown: str,
    title: Optional[str],
    outcome: ocr_fallback.OcrOutcome,
    *,
    ocr_only: bool = False,
) -> ConversionResult:
    """Merge the OCR pass into converted markdown and classify the result."""
    merged = ocr_fallback.merge(markdown, outcome)
    if not (merged or "").strip():
        # ``outcome.reason`` is the only record of *why* OCR could not rescue
        # this source (no vision credential, model not vision-capable, OCR
        # disabled, ...). Logging it here is the difference between "some PDF
        # failed" and knowing which credential tier to fix.
        logger.warning(
            "Conversion produced no text and OCR did not recover it (reason=%s)",
            outcome.reason or "ocr_not_attempted",
        )
        raise ConversionError(
            "No text could be read from this source. It may be empty, "
            "password protected, or an image with no readable content."
            + (f" (ocr_skipped_reason={outcome.reason})" if outcome.reason else "")
        )

    if ocr_only:
        backend = BACKEND_OCR_ONLY
    elif outcome.produced_text:
        backend = BACKEND_MARKITDOWN_OCR
    else:
        backend = BACKEND_MARKITDOWN

    # PostgreSQL rejects null bytes in text columns, and some PDF text layers
    # produce them from binary font mappings.
    return ConversionResult(
        markdown=merged.replace("\x00", ""),
        title=title,
        converted_by=backend,
        ocr_skipped_reason=outcome.reason,
        ocr_calls=outcome.calls,
    )


def convert_bytes(
    data: bytes,
    *,
    filename: str,
    mimetype: Optional[str] = None,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    binding: Optional[VisionBinding] = None,
) -> ConversionResult:
    """
    Convert an in-memory source to markdown.

    WHAT: ``convert_stream`` with an explicit ``StreamInfo``, followed by the
          OCR pass for scanned pages and embedded images.
    WHY:  Every uploaded document arrives here as bytes — from the request, or
          read back out of Postgres on a refresh — and never as a path.
          ``convert_stream`` requires a *binary* stream; MarkItDown 0.1.x
          rejects text streams, so the payload is wrapped in ``BytesIO`` and the
          type is stated explicitly rather than guessed from content alone.
    RAISES: ``MarkItDownUnavailable`` when the package is missing,
            ``ConversionError`` when nothing readable came out.

    A PDF that MarkItDown cannot open at all is retried through the OCR pass
    alone, which uses PDFium — that is the malformed-PDF recovery the dropped
    ``markitdown-ocr`` plugin provided.
    """
    import io

    extension = Path(filename or "").suffix.lower()
    vision = binding or resolve_vision_binding(user_id, credential_id)

    try:
        result = get_instance(vision).convert_stream(
            io.BytesIO(data), stream_info=_stream_info(filename, mimetype)
        )
        markdown, title = result.markdown or "", result.title
    except MarkItDownUnavailable:
        raise
    except Exception as exc:
        if extension == ".pdf":
            outcome = ocr_fallback.extract(data, extension, vision, force_all_pages=True)
            if outcome.produced_text:
                return _finish("", None, outcome, ocr_only=True)
        raise ConversionError(f"This file could not be converted: {exc}") from exc

    outcome = ocr_fallback.extract(data, extension, vision)
    return _finish(markdown, title, outcome)


def convert_response(
    response: Any,
    *,
    user_id: Optional[str] = None,
    credential_id: Optional[str] = None,
    binding: Optional[VisionBinding] = None,
) -> ConversionResult:
    """
    Convert an already-fetched HTTP response to markdown.

    WHAT: ``convert_response`` on a ``requests.Response`` produced by
          ``fetcher.fetch``.
    WHY:  This is the SSRF control. MarkItDown's own ``convert_uri`` would
          fetch through its session with no address check; by fetching first
          and handing over the response, the guard runs before any packet
          leaves, and MarkItDown still gets the Content-Type and URL it needs
          to pick the right converter (Wikipedia, RSS, YouTube, HTML).
    """
    vision = binding or resolve_vision_binding(user_id, credential_id)

    try:
        result = get_instance(vision).convert_response(response)
    except MarkItDownUnavailable:
        raise
    except Exception as exc:
        raise ConversionError(f"This URL could not be converted: {exc}") from exc

    return _finish(result.markdown or "", result.title, ocr_fallback.OcrOutcome())


def backend_status(user_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Report what this instance can actually do right now.

    A wrong environment should be a visible answer, not a mystery: this is what
    ``GET /agents/markitdown/status`` returns.
    """
    binding = resolve_vision_binding(user_id)
    return {
        "markitdown_installed": markitdown_available(),
        "page_rendering_available": ocr_fallback.available(),
        "ocr_enabled": config.ocr_enabled(),
        "vision": binding.describe(),
        "document_intelligence": bool(config.docintel_endpoint()),
        "max_file_mb": config.max_file_bytes() // (1024 * 1024),
        "inline_max_chars": config.inline_max_chars(),
    }


__all__ = [
    "BACKEND_MARKITDOWN",
    "BACKEND_MARKITDOWN_OCR",
    "BACKEND_OCR_ONLY",
    "ConversionResult",
    "backend_status",
    "convert_bytes",
    "convert_response",
    "get_instance",
    "markitdown_available",
    "reset_instances",
]
