"""
The vision client MarkItDown uses, resolved through the platform credential cascade.

WHAT: Turns a resolved LLM credential into the OpenAI-compatible client
      MarkItDown expects on ``llm_client``, plus the model name for
      ``llm_model``.
WHY:  MarkItDown captions images and OCRs pages through a raw
      ``openai.OpenAI`` / ``openai.AzureOpenAI`` object. Every other LLM
      consumer in Echo receives a LangChain ``BaseChatModel`` from
      ``llm_resolver``. This module is the one adapter between the two, so the
      OCR path uses exactly the same credentials, the same Key Vault reads and
      the same default-LLM rules as everything else.

Resolution order — every tier already exists, none is added here:

    1. the agent's own ``credential_id``   so a file is read by the same model the agent runs on
    2. the user's ``is_default`` credential (credential_resolver Tier 2)
    3. the system user's first credential  (Tier 2.5, seeded by migration 045)
    4. FALLBACK_AZURE_OPENAI_* env         (llm_resolver Tier 3)
    5. nothing                             OCR is skipped, text extraction still runs

**No API key is ever read from the environment for a user credential, logged,
persisted, or returned to a caller.** Keys reach this module only inside the
dict ``resolve_llm_credential_sync`` returns, which read them from Key Vault
(``user-cred-{credential_id}``) with the existing DB fallback for a Key Vault
outage.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from echolib.credential_resolver import resolve_llm_credential_sync
from echolib.secrets_provider import secrets as secrets_provider

from . import config

logger = logging.getLogger(__name__)

# Providers whose API surface MarkItDown's OpenAI-shaped client can speak.
# Anthropic and Gemini are excluded: they are not wire-compatible, and handing
# MarkItDown a client it cannot call would fail per image rather than once.
OPENAI_COMPATIBLE = ("azure", "azure_openai", "openai", "ollama")

CLIENT_CACHE_TTL_SECONDS = 900

SKIP_NO_CREDENTIAL = "no_llm_credential_configured"
SKIP_NOT_VISION_CAPABLE = "model_not_vision_capable"
SKIP_PROVIDER_UNSUPPORTED = "provider_not_openai_compatible"
SKIP_DISABLED = "ocr_disabled_by_configuration"
SKIP_CLIENT_BUILD_FAILED = "vision_client_could_not_be_built"


@dataclass(frozen=True)
class VisionBinding:
    """
    The outcome of resolving a vision client.

    ``client`` is ``None`` whenever OCR cannot run; ``skipped_reason`` then
    says why, in a form the file's status and the agent's descriptor can both
    show. A missing vision model is a visible state, never a silent no-op.
    """

    client: Optional[Any] = None
    model: str = ""
    provider: str = ""
    tier: str = ""
    credential_id: Optional[str] = None
    skipped_reason: Optional[str] = None

    @property
    def available(self) -> bool:
        return self.client is not None and bool(self.model)

    def fingerprint(self) -> str:
        """Identity of this binding, for caching the MarkItDown instance."""
        if not self.available:
            return f"none:{self.skipped_reason or 'unset'}"
        return f"{self.provider}:{self.credential_id or self.tier}:{self.model}"

    def describe(self) -> Dict[str, Any]:
        """Non-secret summary for logs and file records."""
        return {
            "available": self.available,
            "provider": self.provider,
            "model": self.model,
            "tier": self.tier,
            "credential_id": self.credential_id,
            "skipped_reason": self.skipped_reason,
        }


# ---------------------------------------------------------------------------
# Small TTL cache — one client per credential fingerprint
# ---------------------------------------------------------------------------

_cache_lock = threading.Lock()
_client_cache: Dict[str, Tuple[float, Any]] = {}


def _cached_client(key: str) -> Optional[Any]:
    with _cache_lock:
        entry = _client_cache.get(key)
    if entry is None:
        return None
    stored_at, client = entry
    if time.time() - stored_at > CLIENT_CACHE_TTL_SECONDS:
        return None
    return client


def _store_client(key: str, client: Any) -> None:
    with _cache_lock:
        _client_cache[key] = (time.time(), client)


def reset_cache() -> None:
    """Drop every cached client. Used when a credential is rotated or removed."""
    with _cache_lock:
        _client_cache.clear()


# ---------------------------------------------------------------------------
# Vision capability
# ---------------------------------------------------------------------------

def is_vision_capable(model: str) -> bool:
    """
    True when the model name looks like one that accepts image input.

    Substring match against the configured fragments, so a deployment named
    ``prod-gpt-4o-eastus`` is recognized. Deliberately permissive on the
    positive side: a false negative costs OCR on a document, a false positive
    costs one failed API call that the caller already handles.
    """
    name = str(model or "").strip().lower()
    if not name:
        return False
    return any(fragment in name for fragment in config.vision_models())


# ---------------------------------------------------------------------------
# Credential dict -> OpenAI-compatible client
# ---------------------------------------------------------------------------

def _normalize_provider(provider: str) -> str:
    value = str(provider or "").strip().lower()
    return "azure" if value in ("azure", "azure_openai") else value


def _model_from_creds(creds: Dict[str, Any]) -> str:
    """Deployment name is authoritative for Azure; model name is the fallback."""
    for key in ("deployment_name", "model_name", "model", "_original_model"):
        value = str(creds.get(key) or "").strip()
        if value:
            return value
    return ""


def _build_client(creds: Dict[str, Any]) -> Optional[Any]:
    """
    Construct the OpenAI-shaped client for a resolved credential.

    Returns ``None`` for providers that are not wire-compatible, so the caller
    continues down the cascade rather than treating this as a hard failure.
    """
    provider = _normalize_provider(creds.get("provider", ""))
    if provider not in [_normalize_provider(p) for p in OPENAI_COMPATIBLE]:
        return None

    api_key = str(creds.get("api_key") or "").strip()
    base_url = str(creds.get("base_url") or creds.get("endpoint") or "").strip()

    if provider == "azure":
        from openai import AzureOpenAI

        if not (api_key and base_url):
            return None
        return AzureOpenAI(
            api_key=api_key,
            azure_endpoint=base_url,
            api_version=str(creds.get("api_version") or "2024-08-01-preview"),
        )

    from openai import OpenAI

    if provider == "ollama":
        # Ollama exposes an OpenAI-compatible surface at /v1 and ignores the
        # key. Vision still depends on the model itself being multimodal,
        # which is_vision_capable() decides separately.
        if not base_url:
            return None
        root = base_url.rstrip("/")
        if not root.endswith("/v1"):
            root = f"{root}/v1"
        return OpenAI(base_url=root, api_key=api_key or "ollama")

    if not api_key:
        return None
    return OpenAI(api_key=api_key, base_url=base_url or None)


def _azure_fallback_creds() -> Optional[Dict[str, Any]]:
    """
    Read the platform fallback credential (llm_resolver Tier 3).

    Same source and precedence the rest of the platform uses, through
    ``secrets_provider`` rather than raw ``os.getenv`` so a Key Vault-backed
    deployment resolves it the same way.
    """
    api_key = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_KEY")
        or secrets_provider.get_secret("AZURE_OPENAI_API_KEY", "")
    )
    endpoint = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_ENDPOINT")
        or secrets_provider.get_secret("AZURE_OPENAI_ENDPOINT", "")
    )
    deployment = (
        secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_DEPLOYMENT")
        or secrets_provider.get_secret("AZURE_OPENAI_DEPLOYMENT", "")
    )
    if not (api_key and endpoint and deployment):
        return None

    return {
        "provider": "azure",
        "api_key": api_key,
        "base_url": endpoint,
        "deployment_name": deployment,
        "api_version": (
            secrets_provider.get_secret("FALLBACK_AZURE_OPENAI_API_VERSION")
            or "2024-08-01-preview"
        ),
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def resolve_vision_binding(
    user_id: Optional[str],
    credential_id: Optional[str] = None,
) -> VisionBinding:
    """
    Resolve the client MarkItDown should use for image and page OCR.

    WHAT: Walks the platform credential cascade and returns the first tier that
          yields an OpenAI-compatible, vision-capable client.
    WHY:  OCR must obey the same credential rules as every other LLM call —
          the agent's own model first, then the user's default LLM, then the
          platform default. Nothing here is a second credential system.
    INPUT: The acting user and, optionally, the agent's pinned credential.
    OUTPUT: A ``VisionBinding``. Never raises: a document that cannot be OCR'd
            still converts, with the reason recorded.

    Args:
        user_id: Authenticated user UUID. ``None`` skips straight to the
            platform fallback.
        credential_id: The agent's pinned credential, when it has one.
    """
    if not config.ocr_enabled():
        return VisionBinding(skipped_reason=SKIP_DISABLED)

    provider_unsupported = False

    # Tiers 1 / 1b / 2 / 2.5 — the shared cascade decides which one answers.
    if user_id:
        try:
            creds = resolve_llm_credential_sync(user_id, credential_id=credential_id)
        except Exception:
            logger.warning("Credential resolution failed for OCR", exc_info=True)
            creds = None

        if creds:
            binding = _binding_from_creds(creds, tier="user_cascade")
            if binding.available:
                return binding
            if binding.skipped_reason == SKIP_PROVIDER_UNSUPPORTED:
                provider_unsupported = True
            elif binding.skipped_reason == SKIP_NOT_VISION_CAPABLE:
                # A resolved credential that cannot see is worth naming: the
                # platform fallback below may still cover it, but if it does
                # not, this is the reason the user needs to act on.
                logger.info(
                    "Resolved credential's model '%s' is not vision-capable; "
                    "trying the platform fallback for OCR.",
                    binding.model,
                )

    # Tier 3 — platform fallback. A Key Vault outage here must degrade OCR,
    # not crash the upload: get_secret() re-raises on auth failure, and
    # without this guard that exception would escape resolve_vision_binding
    # entirely instead of landing as the usual "no credential" skip.
    try:
        fallback = _azure_fallback_creds()
    except Exception:
        logger.warning("Platform fallback credential lookup failed for OCR", exc_info=True)
        fallback = None
    if fallback:
        binding = _binding_from_creds(fallback, tier="platform_fallback")
        if binding.available:
            return binding
        if binding.skipped_reason == SKIP_PROVIDER_UNSUPPORTED:
            provider_unsupported = True
        if binding.skipped_reason == SKIP_NOT_VISION_CAPABLE:
            return binding

    if provider_unsupported:
        result = VisionBinding(skipped_reason=SKIP_PROVIDER_UNSUPPORTED)
    else:
        result = VisionBinding(skipped_reason=SKIP_NO_CREDENTIAL)

    # Without this, "vision=False" in the MarkItDown build log is the only
    # trace left behind, and diagnosing a scanned-PDF failure means reading
    # this module's source instead of its logs.
    logger.warning("OCR unavailable for this conversion: %s", result.skipped_reason)
    return result


def _binding_from_creds(creds: Dict[str, Any], *, tier: str) -> VisionBinding:
    """Turn one resolved credential dict into a binding, or say why it cannot be."""
    provider = _normalize_provider(creds.get("provider", ""))
    model = _model_from_creds(creds)
    credential_id = creds.get("credential_id")

    if provider not in [_normalize_provider(p) for p in OPENAI_COMPATIBLE]:
        return VisionBinding(
            provider=provider, model=model, tier=tier, credential_id=credential_id,
            skipped_reason=SKIP_PROVIDER_UNSUPPORTED,
        )

    if not is_vision_capable(model):
        return VisionBinding(
            provider=provider, model=model, tier=tier, credential_id=credential_id,
            skipped_reason=SKIP_NOT_VISION_CAPABLE,
        )

    cache_key = f"{provider}:{credential_id or tier}:{model}"
    client = _cached_client(cache_key)
    if client is None:
        try:
            client = _build_client(creds)
        except Exception:
            logger.warning("Vision client construction failed (%s)", provider, exc_info=True)
            client = None
        if client is None:
            return VisionBinding(
                provider=provider, model=model, tier=tier, credential_id=credential_id,
                skipped_reason=SKIP_CLIENT_BUILD_FAILED,
            )
        _store_client(cache_key, client)

    logger.info(
        "OCR vision client resolved: provider=%s model=%s tier=%s credential=%s",
        provider, model, tier, credential_id or "platform",
    )
    return VisionBinding(
        client=client, model=model, provider=provider, tier=tier, credential_id=credential_id
    )


__all__ = [
    "SKIP_CLIENT_BUILD_FAILED",
    "SKIP_DISABLED",
    "SKIP_NOT_VISION_CAPABLE",
    "SKIP_NO_CREDENTIAL",
    "SKIP_PROVIDER_UNSUPPORTED",
    "VisionBinding",
    "is_vision_capable",
    "reset_cache",
    "resolve_vision_binding",
]
