"""
Embedding encoding and cosine retrieval, with no storage of its own.

WHAT: Turns an embedding vector into the compact bytes a database column can
      hold, turns it back, and ranks stored chunks against a query vector.
WHY:  This platform runs on cloud containers with more than one replica and no
      shared disk, so a file-backed vector index is not durable and is not
      visible to the replica that did not write it. Embeddings live in
      Postgres; this module is the vector maths that sits above them.

Vectors are stored **normalized**, as little-endian float32. Normalizing once
at write time makes cosine similarity a plain dot product at query time, and
float32 halves the stored size against float64 with no measurable effect on
ranking.

Why brute force rather than an index: the corpus is bounded by construction --
one agent's own attached documents, not a shared library. Five hundred chunks
of 1536 dimensions is three megabytes and one matrix multiply. If a per-agent
corpus ever outgrows that, ``pgvector`` is the upgrade path and only this module
and the chunk repository change.
"""
from __future__ import annotations

import logging
import math
import struct
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

# Little-endian float32, matching numpy's '<f4'.
_STRUCT_FORMAT = "<f"
BYTES_PER_VALUE = 4


@dataclass(frozen=True)
class ScoredChunk:
    """One retrieved passage and where it came from."""

    content: str
    source_id: str = ""
    source_name: str = ""
    score: float = 0.0
    chunk_index: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content,
            "source_id": self.source_id,
            "source_name": self.source_name,
            "score": round(float(self.score), 4),
            "chunk_index": self.chunk_index,
        }


def normalize(vector: Sequence[float]) -> List[float]:
    """
    Scale a vector to unit length.

    A zero vector is returned unchanged rather than divided: an embedding model
    that returns zeros is a failure to record, not one to turn into NaNs that
    poison every later comparison.
    """
    values = [float(v) for v in vector]
    norm = math.sqrt(sum(v * v for v in values))
    if norm == 0.0:
        return values
    return [v / norm for v in values]


def encode(vector: Sequence[float], *, already_normalized: bool = False) -> bytes:
    """Pack an embedding into little-endian float32 bytes for a BYTEA column."""
    values = list(vector) if already_normalized else normalize(vector)
    return struct.pack(f"<{len(values)}f", *values)


def decode(payload: Optional[bytes]) -> List[float]:
    """Unpack a stored embedding. Returns an empty list for absent or truncated data."""
    if not payload:
        return []
    count = len(payload) // BYTES_PER_VALUE
    if count == 0:
        return []
    try:
        return list(struct.unpack(f"<{count}f", payload[: count * BYTES_PER_VALUE]))
    except struct.error:
        logger.warning("Stored embedding could not be decoded; skipping it")
        return []


def dimensions(payload: Optional[bytes]) -> int:
    """How many values a stored embedding holds."""
    return len(payload) // BYTES_PER_VALUE if payload else 0


# ---------------------------------------------------------------------------
# Ranking
# ---------------------------------------------------------------------------

def _rank_numpy(query: List[float], rows: Sequence[Any]) -> List[tuple]:
    """Rank with numpy: one matrix multiply over the whole candidate set."""
    import numpy as np

    width = len(query)
    matrix = np.zeros((len(rows), width), dtype=np.float32)
    keep: List[int] = []

    for index, row in enumerate(rows):
        payload = row.get("embedding") if isinstance(row, dict) else getattr(row, "embedding", None)
        values = decode(payload)
        # A dimension change means the embedding model changed. Those rows are
        # skipped rather than compared: a similarity computed across two
        # different embedding spaces is a number with no meaning.
        if len(values) != width:
            continue
        matrix[index] = np.asarray(values, dtype=np.float32)
        keep.append(index)

    if not keep:
        return []

    scores = matrix @ np.asarray(query, dtype=np.float32)
    return [(int(i), float(scores[i])) for i in keep]


def _rank_python(query: List[float], rows: Sequence[Any]) -> List[tuple]:
    """Pure-Python fallback, used only when numpy is unavailable."""
    width = len(query)
    ranked: List[tuple] = []
    for index, row in enumerate(rows):
        payload = row.get("embedding") if isinstance(row, dict) else getattr(row, "embedding", None)
        values = decode(payload)
        if len(values) != width:
            continue
        ranked.append((index, sum(a * b for a, b in zip(query, values))))
    return ranked


def rank(
    query_vector: Sequence[float],
    rows: Sequence[Any],
    *,
    top_k: int = 5,
) -> List[tuple]:
    """
    Score every candidate against the query and return the best.

    WHAT: Cosine similarity, which is a dot product because both sides are
          unit vectors.
    INPUT: The query embedding and rows exposing ``embedding`` bytes, either as
           dicts or as ORM objects.
    OUTPUT: ``[(row_index, score)]`` sorted best-first, at most ``top_k``.
            Empty when nothing shares the query's dimensionality.
    """
    query = normalize(query_vector)
    if not query or not rows:
        return []

    try:
        scored = _rank_numpy(query, rows)
    except ImportError:
        logger.info("numpy unavailable; ranking in pure Python")
        scored = _rank_python(query, rows)

    scored.sort(key=lambda pair: pair[1], reverse=True)
    return scored[: max(1, int(top_k))]


def search_rows(
    query_vector: Sequence[float],
    rows: Sequence[Dict[str, Any]],
    *,
    top_k: int = 5,
) -> List[ScoredChunk]:
    """
    Rank stored chunk rows and return them as ``ScoredChunk`` objects.

    Rows are plain dicts -- ``{content, embedding, source_id, source_name,
    chunk_index}`` -- so the repository can detach them from its session before
    the synchronous agent build ever touches them.
    """
    return [
        ScoredChunk(
            content=str(rows[index].get("content") or ""),
            source_id=str(rows[index].get("source_id") or ""),
            source_name=str(rows[index].get("source_name") or ""),
            score=score,
            chunk_index=int(rows[index].get("chunk_index") or 0),
        )
        for index, score in rank(query_vector, rows, top_k=top_k)
    ]


__all__ = [
    "BYTES_PER_VALUE",
    "ScoredChunk",
    "decode",
    "dimensions",
    "encode",
    "normalize",
    "rank",
    "search_rows",
]
