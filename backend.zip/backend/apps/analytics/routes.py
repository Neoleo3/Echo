"""
Analytics Endpoints

OTel-native in-process metrics endpoints, User Token
Allocation CRUD, DB-backed telemetry history, and real-time SSE stream.
"""

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel as PydanticBase, ConfigDict, EmailStr, Field
from sqlalchemy import select, func, text

from echolib.config import settings
from echolib.database import get_db_session
from echolib.models import (
    UserTokenAllocation,
    User,
    AppDesignation,
    AppBusinessUnit,
    AppTag,
    AppLlm,
)
from echolib.security import get_current_user, require_user, require_admin_or_above, require_super_admin, resolve_user_id
from echolib.types import UserContext
from echolib.repositories.telemetry_repo import TelemetryRepository
from echolib.repositories.telemetry_repo import TelemetryRepository
from echolib.repositories.token_governance_repo import (
    TokenGovernanceRepository,
)

_governance_repo = TokenGovernanceRepository()
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

_ALLOWED_TIME_BUCKETS = {"hour", "day", "week", "month"}
_TIMEFRAME_PATTERN = re.compile(r"^(?P<value>\d+)(?P<unit>[hdw])$", re.IGNORECASE)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _calculate_cost(input_tokens: int, output_tokens: int) -> float:
    """Calculate estimated cost based on token counts and configured rates."""
    input_cost = (input_tokens / 1000) * settings.LLM_COST_INPUT_PER_1K
    output_cost = (output_tokens / 1000) * settings.LLM_COST_OUTPUT_PER_1K
    return round(input_cost + output_cost, 4)


async def _build_user_id_to_name_map(user_ids: set) -> Dict[str, Dict[str, str]]:
    """Look up display_name and email for a set of user_id strings."""
    from echolib.repositories.base import safe_uuid

    mapping: Dict[str, Dict[str, str]] = {}
    valid_uuids = []
    for uid in user_ids:
        parsed = safe_uuid(uid)
        if parsed:
            valid_uuids.append(parsed)

    if not valid_uuids:
        return mapping

    try:
        async with get_db_session() as db:
            result = await db.execute(
                select(User.user_id, User.display_name, User.email)
                .where(User.user_id.in_(valid_uuids))
            )
            for row in result.all():
                mapping[str(row.user_id)] = {
                    "display_name": row.display_name or row.email,
                    "email": row.email,
                }
    except Exception:
        logger.debug("Failed to resolve user display names", exc_info=True)

    return mapping


def _ensure_db_telemetry_enabled() -> None:
    if not getattr(settings, "DB_TELEMETRY_ENABLED", False):
        raise HTTPException(status_code=501, detail="DB telemetry not enabled")


def _parse_optional_ts(value: Optional[str], field_name: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid {field_name}; expected ISO-8601 datetime",
        ) from exc


def _parse_time_filters(
    from_ts: Optional[str],
    to_ts: Optional[str],
) -> tuple[Optional[datetime], Optional[datetime]]:
    parsed_from = _parse_optional_ts(from_ts, "from_ts")
    parsed_to = _parse_optional_ts(to_ts, "to_ts")
    if parsed_from and parsed_to and parsed_from > parsed_to:
        raise HTTPException(
            status_code=400,
            detail="from_ts must be less than or equal to to_ts",
        )
    return parsed_from, parsed_to


def _parse_timeframe(timeframe: Optional[str]) -> tuple[Optional[datetime], Optional[datetime]]:
    if not timeframe:
        return None, None

    match = _TIMEFRAME_PATTERN.fullmatch(timeframe.strip())
    if not match:
        raise HTTPException(
            status_code=400,
            detail="Invalid timeframe; expected a short duration like 24h, 7d, or 30d",
        )

    value = int(match.group("value"))
    unit = match.group("unit").lower()
    if value <= 0:
        raise HTTPException(status_code=400, detail="timeframe must be greater than 0")

    if unit == "h":
        delta = timedelta(hours=value)
    elif unit == "d":
        delta = timedelta(days=value)
    else:
        delta = timedelta(weeks=value)

    now = datetime.now(timezone.utc)
    return now - delta, now


def _resolve_requested_time_filters(
    timeframe: Optional[str],
    from_ts: Optional[str],
    to_ts: Optional[str],
) -> tuple[Optional[datetime], Optional[datetime], bool]:
    if from_ts or to_ts:
        parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
        return parsed_from, parsed_to, True

    if timeframe:
        parsed_from, parsed_to = _parse_timeframe(timeframe)
        return parsed_from, parsed_to, True

    return None, None, False


def _validate_time_bucket(bucket: str) -> str:
    normalized = bucket.lower().strip()
    if normalized not in _ALLOWED_TIME_BUCKETS:
        raise HTTPException(
            status_code=400,
            detail=f"bucket must be one of {_ALLOWED_TIME_BUCKETS}",
        )
    return normalized


def _build_overview_summary(overview: Dict[str, Any]) -> Dict[str, Any]:
    total_events = (
        overview.get("llm", {}).get("total_calls", 0)
        + overview.get("tools", {}).get("total_executions", 0)
        + overview.get("agents", {}).get("total_chats", 0)
        + overview.get("rag", {}).get("total_queries", 0)
        + overview.get("workflows", {}).get("total_executions", 0)
        + overview.get("chat", {}).get("count", 0)
        + overview.get("convobi", {}).get("count", 0)
    )
    total_errors = (
        overview.get("llm", {}).get("total_errors", 0)
        + overview.get("tools", {}).get("total_errors", 0)
        + overview.get("chat", {}).get("errors", 0)
        + overview.get("convobi", {}).get("errors", 0)
    )
    successful_events = max(total_events - total_errors, 0)
    llm_data = overview.get("llm", {})
    total_input_tokens = llm_data.get("total_input_tokens", 0)
    total_output_tokens = llm_data.get("total_output_tokens", 0)
    total_cost = _calculate_cost(total_input_tokens, total_output_tokens)
    unique_users = overview.get("active_users", 0)
    return {
        "source": "in_memory",
        "total_events": total_events,
        "unique_users": unique_users,
        "successful_events": successful_events,
        "failed_events": total_errors,
        "success_rate": round(successful_events / total_events, 4) if total_events else 0,
        "total_cost": total_cost,
        "cost_currency": settings.LLM_COST_CURRENCY,
        "cost_per_user": round(total_cost / unique_users, 4) if unique_users else 0,
    }


def _derive_health_status(metrics: Dict[str, Any]) -> str:
    total_events = metrics.get("total_events", 0)
    if not total_events:
        return "no_data"

    success_rate = float(metrics.get("success_rate", 0) or 0)
    avg_response_time_ms = float(metrics.get("avg_response_time_ms", 0) or 0)
    if (
        success_rate < settings.ANALYTICS_HEALTH_CRIT_SUCCESS_RATE
        or avg_response_time_ms > settings.ANALYTICS_HEALTH_CRIT_AVG_RESPONSE_MS
    ):
        return "unhealthy"
    if (
        success_rate < settings.ANALYTICS_HEALTH_WARN_SUCCESS_RATE
        or avg_response_time_ms > settings.ANALYTICS_HEALTH_WARN_AVG_RESPONSE_MS
    ):
        return "degraded"
    return "healthy"


# ============================================================================
# Pydantic schemas for User Token Allocation
# ============================================================================

class TokenAllocationCreate(PydanticBase):
    name: str
    email: EmailStr
    role: str = Field(..., pattern=r"^(super_admin|admin|user)$")
    designation: Optional[str] = None
    department: Optional[str] = None
    tag: Optional[str] = None
    model: Optional[str] = None
    token_limit: int = Field(ge=0)
    token_duration: str = "daily"


class TokenAllocationUpdate(PydanticBase):
    name: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = Field(None, pattern=r"^(super_admin|admin|user)$")
    designation: Optional[str] = None
    department: Optional[str] = None
    tag: Optional[str] = None
    model: Optional[str] = None
    token_limit: Optional[int] = Field(None, ge=0)
    token_duration: Optional[str] = None
    is_active: Optional[bool] = None


class TokenAllocationResponse(PydanticBase):
    id: str
    name: str
    email: str
    role: str
    designation: Optional[str] = None
    department: Optional[str] = None
    tag: Optional[str] = None
    model: Optional[str] = None
    token_limit: int
    token_duration: str
    is_active: bool
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

# Budget related schemas
class BudgetUsage(PydanticBase):
    used: int
    input_tokens: int
    output_tokens: int
    total_tokens: int

    limit: Optional[int] = None
    remaining: Optional[int] = None
    utilization_pct: Optional[float] = None
class ModelConsumptionResponse(PydanticBase):
    credential_id: Optional[str] = None
    credential_name: Optional[str] = None

    model: str
    provider: str

    billing_source: str

    total_calls: int

    input_tokens: int
    output_tokens: int
    total_tokens: int
    lifetime_tokens: int

    daily: BudgetUsage
    monthly: BudgetUsage



class ExemptUserRequest(PydanticBase):
    email: EmailStr


class ExemptUserResponse(PydanticBase):
    email: str
    created_by: str
    created_at: str

# ============================================================================
# Usage Endpoints (backed by in-process OTel MetricsCollector)
# ============================================================================

@router.get("/usage/summary")
async def usage_summary(
    timeframe: Optional[str] = Query(None, description="Short duration alias like 24h, 7d, 30d"),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Total tokens, call count, and error rate for the current user.
    Data is sourced from the in-process OTel MetricsCollector.
    """
    user_id = resolve_user_id(user)
    parsed_from, parsed_to, filters_requested = _resolve_requested_time_filters(
        timeframe,
        from_ts,
        to_ts,
    )

    if filters_requested:
        _ensure_db_telemetry_enabled()
        try:
            from echolib.repositories.telemetry_repo import TelemetryRepository

            repo = TelemetryRepository()
            async with get_db_session() as db:
                user_summary = await repo.get_llm_summary_metrics(
                    db,
                    user_id=user_id,
                    from_ts=parsed_from,
                    to_ts=parsed_to,
                )
                system_summary = await repo.get_summary_metrics(
                    db,
                    from_ts=parsed_from,
                    to_ts=parsed_to,
                )
                overview = await repo.get_overview_metrics(
                    db,
                    from_ts=parsed_from,
                    to_ts=parsed_to,
                )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")

        total_calls = user_summary.get("total_calls", 0)
        errors = user_summary.get("errors", 0)
        sys_input_t = system_summary.get("total_input_tokens", 0)
        sys_output_t = system_summary.get("total_output_tokens", 0)
        sys_cost = _calculate_cost(sys_input_t, sys_output_t)
        sys_users = system_summary.get("unique_users", 0)
        system_summary["source"] = "db"
        system_summary["total_cost"] = sys_cost
        system_summary["cost_currency"] = settings.LLM_COST_CURRENCY
        system_summary["cost_per_user"] = round(sys_cost / sys_users, 4) if sys_users else 0
        user_input_t = user_summary.get("total_input_tokens", 0)
        user_output_t = user_summary.get("total_output_tokens", 0)
        return {
            "user_id": user_id,
            "total_tokens": user_summary.get("total_tokens", 0),
            "total_input_tokens": user_input_t,
            "total_output_tokens": user_output_t,
            "total_calls": total_calls,
            "avg_duration_ms": user_summary.get("avg_duration_ms", 0),
            "errors": errors,
            "error_rate": user_summary.get("error_rate", 0),
            "success_rate": round(max(total_calls - errors, 0) / total_calls, 4) if total_calls else 0,
            "estimated_cost": _calculate_cost(user_input_t, user_output_t),
            "cost_currency": settings.LLM_COST_CURRENCY,
            "system_summary": system_summary,
            "system_overview": overview,
        }

    try:
        from echolib.otel import get_metrics_collector
        from echolib.repositories.telemetry_repo import TelemetryRepository

        collector = get_metrics_collector()
        user_data = collector.get_user_metrics(user_id=user_id)
        overview = collector.get_overview()
        system_summary = _build_overview_summary(overview)

        if getattr(settings, "DB_TELEMETRY_ENABLED", False):
            repo = TelemetryRepository()
            async with get_db_session() as db:
                db_summary = await repo.get_summary_metrics(db)
            system_summary.update(db_summary)
            system_summary["source"] = "db"
            sys_input_t = system_summary.get("total_input_tokens", 0)
            sys_output_t = system_summary.get("total_output_tokens", 0)
            sys_cost = _calculate_cost(sys_input_t, sys_output_t)
            sys_users = system_summary.get("unique_users", 0)
            system_summary["total_cost"] = sys_cost
            system_summary["cost_currency"] = settings.LLM_COST_CURRENCY
            system_summary["cost_per_user"] = round(sys_cost / sys_users, 4) if sys_users else 0

        u = user_data.get(user_id, {})
        total_calls = u.get("total_calls", 0)
        errors = u.get("errors", 0)
        u_input_t = u.get("total_input_tokens", 0)
        u_output_t = u.get("total_output_tokens", 0)
        return {
            "user_id": user_id,
            "total_tokens": u.get("total_tokens", 0),
            "total_input_tokens": u_input_t,
            "total_output_tokens": u_output_t,
            "total_calls": total_calls,
            "avg_duration_ms": u.get("avg_duration_ms", 0),
            "errors": errors,
            "error_rate": u.get("error_rate", 0),
            "success_rate": round(max(total_calls - errors, 0) / total_calls, 4) if total_calls else 0,
            "estimated_cost": _calculate_cost(u_input_t, u_output_t),
            "cost_currency": settings.LLM_COST_CURRENCY,
            "system_summary": system_summary,
            "system_overview": overview,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/usage/by-workflow")
async def usage_by_workflow(
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Token and latency breakdown per workflow.
    Data is sourced from the in-process OTel MetricsCollector.
    """
    user_id = resolve_user_id(user)

    try:
        from echolib.otel import get_metrics_collector
        return {
            "user_id": user_id,
            "workflows": get_metrics_collector().get_workflow_metrics(),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/usage/by-model")
async def usage_by_model(
    timeframe: Optional[str] = Query(None, description="Short duration alias like 24h, 7d, 30d"),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    user: UserContext = Depends(require_admin_or_above),
):
    """
    Token and call breakdown per LLM model.
    Data is sourced from the in-process OTel MetricsCollector.
    """
    user_id = resolve_user_id(user)
    parsed_from, parsed_to, filters_requested = _resolve_requested_time_filters(
        timeframe,
        from_ts,
        to_ts,
    )

    if filters_requested:
        _ensure_db_telemetry_enabled()
        try:
            from echolib.repositories.telemetry_repo import TelemetryRepository

            repo = TelemetryRepository()
            async with get_db_session() as db:
                models = await repo.get_llm_model_metrics(
                    db,
                    from_ts=parsed_from,
                    to_ts=parsed_to,
                )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")

        return {
            "user_id": user_id,
            "models": models,
        }

    try:
        from echolib.otel import get_metrics_collector
        return {
            "user_id": user_id,
            "models": get_metrics_collector().get_llm_metrics(),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


# ============================================================================
# OTel In-Process Metrics Endpoints
# ============================================================================

@router.get("/metrics/llm")
async def metrics_llm(user: UserContext = Depends(require_admin_or_above)):
    """LLM call metrics: counts, latencies, token usage, error rates."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_llm_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/tools")
async def metrics_tools(user: UserContext = Depends(require_admin_or_above)):
    """Tool execution metrics: counts, latencies, error rates by tool name/type."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_tool_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/agents")
async def metrics_agents(user: UserContext = Depends(require_admin_or_above)):
    """Agent chat metrics: counts, latencies, avg loop iterations."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_agent_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/rag")
async def metrics_rag(user: UserContext = Depends(require_admin_or_above)):
    """RAG query metrics: counts, latencies by type."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_rag_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/workflows")
async def metrics_workflows(user: UserContext = Depends(require_admin_or_above)):
    """Workflow execution metrics: counts, latencies by workflow/mode."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_workflow_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/overview")
async def metrics_overview(user: UserContext = Depends(require_admin_or_above)):
    """Combined dashboard summary across all subsystems."""
    try:
        from echolib.otel import get_metrics_collector
        return get_metrics_collector().get_overview()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")


@router.get("/metrics/users")
async def metrics_users(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    timeframe: Optional[str] = Query(None, description="Short duration alias like 24h, 7d, 30d"),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """
    Per-user LLM token usage and call metrics enriched with budget data.
    Includes token_limit, tokens_remaining, extra_tokens_used,
    period info, and budget_status.
    """
    parsed_from, parsed_to, filters_requested = _resolve_requested_time_filters(
        timeframe,
        from_ts,
        to_ts,
    )

    if filters_requested:
        _ensure_db_telemetry_enabled()
        try:
            from echolib.repositories.telemetry_repo import TelemetryRepository

            repo = TelemetryRepository()
            async with get_db_session() as db:
                live_data = await repo.get_user_metrics_summary(
                    db,
                    user_id=user_id,
                    from_ts=parsed_from,
                    to_ts=parsed_to,
                )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")
    else:
        try:
            from echolib.otel import get_metrics_collector
            live_data = get_metrics_collector().get_user_metrics(user_id=user_id)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Metrics unavailable: {e}")

    # Fetch matching allocations from DB
    try:
        async with get_db_session() as db:
            stmt = select(UserTokenAllocation).where(UserTokenAllocation.is_active == True)
            if user_id:
                stmt = stmt.where(UserTokenAllocation.user_id == user_id)
            result = await db.execute(stmt)
            allocations = {str(a.user_id): a for a in result.scalars().all()}
    except Exception:
        allocations = {}

    # Try to read DB-backed usage periods
    db_usage: Dict[str, Any] = {}
    try:
        if getattr(settings, "DB_TELEMETRY_ENABLED", False) and not filters_requested:
            from echolib.repositories.telemetry_repo import TelemetryRepository
            from echolib.repositories.base import safe_uuid
            repo = TelemetryRepository()
            async with get_db_session() as db:
                for uid_str, alloc in allocations.items():
                    user_uuid = safe_uuid(uid_str)
                    if not user_uuid:
                        continue
                    period = await repo.get_user_usage_for_period(
                        db, user_uuid, alloc.token_duration,
                    )
                    db_usage[uid_str] = {
                        "period_used_tokens": period.total_tokens,
                        "period_input_tokens": period.total_input_tokens,
                        "period_output_tokens": period.total_output_tokens,
                        "period_calls": period.total_calls,
                        "period_tool_calls": period.total_tool_calls,
                        "period_errors": period.total_errors,
                        "period_start": period.period_start.isoformat(),
                        "period_end": period.period_end.isoformat(),
                        "period_type": period.period_type,
                    }
                await db.commit()
    except Exception:
        pass

    # Merge budget info into live metrics
    enforcement_mode = getattr(settings, "TOKEN_BUDGET_ENFORCEMENT", "soft")

    enriched: Dict[str, Any] = {}
    all_user_ids = set(live_data.keys()) | set(allocations.keys())

    # Resolve display names for all user IDs
    user_name_map = await _build_user_id_to_name_map(all_user_ids)

    for uid in all_user_ids:
        metrics = live_data.get(uid, {
            "total_calls": 0,
            "avg_duration_ms": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_tokens": 0,
            "errors": 0,
            "error_rate": 0,
        })

        # Add user identity info
        user_info = user_name_map.get(uid, {})
        metrics["display_name"] = user_info.get("display_name", uid)
        metrics["email"] = user_info.get("email", "")

        # Add cost estimate
        metrics["estimated_cost"] = _calculate_cost(
            metrics.get("total_input_tokens", 0),
            metrics.get("total_output_tokens", 0),
        )
        metrics["cost_currency"] = settings.LLM_COST_CURRENCY

        alloc = allocations.get(uid)
        if alloc:
            limit = alloc.token_limit
            if filters_requested:
                period_type = timeframe if timeframe and not (from_ts or to_ts) else "custom"
                period_info = {
                    "period_used_tokens": metrics.get("total_tokens", 0),
                    "period_input_tokens": metrics.get("total_input_tokens", 0),
                    "period_output_tokens": metrics.get("total_output_tokens", 0),
                    "period_calls": metrics.get("total_calls", 0),
                    "period_tool_calls": metrics.get("tool_calls", 0),
                    "period_errors": metrics.get("errors", 0) + metrics.get("tool_errors", 0),
                    "period_start": parsed_from.isoformat() if parsed_from else None,
                    "period_end": parsed_to.isoformat() if parsed_to else None,
                    "period_type": period_type,
                }
            else:
                period_info = db_usage.get(uid)

            if period_info:
                used = period_info["period_used_tokens"]
                metrics.update(period_info)
            else:
                used = metrics.get("total_tokens", 0)
            metrics["token_limit"] = limit
            metrics["token_duration"] = alloc.token_duration
            metrics["tokens_remaining"] = max(0, limit - used)
            metrics["extra_tokens_used"] = max(0, used - limit)
            if used >= limit:
                metrics["budget_status"] = "exceeded"
            elif limit > 0 and used >= limit * 0.8:
                metrics["budget_status"] = "approaching_limit"
            else:
                metrics["budget_status"] = "within_budget"
            metrics["enforcement_mode"] = enforcement_mode
        enriched[uid] = metrics

    return enriched


# ============================================================================
# User Token Allocation – Form Options
# ============================================================================

@router.get("/user-token-allocations/form-options")
async def token_allocation_form_options(
    user: UserContext = Depends(require_admin_or_above),
):
    """Returns dropdown options for the token allocation form."""

    roles = [
        {"id": "super_admin", "name": "Super Admin"},
        {"id": "admin", "name": "Admin"},
        {"id": "user", "name": "User"},
    ]

    async with get_db_session() as db:
        user_result = await db.execute(
            select(User).where(User.is_active == True).order_by(User.display_name.asc(), User.email.asc())
        )
        users = [
            {"name": u.display_name or u.email, "email": u.email}
            for u in user_result.scalars().all()
        ]

        desig_result = await db.execute(
            select(AppDesignation).order_by(AppDesignation.name.asc())
        )
        designations = [
            {"id": str(d.designation_id), "name": d.name}
            for d in desig_result.scalars().all()
        ]

        dept_result = await db.execute(
            select(AppBusinessUnit).order_by(AppBusinessUnit.name.asc())
        )
        departments = [
            {"id": str(d.business_unit_id), "name": d.name}
            for d in dept_result.scalars().all()
        ]

        tag_result = await db.execute(
            select(AppTag).order_by(AppTag.name.asc())
        )
        tags = [
            {"id": str(t.tag_id), "name": t.name}
            for t in tag_result.scalars().all()
        ]

        llm_result = await db.execute(
            select(AppLlm).order_by(AppLlm.name.asc())
        )
        models = [
            {"id": str(m.llm_id), "name": m.name}
            for m in llm_result.scalars().all()
        ]

    return {
        "users": users,
        "roles": roles,
        "designations": designations,
        "departments": departments,
        "tags": tags,
        "models": models,
    }


# ============================================================================
# User Token Allocation – CRUD
# ============================================================================

@router.post("/user-token-allocations", response_model=TokenAllocationResponse)
async def create_token_allocation(
    payload: TokenAllocationCreate,
    user: UserContext = Depends(require_super_admin),
):
    """Create a new per-user token allocation."""
    async with get_db_session() as db:
        resolved_user_id = await _resolve_token_allocation_user_id(db, payload)

        existing = await db.execute(
            select(UserTokenAllocation).where(
                UserTokenAllocation.user_id == resolved_user_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=409,
                detail=f"Token allocation already exists for {payload.email}",
            )

        alloc = UserTokenAllocation(
            user_id=resolved_user_id,
            name=payload.name,
            email=payload.email,
            role=payload.role,
            designation=payload.designation,
            department=payload.department,
            tag=payload.tag,
            model=payload.model,
            token_limit=payload.token_limit,
            token_duration=payload.token_duration,
        )
        db.add(alloc)
        await db.commit()
        await db.refresh(alloc)
        return _alloc_to_response(alloc)


@router.get("/user-token-allocations", response_model=List[TokenAllocationResponse])
async def list_token_allocations(
    user: UserContext = Depends(require_admin_or_above),
    active_only: bool = Query(True, description="Return only active allocations"),
):
    """List all user token allocations."""
    async with get_db_session() as db:
        stmt = select(UserTokenAllocation).order_by(
            UserTokenAllocation.created_at.desc()
        )
        if active_only:
            stmt = stmt.where(UserTokenAllocation.is_active == True)
        result = await db.execute(stmt)
        rows = result.scalars().all()
        return [_alloc_to_response(r) for r in rows]


@router.get("/user-token-allocations/{allocation_id}", response_model=TokenAllocationResponse)
async def get_token_allocation(
    allocation_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    """Get a single token allocation by ID."""
    async with get_db_session() as db:
        result = await db.execute(
            select(UserTokenAllocation).where(
                UserTokenAllocation.id == allocation_id
            )
        )
        alloc = result.scalar_one_or_none()
        if not alloc:
            raise HTTPException(status_code=404, detail="Token allocation not found")
        return _alloc_to_response(alloc)


@router.put("/user-token-allocations/{allocation_id}", response_model=TokenAllocationResponse)
async def update_token_allocation(
    allocation_id: str,
    payload: TokenAllocationUpdate,
    user: UserContext = Depends(require_super_admin),
):
    """Update an existing token allocation."""
    async with get_db_session() as db:
        result = await db.execute(
            select(UserTokenAllocation).where(
                UserTokenAllocation.id == allocation_id
            )
        )
        alloc = result.scalar_one_or_none()
        if not alloc:
            raise HTTPException(status_code=404, detail="Token allocation not found")

        update_data = payload.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(alloc, field, value)

        await db.commit()
        await db.refresh(alloc)
        return _alloc_to_response(alloc)


@router.delete("/user-token-allocations/{allocation_id}")
async def delete_token_allocation(
    allocation_id: str,
    user: UserContext = Depends(require_super_admin),
):
    """Delete a token allocation."""
    async with get_db_session() as db:
        result = await db.execute(
            select(UserTokenAllocation).where(
                UserTokenAllocation.id == allocation_id
            )
        )
        alloc = result.scalar_one_or_none()
        if not alloc:
            raise HTTPException(status_code=404, detail="Token allocation not found")

        await db.delete(alloc)
        await db.commit()

    return {"detail": "Token allocation deleted"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _alloc_to_response(alloc: UserTokenAllocation) -> TokenAllocationResponse:
    d = alloc.to_dict()
    return TokenAllocationResponse(
        id=str(d["id"]),
        name=d["name"],
        email=d["email"],
        role=d["role"],
        designation=d.get("designation"),
        department=d.get("department"),
        tag=d.get("tag"),
        model=d.get("model"),
        token_limit=d["token_limit"],
        token_duration=d["token_duration"],
        is_active=d["is_active"],
        created_at=d.get("created_at"),
        updated_at=d.get("updated_at"),
    )


async def _resolve_token_allocation_user_id(
    db,
    payload: TokenAllocationCreate,
) -> UUID:
    """
    Resolve payload email to a users.user_id UUID.

    If the email already exists in the users table, return that user_id.
    Otherwise, auto-create a new user row so an admin can pre-provision
    allocations for users who haven't logged in yet.
    """
    from uuid import uuid4

    email_normalized = str(payload.email).lower().strip()

    user_result = await db.execute(
        select(User).where(
            func.lower(User.email) == email_normalized,
            User.is_active == True,
        )
    )
    matched_user = user_result.scalar_one_or_none()
    if matched_user:
        return matched_user.user_id

    new_user = User(
        user_id=uuid4(),
        email=email_normalized,
        display_name=payload.name,
        is_active=True,
        user_metadata={},
    )
    db.add(new_user)
    await db.flush()

    logger.info(
        "Auto-created user record for token allocation: %s (user_id=%s)",
        email_normalized,
        new_user.user_id,
    )
    return new_user.user_id


# ============================================================================
# Telemetry History Endpoints (DB-backed)
# ============================================================================

@router.get("/telemetry/events")
async def telemetry_events(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    event_type: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    page: int = 1,
    size: int = 50,
):
    """Paginated telemetry event history from DB."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)

    repo = TelemetryRepository()
    async with get_db_session() as db:
        rows, total = await repo.query_events(
            db,
            user_id=user_id,
            event_type=event_type,
            from_ts=parsed_from,
            to_ts=parsed_to,
            page=page,
            size=size,
        )

    # Enrich events with display names
    event_user_ids = {e.get("user_id") for e in rows if e.get("user_id")}
    user_name_map = await _build_user_id_to_name_map(event_user_ids)
    for event in rows:
        uid = event.get("user_id")
        if uid and uid in user_name_map:
            event["display_name"] = user_name_map[uid]["display_name"]
            event["user_email"] = user_name_map[uid]["email"]

    return {"events": rows, "total": total, "page": page, "size": size}


@router.get("/telemetry/aggregates")
async def telemetry_aggregates(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    group_by: str = "event_type",
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """Grouped aggregate stats from DB for dashboards."""
    _ensure_db_telemetry_enabled()

    allowed_groups = {"event_type", "model", "provider", "tool_name", "user_id"}
    if group_by not in allowed_groups:
        raise HTTPException(status_code=400, detail=f"group_by must be one of {allowed_groups}")

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)

    repo = TelemetryRepository()
    async with get_db_session() as db:
        data = await repo.get_aggregates(
            db,
            group_by=group_by,
            user_id=user_id,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )

    # Enrich with display names when grouping by user_id
    if group_by == "user_id":
        agg_user_ids = {item.get("user_id") for item in data if item.get("user_id")}
        user_name_map = await _build_user_id_to_name_map(agg_user_ids)
        for item in data:
            uid = item.get("user_id")
            if uid and uid in user_name_map:
                item["display_name"] = user_name_map[uid]["display_name"]
                item["email"] = user_name_map[uid]["email"]

    return {"aggregates": data, "group_by": group_by}


@router.get("/telemetry/tool-invocations")
async def telemetry_tool_invocations(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """Historical tool invocation stats from DB telemetry."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        tool_invocations = await repo.get_tool_invocation_stats(
            db,
            user_id=user_id,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )
    return {"tool_invocations": tool_invocations}


@router.get("/telemetry/events-timeline")
async def telemetry_events_timeline(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    event_type: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    bucket: str = Query("day", description="One of hour, day, week, month"),
):
    """Time-bucketed event timeline for dashboards."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    normalized_bucket = _validate_time_bucket(bucket)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        timeline = await repo.get_event_timeline(
            db,
            bucket=normalized_bucket,
            user_id=user_id,
            event_type=event_type,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )
    return {"bucket": normalized_bucket, "timeline": timeline}


@router.get("/telemetry/health-response")
async def telemetry_health_response(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """Operational health and response-time analytics from DB telemetry."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        metrics = await repo.get_health_response_metrics(
            db,
            user_id=user_id,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )

    return {
        **metrics,
        "health_status": _derive_health_status(metrics),
        "thresholds": {
            "warn_success_rate": settings.ANALYTICS_HEALTH_WARN_SUCCESS_RATE,
            "crit_success_rate": settings.ANALYTICS_HEALTH_CRIT_SUCCESS_RATE,
            "warn_avg_response_ms": settings.ANALYTICS_HEALTH_WARN_AVG_RESPONSE_MS,
            "crit_avg_response_ms": settings.ANALYTICS_HEALTH_CRIT_AVG_RESPONSE_MS,
        },
    }


@router.get("/telemetry/peak-user-hours")
async def telemetry_peak_user_hours(
    user: UserContext = Depends(require_admin_or_above),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """Peak user activity by hour of day."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        hours = await repo.get_peak_user_hours(
            db,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )
    return {"hours": hours}


@router.get("/telemetry/user-adoption")
async def telemetry_user_adoption(
    user: UserContext = Depends(require_admin_or_above),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    bucket: str = Query("day", description="One of hour, day, week, month"),
):
    """New-user and active-user trends over time."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    normalized_bucket = _validate_time_bucket(bucket)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        adoption = await repo.get_user_adoption_trend(
            db,
            bucket=normalized_bucket,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )
    return {"bucket": normalized_bucket, **adoption}


@router.get("/telemetry/provider-statistics")
async def telemetry_provider_statistics(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
):
    """Historical provider-level telemetry statistics."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        providers = await repo.get_provider_statistics(
            db,
            user_id=user_id,
            from_ts=parsed_from,
            to_ts=parsed_to,
        )
    return {"providers": providers}


@router.get("/telemetry/error-monitor")
async def telemetry_error_monitor(
    user: UserContext = Depends(require_admin_or_above),
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    top_n: int = Query(10, ge=1, le=50),
):
    """Aggregate error-monitor dashboard data from DB telemetry."""
    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    parsed_from, parsed_to = _parse_time_filters(from_ts, to_ts)
    repo = TelemetryRepository()
    async with get_db_session() as db:
        summary = await repo.get_error_monitor_summary(
            db,
            from_ts=parsed_from,
            to_ts=parsed_to,
            top_n=top_n,
        )
    return summary


# ============================================================================
# Real-Time SSE Telemetry Stream
# ============================================================================

@router.get("/stream")
async def telemetry_stream(
    user: UserContext = Depends(require_admin_or_above),
    user_id: Optional[str] = None,
    all: Optional[bool] = None,
):
    """
    Server-Sent Events stream of real-time telemetry.

    - Authenticated users see their own events.
    - Admin users can pass ``?user_id=<id>`` or ``?all=true`` to see
      other users or all events.
    """
    import asyncio
    import json
    from starlette.responses import StreamingResponse
    from echolib.telemetry_stream import get_event_bus

    resolved_uid = resolve_user_id(user)
    role = (user.metadata or {}).get("role", "user") if hasattr(user, "metadata") else "user"
    if all and role in ("super_admin", "admin"):
        subscribe_uid = "*"
    elif user_id and role in ("super_admin", "admin"):
        subscribe_uid = user_id
    else:
        subscribe_uid = resolved_uid

    bus = get_event_bus()
    queue = bus.subscribe(subscribe_uid)

    async def event_generator():
        try:
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30)
                    payload = json.dumps(event, default=str)
                    yield f"data: {payload}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            bus.unsubscribe(subscribe_uid, queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )

# ============================================================================
# Live-token Aggregator (Fetches token info from DB as per session_id)
# ============================================================================
@router.get("/telemetry/user-token-usage")
async def telemetry_user_token_usage(
    user: UserContext = Depends(require_user),
):
    """
    Returns token usage for the current user grouped by model.

    Source:
    telemetry_events table
    """

    _ensure_db_telemetry_enabled()

    from echolib.repositories.telemetry_repo import TelemetryRepository

    user_id = resolve_user_id(user)

    repo = TelemetryRepository()

    async with get_db_session() as db:
        result = await repo.get_user_token_usage(
            db=db,
            user_id=user_id,
        )

    return result
# ============================================================================
# Budget Allocation and Spent metrics (Per-User Per-Model)
# ============================================================================

@router.get(
    "/model-consumption",
    response_model=List[ModelConsumptionResponse],
)
async def get_model_consumption(
    user: UserContext = Depends(require_user),
):
    
    _ensure_db_telemetry_enabled()

    user_id = resolve_user_id(user)
    logger.info(
    "[MODEL CONSUMPTION] user_id=%s requested",
    user_id,
    )

    repo = TelemetryRepository()

    async with get_db_session() as db:
        result = await repo.get_model_consumption(
            db=db,
            user_id=user_id,
        )

    return result

# ============================================================================
# Token Hard stopping exception endpoints
# ============================================================================
@router.post("/token-governance/exempt-users")
async def add_exempt_user(
    payload: ExemptUserRequest,
    user: UserContext = Depends(require_user),
):
    """
    Add a permanently exempt user.
    """
    from echolib.repositories.base import safe_uuid
    creator_user_id = resolve_user_id(user)

    async with get_db_session() as db:

        existing = await _governance_repo.get_exempt_user(
            db,
            payload.email,
        )

        if existing:
            raise HTTPException(
                status_code=409,
                detail="User is already exempt.",
            )

        exempt_user = await _governance_repo.add_exempt_user(
            db,
            email=payload.email,
            created_by=safe_uuid(creator_user_id),
        )

        await db.commit()

    logger.info(
        "[TOKEN GOVERNANCE] exempt user added email=%s by=%s",
        payload.email,
        creator_user_id,
    )

    return {
        "message": "Exempt user added successfully.",
        "email": exempt_user.email,
    }

@router.delete(
    "/token-governance/exempt-users/{email}",
)
async def remove_exempt_user(
    email: str,
    user: UserContext = Depends(require_user),
):
    """
    Remove an exempt user.
    """

    async with get_db_session() as db:

        removed = await _governance_repo.remove_exempt_user(
            db,
            email=email,
        )

        await db.commit()

    if not removed:
        raise HTTPException(
            status_code=404,
            detail="Exempt user not found.",
        )

    logger.info(
        "[TOKEN GOVERNANCE] exempt user removed email=%s",
        email,
    )

    return {
        "message": "Exempt user removed successfully.",
        "email": email,
    }

@router.get(
    "/token-governance/exempt-users",
)
async def list_exempt_users(
    user: UserContext = Depends(require_user),
):
    """
    List all exempt users.
    """

    async with get_db_session() as db:

        users = await _governance_repo.list_exempt_users(
            db,
        )

    return [
        {
            "email": item.email,
            "created_by": str(item.created_by),
            "created_at": item.created_at.isoformat(),
        }
        for item in users
    ]

