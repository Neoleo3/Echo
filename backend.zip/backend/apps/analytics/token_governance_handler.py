"""
Token Governance Error Handler

Provides centralized error handling for TokenLimitExceededException
across all LLM endpoints.
"""

import logging
from fastapi import HTTPException
from apps.analytics.token_limit import TokenLimitExceededException

logger = logging.getLogger(__name__)


def handle_token_limit_exception(
    ex: TokenLimitExceededException,
    feature_name: str,
    user_id: str,
) -> None:
    """
    Log token limit exception and raise HTTPException(429).

    Provides consistent error handling and logging for token governance
    violations across all LLM endpoints. When a user exceeds their token
    allocation (daily or monthly), this handler logs the violation with
    context and returns a 429 response to the client.

    Args:
        ex: TokenLimitExceededException from token governance service
        feature_name: Feature/endpoint identifier for logging (e.g., "CONVOBI_QUERY", "AGENT_DESIGN")
        user_id: User ID for logging context

    Raises:
        HTTPException: 429 Too Many Requests with structured error detail including:
            - error: "token_limit_exceeded"
            - message: User-facing description
            - limit_type: "daily" or "monthly"
            - current_usage: Current token usage
            - limit_value: Token allocation limit

    Example:
        try:
            llm = await get_llm_for_user(user_id)
        except TokenLimitExceededException as ex:
            handle_token_limit_exception(ex, "AGENT_DESIGN", user_id)
    """
    logger.warning(
        "[%s] token limit exceeded user=%s limit_type=%s usage=%s limit=%s",
        feature_name,
        user_id,
        ex.limit_type,
        ex.current_usage,
        ex.limit_value,
    )

    raise HTTPException(
        status_code=429,
        detail={
            "error": "token_limit_exceeded",
            "message": ex.message,
            "limit_type": ex.limit_type,
            "current_usage": ex.current_usage,
            "limit_value": ex.limit_value,
        },
    )
