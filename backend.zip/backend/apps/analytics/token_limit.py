from typing import Optional

class TokenLimitExceededException(Exception):
    """
    Raised when a user exceeds an allocated token budget.

    This exception is intentionally business-specific so it can be
    intercepted by a global FastAPI exception handler and converted
    into a consistent API response for all consumers.

    Applies to:
    - Apps
    - Workflows
    - Conversational BI
    - Agents
    - Any other feature using llm_resolver.py
    """

    def __init__(
        self,
        *,
        message: str,
        limit_type: str,
        current_usage: int | None = None,
        limit_value: int | None = None,
    ) -> None:

        super().__init__(message)

        self.message = message
        self.limit_type = limit_type
        self.current_usage = current_usage
        self.limit_value = limit_value

    def __str__(self) -> str:
        return self.message