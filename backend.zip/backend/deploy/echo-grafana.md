# EchoAI Grafana Integration Guide

## What is Prometheus?

Prometheus is a **number database**.

Your app says "I made 5 LLM calls this minute, used 3000 tokens." Prometheus stores those numbers with timestamps. Grafana then asks Prometheus "show me LLM calls over the last 24 hours" and draws a graph.

It only stores **numbers over time** (counters, averages, percentiles). It does NOT store individual request details — that's what Tempo does for traces.

---

## Architecture

```
┌─────────────────────────┐
│   EchoAI Backend        │
│   (FastAPI)             │
│                         │
│  OTel SDK pushes        │     OTLP gRPC (:4317)      ┌──────────────────┐
│  spans + metrics  ──────┼────────────────────────────▶│  OTel Collector  │
│                         │                              │                  │
└─────────────────────────┘                              │  traces ───▶ Tempo
                                                         │  metrics ──▶ Prometheus
                                                         └──────────────────┘
                                                                  │
                                                                  ▼
                                                         ┌──────────────────┐
                                                         │   Grafana UI     │
                                                         │  localhost:3000  │
                                                         └──────────────────┘
```

**Your app pushes numbers + traces → OTel Collector sorts them → Prometheus stores the numbers, Tempo stores the traces → Grafana draws the graphs.**

---

## Steps to Connect EchoAI → Grafana

### Step 1: Run 4 services

You need these running (all available as Docker containers):

| Service | What it does | One-liner |
|---|---|---|
| **OTel Collector** | Receives data from your app, forwards it | Middleman |
| **Grafana Tempo** | Stores traces (individual request details) | Like a request log database |
| **Prometheus** | Stores metrics (numbers over time) | Like a counters database |
| **Grafana** | The dashboard UI you open in browser | The screen you look at |

### Step 2: Start them with Docker Compose

Create a `docker-compose.grafana.yml` alongside your app (or add to your existing compose):

```yaml
version: "3"
services:
  otel-collector:
    image: otel/opentelemetry-collector-contrib:latest
    volumes:
      - ./deploy/otel-collector-config.yaml:/etc/otelcol/config.yaml
    ports:
      - "4317:4317"   # Your app sends data here

  tempo:
    image: grafana/tempo:latest
    ports:
      - "3200:3200"

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"   # Open this in your browser
```

Run:

```bash
docker-compose -f docker-compose.grafana.yml up -d
```

### Step 3: Set one env var in your app

```
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

That's the only config your app needs. It's already defaulted to this value in `echolib/config.py`.

Other optional env vars:

```
OTEL_ENABLED=true                          # default: true
OTEL_SERVICE_NAME=echoai-backend           # default: echoai-backend
OTEL_METRICS_EXPORT_INTERVAL_MS=15000      # default: 15000 (15 seconds)
```

### Step 4: Start your app

Run the backend normally. On startup it prints:

```
OTel initialized: service=echoai-backend, endpoint=http://localhost:4317
```

Now every LLM call, tool execution, agent chat automatically sends data to the collector.

### Step 5: Open Grafana and add data sources

1. Go to `http://localhost:3000` (default login: **admin** / **admin**)
2. Go to **Connections → Data Sources → Add data source**
3. Add **Prometheus** — URL: `http://prometheus:9090`
4. Add **Tempo** — URL: `http://tempo:3200`
5. Click **Save & Test** on each to verify connection

### Step 6: Import the pre-built dashboard

1. Go to **Dashboards → Import**
2. Paste the contents of `deploy/grafana-dashboards/echoai-llm-observability.json`
3. Select the Prometheus data source you just added
4. Click **Import**

You'll see graphs for:
- LLM calls per minute (by model/provider)
- LLM latency P50/P95/P99
- Token usage over time
- LLM error rate
- Calls by feature (agent vs RAG vs ConvoBI)
- Streaming time to first token
- Input vs output tokens
- Tool execution latency
- Agent ReAct loop iterations
- RAG query latency

### Step 7: See per-user data

**In Grafana Explore → Tempo:**
- Search for `user.id = "usr_abc123"` to see all LLM calls by a specific user

**Via REST API (no Grafana needed):**
- `GET /api/analytics/metrics/users` → all users' token counts
- `GET /api/analytics/metrics/users?user_id=usr_abc123` → one user's tokens

---

## What Data is Captured

### Per LLM Call (every invoke/stream/embed)

| Field | Example |
|---|---|
| model | `gpt-4o`, `devstral`, `gpt-4o-mini` |
| provider | `azure`, `openrouter`, `ollama` |
| feature | `agent`, `rag`, `convobi`, `workflow_compiler` |
| method | `invoke`, `stream`, `chat`, `embed` |
| user_id | `usr_abc-123-def` or `anonymous` |
| duration_ms | `823.45` |
| input_tokens | `450` |
| output_tokens | `120` |
| total_tokens | `570` |
| status | `success` / `error` |

### System-wide Metrics

| Subsystem | What's tracked |
|---|---|
| **LLM** | Calls, latency, tokens (input/output/total), errors, streaming TTFT |
| **Tools** | Executions, latency, errors — by tool name and type |
| **Agents** | Chat count, latency, ReAct loop iterations — by agent |
| **RAG** | Query count, latency — by type (traditional/graph) |
| **Workflows** | Execution count, latency — by workflow and mode |
| **Chat** | Orchestration count, latency |
| **ConvoBI** | Query count, latency |

---

## REST API Endpoints (work without Grafana)

| Endpoint | Returns |
|---|---|
| `GET /api/analytics/metrics/llm` | Per-model/provider/feature LLM stats |
| `GET /api/analytics/metrics/tools` | Per-tool execution stats |
| `GET /api/analytics/metrics/agents` | Per-agent chat stats |
| `GET /api/analytics/metrics/rag` | RAG query stats |
| `GET /api/analytics/metrics/workflows` | Workflow execution stats |
| `GET /api/analytics/metrics/overview` | Combined dashboard summary |
| `GET /api/analytics/metrics/users` | Per-user LLM token usage |
| `GET /api/analytics/metrics/users?user_id=X` | Single user's token usage |
| `GET /metrics` | Prometheus scrape endpoint |
| `GET /health/otel` | OTel health check |

---

## What happens if Grafana/Collector is down?

Nothing breaks. Every OTel call is wrapped in try/except. The app runs exactly the same — it just loses external telemetry export until the backend comes back. The in-memory REST API metrics (`/api/analytics/metrics/*`) still work.

---

## OTel Collector Config

The collector config is at `deploy/otel-collector-config.yaml`. Key env vars for the collector:

```
TEMPO_ENDPOINT=tempo:4317
PROMETHEUS_REMOTE_WRITE_URL=http://mimir:9009/api/v1/push
```

Two pipelines:
- **traces**: `otlp receiver → batch → otlp/tempo exporter`
- **metrics**: `otlp receiver → batch → prometheus remote write exporter`
