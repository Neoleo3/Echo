# EchoAI Observability Stack

## Quick Start

```bash
cd deploy/observability
docker compose -f docker-compose.observability.yml up -d
```

Then in your backend `.env`:

```env
OTEL_ENABLED=true
OTEL_COLLECTOR_ENABLED=true
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
```

Restart the EchoAI backend. Telemetry will flow through:

```
Backend → OTel Collector (:4317) → Tempo (traces) + Prometheus (metrics) → Grafana (:3000)
```

## Services

| Service         | Port  | Description                        |
|-----------------|-------|------------------------------------|
| OTel Collector  | 4317  | gRPC OTLP receiver                 |
| OTel Collector  | 4318  | HTTP OTLP receiver                 |
| Tempo           | 3200  | Trace storage API                  |
| Prometheus      | 9090  | Metrics TSDB                       |
| Grafana         | 3000  | Dashboard UI (admin / admin)       |

## Grafana Dashboard

Open http://localhost:3000 and navigate to **EchoAI > EchoAI Per-User Telemetry**.

The dashboard provides:
- **LLM Calls/min** — by model and user
- **Token Usage** — cumulative input/output/total by user
- **LLM Latency (p95)** — by model
- **Tool Executions/min** — by tool name
- **Error Rate** — global or per-user
- **Active Users** — count
- **Agent Chats/min** — by agent
- **Workflow Executions/min** — by workflow

Use the `$user_id` template variable at the top to filter all panels
to a specific user.

## Per-User Filtering

All OTel metrics are exported with a `user_id` label.  
Traces carry `user.id` span attribute for search in Tempo.

## Real-Time SSE Stream

For live telemetry without Grafana, connect to:

```
GET /api/analytics/stream
Authorization: Bearer <token>
```

Returns `text/event-stream` with JSON payloads per telemetry event.
Admin users can append `?user_id=<id>` or `?all=true`.

## Stopping

```bash
docker compose -f docker-compose.observability.yml down
```

Add `-v` to also remove persistent volumes.
