"""
Thin wrapper around docling_full_convert_new.convert_to_markdown.

Runs the synchronous Docling conversion inside asyncio.to_thread so it
never blocks the FastAPI event loop.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Optional

from docling_full_convert_new import convert_to_markdown

logger = logging.getLogger(__name__)


async def run_conversion(
    file_path: str | Path,
    out_path: Optional[str | Path] = None,
) -> str:
    """
    Run convert_to_markdown in a background thread and return the markdown
    string.  Non-blocking for the event loop.
    """
    logger.info("Starting conversion for %s", file_path)
    md = await asyncio.to_thread(
        convert_to_markdown,
        in_path=file_path,
        out_path=out_path,
    )
    logger.info("Conversion finished for %s (%d chars)", file_path, len(md))
    return md
