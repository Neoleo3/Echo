"""
In-memory job manager for tracking document conversion jobs.

Each job stores:
  - status (pending / processing / completed / failed)
  - per-file results  {filename -> FileResult}
  - temp directory path (for cleanup)
"""

from __future__ import annotations

import logging
import shutil
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from models import FileResult, FileStatus, JobStatus

logger = logging.getLogger(__name__)


@dataclass
class JobState:
    job_id: str
    status: JobStatus = JobStatus.pending
    total_files: int = 0
    completed_files: int = 0
    failed_files: int = 0
    results: Dict[str, FileResult] = field(default_factory=dict)
    temp_dir: Optional[Path] = None


class JobManager:
    """Thread-safe in-memory store for conversion jobs."""

    def __init__(self) -> None:
        self._jobs: Dict[str, JobState] = {}
        self._lock = threading.Lock()

    def create_job(self, filenames: list[str], temp_dir: Path) -> str:
        job_id = uuid.uuid4().hex
        with self._lock:
            self._jobs[job_id] = JobState(
                job_id=job_id,
                status=JobStatus.pending,
                total_files=len(filenames),
                results={
                    fn: FileResult(status=FileStatus.pending)
                    for fn in filenames
                },
                temp_dir=temp_dir,
            )
        return job_id

    def get_job(self, job_id: str) -> Optional[JobState]:
        with self._lock:
            return self._jobs.get(job_id)

    def mark_processing(self, job_id: str) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job:
                job.status = JobStatus.processing

    def set_file_result(
        self,
        job_id: str,
        filename: str,
        *,
        status: FileStatus,
        markdown: Optional[str] = None,
        error: Optional[str] = None,
    ) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            job.results[filename] = FileResult(
                status=status, markdown=markdown, error=error
            )
            if status == FileStatus.completed:
                job.completed_files += 1
            elif status == FileStatus.failed:
                job.failed_files += 1

            # Check if all files are done
            done = job.completed_files + job.failed_files
            if done >= job.total_files:
                job.status = (
                    JobStatus.completed
                    if job.failed_files == 0
                    else (
                        JobStatus.failed
                        if job.completed_files == 0
                        else JobStatus.completed
                    )
                )

    def delete_job(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.pop(job_id, None)
        if job is None:
            return False
        # Clean up temp directory
        if job.temp_dir and job.temp_dir.exists():
            try:
                shutil.rmtree(job.temp_dir, ignore_errors=True)
            except Exception:
                logger.warning("Failed to clean temp dir %s", job.temp_dir)
        return True

    def list_jobs(self) -> list[str]:
        with self._lock:
            return list(self._jobs.keys())


# Singleton instance
job_manager = JobManager()
