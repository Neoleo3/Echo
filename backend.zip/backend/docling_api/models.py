"""
Pydantic models for Docling API request/response schemas.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class JobStatus(str, Enum):
    pending = "pending"
    processing = "processing"
    completed = "completed"
    failed = "failed"


class FileStatus(str, Enum):
    pending = "pending"
    processing = "processing"
    completed = "completed"
    failed = "failed"


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"


class JobCreatedResponse(BaseModel):
    job_id: str


class FileResult(BaseModel):
    status: FileStatus
    markdown: Optional[str] = None
    error: Optional[str] = None


class JobStatusResponse(BaseModel):
    job_id: str
    status: JobStatus
    total_files: int = 0
    completed_files: int = 0
    failed_files: int = 0


class JobResultResponse(BaseModel):
    job_id: str
    status: JobStatus
    results: Dict[str, FileResult] = Field(default_factory=dict)


class ConvertSingleResponse(BaseModel):
    """Returned by /convert — immediate markdown for a single file."""
    job_id: str
    status: FileStatus
    filename: str
    markdown: Optional[str] = None
    error: Optional[str] = None


class JobDeletedResponse(BaseModel):
    job_id: str
    deleted: bool = True
