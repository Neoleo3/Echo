"""
Docling Document Conversion API
================================
FastAPI service that wraps docling_full_convert_new.convert_to_markdown.

Endpoints
---------
GET   /health                  → liveness probe
POST  /convert                 → single-file conversion (non-blocking, returns job_id)
POST  /batch/convert           → multi-file batch conversion (non-blocking)
GET   /batch/status/{job_id}   → poll job progress
GET   /batch/result/{job_id}   → retrieve per-file markdown results
DELETE /batch/{job_id}         → cancel / remove a job and clean up

All conversions run in background via asyncio tasks (no Celery needed).
Response shapes are designed to match the existing DoclingClient consumer.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from pathlib import Path
from typing import List

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse

from converter import run_conversion
from job_manager import job_manager, FileStatus
from models import (
    ConvertSingleResponse,
    HealthResponse,
    JobCreatedResponse,
    JobDeletedResponse,
    JobResultResponse,
    JobStatusResponse,
    FileResult,
)

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

UPLOAD_DIR = Path(os.getenv("DOCLING_UPLOAD_DIR", tempfile.gettempdir())) / "docling_jobs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="Docling Document Conversion API",
    version="1.0.0",
    description="Non-blocking document-to-markdown conversion powered by Docling 2.32.0",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _save_upload(upload: UploadFile, dest: Path) -> None:
    """Stream an uploaded file to disk."""
    content = await upload.read()
    dest.write_bytes(content)


async def _process_job(job_id: str, file_map: dict[str, Path]) -> None:
    """
    Background coroutine that converts every file in *file_map* and stores
    the results in the job manager.  Each file conversion is offloaded to a
    thread via converter.run_conversion so the event loop stays free.
    """
    job_manager.mark_processing(job_id)

    tasks = []
    for filename, file_path in file_map.items():
        tasks.append(_process_single_file(job_id, filename, file_path))

    await asyncio.gather(*tasks)
    logger.info("Job %s finished processing all files", job_id)


async def _process_single_file(
    job_id: str, filename: str, file_path: Path
) -> None:
    """Convert one file and update the job manager."""
    try:
        md = await run_conversion(file_path)
        job_manager.set_file_result(
            job_id, filename, status=FileStatus.completed, markdown=md
        )
        logger.info("Job %s — file %s completed", job_id, filename)
    except Exception as exc:
        logger.error(
            "Job %s — file %s failed: %s", job_id, filename, exc, exc_info=True
        )
        job_manager.set_file_result(
            job_id, filename, status=FileStatus.failed, error=str(exc)
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse()


@app.post("/convert", response_model=ConvertSingleResponse)
async def convert_single(file: UploadFile = File(...)):
    """
    Upload a single file for conversion.
    Returns a job_id immediately — the conversion runs in the background.
    Poll /batch/status/{job_id} then /batch/result/{job_id} to get the
    markdown, exactly like a batch of one.
    """
    filename = file.filename or "upload"
    job_dir = Path(tempfile.mkdtemp(prefix="job_", dir=str(UPLOAD_DIR)))
    dest = job_dir / filename
    await _save_upload(file, dest)

    job_id = job_manager.create_job([filename], temp_dir=job_dir)

    # Fire-and-forget background task on the running event loop
    asyncio.create_task(_process_job(job_id, {filename: dest}))

    return ConvertSingleResponse(
        job_id=job_id,
        status=FileStatus.pending,
        filename=filename,
    )


@app.post("/batch/convert", response_model=JobCreatedResponse)
async def batch_convert(files: List[UploadFile] = File(...)):
    """
    Upload multiple files for batch conversion.
    Returns a job_id immediately — conversions run concurrently in the
    background.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    job_dir = Path(tempfile.mkdtemp(prefix="job_", dir=str(UPLOAD_DIR)))
    file_map: dict[str, Path] = {}

    for upload in files:
        filename = upload.filename or "upload"
        dest = job_dir / filename
        await _save_upload(upload, dest)
        file_map[filename] = dest

    job_id = job_manager.create_job(list(file_map.keys()), temp_dir=job_dir)

    asyncio.create_task(_process_job(job_id, file_map))

    return JobCreatedResponse(job_id=job_id)


@app.get("/batch/status/{job_id}", response_model=JobStatusResponse)
async def batch_status(job_id: str):
    """Poll job progress."""
    job = job_manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return JobStatusResponse(
        job_id=job.job_id,
        status=job.status,
        total_files=job.total_files,
        completed_files=job.completed_files,
        failed_files=job.failed_files,
    )


@app.get("/batch/result/{job_id}", response_model=JobResultResponse)
async def batch_result(job_id: str):
    """Retrieve per-file conversion results (markdown content or error)."""
    job = job_manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return JobResultResponse(
        job_id=job.job_id,
        status=job.status,
        results=job.results,
    )


@app.delete("/batch/{job_id}", response_model=JobDeletedResponse)
async def delete_job(job_id: str):
    """Remove a job and clean up its temp files."""
    deleted = job_manager.delete_job(job_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Job not found")
    return JobDeletedResponse(job_id=job_id, deleted=True)


# ---------------------------------------------------------------------------
# Run with:  python main.py   or   uvicorn main:app --host 0.0.0.0 --port 8122
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    host = os.getenv("DOCLING_HOST", "0.0.0.0")
    port = int(os.getenv("DOCLING_PORT", "8122"))
    uvicorn.run("main:app", host=host, port=port, reload=True)
