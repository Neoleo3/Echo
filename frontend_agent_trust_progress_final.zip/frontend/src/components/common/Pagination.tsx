"use client";

import React from "react";
import s from "./Pagination.module.css";
import { MultiDropdown } from "./MultiDropdown";

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  pageSizeOptions?: number[];
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 20, 50, 100],
}) => {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const pageStart = (currentPage - 1) * pageSize + 1;
  const pageEnd = Math.min(currentPage * pageSize, total);

  const visiblePages = Array.from({ length: totalPages }, (_, i) => i + 1)
    .filter(
      (p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1,
    )
    .reduce<(number | "…")[]>((acc, p, i, arr) => {
      if (i > 0 && p - (arr[i - 1] as number) > 1) acc.push("…");
      acc.push(p);
      return acc;
    }, []);

  return (
    <div className={s.paginationContainer}>
      <div className={s.pageButtons}>
        <button
          className={s.pageBtn}
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
          aria-label="Previous page"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>

        {visiblePages.map((item, idx) =>
          item === "…" ? (
            <span key={`ellipsis-${idx}`} className={s.pageEllipsis}>
              …
            </span>
          ) : (
            <button
              key={item}
              className={`${s.pageBtn}${currentPage === item ? ` ${s.pageBtnActive}` : ""}`}
              onClick={() => onPageChange(item as number)}
              aria-current={currentPage === item ? "page" : undefined}
            >
              {item}
            </button>
          ),
        )}

        <button
          className={s.pageBtn}
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
          aria-label="Next page"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
        </button>
      </div>

      <span className={s.pageInfo}>
        {pageStart} - {pageEnd} of {total}
      </span>

      {/* <MultiDropdown
        label="Rows"
        placeholder="Select Rows Limit"
        options={pageSizeOptions.map((page: number) => {
          return { id: String(page), name: String(page) };
        })}
        selectedIds={[String(pageSize)]}
        onToggle={(o) => onPageSizeChange(Number(o.id))}
        single
      /> */}

      <div className={s.pageSizeWrap}>
        <label className={s.pageSizeLabel} htmlFor="page-size">
          Rows:
        </label>
        <select
          id="page-size"
          className={s.pageSizeSelect}
          value={pageSize}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
        >
          {pageSizeOptions.map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
