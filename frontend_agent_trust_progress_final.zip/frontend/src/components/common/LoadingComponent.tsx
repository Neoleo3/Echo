import type React from "react"
import { Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface LoadingComponentProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  fullscreen?: boolean
}

const LoadingComponent: React.FC<LoadingComponentProps> = ({ className, size = "md", fullscreen = true }) => {
  const sizeMap = {
    sm: "h-4 w-4",
    md: "h-8 w-8",
    lg: "h-12 w-12",
    xl: "h-16 w-16",
  }

  if (fullscreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className={cn("animate-spin text-primary", sizeMap[size], className)} />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center p-4">
      <Loader2 className={cn("animate-spin text-primary", sizeMap[size], className)} />
    </div>
  )
}

export default LoadingComponent