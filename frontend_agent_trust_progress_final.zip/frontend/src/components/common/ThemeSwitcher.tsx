import { useTheme } from "@/hooks/theme.hook";
import styles from "@/styles/common.module.css";

export default function ThemeSwitcher({
  navbar = false,
}: {
  navbar?: boolean;
}) {
  const { theme, setTheme } = useTheme();

  return (
    <div className={navbar ? styles.themeToggleNav : styles.themeToggle}>
      <button
        type="button"
        className={theme === "light" ? styles.active : ""}
        aria-label="Light theme"
        onClick={() => setTheme("light")}
      >
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.9"
          strokeLinecap="round"
        >
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
        </svg>
      </button>
      <button
        type="button"
        className={theme === "dark" ? styles.active : ""}
        aria-label="Dark theme"
        onClick={() => setTheme("dark")}
      >
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.9"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
        </svg>
      </button>
    </div>
  );
}
