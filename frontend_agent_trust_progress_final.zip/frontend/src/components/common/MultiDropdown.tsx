import { useEffect, useRef, useState } from "react";
import s from "@/styles/config.module.css";

interface DropdownOption {
  id: string;
  name: string;
}

interface MultiDropdownProps {
  label: string;
  placeholder: string;
  options: DropdownOption[];
  selectedIds: string[];
  onToggle: (option: DropdownOption) => void;
  single?: boolean;
}

export const MultiDropdown: React.FC<MultiDropdownProps> = ({
  label,
  placeholder,
  options,
  selectedIds,
  onToggle,
  single = false,
}) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = options.filter((o) =>
    o.name.toLowerCase().includes(search.toLowerCase()),
  );

  const selectedOptions = options.filter((o) => selectedIds.includes(o.id));
  const selectedSingle = single ? selectedOptions[0] : undefined;

  return (
    <div className={s.llmFormField}>
      <label>{label}</label>
      <div className={`${s.umDd} ${open ? s.open : ""}`} ref={ref}>
        {/* Trigger */}
        <div
          className={s.umDdTrigger}
          role="button"
          tabIndex={0}
          onClick={() => setOpen((v) => !v)}
          onKeyDown={(e) => e.key === "Enter" && setOpen((v) => !v)}
          aria-expanded={open}
          aria-haspopup="listbox"
        >
          {single ? (
            <span className={selectedSingle ? s.umDdVal : s.umDdPh}>
              {selectedSingle ? selectedSingle.name : placeholder}
            </span>
          ) : (
            <div className={s.umDdChips}>
              {selectedOptions.length === 0 ? (
                <span className={s.umDdPh}>{placeholder}</span>
              ) : (
                selectedOptions.map((o) => (
                  <span key={o.id} className={s.umChip}>
                    {o.name}
                    <button
                      type="button"
                      className={s.umChipX}
                      aria-label={`Remove ${o.name}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggle(o);
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))
              )}
            </div>
          )}
          <svg
            className={s.umDdCaret}
            width="14"
            height="14"
            viewBox="0 0 256 256"
            fill="currentColor"
          >
            <path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z" />
          </svg>
        </div>

        {/* Dropdown popup */}
        <div className={s.umDdPop} role="listbox">
          <div className={s.umDdSearch}>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              className={s.umDdSearchInput}
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          <div className={s.umDdList}>
            {filtered.length === 0 ? (
              <div className={s.umDdEmpty}>No options found</div>
            ) : (
              filtered.map((o) => {
                const checked = selectedIds.includes(o.id);
                return (
                  <button
                    key={o.id}
                    type="button"
                    className={`${s.umDdOpt}${checked ? ` ${s.on}` : ""}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggle(o);
                      if (single) {
                        setOpen(false);
                        setSearch("");
                      }
                    }}
                    role={single ? "radio" : "option"}
                    aria-checked={single ? checked : undefined}
                    aria-selected={!single ? checked : undefined}
                  >
                    {single ? (
                      <span
                        className={`${s.umRadioDropdown}${checked ? ` ${s.on}` : ""}`}
                      >
                        {checked && <span className={s.umRadioDotDropdown} />}
                      </span>
                    ) : (
                      <span
                        className={`${s.umCbDropdown}${checked ? ` ${s.on}` : ""}`}
                      >
                        {checked && (
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        )}
                      </span>
                    )}
                    {o.name}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
