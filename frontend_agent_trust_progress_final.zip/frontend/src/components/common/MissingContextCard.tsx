"use client";

import { AlertTriangle, Upload, PlugZap, MessageSquare } from "lucide-react";

export type MissingItem = {
  kind?: string;
  label?: string;
  why?: string;
  accepts?: string[];
  blocking?: boolean;
};

export interface MissingContext {
  reason?: string;
  intent?: string;
  skill_considered?: string;
  missing?: MissingItem[];
  optional?: MissingItem[];
  available?: string[];
  action?: "upload" | "connect" | "describe" | string;
}

interface Props {
  data: MissingContext;
  canUpload?: boolean;
  onUpload?: () => void;
}

export default function MissingContextCard({
  data,
  canUpload,
  onUpload,
}: Props) {
  const missing = data?.missing ?? [];
  const optional = data?.optional ?? [];
  const available = data?.available ?? [];
  const action = data?.action ?? "describe";

  return (
    <div className="rounded-xl border border-amber-300/70 bg-amber-50/60 p-4 text-[var(--text-primary)]">
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle className="w-4 h-4 text-amber-600" />
        <span className="font-semibold text-sm">More information needed</span>
      </div>

      {missing.length > 0 && (
        <div className="mb-3">
          <div className="text-xs font-semibold uppercase tracking-wide text-amber-700 mb-1">
            I need
          </div>
          <ul className="space-y-1">
            {missing.map((m, i) => (
              <li key={i} className="text-sm">
                <span className="font-medium">{m.label || "this"}</span>
                {m.why ? (
                  <span className="text-[var(--text-secondary)]">
                    {" "}
                    — {m.why}
                  </span>
                ) : null}
                {m.accepts && m.accepts.length > 0 ? (
                  <span className="text-[var(--text-secondary)]">
                    {" "}
                    ({m.accepts.join(", ")})
                  </span>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      )}

      {optional.length > 0 && (
        <div className="mb-3">
          <div className="text-xs font-semibold uppercase tracking-wide text-[var(--text-secondary)] mb-1">
            Helpful, but not required
          </div>
          <ul className="space-y-1">
            {optional.map((m, i) => (
              <li key={i} className="text-sm text-[var(--text-secondary)]">
                {m.label}
              </li>
            ))}
          </ul>
        </div>
      )}

      {available.length > 0 && (
        <div className="mb-3 text-xs text-[var(--text-secondary)]">
          I do have: {available.join(", ")}.
        </div>
      )}

      {action === "upload" ? (
        <button
          type="button"
          onClick={onUpload}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-[var(--accent-blue)] text-white text-sm font-medium hover:bg-[#1a6bc7] transition-colors"
        >
          <Upload className="w-4 h-4" />
          {canUpload ? "Upload a file and I'll continue" : "Upload a file"}
        </button>
      ) : action === "connect" ? (
        <div className="inline-flex items-center gap-2 text-sm text-[var(--text-secondary)]">
          <PlugZap className="w-4 h-4 text-amber-600" />
          Connect it in the application&apos;s data sources and I&apos;ll
          continue.
        </div>
      ) : (
        <div className="inline-flex items-center gap-2 text-sm text-[var(--text-secondary)]">
          <MessageSquare className="w-4 h-4 text-amber-600" />
          Tell me and I&apos;ll continue.
        </div>
      )}
    </div>
  );
}
