import { create } from "zustand";
import { applicationsService } from "@/services";
import type { Application, ApplicationList } from "@/types";

export interface ApprovalFocus {
  applicationId: string;
  nonce: number;
}

interface AppStore {
  applications: ApplicationList[];
  selectedApp: Application | null;
  approvalFocus: ApprovalFocus | null;
  loading: boolean;

  setApplications: (apps: ApplicationList[]) => void;
  setSelectedApp: (app: Application | null) => void;

  setApprovalFocus: (focus: ApprovalFocus | null) => void;
  openApprovals: (applicationId: string) => void;

  loadApplications: () => Promise<void>;
  selectApp: (
    app: ApplicationList | null,
    application_id?: string | null,
    onReset?: () => void,
  ) => Promise<void>;
}

export const useAppStore = create<AppStore>((set) => ({
  applications: [],
  selectedApp: null,
  approvalFocus: null,
  loading: false,

  setApplications: (applications) => set({ applications }),

  setSelectedApp: (selectedApp) => set({ selectedApp }),

  setApprovalFocus: (approvalFocus) => set({ approvalFocus }),
  openApprovals: (applicationId) =>
    set({
      approvalFocus: {
        applicationId,
        nonce: Date.now(),
      },
    }),

  loadApplications: async () => {
    set({ loading: true });

    try {
      const response = await applicationsService.getVisibleApplications();

      if (response.success && response.data?.items?.length) {
        set({
          applications: response.data.items,
        });
      }
    } finally {
      set({ loading: false });
    }
  },

  selectApp: async (app, application_id, onReset) => {
    const response = await applicationsService.getApplication(
      app?.application_id ?? application_id ?? "",
    );

    if (response.success && response.data) {
      set({
        selectedApp: response.data as Application,
      });

      onReset?.();
    }
  },
}));
