"use client";

import { EchoMessage, PendingUploadFile, SessionDocument, Step } from "@/types";
import { create } from "zustand";

interface EchoChatStore {
  messages: EchoMessage[];
  streamingText: string;
  steps: Step[];
  sessionId: string | null;
  surfaceVisible: boolean;
  isStreaming: boolean;
  isFileUploading: boolean;
  pendingUploadFiles: PendingUploadFile[];
  sessionDocuments: SessionDocument[];

  setMessages: (
    messages: EchoMessage[] | ((prev: EchoMessage[]) => EchoMessage[]),
  ) => void;
  addMessage: (message: EchoMessage) => void;

  setStreamingText: (text: string | ((prev: string) => string)) => void;
  appendStreamingText: (text: string) => void;

  setSteps: (steps: Step[]) => void;
  setSessionId: (id: string | null) => void;
  setSurfaceVisible: (value: boolean) => void;
  setIsStreaming: (value: boolean) => void;

  setIsFileUploading: (value: boolean) => void;
  setPendingUploadFiles: (files: PendingUploadFile[]) => void;
  setSessionDocuments: (
    docs: SessionDocument[] | ((prev: SessionDocument[]) => SessionDocument[]),
  ) => void;

  clear: () => void;
}

export const useEchoChatStore = create<EchoChatStore>((set) => ({
  messages: [],
  streamingText: "",
  steps: [],
  sessionId: null,
  surfaceVisible: false,
  isStreaming: false,
  isFileUploading: false,
  pendingUploadFiles: [],
  sessionDocuments: [],

  setMessages: (messages) =>
    set((state) => ({
      messages:
        typeof messages === "function" ? messages(state.messages) : messages,
    })),

  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),

  setStreamingText: (text) =>
    set((state) => ({
      streamingText:
        typeof text === "function" ? text(state.streamingText) : text,
    })),

  appendStreamingText: (text) =>
    set((state) => ({
      streamingText: state.streamingText + text,
    })),

  setSteps: (steps) =>
    set({
      steps,
    }),

  setSessionId: (sessionId) =>
    set({
      sessionId,
    }),

  setSurfaceVisible: (surfaceVisible) =>
    set({
      surfaceVisible,
    }),

  setIsStreaming: (isStreaming) =>
    set({
      isStreaming,
    }),

  setIsFileUploading: (isFileUploading) =>
    set({
      isFileUploading,
    }),

  setPendingUploadFiles: (pendingUploadFiles) =>
    set({
      pendingUploadFiles,
    }),

  setSessionDocuments: (docs) =>
    set((state) => ({
      sessionDocuments:
        typeof docs === "function" ? docs(state.sessionDocuments) : docs,
    })),

  clear: () =>
    set({
      messages: [],
      streamingText: "",
      steps: [],
      sessionId: null,
      surfaceVisible: false,
      isStreaming: false,
      isFileUploading: false,
      pendingUploadFiles: [],
      sessionDocuments: [],
    }),
}));
