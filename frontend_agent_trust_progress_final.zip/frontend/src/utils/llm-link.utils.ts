import type { Application, LlmLink, LLMModel } from "@/types";

export const ORCHESTRATOR_ROLE = "orchestrator" as const;

const isUsable = (value: unknown): value is string =>
  typeof value === "string" && value.trim() !== "";

export function resolveLlmId(
  model: Partial<LLMModel> | null | undefined,
): string | null {
  if (!model) return null;
  if (isUsable(model.credential_id)) return model.credential_id.trim();
  if (isUsable(model.id)) return model.id.trim();
  if (isUsable(model.model_id)) return model.model_id.trim();
  return null;
}

export function isSelectableLlm(
  model: Partial<LLMModel> | null | undefined,
): boolean {
  return resolveLlmId(model) !== null;
}

export function buildLlmLinks(
  model: Partial<LLMModel> | null | undefined,
  role: string = ORCHESTRATOR_ROLE,
): LlmLink[] {
  const llmId = resolveLlmId(model);
  if (!llmId) return [];
  const link: LlmLink = { llm_id: llmId, role: role as LlmLink["role"] };
  if (isUsable(model?.name)) link.name = model!.name;
  return [link];
}

export function linkMatchesModel(
  link: LlmLink | null | undefined,
  model: Partial<LLMModel> | null | undefined,
): boolean {
  if (!link || !model || !isUsable(link.llm_id)) return false;
  const id = link.llm_id.trim();
  return (
    (isUsable(model.credential_id) && model.credential_id.trim() === id) ||
    (isUsable(model.id) && model.id.trim() === id) ||
    (isUsable(model.model_id) && model.model_id.trim() === id)
  );
}

export function selectedLlmId(
  application: Partial<Application> | null | undefined,
): string | null {
  if (!application) return null;
  const link = application.llm_links?.find((entry) =>
    isUsable((entry as { llm_id?: string })?.llm_id),
  ) as { llm_id: string } | undefined;
  if (link) return link.llm_id.trim();
  const legacy = application.llm_links?.find(isUsable);
  return legacy ? legacy.llm_id : null;
}

export function selectedLlmModel(
  application: Partial<Application> | null | undefined,
  models: Partial<LLMModel>[],
): Partial<LLMModel> | null {
  const id = selectedLlmId(application);
  if (!id) return null;
  return (
    models.find((model) => linkMatchesModel({ llm_id: id }, model)) ?? null
  );
}

export function toLlmLinks(
  value: LlmLink[] | Partial<LLMModel> | string | null | undefined,
  role: string = ORCHESTRATOR_ROLE,
): LlmLink[] {
  if (!value) return [];
  if (typeof value === "string") {
    return isUsable(value)
      ? [{ llm_id: value.trim(), role: role as LlmLink["role"] }]
      : [];
  }
  if (Array.isArray(value)) {
    const first = value.find((entry) => isUsable(entry?.llm_id));
    if (!first) return [];
    return [
      {
        ...first,
        llm_id: first.llm_id.trim(),
        role: first.role ?? (role as LlmLink["role"]),
      },
    ];
  }
  return buildLlmLinks(value, role);
}
