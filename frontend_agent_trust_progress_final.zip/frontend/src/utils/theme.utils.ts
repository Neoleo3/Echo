import { STORAGE_KEYS } from "@/config";

export type AppTheme = "light" | "dark";

const VALID_THEMES = new Set<string>(["light", "dark"]);

export function getPersistedTheme(): AppTheme {
  if (typeof window === "undefined") return "light";
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.THEME);
    if (stored && VALID_THEMES.has(stored)) return stored as AppTheme;
  } catch (err:any) {
    // localStorage may throw in restricted contexts
    console.error("Error while fetching the theme from localstorage: ", err);
  }
  return "light";
}

/**
 * Persists the theme preference and immediately applies it to the document
 * by setting `html[data-theme]`.
 */
export function applyTheme(theme: AppTheme): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch {
    // silently fail if storage is unavailable
  }
  document.documentElement.setAttribute("data-theme", theme);
}