import type { LLMModel, LlmModelFamily } from "@/types";

const GATED_PROVIDERS: readonly string[] = ["azure", "openai"];

const REASONING_NAME = /(?:^|[^a-z0-9])(?:gpt-?5|o[134])(?![a-z])/i;

const CHAT_VARIANT = /gpt-?5(?:\.\d+)?-chat/i;

export function detectsAsReasoning(
  ...names: Array<string | null | undefined>
): boolean {
  for (const name of names) {
    const text = (name ?? "").trim();
    if (!text) continue;
    if (CHAT_VARIANT.test(text)) return false;
    if (REASONING_NAME.test(text)) return true;
  }
  return false;
}

export function isReasoningModel(
  model: Partial<LLMModel> | null | undefined,
): boolean {
  if (!model) return false;

  const provider = (model.provider ?? "").trim().toLowerCase();
  if (!GATED_PROVIDERS.includes(provider)) return false;

  const declared = (model.model_family ?? "auto") as LlmModelFamily;
  if (declared === "gpt5") return true;
  if (declared === "gpt4") return false;

  return detectsAsReasoning(model.deployment_name, model.model_name, model.id);
}

export const REASONING_SAMPLING_NOTE =
  "This model reasons before it answers, and its provider rejects temperature " +
  "and top-p. These settings are saved but not sent while it is selected.";
