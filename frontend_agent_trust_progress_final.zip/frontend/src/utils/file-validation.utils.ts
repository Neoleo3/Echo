export const ALLOWED_EXTENSIONS = [
  "pdf",
  "png",
  "jpg",
  "jpeg",
  "docx",
  "xlsx",
  "csv",
  "txt",
  "msg",
  "json",
  "pptx",
] as const;

export const MAX_FILE_SIZE_MB = 50;

const DANGEROUS_EXTENSIONS = [
  "exe",
  "bat",
  "cmd",
  "msi",
  "apk",
  "sh",
  "ps1",
  "vbs",
  "js",
  "jar",
  "scr",
] as const;

/** All dot-separated extensions after the base filename. */
function getAllExtensions(fileName: string): string[] {
  return fileName.toLowerCase().split(".").slice(1);
}

function hasDoubleExtension(fileName: string): boolean {
  return getAllExtensions(fileName).length >= 2;
}

function containsDangerousExtension(fileName: string): boolean {
  return getAllExtensions(fileName).some((ext) =>
    (DANGEROUS_EXTENSIONS as readonly string[]).includes(ext),
  );
}

function isSuspiciousFileName(fileName: string): boolean {
  return (
    fileName.includes("\0") ||
    fileName.includes("..") ||
    /[<>:"|?*]/.test(fileName)
  );
}

export function validateFile(file: File): string | null {
  const name = file.name.toLowerCase();
  const sizeMB = file.size / (1024 * 1024);

  if (sizeMB > MAX_FILE_SIZE_MB)
    return `File exceeds the ${MAX_FILE_SIZE_MB} MB limit`;

  if (isSuspiciousFileName(name))
    return "File has an invalid or suspicious name";

  if (hasDoubleExtension(name)) return "File contains multiple extensions";

  if (containsDangerousExtension(name))
    return "File type is potentially dangerous";

  const ext = name.split(".").pop();
  if (!ext || !(ALLOWED_EXTENSIONS as readonly string[]).includes(ext))
    return "File type is not allowed";

  return null; // ✅ safe
}
