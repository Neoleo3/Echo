const CODE_SEGMENT = /(```[\s\S]*?```|~~~[\s\S]*?~~~|`[^`\n]*`)/g;

const CURRENCY_PATTERNS: ReadonlyArray<RegExp> = [
  /(?<!\\)\((\$)(?=[A-Za-z]{0,3}\))/g,
  /(?<![\\$])\$(?=\d)/g,
  /(?<=^|[ \t])(?<!\\)\$(?=[ \t]|$)/gm,
];

function escapeSegment(segment: string): string {
  return CURRENCY_PATTERNS.reduce(
    (text, pattern) =>
      text.replace(pattern, (match) =>
        match.startsWith("(") ? "(\\$" : "\\$",
      ),
    segment,
  );
}

export function escapeCurrencyDollars(markdown: string): string {
  if (!markdown || !markdown.includes("$")) return markdown;
  return markdown
    .split(CODE_SEGMENT)
    .map((segment, index) =>
      index % 2 === 1 ? segment : escapeSegment(segment),
    )
    .join("");
}
