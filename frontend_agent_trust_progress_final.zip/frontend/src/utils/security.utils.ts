import CryptoJS from "crypto-js";
import DOMPurify from "dompurify";

export const encryptAndStore = (key: string, value: unknown): void => {
  const encryption_key =
    process.env.NEXT_PUBLIC_ENCRYPTION_KEY ?? "echo-ai-key";
  try {
    const jsonString = JSON.stringify(value);
    const encrypted = CryptoJS.AES.encrypt(
      jsonString,
      encryption_key,
    ).toString();

    console.log("Cookie Encrypt: ", encrypted, encryption_key);

    localStorage.setItem(key, encrypted);

    console.log(
      `[encryptAndStore] Successfully stored encrypted cookie in localStorage for key: ${key}`,
    );
  } catch (error) {
    console.error(`[encryptAndStore] Encryption failed for key: ${key}`, error);
  }
};

export const decryptAndRetrieve = <T = unknown>(key: string): T | null => {
  try {
    const encrypted = localStorage.getItem(key);
    const encryption_key =
      process.env.NEXT_PUBLIC_ENCRYPTION_KEY ?? "echo-ai-key";

    if (!encrypted) {
      console.warn(
        `[decryptAndRetrieve] No cookie in localStorage found for key: ${key}`,
      );
      return null;
    }

    const decrypted = CryptoJS.AES.decrypt(encrypted, encryption_key);

    const decryptedString = decrypted.toString(CryptoJS.enc.Utf8);

    if (!decryptedString) {
      console.error(
        `[decryptAndRetrieve] Decryption returned empty string. Encryption key might be wrong.`,
      );
      return null;
    }

    return JSON.parse(decryptedString) as T;
  } catch (error) {
    console.error(
      `[decryptAndRetrieve] Failed to decrypt/parse cookie in localstorage for key: ${key}`,
      error,
    );
    return null;
  }
};

export const removeEncrypted = (key: string): void => {
  localStorage.removeItem(key);
};

export const sanitizeInput = (input: string): string => {
  if (typeof window === "undefined") return input;

  return DOMPurify.sanitize(input, {
    ALLOWED_TAGS: [],
    ALLOWED_ATTR: [],
  });
};

export const sanitizeHTML = (html: string): string => {
  if (typeof window === "undefined") return html;

  return DOMPurify.sanitize(html, {
    ALLOWED_TAGS: ["b", "i", "em", "strong", "a", "p", "br"],
    ALLOWED_ATTR: ["href", "title"],
  });
};

export const dangerousPattern = /(script|<img|prompt)/i;
