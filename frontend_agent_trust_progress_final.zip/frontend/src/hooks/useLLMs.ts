"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { llmsService } from "@/services/llms.service";
import type { LLMModel, LlmProviderCatalogEntry } from "@/types";

export type LlmFormValues = Omit<
  Partial<LLMModel>,
  "context_window" | "max_output_tokens" | "temperature" | "token_usage_limit"
> & {
  context_window?: string;
  max_output_tokens?: string;
  temperature?: string;
  token_usage_limit?: string;
};

export const INITIAL_LLM_FORM: LlmFormValues = {
  model_id: "",
  name: "",
  provider: "",
  base_url: "",
  api_key: "",
  model_name: "",
  description: "",
  icon: "",
  api_version: "",
  deployment_name: "",
  model_family: "auto",
  reasoning_effort: null,
  context_window: "",
  max_output_tokens: "",
  temperature: "",
  enabled: true,
  is_embedding: false,
  credential_name: "",
  workbench_provider: "",
  charge_code: "",
  region_override: "",
  azureml_model_deployment: "",
  token_usage_limit: "",
  usage_limit_duration: null,
};

const NUMERIC_KEYS = [
  "context_window",
  "max_output_tokens",
  "temperature",
  "token_usage_limit",
] as const;

export function toApiPayload(values: LlmFormValues): Partial<LLMModel> {
  const payload: Record<string, unknown> = { ...values };

  NUMERIC_KEYS.forEach((key) => {
    const raw = values[key];
    if (raw === undefined) {
      delete payload[key];
      return;
    }
    const trimmed = String(raw).trim();
    if (trimmed === "") {
      payload[key] = null;
      return;
    }
    const parsed = Number(trimmed);

    payload[key] = Number.isFinite(parsed) ? parsed : null;
  });

  if ("enabled" in payload) {
    payload.enabled = values.enabled !== false;
  }

  if ("is_embedding" in payload) {
    payload.is_embedding = values.is_embedding === true;
  }

  if ("reasoning_effort" in payload) {
    const effort = String(values.reasoning_effort ?? "").trim();
    payload.reasoning_effort = effort === "" ? null : effort;
  }

  if ("model_family" in payload) {
    payload.model_family = String(values.model_family ?? "").trim() || "auto";
  }

  if ("usage_limit_duration" in payload) {
    const dur = String(values.usage_limit_duration ?? "").trim();
    payload.usage_limit_duration = dur === "" ? null : dur;
  }

  return payload as Partial<LLMModel>;
}

const EDITABLE_KEYS: ReadonlyArray<keyof LLMModel> = [
  "name",
  "provider",
  "base_url",
  "api_key",
  "model_name",
  "description",
  "icon",
  "api_version",
  "deployment_name",
  "model_family",
  "reasoning_effort",
  "context_window",
  "max_output_tokens",
  "temperature",
  "enabled",
  "is_embedding",
  "credential_name",
  "workbench_provider",
  "charge_code",
  "region_override",
  "azureml_model_deployment",
  "token_usage_limit",
  "usage_limit_duration",
];

export function useLLMs() {
  const [llmsData, setLLMsData] = useState<LLMModel[]>([]);
  const [providers, setProviders] = useState<LlmProviderCatalogEntry[] | null>(
    null,
  );
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<LlmFormValues>({ ...INITIAL_LLM_FORM });

  const originalFormRef = useRef<LlmFormValues>({ ...INITIAL_LLM_FORM });

  const updateField = useCallback((key: string, value: unknown) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  }, []);

  const patchForm = useCallback((patch: LlmFormValues) => {
    setForm((prev) => ({ ...prev, ...patch }));
  }, []);

  const resetForm = useCallback(() => {
    setForm({ ...INITIAL_LLM_FORM });
    originalFormRef.current = { ...INITIAL_LLM_FORM };
  }, []);

  const populateForEdit = useCallback((llm: LLMModel) => {
    const populated: Record<string, unknown> = { ...INITIAL_LLM_FORM };
    const source = llm as unknown as Record<string, unknown>;

    Object.keys(populated).forEach((key) => {
      if (key === "model_id") {
        populated.model_id = llm.model_id || llm.id || "";
        return;
      }
      const value = source[key];
      if (value === undefined || value === null) return;
      populated[key] = (NUMERIC_KEYS as readonly string[]).includes(key)
        ? String(value)
        : value;
    });

    populated.api_key = "";
    populated.enabled = llm.enabled !== false;
    populated.is_embedding = llm.is_embedding === true;

    setForm(populated as LlmFormValues);
    originalFormRef.current = { ...(populated as LlmFormValues) };
  }, []);

  const getProviderCatalog = useCallback(async () => {
    const response = await llmsService.getProviderCatalog();
    if (response.success && response.data?.providers) {
      setProviders(response.data.providers);
      return response.data.providers;
    }
    return null;
  }, []);

  const getLLMs = useCallback(async () => {
    setLoading(true);
    setError(null);
    const response = await llmsService.getModels();
    setLoading(false);

    if (response.success && response.data) {
      const models = response.data.models ?? [];
      setLLMsData(models);
      if (response.data.providers?.length) {
        setProviders(response.data.providers);
      }
      return models;
    }

    setError(response.error ?? "Could not load the registered models.");
    return [];
  }, []);

  const addModel = useCallback(
    async (values?: LlmFormValues) => {
      setSubmitting(true);
      setError(null);
      const response = await llmsService.addModel(toApiPayload(values ?? form));
      setSubmitting(false);
      if (!response.success) {
        setError(response.error ?? "Could not register the model.");
      }
      return response;
    },
    [form],
  );

  const editModel = useCallback(
    async (modelId: string, values?: LlmFormValues) => {
      setSubmitting(true);
      setError(null);

      const next = (values ?? form) as Record<string, unknown>;
      const original = originalFormRef.current as Record<string, unknown>;
      const dirty: LlmFormValues = {};

      EDITABLE_KEYS.forEach((key) => {
        const current = next[key as string];
        if (current === original[key as string]) return;

        if (key === "api_key" && !current) return;
        (dirty as Record<string, unknown>)[key as string] = current;
      });

      const response = await llmsService.updateModel(
        modelId,
        toApiPayload(dirty),
      );
      setSubmitting(false);
      if (!response.success) {
        setError(response.error ?? "Could not update the model.");
      }
      return response;
    },
    [form],
  );

  const deleteModel = useCallback(async (id: string) => {
    setError(null);
    const response = await llmsService.deleteModel(id);
    if (response.success) {
      setLLMsData((prev) => prev.filter((m) => (m.id ?? m.model_id) !== id));
    } else {
      setError(response.error ?? "Could not remove the model.");
    }
    return response;
  }, []);

  const setDefaultModel = useCallback(async (credentialId: string) => {
    setError(null);
    const response = await llmsService.setDefault(credentialId);
    if (response.success) {
      setLLMsData((prev) =>
        prev.map((m) => ({
          ...m,
          is_default: m.credential_id === credentialId,
        })),
      );
    } else {
      setError(response.error ?? "Could not set this model as the default.");
    }
    return response;
  }, []);

  const setDefaultEmbeddingModel = useCallback(async (credentialId: string) => {
    setError(null);
    const response = await llmsService.setDefaultEmbedding(credentialId);
    if (response.success) {
      setLLMsData((prev) =>
        prev.map((m) => ({
          ...m,
          is_default_embedding: m.credential_id === credentialId,
        })),
      );
    } else {
      setError(
        response.error ??
          "Could not set this model as the default embedding model.",
      );
    }
    return response;
  }, []);

  const testConnection = useCallback(
    async (credentialId: string, prompt?: string) => {
      return llmsService.testConnection(credentialId, prompt);
    },
    [],
  );

  useEffect(() => {
    getLLMs();
  }, [getLLMs]);

  return {
    llmsData,
    providers,
    loading,
    submitting,
    error,
    setError,
    form,
    updateField,
    patchForm,
    resetForm,
    populateForEdit,
    addModel,
    editModel,
    deleteModel,
    setDefaultModel,
    setDefaultEmbeddingModel,
    testConnection,
    getLLMs,
    getProviderCatalog,
  };
}
