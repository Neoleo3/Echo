"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { applicationsService } from "@/services";
import {
  ChatUploadResponse,
  EchoMessage,
  MessageAttachment,
  PendingUploadFile,
  RawMessage,
  SessionDocument,
  SessionDocumentsResponse,
  Step,
  StreamEvent,
} from "@/types";
import { useEchoChatStore } from "@/stores/echo-chat-store";
import { useRouter } from "next/navigation";
import { ROUTES } from "@/config";

const DOCUMENT_POLL_MS = 3000;

export function useEchoChat() {
  const router = useRouter();
  const messages = useEchoChatStore((s) => s.messages);
  const setMessages = useEchoChatStore((s) => s.setMessages);

  const streamingText = useEchoChatStore((s) => s.streamingText);
  const setStreamingText = useEchoChatStore((s) => s.setStreamingText);

  const steps = useEchoChatStore((s) => s.steps);
  const setSteps = useEchoChatStore((s) => s.setSteps);

  const isStreaming = useEchoChatStore((s) => s.isStreaming);
  const setIsStreaming = useEchoChatStore((s) => s.setIsStreaming);

  const sessionId = useEchoChatStore((s) => s.sessionId);
  const setSessionId = useEchoChatStore((s) => s.setSessionId);

  const surfaceVisible = useEchoChatStore((s) => s.surfaceVisible);
  const setSurfaceVisible = useEchoChatStore((s) => s.setSurfaceVisible);

  const sessionDocuments = useEchoChatStore((s) => s.sessionDocuments);
  const setSessionDocuments = useEchoChatStore((s) => s.setSessionDocuments);

  const isFileUploading = useEchoChatStore((s) => s.isFileUploading);
  const setIsFileUploading = useEchoChatStore((s) => s.setIsFileUploading);

  const pendingUploadFiles = useEchoChatStore((s) => s.pendingUploadFiles);
  const setPendingUploadFiles = useEchoChatStore(
    (s) => s.setPendingUploadFiles,
  );

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [_uploadedDocs, setUploadedDocs] = useState<
    { id: string; name: string }[]
  >([]);

  const controllerRef = useRef<AbortController | null>(null);
  const lastSeqRef = useRef<number>(-1);
  // Now stores full attachment metadata, not just ids
  const attachmentsRef = useRef<MessageAttachment[]>([]);

  const reset = useCallback(() => {
    controllerRef.current?.abort();
    setMessages([]);
    setStreamingText("");
    setSurfaceVisible(false);
    setSteps([]);
    setIsStreaming(false);
    setSessionId(null);
    setSessionDocuments([]);
    setPendingUploadFiles([]);
    lastSeqRef.current = -1;
    attachmentsRef.current = [];
  }, []);

  const docsAppIdRef = useRef<string | null>(null);

  const loadSessionDocuments = useCallback(
    async (appId: string, sid: string) => {
      docsAppIdRef.current = appId;
      try {
        const response = (await applicationsService.sessionDocuments(
          appId,
          sid,
        )) as { success: boolean; data?: SessionDocumentsResponse };
        const payload = response.data;
        const docs: SessionDocument[] = Array.isArray(payload?.documents)
          ? payload?.documents
          : [];
        console.log("docs", docs);
        setSessionDocuments(docs);
      } catch {
        setSessionDocuments([]);
      }
    },
    [],
  );

  useEffect(() => {
    const converting = sessionDocuments.some((d: SessionDocument) => {
      const status = (d.processing_status || "").toLowerCase();
      return status === "pending" || status === "processing";
    });
    const appId = docsAppIdRef.current;
    if (!converting || !appId || !sessionId) return;
    const timer = setTimeout(() => {
      void loadSessionDocuments(appId, sessionId);
    }, DOCUMENT_POLL_MS);
    return () => clearTimeout(timer);
  }, [sessionDocuments, sessionId, loadSessionDocuments]);

  const enrich = useCallback(
    async (appId: string, sid: string) => {
      try {
        const data = (await applicationsService.getChatMessages(appId, sid)) as
          | RawMessage[]
          | { data?: RawMessage[] };
        const rows: RawMessage[] = Array.isArray(data)
          ? data
          : ((data as { data?: RawMessage[] })?.data ?? []);
        if (!rows.length) return;
        console.log("MSG row: ", rows);
        setMessages(
          rows
            .filter((m) => m.execution_trace?.type !== "welcome_prompt")
            .map(
              (m): EchoMessage => ({
                role: m.role === "user" ? "user" : "agent",
                content: m.content,
                execution_trace: m.execution_trace,
              }),
            ),
        );
        await loadSessionDocuments(appId, sid);
      } catch {
        /* best-effort; the verbatim message already shows */
      }
    },
    [loadSessionDocuments],
  );

  const MAX_FILE_SIZE_BYTES = 32 * 1024 * 1024; // 32 MB Backend limit

  const uploadFiles = useCallback(
    async (appId: string, files: FileList) => {
      if (!sessionId) {
        router.push(`${ROUTES.CHAT}/${appId}`);
      }
      const oversized = Array.from(files).filter(
        (f) => f.size > MAX_FILE_SIZE_BYTES,
      );
      if (oversized.length > 0) {
        const names = oversized.map((f) => f.name).join(", ");
        setMessages((prev) => [
          ...prev,
          {
            role: "agent",
            content: `The following file${oversized.length > 1 ? "s exceed" : " exceeds"} the 32 MB upload limit and cannot be uploaded: ${names}. Please reduce the file size and try again.`,
          },
        ]);
        return;
      }

      const pending: PendingUploadFile[] = Array.from(files).map((f) => ({
        name: f.name,
        size: f.size,
      }));
      setPendingUploadFiles(pending);

      setIsFileUploading(true);
      try {
        const data = (await applicationsService.sessionFileUpload(
          appId,
          files,
          sessionId ? sessionId : undefined,
        )) as ChatUploadResponse;
        const effectiveSessionId = data?.session_id || sessionId;
        if (effectiveSessionId) {
          setSessionId(effectiveSessionId);
          router.push(`${ROUTES.CHAT}/${appId}/${effectiveSessionId}`);
        }
        const docs = data?.documents ?? [];

        // Accumulate attachment metadata for embedding in the next user message
        const successfulDocs = docs.filter(
          (d) => (d?.processing_status || "").toLowerCase() !== "failed",
        );
        attachmentsRef.current = [
          ...attachmentsRef.current,
          ...successfulDocs
            .filter((d) => Boolean(d.document_id))
            .map(
              (d): MessageAttachment => ({
                document_id: d.document_id,
                original_filename: d.original_filename,
                size_bytes: d.size_bytes,
                mime_type: d.mime_type,
              }),
            ),
        ];

        // Immediately show uploaded docs in the panel from the upload response,
        // then refresh with full metadata (size, chunks) via loadSessionDocuments.
        if (docs.length > 0) {
          setSessionDocuments((prev) => {
            const existingIds = new Set(prev.map((p) => p.document_id));
            return [
              ...prev,
              ...docs.filter(
                (d) => d.document_id && !existingIds.has(d.document_id),
              ),
            ];
          });
        }

        if (effectiveSessionId) {
          await enrich(appId, effectiveSessionId);
          // await loadSessionDocuments(appId, effectiveSessionId);
        }
      } catch {
        setMessages((prev) => [
          ...prev,
          { role: "agent", content: "The file upload failed." },
        ]);
      } finally {
        setIsFileUploading(false);
        setPendingUploadFiles([]);
      }
    },
    [sessionId, loadSessionDocuments, enrich],
  );

  const send = useCallback(
    async (appId: string, message: string) => {
      console.log("sessionID: ", sessionId);
      const text = message.trim();
      if (!text) return;

      // Snapshot and clear pending attachments before the message is added
      const pendingAttachments = attachmentsRef.current.slice();
      attachmentsRef.current = [];

      setMessages((prev) => [
        ...prev,
        {
          role: "user",
          content: text,
          attachments:
            pendingAttachments.length > 0 ? pendingAttachments : undefined,
        },
      ]);
      setStreamingText("");
      setSurfaceVisible(false);
      setSteps([]);
      setIsStreaming(true);
      lastSeqRef.current = -1;

      const controller = new AbortController();
      controllerRef.current = controller;

      let effectiveSession = sessionId;
      let committed = false;

      const onEvent = (msg: StreamEvent) => {
        if (msg.type === "beginRendering") {
          setSurfaceVisible(true);
        }

        if (msg.type === "dataModelUpdate") {
          const d = msg.data || {};
          if (d.steps !== undefined) setSteps(d.steps);
          if (d.output_delta !== undefined) {
            const { seq, text: frag } = d.output_delta;
            if (
              typeof frag === "string" &&
              (typeof seq !== "number" || seq > lastSeqRef.current)
            ) {
              if (typeof seq === "number") lastSeqRef.current = seq;
              setStreamingText((p) => p + frag);
              setSurfaceVisible(true);
            }
          }
          if (d.chat_session_id && !effectiveSession) {
            effectiveSession = d.chat_session_id;
            setSessionId(d.chat_session_id);
            router.push(`${ROUTES.CHAT}/${appId}/${d.chat_session_id}`);
          }
          if (d.final_output !== undefined && d.final_output !== "") {
            committed = true;
            setMessages((prev) => [
              ...prev,
              { role: "agent", content: d.final_output as string },
            ]);
            setSurfaceVisible(false);
            setStreamingText("");
            lastSeqRef.current = -1;
          }
        } else if (msg.type === "deleteSurface") {
          setSurfaceVisible(false);
          setSteps([]);
          setStreamingText("");
        } else if (msg.type === "error") {
          setSurfaceVisible(false);
          setSteps([]);
          setStreamingText("");
          setMessages((prev) => [
            ...prev,
            { role: "agent", content: msg.message || "Something went wrong." },
          ]);
        }
      };

      try {
        await applicationsService.chatSessionStream(
          appId,
          {
            message: text,
            session_id: sessionId,
            attachment_ids: pendingAttachments.length
              ? pendingAttachments.map((a) => a.document_id)
              : undefined,
          },
          (msg) => onEvent(msg as unknown as StreamEvent),
          controller.signal,
        );
      } catch (err: unknown) {
        console.error("chatStream error:", err);
        if ((err as { name?: string })?.name !== "AbortError") {
          setMessages((prev) => [
            ...prev,
            { role: "agent", content: "The request could not be completed." },
          ]);
        }
      } finally {
        setIsStreaming(false);
        setStreamingText("");
        if (committed && effectiveSession) enrich(appId, effectiveSession);
      }
    },
    [sessionId, enrich],
  );

  const abort = useCallback(() => {
    controllerRef.current?.abort();
    setIsStreaming(false);
    setStreamingText("");
  }, []);

  const removeDocument = useCallback((docId: string) => {
    attachmentsRef.current = attachmentsRef.current.filter(
      (a) => a.document_id !== docId,
    );
    setUploadedDocs((prev) => prev.filter((d) => d.id !== docId));
  }, []);

  const fetchHistory = useCallback(
    async (appId: string, chatId: string) => {
      const response = await applicationsService.getChatMessages(appId, chatId);
      if (response.success && Array.isArray(response.data)) {
        const mapped = response.data.map(
          (msg): EchoMessage => ({
            role: msg.role !== "user" ? "agent" : "user",
            content: msg.content,
            execution_trace:
              msg.execution_trace as EchoMessage["execution_trace"],
          }),
        );
        setMessages(mapped);
        setSessionId(chatId);
        await loadSessionDocuments(appId, chatId);
      }
    },
    [loadSessionDocuments],
  );

  return {
    messages,
    setMessages,
    streamingText,
    steps,
    isStreaming,
    sessionId,
    setSessionId,
    send,
    uploadFiles,
    reset,
    abort,
    surfaceVisible,
    isFileUploading,
    pendingUploadFiles,
    fetchHistory,
    removeDocument,
    sessionDocuments,
  };
}
