"use client";

import { useEffect, useState } from "react";
import {
  applyTheme,
  getPersistedTheme,
  type AppTheme,
} from "@/utils/theme.utils";

export function useTheme() {
  const [theme, setTheme] = useState<AppTheme>("light");

  useEffect(() => {
    setTheme(getPersistedTheme());
  }, []);

  const changeTheme = (mode: AppTheme) => {
    setTheme(mode);
    applyTheme(mode);
  };

  return {
    theme,
    setTheme: changeTheme,
  };
}
