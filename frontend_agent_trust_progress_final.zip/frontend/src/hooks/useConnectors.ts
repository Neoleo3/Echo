/**
 * Connectors hook (MCP, API, DB, Channel)
 */

"use client";

import { useState, useEffect, useCallback } from "react";
import { connectorsService } from "@/services/connectors.service";
import type { Connector, ApiResponse } from "@/types";
import type { ConnectorKind, SupportedDatabase } from "@/types/connector.types";
import {
  extractConnectorItems,
  type LegacyConnectorListResponse,
  type PaginatedResponse,
} from "@/services/connectors.service";

export interface ListedConnector extends Connector {
  kind: ConnectorKind;
}

export const connectorIdOf = (connector: Connector): string =>
  connector.connector_id ?? connector.id ?? "";

export function useConnectors() {
  const [connectors, setConnectors] = useState<ListedConnector[]>([]);
  const [supportedDatabases, setSupportedDatabases] = useState<
    SupportedDatabase[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAllConnectors = useCallback(async () => {
    setLoading(true);
    try {
      const results = await Promise.allSettled([
        connectorsService.getMCPConnectors(),
        connectorsService.getAPIConnectors(),
        connectorsService.getDBConnectors(),
        connectorsService.getChannelConnectors(),
      ]);

      const mcpRes: ApiResponse<PaginatedResponse<Connector>> | null =
        results[0].status === "fulfilled" ? results[0].value : null;
      const apiRes: ApiResponse<PaginatedResponse<Connector>> | null =
        results[1].status === "fulfilled" ? results[1].value : null;
      const dbRes: ApiResponse<LegacyConnectorListResponse> | null =
        results[2].status === "fulfilled" ? results[2].value : null;
      const channelRes: ApiResponse<Connector[]> | null =
        results[3].status === "fulfilled" ? results[3].value : null;

      const tag = (
        items: Connector[] | undefined,
        kind: ConnectorKind,
      ): ListedConnector[] => (items ?? []).map((item) => ({ ...item, kind }));

      const all: ListedConnector[] = [
        ...tag(extractConnectorItems(mcpRes?.data), "mcp"),
        ...tag(extractConnectorItems(apiRes?.data), "api"),
        ...tag(extractConnectorItems(dbRes?.data), "db"),
        ...tag(extractConnectorItems(channelRes?.data), "channel"),
      ];

      setConnectors(all);
      setError(null);
      return all;
    } finally {
      setLoading(false);
    }
  }, []);

  const loadSupportedDatabases = useCallback(async () => {
    const res = await connectorsService.getSupportedDatabases();
    if (!res.success || !res.data) return;
    const raw = (res.data as { databases?: unknown }).databases;
    if (!Array.isArray(raw)) return;
    setSupportedDatabases(
      raw.map((entry) =>
        typeof entry === "string"
          ? ({ db_type: entry, label: entry } as SupportedDatabase)
          : (entry as SupportedDatabase),
      ),
    );
  }, []);

  const deleteConnector = useCallback(
    async (kind: ConnectorKind, id: string) => {
      const response =
        kind === "mcp"
          ? await connectorsService.deleteMCPConnector(id)
          : kind === "api"
            ? await connectorsService.deleteAPIConnector(id)
            : kind === "db"
              ? await connectorsService.deleteDBConnector(id)
              : await connectorsService.deleteChannelConnector(id);

      if (!response.success) {
        setError(response.error ?? "Could not delete that connector.");
        return false;
      }
      await getAllConnectors();
      return true;
    },
    [getAllConnectors],
  );

  const testConnector = useCallback(
    async (kind: ConnectorKind, idOrPayload: string | unknown) => {
      if (kind === "db") {
        return connectorsService.testDBConnection(String(idOrPayload));
      }
      return connectorsService.testAPIConnector(idOrPayload);
    },
    [],
  );

  const refreshMCPDiscovery = useCallback(
    async (connectorId: string) => {
      const response = await connectorsService.refreshMCPDiscovery(connectorId);
      if (response.success) await getAllConnectors();
      return response;
    },
    [getAllConnectors],
  );

  useEffect(() => {
    getAllConnectors();
    loadSupportedDatabases();
  }, [getAllConnectors, loadSupportedDatabases]);

  return {
    connectors,
    supportedDatabases,
    loading,
    error,
    reload: getAllConnectors,
    getAllConnectors,
    loadSupportedDatabases,
    deleteConnector,
    testConnector,
    refreshMCPDiscovery,
  };
}
