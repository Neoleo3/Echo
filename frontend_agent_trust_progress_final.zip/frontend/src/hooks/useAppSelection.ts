"use client";

import { useEffect } from "react";
import { ROUTES } from "@/config";
import { useAppStore } from "@/stores/app-store";

export function useAppSelection(path: string) {
  const { applications, selectedApp, loading, selectApp, loadApplications } =
    useAppStore();

  useEffect(() => {
    const shouldLoadApplications =
      path === ROUTES.HOME ||
      path.startsWith(`${ROUTES.HOME}/`) ||
      path === ROUTES.LIBRARY ||
      path === ROUTES.CHAT ||
      path.startsWith(`${ROUTES.CHAT}/`);

    if (shouldLoadApplications) {
      loadApplications();
    }
  }, [path, loadApplications]);
  ``;

  return {
    applications,
    selectedApp,
    loading,
    selectApp,
    loadApplications,
  };
}
