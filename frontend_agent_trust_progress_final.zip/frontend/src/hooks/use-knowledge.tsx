import { useEffect, useState } from "react";

import {
  knowledgeService,
  extractKnowledgeItems,
  extractKnowledgeMeta,
} from "@/services/knowledge.service";
import { dangerousPattern } from "@/utils/security.utils";

export function useKnowledgeForm() {
  const [kModels, setKModels] = useState<any[]>([]);
  const [knowledgeData, setKnowledgeData] = useState<any[]>([]);
  const [knowledgeStats, setKnowledgeStats] = useState<any | null>(null);
  const [tloading, setTLoading] = useState<boolean>(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<any>({
    name: "",
    description: "",
    icon: "",
    source: "file_upload",
    processing: "vector",
    files: null,
  });

  const ResetForm = () => {
    setForm({
      name: "",
      description: "",
      icon: "",
      source: "file_upload",
      processing: "vector",
      files: null,
    });
  };

  const GetModels = async () => {
    setKModels([]);
    const response = await knowledgeService.getModels();
    if (response.success && response.data?.models) {
      setKModels(response.data.models as any[]);
      return;
    }
    setKModels([]);
  };

  const GetKnowledge = async (
    nextPage = page,
    nextPageSize = pageSize,
    nextSearch = search,
  ): Promise<any[]> => {
    setTLoading(true);
    const response = await knowledgeService.getKnowledge(
      nextPage,
      nextPageSize,
      nextSearch,
    );
    if (response.success) {
      const items = extractKnowledgeItems(response.data) as any[];
      const meta = extractKnowledgeMeta(response.data, nextPage, nextPageSize);
      setPage(meta.page);
      setPageSize(meta.pageSize);
      setTotal(meta.total);
      setTLoading(false);
      setKnowledgeData(items);
      return items;
    }
    setTLoading(false);
    setKnowledgeData([]);
    setTotal(0);
    return [];
  };

  const GetKnowledgeStats = async () => {
    const response = await knowledgeService.getStats();
    setKnowledgeStats({
      total: response.data?.total_sources ?? 0,
      synced: response.data?.synced ?? 0,
      total_documents: response.data?.total_documents ?? 0,
      total_chunks: response.data?.total_chunks ?? 0,
    });
  };

  const updateField = (key: string, value: any) => {
    if (dangerousPattern.test(value))
      alert(`${key} contains Input Validation Content`);
    else setForm((prev: any) => ({ ...prev, [key]: value }));
  };

  const SaveKnowledge = async () => {
    const formData = new FormData();
    const { files, source, processing, ...rest } = form;

    Object.entries(rest).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        formData.append(key, String(value));
      }
    });

    // Backend contract expects these names.
    formData.append("source_type", source ?? "file_upload");
    formData.append("processing_type", processing ?? "vector");

    if (files) {
      const fileList: File[] = Array.isArray(files)
        ? files
        : Array.from(files as FileList);

      fileList.forEach((file) => {
        formData.append("files", file);
      });
    }

    const response = await knowledgeService.createKnowledge(formData);
    if (response.success) {
      ResetForm();
      GetKnowledge();
      return true;
    }
    return false;
  };

  const DeleteKnowledge = async (id: string) => {
    const response = await knowledgeService.deleteKnowledge(id);
    return response.success;
  };

  useEffect(() => {
    GetKnowledge();
    GetKnowledgeStats();
    GetModels();
  }, []);

  return {
    knowledgeData,
    page,
    pageSize,
    total,
    search,
    tloading,
    form,
    updateField,
    knowledgeStats,
    kModels,
    SaveKnowledge,
    DeleteKnowledge,
    GetKnowledge,
    setPage,
    setPageSize,
    setSearch,
    setForm,
    ResetForm,
  };
}
