// "use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import type { Session, User, UserRole } from "@/types";
import { authService } from "@/services";
import {
  encryptAndStore,
  decryptAndRetrieve,
  removeEncrypted,
} from "@/utils/security.utils";
import { ROUTES, STORAGE_KEYS, AUTH_CONFIG, AUTH_ROLES } from "@/config";

export const AuthMissEndPoints = ["/health", "/ping", "/metrics"];

export const useAuth = () => {
  const path = usePathname();
  const router = useRouter();

  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  // const [agreementcheck, setAgreemnentCheck] = useState(false);
  const [actingRole, setActingRole] = useState<UserRole>(AUTH_ROLES.USER);

  const logoutInProgress = useRef(false);

  /**
   * Initial session restoration
   */
  useEffect(() => {
    const savedSession = decryptAndRetrieve<Session>(STORAGE_KEYS.SESSION);
    if (!savedSession) {
      setIsLoading(false);
      return;
    }
    if (Date.now() >= savedSession.expiresAt) {
      removeEncrypted(STORAGE_KEYS.SESSION);
      setIsLoading(false);
      return;
    }
    // setAgreemnentCheck(true);
    // if (decryptAndRetrieve(STORAGE_KEYS.AGREEMENT)) setAgreemnentCheck(true);
    setSession(savedSession);

    if (
      (path.startsWith(ROUTES.CONFIG) ||
        path.endsWith(ROUTES.MONITORING) ||
        path.endsWith(ROUTES.AGENT_TRUST)) &&
      savedSession.user?.role
    )
      setActingRole(savedSession.user?.role as UserRole);
    setIsLoading(false);
  }, []);

  /**
   * Logout
   */
  const logout = useCallback(async () => {
    if (logoutInProgress.current) return;

    logoutInProgress.current = true;

    try {
      if (session?.accessToken) {
        await authService.logout();
      }
    } catch (err) {
      // ignore logout failures
      console.error("Error while logout: ", err);
    } finally {
      // removeEncrypted(STORAGE_KEYS.AGREEMENT);
      removeEncrypted(STORAGE_KEYS.SESSION);
      setSession(null);
      router.push(ROUTES.LOGIN);
      logoutInProgress.current = false;
    }
  }, [router, session?.accessToken]);

  /**
   * Refresh token
   */
  const RefreshSession = useCallback(async () => {
    if (!session || logoutInProgress.current) return;

    try {
      const response = await authService.refreshToken();

      if (!response.success || !response.data) {
        throw new Error("Token*refresh failed");
      }

      const now = Date.now();
      const { session: _, ...user } = response.data;

      setSession((prev) => {
        if (!prev) return prev;

        const updatedSession: Session = {
          ...prev,
          user,
          accessToken: user.token,
          refreshToken: user.refresh_token,
          expiresAt: now + AUTH_CONFIG.SESSION_TIMEOUT,
          lastRefreshAt: now,
        };

        encryptAndStore(STORAGE_KEYS.SESSION, updatedSession);

        return updatedSession;
      });
    } catch {
      logout();
    }
  }, [logout, session]);

  /**
   * Session expiry check
   **/
  useEffect(() => {
    if (!session) return;

    const interval = setInterval(() => {
      if (Date.now() >= session.expiresAt) {
        logout();
      }
    }, AUTH_CONFIG.SESSION_CHECK_INTERVAL);

    return () => clearInterval(interval);
  }, [session, logout]);

  /**
   * Refresh timer
   */
  useEffect(() => {
    if (!session) return;

    const interval = setInterval(RefreshSession, AUTH_CONFIG.REFRESH_TIMEOUT);

    return () => clearInterval(interval);
  }, [session, RefreshSession]);

  /**
   * Refresh immedia*ely if overdue
   */
  useEffect(() => {
    if (!session) return;

    if (
      session.lastRefreshAt &&
      Date.now() - session.lastRefreshAt >= AUTH_CONFIG.REFRESH_TIMEOUT
    ) {
      RefreshSession();
    }
  }, [session, RefreshSession]);

  /**
   * Login
   */
  const login = useCallback(async (credentials: string) => {
    const response = await authService.login(credentials);

    if (response.success && response.data) {
      const now = Date.now();
      const { session: _, ...user } = response.data;

      const sessionData: Session = {
        user,
        accessToken: user.token,
        refreshToken: user.refresh_token,
        expiresAt: now + AUTH_CONFIG.SESSION_TIMEOUT,
        lastRefreshAt: now,
      };

      encryptAndStore(STORAGE_KEYS.SESSION, sessionData);

      setSession(sessionData);
    }

    return response;
  }, []);

  const callbackHandler = useCallback(async (user: User) => {
    if (!user) return "Error while SSO Login";
    const now = Date.now();
    const sessionData: Session = {
      user,
      accessToken: user.token,
      refreshToken: user.refresh_token,
      expiresAt: now + AUTH_CONFIG.SESSION_TIMEOUT,
      lastRefreshAt: now,
    };
    encryptAndStore(STORAGE_KEYS.SESSION, sessionData);

    setSession(sessionData);
    return sessionData;
  }, []);

  /**
   * Agreement
   */
  const Agreement = useCallback(() => {
    router.push(ROUTES.HOME);
    // if (!decryptAndRetrieve(STORAGE_KEYS.AGREEMENT))
    //   encryptAndStore(STORAGE_KEYS.AGREEMENT, new Date().toISOString());
  }, []);

  return {
    session,
    user: session?.user ?? null,
    isAuthenticated: !!session,
    isLoading,
    login,
    logout,
    RefreshSession,
    // agreementcheck,
    Agreement,
    setActingRole,
    actingRole,
    callbackHandler,
  };
};
