"use client";

import { useState, useEffect, useCallback } from "react";
import { applicationsService } from "@/services";
import {
  extractKnowledgeItems,
  knowledgeService,
} from "@/services/knowledge.service";
import type {
  ApiResponse,
  Application,
  ApplicationList,
  LLMModel,
  LlmLink,
  SkillLink,
} from "@/types";
import {
  isSelectableLlm,
  selectedLlmId,
  toLlmLinks,
} from "@/utils/llm-link.utils";
import { llmsService } from "@/services/llms.service";

export const NO_LLM_SELECTED_MESSAGE = "An LLM must be selected";

const INITIAL_FORM: Partial<Application> = {
  name: "",
  description: "",
  llm_links: [],
  data_source_ids: [],
  skill_links: [],
  designation_ids: [],
  business_unit_ids: [],
  tag_ids: [],
  available_for_all_users: false,
  upload_enabled: false,
  welcome_prompt: "",
  disclaimer: "",
  sorry_message: "",
  persona_id: "",
  persona_text: "",
  guardrail_category_ids: [],
  guardrail_text: "",
  starter_questions: [],
  logo_url: null,
};

export function useApplications() {
  const [applications, setApplications] = useState<ApplicationList[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [pagination, setPagination] = useState({
    page: 1,
    size: 100,
    total: 0,
  });
  const [form, setForm] = useState<Partial<Application>>({ ...INITIAL_FORM });
  const [dropdowns, setDropdowns] = useState<Record<string, unknown[]>>({
    llms: [],
    "data-sources": [],
    skills: [],
    designations: [],
    "business-units": [],
    tags: [],
    personas: [],
    "guardrail-categories": [],
  });

  const updateField = useCallback((key: string, value: unknown) => {
    setForm((p) => ({ ...p, [key]: value }));
  }, []);

  const resetForm = useCallback(() => {
    setForm({ ...INITIAL_FORM });
  }, []);

  const getApplications = useCallback(async () => {
    setLoading(true);
    const response = await applicationsService.getApplications(
      pagination.page,
      pagination.size,
    );
    setLoading(false);
    if (response.success && response.data) {
      setApplications(response.data.items ?? []);
      setPagination((p) => ({ ...p, total: response.data!.total ?? 0 }));
      return response.data.items ?? [];
    }
    return [] as Application[];
  }, [pagination.page, pagination.size]);

  const getVisibleApplications = useCallback(async () => {
    setLoading(true);
    const response = await applicationsService.getVisibleApplications(
      pagination.page,
      pagination.size,
    );
    setLoading(false);
    if (response.success && response.data) {
      const items = response.data.items ?? [];
      setPagination((p) => ({
        ...p,
        total: response.data!.total ?? items.length,
      }));
      return items;
    }
    return [] as Application[];
  }, [pagination.page, pagination.size]);

  const fetchDetails = useCallback(async (id: string) => {
    const response = await applicationsService.getApplication(id);
    if (response.success && response.data) {
      setForm((p) => ({ ...p, ...response.data }));
      return response.data;
    }
    return null;
  }, []);

  const loadDropdowns = useCallback(async () => {
    const [
      llmsRes,
      skillsRes,
      desigRes,
      buRes,
      tagsRes,
      personasRes,
      guardrailsRes,
    ] = await Promise.allSettled([
      llmsService.getModels(),
      applicationsService.getCatalog("skills"),
      applicationsService.getCatalog("designations"),
      applicationsService.getCatalog("business-units"),
      applicationsService.getCatalog("tags"),
      applicationsService.getCatalog("personas"),
      applicationsService.getCatalog("guardrail-categories"),
    ]);

    const llms = (
      llmsRes.status === "fulfilled" && llmsRes.value.success
        ? (llmsRes.value.data?.models ?? [])
        : []
    ).filter(isSelectableLlm);

    const skills = (
      skillsRes.status === "fulfilled" && skillsRes.value.success
        ? ((skillsRes.value.data as Record<string, unknown>[]) ?? [])
        : []
    ).map((s: Record<string, unknown>) => ({
      id: s.skill_id,
      skill_type: s.skill_type,
      rawName: s.name,
      name: `${s.skill_type}: ${s.name}`,
    }));

    const designations =
      desigRes.status === "fulfilled" && desigRes.value.success
        ? ((desigRes.value.data as unknown[]) ?? [])
        : [];

    const businessUnits =
      buRes.status === "fulfilled" && buRes.value.success
        ? ((buRes.value.data as unknown[]) ?? [])
        : [];

    const tags =
      tagsRes.status === "fulfilled" && tagsRes.value.success
        ? ((tagsRes.value.data as unknown[]) ?? [])
        : [];

    const personas =
      personasRes.status === "fulfilled" && personasRes.value.success
        ? ((personasRes.value.data as Record<string, unknown>[]) ?? []).map(
            (p) => ({
              id: (p.persona_id ?? p.id ?? "") as string,
              name: (p.name ??
                p.persona_name ??
                String(p.persona_id ?? "")) as string,
            }),
          )
        : [];

    const guardrails =
      guardrailsRes.status === "fulfilled" && guardrailsRes.value.success
        ? ((guardrailsRes.value.data as unknown[]) ?? [])
        : [];

    let knowledgeSources: unknown[] = [];
    try {
      const kbRes = await knowledgeService.getKnowledge();
      if (kbRes.success && kbRes.data) {
        const items = extractKnowledgeItems(kbRes.data);
        knowledgeSources = items
          .filter((k) => k.status === "synced")
          .map((k) => ({ id: k.id, name: k.name, kind: "knowledge" as const }));
      }
    } catch {}

    setDropdowns({
      llms,
      "data-sources": knowledgeSources,
      skills,
      designations,
      "business-units": businessUnits,
      tags,
      personas: personas,
      "guardrail-categories": guardrails,
    });
  }, []);

  const submitApplication = useCallback(
    async (
      tab: string,
      appId: string | null = null,
    ): Promise<ApiResponse<Application>> => {
      setSubmitting(true);
      try {
        if (tab === "chat-configuration") {
          const { logo_url, ...rest } = form as Application;

          const payload = {
            ...rest,
            llm_links: toLlmLinks(rest.llm_links as LlmLink[] | undefined),
          };

          const response = appId
            ? await applicationsService.updateApplication(appId, payload)
            : await applicationsService.createApplication(payload);

          if (response.success && logo_url && typeof logo_url !== "string") {
            const id =
              (response.data as Application)?.application_id ?? appId ?? "";
            await applicationsService.uploadLogo(
              id,
              logo_url as unknown as File,
            );
          }
          setSubmitting(false);
          return response;
        }

        if (tab === "dashboard" && appId) {
          const response = await applicationsService.publishApplication(appId);
          if (response.success) await getApplications();
          setSubmitting(false);
          return response as ApiResponse<Application>;
        }
      } catch {
        /* handled upstream */
      }

      setSubmitting(false);
      return { success: false, error: "Unknown submit error" };
    },
    [form, getApplications],
  );

  const selectLlm = useCallback((model: Partial<LLMModel> | null) => {
    setForm((prev) => ({ ...prev, llm_links: toLlmLinks(model) }));
  }, []);

  const currentLlmId = selectedLlmId(form);

  const saveSetup = useCallback(
    async (appId: string) => {
      setSubmitting(true);
      // const response = await applicationsService.updateSetup(appId, {
      //   llm_links: toLlmLinks(form.llm_links as LlmLink[] | undefined),
      //   skill_links: (form.skill_links as SkillLink[] | undefined) ?? [],
      //   data_source_ids: form.data_source_ids ?? [],
      // });
      // setSubmitting(false);
      // return response;
    },
    [form],
  );

  const deleteApplication = useCallback(async (id: string) => {
    return applicationsService.deleteApplication(id);
  }, []);

  useEffect(() => {
    loadDropdowns();
    getApplications();
  }, []);

  return {
    applications,
    loading,
    submitting,
    pagination,
    setPagination,
    form,
    setForm,
    dropdowns,
    updateField,
    selectLlm,
    currentLlmId,
    saveSetup,
    resetForm,
    getApplications,
    getVisibleApplications,
    fetchDetails,
    loadDropdowns,
    submitApplication,
    deleteApplication,
  };
}
