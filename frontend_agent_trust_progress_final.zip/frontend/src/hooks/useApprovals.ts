"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { applicationsService } from "@/services";
import type { Application, ApprovalQueueItem } from "@/types";

export interface UseApprovalsOptions {
  enabled?: boolean;
}

export function useApprovals({ enabled = true }: UseApprovalsOptions = {}) {
  const [queue, setQueue] = useState<ApprovalQueueItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [actingOn, setActingOn] = useState<string | null>(null);

  const [details, setDetails] = useState<Record<string, Application>>({});
  const [detailLoading, setDetailLoading] = useState<string | null>(null);

  const enabledRef = useRef(enabled);
  useEffect(() => {
    enabledRef.current = enabled;
  }, [enabled]);

  const inFlightRef = useRef(false);

  const loadQueue = useCallback(async () => {
    if (!enabledRef.current || inFlightRef.current) return;
    inFlightRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const response = await applicationsService.getApprovalQueue();
      if (!enabledRef.current) return;
      if (response.success) {
        setQueue(response.data ?? []);
        return;
      }
      setError(response.error ?? "Could not load the approval queue.");
    } finally {
      inFlightRef.current = false;
      setLoading(false);
    }
  }, []);

  const loadDetail = useCallback(
    async (applicationId: string) => {
      if (details[applicationId]) return details[applicationId];
      setDetailLoading(applicationId);
      setError(null);
      const response = await applicationsService.getApplication(applicationId);
      setDetailLoading(null);
      if (response.success && response.data) {
        const detail = response.data;
        setDetails((prev) => ({ ...prev, [applicationId]: detail }));
        return detail;
      }
      setError(
        response.error ?? "Could not load the application configuration.",
      );
      return undefined;
    },
    [details],
  );

  const approve = useCallback(async (applicationId: string) => {
    setActingOn(applicationId);
    setError(null);
    const response =
      await applicationsService.approveApplication(applicationId);
    setActingOn(null);
    if (!response.success) {
      setError(response.error ?? "Could not approve the application.");
      return false;
    }
    setQueue((prev) =>
      prev.filter((item) => item.application_id !== applicationId),
    );
    return true;
  }, []);

  const reject = useCallback(
    async (applicationId: string, comment?: string) => {
      setActingOn(applicationId);
      setError(null);
      const response = await applicationsService.rejectApplication(
        applicationId,
        comment,
      );
      setActingOn(null);
      if (!response.success) {
        setError(response.error ?? "Could not reject the application.");
        return false;
      }
      setQueue((prev) =>
        prev.filter((item) => item.application_id !== applicationId),
      );
      return true;
    },
    [],
  );

  useEffect(() => {
    if (!enabled) {
      setQueue([]);
      setDetails({});
      setError(null);
      return;
    }
    loadQueue();
  }, [enabled, loadQueue]);

  return {
    queue,
    loading,
    error,
    actingOn,
    details,
    detailLoading,
    loadQueue,
    loadDetail,
    approve,
    reject,
    clearError: useCallback(() => setError(null), []),
  };
}
