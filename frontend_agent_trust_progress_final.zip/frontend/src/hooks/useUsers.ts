"use client";

import { useState, useEffect, useCallback } from "react";
import { usersService } from "@/services/users.service";
import { applicationsService } from "@/services";
import type { AdminUser, LookupItem } from "@/types";

export interface UserFormState {
  email: string;
  display_name: string;
  role: string;
  designation_ids: string[];
  business_unit_ids: string[];
}

export interface UserDropDowns {
  roles: { label: string; value: string }[];
  designations: LookupItem[];
  business_units: LookupItem[];
}

export interface UserFilters {
  search: string;
  role: string;
  businessUnitId: string;
  designationId: string;
}

const INITIAL_FORM: UserFormState = {
  email: "",
  display_name: "",
  role: "",
  designation_ids: [],
  business_unit_ids: [],
};

export const INITIAL_USER_FILTERS: UserFilters = {
  search: "",
  role: "",
  businessUnitId: "",
  designationId: "",
};

const ALL_ROLES = [
  { label: "User", value: "user" },
  { label: "Admin", value: "admin" },
  { label: "Super Admin", value: "super_admin" },
];

export const roleLabel = (role: string | undefined): string =>
  ALL_ROLES.find((r) => r.value === role)?.label ?? role ?? "";

export const userKey = (user: AdminUser): string =>
  user.user_id ?? user.id ?? user.email;

export const isUserActive = (user: AdminUser): boolean =>
  user.is_active !== false;

export const resolveAssigned = (
  items: LookupItem[] | undefined,
  ids: string[] | undefined,
  catalog: LookupItem[],
): string[] => {
  if (items && items.length > 0) return items.map((item) => item.name);
  return (ids ?? []).map(
    (id) => catalog.find((entry) => entry.id === id)?.name ?? id,
  );
};

const errorMessage = (fallback: string, err: unknown): string => {
  const detail = (err as { response?: { data?: { detail?: string } } })
    ?.response?.data?.detail;
  return detail ?? (err as Error)?.message ?? fallback;
};

export function useUsers() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    page: 1,
    size: 100,
    total: 0,
  });
  const [filters, setFilters] = useState<UserFilters>({
    ...INITIAL_USER_FILTERS,
  });
  const [form, setForm] = useState<UserFormState>({ ...INITIAL_FORM });
  const [dropdowns, setDropdowns] = useState<UserDropDowns>({
    roles: ALL_ROLES,
    designations: [],
    business_units: [],
  });

  const setPage = useCallback((page: number) => {
    setPagination((prev) => ({ ...prev, page }));
  }, []);

  const setPageSize = useCallback((size: number) => {
    setPagination((prev) => ({ ...prev, size, page: 1 }));
  }, []);

  const updateFilters = useCallback((patch: Partial<UserFilters>) => {
    setFilters((prev) => ({ ...prev, ...patch }));

    setPagination((prev) => ({ ...prev, page: 1 }));
  }, []);

  const updateField = useCallback(
    (key: keyof UserFormState, value: unknown) => {
      setForm((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  const toggleFormId = useCallback(
    (key: "designation_ids" | "business_unit_ids", id: string) => {
      setForm((prev) => {
        const current = prev[key];
        return {
          ...prev,
          [key]: current.includes(id)
            ? current.filter((entry) => entry !== id)
            : [...current, id],
        };
      });
    },
    [],
  );

  const resetForm = useCallback(() => {
    setForm({ ...INITIAL_FORM });
  }, []);

  const populateForEdit = useCallback((user: AdminUser) => {
    setForm({
      email: user.email ?? "",
      display_name: user.display_name ?? "",
      role: user.role ?? "",
      designation_ids: [
        ...(user.designations?.map((d) => d.id) ?? user.designation_ids ?? []),
      ],
      business_unit_ids: [
        ...(user.business_units?.map((b) => b.id) ??
          user.business_unit_ids ??
          []),
      ],
    });
  }, []);

  const getUserOptions = useCallback(async () => {
    const [desigRes, buRes] = await Promise.all([
      applicationsService.getCatalog("designations"),
      applicationsService.getCatalog("business-units"),
    ]);

    const toLookup = (rows: unknown, idKey: string): LookupItem[] =>
      ((rows as Record<string, unknown>[]) ?? []).map((row) => ({
        id: (row.id ?? row[idKey]) as string,
        name: row.name as string,
      }));

    setDropdowns({
      roles: ALL_ROLES,
      designations: desigRes.success
        ? toLookup(desigRes.data, "designation_id")
        : [],
      business_units: buRes.success
        ? toLookup(buRes.data, "business_unit_id")
        : [],
    });
  }, []);

  const getUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    const response = await usersService.getUsers(
      pagination.page,
      pagination.size,
      filters.search,
      filters.role,
    );
    setLoading(false);

    if (response.success && response.data) {
      setUsers(response.data.items ?? []);
      setPagination((prev) => ({ ...prev, total: response.data!.total ?? 0 }));
      return;
    }
    setUsers([]);
    setError(response.error ?? "Could not load users.");
  }, [pagination.page, pagination.size, filters.search, filters.role]);

  const submitUser = useCallback(
    async (editingUser: AdminUser | null) => {
      setSubmitting(true);
      setError(null);
      try {
        const response = editingUser
          ? // The update endpoint does not accept `email`; identity is not
            // editable, and sending it would suggest otherwise.
            await usersService.updateUser(userKey(editingUser), {
              display_name: form.display_name,
              role: form.role,
              designation_ids: form.designation_ids,
              business_unit_ids: form.business_unit_ids,
            })
          : await usersService.createUser(form);

        if (!response.success) {
          setError(response.error ?? "Could not save the user.");
          return false;
        }
        await getUsers();
        return true;
      } catch (err: unknown) {
        setError(errorMessage("Could not save the user.", err));
        return false;
      } finally {
        setSubmitting(false);
      }
    },
    [form, getUsers],
  );

  const deleteUser = useCallback(
    async (id: string) => {
      setError(null);
      try {
        const response = await usersService.deleteUser(id);
        if (!response.success) {
          setError(response.error ?? "Could not remove the user.");
          return false;
        }
        await getUsers();
        return true;
      } catch (err: unknown) {
        setError(errorMessage("Could not remove the user.", err));
        return false;
      }
    },
    [getUsers],
  );

  /** `activate` is the state being moved to, not the current one. */
  const toggleUserStatus = useCallback(
    async (id: string, activate: boolean) => {
      setError(null);
      const response = await usersService.toggleUserStatus(id, activate);
      if (!response.success) {
        setError(
          response.error ??
            `Could not ${activate ? "activate" : "deactivate"} the user.`,
        );
        return false;
      }
      await getUsers();
      return true;
    },
    [getUsers],
  );

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => {
    getUserOptions();
  }, [getUserOptions]);

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => {
    getUsers();
  }, [getUsers]);

  return {
    users,
    dropdowns,
    form,
    loading,
    submitting,
    error,
    setError,
    pagination,
    setPagination,
    setPage,
    setPageSize,
    filters,
    updateFilters,
    updateField,
    toggleFormId,
    resetForm,
    populateForEdit,
    setForm,
    getUsers,
    submitUser,
    deleteUser,
    toggleUserStatus,
    getUserOptions,
  };
}
