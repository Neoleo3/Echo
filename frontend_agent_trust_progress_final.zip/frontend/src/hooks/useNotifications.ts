"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { notificationsService } from "@/services/notifications.service";
import type { AppNotification } from "@/types";

const POLL_INTERVAL_MS = 60_000;

export interface UseNotificationsOptions {
  enabled?: boolean;
}

export function useNotifications({
  enabled = true,
}: UseNotificationsOptions = {}) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const enabledRef = useRef(enabled);
  useEffect(() => {
    enabledRef.current = enabled;
  }, [enabled]);

  const refreshUnreadCount = useCallback(async () => {
    if (!enabledRef.current) return;
    const response = await notificationsService.getUnreadCount();
    if (!enabledRef.current) return;
    if (response.success && response.data) {
      setUnreadCount(response.data.count ?? 0);
    }
  }, []);

  const loadNotifications = useCallback(async () => {
    if (!enabledRef.current) return;
    setLoading(true);
    setError(null);
    const response = await notificationsService.getNotifications();
    if (!enabledRef.current) return;
    setLoading(false);
    if (response.success) {
      const items = response.data ?? [];
      setNotifications(items);
      setUnreadCount(items.filter((n) => !n.is_read).length);
      return;
    }
    setError(response.error ?? "Could not load notifications.");
  }, []);

  const markRead = useCallback(async (notificationId: string) => {
    const response = await notificationsService.markRead(notificationId);
    if (!response.success) {
      setError(response.error ?? "Could not mark the notification as read.");
      return false;
    }
    setNotifications((prev) =>
      prev.map((n) =>
        n.notification_id === notificationId ? { ...n, is_read: true } : n,
      ),
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
    return true;
  }, []);

  const markAllRead = useCallback(async () => {
    const response = await notificationsService.markAllRead();
    if (!response.success) {
      setError(response.error ?? "Could not mark notifications as read.");
      return false;
    }
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadCount(0);
    return true;
  }, []);

  useEffect(() => {
    if (!enabled) {
      setNotifications([]);
      setUnreadCount(0);
      setError(null);
      return;
    }
    refreshUnreadCount();
    const timer = setInterval(refreshUnreadCount, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [enabled, refreshUnreadCount]);

  return {
    notifications,
    unreadCount,
    loading,
    error,
    loadNotifications,
    refreshUnreadCount,
    markRead,
    markAllRead,
  };
}
