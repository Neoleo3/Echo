"use client";

import { useState, useEffect, useCallback } from "react";
import { settingsService, LookupItem } from "@/services/settings.service";

export function useSettings() {
  const [designations, setDesignations] = useState<LookupItem[]>([]);
  const [businessUnits, setBusinessUnits] = useState<LookupItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    const [desigRes, buRes] = await Promise.all([
      settingsService.getDesignations(),
      settingsService.getBusinessUnits(),
    ]);
    setLoading(false);

    if (desigRes.success && desigRes.data) {
      const items = Array.isArray(desigRes.data)
        ? desigRes.data
        : ((desigRes.data as unknown as { data: LookupItem[] }).data ?? []);
      setDesignations(items);
    } else if (!desigRes.success) {
      setError(desigRes.error ?? "Could not load designations.");
    }
    if (buRes.success && buRes.data) {
      const items = Array.isArray(buRes.data)
        ? buRes.data
        : ((buRes.data as unknown as { data: LookupItem[] }).data ?? []);
      setBusinessUnits(items);
    } else if (!buRes.success) {
      setError((prev) =>
        prev
          ? `${prev} Could not load business units.`
          : "Could not load business units.",
      );
    }
  }, []);

  const createDesignation = useCallback(
    async (name: string): Promise<boolean> => {
      setSubmitting(true);
      setError(null);
      const res = await settingsService.createDesignation(name.trim());
      setSubmitting(false);
      if (!res.success) {
        setError(res.error ?? "Could not create designation.");
        return false;
      }
      await fetchAll();
      return true;
    },
    [fetchAll],
  );

  const createBusinessUnit = useCallback(
    async (name: string): Promise<boolean> => {
      setSubmitting(true);
      setError(null);
      const res = await settingsService.createBusinessUnit(name.trim());
      setSubmitting(false);
      if (!res.success) {
        setError(res.error ?? "Could not create business unit.");
        return false;
      }
      await fetchAll();
      return true;
    },
    [fetchAll],
  );
  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const deleteDesignation = useCallback(
    async (id: string): Promise<boolean> => {
      setSubmitting(true);
      setError(null);
      const res = await settingsService.deleteDesignation(id);
      setSubmitting(false);
      if (!res.success) {
        setError(res.error ?? "Could not delete designation");
        return false;
      }
      await fetchAll();
      return true;
    },
    [fetchAll],
  );

  const deleteBusinessUnit = useCallback(
    async (id: string): Promise<boolean> => {
      setSubmitting(true);
      setError(null);
      const res = await settingsService.deleteBusinessUnit(id);
      setSubmitting(false);
      if (!res.success) {
        setError(res.error ?? "Could not delete business unit");
        return false;
      }
      await fetchAll();
      return true;
    },
    [fetchAll],
  );

  return {
    designations,
    businessUnits,
    loading,
    submitting,
    error,
    setError,
    fetchAll,
    createDesignation,
    createBusinessUnit,
    deleteBusinessUnit,
    deleteDesignation,
  };
}
