import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

function isDevelopmentEnvironment() {
  const runtime = globalThis as typeof globalThis & {
    process?: { env?: { NODE_ENV?: string } };
  };

  return runtime.process?.env?.NODE_ENV === "development";
}

function buildApiCsp() {
  return [
    "default-src 'none'",
    "base-uri 'self'",
    "frame-ancestors 'none'",
    "form-action 'self'",
  ].join("; ");
}

function buildPageCsp(nonce: string) {
  const isDev = isDevelopmentEnvironment();

  return [
    "default-src 'self'",
    // `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${isDev ? " 'unsafe-eval'" : ""}`,
    `script-src 'self' 'unsafe-inline' 'unsafe-eval'`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: https:",
    "connect-src 'self' https: wss:",
    "font-src 'self' data:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join("; ");
}

export function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  const isApiRoute = pathname.startsWith("/api");
  const nonce = crypto.randomUUID().replace(/-/g, "");
  const contentSecurityPolicy = isApiRoute
    ? buildApiCsp()
    : buildPageCsp(nonce);

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("Content-Security-Policy", contentSecurityPolicy);

  if (!isApiRoute) {
    requestHeaders.set("x-nonce", nonce);
  }

  // Update the html lang attribute
  const response = NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });

  response.headers.set("Content-Security-Policy", contentSecurityPolicy);

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
