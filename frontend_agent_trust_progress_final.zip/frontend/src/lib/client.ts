"use client";

import { ENV } from "@/config";

export const API_BASE = (): string => ENV.API_BASE_URL;

export type Method = "get" | "post" | "put" | "patch" | "delete";

export interface RequestOpts {
  /** JSON body (serialized) — ignored for form uploads. */
  body?: unknown;
  /** Extra query params. */
  query?: Record<string, string | number | boolean | undefined | null>;
  /** Extra headers. */
  headers?: Record<string, string>;
  signal?: AbortSignal;
}

function buildUrl(path: string, query?: RequestOpts["query"]): string {
  const base = API_BASE().replace(/\/$/, "");
  const clean = path.replace(/^\//, "");
  const url = `${base}/${clean}`;
  if (!query) return url;
  const qs = Object.entries(query)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(
      ([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`,
    )
    .join("&");
  return qs ? `${url}${url.includes("?") ? "&" : "?"}${qs}` : url;
}

/** JSON request. Returns parsed JSON (or null on 204). Throws ApiError on !ok. */
export async function request<T = unknown>(
  method: Method,
  path: string,
  opts: RequestOpts = {},
): Promise<T> {
  const hasBody = opts.body !== undefined && method !== "get";
  const res = await fetch(buildUrl(path, opts.query), {
    method: method.toUpperCase(),
    headers: {
      accept: "application/json",
      ...(hasBody ? { "Content-Type": "application/json" } : {}),
      ...(opts.headers || {}),
    },
    body: hasBody ? JSON.stringify(opts.body) : undefined,
    credentials: "include",
    signal: opts.signal,
  });
  if (res.status === 204) return null as T;
  const text = await res.text();
  const data = text ? safeJson(text) : null;
  if (!res.ok) {
    throw new ApiError(
      res.status,
      (data as Record<string, string>)?.detail || res.statusText,
      data,
    );
  }
  return data as T;
}

/** multipart/form-data upload (no Content-Type — the browser sets the boundary). */
export async function upload<T = unknown>(
  path: string,
  form: FormData,
  opts: Omit<RequestOpts, "body"> = {},
): Promise<T> {
  const res = await fetch(buildUrl(path, opts.query), {
    method: "POST",
    headers: {
      accept: "application/json",
      ...(opts.headers || {}),
    },
    body: form,
    credentials: "include",
    signal: opts.signal,
  });
  const text = await res.text();
  const data = text ? safeJson(text) : null;
  if (!res.ok) {
    throw new ApiError(
      res.status,
      (data as Record<string, string>)?.detail || res.statusText,
      data,
    );
  }
  return data as T;
}

/** SSE POST stream. Parses `data: <json>` frames and calls onEvent per frame. */
export async function stream(
  path: string,
  body: unknown,
  onEvent: (msg: Record<string, unknown>) => void,
  opts: { signal?: AbortSignal } = {},
): Promise<void> {
  const res = await fetch(buildUrl(path), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      accept: "text/event-stream",
    },
    body: JSON.stringify(body),
    credentials: "include",
    signal: opts.signal,
  });
  if (!res.ok) throw new ApiError(res.status, res.statusText);
  const reader = res.body?.getReader();
  if (!reader) return;
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const parsed = safeJson(line.slice(6));
      if (parsed !== undefined) onEvent(parsed as Record<string, unknown>);
    }
  }
}

export class ApiError extends Error {
  status: number;
  data: unknown;
  constructor(status: number, message: string, data?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

function safeJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}
