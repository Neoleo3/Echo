import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatSize(sizeBytes?: number): string {
  if (!sizeBytes || sizeBytes <= 0) return "0 B";
  const kb = 1024;
  const mb = kb * 1024;
  if (sizeBytes >= mb) return `${(sizeBytes / mb).toFixed(2)} MB`;
  if (sizeBytes >= kb) return `${(sizeBytes / kb).toFixed(1)} KB`;
  return `${sizeBytes} B`;
}
