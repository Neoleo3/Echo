import React from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Line,
  ComposedChart,
} from "recharts";

const AdoptionChart = ({ data }: any) => {
  if (!data || !data.trend_data || data.trend_data.length === 0) {
    return <div className="alert alert-info">No adoption data available</div>;
  }

  const growth = data.growth_percentage;
  const growthText = growth >= 0 ? `+${growth}%` : `${growth}%`;

  return (
    <div>
      <div
        style={{
          marginBottom: "1rem",
          color: "var(--text-secondary)",
          fontSize: "0.9rem",
        }}
      >
        Growth:{" "}
        <span
          style={{
            color: growth >= 0 ? "var(--accent-green)" : "var(--accent-red)",
            fontWeight: 600,
          }}
        >
          {growthText}
        </span>
      </div>
      <div className="chart-container">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data.trend_data}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
            <XAxis
              dataKey="date"
              stroke="var(--text-secondary)"
              tick={{ fill: "var(--text-secondary)", fontSize: 10 }}
              tickFormatter={(date: any) => {
                const d = new Date(date);
                return `${d.getMonth() + 1}/${d.getDate()}`;
              }}
            />
            <YAxis
              stroke="var(--text-secondary)"
              tick={{ fill: "var(--text-secondary)", fontSize: 12 }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "var(--secondary-bg)",
                border: "1px solid var(--border-color)",
                borderRadius: "8px",
                color: "var(--text-primary)",
                boxShadow: "var(--shadow-sm)",
              }}
              labelStyle={{ color: "var(--text-muted)" }}
            />
            <Legend
              wrapperStyle={{
                color: "var(--text-secondary)",
                fontSize: "12px",
              }}
            />

            {/* Daily Active Users */}
            <Area
              type="monotone"
              dataKey="active_users"
              name="Daily Active Users"
              stroke="var(--accent-blue)"
              fill="var(--accent-blue)"
              fillOpacity={0.25}
            />

            {/* Cumulative Adoption */}
            <Line
              type="monotone"
              dataKey="cumulative_users"
              name="Total Adopted Users"
              stroke="var(--accent-purple)"
              strokeWidth={2}
              dot={false}
              strokeDasharray="5 5"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default AdoptionChart;
