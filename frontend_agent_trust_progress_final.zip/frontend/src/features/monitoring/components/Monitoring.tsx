"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  Activity,
  DollarSign,
  Users,
  Zap,
  TrendingUp,
  Clock,
  RefreshCw,
  Wifi,
  WifiOff,
  BarChart2,
  AlertCircle,
  CheckCircle,
  Gauge,
  ClipboardList,
  Wrench,
  Database,
  Timer,
  IndianRupee,
} from "lucide-react";
import {
  fetchStats,
  fetchTimeline,
  fetchTokenUsage,
  fetchToolUsage,
  fetchProviderStats,
  fetchUserActivity,
  fetchPeakHours,
  fetchAdoptionTrend,
  fetchErrors,
  fetchEvents,
  // checkHealth,
} from "./api";
import "./monitoring.css";
import TimelineChart from "./TimelineChart";
import AdoptionChart from "./AdoptionChart";

// ─── Types ────────────────────────────────────────────────────────────────────

type TimeRangeValue = "5m" | "15m" | "30m" | "1h" | "6h" | "24h" | "7d" | "";

const TIME_RANGES: { label: string; value: TimeRangeValue }[] = [
  { label: "Last 5 min", value: "5m" },
  { label: "Last 15 min", value: "15m" },
  { label: "Last 30 min", value: "30m" },
  { label: "Last 1 hour", value: "1h" },
  { label: "Last 6 hours", value: "6h" },
  { label: "Last 24 hrs", value: "24h" },
  { label: "Last 7 days", value: "7d" },
  { label: "All time", value: "" },
];

const DURATION_MS: Record<Exclude<TimeRangeValue, "">, number> = {
  "5m": 5 * 60 * 1000,
  "15m": 15 * 60 * 1000,
  "30m": 30 * 60 * 1000,
  "1h": 60 * 60 * 1000,
  "6h": 6 * 60 * 60 * 1000,
  "24h": 24 * 60 * 60 * 1000,
  "7d": 7 * 24 * 60 * 60 * 1000,
};

function buildPayloadISO(rangeValue: TimeRangeValue) {
  if (!rangeValue) return { from_ts: null, to_ts: null };
  const now = new Date();
  const from = new Date(now.getTime() - DURATION_MS[rangeValue]);
  return { from_ts: from.toISOString(), to_ts: now.toISOString() };
}

// ─── Formatters ───────────────────────────────────────────────────────────────

const fmt = (n: any) => (n == null ? "—" : Number(n).toLocaleString());
const fmtCost = (n: any) => (n == null ? "—" : `$${Number(n).toFixed(4)}`);
const fmtPct = (n: any) =>
  n == null ? "—" : `${(Number(n) * 100).toFixed(1)}%`;
const fmtMs = (n: any) => (n == null ? "—" : `${Number(n).toFixed(0)} ms`);

// ─── Stat Card ────────────────────────────────────────────────────────────────

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  accent?: "blue" | "green" | "violet" | "amber" | "red";
}

function StatCard({ icon, label, value, sub, accent = "blue" }: StatCardProps) {
  const map: Record<string, { bg: string; color: string }> = {
    blue: { bg: "var(--accent-wash)", color: "var(--accent)" },
    green: { bg: "var(--success-wash)", color: "var(--success)" },
    violet: { bg: "var(--violet-wash)", color: "var(--violet)" },
    amber: { bg: "var(--warning-wash)", color: "var(--warning)" },
    red: { bg: "var(--error-wash)", color: "var(--error)" },
  };
  const c = map[accent];

  return (
    <div
      className="mon-stat-card"
      style={{ "--card-accent": c.color } as React.CSSProperties}
    >
      <div
        className="mon-stat-icon"
        style={{ background: c.bg, color: c.color }}
      >
        {icon}
      </div>
      <div className="mon-stat-body">
        <span className="mon-stat-label">{label}</span>
        <span className="mon-stat-value">{value}</span>
        {sub && <span className="mon-stat-sub">{sub}</span>}
      </div>
    </div>
  );
}

// ─── Panel ────────────────────────────────────────────────────────────────────

type Accent = "blue" | "green" | "violet" | "amber" | "neutral" | "red";

function Panel({
  title,
  subtitle,
  icon,
  accent = "blue",
  children,
}: {
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  accent?: Accent;
  children: React.ReactNode;
}) {
  const bgMap: Record<Accent, string> = {
    blue: "var(--accent-wash)",
    green: "var(--success-wash)",
    violet: "var(--violet-wash)",
    amber: "var(--warning-wash)",
    neutral: "var(--surface-2)",
    red: "var(--error-wash)",
  };
  const colorMap: Record<Accent, string> = {
    blue: "var(--accent)",
    green: "var(--success)",
    violet: "var(--violet)",
    amber: "var(--warning)",
    neutral: "var(--text-soft)",
    red: "var(--error)",
  };
  return (
    <div className="panel">
      <div className="panel-header">
        <div
          className="icon-box"
          style={{ background: bgMap[accent], color: colorMap[accent] }}
        >
          {icon}
        </div>
        <div className="panel-header-text">
          <span className="panel-title">{title}</span>
          {subtitle && <span className="panel-subtitle">{subtitle}</span>}
        </div>
      </div>
      <div className="panel-content">{children}</div>
    </div>
  );
}

// ─── Empty / Skeleton ─────────────────────────────────────────────────────────

function EmptyState({ message }: { message: string }) {
  return (
    <div className="mon-empty">
      <BarChart2 size={28} strokeWidth={1.4} />
      <span>{message}</span>
    </div>
  );
}

// ─── Status Gauge ─────────────────────────────────────────────────────────────

function StatusGauge({ stats }: { stats: any }) {
  const rate = stats?.success_rate != null ? Number(stats.success_rate) : null;
  const pct = rate != null ? Math.round(rate * 100) : null;

  // Arc parameters
  const R = 54;
  const cx = 70;
  const cy = 70;
  const circ = Math.PI * R; // half-circle arc length
  const dash = pct != null ? (pct / 100) * circ : 0;

  const color =
    pct == null
      ? "var(--text-faint)"
      : pct >= 90
        ? "var(--success)"
        : pct >= 70
          ? "var(--warning)"
          : "var(--error)";

  return (
    <div className="panel">
      <div className="panel-header">
        <div
          className="icon-box"
          style={{ background: "var(--accent-wash)", color: "var(--accent)" }}
        >
          <Gauge size={18} />
        </div>
        <div className="panel-header-text">
          <span className="panel-title">System Health</span>
          <span className="panel-subtitle">Overall success rate</span>
        </div>
      </div>
      <div className="panel-content gauge-container">
        <svg viewBox="0 0 140 80" style={{ width: "100%", maxWidth: 200 }}>
          {/* Track */}
          <path
            d={`M ${cx - R} ${cy} A ${R} ${R} 0 0 1 ${cx + R} ${cy}`}
            fill="none"
            stroke="var(--line)"
            strokeWidth="10"
            strokeLinecap="round"
          />
          {/* Fill */}
          <path
            d={`M ${cx - R} ${cy} A ${R} ${R} 0 0 1 ${cx + R} ${cy}`}
            fill="none"
            stroke={color}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circ}`}
            style={{ transition: "stroke-dasharray 0.6s ease" }}
          />
          {/* Value text */}
          <text
            x={cx}
            y={cy - 6}
            textAnchor="middle"
            style={{ fontSize: 22, fontWeight: 700, fill: "var(--text)" }}
          >
            {pct != null ? `${pct}%` : "—"}
          </text>
          <text
            x={cx}
            y={cy + 10}
            textAnchor="middle"
            style={{ fontSize: 9, fill: "var(--text-faint)" }}
          >
            SUCCESS RATE
          </text>
        </svg>

        <div
          style={{
            display: "flex",
            gap: 16,
            flexWrap: "wrap",
            justifyContent: "center",
            marginTop: 8,
          }}
        >
          {[
            { label: "Total Events", value: fmt(stats?.total_events) },
            { label: "LLM Calls", value: fmt(stats?.llm_calls) },
            { label: "Unique Users", value: fmt(stats?.unique_users) },
          ].map((item) => (
            <div key={item.label} style={{ textAlign: "center" }}>
              <div
                style={{ fontSize: 18, fontWeight: 700, color: "var(--text)" }}
              >
                {item.value}
              </div>
              <div
                style={{
                  fontSize: 10,
                  color: "var(--text-faint)",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                }}
              >
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Timeline Chart ───────────────────────────────────────────────────────────

// function TimelineChart({ data }: { data: any[] }) {
//   if (!data?.length) return <EmptyState message="No timeline events yet" />;

//   const maxVal = Math.max(...data.map((d) => d.total_events), 1);
//   const W = 600;
//   const H = 200;
//   const pad = { top: 16, right: 16, bottom: 32, left: 40 };
//   const iW = W - pad.left - pad.right;
//   const iH = H - pad.top - pad.bottom;

//   const xScale = (i: number) => pad.left + (i / Math.max(data.length - 1, 1)) * iW;
//   const yScale = (v: number) => pad.top + iH - (v / maxVal) * iH;

//   // Build path strings
//   const totalPts  = data.map((d, i) => `${xScale(i)},${yScale(d.total_events)}`).join(" ");
//   const successPts = data.map((d, i) => `${xScale(i)},${yScale(d.successful_events)}`).join(" ");
//   const failedPts  = data.map((d, i) => `${xScale(i)},${yScale(d.failed_events)}`).join(" ");

//   // Y-axis tick count
//   const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => Math.round(t * maxVal));

//   // X labels: show first, last, and ~4 in between
//   const step = Math.max(1, Math.floor(data.length / 5));
//   const xLabels = data
//     .map((d, i) => ({ i, label: new Date(d.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }))
//     .filter((_, i) => i % step === 0 || i === data.length - 1);

//   return (
//     <div>
//       <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 220 }}>
//         {/* Y grid lines */}
//         {ticks.map((t) => (
//           <g key={t}>
//             <line
//               x1={pad.left} x2={W - pad.right}
//               y1={yScale(t)} y2={yScale(t)}
//               stroke="var(--line)" strokeWidth="1"
//             />
//             <text x={pad.left - 6} y={yScale(t) + 4} textAnchor="end"
//               style={{ fontSize: 9, fill: "var(--text-faint)" }}>
//               {t}
//             </text>
//           </g>
//         ))}

//         {/* X labels */}
//         {xLabels.map(({ i, label }) => (
//           <text key={i} x={xScale(i)} y={H - 4} textAnchor="middle"
//             style={{ fontSize: 8.5, fill: "var(--text-faint)" }}>
//             {label}
//           </text>
//         ))}

//         {/* Lines */}
//         <polyline points={totalPts}   fill="none" stroke="var(--accent)"  strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
//         <polyline points={successPts} fill="none" stroke="var(--success)" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="4 2" />
//         <polyline points={failedPts}  fill="none" stroke="var(--error)"   strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="4 2" />

//         {/* Dots for total */}
//         {data.map((d, i) => (
//           <circle key={i} cx={xScale(i)} cy={yScale(d.total_events)} r="3"
//             fill="var(--accent)" stroke="var(--surface)" strokeWidth="1.5">
//             <title>{`${new Date(d.time).toLocaleString()}\nTotal: ${d.total_events}  Success: ${d.successful_events}  Failed: ${d.failed_events}`}</title>
//           </circle>
//         ))}
//       </svg>

//       {/* Legend */}
//       <div style={{ display: "flex", gap: 16, fontSize: 11, color: "var(--text-soft)", marginTop: 4 }}>
//         {[
//           { color: "var(--accent)",  label: "Total" },
//           { color: "var(--success)", label: "Successful" },
//           { color: "var(--error)",   label: "Failed" },
//         ].map(({ color, label }) => (
//           <span key={label} style={{ display: "flex", alignItems: "center", gap: 5 }}>
//             <span style={{ width: 20, height: 2, background: color, display: "inline-block", borderRadius: 1 }} />
//             {label}
//           </span>
//         ))}
//       </div>
//     </div>
//   );
// }

// ─── Token Usage Bar Chart ────────────────────────────────────────────────────

function TokenUsageChart({ data }: { data: any[] }) {
  if (!data?.length) return <EmptyState message="No model usage yet" />;

  const maxTokens = Math.max(
    ...data.map((d) => (d.input_tokens ?? 0) + (d.output_tokens ?? 0)),
    1,
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {data.map((row, i) => {
        const total = (row.input_tokens ?? 0) + (row.output_tokens ?? 0);
        const pct = (total / maxTokens) * 100;
        const iPct = total > 0 ? ((row.input_tokens ?? 0) / total) * pct : 0;
        const oPct = total > 0 ? ((row.output_tokens ?? 0) / total) * pct : 0;
        return (
          <div key={i}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: 4,
              }}
            >
              <span
                style={{ fontSize: 12, fontWeight: 600, color: "var(--text)" }}
              >
                {row.model ?? "Unknown"}
              </span>
              <span style={{ fontSize: 11, color: "var(--text-faint)" }}>
                {total.toLocaleString()} tokens ·{" "}
                {row.total_calls?.toLocaleString() ?? 0} calls
              </span>
            </div>
            <div
              style={{
                height: 8,
                background: "var(--surface-2)",
                borderRadius: 4,
                display: "flex",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  width: `${iPct}%`,
                  background: "var(--good)",
                  transition: "width 0.5s ease",
                }}
                title={`Input: ${row.input_tokens?.toLocaleString()}`}
              />
              <div
                style={{
                  width: `${oPct}%`,
                  background: "var(--violet)",
                  transition: "width 0.5s ease",
                }}
                title={`Output: ${row.output_tokens?.toLocaleString()}`}
              />
            </div>
          </div>
        );
      })}
      <div
        style={{
          display: "flex",
          gap: 14,
          fontSize: 11,
          color: "var(--text-soft)",
          marginTop: 4,
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span
            style={{
              width: 10,
              height: 10,
              borderRadius: 2,
              background: "var(--good)",
              display: "inline-block",
            }}
          />
          Input tokens
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <span
            style={{
              width: 10,
              height: 10,
              borderRadius: 2,
              background: "var(--violet)",
              display: "inline-block",
            }}
          />
          Output tokens
        </span>
      </div>
    </div>
  );
}

// ─── Tool Usage Bar Chart ─────────────────────────────────────────────────────

function ToolUsageChart({ data }: { data: any[] }) {
  if (!data?.length) return <EmptyState message="No tool invocations yet" />;

  const maxCount = Math.max(...data.map((d) => d.count), 1);
  const top10 = data.slice(0, 10);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {top10.map((row, i) => {
        const pct = (row.count / maxCount) * 100;
        const sr = row.success_rate;
        const badgeCls =
          sr == null
            ? "badge"
            : sr >= 0.9
              ? "badge success"
              : sr >= 0.7
                ? "badge warning"
                : "badge error";
        return (
          <div key={i}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 3,
              }}
            >
              <span
                style={{
                  fontSize: 12,
                  fontWeight: 600,
                  color: "var(--text)",
                  flex: 1,
                  minWidth: 0,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {row.tool_name}
              </span>
              <div
                style={{
                  display: "flex",
                  gap: 6,
                  alignItems: "center",
                  flex: "none",
                  marginLeft: 8,
                }}
              >
                {sr != null && (
                  <span className={badgeCls}>{(sr * 100).toFixed(0)}%</span>
                )}
                <span style={{ fontSize: 11, color: "var(--text-faint)" }}>
                  {row.count?.toLocaleString()}
                </span>
              </div>
            </div>
            <div
              style={{
                height: 6,
                background: "var(--surface-2)",
                borderRadius: 3,
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  width: `${pct}%`,
                  height: "100%",
                  background: "var(--violet)",
                  borderRadius: 3,
                  transition: "width 0.5s ease",
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Peak Hours Chart ─────────────────────────────────────────────────────────

function PeakHoursChart({ data }: { data: any | null }) {
  if (!data?.hourly_data?.length)
    return <EmptyState message="No peak-hour data yet" />;

  const maxEvt = Math.max(...data.hourly_data.map((h: any) => h.events), 1);

  return (
    <div>
      <div
        style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 120 }}
      >
        {data.hourly_data.map((h: any) => {
          const barH = Math.max(4, (h.events / maxEvt) * 100);
          const isPeak = h.hour === data.peak_hour;
          return (
            <div
              key={h.hour}
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              <div
                title={`${h.label}: ${h.events} events`}
                style={{
                  width: "100%",
                  height: `${barH}px`,
                  background: isPeak ? "var(--accent)" : "var(--accent-wash)",
                  borderRadius: "3px 3px 0 0",
                  transition: "height 0.4s ease",
                  border: isPeak ? "1.5px solid var(--accent-deep)" : undefined,
                }}
              />
            </div>
          );
        })}
      </div>
      {/* x-axis labels at 0, 6, 12, 18, 23 */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 4,
        }}
      >
        {["00:00", "06:00", "12:00", "18:00", "23:00"].map((l) => (
          <span key={l} style={{ fontSize: 9.5, color: "var(--text-faint)" }}>
            {l}
          </span>
        ))}
      </div>
      {data.peak_hour != null && (
        <div style={{ marginTop: 8, fontSize: 12, color: "var(--text-soft)" }}>
          Peak at{" "}
          <strong style={{ color: "var(--text)" }}>
            {String(data.peak_hour).padStart(2, "0")}:00
          </strong>{" "}
          · {data.peak_events?.toLocaleString()} events
        </div>
      )}
    </div>
  );
}

// ─── Adoption Trend Chart ─────────────────────────────────────────────────────

// function AdoptionChart({ data }: { data: any | null }) {
//   if (!data?.trend_data?.length) return <EmptyState message="No adoption data yet" />;

//   const pts  = data.trend_data;
//   const vals = pts.map((d: any) => d.active_users);
//   const max  = Math.max(...vals, 1);
//   const W = 400;
//   const H = 100;

//   const mkPath = (arr: number[]) =>
//     arr.map((v, i) => {
//       const x = (i / Math.max(arr.length - 1, 1)) * W;
//       const y = H - 8 - (v / max) * (H - 20);
//       return `${x},${y}`;
//     }).join(" ");

//   const activePts = mkPath(vals);
//   const newVals   = pts.map((d: any) => d.new_users);
//   const newPts    = mkPath(newVals);

//   return (
//     <div>
//       <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 110 }}>
//         <polyline points={activePts} fill="none" stroke="var(--accent)"  strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
//         <polyline points={newPts}    fill="none" stroke="var(--success)" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="4 2" />
//       </svg>
//       <div style={{ display: "flex", gap: 16, fontSize: 11, color: "var(--text-soft)", marginTop: 2 }}>
//         <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
//           <span style={{ width: 16, height: 2, background: "var(--accent)", display: "inline-block" }} />Active users
//         </span>
//         <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
//           <span style={{ width: 16, height: 2, background: "var(--success)", display: "inline-block" }} />New users
//         </span>
//       </div>
//       {data.growth_percentage !== 0 && (
//         <div style={{ fontSize: 12, color: data.growth_percentage > 0 ? "var(--success)" : "var(--error)", marginTop: 6, fontWeight: 600 }}>
//           {data.growth_percentage > 0 ? "▲" : "▼"} {Math.abs(data.growth_percentage)}% growth
//         </div>
//       )}
//     </div>
//   );
// }

// ─── Users Panel ──────────────────────────────────────────────────────────────

function UsersPanel({ data }: { data: any[] }) {
  if (!data?.length) return <EmptyState message="No user activity yet" />;
  return (
    <div style={{ overflowX: "auto" }}>
      <table className="data-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Email</th>
            <th style={{ textAlign: "right" }}>Events</th>
            <th style={{ textAlign: "right" }}>Total Tokens</th>
            <th style={{ textAlign: "right" }}>Avg Duration</th>
          </tr>
        </thead>
        <tbody>
          {data.slice(0, 12).map((row, i) => (
            <tr key={i}>
              <td style={{ fontWeight: 600 }}>{row.user_name}</td>
              <td style={{ color: "var(--text-faint)", fontSize: 12 }}>
                {row.email}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.events?.toLocaleString()}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.total_tokens?.toLocaleString()}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.avg_duration_ms
                  ? `${row.avg_duration_ms.toFixed(0)} ms`
                  : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Events Table ─────────────────────────────────────────────────────────────

function EventsTable({ events }: { events: any[] }) {
  if (!events?.length) return <EmptyState message="No recent events" />;
  return (
    <div style={{ overflowX: "auto" }}>
      <table className="data-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>Type</th>
            <th>User</th>
            <th>Status</th>
            <th style={{ textAlign: "right" }}>Duration</th>
          </tr>
        </thead>
        <tbody>
          {events.slice(0, 20).map((evt: any, i: number) => {
            const ok = evt.status === "success" || evt.status === "completed";
            return (
              <tr key={i}>
                <td
                  style={{
                    fontSize: 11.5,
                    color: "var(--text-faint)",
                    whiteSpace: "nowrap",
                  }}
                >
                  {new Date(
                    evt.timestamp ?? evt.created_at ?? evt.time,
                  ).toLocaleTimeString()}
                </td>
                <td>
                  <span className="badge">
                    {evt.event_type ?? evt.type ?? "—"}
                  </span>
                </td>
                <td style={{ fontSize: 12 }}>
                  {evt.user_id ?? evt.user ?? "—"}
                </td>
                <td>
                  <span className={`badge ${ok ? "success" : "error"}`}>
                    {evt.status ?? "—"}
                  </span>
                </td>
                <td style={{ textAlign: "right", fontSize: 12 }}>
                  {evt.duration_ms ? `${evt.duration_ms.toFixed(0)} ms` : "—"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Provider Stats ───────────────────────────────────────────────────────────

function ProviderStats({ data }: { data: any[] }) {
  if (!data?.length) return <EmptyState message="No provider data yet" />;
  return (
    <div style={{ overflowX: "auto" }}>
      <table className="data-table">
        <thead>
          <tr>
            <th>Provider</th>
            <th style={{ textAlign: "right" }}>Calls</th>
            <th style={{ textAlign: "right" }}>Tokens</th>
            <th style={{ textAlign: "right" }}>Success</th>
            <th style={{ textAlign: "right" }}>Avg Duration</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              <td style={{ fontWeight: 600 }}>{row.provider}</td>
              <td style={{ textAlign: "right" }}>
                {row.calls?.toLocaleString()}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.total_tokens?.toLocaleString()}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.success_rate != null ? (
                  <span
                    className={`badge ${row.success_rate >= 0.9 ? "success" : row.success_rate >= 0.7 ? "warning" : "error"}`}
                  >
                    {(row.success_rate * 100).toFixed(1)}%
                  </span>
                ) : (
                  "—"
                )}
              </td>
              <td style={{ textAlign: "right" }}>
                {row.avg_duration_ms
                  ? `${row.avg_duration_ms.toFixed(0)} ms`
                  : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Error Panel ──────────────────────────────────────────────────────────────

function ErrorPanel({
  errors,
  totalErrors,
  errorRate,
}: {
  errors: any[];
  totalErrors: number;
  errorRate: number;
}) {
  return (
    <div className="panel">
      <div className="panel-header">
        <div
          className="icon-box"
          style={{
            background:
              totalErrors > 0 ? "var(--error-wash)" : "var(--success-wash)",
            color: totalErrors > 0 ? "var(--error)" : "var(--success)",
          }}
        >
          {totalErrors > 0 ? (
            <AlertCircle size={18} />
          ) : (
            <CheckCircle size={18} />
          )}
        </div>
        <div className="panel-header-text">
          <span className="panel-title">Error Monitor</span>
          <span className="panel-subtitle">
            {totalErrors} errors · {(errorRate * 100).toFixed(1)}% error rate
          </span>
        </div>
      </div>
      <div className="panel-content">
        {!errors?.length ? (
          <EmptyState message="No errors recorded" />
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Source</th>
                  <th style={{ textAlign: "right" }}>Errors</th>
                </tr>
              </thead>
              <tbody>
                {errors.map((row) => (
                  <tr key={row.id}>
                    <td>
                      <span className="badge">{row.type}</span>
                    </td>
                    <td style={{ fontWeight: 600 }}>{row.source}</td>
                    <td style={{ textAlign: "right" }}>
                      <span className="badge error">{row.errors}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Monitoring() {
  const [isConnected, setIsConnected] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [timeRange, setTimeRange] = useState<TimeRangeValue>("");
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [stats, setStats] = useState<any>(null);
  const [timeline, setTimeline] = useState<any[]>([]);
  const [tokenUsage, setTokenUsage] = useState<any[]>([]);
  const [toolUsage, setToolUsage] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [peakHours, setPeakHours] = useState<any | null>(null);
  const [adoption, setAdoption] = useState<any | null>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [errors, setErrors] = useState<{
    errorRows: any[];
    total_errors: number;
    error_rate: number;
  }>({ errorRows: [], total_errors: 0, error_rate: 0 });

  const loadData = useCallback(
    async (silent = false) => {
      try {
        if (!silent) setLoading(true);
        else setRefreshing(true);

        const ts = buildPayloadISO(timeRange);
        const params: Record<string, string> = {
          page: "1",
          limit: "100",
        };
        if (ts.from_ts != null) params.from_ts = ts.from_ts;
        if (ts.to_ts != null) params.to_ts = ts.to_ts;

        const query = new URLSearchParams(params);
        const [
          // connected,
          statsData,
          timelineData,
          tokenData,
          toolData,
          providerData,
          userData,
          peakData,
          adoptionData,
          errorData,
          eventsData,
        ] = await Promise.all([
          // checkHealth().catch(() => false),
          fetchStats(query).catch(() => null),
          fetchTimeline(query).catch(() => []),
          fetchTokenUsage(query).catch(() => []),
          fetchToolUsage(query).catch(() => []),
          fetchProviderStats(query).catch(() => []),
          fetchUserActivity(query).catch(() => []),
          fetchPeakHours(query).catch(() => null),
          fetchAdoptionTrend(query).catch(() => null),
          fetchErrors(query).catch(() => null),
          fetchEvents(query).catch(() => []),
        ]);

        // setIsConnected(connected as boolean);
        setStats(statsData);
        setTimeline(timelineData as any[]);
        setTokenUsage(tokenData as any[]);
        setToolUsage(toolData as any[]);
        setProviders(providerData as any[]);
        setUsers(userData as any[]);
        setPeakHours(peakData);
        setAdoption(adoptionData);
        setEvents((eventsData as any[]) ?? []);
        setErrors(
          errorData || { errorRows: [], total_errors: 0, error_rate: 0 },
        );
        setLastRefresh(new Date());
      } catch (err) {
        console.error("Monitoring load error:", err);
        setIsConnected(false);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [timeRange],
  );

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(() => loadData(true), 15_000);
    return () => clearInterval(id);
  }, [autoRefresh, loadData]);

  // Derive total_tokens and avg_duration from system_overview if available
  const totalTokens =
    stats?.system_overview?.llm?.total_tokens ?? stats?.total_tokens ?? null;
  const successRate =
    stats?.system_overview?.llm?.success_rate ?? stats?.success_rate ?? null;
  const avgDurationMs =
    stats?.system_overview?.llm?.avg_duration_ms ??
    stats?.avg_duration_ms ??
    null;

  return (
    <div className="app">
      {/* ── Header ── */}
      <div className="header">
        <div className="header-icon-box">
          <Activity size={22} />
        </div>
        <div className="header-title">
          <h1>
            Monitoring
            <span
              style={{
                color: "var(--text-faint)",
                fontWeight: 400,
                fontSize: "1rem",
              }}
            >
              {" / Analytics"}
            </span>
          </h1>
          <p>Real-time observability for your EchoAI workspace</p>
        </div>

        <div className="header-controls">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as TimeRangeValue)}
            aria-label="Time range"
          >
            {TIME_RANGES.map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>

          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
            />
            Auto-refresh
          </label>

          <button
            className="refresh-btn"
            onClick={() => loadData()}
            disabled={loading || refreshing}
          >
            <RefreshCw size={14} className={refreshing ? "mon-spin" : ""} />
            Refresh
          </button>
        </div>
      </div>

      {loading && !stats ? (
        <div className="loading">
          <div className="spinner" />
          <span style={{ fontSize: 13 }}>Loading monitoring data…</span>
        </div>
      ) : (
        <>
          {/* ── Stat cards — 9 cards ── */}
          <div className="mon-cards-grid">
            <StatCard
              icon={<Activity size={18} />}
              label="Total Events"
              value={fmt(stats?.total_events)}
              sub="in selected window"
              accent="blue"
            />
            <StatCard
              icon={<Zap size={18} />}
              label="LLM Calls"
              value={fmt(stats?.llm_calls)}
              sub="model invocations"
              accent="violet"
            />
            <StatCard
              icon={<Users size={18} />}
              label="Unique Users"
              value={fmt(stats?.unique_users)}
              sub="active in range"
              accent="green"
            />
            <StatCard
              icon={<IndianRupee size={18} />}
              label="Total Cost"
              value={fmtCost(stats?.total_cost)}
              sub="across all models"
              accent="amber"
            />
            <StatCard
              icon={<TrendingUp size={18} />}
              label="Cost / User"
              value={fmtCost(stats?.cost_per_user)}
              sub="avg per active user"
              accent="amber"
            />
            <StatCard
              icon={<Database size={18} />}
              label="Total Tokens"
              value={fmt(totalTokens)}
              sub="input + output combined"
              accent="violet"
            />
            <StatCard
              icon={<CheckCircle size={18} />}
              label="Success Rate"
              value={fmtPct(successRate)}
              sub="across all LLM calls"
              accent={
                successRate == null || successRate >= 0.9
                  ? "green"
                  : successRate >= 0.7
                    ? "amber"
                    : "red"
              }
            />
            <StatCard
              icon={<Timer size={18} />}
              label="Avg Duration"
              value={fmtMs(avgDurationMs)}
              sub="avg LLM response time"
              accent="blue"
            />
            <StatCard
              icon={
                errors.total_errors > 0 ? (
                  <AlertCircle size={18} />
                ) : (
                  <CheckCircle size={18} />
                )
              }
              label="Error Rate"
              value={fmtPct(errors.error_rate)}
              sub={`${errors.total_errors} total errors`}
              accent={errors.total_errors > 0 ? "red" : "green"}
            />
          </div>

          <div className="dashboard-grid">
            {/* Row 1: Events Timeline + Status Gauge */}
            <div className="row row-2">
              <Panel
                icon={<Activity size={18} />}
                title="Events Timeline"
                subtitle="Live activity over the selected window"
                accent="blue"
              >
                <TimelineChart data={timeline} />
              </Panel>

              <StatusGauge stats={stats} />
            </div>

            {/* Row 2: Token Usage + Tool Invocations */}
            <div className="row row-equal">
              <Panel
                icon={<IndianRupee size={18} />}
                title="Token Usage by Model"
                subtitle="Cost and consumption per model"
                accent="green"
              >
                <TokenUsageChart data={tokenUsage} />
              </Panel>

              <Panel
                icon={<Wrench size={18} />}
                title="Tool Invocations"
                subtitle="Which tools are being called"
                accent="violet"
              >
                <ToolUsageChart data={toolUsage} />
              </Panel>
            </div>

            {/* Row 3: Peak Hours + Adoption */}
            <div className="row row-equal">
              <Panel
                icon={<Clock size={18} />}
                title="Peak Usage Hours"
                subtitle="When the platform is busiest"
                accent="amber"
              >
                <PeakHoursChart data={peakHours} />
              </Panel>

              <Panel
                icon={<TrendingUp size={18} />}
                title="User Adoption Trend"
                subtitle="Growth in active users over time"
                accent="blue"
              >
                <AdoptionChart data={adoption} />
              </Panel>
            </div>

            {/* Row 4: Users Panel */}
            <div className="row">
              <Panel
                icon={<Users size={18} />}
                title="User Activity"
                subtitle="Top active users in the selected window"
                accent="blue"
              >
                <UsersPanel data={users} />
              </Panel>
            </div>

            {/* Row 5: Recent Events table + Provider Stats + Errors */}
            <div className="row row-3-1">
              <Panel
                icon={<ClipboardList size={18} />}
                title="Recent Events"
                subtitle="Most recent activity in the selected range"
                accent="neutral"
              >
                <EventsTable events={events} />
              </Panel>

              <div>
                <Panel
                  icon={<BarChart2 size={18} />}
                  title="Provider Statistics"
                  subtitle="Breakdown by LLM provider"
                  accent="violet"
                >
                  <ProviderStats data={providers} />
                </Panel>
                <div style={{ marginTop: "1rem" }}>
                  <ErrorPanel
                    errors={errors.errorRows}
                    totalErrors={errors.total_errors}
                    errorRate={errors.error_rate}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* ── Footer ── */}
          <div className="footer">
            <Gauge size={14} />
            <span>Last updated: {lastRefresh.toLocaleString()}</span>
            <span className="divider">•</span>
            <span>Auto-refresh: {autoRefresh ? "On (15s)" : "Off"}</span>
          </div>
        </>
      )}
    </div>
  );
}
