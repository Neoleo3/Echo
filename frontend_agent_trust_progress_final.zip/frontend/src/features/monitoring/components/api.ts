// import axios from "axios";
// import { ENV } from "@/config";
import { baseService } from "@/services/base.service";

// const api = axios.create({
//   baseURL: ENV.API_BASE_URL,
//   timeout: 10_000,
//   headers: { "Content-Type": "application/json" },
//   withCredentials: true,
// });

// ─── Token / model consumption ───────────────────────────────────────────────

export interface ModelUsageWindow {
  used: number;
  limit: number | null;
  remaining: number | null;
  utilization_pct: number | null;
}

export interface ModelUsage {
  credential_id: string;
  credential_name: string;
  model: string;
  provider: string;
  billing_source: string;
  daily: ModelUsageWindow;
  monthly: ModelUsageWindow;
  lifetime_tokens: number;
  total_calls: number;
}

export const fetchLiveTokens = async (): Promise<ModelUsage[]> => {
  const response = await baseService.get<ModelUsage[]>(
    "/api/analytics/model-consumption",
  );
  return response.data ?? [];
};

// ─── Telemetry ────────────────────────────────────────────────────────────────

export interface TimelineItem {
  time: string;
  total_events: number;
  successful_events: number;
  failed_events: number;
}

export interface TokenUsageRow {
  model: string;
  input_tokens: number;
  output_tokens: number;
  provider: string;
  feature: string;
  total_calls: number;
  total_tokens: number;
  error_rate: number;
}

export interface UserAnalyticsRow {
  user_id: string;
  user_name: string;
  email: string;
  events: number;
  total_tokens: number;
  avg_duration_ms: number;
}

export interface ToolUsageRow {
  tool_name: string;
  count: number;
  tool_type: string;
  unique_users: number;
  total_errors: number;
  success_rate: number;
  avg_duration_ms: number;
}

export interface ProviderStatsRow {
  provider: string;
  calls: number;
  total_tokens: number;
  avg_duration_ms: number;
  unique_users: number;
  model_count: number;
  total_errors: number;
  success_rate: number;
}

export interface AdoptionData {
  trend_data: Array<{
    date: string;
    active_users: number;
    cumulative_users: number;
    new_users: number;
  }>;
  growth_percentage: number;
}

export interface PeakHoursData {
  hourly_data: Array<{
    hour: number;
    label: string;
    events: number;
    unique_users: number;
    success_rate: number;
  }>;
  peak_hour: number;
  peak_events: number;
}

export interface ErrorRow {
  id: string;
  type: string;
  source: string;
  errors: number;
}

export interface ErrorStats {
  errorRows: ErrorRow[];
  total_errors: number;
  error_rate: number;
}

export const fetchEvents = async (query: any) => {
  return baseService.get<{ events: unknown[] }>(
    `/api/analytics/telemetry/events?${query.toString()}`,
  );
};
export const fetchStats = async (query: any) => {
  const response = await baseService.get(
    `/api/analytics/usage/summary?${query.toString()}`,
  );
  const d = response.data as Record<string, Record<string, unknown>>;
  return {
    ...d,
    total_events: (d.system_summary?.total_events as number) ?? 0,
    llm_calls:
      ((d.system_overview?.llm as Record<string, unknown>)
        ?.total_calls as number) ?? 0,
    unique_users: (d.system_summary?.unique_users as number) ?? 0,
    total_cost: (d.system_summary?.total_cost as number) ?? 0,
    cost_per_user: (d.system_summary?.cost_per_user as number) ?? 0,
  };
};

export const fetchTimeline = async (query: any): Promise<TimelineItem[]> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/events-timeline?${query.toString()}`,
  );
  return transformTimelineData(response.data as Record<string, unknown>);
};

export const fetchTokenUsage = async (query: any): Promise<TokenUsageRow[]> => {
  const response = await baseService.get(
    `/api/analytics/usage/by-model?${query.toString()}`,
  );
  return transformTokenUsageData(
    (response.data as { models: Record<string, unknown> }).models,
  );
};

export const fetchToolUsage = async (query: any): Promise<ToolUsageRow[]> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/tool-invocations?${query.toString()}`,
  );
  return transformToolUsageData(
    (response.data as { tool_invocations: unknown[] }).tool_invocations,
  );
};

export const fetchProviderStats = async (
  query: any,
): Promise<ProviderStatsRow[]> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/provider-statistics?${query.toString()}`,
  );
  return transformProviderStats(response.data as Record<string, unknown>);
};

export const fetchUserActivity = async (
  query: any,
): Promise<UserAnalyticsRow[]> => {
  const response = await baseService.get(
    `/api/analytics/metrics/users?${query.toString()}`,
  );
  return transformUserAnalytics(response.data as Record<string, unknown>);
};

export const fetchPeakHours = async (
  query: any,
): Promise<PeakHoursData | null> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/peak-user-hours?${query.toString()}`,
  );
  return transformPeakHoursData(response.data as Record<string, unknown>);
};

export const fetchAdoptionTrend = async (
  query: any,
): Promise<AdoptionData | null> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/user-adoption?${query.toString()}`,
  );
  return transformAdoptionData(response.data as Record<string, unknown>);
};

export const fetchErrors = async (query: any): Promise<ErrorStats> => {
  const response = await baseService.get(
    `/api/analytics/telemetry/error-monitor?${query.toString()}`,
  );
  const d = response.data as Record<string, unknown>;
  return {
    errorRows: transformErrorStatsToRows(d),
    total_errors: d.total_errors as number,
    error_rate: d.error_rate as number,
  };
};

// export const checkHealth = async (): Promise<boolean> => {
//   try {
//     const response = await baseService.get<{ status: string }>("/health");
//     return response?.data?.status === "healthy";
//   } catch {
//     return false;
//   }
// };
// ─── Transform helpers ────────────────────────────────────────────────────────

export function transformTokenUsageData(
  apiResponse: Record<string, unknown>,
): TokenUsageRow[] {
  if (!apiResponse || typeof apiResponse !== "object") return [];
  return Object.values(apiResponse).map((item) => {
    const i = item as Record<string, unknown>;
    return {
      model: i.model as string,
      input_tokens: i.total_input_tokens as number,
      output_tokens: i.total_output_tokens as number,
      provider: i.provider as string,
      feature: i.feature as string,
      total_calls: i.total_calls as number,
      total_tokens: i.total_tokens as number,
      error_rate: i.error_rate as number,
    };
  });
}

export function transformUserAnalytics(
  raw: Record<string, unknown>,
): UserAnalyticsRow[] {
  if (!raw || typeof raw !== "object") return [];
  return Object.entries(raw).map(([userId, data]) => {
    const d = data as Record<string, unknown>;
    return {
      user_id: userId,
      user_name: (d.user_name as string) || `User ${userId.slice(0, 6)}`,
      email: (d.email as string) || "-",
      events: (d.total_calls as number) ?? 0,
      total_tokens: (d.total_tokens as number) ?? 0,
      avg_duration_ms: (d.avg_duration_ms as number) ?? 0,
    };
  });
}

export function transformToolUsageData(rawTools: unknown[]): ToolUsageRow[] {
  if (!Array.isArray(rawTools)) return [];
  return rawTools
    .map((tool) => {
      const t = tool as Record<string, unknown>;
      return {
        tool_name: (t.tool_name as string) || "Unknown Tool",
        count: (t.total_calls as number) ?? 0,
        tool_type: t.tool_type as string,
        unique_users: t.unique_users as number,
        total_errors: t.total_errors as number,
        success_rate: t.success_rate as number,
        avg_duration_ms: t.avg_duration_ms as number,
      };
    })
    .sort((a, b) => b.count - a.count);
}

export function transformTimelineData(
  apiResponse: Record<string, unknown>,
): TimelineItem[] {
  if (!apiResponse || !Array.isArray(apiResponse.timeline)) return [];
  return (apiResponse.timeline as Array<Record<string, unknown>>).map(
    (item) => ({
      time: item.bucket_start as string,
      total_events: (item.total_events as number) ?? 0,
      successful_events: (item.successful_events as number) ?? 0,
      failed_events: (item.failed_events as number) ?? 0,
    }),
  );
}
export function transformAdoptionData(
  apiResponse: Record<string, unknown>,
): AdoptionData | null {
  if (!apiResponse) return null;

  const activeMap: Record<string, number> = {};
  const newMap: Record<string, number> = {};

  for (const item of (apiResponse.active_users as Array<
    Record<string, unknown>
  >) ?? []) {
    activeMap[item.bucket_start as string] = (item.active_users as number) ?? 0;
  }
  for (const item of (apiResponse.new_users as Array<
    Record<string, unknown>
  >) ?? []) {
    newMap[item.bucket_start as string] = (item.new_users as number) ?? 0;
  }

  const allDates = Array.from(
    new Set([...Object.keys(activeMap), ...Object.keys(newMap)]),
  ).sort();

  let cumulative = 0;
  const trendData = allDates.map((date) => {
    const dailyNew = newMap[date] || 0;
    cumulative += dailyNew;
    return {
      date,
      active_users: activeMap[date] || 0,
      cumulative_users: cumulative,
      new_users: dailyNew,
    };
  });

  let growthPercentage = 0;
  if (trendData.length > 1) {
    const first = trendData[0].cumulative_users;
    const last = trendData[trendData.length - 1].cumulative_users;
    if (first > 0)
      growthPercentage = parseFloat(
        (((last - first) / first) * 100).toFixed(1),
      );
  }

  return { trend_data: trendData, growth_percentage: growthPercentage };
}

export function transformPeakHoursData(
  apiResponse: Record<string, unknown>,
): PeakHoursData | null {
  if (!apiResponse || !Array.isArray(apiResponse.hours)) return null;

  const hourlyData = (apiResponse.hours as Array<Record<string, unknown>>).map(
    (item) => ({
      hour: item.hour as number,
      label:
        (item.label as string) || `${String(item.hour).padStart(2, "0")}:00`,
      events: (item.total_events as number) ?? 0,
      unique_users: item.unique_users as number,
      success_rate: item.success_rate as number,
    }),
  );

  const peak = hourlyData.reduce(
    (max, h) => (h.events > max.events ? h : max),
    { events: 0, hour: 0, label: "", unique_users: 0, success_rate: 0 },
  );

  return {
    hourly_data: hourlyData,
    peak_hour: peak.hour,
    peak_events: peak.events,
  };
}
export function transformProviderStats(
  apiResponse: Record<string, unknown>,
): ProviderStatsRow[] {
  if (!apiResponse || !Array.isArray(apiResponse.providers)) return [];
  return (apiResponse.providers as Array<Record<string, unknown>>).map((p) => ({
    provider: (p.provider as string) || "Unknown",
    calls: (p.total_calls as number) ?? 0,
    total_tokens: (p.total_tokens as number) ?? 0,
    avg_duration_ms: (p.avg_duration_ms as number) ?? 0,
    unique_users: p.unique_users as number,
    model_count: p.model_count as number,
    total_errors: p.total_errors as number,
    success_rate: p.success_rate as number,
  }));
}

export function transformErrorStatsToRows(
  apiResponse: Record<string, unknown>,
): ErrorRow[] {
  if (!apiResponse) return [];
  const rows: ErrorRow[] = [];

  for (const item of (apiResponse.top_event_types as Array<
    Record<string, unknown>
  >) ?? []) {
    rows.push({
      id: `event-${item.event_type}`,
      type: "Event",
      source: (item.event_type as string) || "Unknown",
      errors: (item.total_errors as number) ?? 0,
    });
  }
  for (const item of (apiResponse.top_providers as Array<
    Record<string, unknown>
  >) ?? []) {
    rows.push({
      id: `provider-${item.provider}`,
      type: "Provider",
      source: (item.provider as string) || "Unknown",
      errors: (item.total_errors as number) ?? 0,
    });
  }
  for (const item of (apiResponse.top_tools as Array<
    Record<string, unknown>
  >) ?? []) {
    rows.push({
      id: `tool-${item.tool_name}`,
      type: "Tool",
      source: (item.tool_name as string) || "Unknown",
      errors: (item.total_errors as number) ?? 0,
    });
  }

  return rows;
}
