import React from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const TimelineChart = ({ data }: any) => {
  if (!data || data.length === 0) {
    return <div className="alert alert-info">No timeline data available</div>;
  }

  return (
    <div className="chart-container">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
          <XAxis
            dataKey="time"
            stroke="var(--text-secondary)"
            tick={{ fill: "var(--text-secondary)", fontSize: 12 }}
            tickFormatter={(time) => new Date(time).toLocaleDateString()}
          />
          <YAxis
            stroke="var(--text-secondary)"
            tick={{ fill: "var(--text-secondary)", fontSize: 12 }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "var(--secondary-bg)",
              border: "1px solid var(--border-color)",
              borderRadius: "8px",
              color: "var(--text-primary)",
              boxShadow: "var(--shadow-sm)",
            }}
            labelStyle={{ color: "var(--text-muted)" }}
            labelFormatter={(time: any) => new Date(time).toLocaleString()}
          />
          <Legend
            wrapperStyle={{
              color: "var(--text-secondary)",
              fontSize: "12px",
            }}
          />

          <Area
            type="monotone"
            dataKey="successful_events"
            name="Successful Events"
            stackId="1"
            stroke="var(--accent-green)"
            fill="var(--accent-green)"
            fillOpacity={0.35}
          />

          <Area
            type="monotone"
            dataKey="failed_events"
            name="Failed Events"
            stackId="1"
            stroke="var(--accent-red)"
            fill="var(--accent-red)"
            fillOpacity={0.35}
          />

          <Area
            type="monotone"
            dataKey="total_events"
            name="Total Events"
            stackId="2"
            stroke="var(--accent-blue)"
            fill="var(--accent-blue)"
            fillOpacity={0.15}
          />

          {/* {eventTypes.map((type) => (
            <Area
              key={type}
              type="monotone"
              dataKey={type}
              stackId="1"
              stroke={colors[type] || "#888888"}
              fill={colors[type] || "#888888"}
              fillOpacity={0.3}
            />
          ))} */}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TimelineChart;
