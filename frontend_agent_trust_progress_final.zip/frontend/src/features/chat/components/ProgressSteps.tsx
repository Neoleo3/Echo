"use client";

import { useMemo, useRef, useState } from "react";
import {
  CheckCircle2,
  Loader2,
  PauseCircle,
  XCircle,
  ChevronDown,
  ChevronRight,
  Shield,
  Wand2,
  Search,
  GitFork,
  PlayCircle,
  Bot,
  Zap,
} from "lucide-react";
import { Step } from "@/types";

export const iconMap: Record<string, React.ElementType> = {
  shield: Shield,
  auto_fix_high: Wand2,
  search: Search,
  account_tree: GitFork,
  play_circle: PlayCircle,
  smart_toy: Bot,
};

interface Props {
  steps: Step[];
}

export default function ProgressSteps({ steps }: Props) {
  const [showTimeline, setShowTimeline] = useState(false);
  const [expandedSteps, setExpandedSteps] = useState<string[]>([]);

  // Whether the main card timeline is pinned open (click-to-lock)
  const [cardPinned, setCardPinned] = useState(false);
  // Which step output panels are pinned open (click-to-lock, by step id)
  const [pinnedSteps, setPinnedSteps] = useState<string[]>([]);

  const cardLeaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stepLeaveTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>(
    {},
  );

  const completedSteps = useMemo(
    () => steps.filter((s) => s.status === "completed").length,
    [steps],
  );
  const runningStep = useMemo(
    () => steps.find((s) => s.status === "running"),
    [steps],
  );
  const allDone = completedSteps === steps.length && steps.length > 0;
  const progress = steps.length
    ? Math.round((completedSteps / steps.length) * 100)
    : 0;

  const handleCardMouseEnter = () => {
    if (cardLeaveTimer.current) clearTimeout(cardLeaveTimer.current);
    setShowTimeline(true);
  };
  const handleCardMouseLeave = () => {
    // Don't auto-close if pinned
    if (cardPinned) return;
    cardLeaveTimer.current = setTimeout(() => setShowTimeline(false), 220);
  };

  /** Click anywhere on the card header/timeline toggles the pin.
   *  - If not pinned: pin it (stops auto-close).
   *  - If pinned: unpin and close immediately. */
  const handleCardClick = () => {
    if (cardPinned) {
      setCardPinned(false);
      setShowTimeline(false);
    } else {
      setCardPinned(true);
      setShowTimeline(true);
    }
  };

  const handleStepMouseEnter = (id: string) => {
    if (stepLeaveTimers.current[id]) clearTimeout(stepLeaveTimers.current[id]);
    setExpandedSteps((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };
  const handleStepMouseLeave = (id: string) => {
    // Don't auto-close if this step is pinned
    if (pinnedSteps.includes(id)) return;
    stepLeaveTimers.current[id] = setTimeout(() => {
      setExpandedSteps((prev) => prev.filter((x) => x !== id));
    }, 200);
  };

  /** Click on a step row toggles its output pin.
   *  - If not pinned: pin it (output stays open).
   *  - If pinned: unpin and collapse. */
  const handleStepClick = (id: string) => {
    if (pinnedSteps.includes(id)) {
      setPinnedSteps((prev) => prev.filter((x) => x !== id));
      setExpandedSteps((prev) => prev.filter((x) => x !== id));
    } else {
      setPinnedSteps((prev) => [...prev, id]);
      setExpandedSteps((prev) => (prev.includes(id) ? prev : [...prev, id]));
    }
  };

  const getStatusIcon = (status: Step["status"]) => {
    switch (status) {
      case "running":
        return (
          <Loader2
            size={15}
            className="ps-spin"
            style={{ color: "var(--accent, #6366f1)", flexShrink: 0 }}
          />
        );
      case "completed":
        return (
          <CheckCircle2
            size={15}
            style={{ color: "var(--good, #22c55e)", flexShrink: 0 }}
          />
        );
      case "failed":
        return (
          <XCircle
            size={15}
            style={{ color: "var(--danger, #ef4444)", flexShrink: 0 }}
          />
        );
      case "interrupted":
        return (
          <PauseCircle
            size={15}
            style={{ color: "var(--warning, #f59e0b)", flexShrink: 0 }}
          />
        );
      default:
        return (
          <span
            style={{
              width: 9,
              height: 9,
              borderRadius: "50%",
              background: "var(--line, #d1d5db)",
              display: "inline-block",
              flexShrink: 0,
            }}
          />
        );
    }
  };

  const statusBadgeStyle = (status: Step["status"]): React.CSSProperties => {
    const base: React.CSSProperties = {
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.04em",
      padding: "2px 7px",
      borderRadius: 99,
      textTransform: "uppercase",
    };
    switch (status) {
      case "running":
        return {
          ...base,
          background:
            "color-mix(in srgb, var(--accent, #6366f1) 12%, transparent)",
          color: "var(--accent, #6366f1)",
          border:
            "1px solid color-mix(in srgb, var(--accent, #6366f1) 30%, transparent)",
        };
      case "completed":
        return {
          ...base,
          background: "color-mix(in srgb, #22c55e 12%, transparent)",
          color: "#16a34a",
          border: "1px solid color-mix(in srgb, #22c55e 30%, transparent)",
        };
      case "failed":
        return {
          ...base,
          background: "color-mix(in srgb, #ef4444 12%, transparent)",
          color: "#dc2626",
          border: "1px solid color-mix(in srgb, #ef4444 30%, transparent)",
        };
      case "interrupted":
        return {
          ...base,
          background: "color-mix(in srgb, #f59e0b 12%, transparent)",
          color: "#d97706",
          border: "1px solid color-mix(in srgb, #f59e0b 30%, transparent)",
        };
      default:
        return {
          ...base,
          background: "var(--surface-2, #f3f4f6)",
          color: "var(--text-faint, #9ca3af)",
          border: "1px solid var(--line)",
        };
    }
  };

  return (
    <>
      <style>{`
        @keyframes ps-spin { to { transform: rotate(360deg); } }
        @keyframes ps-pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:.45; transform:scale(.85); } }
        @keyframes ps-shimmer {
          0%   { background-position: -200% 0; }
          100% { background-position:  200% 0; }
        }
        @keyframes ps-slide-in {
          from { opacity:0; transform:translateY(-6px); }
          to   { opacity:1; transform:translateY(0);    }
        }
        @keyframes ps-output-in {
          from { opacity:0; transform:translateY(-4px); max-height:0; }
          to   { opacity:1; transform:translateY(0);    max-height:600px; }
        }
        .ps-spin { animation: ps-spin .85s linear infinite; }
        .ps-progress-bar {
          height: 3px;
          border-radius: 99px;
          background: linear-gradient(
            90deg,
            var(--accent, #6366f1) 0%,
            color-mix(in srgb, var(--accent,#6366f1) 60%, #818cf8) 100%
          );
          transition: width .5s cubic-bezier(.4,0,.2,1);
        }
        .ps-card {
          border-radius: 14px;
          border: 1px solid var(--line);
          background: var(--surface);
          box-shadow: 0 2px 12px -4px rgba(0,0,0,.08), 0 0 0 0 transparent;
          transition: box-shadow .2s, border-color .2s;
          width: 100%;
        }
        .ps-card:hover {
          box-shadow: 0 4px 20px -6px rgba(99,102,241,.18), 0 1px 4px -2px rgba(0,0,0,.06);
          border-color: color-mix(in srgb, var(--accent,#6366f1) 35%, var(--line));
        }
        .ps-timeline-wrap {
          animation: ps-slide-in .18s ease both;
        }
        .ps-step-output {
          animation: ps-output-in .18s ease both;
          overflow: hidden;
        }
        .ps-step-row {
          border-radius: 10px;
          padding: 8px 10px;
          transition: background .15s;
        }
        .ps-step-row:hover {
          background: color-mix(in srgb, var(--accent,#6366f1) 5%, transparent);
        }
      `}</style>

      <div className="ps-card">
        <div
          onMouseEnter={handleCardMouseEnter}
          onClick={handleCardClick}
          style={{ padding: "14px 16px", cursor: "pointer" }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 8,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 8,
                  background: allDone
                    ? "color-mix(in srgb, #22c55e 14%, transparent)"
                    : "color-mix(in srgb, var(--accent,#6366f1) 12%, transparent)",
                  display: "grid",
                  placeItems: "center",
                  border: `1px solid ${allDone ? "color-mix(in srgb,#22c55e 30%,transparent)" : "color-mix(in srgb,var(--accent,#6366f1) 28%,transparent)"}`,
                  flexShrink: 0,
                }}
              >
                {allDone ? (
                  <CheckCircle2 size={16} style={{ color: "#22c55e" }} />
                ) : (
                  <Zap size={16} style={{ color: "var(--accent,#6366f1)" }} />
                )}
              </span>

              <div>
                <div
                  style={{
                    fontWeight: 700,
                    fontSize: 13.5,
                    color: "var(--text)",
                    lineHeight: 1.2,
                  }}
                >
                  {allDone ? "Workflow Complete" : "Running Workflow"}
                </div>
                <div
                  style={{
                    fontSize: 11.5,
                    color: "var(--text-faint)",
                    marginTop: 1,
                  }}
                >
                  {completedSteps} of {steps.length} steps done
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  color: allDone ? "#16a34a" : "var(--accent,#6366f1)",
                  background: allDone
                    ? "color-mix(in srgb,#22c55e 10%,transparent)"
                    : "color-mix(in srgb,var(--accent,#6366f1) 10%,transparent)",
                  padding: "2px 8px",
                  borderRadius: 99,
                  border: `1px solid ${allDone ? "color-mix(in srgb,#22c55e 25%,transparent)" : "color-mix(in srgb,var(--accent,#6366f1) 25%,transparent)"}`,
                }}
              >
                {progress}%
              </span>

              <ChevronDown
                size={15}
                style={{
                  color: cardPinned
                    ? "var(--accent,#6366f1)"
                    : "var(--text-faint)",
                  transform: showTimeline ? "rotate(180deg)" : "rotate(0deg)",
                  transition: "transform .2s, color .2s",
                }}
              />
            </div>
          </div>

          <div
            style={{
              marginTop: 12,
              background: "var(--surface-2, #f3f4f6)",
              borderRadius: 99,
              height: 3,
              overflow: "hidden",
            }}
          >
            <div
              className="ps-progress-bar"
              style={{ width: `${progress}%` }}
            />
          </div>

          {!allDone && (
            <div
              style={{
                marginTop: 10,
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
                {[0, 0.2, 0.4].map((delay, i) => (
                  <span
                    key={i}
                    style={{
                      width: 5,
                      height: 5,
                      borderRadius: "50%",
                      display: "inline-block",
                      background: `color-mix(in srgb, var(--accent,#6366f1) ${100 - i * 25}%, transparent)`,
                      animation: `ps-pulse 1.3s ease-in-out ${delay}s infinite`,
                    }}
                  />
                ))}
              </div>
              <span
                style={{
                  fontSize: 12,
                  color: "var(--text-soft)",
                  fontStyle: "italic",
                }}
              >
                {runningStep
                  ? `${runningStep.label}…`
                  : "Workflow in progress…"}
              </span>
            </div>
          )}
        </div>

        {showTimeline && steps.length > 0 && (
          <div
            className="ps-timeline-wrap"
            onMouseEnter={handleCardMouseEnter}
            onMouseLeave={handleCardMouseLeave}
            onClick={handleCardClick}
            style={{
              borderTop: "1px solid var(--line)",
              padding: "12px 14px 14px",
              cursor: "pointer",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                marginBottom: 10,
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: "0.06em",
                textTransform: "uppercase",
                color: "var(--text-faint)",
              }}
            >
              <span>Steps</span>
              <span
                style={{
                  background: "var(--surface-2,#f3f4f6)",
                  color: "var(--text-faint)",
                  border: "1px solid var(--line)",
                  borderRadius: 99,
                  padding: "0 6px",
                  fontSize: 10,
                  fontWeight: 700,
                }}
              >
                {steps.length}
              </span>
            </div>

            <div style={{ position: "relative", paddingLeft: 22 }}>
              <div
                style={{
                  position: "absolute",
                  left: 7,
                  top: 6,
                  bottom: 6,
                  width: 1.5,
                  background:
                    "linear-gradient(to bottom, var(--accent,#6366f1) 0%, var(--line) 100%)",
                  borderRadius: 99,
                }}
              />

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 4,
                }}
              >
                {steps.map((step, idx) => {
                  const isOpen = expandedSteps.includes(step.id);
                  const isRunning = step.status === "running";
                  const isCompleted = step.status === "completed";
                  const hasOutput = !!step.output;

                  return (
                    <div
                      key={step.id}
                      className="ps-step-row"
                      onMouseEnter={() =>
                        hasOutput ? handleStepMouseEnter(step.id) : undefined
                      }
                      onMouseLeave={() =>
                        hasOutput ? handleStepMouseLeave(step.id) : undefined
                      }
                      onClick={(e) => {
                        if (hasOutput) {
                          e.stopPropagation(); // don't toggle card pin
                          handleStepClick(step.id);
                        }
                      }}
                      style={{
                        position: "relative",
                        cursor: hasOutput ? "pointer" : "default",
                        outline: pinnedSteps.includes(step.id)
                          ? "1.5px solid color-mix(in srgb, var(--accent,#6366f1) 40%, transparent)"
                          : "none",
                        outlineOffset: 1,
                      }}
                    >
                      <div
                        style={{
                          position: "absolute",
                          left: -15,
                          top: "50%",
                          transform: "translateY(-50%)",
                          background: "var(--surface)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          zIndex: 1,
                        }}
                      >
                        {getStatusIcon(step.status)}
                      </div>

                      <div>
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: 6,
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 6,
                              minWidth: 0,
                            }}
                          >
                            <span
                              style={{
                                fontSize: 10,
                                fontWeight: 700,
                                color: "var(--text-faint)",
                                flexShrink: 0,
                              }}
                            >
                              {String(idx + 1).padStart(2, "0")}
                            </span>

                            <span
                              style={{
                                fontWeight: isRunning
                                  ? 700
                                  : isCompleted
                                    ? 600
                                    : 500,
                                fontSize: 13,
                                color: isRunning
                                  ? "var(--accent,#6366f1)"
                                  : isCompleted
                                    ? "var(--text)"
                                    : "var(--text-soft)",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "nowrap",
                              }}
                            >
                              {step.label}
                            </span>
                          </div>

                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 6,
                              flexShrink: 0,
                            }}
                          >
                            <span style={statusBadgeStyle(step.status)}>
                              {step.status}
                            </span>

                            {hasOutput &&
                              (isOpen ? (
                                <ChevronDown
                                  size={13}
                                  style={{ color: "var(--text-faint)" }}
                                />
                              ) : (
                                <ChevronRight
                                  size={13}
                                  style={{ color: "var(--text-faint)" }}
                                />
                              ))}
                          </div>
                        </div>

                        {step.detail && (
                          <div
                            style={{
                              marginTop: 2,
                              paddingLeft: 22,
                              fontSize: 11.5,
                              color: "var(--text-faint)",
                              fontStyle: "italic",
                            }}
                          >
                            {step.detail}
                          </div>
                        )}
                        {isOpen && hasOutput && (
                          <div
                            className="ps-step-output"
                            onClick={(e) => e.stopPropagation()}
                            style={{
                              marginTop: 8,
                              borderRadius: 10,
                              border: "1px solid var(--line)",
                              background: "var(--surface-2, #f8fafc)",
                              padding: "10px 12px",
                              maxHeight: 220,
                              overflowY: "auto",
                            }}
                          >
                            <div
                              style={{
                                fontSize: 10,
                                fontWeight: 700,
                                letterSpacing: "0.06em",
                                textTransform: "uppercase",
                                color: "var(--text-faint)",
                                marginBottom: 6,
                              }}
                            >
                              Output
                            </div>
                            <pre
                              style={{
                                margin: 0,
                                fontSize: 12,
                                color: "var(--text-soft)",
                                lineHeight: 1.6,
                                whiteSpace: "pre-wrap",
                                wordBreak: "break-word",
                                fontFamily: "inherit",
                              }}
                            >
                              {step.output}
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
