"use client";

import { ArrowUpIcon, PaperclipIcon } from "@/components/common/Icons";
import { useToast } from "@/hooks/use-toast";
import { useEchoChat } from "@/hooks/useEchoChat";
import { Application } from "@/types";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

interface Props {
  selectedApp: Application | null;
  disabled?: boolean;
  placeholder?: string;
  autoFocus?: boolean;
  prompt?: string;
}

export default function Composer({
  selectedApp,
  disabled,
  placeholder = "Ask anything",
  autoFocus,
  prompt,
}: Props) {
  const router = useRouter();
  const [value, setValue] = useState<string>("");
  const ref = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const chat = useEchoChat();

  const sendMessage = async () => {
    const text = value.trim();
    if (!selectedApp?.application_id) {
      toast({
        title: "No application selected",
        description: "Select an application before sending.",
        variant: "destructive",
      });
      return;
    }
    if (!text) {
      toast({
        title: "Empty message",
        description: "Enter a message before sending.",
        variant: "destructive",
      });
      return;
    }
    if (chat.isStreaming) return;
    setValue("");
    await chat.send(selectedApp.application_id, text);
  };

  const grow = () => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  };

  useEffect(() => {
    grow();
  }, [value]);

  useEffect(() => {
    if (autoFocus) ref.current?.focus();
  }, [autoFocus]);

  const canSend = value.trim() !== "" && !disabled;

  useEffect(() => {
    if (prompt && prompt !== "") setValue(prompt);
  }, [prompt]);

  return (
    <div className="composer">
      <button
        type="button"
        className="c-btn"
        aria-label="Attach"
        title="Attach"
        onClick={() => {
          if (selectedApp?.upload_enabled) fileRef.current?.click();
          else
            toast({
              title: "File Upload Restricted",
              description: !selectedApp?.upload_enabled
                ? "This Application does not allow File Upload"
                : "There is an issue with the file upload, please connect with the support team.",
              variant: "destructive",
            });
        }}
        // disabled={!selectedApp?.upload_enabled}
      >
        <PaperclipIcon size={18} />
      </button>
      <textarea
        ref={ref}
        rows={1}
        placeholder={placeholder}
        value={value}
        disabled={disabled}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            if (canSend) sendMessage();
          }
        }}
      />
      <button
        type="button"
        className="send"
        aria-label="Send"
        disabled={!canSend}
        onClick={() => canSend && sendMessage()}
      >
        <ArrowUpIcon size={18} />
      </button>
      <input
        ref={fileRef}
        type="file"
        multiple
        style={{ display: "none" }}
        onChange={(e) => {
          if (selectedApp && e.target.files?.length) {
            chat.uploadFiles(selectedApp.application_id ?? "", e.target.files);
          }
          if (fileRef.current) fileRef.current.value = "";
        }}
      />
    </div>
  );
}
