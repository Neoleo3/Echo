"use client";

import { useEffect, useRef } from "react";

export interface Visualization {
  enabled?: boolean;
  chart_type?: string;
  traces: Record<string, unknown>[];
  layout: Record<string, unknown>;
}

interface Props {
  visualization: Visualization;
}

/** Returns "dark" when the page carries data-theme="dark" or OS prefers dark. */
function isDarkMode(): boolean {
  if (typeof document !== "undefined") {
    const theme = document.documentElement.getAttribute("data-theme");
    if (theme === "dark") return true;
    if (theme === "light") return false;
  }
  if (typeof window !== "undefined") {
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
  }
  return false;
}

function buildDarkLayout(base: Record<string, any>): Record<string, any> {
  return {
    ...base,
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { ...(base.font ?? {}), color: "#e7e8ec" },
    xaxis: {
      ...(base.xaxis ?? {}),
      color: "#9a9ba4",
      gridcolor: "#26272e",
      linecolor: "#34353e",
      zerolinecolor: "#34353e",
    },
    yaxis: {
      ...(base.yaxis ?? {}),
      color: "#9a9ba4",
      gridcolor: "#26272e",
      linecolor: "#34353e",
      zerolinecolor: "#34353e",
    },
    legend: { ...(base.legend ?? {}), bgcolor: "rgba(0,0,0,0)", font: { color: "#9a9ba4" } },
  };
}

export default function PlotlyChart({ visualization }: Props) {
  const chartRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let plotlyInstance: any;

    async function renderChart() {
      if (!chartRef.current || !visualization?.enabled) return;

      const Plotly = (await import("plotly.js-dist-min")).default;
      plotlyInstance = Plotly;

      const dark = isDarkMode();
      const layout = dark
        ? buildDarkLayout(visualization.layout)
        : { ...visualization.layout };

      Plotly.react(
        chartRef.current,
        visualization.traces,
        layout,
        {
          responsive: true,
          displayModeBar: false,
        },
      );
    }

    renderChart();

    return () => {
      if (chartRef.current && plotlyInstance) {
        plotlyInstance.purge(chartRef.current);
      }
    };
  }, [visualization]);

  if (!visualization?.enabled) {
    return null;
  }

  return (
    <div
      ref={chartRef}
      style={{
        width: "100%",
        minHeight: "400px",
      }}
    />
  );
}
