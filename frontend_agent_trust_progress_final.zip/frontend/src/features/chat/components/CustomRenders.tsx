import React from "react";
import type { ReactNode } from "react";
import type { Components } from "react-markdown";
import NextImage from "next/image";

export const CustomRenderers: Components = {
  p({ children }: { children?: ReactNode }) {
    return (
      <p className="mb-4 leading-7 [&:not(:first-child)]:mt-6">{children}</p>
    );
  },
  h1({ children }: { children?: ReactNode }) {
    return (
      <h1 className="mt-10 scroll-m-20 border-b pb-2 text-3xl font-semibold tracking-tight first:mt-0">
        {children}
      </h1>
    );
  },
  h2({ children }: { children?: ReactNode }) {
    return (
      <h2 className="mt-10 scroll-m-20 border-b pb-2 text-2xl font-semibold tracking-tight first:mt-0">
        {children}
      </h2>
    );
  },
  h3({ children }: { children?: ReactNode }) {
    return (
      <h3 className="mt-8 scroll-m-20 text-xl font-semibold tracking-tight">
        {children}
      </h3>
    );
  },
  h4({ children }: { children?: ReactNode }) {
    return (
      <h4 className="mt-8 scroll-m-20 text-lg font-semibold tracking-tight">
        {children}
      </h4>
    );
  },
  h5({ children }: { children?: ReactNode }) {
    return (
      <h5 className="mt-8 scroll-m-20 text-base font-semibold tracking-tight">
        {children}
      </h5>
    );
  },
  h6({ children }: { children?: ReactNode }) {
    return (
      <h6 className="mt-8 scroll-m-20 text-sm font-semibold tracking-tight">
        {children}
      </h6>
    );
  },
  li({ children }: { children?: ReactNode }) {
    return <li className="mt-2">{children}</li>;
  },
  ul({ children }: { children?: ReactNode }) {
    return <ul className="my-6 ml-6 list-disc [&>li]:mt-2">{children}</ul>;
  },
  ol({ children }: { children?: ReactNode }) {
    return <ol className="my-6 ml-6 list-decimal [&>li]:mt-2">{children}</ol>;
  },
  strong({ children }: { children?: ReactNode }) {
    return <strong className="font-semibold">{children}</strong>;
  },
  pre({ children }: { children?: ReactNode }) {
    return (
      <pre className="overflow-auto break-word max-w-[800px] max-h-[500px] border-2 border-[var(--border-light)]">
        {children}
      </pre>
    );
  },
  a({ href, children }: { href?: string; children?: ReactNode }) {
    const resolvedHref = href ?? "#";
    const isBlobFile = resolvedHref.startsWith(
      "https://ecoaiprdstg.blob.core.windows.net",
    );
    if (isBlobFile) {
      return (
        <a
          href={resolvedHref}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-blue-600 underline underline-offset-4 hover:text-blue-800"
        >
          Download File
        </a>
      );
    }
    return <a href={resolvedHref}>{children}</a>;
  },
  thead({ children }: { children?: ReactNode }) {
    return <thead className="border-b border-border">{children}</thead>;
  },
  tbody({ children }: { children?: ReactNode }) {
    return <tbody>{children}</tbody>;
  },
  tr({ children }: { children?: ReactNode }) {
    return <tr className="border-b border-border">{children}</tr>;
  },
  th({ children }: { children?: ReactNode }) {
    return (
      <th className="border border-border px-4 py-2 text-left font-semibold">
        {children}
      </th>
    );
  },
  td({ children }: { children?: ReactNode }) {
    return <td className="border border-border px-4 py-2">{children}</td>;
  },
  blockquote({ children }: { children?: ReactNode }) {
    return (
      <blockquote className="mt-6 border-l-2 border-border pl-6 italic">
        {children}
      </blockquote>
    );
  },
  hr() {
    return <hr className="my-4 border-border" />;
  },
  img({ src, alt }: React.ImgHTMLAttributes<HTMLImageElement>) {
    // next/image requires a string; react-markdown always passes string | undefined
    const resolvedSrc =
      (typeof src === "string" ? src : undefined) ?? "/placeholder.svg";
    return (
      <NextImage
        src={resolvedSrc}
        alt={alt ?? ""}
        width={800}
        height={600}
        className="my-4 rounded-md border border-border"
        style={{ maxWidth: "100%", height: "auto" }}
        unoptimized={resolvedSrc.startsWith("data:")}
      />
    );
  },
};
