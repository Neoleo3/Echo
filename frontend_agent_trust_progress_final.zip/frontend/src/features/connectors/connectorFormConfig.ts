import type {
  ApiAuthType,
  McpAuthType,
  McpTransport,
} from "@/types/connector.types";

export const TRANSPORT_FIELDS: Record<McpTransport, string[]> = {
  streamable_http: ["endpoint_url", "headers", "timeout"],
  stdio: ["command", "args", "env_vars", "working_dir", "timeout", "shell"],
};

export const AUTH_TYPES: { MCP: McpAuthType[]; API: ApiAuthType[] } = {
  MCP: ["none", "api_key", "bearer", "basic", "oauth2", "custom_header"],
  API: [
    "none",
    "api_key",
    "bearer",
    "basic",
    "oauth2_client_credentials",
    "oauth2_authorization_code",
    "custom_header",
  ],
};

export const AUTH_FIELDS: {
  MCP: Record<string, string[]>;
  API: Record<string, string[]>;
} = {
  MCP: {
    none: [],
    api_key: ["location", "key_name", "api_key"],
    bearer: ["token"],
    basic: ["username", "password"],
    oauth2: ["grant_type"],
    custom_header: ["header_name", "header_value"],
  },
  API: {
    none: [],
    api_key: ["key", "value", "add_to"],
    bearer: ["token"],
    basic: ["username", "password"],
    oauth2_client_credentials: [
      "client_id",
      "client_secret",
      "token_url",
      "scope",
      "tenant_id",
    ],
    oauth2_authorization_code: ["access_token"],
    custom_header: ["headers"],
  },
};

export const GRANT_TYPE: Record<string, string[]> = {
  authorization_code: ["access_token"],
  client_credentials: [
    "tenant_id",
    "client_id",
    "client_secret",
    "token_url",
    "scope",
  ],
};

export const HOST_BASE_DB = [
  "postgresql",
  "mysql",
  "mariadb",
  "clickhouse",
  "hive",
  "oracle",
  "redshift",
];

export const DB_CONFIG_MAP: Record<string, string[]> = {
  postgresql: ["name", "host", "port", "database_name", "username", "password"],
  oracle: ["name", "host", "port", "database_name", "username", "password"],
  mariadb: ["name", "host", "port", "database_name", "username", "password"],
  clickhouse: ["name", "host", "port", "database_name", "username", "password"],
  redshift: ["name", "host", "port", "database_name", "username", "password"],
  hive: ["name", "host", "port", "database_name", "username", "password"],
  mysql: ["name", "host", "port", "database_name", "username", "password"],
  mssql: ["name", "odbc_connection_string"],
  snowflake: ["name", "database_name", "username", "password", "account_url"],
  sqlite: ["name", "database_file_path"],
  duckdb: ["name", "database_file_path"],
  bigquery: ["name", "database_name"],
};

export const FIELD_META: Record<
  string,
  {
    label: string;
    type?: "text" | "number" | "password" | "textarea";
    placeholder?: string;
    hint?: string;
  }
> = {
  name: { label: "Connector name" },
  host: { label: "Host" },
  port: { label: "Port", type: "number" },
  database_name: { label: "Database name" },
  username: { label: "Username" },
  password: { label: "Password", type: "password" },
  account_url: {
    label: "Account URL",
    placeholder: "your-account.snowflakecomputing.com",
  },
  odbc_connection_string: {
    label: "ODBC connection string",
    type: "textarea",
    placeholder:
      "Driver={ODBC Driver 17 for SQL Server};Server=host;Database=db;UID=user;PWD=pass;",
  },
  database_file_path: {
    label: "Database file path",
    hint: "A path on the server, or upload a file below.",
  },

  /* auth — API */
  key: { label: "Key name", placeholder: "X-API-Key" },
  value: { label: "Key value", type: "password" },
  add_to: { label: "Send in" },
  token: { label: "Token", type: "password" },
  client_id: { label: "Client ID" },
  client_secret: { label: "Client secret", type: "password" },
  token_url: { label: "Token URL" },
  scope: { label: "Scope" },
  tenant_id: { label: "Tenant ID" },
  access_token: { label: "Access token", type: "password" },

  /* auth — MCP */
  location: { label: "Send in" },
  key_name: { label: "Key name", placeholder: "X-API-Key" },
  api_key: { label: "API key", type: "password" },
  header_name: { label: "Header name" },
  header_value: { label: "Header value", type: "password" },
  grant_type: { label: "Grant type" },

  /* MCP transport */
  endpoint_url: {
    label: "Server URL",
    placeholder: "https://mcp.example.com/v1",
  },
  command: { label: "Command", placeholder: "npx" },
  args: { label: "Arguments" },
  env_vars: { label: "Environment variables" },
  working_dir: { label: "Working directory" },
  timeout: { label: "Timeout (seconds)", type: "number" },
  shell: { label: "Run through a shell" },
  headers: { label: "Headers" },
};

export const isSecretField = (field: string): boolean =>
  field.includes("password") ||
  field.includes("token") ||
  field.includes("secret") ||
  ["api_key", "header_value", "key", "value"].includes(field);

export const AUTH_TYPE_LABELS: Record<string, string> = {
  none: "No authentication",
  api_key: "API key",
  bearer: "Bearer token",
  basic: "Basic (username & password)",
  oauth2: "OAuth 2.0",
  oauth2_client_credentials: "OAuth 2.0 — client credentials",
  oauth2_authorization_code: "OAuth 2.0 — authorization code",
  custom_header: "Custom header",
};

export const HTTP_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;

export const CONTENT_TYPES = [
  "application/json",
  "application/x-www-form-urlencoded",
  "multipart/form-data",
  "text/plain",
] as const;
