"use client";

import React, { useMemo, useRef } from "react";
import { DB_CONFIG_MAP, FIELD_META } from "../connectorFormConfig";
import { SecretField, SelectField, TextField } from "./ConnectorFields";
import type { DbFormState } from "../hooks/useConnectorForm";
import type { SupportedDatabase } from "@/types/connector.types";
import s from "./connectors.module.css";

interface DbConnectorFormProps {
  form: DbFormState;
  update: <K extends keyof DbFormState>(key: K, value: DbFormState[K]) => void;
  supported: SupportedDatabase[];
  editing?: boolean;
}

export const DbConnectorForm: React.FC<DbConnectorFormProps> = ({
  form,
  update,
  supported,
  editing,
}) => {
  const fileRef = useRef<HTMLInputElement | null>(null);

  const selected = useMemo(
    () => supported.find((entry) => entry.db_type === form.db_type) ?? null,
    [supported, form.db_type],
  );

  const fields = DB_CONFIG_MAP[form.db_type] ?? [];
  const allowsUpload = Boolean(selected?.supports_file_upload);

  const chooseType = (dbType: string) => {
    update("db_type", dbType);
    const next = DB_CONFIG_MAP[dbType] ?? [];
    (
      [
        "host",
        "port",
        "database_name",
        "username",
        "password",
        "account_url",
        "odbc_connection_string",
        "database_file_path",
      ] as const
    ).forEach((field) => {
      if (!next.includes(field)) update(field, "");
    });
    const entry = supported.find((item) => item.db_type === dbType);
    if (next.includes("port") && entry?.default_port) {
      update("port", String(entry.default_port));
    }
  };

  return (
    <div className={s.formGrid}>
      <SelectField
        label="Database type"
        required
        full
        value={form.db_type}
        onChange={chooseType}
        options={[
          { value: "", label: "Select a database…" },
          ...supported.map((entry) => ({
            value: entry.db_type,
            label:
              entry.drivers_available === false
                ? `${entry.label} (driver not installed)`
                : entry.label,
          })),
        ]}
      />

      {!form.db_type && (
        <p className={`${s.hint} ${s.full}`}>
          Pick a database type to see the details it needs.
        </p>
      )}

      {fields.map((field) => {
        const meta = FIELD_META[field] ?? { label: field };

        if (field === "password") {
          return (
            <SecretField
              key={field}
              label={meta.label}
              editing={editing}
              value={form.password}
              onChange={(value) => update("password", value)}
            />
          );
        }

        if (meta.type === "textarea") {
          return (
            <TextField
              key={field}
              label={meta.label}
              full
              multiline
              placeholder={meta.placeholder}
              value={String(
                (form as unknown as Record<string, string>)[field] ?? "",
              )}
              onChange={(value) =>
                update(field as keyof DbFormState, value as never)
              }
            />
          );
        }

        return (
          <TextField
            key={field}
            label={meta.label}
            required={field === "name"}
            type={meta.type === "number" ? "number" : "text"}
            placeholder={
              field === "host"
                ? (selected?.placeholder_host ?? meta.placeholder)
                : meta.placeholder
            }
            hint={meta.hint}
            value={String(
              (form as unknown as Record<string, string>)[field] ?? "",
            )}
            onChange={(value) =>
              update(field as keyof DbFormState, value as never)
            }
          />
        );
      })}

      {allowsUpload && (
        <div className={`${s.field} ${s.full}`}>
          <label>Upload a database file</label>
          <div className={s.uploadRow}>
            <button
              type="button"
              className={s.ghostBtn}
              onClick={() => fileRef.current?.click()}
            >
              Choose file
            </button>
            <span className={s.hint}>
              {form.file ? form.file.name : "No file selected."}
            </span>
            {form.file && (
              <button
                type="button"
                className={s.ghostBtn}
                onClick={() => update("file", null)}
              >
                Remove
              </button>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            hidden
            onChange={(e) => update("file", e.target.files?.[0] ?? null)}
          />
          <p className={s.hint}>Uploading a file replaces the path above.</p>
        </div>
      )}
    </div>
  );
};
