"use client";

import React, { useEffect, useState } from "react";
import { connectorsService } from "@/services/connectors.service";
import { DB_CONFIG_MAP } from "../connectorFormConfig";
import {
  apiFormFrom,
  buildApiPayload,
  buildDbPayload,
  buildMcpPayload,
  dbFormFrom,
  mcpFormFrom,
  useConnectorForm,
} from "../hooks/useConnectorForm";
import { ApiConnectorForm } from "./ApiConnectorForm";
import { McpConnectorForm } from "./McpConnectorForm";
import { DbConnectorForm } from "./DbConnectorForm";
import type { ConnectorKind, SupportedDatabase } from "@/types/connector.types";
import s from "./connectors.module.css";
import { Connector } from "@/types";

interface ConnectorFormDialogProps {
  kind: ConnectorKind;
  /** Null when creating. */
  existing: Connector | null;
  supportedDatabases: SupportedDatabase[];
  onClose: () => void;
  onSaved: () => void;
}

const TITLES: Record<string, { title: string; blurb: string }> = {
  api: { title: "API connector", blurb: "Connect a REST or HTTP endpoint." },
  mcp: {
    title: "MCP server",
    blurb: "Connect a Model Context Protocol server.",
  },
  db: { title: "Database", blurb: "Connect a SQL database." },
};

/** The create endpoint returns its failure as a detail object rather than a
 *  sentence, so it is unwrapped instead of shown as `[object Object]`. */
const readError = (error: unknown): string => {
  if (typeof error === "string") return error;
  if (error && typeof error === "object") {
    const detail = error as {
      detail?: unknown;
      message?: unknown;
      error?: unknown;
    };
    const candidate = detail.detail ?? detail.message ?? detail.error;
    if (typeof candidate === "string") return candidate;
    try {
      return JSON.stringify(candidate ?? error);
    } catch {
      return "That connector could not be saved.";
    }
  }
  return "That connector could not be saved.";
};

export const ConnectorFormDialog: React.FC<ConnectorFormDialogProps> = ({
  kind,
  existing,
  supportedDatabases,
  onClose,
  onSaved,
}) => {
  const formState = useConnectorForm();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const editing = Boolean(existing);
  const existingId = existing?.connector_id ?? existing?.id ?? null;
  const info = TITLES[kind] ?? TITLES.api;

  /* Reopening an existing connector prefills from what it was created with. */
  useEffect(() => {
    if (!existing) return;
    if (kind === "api") formState.setApi(apiFormFrom(existing));
    if (kind === "mcp") formState.setMcp(mcpFormFrom(existing));
    if (kind === "db") formState.setDb(dbFormFrom(existing));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing, kind]);

  const save = async () => {
    setSaving(true);
    setError(null);
    setNotice(null);

    let response;

    if (kind === "db") {
      const { db } = formState;
      if (db.file) {
        /* A file-backed database is uploaded rather than described. */
        const data = new FormData();
        data.append("file", db.file);
        data.append("name", db.name);
        data.append("db_type", db.db_type);
        response = existingId
          ? await connectorsService.updateDBConnectorWithFile(existingId, data)
          : await connectorsService.connectDBWithFile(data);
      } else {
        const payload = buildDbPayload(db, DB_CONFIG_MAP[db.db_type] ?? []);
        response = existingId
          ? await connectorsService.updateDBConnector(existingId, payload)
          : await connectorsService.connectDB(payload);
      }
    } else if (kind === "mcp") {
      const payload = buildMcpPayload(formState.mcp);
      response = existingId
        ? await connectorsService.updateMCPConnector(existingId, payload)
        : await connectorsService.createMCPConnector(payload);
    } else {
      const payload = buildApiPayload(formState.api);
      response = existingId
        ? await connectorsService.updateAPIConnector(existingId, payload)
        : await connectorsService.createAPIConnector(payload);
    }

    setSaving(false);

    if (!response.success) {
      setError(readError(response.error));
      return;
    }

    onSaved();
    onClose();
  };

  /** An API connector is tested against the form as typed, before saving. */
  const test = async () => {
    setNotice(null);
    setError(null);
    const response = await connectorsService.testAPIConnector(
      buildApiPayload(formState.api),
    );
    if (response.success) setNotice("The endpoint responded.");
    else setError(readError(response.error));
  };

  const canSave =
    kind === "db"
      ? Boolean(formState.db.db_type && formState.db.name)
      : kind === "mcp"
        ? Boolean(formState.mcp.name)
        : Boolean(formState.api.name && formState.api.endpoint_url);

  return (
    <div className={s.overlay} onClick={onClose}>
      <div className={s.dialog} onClick={(e) => e.stopPropagation()}>
        <div className={s.dialogHead}>
          <div>
            <h3 className={s.dialogTitle}>
              {editing ? `Edit ${existing?.name ?? "connector"}` : info.title}
            </h3>
            <p className={s.dialogBlurb}>{info.blurb}</p>
          </div>
          <button
            className={s.dialogClose}
            onClick={onClose}
            aria-label="Close"
          >
            ×
          </button>
        </div>

        <div className={s.dialogBody}>
          {kind === "api" && (
            <ApiConnectorForm
              form={formState.api}
              update={formState.updateApi}
              onAuthTypeChange={formState.setApiAuthType}
              onAuthValueChange={formState.updateApiAuth}
              editing={editing}
            />
          )}
          {kind === "mcp" && (
            <McpConnectorForm
              form={formState.mcp}
              update={formState.updateMcp}
              onAuthTypeChange={formState.setMcpAuthType}
              onAuthValueChange={formState.updateMcpAuth}
              editing={editing}
            />
          )}
          {kind === "db" && (
            <DbConnectorForm
              form={formState.db}
              update={formState.updateDb}
              supported={supportedDatabases}
              editing={editing}
            />
          )}

          {error && <p className={s.errText}>{error}</p>}
          {notice && <p className={s.noticeText}>{notice}</p>}
          {kind === "api" && (
            <p className={s.hint}>
              Saving tests the endpoint first — it is only stored if the test
              passes.
            </p>
          )}
        </div>

        <div className={s.dialogFoot}>
          <button className={s.ghostBtn} onClick={onClose}>
            Cancel
          </button>
          {kind === "api" && (
            <button className={s.ghostBtn} onClick={test} disabled={!canSave}>
              Test
            </button>
          )}
          <button
            className={s.primaryBtn}
            onClick={save}
            disabled={saving || !canSave}
          >
            {saving
              ? "Saving…"
              : editing
                ? "Save connector"
                : "Create connector"}
          </button>
        </div>
      </div>
    </div>
  );
};
