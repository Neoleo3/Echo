"use client";

import React from "react";
import {
  AUTH_TYPE_LABELS,
  AUTH_TYPES,
  FIELD_META,
  isSecretField,
} from "../connectorFormConfig";
import { authFieldsFor } from "../hooks/useConnectorForm";
import {
  KeyValueEditor,
  SecretField,
  SelectField,
  TextField,
} from "./ConnectorFields";
import s from "./connectors.module.css";
import { AuthValues } from "@/types/connector.types";

interface AuthFieldSetProps {
  kind: "MCP" | "API";
  authType: string;
  values: AuthValues;
  onTypeChange: (authType: string) => void;
  onValueChange: (field: string, value: unknown) => void;
  editing?: boolean;
}

const MAP_FIELDS = new Set(["headers"]);

const CHOICES: Record<string, { value: string; label: string }[]> = {
  add_to: [
    { value: "header", label: "Header" },
    { value: "query", label: "Query string" },
  ],
  location: [
    { value: "header", label: "Header" },
    { value: "query", label: "Query string" },
  ],
  grant_type: [
    { value: "client_credentials", label: "Client credentials" },
    { value: "authorization_code", label: "Authorization code" },
  ],
};

export const AuthFieldSet: React.FC<AuthFieldSetProps> = ({
  kind,
  authType,
  values,
  onTypeChange,
  onValueChange,
  editing,
}) => {
  const fields = authFieldsFor(kind, authType, values);

  return (
    <>
      <SelectField
        label="Authentication"
        value={authType}
        onChange={onTypeChange}
        options={AUTH_TYPES[kind].map((type) => ({
          value: type,
          label: AUTH_TYPE_LABELS[type] ?? type,
        }))}
      />

      {fields.map((field) => {
        const meta = FIELD_META[field] ?? { label: field };

        if (CHOICES[field]) {
          return (
            <SelectField
              key={field}
              label={meta.label}
              value={String(values[field] ?? CHOICES[field][0].value)}
              onChange={(value) => onValueChange(field, value)}
              options={CHOICES[field]}
            />
          );
        }

        if (MAP_FIELDS.has(field)) {
          return (
            <KeyValueEditor
              key={field}
              label={meta.label}
              secretValues
              value={(values[field] as Record<string, string>) ?? {}}
              onChange={(next) => onValueChange(field, next)}
            />
          );
        }

        if (isSecretField(field)) {
          return (
            <SecretField
              key={field}
              label={meta.label}
              editing={editing}
              value={String(values[field] ?? "")}
              onChange={(value) => onValueChange(field, value)}
            />
          );
        }

        return (
          <TextField
            key={field}
            label={meta.label}
            placeholder={meta.placeholder}
            value={String(values[field] ?? "")}
            onChange={(value) => onValueChange(field, value)}
          />
        );
      })}

      {authType === "none" && (
        <p className={`${s.hint} ${s.full}`}>
          This connector will be called without credentials.
        </p>
      )}
    </>
  );
};
