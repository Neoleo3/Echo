"use client";

import React from "react";
import { AuthFieldSet } from "./AuthFieldSet";
import {
  CheckboxField,
  KeyValueEditor,
  SelectField,
  StringListField,
  TextField,
} from "./ConnectorFields";
import type { McpFormState } from "../hooks/useConnectorForm";
import s from "./connectors.module.css";

interface McpConnectorFormProps {
  form: McpFormState;
  update: <K extends keyof McpFormState>(
    key: K,
    value: McpFormState[K],
  ) => void;
  onAuthTypeChange: (authType: string) => void;
  onAuthValueChange: (field: string, value: unknown) => void;
  editing?: boolean;
}

export const McpConnectorForm: React.FC<McpConnectorFormProps> = ({
  form,
  update,
  onAuthTypeChange,
  onAuthValueChange,
  editing,
}) => {
  const isStdio = form.transport_type === "stdio";

  return (
    <div className={s.formGrid}>
      <TextField
        label="Name"
        required
        value={form.name}
        onChange={(value) => update("name", value)}
        placeholder="e.g. Jira MCP"
      />
      <TextField
        label="Icon"
        value={form.icon}
        onChange={(value) => update("icon", value)}
        placeholder="Optional identifier"
      />
      <TextField
        label="Description"
        full
        value={form.description}
        onChange={(value) => update("description", value)}
        placeholder="What does this server provide?"
      />

      <SelectField
        label="Transport"
        value={form.transport_type}
        onChange={(value) => update("transport_type", value)}
        options={[
          { value: "streamable_http", label: "Streamable HTTP" },
          { value: "stdio", label: "stdio (local process)" },
        ]}
        hint={
          isStdio
            ? "The server is started as a process on the host."
            : "The server is reached over HTTP."
        }
      />

      <TextField
        label="Timeout (seconds)"
        type="number"
        value={String(form.timeout)}
        onChange={(value) => update("timeout", Number(value))}
      />

      {/* ---- HTTP transport ---- */}
      {!isStdio && (
        <>
          <TextField
            label="Server URL"
            required
            full
            value={form.endpoint_url}
            onChange={(value) => update("endpoint_url", value)}
            placeholder="https://mcp.example.com/v1"
          />
          <KeyValueEditor
            label="Headers"
            value={form.headers}
            onChange={(next) => update("headers", next)}
          />
        </>
      )}

      {/* ---- stdio transport ---- */}
      {isStdio && (
        <>
          <TextField
            label="Command"
            required
            value={form.command}
            onChange={(value) => update("command", value)}
            placeholder="npx"
          />
          <TextField
            label="Working directory"
            value={form.working_dir}
            onChange={(value) => update("working_dir", value)}
            placeholder="Optional"
          />
          <StringListField
            label="Arguments"
            value={form.args}
            onChange={(next) => update("args", next)}
            hint="One argument per row, in the order the command expects them."
          />
          <KeyValueEditor
            label="Environment variables"
            secretValues
            value={form.env_vars}
            onChange={(next) => update("env_vars", next)}
          />
          <div className={s.full}>
            <CheckboxField
              label="Run through a shell"
              hint="Only needed when the command relies on shell features."
              checked={form.shell}
              onChange={(checked) => update("shell", checked)}
            />
          </div>
        </>
      )}

      <div className={s.full}>
        <CheckboxField
          label="Enabled"
          hint="A disabled server stays configured but is never called."
          checked={form.enabled}
          onChange={(checked) => update("enabled", checked)}
        />
      </div>

      <AuthFieldSet
        kind="MCP"
        authType={form.auth_type}
        values={form.auth}
        onTypeChange={onAuthTypeChange}
        onValueChange={onAuthValueChange}
        editing={editing}
      />
    </div>
  );
};
