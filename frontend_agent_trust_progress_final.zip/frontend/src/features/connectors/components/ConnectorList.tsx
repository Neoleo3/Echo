"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  useConnectors,
  connectorIdOf,
  type ListedConnector,
} from "@/hooks/useConnectors";
import { ConnectorFormDialog } from "./ConnectorFormDialog";
import type { ConnectorKind } from "@/types/connector.types";
import s from "./connectors.module.css";
import { MarketplaceTemplates } from "./MarketplaceTemplates";
import ms from "./marketplace.module.css";
import { Connector } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { MultiDropdown } from "@/components/common/MultiDropdown";

const KIND_LABELS: Record<string, string> = {
  api: "API",
  mcp: "MCP",
  db: "Database",
  // channel: "Channel",
};

const CREATABLE: ConnectorKind[] = ["api", "mcp", "db"];

const statusOf = (
  connector: ListedConnector,
): { label: string; tone: string } => {
  const raw = String(
    connector.validation_status ?? connector.status ?? "",
  ).toLowerCase();
  if (["active", "validated", "connected", "success"].includes(raw))
    return { label: raw || "active", tone: s.statusOk };
  if (["failed", "error", "invalid"].includes(raw))
    return { label: raw, tone: s.statusBad };
  return { label: raw || "untested", tone: s.statusIdle };
};

const GridIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
  </svg>
);

const TableIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);

const DotsIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="12" cy="5" r="1" fill="currentColor" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <circle cx="12" cy="19" r="1" fill="currentColor" />
  </svg>
);

const RowMenu: React.FC<{
  connector: ListedConnector;
  id: string;
  busyId: string | null;
  onTest?: () => void;
  onRefresh?: () => void;
  onConfigure?: () => void;
  onDelete: () => void;
}> = ({ id, busyId, onTest, onRefresh, onConfigure, onDelete }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  return (
    <div className={s.rowMenuWrap} ref={ref}>
      <button
        type="button"
        className={s.dotsBtn}
        onClick={() => setOpen((o) => !o)}
        aria-label="Actions"
      >
        <DotsIcon />
      </button>
      {open && (
        <div className={s.rowMenu}>
          {/* {onRefresh && (
            <button
              type="button"
              className={s.rowMenuItem}
              disabled={busyId === id}
              onClick={() => { setOpen(false); onRefresh(); }}
            >
              Refresh tools
            </button>
          )} */}
          {onTest && (
            <button
              type="button"
              className={s.rowMenuItem}
              disabled={busyId === id}
              onClick={() => {
                setOpen(false);
                onTest();
              }}
            >
              {busyId === id ? "Testing…" : "Test"}
            </button>
          )}
          {onConfigure && (
            <button
              type="button"
              className={s.rowMenuItem}
              onClick={() => {
                setOpen(false);
                onConfigure();
              }}
            >
              Configure
            </button>
          )}
          <button
            type="button"
            className={`${s.rowMenuItem} ${s.rowMenuItemDanger}`}
            onClick={() => {
              setOpen(false);
              onDelete();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
              <path d="M10 11v6" />
              <path d="M14 11v6" />
              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

export const ConnectorList: React.FC = () => {
  const { toast } = useToast();
  const {
    connectors,
    supportedDatabases,
    loading,
    error,
    reload,
    deleteConnector,
    testConnector,
    refreshMCPDiscovery,
  } = useConnectors();

  const [search, setSearch] = useState("");
  const [kindFilter, setKindFilter] = useState<"all" | ConnectorKind>("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [mainView, setMainView] = useState<"connectors" | "marketplace">(
    "connectors",
  );
  const [addOpen, setAddOpen] = useState(false);
  const [formKind, setFormKind] = useState<ConnectorKind | null>(null);
  const [editing, setEditing] = useState<Connector | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [rowNotice, setRowNotice] = useState<Record<string, string>>({});

  const query = search.trim().toLowerCase();
  const filtered = connectors.filter((connector) => {
    if (kindFilter !== "all" && connector.kind !== kindFilter) return false;
    if (!query) return true;
    return (
      (connector.name ?? "").toLowerCase().includes(query) ||
      (connector.description ?? "").toLowerCase().includes(query)
    );
  });

  const openCreate = (kind: ConnectorKind) => {
    setEditing(null);
    setFormKind(kind);
    setAddOpen(false);
  };

  const openEdit = (connector: ListedConnector) => {
    setEditing(connector);
    setFormKind(connector.kind);
  };

  const handleTest = async (connector: ListedConnector) => {
    const id = connectorIdOf(connector);
    setBusyId(id);
    const response = await testConnector(
      connector.kind,
      connector.kind === "db" ? id : (connector.creation_payload ?? {}),
    );
    setBusyId(null);
    setRowNotice((prev) => ({
      ...prev,
      [id]: response.success
        ? "Reachable."
        : (response.error ?? "Test failed."),
    }));
    toast({
      title: "Connector Testing",
      description: response.success
        ? response.message
        : (response.error ?? "Error while testing the connector"),
      variant: response.success ? "success" : "destructive",
    });
  };

  const handleRefresh = async (connector: ListedConnector) => {
    const id = connectorIdOf(connector);
    setBusyId(id);
    await refreshMCPDiscovery(id);
    setBusyId(null);
  };

  const renderCardActions = (connector: ListedConnector, id: string) => {
    if (confirmId === id) {
      return (
        <>
          <span className={s.hint}>Delete this connector?</span>
          <button
            className={s.dangerBtn}
            onClick={async () => {
              await deleteConnector(connector.kind, id);
              setConfirmId(null);
            }}
          >
            Delete
          </button>
          <button className={s.ghostBtn} onClick={() => setConfirmId(null)}>
            Keep
          </button>
        </>
      );
    }
    return (
      <>
        {/* {connector.kind === "mcp" && (
          <button className={s.cardActionBtn} disabled={busyId === id} onClick={() => handleRefresh(connector)}>
            Refresh tools
          </button>
        )} */}
        {(connector.kind === "api" || connector.kind === "db") && (
          <button
            className={s.cardActionBtn}
            disabled={busyId === id}
            onClick={() => handleTest(connector)}
          >
            {busyId === id ? "Testing…" : "Test"}
          </button>
        )}
        {connector.kind !== "channel" && (
          <button
            className={s.cardActionBtn}
            onClick={() => openEdit(connector)}
          >
            Configure
          </button>
        )}
        <button className={s.cardDelBtn} onClick={() => setConfirmId(id)}>
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
          >
            <polyline points="3 6 5 6 21 6" />
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
            <path d="M10 11v6" />
            <path d="M14 11v6" />
            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
          </svg>
          Delete
        </button>
      </>
    );
  };

  return (
    <div className={s.listWrap}>
      <div className={s.listTop}>
        {/* Connectors | Marketplace tab switch */}
        <div className={ms.viewTabs}>
          <button
            type="button"
            className={`${ms.viewTab}${mainView === "connectors" ? ` ${ms.viewTabActive}` : ""}`}
            onClick={() => setMainView("connectors")}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" />
              <path d="M8 21h8M12 17v4" />
            </svg>
            Connectors
          </button>
          <button
            type="button"
            className={`${ms.viewTab}${mainView === "marketplace" ? ` ${ms.viewTabActive}` : ""}`}
            onClick={() => setMainView("marketplace")}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
              <line x1="3" y1="6" x2="21" y2="6" />
              <path d="M16 10a4 4 0 0 1-8 0" />
            </svg>
            Marketplace
          </button>
        </div>

        {mainView === "connectors" && (
          <>
            <input
              className={s.listSearch}
              placeholder="Search connectors by name or description…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <div style={{ minWidth: "200px" }}>
              <MultiDropdown
                label=""
                placeholder="Select Type"
                options={Object.entries(KIND_LABELS).map(([value, label]) => {
                  return { id: value, name: label };
                })}
                selectedIds={[kindFilter]}
                onToggle={(o) => setKindFilter(o.id as "all" | ConnectorKind)}
                single
              />
            </div>
            <div className={s.viewToggle}>
              <button
                type="button"
                className={`${s.viewBtn}${view === "grid" ? ` ${s.viewBtnActive}` : ""}`}
                onClick={() => setView("grid")}
                aria-label="Grid view"
                title="Grid view"
              >
                <GridIcon />
              </button>
              <button
                type="button"
                className={`${s.viewBtn}${view === "list" ? ` ${s.viewBtnActive}` : ""}`}
                onClick={() => setView("list")}
                aria-label="Table view"
                title="Table view"
              >
                <TableIcon />
              </button>
            </div>
            <div className={s.addWrap}>
              <button
                className={s.primaryBtn}
                onClick={() => setAddOpen((open) => !open)}
              >
                + Add connector
              </button>
              {addOpen && (
                <div className={s.addMenu}>
                  {CREATABLE.map((kind) => (
                    <button key={kind} onClick={() => openCreate(kind)}>
                      {KIND_LABELS[kind]}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {mainView === "marketplace" && (
          <div className={s.viewToggle}>
            <button
              type="button"
              className={`${s.viewBtn}${view === "grid" ? ` ${s.viewBtnActive}` : ""}`}
              onClick={() => setView("grid")}
              aria-label="Grid view"
              title="Grid view"
            >
              <GridIcon />
            </button>
            <button
              type="button"
              className={`${s.viewBtn}${view === "list" ? ` ${s.viewBtnActive}` : ""}`}
              onClick={() => setView("list")}
              aria-label="Table view"
              title="Table view"
            >
              <TableIcon />
            </button>
          </div>
        )}
      </div>

      {/* ── Marketplace ── */}
      {mainView === "marketplace" && (
        <MarketplaceTemplates view={view} onSaved={reload} />
      )}

      {/* ── Connectors list ── */}
      {mainView === "connectors" && (
        <>
          {error && <p className={s.errText}>{error}</p>}
          {loading && connectors.length === 0 && (
            <p className={s.hint}>Loading connectors…</p>
          )}

          {!loading && connectors.length === 0 && !error && (
            <div className={s.emptyState}>
              <p>No connectors yet.</p>
              <span>Add an API, MCP server or database to get started.</span>
            </div>
          )}

          {filtered.length === 0 && connectors.length > 0 && (
            <p className={s.hint}>Nothing matches that search.</p>
          )}

          {view === "grid" ? (
            <div className={s.cards}>
              {filtered.map((connector) => {
                const id = connectorIdOf(connector);
                const status = statusOf(connector);
                return (
                  <div key={`${connector.kind}-${id}`} className={s.card}>
                    <div className={s.cardTop}>
                      <span
                        className={`${s.kindTag} ${s[`kind_${connector.kind}`]}`}
                      >
                        {KIND_LABELS[connector.kind]}
                      </span>
                      {connector?.kind !== "db" && (
                        <span className={`${s.statusTag} ${status.tone}`}>
                          {status.label}
                        </span>
                      )}
                    </div>
                    <h3 className={s.cardName}>
                      {connector.name ?? connector?.connector_name}
                    </h3>
                    <p className={s.cardDesc}>
                      {connector.description || "No description."}
                    </p>
                    {connector.endpoint_url && (
                      <p className={s.cardMeta}>{connector.endpoint_url}</p>
                    )}
                    {rowNotice[id] && (
                      <p className={s.cardMeta}>{rowNotice[id]}</p>
                    )}
                    <div className={s.cardFoot}>
                      {renderCardActions(connector, id)}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className={s.tableWrap}>
              <table className={s.dataTable}>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Endpoint</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((connector) => {
                    const id = connectorIdOf(connector);
                    const status = statusOf(connector);
                    return (
                      <tr key={`${connector.kind}-${id}`}>
                        <td style={{ fontWeight: 600 }}>
                          {connector.name ?? connector?.connector_name}
                        </td>
                        <td>
                          <span
                            className={`${s.kindTag} ${s[`kind_${connector.kind}`]}`}
                          >
                            {KIND_LABELS[connector.kind]}
                          </span>
                        </td>
                        <td>
                          <span className={`${s.statusTag} ${status.tone}`}>
                            {status.label}
                          </span>
                        </td>
                        <td
                          style={{
                            fontSize: "12px",
                            color: "var(--text-soft)",
                            maxWidth: 220,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {connector.endpoint_url || "—"}
                          {rowNotice[id] && (
                            <span
                              style={{
                                marginLeft: 8,
                                color: "var(--text-faint)",
                              }}
                            >
                              {rowNotice[id]}
                            </span>
                          )}
                        </td>
                        <td>
                          {confirmId === id ? (
                            <div className={s.tableActions}>
                              <span className={s.hint} style={{ margin: 0 }}>
                                Delete?
                              </span>
                              <button
                                className={s.dangerBtn}
                                style={{
                                  fontSize: "12px",
                                  padding: "5px 10px",
                                }}
                                onClick={async () => {
                                  await deleteConnector(connector.kind, id);
                                  setConfirmId(null);
                                }}
                              >
                                Confirm
                              </button>
                              <button
                                className={s.ghostBtn}
                                style={{
                                  fontSize: "12px",
                                  padding: "5px 10px",
                                }}
                                onClick={() => setConfirmId(null)}
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <RowMenu
                              connector={connector}
                              id={id}
                              busyId={busyId}
                              onTest={
                                connector.kind === "api" ||
                                connector.kind === "db"
                                  ? () => handleTest(connector)
                                  : undefined
                              }
                              onRefresh={
                                connector.kind === "mcp"
                                  ? () => handleRefresh(connector)
                                  : undefined
                              }
                              onConfigure={
                                connector.kind !== "channel"
                                  ? () => openEdit(connector)
                                  : undefined
                              }
                              onDelete={() => setConfirmId(id)}
                            />
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {formKind && (
        <ConnectorFormDialog
          kind={formKind}
          existing={editing}
          supportedDatabases={supportedDatabases}
          onClose={() => {
            setFormKind(null);
            setEditing(null);
          }}
          onSaved={reload}
        />
      )}
    </div>
  );
};
