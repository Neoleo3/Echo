"use client";

import React from "react";
import { CONTENT_TYPES, HTTP_METHODS } from "../connectorFormConfig";
import { AuthFieldSet } from "./AuthFieldSet";
import {
  CheckboxField,
  JsonField,
  KeyValueEditor,
  SelectField,
  TextField,
} from "./ConnectorFields";
import type { ApiFormState } from "../hooks/useConnectorForm";
import s from "./connectors.module.css";

interface ApiConnectorFormProps {
  form: ApiFormState;
  update: <K extends keyof ApiFormState>(key: K, value: ApiFormState[K]) => void;
  onAuthTypeChange: (authType: string) => void;
  onAuthValueChange: (field: string, value: unknown) => void;
  editing?: boolean;
}

/** A body only means something on methods that carry one. */
const METHODS_WITH_BODY = new Set(["POST", "PUT", "PATCH"]);

export const ApiConnectorForm: React.FC<ApiConnectorFormProps> = ({
  form,
  update,
  onAuthTypeChange,
  onAuthValueChange,
  editing,
}) => (
  <div className={s.formGrid}>
    <TextField
      label="Name"
      required
      value={form.name}
      onChange={(value) => update("name", value)}
      placeholder="e.g. Internal Analytics API"
    />
    <TextField
      label="Icon"
      value={form.logo}
      onChange={(value) => update("logo", value)}
      placeholder="Optional identifier"
    />
    <TextField
      label="Description"
      full
      value={form.description}
      onChange={(value) => update("description", value)}
      placeholder="What does this API do?"
    />

    <TextField
      label="Endpoint URL"
      required
      full
      value={form.endpoint_url}
      onChange={(value) => update("endpoint_url", value)}
      placeholder="https://api.example.com/v1/resource"
      hint="Must start with http:// or https://."
    />

    <SelectField
      label="Method"
      value={form.method}
      onChange={(value) => update("method", value)}
      options={HTTP_METHODS.map((method) => ({ value: method, label: method }))}
    />
    <SelectField
      label="Content type"
      value={form.content_type}
      onChange={(value) => update("content_type", value)}
      options={CONTENT_TYPES.map((type) => ({ value: type, label: type }))}
    />

    <TextField
      label="Timeout (seconds)"
      type="number"
      value={String(form.timeout)}
      onChange={(value) => update("timeout", Number(value))}
      hint="1–300."
    />
    <TextField
      label="Retries"
      type="number"
      value={String(form.retry_count)}
      onChange={(value) => update("retry_count", Number(value))}
      hint="0–5."
    />

    <div className={s.full}>
      <CheckboxField
        label="Verify SSL certificates"
        hint="Turn this off only for a trusted host with a self-signed certificate."
        checked={form.verify_ssl}
        onChange={(checked) => update("verify_ssl", checked)}
      />
    </div>

    <KeyValueEditor
      label="Default headers"
      value={form.headers}
      onChange={(next) => update("headers", next)}
      hint="Sent with every request. Authentication is configured separately below."
    />

    <KeyValueEditor
      label="Default query parameters"
      value={form.query_params}
      onChange={(next) => update("query_params", next)}
    />

    {METHODS_WITH_BODY.has(form.method) && (
      <JsonField
        label="Default request body"
        value={form.default_body}
        onChange={(raw) => update("default_body", raw)}
        hint="A JSON object sent as the body unless a caller overrides it."
      />
    )}

    <AuthFieldSet
      kind="API"
      authType={form.auth_type}
      values={form.auth}
      onTypeChange={onAuthTypeChange}
      onValueChange={onAuthValueChange}
      editing={editing}
    />
  </div>
);
