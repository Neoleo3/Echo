"use client";

import React, { useCallback, useEffect, useState } from "react";
import s from "./connectors.module.css";
import ms from "./marketplace.module.css";
import sharepoint from "@/assests/marketplace/sharepointMicrosoft.svg";
import azure from "@/assests/marketplace/azure.svg";
import aws from "@/assests/marketplace/aws.svg";
import teams from "@/assests/marketplace/teams.svg";
import outlook from "@/assests/marketplace/outlook.svg";
import oracle from "@/assests/marketplace/oracle.svg";
import api from "@/assests/marketplace/api.svg";

const iconMap: Record<string, any> = {
  sharepoint: sharepoint,
  azure: azure,
  aws: aws,
  teams: teams,
  outlook: outlook,
  oracle: oracle,
  api: api,
};

/* ─── Types ─────────────────────────────────────────────────────────────── */

interface InputSchemaField {
  key: string;
  type: string;
  label: string;
  options: string[];
  required: boolean;
  help_text: string;
  placeholder: string | null;
  default_value: string | null;
}

interface MarketplaceTemplate {
  id: string;
  template_id: string;
  name: string;
  description: string;
  connector_type: "api" | "mcp" | "empty" | string;
  status: string;
  icon: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  template_json: {
    input_schema: InputSchemaField[];
    connector_config: Record<string, unknown>;
  };
}

import { ENV } from "@/config";
import { MultiDropdown } from "@/components/common/MultiDropdown";
import Image from "next/image";

/* ─── Helpers ─────────────────────────────────────────────────────────────── */

const CONNECTOR_TYPE_OPTIONS = [
  { value: "", label: "All types" },
  { value: "api", label: "API" },
  { value: "mcp", label: "MCP" },
];

const TYPE_COLORS: Record<string, string> = {
  api: "#06b6d4",
  mcp: "#6366f1",
  empty: "#8b5cf6",
};

const BASE_URL =
  ENV.API_BASE_URL ??
  "https://ecoapilwebapp02-ash2f8e6fcgzexgq.centralindia-01.azurewebsites.net";

async function apiFetch(url: string, options?: RequestInit) {
  const headers: Record<string, string> = {
    accept: "application/json",
    ...(options?.headers as Record<string, string>),
  };
  const res = await fetch(url, { ...options, headers, credentials: "include" });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

/* ─── UseTemplateDialog ──────────────────────────────────────────────────── */

interface UseTemplateDialogProps {
  template: MarketplaceTemplate;
  onClose: () => void;
  onSaved: () => void;
}

const UseTemplateDialog: React.FC<UseTemplateDialogProps> = ({
  template,
  onClose,
  onSaved,
}) => {
  const inputSchema = template.template_json?.input_schema ?? [];
  const connectorConfig = template.template_json?.connector_config ?? {};

  const [inputs, setInputs] = useState<Record<string, string>>(() =>
    Object.fromEntries(inputSchema.map((f) => [f.key, f.default_value ?? ""])),
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [revealFields, setRevealFields] = useState<Set<string>>(new Set());

  const toggleReveal = (key: string) => {
    setRevealFields((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      await apiFetch(
        `${BASE_URL}/marketplace/templates/${template.template_id}/use`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ inputs }),
        },
      );
      onSaved();
      onClose();
    } catch (err: any) {
      setError(err?.message ?? "Failed to create connector from template.");
    } finally {
      setSaving(false);
    }
  };

  const canSave = inputSchema
    .filter((f) => f.required)
    .every((f) => (inputs[f.key] ?? "").trim() !== "");

  // Render the connector_config as a flat list of disabled fields
  const configEntries = flattenConfig(connectorConfig);

  return (
    <div className={s.overlay} onClick={onClose}>
      <div
        className={s.dialog}
        style={{ maxWidth: 600 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={s.dialogHead}>
          <div>
            <h3 className={s.dialogTitle}>{template.name}</h3>
            <p className={s.dialogBlurb}>{template.description}</p>
          </div>
          <button
            className={s.dialogClose}
            onClick={onClose}
            aria-label="Close"
          >
            ×
          </button>
        </div>

        <div className={s.dialogBody}>
          {/* Required inputs from input_schema */}
          {inputSchema.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <p
                style={{
                  fontSize: 12,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                  color: "var(--text-faint)",
                  marginBottom: 12,
                  marginTop: 0,
                }}
              >
                Required Configuration
              </p>
              <div className={s.formGrid}>
                {inputSchema.map((field) => (
                  <div key={field.key} className={`${s.field} ${s.full}`}>
                    <label>
                      {field.label}{" "}
                      {field.required && <span className={s.req}>*</span>}
                    </label>

                    {/* Select — when options array is populated */}
                    {field.options?.length > 0 ? (
                      <select
                        value={inputs[field.key] ?? ""}
                        onChange={(e) =>
                          setInputs((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                          }))
                        }
                      >
                        <option value="">Select…</option>
                        {field.options.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    ) : field.type === "password" ? (
                      /* Password field with show/hide toggle */
                      <div className={s.secretRow}>
                        <input
                          type={
                            revealFields.has(field.key) ? "text" : "password"
                          }
                          value={inputs[field.key] ?? ""}
                          placeholder={field.placeholder ?? ""}
                          autoComplete="new-password"
                          onChange={(e) =>
                            setInputs((prev) => ({
                              ...prev,
                              [field.key]: e.target.value,
                            }))
                          }
                        />
                        <button
                          type="button"
                          className={s.ghostBtn}
                          onClick={() => toggleReveal(field.key)}
                        >
                          {revealFields.has(field.key) ? "Hide" : "Show"}
                        </button>
                      </div>
                    ) : field.type === "textarea" ? (
                      /* Multiline text */
                      <textarea
                        value={inputs[field.key] ?? ""}
                        placeholder={field.placeholder ?? ""}
                        rows={3}
                        onChange={(e) =>
                          setInputs((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                          }))
                        }
                      />
                    ) : (
                      /* Default: plain text / number / email */
                      <input
                        type={field.type === "number" ? "number" : "text"}
                        value={inputs[field.key] ?? ""}
                        placeholder={field.placeholder ?? ""}
                        onChange={(e) =>
                          setInputs((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                          }))
                        }
                      />
                    )}

                    {field.help_text && (
                      <p className={s.hint}>{field.help_text}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Connector config (read-only) */}
          {configEntries.length > 0 && (
            <div>
              <p
                style={{
                  fontSize: 12,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                  color: "var(--text-faint)",
                  marginBottom: 12,
                  marginTop: 0,
                }}
              >
                Connector Configuration (pre-filled)
              </p>
              <div className={s.formGrid}>
                {configEntries.map(({ key, value }) => (
                  <div key={key} className={`${s.field} ${s.full}`}>
                    <label style={{ textTransform: "capitalize" }}>
                      {key.replace(/_/g, " ")}
                    </label>
                    <input
                      type="text"
                      value={
                        typeof value === "object"
                          ? JSON.stringify(value)
                          : String(value ?? "")
                      }
                      disabled
                      readOnly
                      style={{ opacity: 0.65, cursor: "not-allowed" }}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && <p className={s.errText}>{error}</p>}
        </div>

        <div className={s.dialogFoot}>
          <button className={s.ghostBtn} onClick={onClose}>
            Cancel
          </button>
          <button
            className={s.primaryBtn}
            onClick={handleSave}
            disabled={saving || !canSave}
          >
            {saving ? "Creating…" : "Use Template"}
          </button>
        </div>
      </div>
    </div>
  );
};

/** Flatten a nested connector_config object for display. */
function flattenConfig(
  obj: Record<string, unknown>,
  prefix = "",
): { key: string; value: unknown }[] {
  const result: { key: string; value: unknown }[] = [];
  for (const [k, v] of Object.entries(obj)) {
    const fullKey = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === "object" && !Array.isArray(v)) {
      result.push(...flattenConfig(v as Record<string, unknown>, fullKey));
    } else {
      result.push({ key: fullKey, value: v });
    }
  }
  return result;
}

/* ─── Main Marketplace Component ─────────────────────────────────────────── */

interface MarketplaceTemplatesProps {
  view: "grid" | "list";
  onSaved: () => void;
}

export const MarketplaceTemplates: React.FC<MarketplaceTemplatesProps> = ({
  view,
  onSaved,
}) => {
  const [templates, setTemplates] = useState<MarketplaceTemplate[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState("");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<MarketplaceTemplate | null>(null);

  const fetchTemplates = useCallback(async (connectorType = "") => {
    setLoading(true);
    setError(null);
    try {
      const params = connectorType ? `?connector_type=${connectorType}` : "";
      const data = await apiFetch(`${BASE_URL}/marketplace/templates${params}`);
      setTemplates(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err?.message ?? "Failed to load marketplace templates.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTemplates(typeFilter);
  }, [typeFilter, fetchTemplates]);

  const filtered = templates.filter((t) => {
    const q = search.trim().toLowerCase();
    return (
      !q ||
      t.name.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q)
    );
  });

  console.log("filter: ", filtered);

  return (
    <div className={ms.mpWrap}>
      {/* Toolbar */}
      <div className={ms.mpTop}>
        <input
          className={s.listSearch}
          placeholder="Search templates…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div style={{ minWidth: "200px" }}>
          <MultiDropdown
            label=""
            placeholder="Select Type"
            options={CONNECTOR_TYPE_OPTIONS.map((type: any) => {
              return { id: type.value, name: type.label };
            })}
            selectedIds={[typeFilter]}
            onToggle={(o) => setTypeFilter(o.id)}
            single
          />
        </div>
      </div>

      {error && <p className={s.errText}>{error}</p>}

      {loading && (
        <div className={ms.mpLoading}>
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            style={{ animation: "spin 1s linear infinite" }}
          >
            <path d="M21 12a9 9 0 1 1-9-9" />
          </svg>
          Loading templates…
        </div>
      )}

      {!loading && filtered.length === 0 && !error && (
        <div className={s.emptyState}>
          <p>No templates found.</p>
          <span>Try a different type or search term.</span>
        </div>
      )}

      {!loading && view === "grid" && (
        <div className={ms.mpCards}>
          {filtered.map((t) => (
            <div
              key={t.template_id}
              className={ms.mpCard}
              onClick={() => setSelected(t)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && setSelected(t)}
            >
              <div className={ms.mpCardTop}>
                <div className={ms.mpIcon}>
                  {(() => {
                    const iconName = t.icon || t.name || "";
                    const iconSrc = iconName ? iconMap[iconName] : null;
                    return iconSrc ? (
                      <Image
                        src={iconSrc}
                        alt={iconName}
                        width={20}
                        height={20}
                        className="w-4 h-4 mr-1"
                      />
                    ) : (
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke={`var(--text)`}
                        strokeWidth="2"
                      >
                        <rect x="2" y="7" width="20" height="14" rx="2" />
                        <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" />
                      </svg>
                    );
                  })()}
                </div>
                <span
                  className={s.kindTag}
                  style={{
                    background:
                      TYPE_COLORS[t.connector_type] ?? "var(--text-faint)",
                  }}
                >
                  {t.connector_type}
                </span>
              </div>
              <h3 className={ms.mpCardName}>{t.name}</h3>
              <p className={ms.mpCardDesc}>{t.description}</p>
              <div className={ms.mpCardFoot}>
                <button
                  className={s.primaryBtn}
                  style={{ fontSize: 12, padding: "7px 14px" }}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelected(t);
                  }}
                >
                  Use Template
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && view === "list" && (
        <div className={s.tableWrap}>
          <table className={s.dataTable}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Description</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => (
                <tr
                  key={t.template_id}
                  style={{ cursor: "pointer" }}
                  onClick={() => setSelected(t)}
                >
                  <td style={{ fontWeight: 600 }}>{t.name}</td>
                  <td>
                    <span
                      className={s.kindTag}
                      style={{
                        background:
                          TYPE_COLORS[t.connector_type] ?? "var(--text-faint)",
                      }}
                    >
                      {t.connector_type}
                    </span>
                  </td>
                  <td
                    style={{
                      fontSize: 12,
                      color: "var(--text-soft)",
                      maxWidth: 300,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {t.description}
                  </td>
                  <td>
                    <button
                      className={s.primaryBtn}
                      style={{ fontSize: 12, padding: "6px 12px" }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelected(t);
                      }}
                    >
                      Use
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <UseTemplateDialog
          template={selected}
          onClose={() => setSelected(null)}
          onSaved={onSaved}
        />
      )}
    </div>
  );
};
