"use client";

import React, { useState } from "react";
import s from "./connectors.module.css";

interface BaseFieldProps {
  label: string;
  hint?: string;
  required?: boolean;
  full?: boolean;
}

export const TextField: React.FC<
  BaseFieldProps & {
    value: string;
    onChange: (value: string) => void;
    type?: "text" | "number" | "password";
    placeholder?: string;
    multiline?: boolean;
  }
> = ({
  label,
  hint,
  required,
  full,
  value,
  onChange,
  type = "text",
  placeholder,
  multiline,
}) => (
  <div className={`${s.field}${full ? ` ${s.full}` : ""}`}>
    <label>
      {label} {required && <span className={s.req}>*</span>}
    </label>
    {multiline ? (
      <textarea
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    ) : (
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    )}
    {hint && <p className={s.hint}>{hint}</p>}
  </div>
);

export const SecretField: React.FC<
  BaseFieldProps & {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
    editing?: boolean;
  }
> = ({
  label,
  hint,
  required,
  full,
  value,
  onChange,
  placeholder,
  editing,
}) => {
  const [reveal, setReveal] = useState(false);
  return (
    <div className={`${s.field}${full ? ` ${s.full}` : ""}`}>
      <label>
        {label} {required && <span className={s.req}>*</span>}
      </label>
      <div className={s.secretRow}>
        <input
          type={reveal ? "text" : "password"}
          value={value}
          placeholder={
            placeholder ?? (editing ? "Leave blank to keep current" : "")
          }
          onChange={(e) => onChange(e.target.value)}
          autoComplete="new-password"
        />
        <button
          type="button"
          className={s.ghostBtn}
          onClick={() => setReveal((open) => !open)}
        >
          {reveal ? "Hide" : "Show"}
        </button>
      </div>
      <p className={s.hint}>
        {hint ?? (editing ? "Leave blank to keep the stored value." : "")}
      </p>
    </div>
  );
};

export const SelectField: React.FC<
  BaseFieldProps & {
    value: string;
    onChange: (value: string) => void;
    options: { value: string; label: string }[];
  }
> = ({ label, hint, required, full, value, onChange, options }) => (
  <div className={`${s.field}${full ? ` ${s.full}` : ""}`}>
    <label>
      {label} {required && <span className={s.req}>*</span>}
    </label>
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
    {hint && <p className={s.hint}>{hint}</p>}
  </div>
);

export const CheckboxField: React.FC<{
  label: string;
  hint?: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}> = ({ label, hint, checked, onChange }) => (
  <label className={s.checkRow}>
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
    />
    <span>
      <span className={s.checkLabel}>{label}</span>
      {hint && <span className={s.checkHint}>{hint}</span>}
    </span>
  </label>
);

export const KeyValueEditor: React.FC<{
  label: string;
  hint?: string;
  value: Record<string, string>;
  onChange: (next: Record<string, string>) => void;
  secretValues?: boolean;
}> = ({ label, hint, value, onChange, secretValues }) => {
  const entries = Object.entries(value ?? {});

  const setEntry = (index: number, key: string, entryValue: string) => {
    const next: Record<string, string> = {};
    entries.forEach(([existingKey, existingValue], i) => {
      if (i === index) next[key] = entryValue;
      else next[existingKey] = existingValue;
    });
    onChange(next);
  };

  const removeEntry = (index: number) => {
    const next: Record<string, string> = {};
    entries.forEach(([key, entryValue], i) => {
      if (i !== index) next[key] = entryValue;
    });
    onChange(next);
  };

  return (
    <div className={`${s.field} ${s.full}`}>
      <label>{label}</label>
      {entries.length === 0 && <p className={s.hint}>None yet.</p>}
      {entries.map(([key, entryValue], index) => (
        <div key={index} className={s.kvRow}>
          <input
            type="text"
            placeholder="name"
            value={key}
            onChange={(e) => setEntry(index, e.target.value, entryValue)}
          />
          <input
            type={secretValues ? "password" : "text"}
            placeholder="value"
            value={entryValue}
            onChange={(e) => setEntry(index, key, e.target.value)}
          />
          <button
            type="button"
            className={s.ghostBtn}
            onClick={() => removeEntry(index)}
          >
            Remove
          </button>
        </div>
      ))}
      <button
        type="button"
        className={s.ghostBtn}
        onClick={() => onChange({ ...value, "": "" })}
        disabled={Object.prototype.hasOwnProperty.call(value ?? {}, "")}
      >
        + Add
      </button>
      {hint && <p className={s.hint}>{hint}</p>}
    </div>
  );
};

export const StringListField: React.FC<{
  label: string;
  hint?: string;
  value: string[];
  onChange: (next: string[]) => void;
}> = ({ label, hint, value, onChange }) => (
  <div className={`${s.field} ${s.full}`}>
    <label>{label}</label>
    {(value ?? []).map((item, index) => (
      <div key={index} className={s.kvRow}>
        <input
          type="text"
          value={item}
          onChange={(e) =>
            onChange(
              value.map((existing, i) =>
                i === index ? e.target.value : existing,
              ),
            )
          }
        />
        <button
          type="button"
          className={s.ghostBtn}
          onClick={() => onChange(value.filter((_, i) => i !== index))}
        >
          Remove
        </button>
      </div>
    ))}
    <button
      type="button"
      className={s.ghostBtn}
      onClick={() => onChange([...(value ?? []), ""])}
    >
      + Add argument
    </button>
    {hint && <p className={s.hint}>{hint}</p>}
  </div>
);

export const JsonField: React.FC<{
  label: string;
  hint?: string;
  value: string;
  onChange: (raw: string) => void;
  placeholder?: string;
}> = ({ label, hint, value, onChange, placeholder }) => {
  const trimmed = (value ?? "").trim();
  let invalid = false;
  if (trimmed) {
    try {
      JSON.parse(trimmed);
    } catch {
      invalid = true;
    }
  }

  return (
    <div className={`${s.field} ${s.full}`}>
      <label>{label}</label>
      <textarea
        className={`${s.mono}${invalid ? ` ${s.invalid}` : ""}`}
        rows={4}
        value={value}
        placeholder={placeholder ?? "{ }"}
        onChange={(e) => onChange(e.target.value)}
      />
      {invalid ? (
        <p className={s.errText}>That is not valid JSON yet.</p>
      ) : (
        hint && <p className={s.hint}>{hint}</p>
      )}
    </div>
  );
};
