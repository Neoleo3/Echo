"use client";

import { useCallback, useState } from "react";
import { AUTH_FIELDS, GRANT_TYPE } from "../connectorFormConfig";
import type {
  ApiConnectorPayload,
  AuthPayload,
  AuthValues,
  DbConnectorPayload,
  McpConnectorPayload,
} from "@/types/connector.types";
import { Connector } from "@/types";

export interface ApiFormState {
  name: string;
  description: string;
  logo: string;
  endpoint_url: string;
  method: string;
  content_type: string;
  timeout: number;
  retry_count: number;
  verify_ssl: boolean;
  headers: Record<string, string>;
  query_params: Record<string, string>;
  default_body: string;
  auth_type: string;
  auth: AuthValues;
}

export interface McpFormState {
  name: string;
  description: string;
  icon: string;
  transport_type: string;
  endpoint_url: string;
  headers: Record<string, string>;
  timeout: number;
  enabled: boolean;
  command: string;
  args: string[];
  env_vars: Record<string, string>;
  working_dir: string;
  shell: boolean;
  auth_type: string;
  auth: AuthValues;
}

export interface DbFormState {
  db_type: string;
  name: string;
  host: string;
  port: string;
  database_name: string;
  username: string;
  password: string;
  account_url: string;
  odbc_connection_string: string;
  database_file_path: string;
  file: File | null;
}

export const EMPTY_API_FORM: ApiFormState = {
  name: "",
  description: "",
  logo: "",
  endpoint_url: "",
  method: "GET",
  content_type: "application/json",
  timeout: 30,
  retry_count: 3,
  verify_ssl: true,
  headers: {},
  query_params: {},
  default_body: "",
  auth_type: "none",
  auth: {},
};

export const EMPTY_MCP_FORM: McpFormState = {
  name: "",
  description: "",
  icon: "",
  transport_type: "streamable_http",
  endpoint_url: "",
  headers: {},
  timeout: 30,
  enabled: true,
  command: "",
  args: [],
  env_vars: {},
  working_dir: "",
  shell: false,
  auth_type: "none",
  auth: {},
};

export const EMPTY_DB_FORM: DbFormState = {
  db_type: "",
  name: "",
  host: "",
  port: "",
  database_name: "",
  username: "",
  password: "",
  account_url: "",
  odbc_connection_string: "",
  database_file_path: "",
  file: null,
};

const prune = <T extends Record<string, unknown>>(
  source: T,
): Record<string, unknown> => {
  const out: Record<string, unknown> = {};
  Object.entries(source).forEach(([key, value]) => {
    if (value === undefined || value === null) return;
    if (typeof value === "string" && value.trim() === "") return;
    if (Array.isArray(value) && value.length === 0) return;
    if (
      typeof value === "object" &&
      !Array.isArray(value) &&
      Object.keys(value as object).length === 0
    ) {
      return;
    }
    out[key] = value;
  });
  return out;
};

export function buildAuthPayload(
  authType: string,
  values: AuthValues,
): AuthPayload {
  const cleaned = prune(values as Record<string, unknown>);
  return {
    auth_type: authType || "none",
    auth_config: { ...cleaned, auth_type: authType || "none" },
  };
}

export function authFieldsFor(
  kind: "MCP" | "API",
  authType: string,
  values: AuthValues,
): string[] {
  const base = AUTH_FIELDS[kind][authType] ?? [];
  if (kind !== "MCP" || authType !== "oauth2") return base;
  const grant = String(values.grant_type ?? "");
  return [...base, ...(GRANT_TYPE[grant] ?? [])];
}

const parseJsonObject = (raw: string): Record<string, unknown> | undefined => {
  const trimmed = (raw ?? "").trim();
  if (!trimmed) return undefined;
  try {
    const parsed = JSON.parse(trimmed);
    return typeof parsed === "object" &&
      parsed !== null &&
      !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : undefined;
  } catch {
    return undefined;
  }
};

export function buildApiPayload(form: ApiFormState): ApiConnectorPayload {
  return {
    ...prune({
      name: form.name,
      description: form.description,
      logo: form.logo,
      endpoint_url: form.endpoint_url,
      headers: form.headers,
      query_params: form.query_params,
      default_body: parseJsonObject(form.default_body),
    }),
    method: form.method || "GET",
    content_type: form.content_type || "application/json",
    timeout: Number(form.timeout) || 30,
    retry_count: Number.isFinite(Number(form.retry_count))
      ? Number(form.retry_count)
      : 3,
    verify_ssl: form.verify_ssl !== false,
    ...buildAuthPayload(form.auth_type, form.auth),
  } as ApiConnectorPayload;
}

export function buildMcpPayload(form: McpFormState): McpConnectorPayload {
  const isStdio = form.transport_type === "stdio";
  return {
    ...prune({
      name: form.name,
      description: form.description,
      icon: form.icon,
      endpoint_url: isStdio ? "" : form.endpoint_url,
      headers: isStdio ? {} : form.headers,
      command: isStdio ? form.command : "",
      args: isStdio ? form.args.filter((arg) => arg.trim() !== "") : [],
      env_vars: isStdio ? form.env_vars : {},
      working_dir: isStdio ? form.working_dir : "",
    }),
    transport_type: form.transport_type || "streamable_http",
    timeout: Number(form.timeout) || 30,
    enabled: form.enabled !== false,
    ...(isStdio ? { shell: Boolean(form.shell) } : {}),
    ...buildAuthPayload(form.auth_type, form.auth),
  } as McpConnectorPayload;
}

export function buildDbPayload(
  form: DbFormState,
  fields: string[],
): DbConnectorPayload {
  const payload: Record<string, unknown> = { db_type: form.db_type };
  fields.forEach((field) => {
    const value = (form as unknown as Record<string, unknown>)[field];
    if (value === undefined || value === null || value === "") return;
    payload[field] = field === "port" ? Number(value) : value;
  });
  return payload as unknown as DbConnectorPayload;
}

const asRecord = (value: unknown): Record<string, string> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, string>)
    : {};

export function apiFormFrom(connector: Connector): ApiFormState {
  const p = (connector.creation_payload ?? {}) as Record<string, unknown>;
  return {
    ...EMPTY_API_FORM,
    name: connector.name ?? "",
    description: connector.description ?? "",
    logo: String(p.logo ?? ""),
    endpoint_url: String(p.endpoint_url ?? connector.endpoint_url ?? ""),
    method: String(p.method ?? "GET"),
    content_type: String(p.content_type ?? "application/json"),
    timeout: Number(p.timeout ?? 30),
    retry_count: Number(p.retry_count ?? 3),
    verify_ssl: p.verify_ssl !== false,
    headers: asRecord(p.headers),
    query_params: asRecord(p.query_params),
    default_body: p.default_body ? JSON.stringify(p.default_body, null, 2) : "",
    auth_type: String(p.auth_type ?? "none"),
    auth: {},
  };
}

export function mcpFormFrom(connector: Connector): McpFormState {
  const p = (connector.creation_payload ?? {}) as Record<string, unknown>;
  return {
    ...EMPTY_MCP_FORM,
    name: connector.name ?? "",
    description: connector.description ?? "",
    icon: String(p.icon ?? ""),
    transport_type: String(
      p.transport_type ?? connector.transport_type ?? "streamable_http",
    ),
    endpoint_url: String(p.endpoint_url ?? connector.endpoint_url ?? ""),
    headers: asRecord(p.headers),
    timeout: Number(p.timeout ?? 30),
    enabled: p.enabled !== false,
    command: String(p.command ?? ""),
    args: Array.isArray(p.args) ? (p.args as string[]) : [],
    env_vars: asRecord(p.env_vars),
    working_dir: String(p.working_dir ?? ""),
    shell: Boolean(p.shell),
    auth_type: String(p.auth_type ?? "none"),
    auth: {},
  };
}

export function dbFormFrom(connector: Connector): DbFormState {
  const p = (connector.creation_payload ?? {}) as Record<string, unknown>;
  return {
    ...EMPTY_DB_FORM,
    db_type: String(p.db_type ?? ""),
    name: connector.name ?? String(p.name ?? ""),
    host: String(p.host ?? ""),
    port: p.port ? String(p.port) : "",
    database_name: String(p.database_name ?? ""),
    username: String(p.username ?? ""),
    account_url: String(p.account_url ?? ""),
    odbc_connection_string: String(p.odbc_connection_string ?? ""),
    database_file_path: String(p.database_file_path ?? ""),
  };
}

export function useConnectorForm() {
  const [api, setApi] = useState<ApiFormState>(EMPTY_API_FORM);
  const [mcp, setMcp] = useState<McpFormState>(EMPTY_MCP_FORM);
  const [db, setDb] = useState<DbFormState>(EMPTY_DB_FORM);

  const updateApi = useCallback(
    <K extends keyof ApiFormState>(key: K, value: ApiFormState[K]) => {
      setApi((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  const updateMcp = useCallback(
    <K extends keyof McpFormState>(key: K, value: McpFormState[K]) => {
      setMcp((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  const updateDb = useCallback(
    <K extends keyof DbFormState>(key: K, value: DbFormState[K]) => {
      setDb((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  const setApiAuthType = useCallback((authType: string) => {
    setApi((prev) => ({ ...prev, auth_type: authType, auth: {} }));
  }, []);

  const setMcpAuthType = useCallback((authType: string) => {
    setMcp((prev) => ({ ...prev, auth_type: authType, auth: {} }));
  }, []);

  const updateApiAuth = useCallback((field: string, value: unknown) => {
    setApi((prev) => ({ ...prev, auth: { ...prev.auth, [field]: value } }));
  }, []);

  const updateMcpAuth = useCallback((field: string, value: unknown) => {
    setMcp((prev) => ({ ...prev, auth: { ...prev.auth, [field]: value } }));
  }, []);

  const reset = useCallback(() => {
    setApi(EMPTY_API_FORM);
    setMcp(EMPTY_MCP_FORM);
    setDb(EMPTY_DB_FORM);
  }, []);

  return {
    api,
    mcp,
    db,
    setApi,
    setMcp,
    setDb,
    updateApi,
    updateMcp,
    updateDb,
    setApiAuthType,
    setMcpAuthType,
    updateApiAuth,
    updateMcpAuth,
    reset,
  };
}
