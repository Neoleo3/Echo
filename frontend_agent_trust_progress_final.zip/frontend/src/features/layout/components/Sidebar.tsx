"use client";

import { useState } from "react";
import AccountFooter from "./AccountFooter";
import { useAuth } from "@/hooks/useAuth";
import { AUTH_ROLES, ROUTES } from "@/config";
import HistoryToggle from "./HistoryToggle";
import {
  ChatIcon,
  ConvoIcon,
  HomeIcon,
  Icon,
  LibraryIcon,
} from "@/components/common/Icons";
import { usePathname, useRouter } from "next/navigation";
import "@/styles/chat.css";
import { UserRole } from "@/types";
import { TokenUsagePanel } from "./TokenUsagePanel";

const SIDE_LINKS = [
  {
    icon: "file-text",
    name: "Docs",
    disable: false,
    desc: "Documentation",
    type: "documentation",
    path: ROUTES.DOCUMENTATION,
  },
  {
    icon: "chats-circle",
    name: "Support",
    disable: false,
    desc: "Support Center",
    type: "support",
    path: ROUTES.SUPPORT,
  },
];

// Admins see everything users see, plus Monitoring up top.
const ADMIN_SIDE_LINKS = [
  {
    icon: "shield-check",
    name: "Agent Trust",
    disable: false,
    desc: "Governance & Security",
    type: "agent-trust",
    path: ROUTES.AGENT_TRUST,
  },
  {
    icon: "app-window",
    name: "Monitoring",
    disable: false,
    desc: "Analytic Page",
    type: "monitoring",
    path: ROUTES.MONITORING,
  },
  {
    icon: "settings",
    name: "Settings",
    disable: false,
    desc: "Setting Page",
    type: "setting",
    path: ROUTES.SETTING,
  },
  ...SIDE_LINKS,
];

// ─── Sidebar ──────────────────────────────────────────────────────────────────

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { actingRole, setActingRole, user } = useAuth();
  const [history_open, setHistoryOpen] = useState(false);
  const [token_open, setTokenOpen] = useState(false);

  const isConfigPage = pathname.startsWith(ROUTES.CONFIG);

  const isChatPage =
    pathname === ROUTES.CHAT || pathname.startsWith(`${ROUTES.CHAT}/`);

  const isHomePage =
    pathname === ROUTES.HOME || pathname.startsWith(`${ROUTES.HOME}/`);

  const isLibraryPage =
    pathname === ROUTES.LIBRARY || pathname.startsWith(`${ROUTES.LIBRARY}/`);

  const isConvoBiPage = pathname === ROUTES.CONVOBI;

  const isAdmin =
    actingRole?.toLowerCase() === AUTH_ROLES.ADMIN ||
    actingRole?.toLowerCase() === AUTH_ROLES.SUPER_ADMIN;

  const changeRole = (path: string) => {
    router.push(path);
    setActingRole(AUTH_ROLES.USER as UserRole);
  };

  return (
    <aside className="sidebar">
      <div className="side-top">
        <span className="brand">EchoAI</span>
      </div>

      {!history_open && (
        <nav className="nav">
          {isAdmin && (
            <button
              className={`nav-item ${isConfigPage || isHomePage ? "active" : ""}`}
              onClick={() => {
                if (isConfigPage) {
                  changeRole(ROUTES.HOME);
                } else router.push(ROUTES.CONFIG);
              }}
            >
              <HomeIcon />
              Home
            </button>
          )}

          {(!isAdmin || !isConfigPage) && (
            <button
              className={`nav-item${(isHomePage || isConfigPage || isChatPage) && !isLibraryPage && !isConvoBiPage ? " active" : ""}`}
              onClick={() => router.push(ROUTES.HOME)}
            >
              <ChatIcon />
              Chat
            </button>
          )}

          <button
            className={`nav-item${pathname.endsWith(ROUTES.LIBRARY) ? " active" : ""}`}
            onClick={() => {
              if (isConfigPage) {
                changeRole(ROUTES.LIBRARY);
              } else router.push(ROUTES.LIBRARY);
            }}
          >
            <LibraryIcon />
            Library
          </button>

          <button
            className={`nav-item${pathname.endsWith(ROUTES.CONVOBI) ? " active" : ""}`}
            onClick={() => {
              if (isConfigPage) {
                changeRole(ROUTES.CONVOBI);
              } else router.push(ROUTES.CONVOBI);
            }}
          >
            <ConvoIcon />
            Conversational BI
          </button>
        </nav>
      )}
      <HistoryToggle
        history_open={history_open}
        setHistoryOpen={setHistoryOpen}
        enabled={
          (isHomePage || isChatPage || isLibraryPage) &&
          !isConvoBiPage &&
          !isConfigPage
        }
      />

      <div className="side-spacer" />

      {!token_open && (
        <div className="side-links">
          {(actingRole === "user" ? SIDE_LINKS : ADMIN_SIDE_LINKS).map((l) => {
            return (
              <button
                className="side-link"
                key={l.name}
                type="button"
                tabIndex={-1}
                onClick={() => !l.disable && router.push(l.path)}
              >
                <span className={l.disable ? "sl-ic" : "sl-ia"}>
                  <Icon name={l.icon} size={18} />
                </span>
                <span className="sl-meta">
                  <span className={l.disable ? "sl-name" : "sa-name"}>
                    {l.name}
                  </span>
                  <span className="sl-soon">
                    {l.disable ? "To be added soon" : l.desc}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      )}

      <TokenUsagePanel token_open={token_open} setTokenOpen={setTokenOpen} />

      <AccountFooter
        actingRole={actingRole}
        setActingRole={setActingRole}
        user={user}
      />
    </aside>
  );
}
