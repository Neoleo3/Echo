"use client";

import { API_ROUTES } from "@/config";
import { baseService } from "@/services/base.service";
import { ModelUsage, ModelUsageWindow } from "@/types/monitoring.types";
import { Dispatch, useEffect, useState } from "react";
import "@/styles/chat.css";
import { useAuth } from "@/hooks/useAuth";

interface Props {
  token_open: boolean;
  setTokenOpen: Dispatch<React.SetStateAction<boolean>>;
}

export const TokenUsagePanel = ({ token_open, setTokenOpen }: Props) => {
  const [usage, setUsage] = useState<ModelUsage[]>([]);
  const { logout } = useAuth();

  const LiveTokens = async () => {
    try {
      const response = await baseService.get(API_ROUTES.MONITORING.USAGE);
      if (response?.isAuthError) {
        logout();
      }
      setUsage((response.data as ModelUsage[]) ?? []);
    } catch (error) {
      console.error("Failed to fetch token usage:", error);
      setUsage([]);
    }
  };

  useEffect(() => {
    LiveTokens();
    const interval = setInterval(LiveTokens, 15000);
    return () => clearInterval(interval);
  }, []);

  const lifetimeTotal = usage.reduce(
    (sum, m) => sum + (m.lifetime_tokens || 0),
    0,
  );

  return (
    <div className="tu-wrap">
      <button
        type="button"
        className={`tu-toggle${token_open ? " open" : ""}`}
        aria-expanded={token_open}
        onClick={() => setTokenOpen((o) => !o)}
      >
        <span>Token Usage</span>
        <span className="tu-toggle-meta">
          {lifetimeTotal.toLocaleString()} tokens
        </span>
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          style={{
            transform: token_open ? "rotate(180deg)" : "none",
            transition: "transform .2s ease",
          }}
        >
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>

      <div
        className="tu-slide"
        style={{
          maxHeight: token_open ? 320 : 0,
          opacity: token_open ? 1 : 0,
          transform: token_open ? "translateY(0)" : "translateY(8px)",
          overflow: "scroll",
          scrollbarWidth: "none",
          transition:
            "max-height .3s ease, opacity .25s ease, transform .3s ease",
        }}
      >
        <div className="tu-list">
          {usage.map((m) => (
            <div className="tu-card" key={m.credential_id || m.model}>
              <div className="tu-card-top">
                <span className="tu-model">{m.model}</span>
                <span className="tu-provider">{m.provider}</span>
              </div>
              <UsageBar label="Daily" window={m.daily} />
              <UsageBar label="Monthly" window={m.monthly} />
              <div className="tu-stats">
                <span>
                  {m.lifetime_tokens.toLocaleString()} lifetime tokens
                </span>
                <span>{m.total_calls.toLocaleString()} calls</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

function UsageBar({
  label,
  window,
}: {
  label: string;
  window: ModelUsageWindow;
}) {
  const unlimited = window.limit == null;
  return (
    <div className="tu-bar-row">
      <div className="tu-bar-label">
        <span>{label}</span>
        <span>
          {window.used.toLocaleString()}
          {unlimited ? "" : ` / ${window.limit!.toLocaleString()}`}
        </span>
      </div>
      <div className="tu-bar-track">
        <div
          className="tu-bar-fill"
          style={{
            width: unlimited ? "100%" : `${usagePct(window)}%`,
            opacity: unlimited ? 0.35 : 1,
          }}
        />
      </div>
    </div>
  );
}

function usagePct(window: ModelUsageWindow): number {
  if (window.utilization_pct != null)
    return Math.min(100, window.utilization_pct);
  if (window.limit) return Math.min(100, (window.used / window.limit) * 100);
  return 0;
}
