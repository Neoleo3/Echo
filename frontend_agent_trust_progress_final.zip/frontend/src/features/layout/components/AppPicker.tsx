"use client";

import { CaretUpDown, Icon } from "@/components/common/Icons";
import { ROUTES } from "@/config";
import { useAppSelection } from "@/hooks/useAppSelection";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";

export default function AppPicker() {
  const router = useRouter();
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const rootRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const { applications, selectedApp, loading, selectApp } =
    useAppSelection(path);

  useEffect(() => {
    if (open) requestAnimationFrame(() => searchRef.current?.focus());
  }, [open]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("click", onDoc);
    return () => document.removeEventListener("click", onDoc);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return applications;
    return applications.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.description.toLowerCase().includes(q),
    );
  }, [applications, query]);

  return (
    <div className={`agent-select${open ? " open" : ""}`} ref={rootRef}>
      <button
        type="button"
        className="agent-top"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        <span className="g">
          <Icon name={"sparkle"} size={18} />
        </span>
        <span>
          {selectedApp?.name ||
            (loading ? "Loading…" : "Select an application")}
        </span>
        <span className="cv">
          <CaretUpDown size={15} />
        </span>
      </button>

      <div
        className="menu"
        role="listbox"
        aria-label="Applications"
        // keep .open in sync with state via className toggle
      >
        <div className="m-search">
          <Icon name="search" size={16} />
          <input
            ref={searchRef}
            type="text"
            placeholder="Search applications…"
            autoComplete="off"
            spellCheck={false}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="m-list">
          {filtered.length > 0 && <div className="m-cat">Applications</div>}
          {filtered.map((a) => {
            const sel = selectedApp?.application_id === a.application_id;
            return (
              <button
                type="button"
                key={a.application_id}
                role="option"
                aria-selected={sel}
                className={`m-item${sel ? " sel" : ""}`}
                onClick={() => {
                  selectApp(a, null, () =>
                    router.push(`${ROUTES.HOME}/${a.application_id}`),
                  );
                  setOpen(false);
                }}
              >
                <span className="g">
                  <Icon name={"chat"} size={18} />
                </span>
                <span className="txt">
                  <span className="t-name">{a.name}</span>
                  <span className="t-desc">{a.description || " "}</span>
                </span>
                <span className="check">
                  <Icon name="check" size={16} />
                </span>
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="m-empty">
              {loading ? "Loading applications…" : "No applications found"}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
