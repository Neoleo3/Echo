"use client";

import { LogOut, PanelLeftIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import ThemeSwitcher from "@/components/common/ThemeSwitcher";
import { usePathname, useRouter } from "next/navigation";
import { ROUTES } from "@/config";
import AppPicker from "./AppPicker";
import { Icon } from "@/components/common/Icons";
import { useAppSelection } from "@/hooks/useAppSelection";

interface Props {
  HandleToggle: () => void;
}

export default function Navbar({ HandleToggle }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const { logout } = useAuth();
  const { selectedApp } = useAppSelection(pathname);
  return (
    <div className="topbar">
      <button
        className="side-toggle"
        onClick={HandleToggle}
        aria-label="Toggle sidebar"
        title="Toggle sidebar"
      >
        <PanelLeftIcon size={18} />
      </button>

      {(pathname.startsWith(ROUTES.HOME) ||
        pathname.startsWith(ROUTES.CHAT)) && <AppPicker />}

      {pathname.startsWith(`${ROUTES.CHAT}/`) && (
        <button
          className="newchat-top"
          onClick={() =>
            router.push(`${ROUTES.HOME}/${selectedApp?.application_id}`)
          }
        >
          <Icon name="plus" size={14} /> New chat
        </button>
      )}

      {(pathname.startsWith(ROUTES.CONFIG) ||
        pathname.startsWith(ROUTES.APPLICATION)) && (
        <div className="switch-container">
          <div className="cfg-switch">
            <button
              className={`cfg-seg ${!pathname.endsWith(ROUTES.APPLICATION) ? "active" : ""}`}
              onClick={() => router.push(ROUTES.CONFIG)}
            >
              Configuration
            </button>

            <button
              className={`cfg-seg ${pathname.endsWith(ROUTES.APPLICATION) ? "active" : ""}`}
              onClick={() => router.push(ROUTES.APPLICATION)}
            >
              App
            </button>
          </div>
        </div>
      )}

      <span className="grow" />

      <ThemeSwitcher navbar={true} />

      <button
        className="logout-btn"
        title="Sign out"
        aria-label="Sign out"
        onClick={() => {
          if (logout) logout();
        }}
      >
        <LogOut size={18} />
      </button>
    </div>
  );
}
