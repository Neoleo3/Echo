import { ChatHistoryClock } from "@/components/common/Icons";
import { ROUTES } from "@/config";
import { useAppSelection } from "@/hooks/useAppSelection";
import { applicationsService } from "@/services";
import { useParams, usePathname, useRouter } from "next/navigation";
import { Dispatch, useEffect, useRef, useState } from "react";

export interface Session {
  chat_session_id: string;
  title: string | null;
}

interface Props {
  history_open: boolean;
  setHistoryOpen: Dispatch<React.SetStateAction<boolean>>;
  enabled: boolean;
}

export default function HistoryToggle({
  history_open,
  setHistoryOpen,
  enabled,
}: Props) {
  const params = useParams();
  const path = usePathname();
  const router = useRouter();
  const { selectedApp } = useAppSelection(path);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  // Inline rename state
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const renameInputRef = useRef<HTMLInputElement>(null);

  // Per-row action menu open state
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const session_id = params.session_id as string;

  const [menuPos, setMenuPos] = useState<{
    top: number;
    right: number;
  } | null>(null);

  // ── Fetch history ──
  const fetchHistory = async () => {
    setSessions([]);
    setLoading(true);
    try {
      const response = await applicationsService.getChatSessions(
        selectedApp?.application_id ?? "",
      );
      if (response.success && Array.isArray(response.data)) {
        setSessions(response.data as Session[]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedApp?.application_id) fetchHistory();
  }, [selectedApp]);

  // Close action menu on outside click
  useEffect(() => {
    if (!menuOpenId) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpenId(null);
        setMenuPos(null);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [menuOpenId]);

  // Focus rename input when it appears
  useEffect(() => {
    if (renamingId && renameInputRef.current) {
      renameInputRef.current.focus();
      renameInputRef.current.select();
    }
  }, [renamingId]);

  // ── Handlers ──
  const handleRenameStart = (session: Session) => {
    setMenuOpenId(null);
    setMenuPos(null);
    setRenamingId(session.chat_session_id);
    setRenameValue(session.title || "New Chat");
  };

  const handleRenameSave = async (sessionId: string) => {
    const response = await applicationsService.renameChatSession(
      selectedApp?.application_id ?? "",
      sessionId,
      renameValue.trim() || "New Chat",
    );
    const ok = response.success;
    if (ok) {
      setSessions((prev: Session[]) =>
        prev.map((sess) =>
          sess.chat_session_id === sessionId
            ? { ...sess, title: renameValue.trim() || "New Chat" }
            : sess,
        ),
      );
    }
    setRenamingId(null);
  };

  const handleRenameCancel = () => {
    setRenamingId(null);
    setRenameValue("");
  };

  const handleDelete = async (sessionId: string) => {
    setMenuOpenId(null);
    setMenuPos(null);
    const response = await applicationsService.deleteChatSession(
      selectedApp?.application_id ?? "",
      sessionId,
    );
    if (response?.success) {
      await fetchHistory();
      if (sessionId === session_id) {
        router.push(`${ROUTES.HOME}/${selectedApp?.application_id}`);
      }
    }
  };

  // ── Filtered sessions ──
  const filtered = sessions.filter((sess: Session) =>
    (sess.title || "New Chat").toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="ch-toggle-wrap">
      <button
        type="button"
        className={`nav-item${history_open ? " active" : ""}`}
        disabled={!enabled}
        aria-expanded={history_open}
        onClick={() => enabled && setHistoryOpen((o) => !o)}
      >
        <ChatHistoryClock />
        Chat History
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          style={{
            marginLeft: "auto",
            transform: history_open ? "rotate(180deg)" : "none",
            transition: "transform .2s ease",
          }}
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      <div
        className="ch-slide"
        style={{
          maxHeight: history_open ? 360 : 0,
          opacity: history_open ? 1 : 0,
          overflow: "hidden",
          transition: "max-height .3s ease, opacity .25s ease",
        }}
      >
        {history_open && (
          <div className="ch-panel">
            {/* Search */}
            <div className="m-search ch-search">
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                placeholder="Search chats…"
                value={search}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setSearch(e.target.value)
                }
                aria-label="Search chat history"
              />
            </div>

            {/* Session list */}
            <div className="m-list ch-list">
              {loading && <p className="ch-empty">Loading…</p>}
              {!loading && filtered.length === 0 && (
                <p className="ch-empty">
                  {sessions.length === 0
                    ? "No chat sessions yet."
                    : "No results."}
                </p>
              )}

              {filtered.map((session: Session) => {
                const isActive = session.chat_session_id === session_id;
                const isRenaming = renamingId === session.chat_session_id;
                const isMenuOpen = menuOpenId === session.chat_session_id;

                return (
                  <div
                    key={session.chat_session_id}
                    className={`ch-item${isActive ? " ch-item-active" : ""}`}
                  >
                    {/* Session title / rename input */}
                    <div className="ch-item-body">
                      {isRenaming ? (
                        <input
                          ref={renameInputRef}
                          className="ch-rename-input"
                          value={renameValue}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            setRenameValue(e.target.value)
                          }
                          onKeyDown={(
                            e: React.KeyboardEvent<HTMLInputElement>,
                          ) => {
                            if (e.key === "Enter")
                              handleRenameSave(session.chat_session_id);
                            if (e.key === "Escape") handleRenameCancel();
                          }}
                          aria-label="Rename chat"
                        />
                      ) : (
                        <div
                          onClick={async () => {
                            router.push(
                              `${ROUTES.CHAT}/${selectedApp?.application_id}/${session.chat_session_id}`,
                            );
                          }}
                          className="ch-item-link"
                          title={session.title || "New Chat"}
                        >
                          {session.title || "New Chat"}
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    {isRenaming ? (
                      /* Save / Cancel inline rename */
                      <div className="ch-rename-actions">
                        <button
                          type="button"
                          className="ch-icon-btn"
                          onClick={() =>
                            handleRenameSave(session.chat_session_id)
                          }
                          aria-label="Save rename"
                          title="Save"
                        >
                          {/* checkmark */}
                          <svg
                            width="13"
                            height="13"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        </button>
                        <button
                          type="button"
                          className="ch-icon-btn"
                          onClick={handleRenameCancel}
                          aria-label="Cancel rename"
                          title="Cancel"
                        >
                          {/* ✕ */}
                          <svg
                            width="13"
                            height="13"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <line x1="18" y1="6" x2="6" y2="18" />
                            <line x1="6" y1="6" x2="18" y2="18" />
                          </svg>
                        </button>
                      </div>
                    ) : (
                      /* Three-dot menu */
                      <div
                        className="ch-menu-wrap"
                        ref={isMenuOpen ? menuRef : null}
                      >
                        <button
                          type="button"
                          className="ch-icon-btn ch-more-btn"
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation();
                            // setMenuOpenId(isMenuOpen ? null : session.chat_session_id);
                            if (isMenuOpen) {
                              setMenuOpenId(null);
                              setMenuPos(null);
                            } else {
                              const rect = (
                                e.currentTarget as HTMLButtonElement
                              ).getBoundingClientRect();
                              setMenuPos({
                                top: rect.bottom + 4,
                                right: window.innerWidth - rect.right,
                              });
                              setMenuOpenId(session.chat_session_id);
                            }
                          }}
                          aria-label="More options"
                          aria-expanded={isMenuOpen}
                          aria-haspopup="menu"
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                          >
                            <circle cx="5" cy="12" r="2" />
                            <circle cx="12" cy="12" r="2" />
                            <circle cx="19" cy="12" r="2" />
                          </svg>
                        </button>

                        {isMenuOpen && menuPos && (
                          <div
                            className="ch-menu"
                            role="menu"
                            style={{
                              position: "fixed",
                              top: menuPos.top,
                              right: menuPos.right,
                              zIndex: 9999,
                            }}
                          >
                            {/* Rename */}
                            <button
                              type="button"
                              className="ch-menu-item"
                              role="menuitem"
                              onClick={() => handleRenameStart(session)}
                            >
                              {/* pencil */}
                              <svg
                                width="13"
                                height="13"
                                viewBox="0 0 14 14"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M13.236 0.763861C12.2123 -0.259828 10.5525 -0.259829 9.52885 0.76386L1.65722 8.63549C1.28304 9.00967 1.01623 9.47748 0.88467 9.99003L0.0157097 13.3755C-0.0282329 13.5467 0.0214766 13.7284 0.146457 13.8534C0.271438 13.9783 0.453118 14.028 0.624318 13.9841L4.00978 13.1151C4.52234 12.9836 4.99015 12.7168 5.36433 12.3426L13.236 4.47097C14.2596 3.44728 14.2596 1.78755 13.236 0.763861Z"
                                  fill="currentColor"
                                />
                              </svg>
                              Rename
                            </button>

                            {/* Delete */}
                            <button
                              type="button"
                              className="ch-menu-item ch-menu-danger"
                              role="menuitem"
                              onClick={() =>
                                handleDelete(session.chat_session_id)
                              }
                            >
                              {/* trash */}
                              <svg
                                width="13"
                                height="13"
                                viewBox="0 0 14 14"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M6 2H8C8 1.44772 7.55228 1 7 1C6.44772 1 6 1.44772 6 2ZM5 2C5 0.89543 5.89543 0 7 0C8.10457 0 9 0.89543 9 2H13C13.2761 2 13.5 2.22386 13.5 2.5C13.5 2.77614 13.2761 3 13 3H12.4364L11.2313 11.8378C11.0624 13.0765 10.0044 14 8.75422 14H5.24578C3.99561 14 2.93762 13.0765 2.76871 11.8378L1.56355 3H1C0.723858 3 0.5 2.77614 0.5 2.5C0.5 2.22386 0.723858 2 1 2H5ZM6 5.5C6 5.22386 5.77614 5 5.5 5C5.22386 5 5 5.22386 5 5.5V10.5C5 10.7761 5.22386 11 5.5 11C5.77614 11 6 10.7761 6 10.5V5.5ZM8.5 5C8.77614 5 9 5.22386 9 5.5V10.5C9 10.7761 8.77614 11 8.5 11C8.22386 11 8 10.7761 8 10.5V5.5C8 5.22386 8.22386 5 8.5 5ZM3.75954 11.7027C3.86089 12.4459 4.49568 13 5.24578 13H8.75422C9.50432 13 10.1391 12.4459 10.2405 11.7027L11.4272 3H2.57281L3.75954 11.7027Z"
                                  fill="currentColor"
                                />
                              </svg>
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
