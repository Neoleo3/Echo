"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNotifications } from "@/hooks/useNotifications";
import type { AppNotification } from "@/types";
import s from "@/styles/config.module.css";

interface NotificationBellProps {
  enabled: boolean;
  onOpenApplication?: (applicationId: string) => void;
}

const isActionable = (notification: AppNotification): boolean =>
  notification.type === "approval_pending" &&
  notification.reference_type === "application" &&
  Boolean(notification.reference_id);

const relativeTime = (iso: string): string => {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";

  const seconds = Math.round((Date.now() - then) / 1000);
  if (seconds < 60) return "just now";

  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;

  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;

  const days = Math.round(hours / 24);
  if (days < 7) return `${days}d ago`;

  return new Date(then).toLocaleDateString();
};

export const NotificationBell: React.FC<NotificationBellProps> = ({
  enabled,
  onOpenApplication,
}) => {
  const {
    notifications,
    unreadCount,
    loading,
    error,
    loadNotifications,
    markRead,
    markAllRead,
  } = useNotifications({ enabled });

  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const toggle = useCallback(async () => {
    const next = !open;
    setOpen(next);
    if (next) await loadNotifications();
  }, [open, loadNotifications]);

  const handleOpen = useCallback(
    async (notification: AppNotification) => {
      if (!notification.is_read) await markRead(notification.notification_id);
      if (isActionable(notification)) {
        onOpenApplication?.(notification.reference_id as string);
        setOpen(false);
      }
    },
    [markRead, onOpenApplication],
  );

  if (!enabled) return null;

  return (
    <div className={s.nbWrap} ref={wrapRef}>
      <button
        className={s.nbBtn}
        onClick={toggle}
        aria-label={
          unreadCount > 0
            ? `Notifications, ${unreadCount} unread`
            : "Notifications"
        }
        aria-expanded={open}
      >
        <svg
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {unreadCount > 0 && (
          <span className={s.nbDot}>
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className={s.nbPanel} role="dialog" aria-label="Notifications">
          <div className={s.nbPanelHead}>
            <span className={s.nbPanelTitle}>Notifications</span>
            {unreadCount > 0 && (
              <button className={s.nbMarkAll} onClick={markAllRead}>
                Mark all read
              </button>
            )}
          </div>

          {loading && <p className={s.nbEmpty}>Loading…</p>}
          {error && <p className={s.nbEmpty}>{error}</p>}

          {!loading && !error && notifications.length === 0 && (
            <p className={s.nbEmpty}>You&apos;re all caught up.</p>
          )}

          {notifications.map((notification) => (
            <button
              key={notification.notification_id}
              className={`${s.nbItem}${notification.is_read ? "" : ` ${s.nbItemUnread}`}`}
              onClick={() => handleOpen(notification)}
            >
              <span className={s.nbTitle}>{notification.title}</span>
              <span className={s.nbMsg}>{notification.message}</span>
              <span className={s.nbFoot}>
                <span className={s.nbTime}>
                  {relativeTime(notification.created_at)}
                </span>
                {isActionable(notification) && (
                  <span className={s.nbAction}>
                    Review
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="9 18 15 12 9 6" />
                    </svg>
                  </span>
                )}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
