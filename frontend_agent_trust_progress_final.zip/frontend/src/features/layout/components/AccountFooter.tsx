import { AUTH_ROLES, ROUTES } from "@/config";
import { User, UserRole } from "@/types";
import { Dispatch, useEffect, useState } from "react";
import styles from "@/styles/common.module.css";
import { useRouter } from "next/navigation";

interface Props {
  actingRole: UserRole;
  setActingRole: Dispatch<React.SetStateAction<UserRole>>;
  user: User | null;
}

export default function AccountFooter({
  actingRole,
  setActingRole,
  user,
}: Props) {
  const router = useRouter();
  const [acctMenuOpen, setAcctMenuOpen] = useState(false);

  const actualRole = user?.role?.toLocaleLowerCase() as UserRole;
  const canSwitchRole =
    actualRole === AUTH_ROLES.ADMIN ||
    actualRole === (AUTH_ROLES.SUPER_ADMIN as UserRole);

  const userInitials =
    (user?.display_name ?? "U")
      .split(" ")
      .map((w: string) => w[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "U";

  useEffect(() => {
    if (!acctMenuOpen) return;
    const handler = () => setAcctMenuOpen(false);
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, [acctMenuOpen]);

  const isAdminView = actingRole === actualRole;

  const displayName = isAdminView ? "Admin Panel" : user?.display_name;

  const displaySubText = isAdminView
    ? actualRole === AUTH_ROLES.SUPER_ADMIN
      ? "Super Admin"
      : "Admin"
    : user?.email;

  return (
    <div
      className={`${styles.sideFoot}${acctMenuOpen ? ` ${styles.open}` : ""}`}
    >
      {/* Popover menu */}

      <div className={styles.acctMenu} role="menu">
        {/* Logged In User */}
        <button
          className={styles.acctRow}
          role="menuitem"
          onClick={() => {
            setActingRole?.(AUTH_ROLES.USER as UserRole);
            setAcctMenuOpen(false);
            router.push(ROUTES.HOME);
            // onNewChat();
          }}
        >
          <span className={`${styles.uAvatar} ${styles.sm}`}>
            {userInitials}
          </span>
          <span className={styles.acctRowMeta}>
            <span className={styles.arName}>{user?.display_name}</span>
            <span className={styles.arRole}>{user?.email}</span>
          </span>

          {actingRole === AUTH_ROLES.USER && (
            <span className={styles.acctCheck}>
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </span>
          )}
        </button>

        {/* Admin Panel */}
        {canSwitchRole && (
          <button
            className={styles.acctRow}
            role="menuitem"
            onClick={() => {
              setActingRole?.(actualRole as UserRole);
              setAcctMenuOpen(false);
              router.push(ROUTES.CONFIG);
              // onHome();
            }}
          >
            <span className={`${styles.uAvatar} ${styles.sm}`}>
              {userInitials}
            </span>
            <span className={styles.acctRowMeta}>
              <span className={styles.arName}>Admin Panel</span>
              <span className={styles.arRole}>
                {actualRole === AUTH_ROLES.SUPER_ADMIN
                  ? "Super Admin"
                  : "Admin"}
              </span>
            </span>

            {actingRole === actualRole && (
              <span className={styles.acctCheck}>
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </span>
            )}
          </button>
        )}
      </div>

      {/* Trigger button */}
      <button
        className={styles.acctBtn}
        onClick={(e: React.MouseEvent) => {
          e.stopPropagation();
          setAcctMenuOpen((o: boolean) => !o);
        }}
        aria-haspopup="menu"
        aria-expanded={acctMenuOpen}
      >
        <div className={styles.uAvatar}>{userInitials}</div>
        <div className={styles.uMeta}>
          <div className={styles.uName}>{displayName}</div>
          <div className={styles.uPlan}>{displaySubText}</div>
        </div>
        <svg
          className={styles.acctCaret}
          width="14"
          height="14"
          viewBox="0 0 256 256"
          fill="currentColor"
        >
          <path d="M181.66,170.34a8,8,0,0,1,0,11.32l-48,48a8,8,0,0,1-11.32,0l-48-48a8,8,0,0,1,11.32-11.32L128,212.69l42.34-42.35A8,8,0,0,1,181.66,170.34Zm-96-84.68L128,43.31l42.34,42.35a8,8,0,0,0,11.32-11.32l-48-48a8,8,0,0,0-11.32,0l-48,48A8,8,0,0,0,85.66,85.66Z" />
        </svg>
      </button>
    </div>
  );
}
