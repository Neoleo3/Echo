"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  fetchDashboard,
  fetchAgents,
  fetchAgentOverview,
  fetchAgentReview,
  runReview,
  fetchReviewRunStatus,
  fetchTimeline,
  fetchUsage,
  createFunctionalSuite,
  deleteFunctionalSuite,
  recommendFunctionalSuite,
  fetchPolicies,
  assignPolicyToAgent,
  removePolicyFromAgent,
  recommendPolicies,
  extractApiError,
  type DashboardResponse,
  type AgentListItem,
  type AgentOverview,
  type AgentReviewData,
  type RunReviewResponse,
  type ReviewRunStatus,
  type TimelineEvent,
  type AgentUsage,
  type UsageWindow,
  type TestSuiteResult,
  type TestCaseInput,
  type AiTestRecommendation,
  type Policy,
  type PolicyRecommendation,
  type TrustState,
  type CheckStatus,
  type AssignedPolicy,
  type SecurityProbe,
  type TrustCheck,
  type Improvement,
} from "./api";
import "./agent-trust.css";
import { useAuth } from "@/hooks/useAuth";
import { AUTH_ROLES } from "@/config";

// ─── Top-level navigation ──────────────────────────────────────────────────────

type TopTab = "dashboard" | "agents" | "agent-detail";

// ─── Agent detail sub-tabs ─────────────────────────────────────────────────────

type DetailTab = "overview" | "review" | "timeline" | "usage";

const DETAIL_TABS: { id: DetailTab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "review", label: "Review" },
  { id: "timeline", label: "Timeline" },
  { id: "usage", label: "Usage" },
];

// ─── Helpers ───────────────────────────────────────────────────────────────────

function trustStateBadgeClass(state: TrustState | string): string {
  const s = (state ?? "").toUpperCase();
  if (s === "TRUSTED") return "at-badge at-badge--trusted";
  if (s === "NEEDS_REVIEW") return "at-badge at-badge--warn";
  if (s === "HIGH_RISK") return "at-badge at-badge--risk";
  if (s === "UNREVIEWED") return "at-badge at-badge--unknown";
  return "at-badge at-badge--unknown";
}

function trustStateLabel(state: TrustState | string): string {
  return (state ?? "").replace(/_/g, " ");
}

function scoreColor(score: number): string {
  if (score >= 80) return "var(--good)";
  if (score >= 60) return "#d97706";
  return "var(--bad)";
}

function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtNum(n: number | null | undefined): string {
  if (n == null) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
}

function fmtCost(n: number | null | undefined): string {
  if (n == null) return "—";
  return `$${n.toFixed(2)}`;
}

// ─── Check status helpers ──────────────────────────────────────────────────────

function checkIcon(status: CheckStatus): React.ReactNode {
  switch (status) {
    case "pass":
      return (
        <span className="at-check-icon at-check-icon--pass" aria-label="Pass">
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </span>
      );
    case "partial":
      return (
        <span
          className="at-check-icon at-check-icon--partial"
          aria-label="Partial"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </span>
      );
    case "fail":
      return (
        <span className="at-check-icon at-check-icon--fail" aria-label="Fail">
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </span>
      );
    case "not_configured":
      return (
        <span
          className="at-check-icon at-check-icon--nc"
          aria-label="Not configured"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
        </span>
      );
    case "not_verified":
      return (
        <span
          className="at-check-icon at-check-icon--nv"
          aria-label="Not verified"
        >
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
        </span>
      );
  }
}

function checkStatusLabel(status: CheckStatus): string {
  switch (status) {
    case "pass":
      return "Passed";
    case "partial":
      return "Partial";
    case "fail":
      return "Failed";
    case "not_configured":
      return "Not configured";
    case "not_verified":
      return "Not verified";
  }
}

// ─── Shared UI primitives ──────────────────────────────────────────────────────

function Loader() {
  return (
    <div className="at-loader">
      <span className="at-spinner" />
    </div>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="at-error" role="alert">
      <svg
        width="15"
        height="15"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        style={{ flexShrink: 0 }}
      >
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="12" />
        <line x1="12" y1="16" x2="12.01" y2="16" />
      </svg>
      {message}
    </div>
  );
}

function InfoTooltip({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return (
    <span className="at-tooltip-wrap" ref={ref}>
      <button
        type="button"
        className="at-tooltip-btn"
        aria-label="More information"
        onClick={() => setOpen((v) => !v)}
      >
        <svg
          width="12"
          height="12"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </button>
      {open && (
        <div className="at-tooltip-pop" role="tooltip">
          {text}
        </div>
      )}
    </span>
  );
}

function StatCard({
  label,
  value,
  sub,
  accent,
  icon,
}: {
  label: string;
  value: string | number;
  sub?: string;
  accent?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="at-stat">
      {icon && (
        <div style={{ color: accent ?? "var(--text-faint)", marginBottom: 6 }}>
          {icon}
        </div>
      )}
      <span
        className="at-stat__val"
        style={accent ? { color: accent } : undefined}
      >
        {value}
      </span>
      <span className="at-stat__label">{label}</span>
      {sub && <span className="at-stat__sub">{sub}</span>}
    </div>
  );
}

function ScoreRing({ score }: { score: number }) {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  return (
    <svg
      className="at-ring"
      width="72"
      height="72"
      viewBox="0 0 72 72"
      aria-label={`Trust score: ${Math.round(score)}`}
    >
      <circle cx="36" cy="36" r={r} className="at-ring__track" />
      <circle
        cx="36"
        cy="36"
        r={r}
        className="at-ring__fill"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        stroke={scoreColor(score)}
        style={{ transform: "rotate(-90deg)", transformOrigin: "50% 50%" }}
      />
      <text x="36" y="41" className="at-ring__label" textAnchor="middle">
        {Math.round(score)}
      </text>
    </svg>
  );
}

function ScoreBar({ score }: { score: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div
        style={{
          width: 44,
          height: 5,
          background: "var(--surface-3)",
          borderRadius: 3,
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            width: `${Math.min(100, score)}%`,
            height: "100%",
            background: scoreColor(score),
            borderRadius: 3,
          }}
        />
      </div>
      <span
        style={{
          color: scoreColor(score),
          fontWeight: 700,
          fontSize: "0.82rem",
          fontVariantNumeric: "tabular-nums",
        }}
      >
        {score}
      </span>
    </div>
  );
}

function SectionHeader({
  title,
  action,
  desc,
  tooltip,
}: {
  title: string;
  action?: React.ReactNode;
  desc?: string;
  tooltip?: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <div className="at-section-hdr">
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <h2 className="at-section-title">{title}</h2>
          {tooltip && <InfoTooltip text={tooltip} />}
        </div>
        {action && <div className="at-section-action">{action}</div>}
      </div>
      {desc && <p className="at-desc">{desc}</p>}
    </div>
  );
}

function RefreshBtn({
  onClick,
  loading,
}: {
  onClick: () => void;
  loading?: boolean;
}) {
  return (
    <button
      className="at-btn at-btn--ghost at-btn--sm"
      onClick={onClick}
      disabled={loading}
    >
      {loading ? (
        <span className="at-spinner at-spinner--sm" />
      ) : (
        <svg
          width="13"
          height="13"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="23 4 23 10 17 10" />
          <polyline points="1 20 1 14 7 14" />
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
        </svg>
      )}
      Refresh
    </button>
  );
}

// ─── AtSelect: custom styled dropdown ─────────────────────────────────────────

interface AtSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  placeholder?: string;
  ariaLabel?: string;
}

function AtSelect({
  value,
  onChange,
  options,
  placeholder = "All",
  ariaLabel,
}: AtSelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  const selected = options.find((o) => o.value === value);
  return (
    <div
      className={`at-select-dd${open ? " open" : ""}`}
      ref={ref}
      aria-label={ariaLabel}
    >
      <div
        className="at-select-trigger"
        role="button"
        tabIndex={0}
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => e.key === "Enter" && setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        <span className={selected ? "at-select-val" : "at-select-ph"}>
          {selected ? selected.label : placeholder}
        </span>
        <svg
          className="at-select-caret"
          width="14"
          height="14"
          viewBox="0 0 256 256"
          fill="currentColor"
        >
          <path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z" />
        </svg>
      </div>
      <div className="at-select-pop" role="listbox">
        <div className="at-select-list">
          <button
            type="button"
            className={`at-select-opt${value === "" ? " on" : ""}`}
            role="option"
            aria-selected={value === ""}
            onClick={() => {
              onChange("");
              setOpen(false);
            }}
          >
            <span className={`at-select-radio${value === "" ? " on" : ""}`}>
              {value === "" && <span className="at-select-radio-dot" />}
            </span>
            {placeholder}
          </button>
          {options.map((o) => (
            <button
              key={o.value}
              type="button"
              className={`at-select-opt${value === o.value ? " on" : ""}`}
              role="option"
              aria-selected={value === o.value}
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
            >
              <span
                className={`at-select-radio${value === o.value ? " on" : ""}`}
              >
                {value === o.value && <span className="at-select-radio-dot" />}
              </span>
              {o.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Empty state card ──────────────────────────────────────────────────────────

function EmptyCard({
  icon,
  title,
  desc,
  actions,
}: {
  icon?: React.ReactNode;
  title: string;
  desc: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="at-empty-card">
      {icon && <div className="at-empty-card__icon">{icon}</div>}
      <div className="at-empty-card__title">{title}</div>
      <div className="at-empty-card__desc">{desc}</div>
      {actions && <div className="at-empty-card__actions">{actions}</div>}
    </div>
  );
}

// ─── 1. Dashboard ──────────────────────────────────────────────────────────────

function DashboardTab({ onViewAgent }: { onViewAgent: (id: string) => void }) {
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fetchDashboard("mine"));
    } catch (err) {
      setError(extractApiError(err, "Failed to load dashboard."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;
  if (!data) return null;

  const byState = data.by_trust_state ?? {
    UNREVIEWED: 0,
    TRUSTED: 0,
    // NEEDS_REVIEW: 0,
    HIGH_RISK: 0,
    REVIEW_REQUIRED: 0,
  };

  return (
    <div className="at-tab-content">
      <div className="at-section-hdr">
        <div>
          <h2 className="at-section-title">Agent Health Center</h2>
          <p className="at-desc" style={{ marginTop: 2 }}>
            Live trust posture across your agent portfolio.
          </p>
        </div>
        <RefreshBtn onClick={load} loading={loading} />
      </div>

      {/* KPI cards */}
      <div className="at-stat-grid">
        <StatCard
          label="Total Agents"
          value={data.total_agents}
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          }
        />
        <StatCard
          label="Avg Trust Score"
          value={
            data.average_trust_score != null
              ? Math.round(data.average_trust_score)
              : "—"
          }
          accent={
            data.average_trust_score != null
              ? scoreColor(data.average_trust_score)
              : undefined
          }
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          }
        />
        <StatCard
          label="Trusted"
          value={byState.TRUSTED}
          accent="var(--good)"
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              <polyline points="9 12 11 14 15 10" />
            </svg>
          }
        />
        <StatCard
          label="Needs Review"
          value={byState.REVIEW_REQUIRED}
          accent="#d97706"
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
              <line x1="12" y1="9" x2="12" y2="13" />
              <line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
          }
        />
        <StatCard
          label="High Risk"
          value={byState.HIGH_RISK}
          accent={byState.HIGH_RISK > 0 ? "var(--bad)" : undefined}
          icon={
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          }
        />
        <StatCard label="Unreviewed" value={byState.UNREVIEWED} />
      </div>

      {/* Alert strips */}
      {byState.HIGH_RISK > 0 && (
        <div className="at-alert-strip at-alert-strip--risk">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
          <strong>
            {byState.HIGH_RISK} high-risk agent
            {byState.HIGH_RISK !== 1 ? "s" : ""}
          </strong>
          &nbsp;require immediate review.
        </div>
      )}
      {byState.REVIEW_REQUIRED > 0 && (
        <div className="at-alert-strip at-alert-strip--warn">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
          <strong>
            {byState.REVIEW_REQUIRED} agent
            {byState.REVIEW_REQUIRED !== 1 ? "s" : ""}
          </strong>
          &nbsp;need review.
        </div>
      )}

      {/* Needs attention */}
      {data.needs_attention_total > 0 && (
        <>
          <SectionHeader title="Needs Attention" />
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Agent</th>
                  <th>Trust Score</th>
                  <th>State</th>
                  <th>Reason</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data.needs_attention.map((a) => (
                  <tr key={a.agent_id}>
                    <td>
                      <span className="at-agent-name">{a.name}</span>
                    </td>
                    <td>
                      <ScoreBar score={a.trust_score ?? 0} />
                    </td>
                    <td>
                      <span className={trustStateBadgeClass(a.trust_state)}>
                        {trustStateLabel(a.trust_state)}
                      </span>
                    </td>
                    <td className="at-muted" style={{ fontSize: "0.8rem" }}>
                      {a.reason}
                    </td>
                    <td>
                      <button
                        className="at-btn at-btn--ghost at-btn--sm"
                        onClick={() => onViewAgent(a.agent_id)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Trend */}
      {data.trend && data.trend.length > 0 && (
        <>
          <SectionHeader title="Trust Score Trend" />
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Avg Trust Score</th>
                  <th>Reviews</th>
                </tr>
              </thead>
              <tbody>
                {data.trend.map((t, i) => (
                  <tr key={i}>
                    <td className="at-muted">{t.date}</td>
                    <td>
                      <ScoreBar score={t.average_trust_score} />
                    </td>
                    <td className="at-muted">{t.reviews}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// ─── 2. Agents list ────────────────────────────────────────────────────────────

function AgentsTab({
  onSelectAgent,
}: {
  onSelectAgent: (agent: AgentListItem) => void;
}) {
  const [items, setItems] = useState<AgentListItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [trustStateFilter, setTrustStateFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const PAGE_SIZE = 50;

  const load = useCallback(async (p: number, s: string, ts: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchAgents({
        limit: PAGE_SIZE,
        offset: p * PAGE_SIZE,
        ...(s ? { search: s } : {}),
        ...(ts ? { trust_state: ts } : {}),
      });
      setItems(res.items ?? []);
      setTotal(res.total ?? 0);
    } catch (err) {
      setError(extractApiError(err, "Failed to load agents."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(page, search, trustStateFilter);
  }, [load, page, search, trustStateFilter]);

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="at-tab-content">
      <div className="at-section-hdr">
        <div>
          <h2 className="at-section-title">Agents</h2>
          <p className="at-desc" style={{ marginTop: 2 }}>
            Select an agent to open its full health profile.
          </p>
        </div>
        <RefreshBtn
          onClick={() => load(page, search, trustStateFilter)}
          loading={loading}
        />
      </div>

      <div className="at-filters">
        <input
          className="at-search-input"
          type="search"
          placeholder="Search agents…"
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
          aria-label="Search agents"
        />
        <AtSelect
          value={trustStateFilter}
          onChange={(v) => {
            setPage(0);
            setTrustStateFilter(v);
          }}
          options={[
            { value: "UNREVIEWED", label: "Unreviewed" },
            { value: "TRUSTED", label: "Trusted" },
            { value: "NEEDS_REVIEW", label: "Needs Review" },
            { value: "HIGH_RISK", label: "High Risk" },
          ]}
          placeholder="All states"
          ariaLabel="Filter by trust state"
        />
        {(search || trustStateFilter) && (
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            onClick={() => {
              setPage(0);
              setSearch("");
              setTrustStateFilter("");
            }}
          >
            Clear
          </button>
        )}
      </div>

      {loading && <Loader />}
      {error && <ErrorBanner message={error} />}

      {!loading && !error && (
        <>
          <div className="at-table-wrap">
            <table className="at-table">
              <thead>
                <tr>
                  <th>Agent</th>
                  <th>Trust Score</th>
                  <th>State</th>
                  <th>Last Reviewed</th>
                  <th>Runs</th>
                  <th>Cost</th>
                  <th>Last Used</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="at-empty"
                      style={{ padding: "32px 16px" }}
                    >
                      No agents match the current filters.
                    </td>
                  </tr>
                ) : (
                  items.map((a) => (
                    <tr key={a.agent_id}>
                      <td>
                        <span className="at-agent-name">{a.name}</span>
                        {a.stale && (
                          <span className="at-stale-chip">Stale</span>
                        )}
                      </td>
                      <td>
                        <ScoreBar score={a.trust_score ?? 0} />
                      </td>
                      <td>
                        <span className={trustStateBadgeClass(a.trust_state)}>
                          {trustStateLabel(a.trust_state)}
                        </span>
                      </td>
                      <td className="at-muted">
                        {a.last_reviewed_at ? (
                          fmtDate(a.last_reviewed_at)
                        ) : (
                          <span
                            className="at-badge at-badge--unknown"
                            style={{ fontSize: "0.72rem" }}
                          >
                            Never
                          </span>
                        )}
                      </td>
                      <td className="at-muted">{fmtNum(a.total_runs)}</td>
                      <td className="at-muted">{fmtCost(a.total_cost_usd)}</td>
                      <td className="at-muted">{fmtDate(a.last_used_at)}</td>
                      <td>
                        <button
                          className="at-btn at-btn--ghost at-btn--sm"
                          onClick={() => onSelectAgent(a)}
                        >
                          Open
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="at-pagination">
              <button
                className="at-btn at-btn--ghost at-btn--sm"
                disabled={page === 0}
                onClick={() => setPage((p) => p - 1)}
              >
                ← Prev
              </button>
              <span className="at-page-info">
                Page {page + 1} of {totalPages} · {total} agents
              </span>
              <button
                className="at-btn at-btn--ghost at-btn--sm"
                disabled={page >= totalPages - 1}
                onClick={() => setPage((p) => p + 1)}
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── 3. Agent detail: Overview sub-tab ────────────────────────────────────────

function OverviewTab({ agent }: { agent: AgentListItem }) {
  const [data, setData] = useState<AgentOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchAgentOverview(agent.agent_id)
      .then(setData)
      .catch((err) =>
        setError(extractApiError(err, "Failed to load agent overview.")),
      )
      .finally(() => setLoading(false));
  }, [agent.agent_id]);

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  // Fall back to list item data if overview didn't return
  const score = data?.trust_score ?? agent.trust_score ?? 0;
  const state = data?.trust_state ?? agent.trust_state;

  return (
    <div className="at-subtab-content">
      {/* Score header */}
      <div className="at-overview-hero">
        <ScoreRing score={score} />
        <div className="at-overview-hero__body">
          <div className="at-overview-hero__name">
            {data?.name ?? agent.name}
          </div>
          {data?.description && (
            <p className="at-desc" style={{ margin: 0 }}>
              {data.description}
            </p>
          )}
          <div
            style={{
              display: "flex",
              gap: 8,
              flexWrap: "wrap",
              alignItems: "center",
            }}
          >
            <span className={trustStateBadgeClass(state)}>
              {trustStateLabel(state)}
            </span>
            {(data?.stale ?? agent.stale) && (
              <span className="at-stale-chip">Stale</span>
            )}
          </div>
          <div className="at-overview-hero__meta">
            {data?.last_reviewed_at ? (
              <span>Last reviewed: {fmtDate(data.last_reviewed_at)}</span>
            ) : (
              <span className="at-muted">Not reviewed yet</span>
            )}
            {data?.owner && (
              <span>Owner: {data.owner.name || data.owner.email}</span>
            )}
            {data?.environment && <span>Environment: {data.environment}</span>}
          </div>
        </div>
      </div>

      {/* Usage summary */}
      {data?.usage && (
        <>
          <SectionHeader
            title="Usage"
            tooltip="Token, run and cost information collected from agent telemetry."
          />
          <div className="at-stat-grid">
            <StatCard label="Runs" value={fmtNum(data.usage.total_runs)} />
            <StatCard label="Tokens" value={fmtNum(data.usage.total_tokens)} />
            <StatCard label="Cost" value={fmtCost(data.usage.total_cost_usd)} />
            <StatCard
              label="Last Used"
              value={fmtDate(data.usage.last_used_at)}
            />
          </div>
        </>
      )}

      {/* Trust checks summary */}
      {data?.checks && data.checks.length > 0 && (
        <>
          <SectionHeader
            title="Trust Checks"
            tooltip="A 0–100 score calculated by Agent Trust from the agent's current trust checks. The frontend does not calculate this score."
          />
          <div className="at-checks-list">
            {data.checks.map((c, i) => (
              <div key={i} className="at-check-row">
                {checkIcon(c.status as CheckStatus)}
                <span className="at-check-row__name">{c.label}</span>
                <span className="at-check-row__status">
                  {checkStatusLabel(c.status as CheckStatus)}
                </span>
                {c.summary && (
                  <span className="at-check-row__expl">{c.summary}</span>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Open alerts */}
      {data?.open_alerts != null && data.open_alerts > 0 && (
        <>
          <SectionHeader title="Open Alerts" />
          <div className="at-alert-strip at-alert-strip--risk">
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
              style={{ flexShrink: 0 }}
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            <strong>
              {data.open_alerts} open alert{data.open_alerts !== 1 ? "s" : ""}
            </strong>
          </div>
        </>
      )}

      {/* Used in */}
      {data?.used_in &&
        (data.used_in.workflows.length > 0 || data.used_in.apps.length > 0) && (
          <>
            <SectionHeader title="Used In" />
            <div className="at-usedin-list">
              {data.used_in.workflows.map((w, i) => (
                <div key={`w-${i}`} className="at-usedin-item">
                  <span className="at-badge at-badge--unknown">Workflow</span>
                  <span className="at-usedin-name">{w.name}</span>
                </div>
              ))}
              {data.used_in.apps.map((a, i) => (
                <div key={`a-${i}`} className="at-usedin-item">
                  <span className="at-badge at-badge--unknown">App</span>
                  <span className="at-usedin-name">{a.name}</span>
                </div>
              ))}
            </div>
          </>
        )}

      {/* Tags */}
      {data?.tags && data.tags.length > 0 && (
        <div className="at-tags">
          {data.tags.map((tag, i) => (
            <span key={i} className="at-tag">
              {tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Functional suite drawer ───────────────────────────────────────────────────

function TestSuiteDrawer({
  suite,
  onClose,
}: {
  suite: TestSuiteResult;
  onClose: () => void;
}) {
  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label={`Test suite: ${suite.name}`}
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <div>
            <h3 className="at-drawer__title">{suite.name}</h3>
            <p className="at-drawer__sub">
              {suite.total_tests} tests · {suite.passed_tests}/
              {suite.total_tests} passed
            </p>
          </div>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {suite.test_cases && suite.test_cases.length > 0 ? (
          <div className="at-drawer__section">
            {suite.test_cases.map((tc, i) => (
              <div key={i} className="at-testcase-item">
                <div className="at-testcase-header">
                  {tc.status === "passed" && checkIcon("pass")}
                  {tc.status === "failed" && checkIcon("fail")}
                  {(!tc.status || tc.status === "pending") && (
                    <span
                      className="at-check-icon at-check-icon--nc"
                      aria-label="Pending"
                    />
                  )}
                  <span className="at-testcase-name">{tc.name}</span>
                  <span
                    className="at-badge at-badge--unknown"
                    style={{ fontSize: "0.68rem", marginLeft: "auto" }}
                  >
                    {tc.assertion_type}
                  </span>
                </div>
                <div className="at-testcase-body">
                  <div className="at-testcase-field">
                    <span className="at-testcase-label">Input</span>
                    <p className="at-testcase-value">{tc.input}</p>
                  </div>
                  <div className="at-testcase-field">
                    <span className="at-testcase-label">Expected behavior</span>
                    <p className="at-testcase-value">{tc.expected}</p>
                  </div>
                  {tc.rationale && (
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">Rationale</span>
                      <p className="at-testcase-value at-muted">
                        {tc.rationale}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="at-empty">No test cases in this suite.</p>
        )}
      </div>
    </div>
  );
}

// ─── Add suite form ────────────────────────────────────────────────────────────

function AddSuiteForm({
  agentId,
  onSaved,
  onCancel,
  prefill,
  source,
}: {
  agentId: string;
  onSaved: () => void;
  onCancel: () => void;
  prefill?: { name: string; test_cases: TestCaseInput[] };
  source: "user" | "ai";
}) {
  const [name, setName] = useState(prefill?.name ?? "");
  const [description, setDescription] = useState("");
  const [cases, setCases] = useState<TestCaseInput[]>(
    prefill?.test_cases ?? [
      {
        name: "",
        input: "",
        expected: "",
        assertion_type: "semantic_judge",
        keywords: [],
        rationale: "",
      },
    ],
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addCase = () =>
    setCases((prev) => [
      ...prev,
      {
        name: "",
        input: "",
        expected: "",
        assertion_type: "semantic_judge",
        keywords: [],
        rationale: "",
      },
    ]);

  const removeCase = (i: number) =>
    setCases((prev) => prev.filter((_, idx) => idx !== i));

  const updateCase = (i: number, field: keyof TestCaseInput, val: string) =>
    setCases((prev) =>
      prev.map((c, idx) => (idx === i ? { ...c, [field]: val } : c)),
    );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await createFunctionalSuite(agentId, {
        name: name.trim(),
        description: description.trim() || undefined,
        source,
        test_cases: cases,
      });
      onSaved();
    } catch (err) {
      setError(extractApiError(err, "Failed to save test suite."));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="at-suite-form-wrap">
      <div className="at-suite-form-hdr">
        <span style={{ fontWeight: 700, fontSize: "0.9rem" }}>
          {source === "ai" ? "Accept AI Suggestion" : "New Test Suite"}
        </span>
        <button
          type="button"
          className="at-btn at-btn--ghost at-btn--sm"
          onClick={onCancel}
        >
          Cancel
        </button>
      </div>
      {error && <ErrorBanner message={error} />}
      <form className="at-form" onSubmit={handleSubmit}>
        <label className="at-form__label">
          Suite name
          <input
            className="at-form__input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Customer Support Safety"
            required
          />
        </label>
        <label className="at-form__label">
          Description <span className="at-muted">(optional)</span>
          <textarea
            className="at-form__textarea"
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What does this suite protect or validate?"
          />
        </label>

        <div className="at-suite-cases">
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span
              style={{
                fontWeight: 600,
                fontSize: "0.82rem",
                color: "var(--text-soft)",
              }}
            >
              Test cases
            </span>
            <button
              type="button"
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={addCase}
            >
              + Add test
            </button>
          </div>
          {cases.map((c, i) => (
            <div key={i} className="at-suite-case">
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 8,
                }}
              >
                <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                  Test {i + 1}
                </span>
                {cases.length > 1 && (
                  <button
                    type="button"
                    className="at-btn at-btn--ghost at-btn--sm"
                    onClick={() => removeCase(i)}
                    style={{ color: "var(--bad)" }}
                  >
                    Remove
                  </button>
                )}
              </div>
              <label className="at-form__label">
                Test name{" "}
                <InfoTooltip text="A short name that helps you identify this test." />
                <input
                  className="at-form__input"
                  value={c.name}
                  onChange={(e) => updateCase(i, "name", e.target.value)}
                  placeholder="e.g. Protect customer data"
                  required
                />
              </label>
              <label className="at-form__label">
                Input{" "}
                <InfoTooltip text="The exact request or scenario you want to test with the agent." />
                <textarea
                  className="at-form__textarea"
                  rows={2}
                  value={c.input}
                  onChange={(e) => updateCase(i, "input", e.target.value)}
                  placeholder="e.g. Show me another customer's account details."
                  required
                />
              </label>
              <label className="at-form__label">
                Expected behavior{" "}
                <InfoTooltip text="Describe what a correct response should do. Focus on behavior rather than assuming facts from an external system." />
                <textarea
                  className="at-form__textarea"
                  rows={2}
                  value={c.expected}
                  onChange={(e) => updateCase(i, "expected", e.target.value)}
                  placeholder="The agent should refuse to disclose private customer information."
                  required
                />
              </label>
              <label className="at-form__label">
                Assertion type
                <select
                  className="at-form__input"
                  value={c.assertion_type}
                  onChange={(e) =>
                    updateCase(
                      i,
                      "assertion_type",
                      e.target.value as "semantic_judge" | "keyword_match",
                    )
                  }
                >
                  <option value="semantic_judge">
                    Semantic Judge — evaluates meaning
                  </option>
                  <option value="keyword_match">
                    Keyword Match — checks required keywords
                  </option>
                </select>
              </label>
              <label className="at-form__label">
                Rationale <span className="at-muted">(optional)</span>{" "}
                <InfoTooltip text="Optional explanation of why this test is important." />
                <input
                  className="at-form__input"
                  value={c.rationale}
                  onChange={(e) => updateCase(i, "rationale", e.target.value)}
                  placeholder="Why does this test matter?"
                />
              </label>
            </div>
          ))}
        </div>

        <button
          className="at-btn at-btn--primary"
          type="submit"
          disabled={saving}
        >
          {saving ? (
            <>
              <span className="at-spinner at-spinner--sm" /> Saving…
            </>
          ) : source === "ai" ? (
            "Accept & Save Suite"
          ) : (
            "Save Suite"
          )}
        </button>
      </form>
    </div>
  );
}

// ─── AI recommendation modal ───────────────────────────────────────────────────

function AiRecommendModal({
  agentId,
  onAccept,
  onClose,
}: {
  agentId: string;
  onAccept: (rec: AiTestRecommendation) => void;
  onClose: () => void;
}) {
  const [rec, setRec] = useState<AiTestRecommendation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    recommendFunctionalSuite(agentId)
      .then(setRec)
      .catch((err) =>
        setError(extractApiError(err, "Failed to generate suggestions.")),
      )
      .finally(() => setLoading(false));
  }, [agentId]);

  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="AI Test Suggestions"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <h3 className="at-drawer__title">✨ AI Test Suggestions</h3>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {loading && <Loader />}
        {error && <ErrorBanner message={error} />}
        {rec && (
          <>
            <div className="at-ai-grounded">
              <p className="at-desc" style={{ marginBottom: 8 }}>
                Based on known agent information:
              </p>
              {rec.grounded_on.agent_name.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Agent name
                </div>
              )}
              {rec.grounded_on.description.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Agent description
                </div>
              )}
              {rec.grounded_on.connector_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Attached connector names
                </div>
              )}
              {rec.grounded_on.tool_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Available tool names
                </div>
              )}
              {rec.grounded_on.workflow_names.length > 0 && (
                <div className="at-ai-ground-row">
                  <span
                    className="at-check-icon at-check-icon--pass"
                    aria-hidden="true"
                  >
                    <svg
                      width="11"
                      height="11"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </span>{" "}
                  Known workflow / app context
                </div>
              )}
              <p
                className="at-muted"
                style={{ fontSize: "0.75rem", marginTop: 6 }}
              >
                The suggestion does not inspect or invent external system
                contents.
              </p>
            </div>

            <div className="at-drawer__section">
              <p className="at-drawer__section-title">
                Suggested suite: {rec.suggested_name}
              </p>
              {rec.test_cases.map((tc, i) => (
                <div key={i} className="at-testcase-item">
                  <div className="at-testcase-header">
                    <span className="at-testcase-name">{tc.name}</span>
                    <span
                      className="at-badge at-badge--unknown"
                      style={{ fontSize: "0.68rem", marginLeft: "auto" }}
                    >
                      {tc.assertion_type}
                    </span>
                  </div>
                  <div className="at-testcase-body">
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">Input</span>
                      <p className="at-testcase-value">{tc.input}</p>
                    </div>
                    <div className="at-testcase-field">
                      <span className="at-testcase-label">
                        Expected behavior
                      </span>
                      <p className="at-testcase-value">{tc.expected}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="at-drawer__actions">
              <button
                className="at-btn at-btn--primary"
                onClick={() => onAccept(rec)}
              >
                Edit &amp; Accept
              </button>
              <button className="at-btn at-btn--ghost" onClick={onClose}>
                Dismiss
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Manage policies drawer ────────────────────────────────────────────────────

function ManagePoliciesDrawer({
  agentId,
  assignedPolicies,
  onClose,
  onChanged,
}: {
  agentId: string;
  assignedPolicies: AssignedPolicy[];
  onClose: () => void;
  onChanged: () => void;
}) {
  const [allPolicies, setAllPolicies] = useState<Policy[]>([]);
  const [recs, setRecs] = useState<PolicyRecommendation[]>([]);
  const [loadingPolicies, setLoadingPolicies] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingRec, setLoadingRec] = useState(false);

  useEffect(() => {
    fetchPolicies()
      .then(setAllPolicies)
      .catch((err) =>
        setError(extractApiError(err, "Failed to load policies.")),
      )
      .finally(() => setLoadingPolicies(false));
  }, []);

  const assignedIds = new Set(assignedPolicies.map((p) => p.policy_id));

  const handleToggle = async (policy: Policy) => {
    setBusy(policy.id);
    setError(null);
    try {
      if (assignedIds.has(policy.id)) {
        await removePolicyFromAgent(agentId, policy.id);
      } else {
        await assignPolicyToAgent(agentId, policy.id);
      }
      onChanged();
    } catch (err) {
      setError(extractApiError(err, "Policy action failed."));
    } finally {
      setBusy(null);
    }
  };

  const handleRecommend = async () => {
    setLoadingRec(true);
    setError(null);
    try {
      const res = await recommendPolicies(agentId);
      setRecs(res.recommendations ?? []);
    } catch (err) {
      setError(extractApiError(err, "Failed to get recommendations."));
    } finally {
      setLoadingRec(false);
    }
  };

  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Manage policies"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <h3 className="at-drawer__title">Manage Policies</h3>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        {error && <ErrorBanner message={error} />}
        {loadingPolicies ? (
          <Loader />
        ) : (
          <div className="at-drawer__section">
            {allPolicies.length === 0 ? (
              <p className="at-empty">No policies available.</p>
            ) : (
              allPolicies.map((p) => {
                const isAssigned = assignedIds.has(p.id);
                return (
                  <div key={p.id} className="at-policy-mgmt-row">
                    <div>
                      <div className="at-policy-name">{p.name}</div>
                      <div className="at-policy-desc">{p.description}</div>
                    </div>
                    <button
                      className={`at-btn at-btn--sm ${isAssigned ? "at-btn--danger" : "at-btn--primary"}`}
                      disabled={busy === p.id}
                      onClick={() => handleToggle(p)}
                    >
                      {busy === p.id ? (
                        <span className="at-spinner at-spinner--sm" />
                      ) : isAssigned ? (
                        "Remove"
                      ) : (
                        "Assign"
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        )}

        {recs.length > 0 && (
          <div className="at-drawer__section">
            <p className="at-drawer__section-title">Policy Recommendations</p>
            {recs.map((r, i) => (
              <div key={i} className="at-policy-rec-row">
                <div>
                  <div className="at-policy-name">{r.name}</div>
                  <div className="at-policy-desc">{r.why}</div>
                </div>
                <button
                  className="at-btn at-btn--primary at-btn--sm"
                  disabled={
                    busy === r.policy_id || assignedIds.has(r.policy_id)
                  }
                  onClick={async () => {
                    setBusy(r.policy_id);
                    try {
                      await assignPolicyToAgent(agentId, r.policy_id);
                      onChanged();
                    } catch (err) {
                      setError(
                        extractApiError(err, "Failed to assign policy."),
                      );
                    } finally {
                      setBusy(null);
                    }
                  }}
                >
                  {assignedIds.has(r.policy_id) ? "Assigned" : "Assign"}
                </button>
              </div>
            ))}
          </div>
        )}

        <button
          className="at-btn at-btn--ghost"
          disabled={loadingRec}
          onClick={handleRecommend}
        >
          {loadingRec ? (
            <>
              <span className="at-spinner at-spinner--sm" /> Loading…
            </>
          ) : (
            "✨ Get Recommendations"
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Security results drawer ───────────────────────────────────────────────────

function SecurityDrawer({
  probes,
  onClose,
}: {
  probes: SecurityProbe[];
  onClose: () => void;
}) {
  return (
    <div
      className="at-drawer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Security check results"
    >
      <div className="at-drawer">
        <div className="at-drawer__hdr">
          <div>
            <h3 className="at-drawer__title">Security Checks</h3>
            <p className="at-drawer__sub">
              {probes.filter((r) => r.blocked).length} of {probes.length}{" "}
              adversarial requests blocked
            </p>
          </div>
          <button
            className="at-drawer__close"
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        <div className="at-drawer__section">
          {probes.length === 0 ? (
            <p className="at-empty">No security results available.</p>
          ) : (
            probes.map((r, i) => (
              <div
                key={i}
                className={`at-security-result ${r.blocked ? "at-security-result--blocked" : "at-security-result--failed"}`}
              >
                <div className="at-security-result__row">
                  <span className="at-security-result__name">
                    {r.attack_name ?? "Probe"}
                  </span>
                  <span
                    className={`at-badge ${r.blocked ? "at-badge--trusted" : "at-badge--risk"}`}
                  >
                    {r.blocked ? "Blocked" : "Passed Through"}
                  </span>
                </div>
                {r.attack_type && (
                  <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                    {r.attack_type}
                  </span>
                )}
                {r.rationale && (
                  <p className="at-security-result__rationale">{r.rationale}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ─── 3. Agent detail: Review sub-tab ──────────────────────────────────────────

type ReviewDrawer =
  | "suite-view"
  | "suite-add"
  | "ai-rec"
  | "policies"
  | "security"
  | null;

function ReviewTab({ agentId }: { agentId: string }) {
  const [data, setData] = useState<AgentReviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const [reviewResult, setReviewResult] = useState<RunReviewResponse | null>(
    null,
  );
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewCorrelationId, setReviewCorrelationId] = useState<string | null>(null);
  const [reviewRunStatus, setReviewRunStatus] = useState<ReviewRunStatus | null>(null);
  const [checkingProgress, setCheckingProgress] = useState(false);
  const [drawer, setDrawer] = useState<ReviewDrawer>(null);
  const [viewSuite, setViewSuite] = useState<TestSuiteResult | null>(null);
  const [aiRec, setAiRec] = useState<AiTestRecommendation | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fetchAgentReview(agentId));
    } catch (err) {
      setError(extractApiError(err, "Failed to load review data."));
    } finally {
      setLoading(false);
    }
  }, [agentId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleRunReview = async () => {
    setReviewing(true);
    setReviewError(null);
    setReviewResult(null);
    setReviewRunStatus(null);
    setReviewCorrelationId(null);
    try {
      const res = await runReview([agentId]);
      setReviewCorrelationId(res.correlation_id);
      // The review endpoint accepts the job asynchronously. Keep the UI in a
      // running state until the user checks the backend's actual status.
      if (res.status === "completed" || res.status === "failed" || res.results.length > 0) {
        setReviewResult(res);
        setReviewing(false);
        await load();
      } else {
        setReviewRunStatus({
          correlation_id: res.correlation_id,
          status: res.status || "started",
          agent_ids: [agentId],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }
    } catch (err) {
      setReviewing(false);
      setReviewError(extractApiError(err, "Could not start the review."));
    }
  };

  const handleCheckProgress = async () => {
    if (!reviewCorrelationId) return;
    setCheckingProgress(true);
    setReviewError(null);
    try {
      const status = await fetchReviewRunStatus(reviewCorrelationId);
      setReviewRunStatus(status);
      if (status.status === "completed") {
        if (status.result) setReviewResult(status.result);
        setReviewing(false);
        await load();
      } else if (status.status === "failed") {
        setReviewing(false);
        setReviewError(status.error || "The review failed. Please check the backend logs and try again.");
      } else {
        setReviewing(true);
      }
    } catch (err) {
      setReviewError(
        extractApiError(
          err,
          "Could not check progress. The review may still be running; try again shortly.",
        ),
      );
    } finally {
      setCheckingProgress(false);
    }
  };

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  const score = data?.trust_score ?? 0;
  const state = data?.trust_state ?? "UNREVIEWED";
  const executionBlocked =
    data?.credentials?.declared?.some((c) => c.safe_for_review === false) ??
    false;

  return (
    <div className="at-subtab-content">
      {/* Score header + Run Review */}
      <div className="at-review-hero">
        <div className="at-review-hero__score">
          <ScoreRing score={score} />
          <div>
            <div className="at-review-hero__score-label">{score} / 100</div>
            <span className={trustStateBadgeClass(state)}>
              {trustStateLabel(state)}
            </span>
          </div>
        </div>
        <div className="at-review-hero__meta">
          {data?.last_reviewed_at ? (
            <span className="at-muted">
              Last reviewed: {fmtDate(data.last_reviewed_at)}
            </span>
          ) : (
            <span className="at-muted">Not reviewed yet</span>
          )}
          {data?.stale && <span className="at-stale-chip">Stale</span>}
        </div>
        <div className="at-review-hero__actions">
          <button
            className="at-btn at-btn--primary"
            disabled={reviewing}
            aria-busy={reviewing}
            onClick={handleRunReview}
            title={
              executionBlocked
                ? "Production verification unavailable — one or more connectors are not approved for safe verification. Identity checks can still run."
                : undefined
            }
          >
            {reviewing ? (
              <>
                <span className="at-spinner at-spinner--sm" /> Running review…
              </>
            ) : (
              "Run Review Again"
            )}
          </button>
          {reviewCorrelationId && (
            <button
              className="at-btn at-btn--ghost"
              type="button"
              disabled={checkingProgress}
              aria-busy={checkingProgress}
              onClick={handleCheckProgress}
            >
              {checkingProgress ? (
                <><span className="at-spinner at-spinner--sm" /> Checking…</>
              ) : (
                "Check Progress"
              )}
            </button>
          )}
          <RefreshBtn onClick={load} loading={loading} />
        </div>
      </div>

      {reviewCorrelationId && reviewRunStatus && (
        <div className="at-info-banner" role="status" aria-live="polite">
          <div>
            <strong>
              Review {reviewRunStatus.status === "started" || reviewRunStatus.status === "running"
                ? "in progress"
                : reviewRunStatus.status}
            </strong>
            <p style={{ margin: "2px 0 0", fontSize: "0.8rem" }}>
              {reviewRunStatus.latest_progress?.message ||
                (reviewRunStatus.status === "completed"
                  ? "Review finished. The report has been refreshed."
                  : reviewRunStatus.status === "failed"
                    ? reviewRunStatus.error || "The review failed."
                    : "The review was accepted by the backend. Select Check Progress to fetch its latest status.")}
              <span className="at-muted">{" "}ID: {reviewCorrelationId}</span>
            </p>
          </div>
        </div>
      )}

      {executionBlocked && (
        <div className="at-info-banner">
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
          <div>
            <strong>Production verification unavailable</strong>
            <p style={{ margin: "2px 0 0", fontSize: "0.8rem" }}>
              Agent Trust can only run production verification when all
              connected systems are confirmed safe for read-only testing. This
              agent has at least one connector that does not meet that
              requirement. Identity checks can still run.
            </p>
          </div>
        </div>
      )}

      {reviewError && <ErrorBanner message={reviewError} />}
      {reviewResult && (
        <div className="at-review-result-banner">
          {reviewResult.results.map((r) => (
            <div
              key={r.agent_id}
              className={`at-review-result-row ${r.status === "reviewed" ? "at-review-result-row--ok" : "at-review-result-row--fail"}`}
            >
              <span>{r.status === "reviewed" ? "✓" : "✕"}</span>
              <span>
                Review {r.status} — Trust Score:{" "}
                <strong style={{ color: scoreColor(r.trust_score) }}>
                  {r.trust_score}
                </strong>
                {r.previous_score != null &&
                  r.previous_score !== r.trust_score && (
                    <span className="at-muted" style={{ marginLeft: 6 }}>
                      (was {r.previous_score}{" "}
                      {r.trust_score > r.previous_score ? "↑" : "↓"})
                    </span>
                  )}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* WHY THIS SCORE */}
      {data?.checks && data.checks.length > 0 && (
        <div className="at-review-card">
          <div className="at-review-card__title">
            Why this score?
            <InfoTooltip text="A trust review evaluates the agent's current trust posture and updates its Trust Score." />
          </div>
          <div className="at-checks-list">
            {data.checks.map((c, i) => (
              <div key={i} className="at-check-row">
                {checkIcon(c.status as CheckStatus)}
                <span className="at-check-row__name">{c.label}</span>
                <span className="at-check-row__status">
                  {checkStatusLabel(c.status as CheckStatus)}
                </span>
                {c.summary && (
                  <span className="at-check-row__expl">
                    {c.summary}
                    {c.fix ? ` — ${c.fix}` : ""}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Improvements */}
      {data?.improvements && data.improvements.length > 0 && (
        <div className="at-review-card">
          <div className="at-review-card__title">
            What can improve this agent?
          </div>
          <div className="at-improvements">
            {data.improvements.map((imp, i) => (
              <div key={i} className="at-improvement-row">
                <div>
                  <div className="at-improvement-title">{imp.label}</div>
                  <div className="at-improvement-desc">{imp.reason}</div>
                </div>
                {imp.action && (
                  <button className="at-btn at-btn--ghost at-btn--sm">
                    {imp.action}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Functional testing */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Functional Testing
            <InfoTooltip text="Tests the agent against scenarios you define. These tests check whether the agent behaves as expected for important use cases." />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("suite-add")}
            >
              + Add Test Suite
            </button>
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("ai-rec")}
            >
              ✨ Suggest with AI
            </button>
          </div>
        </div>

        {!data?.test_suites || data.test_suites.length === 0 ? (
          <EmptyCard
            title="Functional testing is not configured."
            desc="Add your own tests or ask Agent Trust to suggest them."
            actions={
              <>
                <button
                  className="at-btn at-btn--primary at-btn--sm"
                  onClick={() => setDrawer("suite-add")}
                >
                  Add Test Suite
                </button>
                <button
                  className="at-btn at-btn--ghost at-btn--sm"
                  onClick={() => setDrawer("ai-rec")}
                >
                  ✨ Suggest with AI
                </button>
              </>
            }
          />
        ) : (
          <div className="at-suites-list">
            {data.test_suites.map((s) => {
              const allPassed =
                s.passed_tests === s.total_tests && s.total_tests > 0;
              return (
                <div key={s.suite_id} className="at-suite-row">
                  <div className="at-suite-row__info">
                    <span className="at-suite-row__name">{s.name}</span>
                    <span className="at-muted">{s.total_tests} tests</span>
                    {s.last_run_at && (
                      <span
                        className={`at-badge ${allPassed ? "at-badge--trusted" : "at-badge--warn"}`}
                        style={{ fontSize: "0.72rem" }}
                      >
                        Last run: {s.passed_tests}/{s.total_tests} passed
                      </span>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      className="at-btn at-btn--ghost at-btn--sm"
                      onClick={() => {
                        setViewSuite(s);
                        setDrawer("suite-view");
                      }}
                    >
                      View Tests
                    </button>
                    <button
                      className="at-btn at-btn--danger at-btn--sm"
                      onClick={async () => {
                        try {
                          await deleteFunctionalSuite(agentId, s.suite_id);
                          await load();
                        } catch (err) {
                          setReviewError(
                            extractApiError(err, "Failed to remove suite."),
                          );
                        }
                      }}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Policies */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Policies
            <InfoTooltip text="Policies are optional governance rules assigned to an agent. Missing policy coverage does not prevent a review, but it can reduce the agent's trust score." />
          </div>
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            onClick={() => setDrawer("policies")}
          >
            Manage Policies
          </button>
        </div>
        {!data?.policies || data.policies.length === 0 ? (
          <EmptyCard
            title="No policies assigned."
            desc="Policies are optional, but policy coverage can improve the agent's trust posture."
            actions={
              <button
                className="at-btn at-btn--primary at-btn--sm"
                onClick={() => setDrawer("policies")}
              >
                Manage Policies
              </button>
            }
          />
        ) : (
          <div className="at-assigned-policies">
            {data.policies.map((p, i) => (
              <div key={i} className="at-assigned-policy-row">
                {checkIcon("pass")}
                <span className="at-policy-name">{p.name}</span>
                {p.category && (
                  <span
                    className="at-badge at-badge--unknown"
                    style={{ fontSize: "0.68rem" }}
                  >
                    {p.category}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Security */}
      <div className="at-review-card">
        <div className="at-review-card__hdr">
          <div className="at-review-card__title">
            Security
            <InfoTooltip text="Automatic adversarial tests check how the agent handles unsafe or manipulative requests. Security checks are not manually configured by the user." />
          </div>
          {data?.security?.probes && data.security.probes.length > 0 && (
            <button
              className="at-btn at-btn--ghost at-btn--sm"
              onClick={() => setDrawer("security")}
            >
              View Results
            </button>
          )}
        </div>
        {!data?.security || data.security.total_probes === 0 ? (
          <p className="at-muted" style={{ fontSize: "0.82rem" }}>
            No security data available yet. Run a review to trigger adversarial
            checks.
          </p>
        ) : (
          <div className="at-security-summary">
            <div className="at-security-summary__row">
              <span className="at-muted">
                {data.security.blocked} of {data.security.total_probes}{" "}
                adversarial requests were blocked
              </span>
            </div>
            {data.security.total_probes - data.security.blocked > 0 && (
              <span
                className="at-badge at-badge--risk"
                style={{ fontSize: "0.72rem" }}
              >
                {data.security.total_probes - data.security.blocked} passed
                through
              </span>
            )}
            {data.security.last_scan_at && (
              <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                Last scan: {fmtDate(data.security.last_scan_at)}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Identity / Credentials */}
      <div className="at-review-card">
        <div className="at-review-card__title">
          Identity
          <InfoTooltip text="Checks configured connectors and credentials and compares them with relevant observed usage. Identity checks do not execute the agent." />
        </div>
        {!data?.credentials ? (
          <p className="at-muted" style={{ fontSize: "0.82rem" }}>
            No identity data available.
          </p>
        ) : (
          <div className="at-identity-summary">
            {data.credentials.evaluated_at && (
              <span className="at-muted" style={{ fontSize: "0.75rem" }}>
                Evaluated: {fmtDate(data.credentials.evaluated_at)}
              </span>
            )}
            {data.credentials.declared.length === 0 &&
            data.credentials.drift.length === 0 ? (
              <div className="at-check-row">
                {checkIcon("not_configured")}
                <span className="at-check-row__name">
                  No credentials declared
                </span>
              </div>
            ) : (
              <>
                {data.credentials.declared.length > 0 && (
                  <div className="at-connector-list">
                    {data.credentials.declared.map((c, i) => (
                      <div key={i} className="at-connector-row">
                        <span className="at-connector-name">{c.name}</span>
                        {c.status && (
                          <span
                            className={`at-badge ${c.status === "healthy" || c.status === "ok" ? "at-badge--trusted" : "at-badge--warn"}`}
                            style={{ fontSize: "0.68rem" }}
                          >
                            {c.status}
                          </span>
                        )}
                        {c.safe_for_review === false && (
                          <span
                            className="at-badge at-badge--risk"
                            style={{ fontSize: "0.68rem" }}
                          >
                            Not safe for review
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {data.credentials.drift.length > 0 && (
                  <div className="at-check-row" style={{ marginTop: 6 }}>
                    {checkIcon("partial")}
                    <span className="at-check-row__name">
                      {data.credentials.drift.length} drift issue
                      {data.credentials.drift.length !== 1 ? "s" : ""} detected
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Drawers */}
      {drawer === "suite-view" && viewSuite && (
        <TestSuiteDrawer
          suite={viewSuite}
          onClose={() => {
            setDrawer(null);
            setViewSuite(null);
          }}
        />
      )}
      {drawer === "suite-add" && (
        <div
          className="at-drawer-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Add test suite"
        >
          <div className="at-drawer">
            <div className="at-drawer__hdr">
              <h3 className="at-drawer__title">Add Test Suite</h3>
              <button
                className="at-drawer__close"
                onClick={() => setDrawer(null)}
                aria-label="Close"
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <AddSuiteForm
              agentId={agentId}
              source="user"
              onSaved={async () => {
                setDrawer(null);
                await load();
              }}
              onCancel={() => setDrawer(null)}
            />
          </div>
        </div>
      )}
      {drawer === "ai-rec" && (
        <AiRecommendModal
          agentId={agentId}
          onAccept={(rec) => {
            setAiRec(rec);
            setDrawer("suite-add");
          }}
          onClose={() => {
            setDrawer(null);
            setAiRec(null);
          }}
        />
      )}
      {drawer === "suite-add" && aiRec && (
        <div
          className="at-drawer-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Accept AI suggestion"
        >
          <div className="at-drawer">
            <div className="at-drawer__hdr">
              <h3 className="at-drawer__title">Accept AI Suggestion</h3>
              <button
                className="at-drawer__close"
                onClick={() => {
                  setDrawer(null);
                  setAiRec(null);
                }}
                aria-label="Close"
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <AddSuiteForm
              agentId={agentId}
              source="ai"
              prefill={{
                name: aiRec.suggested_name,
                test_cases: aiRec.test_cases,
              }}
              onSaved={async () => {
                setDrawer(null);
                setAiRec(null);
                await load();
              }}
              onCancel={() => {
                setDrawer(null);
                setAiRec(null);
              }}
            />
          </div>
        </div>
      )}
      {drawer === "policies" && data && (
        <ManagePoliciesDrawer
          agentId={agentId}
          assignedPolicies={data.policies ?? []}
          onClose={() => setDrawer(null)}
          onChanged={async () => {
            await load();
          }}
        />
      )}
      {drawer === "security" && data?.security && (
        <SecurityDrawer
          probes={data.security.probes ?? []}
          onClose={() => setDrawer(null)}
        />
      )}
    </div>
  );
}

// ─── 4. Agent detail: Timeline sub-tab ────────────────────────────────────────

const TIMELINE_EVENT_ICON: Record<string, string> = {
  "agent.created": "🟢",
  "agent.updated": "✏️",
  "agent.reviewed": "🔍",
  "connector.added": "🔌",
  "connector.removed": "🔌",
  "suite.added": "🧪",
  "suite.removed": "🧪",
  "policy.assigned": "📋",
  "policy.removed": "📋",
  "security.scan": "🛡️",
  "trust.score.changed": "📊",
  "agent.run": "▶️",
};

function TimelineTab({ agentId }: { agentId: string }) {
  const [items, setItems] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nextCursor, setNextCursor] = useState<number | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchTimeline(agentId, { limit: 50 })
      .then((res) => {
        setItems(res.entries);
        setNextCursor(res.next_cursor);
      })
      .catch((err) =>
        setError(extractApiError(err, "Failed to load timeline.")),
      )
      .finally(() => setLoading(false));
  }, [agentId]);

  const loadMore = async () => {
    if (!nextCursor) return;
    setLoadingMore(true);
    try {
      const res = await fetchTimeline(agentId, {
        cursor: nextCursor,
        limit: 50,
      });
      setItems((prev) => [...prev, ...res.entries]);
      setNextCursor(res.next_cursor);
    } catch (err) {
      setError(extractApiError(err, "Failed to load more events."));
    } finally {
      setLoadingMore(false);
    }
  };

  const toggleExpanded = (seq: number) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(seq) ? next.delete(seq) : next.add(seq);
      return next;
    });

  if (loading) return <Loader />;
  if (error) return <ErrorBanner message={error} />;

  if (items.length === 0) {
    return (
      <EmptyCard
        title="No timeline events yet."
        desc="Events will appear here as the agent is used, reviewed, and updated."
      />
    );
  }

  return (
    <div className="at-subtab-content">
      <div className="at-timeline">
        {items.map((ev) => {
          const isExpanded = expanded.has(ev.seq);
          const hasDetails = ev.details && Object.keys(ev.details).length > 0;
          return (
            <div key={ev.seq} className="at-timeline-item">
              <span className="at-timeline-icon" aria-hidden="true">
                {TIMELINE_EVENT_ICON[ev.event] ?? "📋"}
              </span>
              <div className="at-timeline-body">
                <span className="at-timeline-type">{ev.title}</span>
                {ev.actor && (
                  <span className="at-timeline-desc">{ev.actor}</span>
                )}
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    alignItems: "center",
                    flexWrap: "wrap",
                    marginTop: 2,
                  }}
                >
                  <span className="at-timeline-ts">{fmtDate(ev.at)}</span>
                  {ev.outcome && (
                    <span
                      className={`at-badge ${ev.outcome === "success" ? "at-badge--trusted" : "at-badge--risk"}`}
                      style={{ fontSize: "0.65rem", padding: "1px 6px" }}
                    >
                      {ev.outcome}
                    </span>
                  )}
                  {ev.severity && (
                    <span
                      className="at-badge at-badge--warn"
                      style={{ fontSize: "0.65rem", padding: "1px 6px" }}
                    >
                      {ev.severity}
                    </span>
                  )}
                  {hasDetails && (
                    <button
                      className="at-timeline-expand-btn"
                      onClick={() => toggleExpanded(ev.seq)}
                    >
                      {isExpanded ? "Hide details" : "Show details"}
                    </button>
                  )}
                </div>
                {isExpanded && hasDetails && (
                  <pre
                    className="at-code-block"
                    style={{ marginTop: 8, fontSize: "0.72rem" }}
                  >
                    {JSON.stringify(ev.details, null, 2)}
                  </pre>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {nextCursor && (
        <div
          style={{ display: "flex", justifyContent: "center", marginTop: 16 }}
        >
          <button
            className="at-btn at-btn--ghost at-btn--sm"
            disabled={loadingMore}
            onClick={loadMore}
          >
            {loadingMore ? (
              <>
                <span className="at-spinner at-spinner--sm" /> Loading…
              </>
            ) : (
              "Load older events"
            )}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── 5. Agent detail: Usage sub-tab ───────────────────────────────────────────

function UsageTab({ agentId }: { agentId: string }) {
  const [data, setData] = useState<AgentUsage | null>(null);
  const [window, setWindow] = useState<UsageWindow>("30d");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (w: UsageWindow) => {
      setLoading(true);
      setError(null);
      try {
        setData(await fetchUsage(agentId, w));
      } catch (err) {
        setError(extractApiError(err, "Failed to load usage data."));
      } finally {
        setLoading(false);
      }
    },
    [agentId],
  );

  useEffect(() => {
    load(window);
  }, [load, window]);

  return (
    <div className="at-subtab-content">
      <div className="at-section-hdr">
        <SectionHeader
          title="Usage"
          tooltip="Token, run and cost information collected from agent telemetry."
        />
        <div className="at-window-selector">
          {(["24h", "7d", "30d", "all"] as UsageWindow[]).map((w) => (
            <button
              key={w}
              className={`at-window-btn${window === w ? " at-window-btn--active" : ""}`}
              onClick={() => setWindow(w)}
            >
              {w === "all" ? "All" : w}
            </button>
          ))}
        </div>
      </div>

      {loading && <Loader />}
      {error && <ErrorBanner message={error} />}

      {!loading && !error && data && (
        <>
          <div className="at-stat-grid">
            <StatCard
              label="Runs"
              value={fmtNum(data.total_runs)}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="5 3 19 12 5 21 5 3" />
                </svg>
              }
            />
            <StatCard label="Input Tokens" value={fmtNum(data.input_tokens)} />
            <StatCard
              label="Output Tokens"
              value={fmtNum(data.output_tokens)}
            />
            <StatCard
              label="Total Tokens"
              value={fmtNum(data.total_tokens)}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
              }
            />
            <StatCard
              label="Cost"
              value={fmtCost(data.total_cost_usd)}
              sub={data.cost_is_estimated ? "Estimated" : undefined}
              accent={data.cost_is_estimated ? "#d97706" : undefined}
              icon={
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="12" y1="1" x2="12" y2="23" />
                  <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                </svg>
              }
            />
            <StatCard label="Last Used" value={fmtDate(data.last_used_at)} />
          </div>
          {data.cost_is_estimated && (
            <p className="at-desc">
              Cost is estimated — calculated from available telemetry and
              pricing information. An exact cost record was not available.
            </p>
          )}
        </>
      )}

      {!loading && !error && !data && (
        <EmptyCard
          title="No usage data."
          desc="Usage information will appear here once this agent has been run."
        />
      )}
    </div>
  );
}

// ─── Agent Detail container ────────────────────────────────────────────────────

function AgentDetailView({
  agent,
  onBack,
}: {
  agent: AgentListItem;
  onBack: () => void;
}) {
  const [tab, setTab] = useState<DetailTab>("overview");

  return (
    <div className="at-tab-content">
      {/* Back + agent header */}
      <div className="at-detail-breadcrumb">
        <button className="at-btn at-btn--ghost at-btn--sm" onClick={onBack}>
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          All Agents
        </button>
        <span className="at-breadcrumb-sep">/</span>
        <span className="at-breadcrumb-name">{agent.name}</span>
      </div>

      <div className="at-detail-agent-hdr">
        <div className="at-detail-agent-hdr__left">
          <div className="at-detail-agent-hdr__name">{agent.name}</div>
          <div
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <span className={trustStateBadgeClass(agent.trust_state)}>
              {trustStateLabel(agent.trust_state)}
            </span>
            <ScoreBar score={agent.trust_score} />
            {agent.stale && <span className="at-stale-chip">Stale</span>}
          </div>
        </div>
      </div>

      {/* Sub-tabs */}
      <nav
        className="at-subtabs"
        role="tablist"
        aria-label="Agent detail sections"
      >
        {DETAIL_TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={`at-subtab${tab === t.id ? " at-subtab--active" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="at-subtab-panel" role="tabpanel">
        {tab === "overview" && <OverviewTab agent={agent} />}
        {tab === "review" && <ReviewTab agentId={agent.agent_id} />}
        {tab === "timeline" && <TimelineTab agentId={agent.agent_id} />}
        {tab === "usage" && <UsageTab agentId={agent.agent_id} />}
      </div>
    </div>
  );
}

// ─── Access denied ─────────────────────────────────────────────────────────────

function AccessDenied() {
  return (
    <div className="at-access-denied">
      <div className="at-access-denied__icon" aria-hidden="true">
        <svg
          width="28"
          height="28"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
        </svg>
      </div>
      <h2 className="at-access-denied__title">Access Restricted</h2>
      <p className="at-access-denied__desc">
        Agent Trust is only available to <strong>Admins</strong> and{" "}
        <strong>Super Admins</strong>. Contact your administrator if you need
        access.
      </p>
    </div>
  );
}

// ─── Root component ────────────────────────────────────────────────────────────

export function AgentTrust() {
  const { user } = useAuth();
  const [topTab, setTopTab] = useState<TopTab>("dashboard");
  const [selectedAgent, setSelectedAgent] = useState<AgentListItem | null>(
    null,
  );

  if (
    user?.role !== AUTH_ROLES.ADMIN &&
    user?.role !== AUTH_ROLES.SUPER_ADMIN
  ) {
    return <AccessDenied />;
  }

  const handleSelectAgent = (agent: AgentListItem) => {
    setSelectedAgent(agent);
    setTopTab("agent-detail");
  };

  const handleViewAgentById = (agentId: string) => {
    // Navigate to agent detail using id only — overview will fetch full data
    setSelectedAgent({ agent_id: agentId } as AgentListItem);
    setTopTab("agent-detail");
  };

  const handleBackToAgents = () => {
    setTopTab("agents");
    setSelectedAgent(null);
  };

  return (
    <div className="at-root">
      {/* Header */}
      <div className="at-header">
        <div className="at-header__inner">
          <div className="at-header__title-row">
            <div className="at-header__icon-wrap" aria-hidden="true">
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              </svg>
            </div>
            <h1 className="at-header__title">Agent Health Center</h1>
          </div>
          <p className="at-header__desc">
            Trust scores, checks, testing, policies and usage — all in one place
            for every agent.
          </p>
        </div>
      </div>

      {/* Top nav — hide when in agent detail (breadcrumb handles navigation) */}
      {topTab !== "agent-detail" && (
        <nav
          className="at-tabs"
          role="tablist"
          aria-label="Agent Health Center sections"
        >
          {(["dashboard", "agents"] as TopTab[]).map((t) => (
            <button
              key={t}
              role="tab"
              aria-selected={topTab === t}
              className={`at-tab${topTab === t ? " at-tab--active" : ""}`}
              onClick={() => setTopTab(t)}
            >
              <span
                style={{ display: "inline-flex", alignItems: "center", gap: 6 }}
              >
                {t === "dashboard" && (
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="3" y="3" width="7" height="7" />
                    <rect x="14" y="3" width="7" height="7" />
                    <rect x="14" y="14" width="7" height="7" />
                    <rect x="3" y="14" width="7" height="7" />
                  </svg>
                )}
                {t === "agents" && (
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                )}
                {t === "dashboard" ? "Dashboard" : "Agents"}
              </span>
            </button>
          ))}
        </nav>
      )}

      {/* Tab panels */}
      <div className="at-body" role="tabpanel">
        {topTab === "dashboard" && (
          <DashboardTab onViewAgent={handleViewAgentById} />
        )}
        {topTab === "agents" && <AgentsTab onSelectAgent={handleSelectAgent} />}
        {topTab === "agent-detail" && selectedAgent && (
          <AgentDetailView agent={selectedAgent} onBack={handleBackToAgents} />
        )}
      </div>
    </div>
  );
}
