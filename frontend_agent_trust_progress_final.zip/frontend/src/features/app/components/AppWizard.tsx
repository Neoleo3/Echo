"use client";

import React, { useRef, useState, useEffect, useMemo } from "react";
import type { Application, DataSourceRef, LLMModel, SkillLink } from "@/types";
import Image from "next/image";
import s from "./AppStudio.module.css";
import { SkillOption, SkillsPicker } from "./SkillsPicker";

export const WIZARD_STEPS = [
  { key: "app-setup", label: "App Setup" },
  { key: "access-permission", label: "Access\nPermission" },
  { key: "context", label: "Context" },
  { key: "chat-configuration", label: "Chat\nConfiguration" },
] as const;

export type WizardStep = 0 | 1 | 2 | 3;

const STEP_ICONS = [
  // App Setup — settings gear
  {
    width: "19",
    height: "20",
    viewBox: "0 0 19 20",
    path: "M9.37253 0C10.1065 0.0084595 10.8376 0.0932622 11.554 0.253038C11.8668 0.322785 12.1007 0.583511 12.1362 0.901963L12.3064 2.42881C12.3834 3.12986 12.9753 3.66084 13.681 3.66158C13.8706 3.66188 14.0583 3.62238 14.2335 3.54483L15.6342 2.92956C15.9255 2.80159 16.2658 2.87136 16.4833 3.10362C17.4955 4.18464 18.2493 5.48115 18.688 6.89558C18.7826 7.20058 18.6738 7.53203 18.4167 7.7215L17.1752 8.63659C16.8211 8.89679 16.6119 9.31001 16.6119 9.74946C16.6119 10.1889 16.8211 10.6021 17.176 10.8629L18.4186 11.7783C18.6757 11.9677 18.7847 12.2992 18.6901 12.6043C18.2515 14.0185 17.4981 15.3149 16.4865 16.3961C16.2692 16.6283 15.9291 16.6983 15.6378 16.5706L14.2315 15.9545C13.8292 15.7784 13.3671 15.8042 12.9869 16.024C12.6067 16.2437 12.3536 16.6312 12.3053 17.0677L12.1362 18.5944C12.1014 18.9092 11.8725 19.1682 11.5644 19.2415C10.1159 19.5861 8.60683 19.5861 7.15838 19.2415C6.85026 19.1682 6.6214 18.9092 6.58653 18.5944L6.41771 17.07C6.36812 16.6343 6.11469 16.248 5.73478 16.029C5.35486 15.81 4.89356 15.7843 4.49255 15.9594L3.08593 16.5756C2.79457 16.7033 2.45439 16.6333 2.23713 16.4009C1.22498 15.3185 0.471545 14.0205 0.0335523 12.6048C-0.0607863 12.2999 0.0482132 11.9686 0.305198 11.7793L1.54853 10.8633C1.90267 10.6031 2.11183 10.1899 2.11183 9.75046C2.11183 9.31101 1.90267 8.89779 1.54807 8.63725L0.305513 7.72285C0.0481474 7.53345 -0.0609522 7.20178 0.033719 6.89658C0.47247 5.48215 1.2263 4.18564 2.23848 3.10462C2.45594 2.87236 2.79629 2.80259 3.0876 2.93056L4.48797 3.54572C4.89091 3.72256 5.35415 3.69585 5.73612 3.47269C6.11644 3.25209 6.36964 2.86422 6.41852 2.42764L6.5886 0.901963C6.62411 0.58335 6.85821 0.322541 7.17115 0.252942C7.88843 0.0934198 8.6203 0.00865372 9.37253 0ZM9.36005 6.74995C7.70319 6.74995 6.36005 8.0931 6.36005 9.74995C6.36005 11.4068 7.70319 12.75 9.36005 12.75C11.0169 12.75 12.36 11.4068 12.36 9.74995C12.36 8.0931 11.0169 6.74995 9.36005 6.74995Z",
  },
  // Access Permission — lock
  {
    width: "17",
    height: "20",
    viewBox: "0 0 17 20",
    paths: [
      "M8.5 11.6667C8.72534 11.6667 8.94159 11.7538 9.10098 11.91C9.26029 12.0662 9.34989 12.2783 9.35 12.4992V14.1659C9.35 14.3869 9.26038 14.5996 9.10098 14.7559C8.94159 14.912 8.72533 14.9992 8.5 14.9992C8.27467 14.9992 8.05841 14.912 7.89902 14.7559C7.73962 14.5996 7.65 14.3869 7.65 14.1659V12.4992C7.65011 12.2783 7.73971 12.0662 7.89902 11.91C8.05841 11.7538 8.27466 11.6667 8.5 11.6667Z",
      "M8.5 0C10.078 0 11.5918 0.614208 12.7077 1.70817C13.8235 2.80213 14.45 4.28624 14.45 5.83333V7.01986C15.207 7.34378 15.8515 7.87745 16.3044 8.55469C16.7571 9.23186 16.9989 10.0236 17 10.8333V15.8333C16.9987 16.938 16.5508 17.9974 15.7541 18.7785C14.9573 19.5596 13.8768 19.9987 12.75 20H4.25C3.12324 19.9987 2.04268 19.5596 1.24595 18.7785C0.44921 17.9974 0.00134968 16.938 0 15.8333V10.8333C0.00108646 10.0236 0.242857 9.23186 0.695606 8.55469C1.14848 7.87745 1.79296 7.34378 2.55 7.01986V5.83333C2.55 4.28624 3.17649 2.80213 4.29233 1.70817C5.40818 0.614208 6.92196 0 8.5 0ZM4.25 8.33333C3.5737 8.33333 2.92529 8.59691 2.44707 9.06575C1.96885 9.5346 1.7 10.1703 1.7 10.8333V15.8333C1.7 16.4964 1.96885 17.1321 2.44707 17.6009C2.92529 18.0698 3.5737 18.3333 4.25 18.3333H12.75C13.4263 18.3333 14.0747 18.0698 14.5529 17.6009C15.0311 17.1321 15.3 16.4964 15.3 15.8333V10.8333C15.3 10.1703 15.0311 9.5346 14.5529 9.06575C14.0747 8.59691 13.4263 8.33333 12.75 8.33333H4.25ZM8.5 1.66667C7.37283 1.66667 6.29215 2.10597 5.49512 2.88737C4.69809 3.66877 4.25 4.72826 4.25 5.83333V6.66667H12.75V5.83333C12.75 4.72826 12.3019 3.66877 11.5049 2.88737C10.7079 2.10597 9.62717 1.66667 8.5 1.66667Z",
    ],
  },
  // Context — document
  {
    width: "17",
    height: "20",
    viewBox: "0 0 17 20",
    path: "M15.2575 4.61335L12.2944 1.70835C11.7432 1.16509 11.0876 0.734373 10.3656 0.441139C9.64351 0.147906 8.8693 -0.00202547 8.08774 2.06634e-05H4.24999C3.12324 0.00134388 2.04302 0.440755 1.24629 1.22187C0.449549 2.00298 0.00134968 3.06202 0 4.16668V15.8333C0.00134968 16.938 0.449549 17.997 1.24629 18.7782C2.04302 19.5593 3.12324 19.9987 4.24999 20H12.75C13.8767 19.9987 14.957 19.5593 15.7537 18.7782C16.5504 17.997 16.9986 16.938 17 15.8333V8.73751C17.0021 7.97128 16.8491 7.21224 16.55 6.50434C16.2509 5.79643 15.8116 5.1537 15.2575 4.61335ZM14.0556 5.79168C14.3149 6.05369 14.5381 6.34786 14.7194 6.66668H11.05C10.8246 6.66668 10.6084 6.57888 10.4489 6.4226C10.2895 6.26632 10.2 6.05436 10.2 5.83335V2.23585C10.5252 2.41367 10.8252 2.63248 11.0925 2.88668L14.0556 5.79168ZM15.3 15.8333C15.3 16.4964 15.0313 17.1323 14.5531 17.6011C14.0749 18.0699 13.4263 18.3333 12.75 18.3333H4.24999C3.57369 18.3333 2.92509 18.0699 2.44687 17.6011C1.96866 17.1323 1.7 16.4964 1.7 15.8333V4.16668C1.7 3.50364 1.96866 2.86776 2.44687 2.39892C2.92509 1.93008 3.57369 1.66669 4.24999 1.66669H8.08774C8.22799 1.66669 8.36229 1.69335 8.49999 1.70585V5.83335C8.49999 6.49639 8.76865 7.13227 9.24687 7.60111C9.72508 8.06995 10.3737 8.33335 11.05 8.33335H15.26C15.2728 8.46835 15.3 8.60001 15.3 8.73751V15.8333Z",
  },
  // Chat Configuration — chat bubble
  {
    width: "20",
    height: "19",
    viewBox: "0 0 20 19",
    path: "M3.25 15C1.45507 15 0 13.5449 0 11.75V3.25C0 1.45507 1.45507 0 3.25 0H16.75C18.5449 0 20 1.45507 20 3.25V11.75C20 13.5449 18.5449 15 16.75 15H11.0125L5.99868 18.7507C5.44585 19.1642 4.6625 19.0512 4.24901 18.4984C4.08736 18.2822 4 18.0196 4 17.7499L3.99921 15H3.25ZM10.5135 13.5H16.75C17.7165 13.5 18.5 12.7165 18.5 11.75V3.25C18.5 2.2835 17.7165 1.5 16.75 1.5H3.25C2.2835 1.5 1.5 2.2835 1.5 3.25V11.75C1.5 12.7165 2.2835 13.5 3.25 13.5H5.49879L5.499 14.2498L5.49986 17.2506L10.5135 13.5Z",
  },
];

// ─── Types ────────────────────────────────────────────────────────────────────
interface Option {
  id?: string;
  name?: string;
  kind?: string;
  skill_type?: string;
  rawName?: string;
}

interface AppWizardProps {
  form: Partial<Application>;
  updateField: (key: string, value: unknown) => void;
  selectLlm?: (model: Partial<LLMModel> | null) => void;
  currentLlmId?: string | null;
  dropdowns: Record<string, unknown[]>;
  submitting: boolean;
  applicationId: string | null;
  error: string | null;
  onSave: () => void;
  // onPublish?: () => void;
  onCancel: () => void;
  editApp?: any | null;
}

// ─── Custom multi-select dropdown (matches the HTML design + screenshot) ──────
interface MultiDropdownProps {
  label: string;
  placeholder: string;
  options: Option[];
  selectedIds: string[];
  onToggle: (option: Option) => void;
  onClear?: () => void;
  single?: boolean;
}

const MultiDropdown: React.FC<MultiDropdownProps> = ({
  label,
  placeholder,
  options,
  selectedIds,
  onToggle,
  onClear,
  single = false,
}) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  const popRef = useRef<HTMLDivElement>(null);
  const [popStyle, setPopStyle] = useState<React.CSSProperties>({});

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        ref.current &&
        !ref.current.contains(e.target as Node) &&
        popRef.current &&
        !popRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    if (open && ref.current) {
      const rect = ref.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      const popHeight = 280;
      if (spaceBelow >= popHeight || spaceBelow >= 160) {
        setPopStyle({
          top: rect.bottom + 6,
          left: rect.left,
          width: rect.width,
        });
      } else {
        setPopStyle({
          bottom: window.innerHeight - rect.top + 6,
          left: rect.left,
          width: rect.width,
        });
      }
    }
  }, [open]);

  const filtered = options.filter((o) =>
    (o.name ?? "").toLowerCase().includes(search.toLowerCase()),
  );

  const selectedOptions = options.filter((o) =>
    selectedIds.includes(o.id ?? ""),
  );

  const selectedSingle = single ? selectedOptions[0] : undefined;

  return (
    <div className={s.abField}>
      <label>{label}</label>
      <div className={`${s.umDd} ${open ? s.open : ""}`} ref={ref}>
        {/* Trigger */}
        <div
          className={s.umDdTrigger}
          role="button"
          tabIndex={0}
          onClick={() => setOpen((v) => !v)}
          onKeyDown={(e) => e.key === "Enter" && setOpen((v) => !v)}
          aria-expanded={open}
          aria-haspopup="listbox"
        >
          {single ? (
            <span className={selectedSingle ? s.umDdVal : s.umDdPh}>
              {selectedSingle ? selectedSingle.name : placeholder}
            </span>
          ) : (
            <div className={s.umDdChips}>
              {selectedOptions.length === 0 ? (
                <span className={s.umDdPh}>{placeholder}</span>
              ) : (
                selectedOptions.map((o) => (
                  <span key={o.id} className={s.umChip}>
                    {o.name}
                    <button
                      type="button"
                      className={s.umChipX}
                      aria-label={`Remove ${o.name}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggle(o);
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))
              )}
            </div>
          )}

          {single && selectedSingle && (
            <button
              type="button"
              className={s.umDdClearBtn}
              aria-label="Clear selection"
              onClick={(e) => {
                e.stopPropagation();
                if (onClear) {
                  onClear();
                } else {
                  onToggle(selectedSingle);
                }
              }}
            >
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
              >
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
          <svg
            className={s.umDdCaret}
            width="14"
            height="14"
            viewBox="0 0 256 256"
            fill="currentColor"
          >
            <path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z" />
          </svg>
        </div>

        {/* Dropdown popup */}
        <div className={s.umDdPop} style={popStyle} ref={popRef} role="listbox">
          {/* Search */}
          <div className={s.umDdSearch}>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              className={s.umDdSearchInput}
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          {/* Options */}
          <div className={s.umDdList}>
            {filtered.length === 0 ? (
              <div className={s.umDdEmpty}>No options found</div>
            ) : (
              filtered.map((o) => {
                const checked = selectedIds.includes(o.id ?? "");
                return (
                  <button
                    key={o.id}
                    type="button"
                    className={`${s.umDdOpt} ${checked ? s.on : ""}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggle(o);
                      if (single) {
                        setOpen(false);
                        setSearch("");
                      }
                    }}
                    role={single ? "radio" : "option"}
                    aria-checked={single ? checked : undefined}
                    aria-selected={!single ? checked : undefined}
                  >
                    {single ? (
                      <span className={`${s.umRadio} ${checked ? s.on : ""}`}>
                        {checked && <span className={s.umRadioDot} />}
                      </span>
                    ) : (
                      <span className={`${s.umCb} ${checked ? s.on : ""}`}>
                        {checked && (
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        )}
                      </span>
                    )}
                    {o.name}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Main Wizard component ────────────────────────────────────────────────────
export const AppWizard: React.FC<AppWizardProps> = ({
  form,
  updateField,
  dropdowns,
  submitting,
  applicationId,
  error,
  onSave,
  // onPublish,
  onCancel,
  editApp,
}) => {
  const [step, setStep] = useState<WizardStep>(0);
  const [slideDir, setSlideDir] = useState<"fwd" | "back">("fwd");
  const [stepError, setStepError] = useState<string | null>(null);
  const logoRef = useRef<HTMLInputElement>(null);

  const logoPreviewUrl = useMemo(() => {
    if (!form.logo_url || typeof form.logo_url === "string") return null;
    return URL.createObjectURL(form.logo_url as File);
  }, [form.logo_url]);

  useEffect(() => {
    return () => {
      if (logoPreviewUrl) URL.revokeObjectURL(logoPreviewUrl);
    };
  }, [logoPreviewUrl]);

  const goStep = (next: WizardStep) => {
    setSlideDir(next > step ? "fwd" : "back");
    setStep(next);
  };

  // ── Dropdown data ──
  const llmOptions = (dropdowns.llms ?? []) as Option[];
  const skillOptions = (dropdowns.skills ?? []) as Option[];
  const sourceOptions = (dropdowns["data-sources"] ?? []) as Option[];
  const designationOptions = (dropdowns.designations ?? []) as Option[];
  const businessUnitOptions = (dropdowns["business-units"] ?? []) as Option[];
  const tagOptions = (dropdowns.tags ?? []) as Option[];
  const personaOptions = (dropdowns.personas ?? []) as Option[];
  const guardrailOptions = (dropdowns["guardrail-categories"] ??
    []) as Option[];

  // ── Selected IDs ──
  const selectedLlmIds: string[] = (
    (form.llm_links as Array<{ llm_id?: string }>) ?? []
  )
    .map((l) => l.llm_id ?? "")
    .filter(Boolean);
  const selectedSourceIds: string[] = (form.data_source_ids ?? []) as string[];
  const selectedDesignationIds: string[] = (form as any).designation_ids ?? [];
  const selectedBusinessUnitIds: string[] =
    (form as any).business_unit_ids ?? [];
  const selectedTagIds: string[] = (form as any).tag_ids ?? [];
  const selectedGuardrailIds: string[] =
    (form as any).guardrail_category_ids ?? [];

  const starters: string[] = form.starter_questions ?? [];

  const toggleMultiId = (key: string, current: string[], id: string) => {
    updateField(
      key,
      current.includes(id) ? current.filter((x) => x !== id) : [...current, id],
    );
  };

  const toggleLlm = (option: Option) => {
    if (!option.id) {
      console.warn("[AppWizard] LLM option has no id — cannot select.");
      return;
    }

    const alreadySelected = selectedLlmIds.includes(option.id);
    updateField(
      "llm_links",
      alreadySelected
        ? []
        : [
            {
              llm_id: option.id,
              role: (option as any).provider ?? "",
            },
          ],
    );
  };

  const toggleSource = (option: Option) => {
    if (!option.id) return;

    const current = (form.data_source_ids ?? []) as string[];

    const next = current.includes(option.id)
      ? current.filter((id) => id !== option.id)
      : [...current, option.id];

    updateField("data_source_ids", next);
  };

  const togglePersona = (option: Option) => {
    const currentId = (form as any).persona_id ?? "";
    const incoming = option.id ?? "";
    updateField("persona_id", currentId === incoming ? "" : incoming);
  };

  // ── Logo upload ──
  const UploadLogo = (event: React.ChangeEvent<HTMLInputElement>) => {
    const MAX_SIZE = 250;
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate MIME type before creating an object URL.
    if (!file.type.startsWith("image/")) {
      console.warn("[AppWizard] Invalid image MIME type:", file.type);
      if (logoRef.current) logoRef.current.value = "";
      return;
    }

    const objectURL = URL.createObjectURL(file);
    const img = document.createElement("img");

    img.onload = () => {
      URL.revokeObjectURL(objectURL);
      if (img.naturalWidth <= MAX_SIZE && img.naturalHeight <= MAX_SIZE) {
        updateField("logo_url", file);
      } else {
        console.warn(
          `[AppWizard] Image too large: ${img.naturalWidth}×${img.naturalHeight} (max ${MAX_SIZE}×${MAX_SIZE}).`,
        );
        if (logoRef.current) logoRef.current.value = "";
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectURL);
      console.warn("[AppWizard] Could not read the image file.");
      if (logoRef.current) logoRef.current.value = "";
    };

    img.src = objectURL;
  };

  // ── Starter prompts ──
  const addStarter = () => {
    if (starters.length < 10)
      updateField("starter_questions", [...starters, ""]);
  };
  const removeStarter = () => {
    if (starters.length > 1)
      updateField("starter_questions", starters.slice(0, -1));
  };
  const updateStarter = (index: number, text: string) =>
    updateField(
      "starter_questions",
      starters.map((v, i) => (i === index ? text : v)),
    );

  // ── Submit handler ──
  const handleNext = async () => {
    setStepError(null);
    if (step < WIZARD_STEPS.length - 1) {
      if (step === 0) {
        const hasLlm =
          selectedLlmIds.length > 0 || (form as any).llm_links?.length > 0;
        if (!hasLlm) {
          setStepError("An LLM must be selected before continuing.");
          return;
        }
      }
      goStep((step + 1) as WizardStep);
    } else {
      onSave();
    }
  };

  // ── Render step content ──
  const renderContent = () => {
    switch (step) {
      // ─ Step 0: App Setup ──────────────────────────────────────────────────
      case 0:
        return (
          <div className={s.awGrid}>
            {/* Name — left half */}
            <div className={s.abField}>
              <label htmlFor="aw-name">
                Name <span className={s.required}>*</span>
              </label>
              <input
                id="aw-name"
                type="text"
                placeholder="e.g., Contract Reviewer"
                autoFocus
                value={form.name ?? ""}
                onChange={(e) => updateField("name", e.target.value)}
              />
            </div>

            {/* App Logo — right half (upload from CreateApplication.tsx) */}
            <div className={s.abField}>
              <label>App Logo</label>
              {form.logo_url ? (
                <div className={s.logoPreview}>
                  <button
                    type="button"
                    className={s.logoRemoveBtn}
                    onClick={() => {
                      if (logoRef.current) logoRef.current.value = "";
                      updateField("logo_url", null);
                    }}
                    aria-label="Remove logo"
                  >
                    ×
                  </button>
                  <Image
                    src={
                      applicationId && typeof form.logo_url === "string"
                        ? `https://ecoapilwebapp02-ash2f8e6fcgzexgq.centralindia-01.azurewebsites.net${form.logo_url as string}`
                        : typeof form.logo_url === "object" &&
                            form.logo_url !== null
                          ? URL.createObjectURL(form.logo_url as Blob)
                          : ""
                    }
                    alt="App Logo"
                    width={120}
                    height={120}
                    className={s.logoImg}
                    unoptimized
                  />
                </div>
              ) : (
                <div
                  className={s.logoUploadBox}
                  onClick={() =>
                    document.getElementById("aw-logo-upload")?.click()
                  }
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) =>
                    e.key === "Enter" &&
                    document.getElementById("aw-logo-upload")?.click()
                  }
                >
                  <svg
                    width="17"
                    height="16"
                    viewBox="0 0 17 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.16675 2C3.89061 2 3.66675 2.22386 3.66675 2.5C3.66675 2.77614 3.89061 3 4.16675 3H13.1667C13.4429 3 13.6667 2.77614 13.6667 2.5C13.6667 2.22386 13.4429 2 13.1667 2H4.16675ZM9.0203 4.14645C8.82504 3.95118 8.50846 3.95118 8.31319 4.14645L4.81319 7.64645C4.61793 7.84171 4.61793 8.15829 4.81319 8.35355C5.00846 8.54882 5.32504 8.54882 5.5203 8.35355L8.16675 5.70711V13.5C8.16675 13.7761 8.39061 14 8.66675 14C8.94289 14 9.16675 13.7761 9.16675 13.5V5.70711L11.8132 8.35355C12.0085 8.54882 12.325 8.54882 12.5203 8.35355C12.7156 8.15829 12.7156 7.84171 12.5203 7.64645L9.0203 4.14645Z"
                      fill="#454554"
                    />
                  </svg>
                  <p className={s.logoUploadText}>
                    Drag and drop files or browse on computer
                  </p>
                  <p className={s.logoUploadHint}>
                    Logo must be 250×250 pixels or smaller
                  </p>
                </div>
              )}
              <input
                ref={logoRef}
                id="aw-logo-upload"
                type="file"
                accept="image/*"
                className={s.hiddenInput}
                onChange={UploadLogo}
              />
            </div>

            {/* Description — full width */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-desc">Description</label>
              <textarea
                id="aw-desc"
                placeholder="What does this application do?"
                value={form.description ?? ""}
                onChange={(e) => updateField("description", e.target.value)}
              />
            </div>

            {/* LLMs — left half */}
            <MultiDropdown
              label="LLMs"
              placeholder="Select LLMs"
              options={llmOptions}
              selectedIds={selectedLlmIds}
              onToggle={toggleLlm}
              onClear={() => updateField("llm_links", [])}
              single
            />

            {/* Data Sources — right half */}
            <MultiDropdown
              label="Data Sources"
              placeholder="Select Data Sources"
              options={sourceOptions}
              selectedIds={selectedSourceIds}
              onToggle={toggleSource}
            />

            {/* Skills — full width */}
            <div className={`${s.abField} ${s.full}`}>
              <SkillsPicker
                options={skillOptions as SkillOption[]}
                selected={(form.skill_links as SkillLink[]) ?? []}
                onChange={(next) => updateField("skill_links", next)}
              />
            </div>
          </div>
        );

      // ─ Step 1: Access Permission ──────────────────────────────────────────
      case 1:
        return (
          <div className={s.awGrid}>
            {/* Designations — left half */}
            <MultiDropdown
              label="Designations"
              placeholder="Select Designations"
              options={designationOptions}
              selectedIds={selectedDesignationIds}
              onToggle={(o) =>
                toggleMultiId(
                  "designation_ids",
                  selectedDesignationIds,
                  o.id ?? "",
                )
              }
            />

            {/* Business Units — right half */}
            <MultiDropdown
              label="Business Units"
              placeholder="Select Business Units"
              options={businessUnitOptions}
              selectedIds={selectedBusinessUnitIds}
              onToggle={(o) =>
                toggleMultiId(
                  "business_unit_ids",
                  selectedBusinessUnitIds,
                  o.id ?? "",
                )
              }
            />

            {/* Tags — full width */}
            <div className={`${s.abField} ${s.full}`}>
              <MultiDropdown
                label="Tags"
                placeholder="Select Tags"
                options={tagOptions}
                selectedIds={selectedTagIds}
                onToggle={(o) =>
                  toggleMultiId("tag_ids", selectedTagIds, o.id ?? "")
                }
              />
            </div>

            {/* Checkboxes */}
            <div className={s.abField}>
              <label className={s.abCheck}>
                <input
                  type="checkbox"
                  checked={form.available_for_all_users ?? false}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    updateField("available_for_all_users", checked);
                    if (checked) {
                      updateField("designation_ids", []);
                      updateField("business_unit_ids", []);
                      updateField("tag_ids", []);
                    }
                  }}
                />
                Available to all users
              </label>
            </div>

            <div className={s.abField}>
              <label className={s.abCheck}>
                <input
                  type="checkbox"
                  checked={form.upload_enabled ?? false}
                  onChange={(e) =>
                    updateField("upload_enabled", e.target.checked)
                  }
                />
                Enable file upload in chat
              </label>
            </div>
          </div>
        );

      // ─ Step 2: Context ────────────────────────────────────────────────────
      case 2:
        return (
          <div className={s.awGrid}>
            {/* Welcome Prompt — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-welcome">Welcome Prompt</label>
              <textarea
                id="aw-welcome"
                placeholder="Greeting shown when the chat opens."
                value={form.welcome_prompt ?? ""}
                onChange={(e) => updateField("welcome_prompt", e.target.value)}
              />
            </div>

            {/* Disclaimer — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-disclaimer">Disclaimer</label>
              <textarea
                id="aw-disclaimer"
                placeholder="Shown below the composer."
                value={form.disclaimer ?? ""}
                onChange={(e) => updateField("disclaimer", e.target.value)}
              />
            </div>

            {/* Sorry Message — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-sorry">Sorry Message</label>
              <textarea
                id="aw-sorry"
                placeholder="Shown when the app can't answer."
                value={form.sorry_message ?? ""}
                onChange={(e) => updateField("sorry_message", e.target.value)}
              />
            </div>

            {/* Starter Questions — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label>Starter Questions</label>
              <div className={s.awStarters}>
                {starters.map((text, index) => (
                  <div key={index} className={s.awStarter}>
                    <input
                      type="text"
                      placeholder={`Starter question ${index + 1}`}
                      value={text}
                      onChange={(e) => updateStarter(index, e.target.value)}
                    />
                  </div>
                ))}
              </div>
              <div className={s.awStarterCtrls}>
                <span>Add / Remove starter question</span>
                <button
                  type="button"
                  className={s.awSqBtn}
                  onClick={removeStarter}
                  disabled={starters.length <= 1}
                  aria-label="Remove starter question"
                >
                  −
                </button>
                <button
                  type="button"
                  className={s.awSqBtn}
                  onClick={addStarter}
                  disabled={starters.length >= 10}
                  aria-label="Add starter question"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        );

      // ─ Step 3: Chat Configuration ─────────────────────────────────────────
      case 3:
        return (
          <div className={s.awGrid}>
            {/* Persona — left half */}
            <MultiDropdown
              label="Persona"
              placeholder="Select Persona"
              options={personaOptions}
              selectedIds={form.persona_id ? [form.persona_id] : []}
              onToggle={togglePersona}
              onClear={() => updateField("persona_id", "")}
              single
            />

            {/* Empty right half (matches HTML layout) */}
            <div className={s.abField} />

            {/* Persona Text — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-personaText">Persona Text</label>
              <textarea
                id="aw-personaText"
                placeholder="Describe the assistant's persona and tone."
                value={form.persona_text ?? ""}
                onChange={(e) => updateField("persona_text", e.target.value)}
              />
            </div>

            {/* Guardrails — full */}
            <div className={`${s.abField} ${s.full}`}>
              <MultiDropdown
                label="Guardrails"
                placeholder="Select Guardrails"
                options={guardrailOptions}
                selectedIds={selectedGuardrailIds}
                onToggle={(o) =>
                  toggleMultiId(
                    "guardrail_category_ids",
                    selectedGuardrailIds,
                    o.id ?? "",
                  )
                }
              />
            </div>

            {/* Guardrail Text — full */}
            <div className={`${s.abField} ${s.full}`}>
              <label htmlFor="aw-guardrailText">Guardrail Text</label>
              <textarea
                id="aw-guardrailText"
                placeholder="Additional guardrail instructions."
                value={form.guardrail_text ?? ""}
                onChange={(e) => updateField("guardrail_text", e.target.value)}
              />
            </div>
          </div>
        );
    }
  };

  const isLastStep = step === WIZARD_STEPS.length - 1;

  return (
    <div className={s.awWrap}>
      {/* ── Dialog panel ── */}
      <div
        className={`${s.awPanel} ${s[slideDir === "fwd" ? "awSlideFwd" : "awSlideBack"]}`}
      >
        {/* Header */}
        <div className={s.awDialogHead}>
          <h2 className={s.awDialogTitle}>
            {applicationId ? "Edit " : "Create New "}Application
          </h2>
          <button
            type="button"
            className={s.awCloseBtn}
            onClick={onCancel}
            aria-label="Close"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Stepper */}
        <div className={s.awStepperWrap}>
          <div className={s.awStepper}>
            {WIZARD_STEPS.map((st, i) => {
              const isCompleted = i < step;
              const isActive = i === step;
              const icon = STEP_ICONS[i];

              const fillColor = isCompleted
                ? "#ffffff"
                : isActive
                  ? "#000000"
                  : "#9CA3AF";

              return (
                <React.Fragment key={st.key}>
                  <div
                    className={`${s.awStep}${isActive ? ` ${s.active}` : ""}${isCompleted ? ` ${s.done}` : ""}`}
                  >
                    <div className={s.awStepIcWrap}>
                      {/* Circle */}
                      <div className={s.awStepIc} />
                      {/* SVG icon overlaid */}
                      <svg
                        width={icon.width}
                        height={icon.height}
                        viewBox={icon.viewBox}
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className={s.awStepSvg}
                      >
                        {"paths" in icon && icon.paths ? (
                          icon.paths.map((pathData: string, idx: number) => (
                            <path
                              key={idx}
                              d={pathData}
                              fill={fillColor}
                              fillRule={idx === 1 ? "evenodd" : undefined}
                              clipRule={idx === 1 ? "evenodd" : undefined}
                            />
                          ))
                        ) : (
                          <path d={(icon as any).path} fill={fillColor} />
                        )}
                      </svg>
                    </div>
                    <span className={s.awStepLbl}>
                      {st.label.split("\n").map((line, li) => (
                        <React.Fragment key={li}>
                          {line}
                          {li < st.label.split("\n").length - 1 && <br />}
                        </React.Fragment>
                      ))}
                    </span>
                  </div>

                  {/* Connecting line */}
                  {i < WIZARD_STEPS.length - 1 && (
                    <div
                      className={`${s.awStepLine}${isCompleted ? ` ${s.done}` : ""}`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Body */}
        <div className={s.awBody}>
          {renderContent()}
          {error && <p className={s.dhError}>{error}</p>}
          {stepError && <p className={s.dhError}>{stepError}</p>}
        </div>

        {/* Footer */}
        <div className={s.awFoot}>
          <div>
            <button
              type="button"
              className={s.abBtnSecondary}
              onClick={() => {
                if (step === 0) {
                  onCancel();
                } else {
                  goStep((step - 1) as WizardStep);
                }
              }}
            >
              {step === 0 ? "Cancel" : "Previous"}
            </button>
          </div>
          <div className={s.awFootRight}>
            {/* Publish button — only in edit mode on the final step */}

            <button
              type="button"
              className={s.abBtnPrimary}
              onClick={handleNext}
              disabled={submitting || (step === 0 && !form.name?.trim())}
            >
              {isLastStep ? (
                <>
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="20 6 9 17 4 12" />
                  </svg>{" "}
                  {submitting
                    ? "Saving…"
                    : applicationId
                      ? "Edit Application"
                      : "Create Application"}
                </>
              ) : (
                "Next"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
