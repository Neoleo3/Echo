"use client";

import React, { useEffect, useMemo, useState } from "react";
import type { SkillLink } from "@/types";
import s from "./AppStudio.module.css";

export interface SkillOption {
  id?: string;
  name?: string;
  rawName?: string;
  skill_type?: string;
}

interface SkillsPickerProps {
  options: SkillOption[];
  selected: SkillLink[];
  onChange: (next: SkillLink[]) => void;
}

// ─── Icons ────────────────────────────────────────────────────────────────────

const SkillIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="15"
    height="15"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
    <path d="M20 3v4M22 5h-4M4 17v2M5 18H3" />
  </svg>
);

const SearchIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="14"
    height="14"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

const ChevronIcon = ({ down }: { down: boolean }) => (
  <svg
    viewBox="0 0 24 24"
    width="12"
    height="12"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    style={{
      transform: down ? "rotate(0deg)" : "rotate(-90deg)",
      transition: "transform 0.2s",
    }}
  >
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

// ─── Skill type → accent colour helper ────────────────────────────────────────
const typeColor = (type?: string): string => {
  switch ((type ?? "").toLowerCase()) {
    case "agent":
      return "var(--accent)";
    case "workflow":
      return "#7c3aed";
    default:
      return "var(--text-soft)";
  }
};

// ─── Component ────────────────────────────────────────────────────────────────
export const SkillsPicker: React.FC<SkillsPickerProps> = ({
  options,
  selected,
  onChange,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [search, setSearch] = useState("");
  // Track which groups are collapsed (by type key). Default: all expanded.
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const selectedIds = useMemo(
    () => new Set(selected.map((l) => l.skill_id)),
    [selected],
  );

  // Group available options by skill_type for display
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return options.filter(
      (o) =>
        !q ||
        (o.name ?? "").toLowerCase().includes(q) ||
        (o.rawName ?? "").toLowerCase().includes(q) ||
        (o.skill_type ?? "").toLowerCase().includes(q),
    );
  }, [options, search]);

  // Group filtered results by type
  const grouped = useMemo(() => {
    const map = new Map<string, SkillOption[]>();
    filtered.forEach((o) => {
      const key = o.skill_type ?? "Other";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    });
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  const toggleGroup = (type: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(type)) next.delete(type);
      else next.add(type);
      return next;
    });
  };

  const collapseAll = () => {
    setCollapsed(new Set(grouped.map(([type]) => type)));
  };

  const expandAll = () => {
    setCollapsed(new Set());
  };

  const toggle = (option: SkillOption) => {
    if (!option.id) return;
    const exists = selectedIds.has(option.id);
    const next: SkillLink[] = exists
      ? selected.filter((l) => l.skill_id !== option.id)
      : [
          ...selected,
          {
            skill_id: option.id,
            skill_type: option.skill_type,
            skill_name: option.rawName ?? option.name,
          },
        ];
    onChange(next);
  };

  const remove = (skillId: string) => {
    onChange(selected.filter((l) => l.skill_id !== skillId));
  };

  const openModal = () => {
    setSearch("");
    setModalOpen(true);
  };

  useEffect(() => {
    collapseAll();
  }, []);

  return (
    <div className={s.spWrap}>
      {/* ── Tag display row ── */}
      <div className={s.spTags}>
        {selected.length === 0 ? (
          <span className={s.spEmpty}>
            No skills added — click &ldquo;Add skills&rdquo; to browse.
          </span>
        ) : (
          selected.map((link) => {
            const opt = options.find((o) => o.id === link.skill_id);
            const label = link.skill_name ?? opt?.rawName ?? link.skill_id;
            const type = link.skill_type ?? opt?.skill_type;
            return (
              <span key={link.skill_id} className={s.spTag}>
                <span
                  className={s.spTagDot}
                  style={{ background: typeColor(type) }}
                />
                {label}
                {type && <span className={s.spTagType}>{type}</span>}
                <button
                  type="button"
                  className={s.spTagX}
                  onClick={() => remove(link.skill_id)}
                  aria-label={`Remove ${label}`}
                >
                  &times;
                </button>
              </span>
            );
          })
        )}
      </div>

      {/* ── Trigger button ── */}
      <button type="button" className={s.spAddBtn} onClick={openModal}>
        <svg
          viewBox="0 0 24 24"
          width="13"
          height="13"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        Add skills
        {options.length > 0 && (
          <span className={s.spCountBadge}>{options.length} available</span>
        )}
      </button>

      {/* ── Modal popup ── */}
      {modalOpen && (
        <div className={s.spOverlay} onClick={() => setModalOpen(false)}>
          <div className={s.spModal} onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div className={s.spModalHead}>
              <div className={s.spModalHeadLeft}>
                <span className={s.spModalIcon}>
                  <SkillIcon />
                </span>
                <div>
                  <h3 className={s.spModalTitle}>Available Skills</h3>
                  <p className={s.spModalSub}>
                    {selected.length} selected &middot; {options.length}{" "}
                    available
                  </p>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {/* Expand / Collapse all */}
                <button
                  type="button"
                  className={s.spGroupToggle}
                  onClick={expandAll}
                  title="Expand all sections"
                >
                  Expand All
                </button>
                <button
                  type="button"
                  className={s.spGroupToggle}
                  onClick={collapseAll}
                  title="Collapse all sections"
                >
                  Collapse All
                </button>
                <button
                  className={s.spModalClose}
                  onClick={() => setModalOpen(false)}
                  aria-label="Close"
                >
                  &times;
                </button>
              </div>
            </div>

            {/* Search */}
            <div className={s.spModalSearch}>
              <input
                type="text"
                placeholder="Search skills…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
              />
            </div>

            {/* List */}
            <div className={s.spModalBody}>
              {filtered.length === 0 ? (
                <p className={s.spHint}>
                  No skills match &ldquo;{search}&rdquo;.
                </p>
              ) : (
                grouped.map(([type, items]) => {
                  const isCollapsed = collapsed.has(type);
                  return (
                    <div key={type} className={s.spGroup}>
                      {/* Group header with expand/collapse toggle */}
                      <div className={s.spGroupHead}>
                        <span
                          className={s.spGroupDot}
                          style={{ background: typeColor(type) }}
                        />
                        <span
                          className={s.spGroupLabel}
                          style={{ color: typeColor(type) }}
                        >
                          {type}
                        </span>
                        <span className={s.spGroupCount}>{items.length}</span>
                        <button
                          type="button"
                          className={`${s.spGroupToggle}${!isCollapsed ? ` ${s.open}` : ""}`}
                          onClick={() => toggleGroup(type)}
                          title={
                            isCollapsed ? "Expand section" : "Collapse section"
                          }
                        >
                          {isCollapsed ? "Expand" : "Collapse"}
                          <ChevronIcon down={!isCollapsed} />
                        </button>
                      </div>

                      {/* Items — hidden when collapsed */}
                      {!isCollapsed &&
                        items.map((option) => {
                          const isOn = selectedIds.has(option.id ?? "");
                          const displayName =
                            option.rawName ?? option.name ?? option.id ?? "";
                          return (
                            <label
                              key={option.id}
                              className={`${s.spRow}${isOn ? ` ${s.spRowOn}` : ""}`}
                            >
                              <input
                                type="checkbox"
                                checked={isOn}
                                onChange={() => toggle(option)}
                              />
                              <span className={s.spRowIcon}>
                                <SkillIcon />
                              </span>
                              <span className={s.spRowMeta}>
                                <span className={s.spRowName}>
                                  {displayName}
                                </span>
                              </span>
                              <span className={s.spRowCheck}>
                                {isOn && (
                                  <svg
                                    viewBox="0 0 24 24"
                                    width="14"
                                    height="14"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2.5"
                                    strokeLinecap="round"
                                  >
                                    <polyline points="20 6 9 17 4 12" />
                                  </svg>
                                )}
                              </span>
                            </label>
                          );
                        })}
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className={s.spModalFoot}>
              <span className={s.spHint}>
                {selected.length} skill{selected.length !== 1 ? "s" : ""}{" "}
                selected
              </span>
              <button
                type="button"
                className={s.abBtnPrimary}
                onClick={() => setModalOpen(false)}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
