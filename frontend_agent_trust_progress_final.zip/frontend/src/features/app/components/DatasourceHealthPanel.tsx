"use client";

import React, { useCallback, useEffect, useState } from "react";
import { applicationsService } from "@/services";
import type { ContextLedger, LedgerSource } from "@/types";
import s from "./AppStudio.module.css";

interface DatasourceHealthPanelProps {
  applicationId: string;
  sessionId?: string;
}

const describeKind = (source: LedgerSource): string =>
  source.kind && source.kind.trim() !== "" ? source.kind : "unresolved";

const SourceRow: React.FC<{ source: LedgerSource }> = ({ source }) => (
  <li className={s.dhRow}>
    <span
      className={`${s.dhDot} ${source.reachable ? s.dhOk : s.dhBad}`}
      aria-hidden="true"
    />
    <span className={s.dhMeta}>
      <span className={s.dhName}>
        {source.name || "Unnamed source"}
        <span className={s.dhKind}>{describeKind(source)}</span>
      </span>
      {source.reachable ? (
        source.detail ? (
          <span className={s.dhDetail}>{source.detail}</span>
        ) : null
      ) : (
        <span className={s.dhError}>
          {source.error || source.detail || "Unreachable"}
        </span>
      )}
    </span>
  </li>
);

export const DatasourceHealthPanel: React.FC<DatasourceHealthPanelProps> = ({
  applicationId,
  sessionId,
}) => {
  const [ledger, setLedger] = useState<ContextLedger | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (refresh = false) => {
      setLoading(true);
      setError(null);
      const response = await applicationsService.getContextLedger(
        applicationId,
        {
          sessionId,
          refresh,
        },
      );
      setLoading(false);
      if (response.success && response.data) {
        setLedger(response.data);
        return;
      }
      setError(response.error ?? "Could not read datasource health.");
    },
    [applicationId, sessionId],
  );

  useEffect(() => {
    load();
  }, [load]);

  const counts = ledger?.counts;
  const sources = [...(ledger?.connectors ?? []), ...(ledger?.knowledge ?? [])];

  return (
    <div className={s.dhPanel}>
      <div className={s.dhHead}>
        <div>
          <h3 className={s.dhTitle}>Data sources</h3>
          {counts && (
            <p className={s.dhSummary}>
              {counts.connectors_reachable} of {counts.connectors} connector
              {counts.connectors === 1 ? "" : "s"} reachable ·{" "}
              {counts.knowledge_bases} knowledge base
              {counts.knowledge_bases === 1 ? "" : "s"} ·{" "}
              {counts.indexed_documents} indexed document
              {counts.indexed_documents === 1 ? "" : "s"}
            </p>
          )}
        </div>
        <button
          type="button"
          className={s.btnGhost}
          onClick={() => load(true)}
          disabled={loading}
        >
          {loading ? "Testing…" : "Retest"}
        </button>
      </div>

      {error && <p className={s.dhError}>{error}</p>}

      {!error && !loading && sources.length === 0 && (
        <p className={s.dhSummary}>No data sources attached yet.</p>
      )}

      {sources.length > 0 && (
        <ul className={s.dhList}>
          {sources.map((source) => (
            <SourceRow
              key={`${source.source_id}-${source.kind}`}
              source={source}
            />
          ))}
        </ul>
      )}

      {ledger && ledger.session_documents.length > 0 && (
        <p className={s.dhSummary}>
          {ledger.session_documents.length} document
          {ledger.session_documents.length === 1 ? "" : "s"} uploaded in this
          chat
        </p>
      )}
    </div>
  );
};
