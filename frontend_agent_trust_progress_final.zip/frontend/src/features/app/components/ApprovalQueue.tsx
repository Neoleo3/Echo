"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import type { useApprovals } from "@/hooks/useApprovals";
import type { Application, ApprovalFocus, ApprovalQueueItem } from "@/types";
import s from "./AppStudio.module.css";

interface ApprovalQueueProps {
  approvals: ReturnType<typeof useApprovals>;
  focus?: ApprovalFocus | null;
  onResolved?: () => void;
}

const EMPTY = "—";

const summarise = (
  values: Array<string | undefined | null> | undefined,
): string => {
  const cleaned = (values ?? []).filter(
    (v): v is string => typeof v === "string" && v.trim().length > 0,
  );
  return cleaned.length > 0 ? cleaned.join(", ") : EMPTY;
};

interface ReviewRowProps {
  label: string;
  value: string;
}

const ReviewRow: React.FC<ReviewRowProps> = ({ label, value }) => (
  <div className={s.aqReviewRow}>
    <span className={s.aqReviewKey}>{label}</span>
    <span className={value === EMPTY ? s.aqReviewEmpty : s.aqReviewVal}>
      {value === EMPTY ? "Not configured" : value}
    </span>
  </div>
);

const ReviewPanel: React.FC<{ detail: Application }> = ({ detail }) => (
  <div className={s.aqReview}>
    <ReviewRow
      label="Model"
      value={summarise(
        detail.llm_links?.map((link) => (link as { name?: string }).name),
      )}
    />
    <ReviewRow
      label="Skills"
      value={summarise(
        detail.skill_links?.map(
          (link) => (link as { skill_name?: string }).skill_name,
        ),
      )}
    />
    <ReviewRow
      label="Data sources"
      value={summarise(detail.data_source_ids as string[])}
    />
    <ReviewRow
      label="Business units"
      value={summarise(detail.business_unit_names)}
    />
    <ReviewRow
      label="Designations"
      value={summarise(detail.designation_names)}
    />
    <ReviewRow label="Tags" value={summarise(detail.tag_names)} />
    <ReviewRow label="Persona" value={detail.persona_text?.trim() || EMPTY} />
    <ReviewRow
      label="Guardrails"
      value={detail.guardrail_text?.trim() || EMPTY}
    />
    <ReviewRow
      label="Welcome prompt"
      value={detail.welcome_prompt?.trim() || EMPTY}
    />
    <ReviewRow label="Disclaimer" value={detail.disclaimer?.trim() || EMPTY} />
    <ReviewRow
      label="Starter prompts"
      value={summarise(detail.starter_questions)}
    />
    <ReviewRow
      label="Uploads"
      value={detail.upload_enabled ? "Enabled" : "Disabled"}
    />
    <ReviewRow
      label="Audience"
      value={
        detail.available_for_all_users
          ? "All workspace members"
          : "Restricted by business unit and designation"
      }
    />
  </div>
);

export const ApprovalQueue: React.FC<ApprovalQueueProps> = ({
  approvals,
  focus = null,
  onResolved,
}) => {
  const {
    queue,
    loading,
    error,
    actingOn,
    details,
    detailLoading,
    loadDetail,
    approve,
    reject,
  } = approvals;

  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [reason, setReason] = useState("");

  const [focusMissing, setFocusMissing] = useState(false);

  const focusId = focus?.applicationId ?? null;
  const focusNonce = focus?.nonce ?? null;

  const handledNonceRef = useRef<number | null>(null);

  useEffect(() => {
    if (!focusId || focusNonce === null || loading) return;
    if (handledNonceRef.current === focusNonce) return;
    handledNonceRef.current = focusNonce;

    const present = queue.some((item) => item.application_id === focusId);
    setFocusMissing(!present);
    if (!present) return;
    setExpandedId(focusId);
    loadDetail(focusId);
  }, [focusId, focusNonce, loading, queue, loadDetail]);

  const toggleExpand = useCallback(
    async (applicationId: string) => {
      if (expandedId === applicationId) {
        setExpandedId(null);
        return;
      }
      setExpandedId(applicationId);
      await loadDetail(applicationId);
    },
    [expandedId, loadDetail],
  );

  const handleApprove = useCallback(
    async (applicationId: string) => {
      const ok = await approve(applicationId);
      if (ok) {
        setExpandedId(null);
        onResolved?.();
      }
    },
    [approve, onResolved],
  );

  const handleReject = useCallback(
    async (applicationId: string) => {
      const ok = await reject(applicationId, reason.trim() || undefined);
      if (ok) {
        setRejectingId(null);
        setReason("");
        setExpandedId(null);
        onResolved?.();
      }
    },
    [reject, reason, onResolved],
  );

  return (
    <>
      <div className={s.aeHead}>
        <h2>Pending Approval</h2>
        <p>
          Review what each application was configured with, then approve or send
          it back with a reason.
        </p>
      </div>

      {error && <p className={s.aqError}>{error}</p>}

      {focusMissing && !loading && (
        <p className={s.dhSummary}>
          That application is no longer awaiting approval — another Super Admin
          may have already actioned it.
        </p>
      )}

      {loading && <p className={s.dhSummary}>Loading the approval queue…</p>}

      {!loading && queue.length === 0 && (
        <p className={s.dhSummary}>Nothing is waiting for approval.</p>
      )}

      <div className={s.aeCards}>
        {queue.map((item: ApprovalQueueItem) => {
          const expanded = expandedId === item.application_id;
          const detail = details[item.application_id];
          const busy = actingOn === item.application_id;
          const isRejecting = rejectingId === item.application_id;

          return (
            <div
              key={item.application_id}
              className={`${s.aeCard} ${s.aqCard}`}
            >
              <div className={s.aeCardTop}>
                <div className={s.aeIc}>
                  {item.logo_url ? (
                    <img src={item.logo_url} alt="" width={20} height={20} />
                  ) : (
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M9 12l2 2 4-4" />
                      <circle cx="12" cy="12" r="10" />
                    </svg>
                  )}
                </div>
                <div className={s.aeMeta}>
                  <h3>{item.name}</h3>
                  <span className={s.aqBadge}>Pending</span>
                </div>
              </div>

              <p className={s.aeDesc}>
                {item.description || "No description provided."}
              </p>

              <div className={s.aeStats}>
                <span>
                  {item.llm_count} model{item.llm_count === 1 ? "" : "s"}
                </span>
                <span>
                  {item.skill_count} skill{item.skill_count === 1 ? "" : "s"}
                </span>
                <span>
                  {item.data_source_count} data source
                  {item.data_source_count === 1 ? "" : "s"}
                </span>
              </div>

              {expanded && detailLoading === item.application_id && (
                <p className={s.dhSummary}>Loading configuration…</p>
              )}
              {expanded && detail && <ReviewPanel detail={detail} />}

              {isRejecting && (
                <textarea
                  className={s.aqReason}
                  placeholder="Why is this being sent back? The owner sees this."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  autoFocus
                />
              )}

              <div className={s.aeFoot}>
                <button
                  className={s.aqBtn}
                  onClick={() => toggleExpand(item.application_id)}
                  disabled={busy}
                >
                  {expanded ? "Hide config" : "Review config"}
                </button>

                <div className={s.aqActions}>
                  {isRejecting ? (
                    <>
                      <button
                        className={s.aqBtn}
                        onClick={() => {
                          setRejectingId(null);
                          setReason("");
                        }}
                        disabled={busy}
                      >
                        Cancel
                      </button>
                      <button
                        className={`${s.aqBtn} ${s.aqReject}`}
                        onClick={() => handleReject(item.application_id)}
                        disabled={busy}
                      >
                        {busy ? "Rejecting…" : "Confirm reject"}
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        className={`${s.aqBtn} ${s.aqReject}`}
                        onClick={() => {
                          setRejectingId(item.application_id);
                          setReason("");
                        }}
                        disabled={busy}
                      >
                        Reject
                      </button>
                      <button
                        className={`${s.aqBtn} ${s.aqApprove}`}
                        onClick={() => handleApprove(item.application_id)}
                        disabled={busy}
                      >
                        {busy ? "Approving…" : "Approve"}
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
};
