"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import type { ApplicationList, Application } from "@/types";
import s from "./AppStudio.module.css";
import { ENV } from "@/config";
import { MultiDropdown } from "@/components/common/MultiDropdown";

export type AppListTab = "apps" | "pending";

interface AppListProps {
  applications: ApplicationList[];
  loading: boolean;
  onBack: () => void;
  onCreate: () => void;
  onEdit: (id: string) => void;
  showApprovals?: boolean;
  activeTab?: AppListTab;
  onTabChange?: (tab: AppListTab) => void;
  pendingCount?: number;
  approvalQueue?: React.ReactNode;
  onDelete?: (appId: string) => void;
  onPublish?: (appId: string) => void;
}

export const applicationKey = (application: ApplicationList): string =>
  application.application_id ?? application.name;

const CopilotIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
);

const GridIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
  </svg>
);

const TableIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);

const DotsIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="12" cy="5" r="1" fill="currentColor" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <circle cx="12" cy="19" r="1" fill="currentColor" />
  </svg>
);

/** 3-dot dropdown for table rows */
const RowMenu: React.FC<{
  onEdit: () => void;
  onDelete: () => void;
  onPublish?: () => void;
}> = ({ onEdit, onDelete, onPublish }) => {
  const [open, setOpen] = useState(false);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(
    null,
  );
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        btnRef.current &&
        !btnRef.current.contains(target) &&
        menuRef.current &&
        !menuRef.current.contains(target)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  // Reposition on scroll / resize while open
  useEffect(() => {
    if (!open) return;
    const reposition = () => {
      if (btnRef.current) {
        const rect = btnRef.current.getBoundingClientRect();
        setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
      }
    };
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [open]);
  const handleToggle = () => {
    if (!open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
    }
    setOpen((o) => !o);
  };

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        className={s.dotsBtn}
        onClick={handleToggle}
        aria-label="Actions"
      >
        <DotsIcon />
      </button>
      {open && menuPos && (
        <div
          ref={menuRef}
          className={s.rowMenu}
          style={{ position: "fixed", top: menuPos.top, left: menuPos.left }}
        >
          <button
            type="button"
            className={s.rowMenuItem}
            onClick={() => {
              setOpen(false);
              onEdit();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
            Edit
          </button>
          {onPublish && (
            <button
              type="button"
              className={s.rowMenuItem}
              onClick={() => {
                setOpen(false);
                onPublish();
              }}
            >
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              >
                <path d="M22 2L11 13" />
                <path d="M22 2L15 22 11 13 2 9l20-7z" />
              </svg>
              Publish
            </button>
          )}
          <button
            type="button"
            className={`${s.rowMenuItem} ${s.rowMenuItemDanger}`}
            onClick={() => {
              setOpen(false);
              onDelete();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
              <path d="M10 11v6" />
              <path d="M14 11v6" />
              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </>
  );
};

export const AppList: React.FC<AppListProps> = ({
  applications,
  loading,
  onBack,
  onCreate,
  onEdit,
  showApprovals = false,
  activeTab = "apps",
  onTabChange,
  pendingCount = 0,
  approvalQueue,
  onDelete,
  onPublish,
}) => {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [view, setView] = useState<"grid" | "list">("grid");

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return applications.filter((app) => {
      const matchesSearch =
        !query ||
        (app.name ?? "").toLowerCase().includes(query) ||
        (app.description ?? "").toLowerCase().includes(query);
      const matchesStatus =
        statusFilter === "all" || (app.status ?? "draft") === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [applications, search, statusFilter]);

  return (
    <div className={s.aeWrap}>
      <div className={s.aeTop}>
        <button className={s.cfgBack} onClick={onBack}>
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          App Studio
        </button>
        <button
          className={s.aeAdd}
          onClick={onCreate}
          title="New app"
          aria-label="Create new app"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </button>
      </div>

      {showApprovals && (
        <div className={s.aqTabs} role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "apps"}
            className={`${s.aqTab}${activeTab === "apps" ? ` ${s.aqTabActive}` : ""}`}
            onClick={() => onTabChange?.("apps")}
          >
            Your Applications
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "pending"}
            className={`${s.aqTab}${activeTab === "pending" ? ` ${s.aqTabActive}` : ""}`}
            onClick={() => onTabChange?.("pending")}
          >
            Pending Approval
            {pendingCount > 0 && (
              <span className={s.aqCount}>{pendingCount}</span>
            )}
          </button>
        </div>
      )}

      {showApprovals && activeTab === "pending" ? (
        approvalQueue
      ) : (
        <>
          <div className={s.aeHead}>
            <h2>Your Applications</h2>
            <p>Manage and publish AI apps for your workspace members.</p>
          </div>

          {/* Toolbar: search + filter + view toggle */}
          <div className={s.aeToolbar}>
            <input
              type="text"
              className={s.aeSearch}
              placeholder="Search applications…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search applications"
            />

            <div style={{ minWidth: "200px" }}>
              <MultiDropdown
                label=""
                placeholder="Select Status"
                options={[
                  { id: "all", name: "All Status" },
                  { id: "draft", name: "Draft" },
                  { id: "published", name: "Published" },
                ]}
                selectedIds={[statusFilter]}
                onToggle={(o) => setStatusFilter(o.id)}
                single
              />
            </div>

            <div className={s.viewToggle}>
              <button
                type="button"
                className={`${s.viewBtn}${view === "grid" ? ` ${s.viewBtnActive}` : ""}`}
                onClick={() => setView("grid")}
                aria-label="Grid view"
                title="Grid view"
              >
                <GridIcon />
              </button>
              <button
                type="button"
                className={`${s.viewBtn}${view === "list" ? ` ${s.viewBtnActive}` : ""}`}
                onClick={() => setView("list")}
                aria-label="Table view"
                title="Table view"
              >
                <TableIcon />
              </button>
            </div>
          </div>

          {loading && <p className={s.dhSummary}>Loading applications…</p>}
          {!loading && applications.length === 0 && (
            <p className={s.dhSummary}>
              No applications yet. Create one to get started.
            </p>
          )}
          {!loading && applications.length > 0 && filtered.length === 0 && (
            <p className={s.dhSummary}>
              No applications match your search or filter.
            </p>
          )}

          {view === "grid" ? (
            <div className={s.aeCards}>
              {filtered.map((application) => {
                const published = application.status === "published";
                return (
                  <div key={applicationKey(application)} className={s.aeCard}>
                    <div className={s.aeCardTop}>
                      <div className={s.aeIc}>
                        {application.logo_url ? (
                          <img
                            src={
                              `${ENV.API_BASE_URL}/${application.logo_url}` as string
                            }
                            alt=""
                            width={20}
                            height={20}
                          />
                        ) : (
                          <CopilotIcon />
                        )}
                      </div>
                      <div className={s.aeMeta}>
                        <h3>{application.name}</h3>
                        <span className={published ? s.aeStatus : s.adStatus}>
                          <svg
                            width="7"
                            height="7"
                            viewBox="0 0 8 8"
                            fill="currentColor"
                            aria-hidden="true"
                          >
                            <circle cx="4" cy="4" r="4" />
                          </svg>
                          {published ? "live" : application.status || "draft"}
                        </span>
                      </div>
                    </div>
                    <p className={s.aeDesc}>{application.description}</p>
                    <div className={s.aeStats}>
                      <span>
                        {application.skill_count ?? 0} skill
                        {(application.skill_count ?? 0) === 1 ? "" : "s"}
                      </span>
                      <span>
                        {application.data_source_count ?? 0} data source
                        {(application.data_source_count ?? 0) === 1 ? "" : "s"}
                      </span>
                      <span>
                        {application.llm_count ?? 0} llm
                        {(application.llm_count ?? 0) === 1 ? "" : "s"}
                      </span>
                    </div>
                    <div className={s.aeFoot}>
                      <div className={s.aeFootRight}>
                        <button
                          className={s.aeLaunch}
                          onClick={() => onEdit(application?.application_id)}
                        >
                          Edit
                          <svg
                            width="13"
                            height="13"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="9 18 15 12 9 6" />
                          </svg>
                        </button>
                        <button
                          className={s.aeDelBtn}
                          onClick={() =>
                            onDelete?.(application.application_id ?? "")
                          }
                          title="Delete this application"
                        >
                          <svg
                            width="13"
                            height="13"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                          >
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                            <path d="M10 11v6" />
                            <path d="M14 11v6" />
                            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                          </svg>
                          Delete
                        </button>
                        {!published && (
                          <button
                            type="button"
                            className={s.abBtnPublish}
                            onClick={() =>
                              onPublish?.(application?.application_id ?? "")
                            }
                            title="Publish this application"
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M22 2L11 13" />
                              <path d="M22 2L15 22 11 13 2 9l20-7z" />
                            </svg>
                            Publish
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Table view */
            <div className={s.aeTableWrap}>
              <table className={s.aeTable}>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Skills</th>
                    <th>Data Sources</th>
                    <th>LLMs</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((application) => {
                    const published = application.status === "published";
                    return (
                      <tr key={applicationKey(application)}>
                        <td>
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 10,
                            }}
                          >
                            <div
                              className={s.aeIc}
                              style={{ width: 28, height: 28, flexShrink: 0 }}
                            >
                              {application.logo_url ? (
                                <img
                                  src={application.logo_url as string}
                                  alt=""
                                  width={16}
                                  height={16}
                                />
                              ) : (
                                <CopilotIcon />
                              )}
                            </div>
                            <div>
                              <div style={{ fontWeight: 600 }}>
                                {application.name}
                              </div>
                              {application.description && (
                                <div
                                  style={{
                                    fontSize: 11.5,
                                    color: "var(--text-soft)",
                                    marginTop: 1,
                                  }}
                                >
                                  {application.description}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className={published ? s.aeStatus : s.adStatus}>
                            <svg
                              width="7"
                              height="7"
                              viewBox="0 0 8 8"
                              fill="currentColor"
                              aria-hidden="true"
                            >
                              <circle cx="4" cy="4" r="4" />
                            </svg>
                            {published ? "live" : application.status || "draft"}
                          </span>
                        </td>
                        <td>{application.skill_count ?? 0}</td>
                        <td>{application.data_source_count ?? 0}</td>
                        <td>{application.llm_count ?? 0}</td>
                        <td>
                          <RowMenu
                            onEdit={() => onEdit(application?.application_id)}
                            onDelete={() =>
                              onDelete?.(application.application_id ?? "")
                            }
                            onPublish={
                              !published
                                ? () =>
                                    onPublish?.(
                                      application?.application_id ?? "",
                                    )
                                : undefined
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
};
