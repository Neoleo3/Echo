"use client";

import React from "react";
import type { LLMModel } from "@/types";
import s from "./AppStudio.module.css";
import { linkMatchesModel } from "@/utils/llm-link.utils";

interface LlmSelectProps {
  models: Partial<LLMModel>[];
  value: string | null;
  onChange: (model: Partial<LLMModel> | null) => void;
  disabled?: boolean;
}

export const LlmSelect: React.FC<LlmSelectProps> = ({
  models,
  value,
  onChange,
  disabled,
}) => {
  const selected = value
    ? (models.find((model) => linkMatchesModel({ llm_id: value }, model)) ??
      null)
    : null;
  const visibleModels = models.filter(
    (model) => model.enabled !== false || model === selected,
  );

  const handleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const index = event.target.value;
    onChange(index === "" ? null : (visibleModels[Number(index)] ?? null));
  };

  const selectedIndex = selected ? String(visibleModels.indexOf(selected)) : "";

  return (
    <div className={`${s.abField} ${s.full}`}>
      <label htmlFor="app-llm">
        Model{" "}
        <span style={{ color: "var(--text-faint)", fontWeight: 400 }}>*</span>
      </label>
      <select
        id="app-llm"
        value={selectedIndex}
        onChange={handleChange}
        disabled={disabled || visibleModels.length === 0}
      >
        <option value="">
          {visibleModels.length === 0
            ? "No models available…"
            : "Select a model…"}
        </option>
        {visibleModels.map((model, index) => (
          <option key={model.credential_id ?? model.id ?? index} value={index}>
            {model.name}
            {model.provider ? ` — ${model.provider}` : ""}
            {model.is_default ? " (default)" : ""}
          </option>
        ))}
      </select>
      <p className={s.fieldHint}>
        This model runs the application&apos;s orchestration, and is the
        fallback for any agent that has not chosen one of its own.
      </p>
    </div>
  );
};
