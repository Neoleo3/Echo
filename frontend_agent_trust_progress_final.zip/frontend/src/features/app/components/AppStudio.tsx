"use client";

import React, { useCallback, useEffect, useState } from "react";
import { AppList, type AppListTab } from "./AppList";
import { AppWizard } from "./AppWizard";
import type { Application, ApprovalFocus } from "@/types";
import s from "./AppStudio.module.css";
import { ApprovalQueue } from "./ApprovalQueue";
import { useApplications } from "@/hooks/useApplications";
import { useApprovals } from "@/hooks/useApprovals";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { AUTH_ROLES } from "@/config";

type AppView = "landing" | "wizard" | "list";

interface AppStudioProps {
  approvalFocus?: ApprovalFocus | null;
}

export const AppStudio: React.FC<AppStudioProps> = ({
  approvalFocus = null,
}) => {
  const {
    applications,
    loading,
    submitting,
    form,
    dropdowns,
    updateField,
    selectLlm,
    currentLlmId,
    resetForm,
    getApplications,
    fetchDetails,
    submitApplication,
    deleteApplication,
  } = useApplications();

  const { user } = useAuth();
  const isSuperAdmin = user?.role === AUTH_ROLES.SUPER_ADMIN;
  const { toast } = useToast();
  const approvals = useApprovals({ enabled: isSuperAdmin });

  const [view, setView] = useState<AppView>("landing");
  const [listTab, setListTab] = useState<AppListTab>("apps");

  const { loadQueue } = approvals;

  useEffect(() => {
    if (!approvalFocus || !isSuperAdmin) return;
    setView("list");
    setListTab("pending");
    loadQueue();
  }, [approvalFocus, isSuperAdmin, loadQueue]);
  const [applicationId, setApplicationId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const startCreate = useCallback(() => {
    resetForm();
    setApplicationId(null);
    setError(null);
    setNotice(null);
    setView("wizard");
  }, [resetForm]);

  const startEdit = useCallback(
    async (id: string) => {
      setApplicationId(id);
      setError(null);
      setNotice(null);
      if (id) await fetchDetails(id);
      setView("wizard");
    },
    [fetchDetails],
  );

  const handleSave = useCallback(async () => {
    setError(null);
    setNotice(null);
    const response = await submitApplication(
      "chat-configuration",
      applicationId,
    );
    if (!response?.success) {
      const msg = response?.error ?? "Could not save the application.";
      setError(msg);
      toast({ title: "Save Failed", description: msg, variant: "destructive" });
      return;
    }
    const saved = response.data as Application | undefined;
    const id = saved?.application_id ?? saved?.application_id ?? applicationId;
    if (id) setApplicationId(id);
    setNotice("Saved.");
    setView("list");
    await getApplications();
    toast({
      title: applicationId ? "Application updated" : "Application created",
      description: applicationId
        ? "Your application has been updated successfully."
        : "Your new application has been created.",
      variant: "success",
    });
  }, [applicationId, submitApplication, getApplications, toast]);

  const handlePublish = useCallback(
    async (appId: string) => {
      setError(null);
      setNotice(null);
      if (!appId) {
        setError("Save the app before publishing it.");
        return;
      }
      const response = await submitApplication("dashboard", appId);
      if (!response?.success) {
        const msg = response?.error ?? "Could not publish the application.";
        setError(msg);
        toast({
          title: "Publish failed",
          description: msg,
          variant: "destructive",
        });
        return;
      }
      setNotice("Published.");
      setView("list");
      toast({
        title: "Application published",
        description: "Your application is now live.",
        variant: "success",
      });
    },
    [applicationId, submitApplication, getApplications, toast],
  );

  const renderLanding = () => (
    <div className={s.asLanding}>
      <div className={s.asHead}>
        <h1>App Studio</h1>
        <p>
          Build, customise and publish AI-powered applications for your team in
          minutes — no code required.
        </p>
      </div>
      <div className={s.asCards}>
        <button className={s.asCard} onClick={startCreate}>
          <div className={`${s.asCardIc} ${s.scratch}`}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
          </div>
          <span className={s.asCardT}>Build from scratch</span>
          <span className={s.asCardD}>
            Start with a blank canvas and define every detail of your app.
          </span>
        </button>

        <button className={s.asCard} onClick={() => setView("list")}>
          <div className={`${s.asCardIc} ${s.edit}`}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
          </div>
          <span className={s.asCardT}>Edit existing app</span>
          <span className={s.asCardD}>
            Update, republish or archive an app you&apos;ve already built.
          </span>
        </button>
      </div>
    </div>
  );

  return (
    <div className={s.appSoon}>
      <div className={s.asWrap}>
        {notice && <p className={s.awNotice}>{notice}</p>}

        {view === "landing" && renderLanding()}

        {view === "wizard" && (
          <AppWizard
            form={form}
            updateField={updateField}
            selectLlm={selectLlm}
            currentLlmId={currentLlmId}
            dropdowns={dropdowns}
            submitting={submitting}
            applicationId={applicationId}
            error={error}
            onSave={handleSave}
            // onPublish={handlePublish}
            onCancel={() => setView("landing")}
            editApp={() => applicationId ?? null}
          />
        )}

        {view === "list" && (
          <AppList
            applications={applications}
            loading={loading}
            onBack={() => setView("landing")}
            onCreate={startCreate}
            onEdit={startEdit}
            showApprovals={isSuperAdmin}
            activeTab={listTab}
            onTabChange={setListTab}
            pendingCount={approvals.queue.length}
            approvalQueue={
              <ApprovalQueue
                approvals={approvals}
                focus={approvalFocus}
                onResolved={getApplications}
              />
            }
            onDelete={async (appId) => {
              await deleteApplication(appId);
              await getApplications();
              toast({
                title: "Application deleted",
                description: "The application has been removed.",
                variant: "success",
              });
            }}
            onPublish={(appId) => handlePublish(appId)}
          />
        )}
      </div>
    </div>
  );
};
