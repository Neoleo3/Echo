"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ENV } from "@/config";

/** Per-step live state, assembled from the transparency socket. */
export interface LiveStep {
  stepId: string;
  name: string;
  status: "running" | "completed" | "failed";
  text: string;
  lastSeq: number;
  error?: string;
}

interface ExecutionFrame {
  event?: string;
  run_id?: string;
  step_id?: string | null;
  timestamp?: string;
  payload?: Record<string, unknown>;
}

export type RunOutcomeKind = "completed" | "failed" | "interrupted";

export interface RunOutcome {
  kind: RunOutcomeKind;
  text?: string;
  error?: string;
  interrupt?: Record<string, unknown>;
}

const socketUrl = (runId: string): string =>
  `${ENV.WS_BASE_URL.replace(/\/$/, "")}/ws/execution/${runId}`;

const asString = (value: unknown): string =>
  typeof value === "string" ? value : "";

const MAX_RETRIES = 3;

export function useExecutionStream(runId: string | null) {
  const [steps, setSteps] = useState<Record<string, LiveStep>>({});
  const [connected, setConnected] = useState(false);
  const [outcome, setOutcome] = useState<RunOutcome | null>(null);
  const [streamUnavailable, setStreamUnavailable] = useState(false);

  const socketRef = useRef<WebSocket | null>(null);
  const retriesRef = useRef(0);
  const closedByUsRef = useRef(false);
  const settledRef = useRef(false);

  const upsert = useCallback(
    (stepId: string, apply: (current: LiveStep) => LiveStep) => {
      setSteps((prev) => {
        const current: LiveStep = prev[stepId] ?? {
          stepId,
          name: "",
          status: "running",
          text: "",
          lastSeq: -1,
        };
        return { ...prev, [stepId]: apply(current) };
      });
    },
    [],
  );

  const handleFrame = useCallback(
    (frame: ExecutionFrame) => {
      const stepId = asString(frame.step_id);
      const payload = frame.payload ?? {};

      switch (frame.event) {
        case "run_completed": {
          if (payload.status === "interrupted" && payload.interrupt) {
            settledRef.current = true;
            setOutcome({
              kind: "interrupted",
              interrupt: payload.interrupt as Record<string, unknown>,
            });
            return;
          }
          settledRef.current = true;
          setOutcome({
            kind: "completed",
            text: asString(payload.final_response),
          });
          return;
        }

        case "run_failed":
          settledRef.current = true;
          setOutcome({
            kind: "failed",
            error: asString(payload.error) || "The run failed.",
          });
          return;

        default:
          break;
      }

      if (!stepId) return;

      switch (frame.event) {
        case "step_started":
          upsert(stepId, (current) => ({
            ...current,
            name: asString(payload.step_name) || current.name,
            status: "running",
          }));
          break;

        case "step_token": {
          const text = asString(payload.text);
          const seq = typeof payload.seq === "number" ? payload.seq : null;
          if (!text) break;
          upsert(stepId, (current) => {
            // Out-of-order or replayed fragments must not duplicate output.
            if (seq !== null && seq <= current.lastSeq) return current;
            return {
              ...current,
              name: asString(payload.step_name) || current.name,
              text: current.text + text,
              lastSeq: seq ?? current.lastSeq,
              status: "running",
            };
          });
          break;
        }

        case "step_output":
          upsert(stepId, (current) => ({
            ...current,
            text: asString(payload.output) || current.text,
          }));
          break;

        case "step_completed": {
          const summary = (payload.output_summary ?? {}) as Record<
            string,
            unknown
          >;
          const preview = asString(summary.output_preview);
          upsert(stepId, (current) => ({
            ...current,
            status: "completed",
            // Authoritative — replace, never append.
            text: preview || current.text,
          }));
          break;
        }

        case "step_failed":
          upsert(stepId, (current) => ({
            ...current,
            status: "failed",
            error: asString(payload.error) || "Step failed",
          }));
          break;

        default:
          // An event this client does not know is not an error.
          break;
      }
    },
    [upsert],
  );

  useEffect(() => {
    if (!runId) {
      setSteps({});
      setOutcome(null);
      return;
    }

    setSteps({});
    setOutcome(null);
    setStreamUnavailable(false);
    settledRef.current = false;

    closedByUsRef.current = false;
    retriesRef.current = 0;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    const open = () => {
      let socket: WebSocket;
      try {
        socket = new WebSocket(socketUrl(runId));
      } catch {
        return;
      }
      socketRef.current = socket;

      socket.onopen = () => {
        retriesRef.current = 0;
        setConnected(true);
        setStreamUnavailable(false);
      };

      socket.onmessage = (message) => {
        try {
          handleFrame(JSON.parse(message.data as string) as ExecutionFrame);
        } catch {
          /* A frame this client cannot parse is skipped, not fatal. */
        }
      };

      socket.onclose = () => {
        setConnected(false);
        if (settledRef.current) return;
        if (closedByUsRef.current) return;
        if (retriesRef.current >= MAX_RETRIES) {
          setStreamUnavailable(true);
          return;
        }
        retriesRef.current += 1;
        retryTimer = setTimeout(open, 1000 * retriesRef.current);
      };

      socket.onerror = () => socket.close();
    };

    open();

    return () => {
      closedByUsRef.current = true;
      if (retryTimer) clearTimeout(retryTimer);
      socketRef.current?.close();
      socketRef.current = null;
    };
  }, [runId, handleFrame]);

  return { steps: Object.values(steps), connected, outcome, streamUnavailable };
}
