"use client";

import { useCallback, useRef, useState } from "react";
import { workflowsService } from "@/services/workflows.service";
import type {
  AuraAgent,
  CanvasConnection,
  CanvasNode,
  WorkflowDesignResult,
} from "@/types/workflow.types";

export interface DesignTurn {
  id: string;
  role: "user" | "assistant";
  text: string;
  questions?: string[];
  degradedNotice?: string;
  failed?: boolean;
}

export interface DesignedCanvas {
  nodes: CanvasNode[];
  connections: CanvasConnection[];
  name?: string;
}

let turnId = 0;
const nextTurnId = (): string => `turn_${++turnId}`;

const summarise = (result: WorkflowDesignResult): string => {
  const count = result.agent_count ?? result.agents?.length ?? 0;
  const score = result.dag_evaluation?.score;
  const verdict = result.dag_evaluation?.verdict;
  const parts = [
    `Designed a workflow with ${count} agent${count === 1 ? "" : "s"}.`,
  ];
  if (typeof score === "number") {
    parts.push(
      `Quality score ${score.toFixed(0)}/100${verdict ? ` — ${verdict}` : ""}.`,
    );
  }
  parts.push("It is on the canvas now; edit anything before saving.");
  return parts.join(" ");
};

export function useWorkflowDesignChat() {
  const [turns, setTurns] = useState<DesignTurn[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const agentsRef = useRef<AuraAgent[]>([]);
  const specRef = useRef<WorkflowDesignResult["echo_spec"] | null>(null);

  const say = useCallback((turn: Omit<DesignTurn, "id">) => {
    setTurns((prev) => [...prev, { ...turn, id: nextTurnId() }]);
  }, []);

  const specToCanvas = useCallback(
    async (result: WorkflowDesignResult): Promise<DesignedCanvas | null> => {
      const spec = result.echo_spec ?? specRef.current ?? null;
      if (!spec?.workflow) return null;

      const canvas = await workflowsService.toCanvas(
        spec.workflow,
        spec.agents ?? {},
      );
      if (!canvas.success || !canvas.data) {
        setError(
          canvas.error ?? "The design could not be opened on the canvas.",
        );
        return null;
      }

      return {
        nodes: canvas.data.canvas_nodes ?? [],
        connections: canvas.data.connections ?? [],
        name: canvas.data.workflow_name || result.workflow_name,
      };
    },
    [],
  );

  const send = useCallback(
    async (prompt: string): Promise<DesignedCanvas | null> => {
      const text = prompt.trim();
      if (!text || busy) return null;

      setBusy(true);
      setError(null);
      say({ role: "user", text });

      const isRefinement = agentsRef.current.length > 0;
      const response = isRefinement
        ? await workflowsService.modifyDesign(agentsRef.current, text)
        : await workflowsService.designFromPrompt(text);

      if (!response.success || !response.data) {
        const reason = response.error ?? "The design could not be generated.";
        setError(reason);
        say({ role: "assistant", text: reason, failed: true });
        setBusy(false);
        return null;
      }

      const result = response.data;

      /* Refused outright — not an error, and not something to retry blindly. */
      if (result.final_event === "workflow_rejected") {
        say({
          role: "assistant",
          text:
            result.reason ||
            "That does not look like a workflow I can build. Try describing it as a task with steps.",
          failed: true,
        });
        setBusy(false);
        return null;
      }

      if (Array.isArray(result.agents)) agentsRef.current = result.agents;
      if (result.echo_spec?.workflow) specRef.current = result.echo_spec;

      const canvas = await specToCanvas(result);
      setBusy(false);

      if (!canvas) {
        say({
          role: "assistant",
          text: "The design came back but could not be laid out on the canvas.",
          failed: true,
        });
        return null;
      }

      say({
        role: "assistant",
        text: summarise(result),
        questions: result.clarification_questions?.length
          ? result.clarification_questions
          : undefined,
        degradedNotice: result.degraded
          ? result.notice ||
            "No model was available, so this is a generic template rather than one tailored to your description. Configure an LLM and try again."
          : undefined,
      });

      return canvas;
    },
    [busy, say, specToCanvas],
  );

  const reset = useCallback(() => {
    setTurns([]);
    setError(null);
    agentsRef.current = [];
    specRef.current = null;
  }, []);

  return { turns, busy, error, send, reset };
}
