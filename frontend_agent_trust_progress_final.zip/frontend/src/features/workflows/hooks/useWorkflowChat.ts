"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { workflowsService } from "@/services/workflows.service";
import { useExecutionStream } from "./useExecutionStream";
import type {
  HitlInterrupt,
  WorkflowChatMessage,
} from "@/types/workflow.types";

let localId = 0;
const nextLocalId = (): string => `local_${++localId}`;

/** Server messages arrive as loose dicts; keep only what renders. */
const toMessage = (
  raw: Record<string, unknown>,
): WorkflowChatMessage | null => {
  const role =
    raw.role === "user" || raw.role === "assistant" ? raw.role : null;
  if (!role) return null;
  const content = typeof raw.content === "string" ? raw.content : "";
  return {
    id: typeof raw.id === "string" ? raw.id : nextLocalId(),
    role,
    content,
    timestamp: typeof raw.timestamp === "string" ? raw.timestamp : undefined,
    run_id: typeof raw.run_id === "string" ? raw.run_id : null,
  };
};

export function useWorkflowChat(workflowId: string | null) {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<WorkflowChatMessage[]>([]);
  const [runId, setRunId] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { steps, outcome } = useExecutionStream(runId);

  /** The assistant row awaiting this run's answer. */
  const pendingIdRef = useRef<string | null>(null);

  /* A different workflow is a different conversation. */
  useEffect(() => {
    setSessionId(null);
    setMessages([]);
    setRunId(null);
    setError(null);
    pendingIdRef.current = null;
  }, [workflowId]);

  const settle = useCallback(
    (apply: (message: WorkflowChatMessage) => WorkflowChatMessage) => {
      const pendingId = pendingIdRef.current;
      if (!pendingId) return;
      pendingIdRef.current = null;
      setMessages((prev) =>
        prev.map((message) =>
          message.id === pendingId ? apply(message) : message,
        ),
      );
    },
    [],
  );

  /* Close the open turn once the socket reports how the run ended. */
  useEffect(() => {
    if (!outcome) return;

    if (outcome.kind === "completed") {
      settle((message) => ({
        ...message,
        pending: false,
        content:
          outcome.text?.trim() ||
          "The workflow finished without producing any output.",
      }));
      return;
    }

    if (outcome.kind === "failed") {
      settle((message) => ({
        ...message,
        pending: false,
        failed: true,
        content: outcome.error || "The run failed.",
      }));
      return;
    }

    settle((message) => ({
      ...message,
      pending: true,
      content: "Waiting for a review decision.",
    }));
  }, [outcome, settle]);

  /** Reuse the session across turns — one per workflow, not one per message. */
  const ensureSession = useCallback(async (): Promise<string | null> => {
    if (sessionId) return sessionId;
    if (!workflowId) {
      setError("Save the workflow before testing it.");
      return null;
    }

    const started = await workflowsService.startChatSession(workflowId);
    if (!started.success || !started.data?.session_id) {
      setError(started.error ?? "Could not start a test session.");
      return null;
    }

    setSessionId(started.data.session_id);
    return started.data.session_id;
  }, [sessionId, workflowId]);

  const send = useCallback(
    async (text: string) => {
      const message = text.trim();
      if (!message || sending) return;

      setSending(true);
      setError(null);

      const session = await ensureSession();
      if (!session) {
        setSending(false);
        return;
      }

      const pendingId = nextLocalId();
      pendingIdRef.current = pendingId;
      setMessages((prev) => [
        ...prev,
        { id: nextLocalId(), role: "user", content: message },
        { id: pendingId, role: "assistant", content: "", pending: true },
      ]);

      const sent = await workflowsService.sendChatMessage(session, message);
      setSending(false);

      if (!sent.success || !sent.data?.run_id) {
        const reason = sent.error ?? "The run did not start.";
        setError(reason);
        settle((entry) => ({
          ...entry,
          pending: false,
          failed: true,
          content: reason,
        }));
        return;
      }

      setRunId(sent.data.run_id);
    },
    [ensureSession, sending, settle],
  );

  /** Pull the stored transcript — what survives a reload. */
  const loadHistory = useCallback(async () => {
    if (!sessionId) return;
    const history = await workflowsService.getChatHistory(sessionId);
    if (!history.success || !history.data) return;
    const stored = (history.data.messages ?? [])
      .map(toMessage)
      .filter((entry): entry is WorkflowChatMessage => entry !== null);
    if (stored.length > 0) setMessages(stored);
  }, [sessionId]);

  const loadFromSession = useCallback(
    (
      incomingSessionId: string,
      rawMessages: Array<Record<string, unknown>>,
    ) => {
      const stored = rawMessages
        .map(toMessage)
        .filter((entry): entry is WorkflowChatMessage => entry !== null);
      setSessionId(incomingSessionId);
      setMessages(stored);
      setRunId(null);
      setError(null);
      pendingIdRef.current = null;
    },
    [],
  );

  /** Start over without losing the workflow. */
  const reset = useCallback(() => {
    setSessionId(null);
    setMessages([]);
    setRunId(null);
    setError(null);
    pendingIdRef.current = null;
  }, []);

  const interrupt =
    outcome?.kind === "interrupted"
      ? (outcome.interrupt as unknown as HitlInterrupt)
      : null;

  return {
    messages,
    steps,
    sessionId,
    runId,
    sending,
    error,
    interrupt,
    awaiting: messages.some((message) => message.pending),
    send,
    loadHistory,
    loadFromSession,
    reset,
  };
}
