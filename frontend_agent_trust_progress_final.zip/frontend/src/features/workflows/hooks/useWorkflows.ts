"use client";

import { useCallback, useEffect, useState } from "react";
import {
  extractWorkflowItems,
  extractWorkflowMeta,
  workflowsService,
} from "@/services/workflows.service";
import type { WorkflowSummary } from "@/types/workflow.types";

export const workflowIdOf = (workflow: WorkflowSummary): string =>
  (workflow.workflow_id as string) ?? (workflow.id as string) ?? "";

export const nodeCountOf = (workflow: WorkflowSummary): number =>
  Array.isArray(workflow.agents) ? workflow.agents.length : 0;

export function useWorkflows() {
  const [workflows, setWorkflows] = useState<WorkflowSummary[]>([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const response = await workflowsService.listDraftWorkflows(
      page,
      pageSize,
      search,
    );
    setLoading(false);
    if (response.success && response.data) {
      const items = extractWorkflowItems(response.data);
      const meta = extractWorkflowMeta(response.data, page, pageSize);
      setWorkflows(items);
      setTotal(meta.total);
      setError(null);
      return;
    }
    setError(response.error ?? "Could not load workflows.");
  }, [page, pageSize, search]);

  useEffect(() => {
    load();
  }, [load]);

  const remove = useCallback(
    async (workflowId: string) => {
      const response = await workflowsService.deleteWorkflow(workflowId);
      if (!response.success) {
        setError(response.error ?? "Could not delete that workflow.");
        return false;
      }
      await load();
      return true;
    },
    [load],
  );

  const onSearchChange = useCallback((value: string) => {
    setSearch(value);
    setPage(1);
  }, []);

  const onPageSizeChange = useCallback((value: number) => {
    setPageSize(value);
    setPage(1);
  }, []);

  return {
    workflows,
    loading,
    error,
    page,
    pageSize,
    total,
    search,
    reload: load,
    remove,
    onPageChange: setPage,
    onPageSizeChange,
    onSearchChange,
  };
}
