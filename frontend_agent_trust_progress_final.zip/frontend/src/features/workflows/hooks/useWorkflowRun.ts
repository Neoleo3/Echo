"use client";

import { useCallback, useEffect, useState } from "react";
import { workflowsService } from "@/services/workflows.service";
import type {
  HitlInterrupt,
  NodeOutput,
  WorkflowRunStatus,
} from "@/types/workflow.types";

export function useWorkflowRun(runId: string | null) {
  const [status, setStatus] = useState<WorkflowRunStatus | null>(null);
  const [interrupt, setInterrupt] = useState<HitlInterrupt | null>(null);
  const [steps, setSteps] = useState<NodeOutput[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!runId) return;
    setLoading(true);
    const [statusRes, stepsRes] = await Promise.all([
      workflowsService.getHitlStatus(runId),
      workflowsService.getExecutionSteps(runId),
    ]);
    setLoading(false);

    if (statusRes.success && statusRes.data) {
      setStatus(statusRes.data);
      setInterrupt(statusRes.data.interrupt ?? null);
      if (
        !statusRes.data.interrupt &&
        statusRes.data.hitl_outcome === undefined
      ) {
        const contextRes = await workflowsService.getHitlContext(runId);
        if (contextRes.success && contextRes.data)
          setInterrupt(contextRes.data);
      }
    } else {
      setError(statusRes.error ?? "Could not read the run.");
    }

    if (stepsRes.success && stepsRes.data) {
      setSteps(stepsRes.data.steps ?? []);
    }
  }, [runId]);

  useEffect(() => {
    load();
  }, [load]);

  const decide = useCallback(
    async (
      action: string,
      options?: { actor?: string; rationale?: string; editFeedback?: string },
    ) => {
      if (!runId) return;
      setError(null);
      const response = await workflowsService.decideHitl({
        run_id: runId,
        action,
        actor: options?.actor,
        rationale: options?.rationale,
        payload:
          action === "edit" && options?.editFeedback
            ? { changes: { edit_feedback: options.editFeedback } }
            : undefined,
      });
      if (!response.success) {
        setError(response.error ?? "That decision was refused.");
        return;
      }
      await load();
    },
    [runId, load],
  );
  const nodeOutputs = [...(status?.all_node_outputs ?? steps)].sort(
    (a, b) => (a.seq ?? 0) - (b.seq ?? 0),
  );

  return {
    status,
    interrupt,
    nodeOutputs,
    loading,
    error,
    reload: load,
    decide,
  };
}
