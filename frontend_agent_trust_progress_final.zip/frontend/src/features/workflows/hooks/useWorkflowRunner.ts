"use client";

import { useCallback, useState } from "react";
import { workflowsService } from "@/services/workflows.service";

export function useWorkflowRunner() {
  const [runId, setRunId] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(
    async (workflowId: string, message = "Run this workflow.") => {
      if (!workflowId) {
        setError("Save the workflow before running it.");
        return null;
      }

      setStarting(true);
      setError(null);

      const started = await workflowsService.startChatSession(workflowId);
      if (!started.success || !started.data?.session_id) {
        setStarting(false);
        setError(started.error ?? "Could not start a test session.");
        return null;
      }

      const session = started.data.session_id;
      setSessionId(session);

      const sent = await workflowsService.sendChatMessage(session, message);
      setStarting(false);

      if (!sent.success || !sent.data?.run_id) {
        setError(sent.error ?? "The run did not start.");
        return null;
      }

      setRunId(sent.data.run_id);
      return sent.data.run_id;
    },
    [],
  );

  const reset = useCallback(() => {
    setRunId(null);
    setSessionId(null);
    setError(null);
  }, []);

  return { runId, sessionId, starting, error, run, reset };
}
