"use client";

import { useCallback, useEffect, useState } from "react";
import { workflowsService } from "@/services/workflows.service";
import { NODE_CATALOG, type NodeCatalogEntry } from "../nodeCatalog";
import type {
  CanvasConnection,
  CanvasNode,
  CanvasNodeConfig,
  WorkflowNodeType,
} from "@/types/workflow.types";

const seedStartNode = (): CanvasNode => ({
  id: 1,
  type: "Start",
  name: "Start",
  label: "Start",
  icon: NODE_CATALOG.Start.icon,
  color: NODE_CATALOG.Start.color,
  description: NODE_CATALOG.Start.description,
  x: 80,
  y: 200,
  status: "configured",
  config: { inputVariables: [] },
});

const nextId = (items: { id: number }[]): number =>
  items.reduce((max, item) => Math.max(max, item.id), 0) + 1;

export interface CanvasState {
  nodes: CanvasNode[];
  connections: CanvasConnection[];
}

export function useWorkflowCanvas(
  workflowId: string | null,
  initialName: string,
) {
  const [nodes, setNodes] = useState<CanvasNode[]>(() =>
    workflowId ? [] : [seedStartNode()],
  );
  const [connections, setConnections] = useState<CanvasConnection[]>([]);
  const [name, setName] = useState(initialName);
  const [savedId, setSavedId] = useState<string | null>(workflowId);
  const [icon, setIcon] = useState("workflow");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [dirty, setDirty] = useState(false);

  /* ---------------- load ---------------- */

  useEffect(() => {
    if (!workflowId) return;
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError(null);

      const detail = await workflowsService.getWorkflow(workflowId);
      if (cancelled) return;
      if (!detail.success || !detail.data) {
        setLoading(false);
        setError(detail.error ?? "Could not load that workflow.");
        return;
      }

      const { workflow, agents } = detail.data as {
        workflow?: unknown;
        agents?: unknown;
      };

      const canvas = await workflowsService.toCanvas(workflow, agents);
      if (cancelled) return;
      setLoading(false);

      if (!canvas.success || !canvas.data) {
        setError(canvas.error ?? "Could not open that workflow on the canvas.");
        return;
      }

      setNodes(canvas.data.canvas_nodes ?? []);
      setConnections(canvas.data.connections ?? []);
      if (canvas.data.workflow_name) setName(canvas.data.workflow_name);
      if (canvas.data.workflow_icon) setIcon(canvas.data.workflow_icon);
      setDirty(false);
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [workflowId]);

  /* ---------------- node editing ---------------- */

  const addNode = useCallback(
    (entry: NodeCatalogEntry, position?: { x: number; y: number }) => {
      setNodes((prev) => {
        const id = nextId(prev);
        const node: CanvasNode = {
          id,
          type: entry.type,
          name: entry.label,
          label: entry.label,
          icon: entry.icon,
          color: entry.color,
          description: entry.description,
          x: position?.x ?? 120 + ((prev.length * 60) % 480),
          y: position?.y ?? 120 + ((prev.length * 90) % 360),
          status: "draft",
          config: { ...entry.defaultConfig },
        };
        return [...prev, node];
      });
      setDirty(true);
    },
    [],
  );

  const moveNode = useCallback((id: number, x: number, y: number) => {
    setNodes((prev) =>
      prev.map((node) => (node.id === id ? { ...node, x, y } : node)),
    );
    setDirty(true);
  }, []);

  const renameNode = useCallback((id: number, name: string) => {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === id ? { ...node, name, label: name } : node,
      ),
    );
    setDirty(true);
  }, []);

  const updateNodeConfig = useCallback(
    (id: number, config: CanvasNodeConfig) => {
      setNodes((prev) =>
        prev.map((node) => (node.id === id ? { ...node, config } : node)),
      );
      setDirty(true);
    },
    [],
  );

  const removeNode = useCallback((id: number) => {
    setNodes((prev) => prev.filter((node) => node.id !== id));
    setConnections((prev) =>
      prev.filter((edge) => edge.from !== id && edge.to !== id),
    );
    setDirty(true);
  }, []);

  /* ---------------- connections ---------------- */

  const connect = useCallback((from: number, to: number) => {
    if (from === to) return;
    setConnections((prev) => {
      const exists = prev.some((edge) => edge.from === from && edge.to === to);
      if (exists) return prev;
      return [...prev, { id: nextId(prev), from, to }];
    });
    setDirty(true);
  }, []);

  const disconnect = useCallback((id: number) => {
    setConnections((prev) => prev.filter((edge) => edge.id !== id));
    setDirty(true);
  }, []);

  const clear = useCallback(() => {
    setNodes([seedStartNode()]);
    setConnections([]);
    setErrors([]);
    setWarnings([]);
    setDirty(true);
  }, []);

  const replaceCanvas = useCallback((state: CanvasState) => {
    setNodes(state.nodes ?? []);
    setConnections(state.connections ?? []);
    setDirty(true);
  }, []);

  const save = useCallback(async () => {
    setSaving(true);
    setError(null);
    setErrors([]);
    setWarnings([]);

    const response = await workflowsService.saveCanvas({
      canvas_nodes: nodes,
      connections,
      workflow_name: name,
      workflow_id: savedId,
      icon,
    });

    setSaving(false);

    if (!response.success || !response.data) {
      setError(response.error ?? "Could not save the workflow.");
      return null;
    }

    const data = response.data;
    /* A validation failure arrives as a 200 with success:false. */
    if (data.success === false) {
      setErrors(data.errors ?? []);
      setWarnings(data.warnings ?? []);
      setError("This workflow could not be saved yet.");
      return null;
    }

    setWarnings(data.warnings ?? []);
    const id =
      (data.workflow_id as string) ??
      (data.workflow as { workflow_id?: string } | undefined)?.workflow_id ??
      null;
    if (id) setSavedId(id);
    setDirty(false);
    return id ?? savedId;
  }, [nodes, connections, name, savedId, icon]);

  return {
    nodes,
    connections,
    name,
    setName,
    icon,
    setIcon,
    savedId,
    loading,
    saving,
    error,
    errors,
    warnings,
    dirty,
    addNode,
    moveNode,
    renameNode,
    updateNodeConfig,
    removeNode,
    connect,
    disconnect,
    clear,
    replaceCanvas,
    save,
  };
}
