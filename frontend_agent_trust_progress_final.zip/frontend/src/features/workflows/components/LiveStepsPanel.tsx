"use client";

import React from "react";
import { useExecutionStream } from "../hooks/useExecutionStream";
import s from "./workflows.module.css";

interface LiveStepsPanelProps {
  runId: string | null;
}

export const LiveStepsPanel: React.FC<LiveStepsPanelProps> = ({ runId }) => {
  const { steps, connected, streamUnavailable } = useExecutionStream(runId);

  if (!runId) return null;
  if (steps.length === 0) {
    return (
      <p className={s.hint}>
        {streamUnavailable
          ? "Could not connect to the live output channel for this run. The run may still be executing — reopen it from the run history to see the result."
          : connected
            ? "Connected — waiting for the run to produce output."
            : "Not receiving live output for this run."}
      </p>
    );
  }

  return (
    <section className={s.live} aria-label="Live output">
      <div className={s.liveHead}>
        <h4 className={s.subHead}>Live output</h4>
        <span className={connected ? s.liveOn : s.liveOff}>
          {connected ? "streaming" : "disconnected"}
        </span>
      </div>

      {steps.map((step) => (
        <div key={step.stepId} className={s.liveStep}>
          <div className={s.nodeHead}>
            <h4 className={s.nodeName}>{step.name || step.stepId}</h4>
            <span
              className={
                step.status === "failed"
                  ? s.liveFailed
                  : step.status === "completed"
                    ? s.liveDone
                    : s.liveRunning
              }
            >
              {step.status}
            </span>
          </div>
          {step.error && <p className={s.errText}>{step.error}</p>}
          {step.text && <pre className={s.outputBlock}>{step.text}</pre>}
        </div>
      ))}
    </section>
  );
};
