"use client";

import React, { useState } from "react";
import { ApiConnectorForm } from "@/features/connectors/components/ApiConnectorForm";
import { McpConnectorForm } from "@/features/connectors/components/McpConnectorForm";
import {
  EMPTY_API_FORM,
  EMPTY_MCP_FORM,
  buildApiPayload,
  buildMcpPayload,
  type ApiFormState,
  type McpFormState,
} from "@/features/connectors/hooks/useConnectorForm";
import { connectorsService } from "@/services/connectors.service";
import s from "./workflows.module.css";

export type ConnectorNodeKind = "api" | "mcp";
export type NodeConfig = Record<string, unknown>;

interface ConnectorNodeConfigProps {
  kind: ConnectorNodeKind;
  config: NodeConfig;
  onChange: (next: NodeConfig) => void;
}

/* ══════════════════════════════════════════════════════════════
   API NODE FORM
══════════════════════════════════════════════════════════════ */
const ApiNodeConfig: React.FC<{
  config: NodeConfig;
  onChange: (next: NodeConfig) => void;
}> = ({ config, onChange }) => {
  // Initialise form state from whatever is already stored on the node config,
  // falling back to the empty defaults from the Connectors module.
  const [form, setForm] = useState<ApiFormState>({
    ...EMPTY_API_FORM,
    name: String(config.name ?? ""),
    description: String(config.description ?? ""),
    logo: String(config.logo ?? ""),
    endpoint_url: String(config.endpoint_url ?? config.url ?? ""),
    method: String(config.method ?? "GET"),
    content_type: String(config.content_type ?? "application/json"),
    timeout: Number(config.timeout ?? 30),
    retry_count: Number(config.retry_count ?? 3),
    verify_ssl: config.verify_ssl !== false,
    headers:
      config.headers &&
      typeof config.headers === "object" &&
      !Array.isArray(config.headers)
        ? (config.headers as Record<string, string>)
        : {},
    query_params:
      config.query_params &&
      typeof config.query_params === "object" &&
      !Array.isArray(config.query_params)
        ? (config.query_params as Record<string, string>)
        : {},
    default_body:
      typeof config.default_body === "string"
        ? config.default_body
        : config.default_body
          ? JSON.stringify(config.default_body, null, 2)
          : "",
    auth_type: String(config.auth_type ?? "none"),
    auth: {},
  });

  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ ok: boolean; msg: string } | null>(
    null,
  );

  const update = <K extends keyof ApiFormState>(
    key: K,
    value: ApiFormState[K],
  ) => setForm((prev) => ({ ...prev, [key]: value }));

  const setAuthType = (authType: string) =>
    setForm((prev) => ({ ...prev, auth_type: authType, auth: {} }));

  const updateAuth = (field: string, value: unknown) =>
    setForm((prev) => ({ ...prev, auth: { ...prev.auth, [field]: value } }));

  const handleSave = async () => {
    if (!form.name.trim()) {
      setNotice({ ok: false, msg: "Name is required." });
      return;
    }
    if (!form.endpoint_url.trim()) {
      setNotice({ ok: false, msg: "Endpoint URL is required." });
      return;
    }
    setSaving(true);
    setNotice(null);
    try {
      const payload = buildApiPayload(form);
      const result = await connectorsService.createAPIConnector(payload);
      // Propagate the saved connector id + config back up to the canvas node
      onChange({
        ...config,
        ...payload,
        connector_id: (result as { id?: string })?.id ?? undefined,
      });
      setNotice({ ok: true, msg: "API connector saved." });
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Failed to save connector.";
      setNotice({ ok: false, msg: message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={s.connectorNodeWrap}>
      <div className={s.connectorNodeBody}>
        <ApiConnectorForm
          form={form}
          update={update}
          onAuthTypeChange={setAuthType}
          onAuthValueChange={updateAuth}
        />
      </div>
      <div className={s.connectorNodeFoot}>
        {notice && (
          <p className={notice.ok ? s.saveNoticeOk : s.saveNoticeErr}>
            {notice.msg}
          </p>
        )}
        <button
          type="button"
          className={s.primaryBtn}
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? "Saving…" : "Save connector"}
        </button>
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════
   MCP NODE FORM
══════════════════════════════════════════════════════════════ */
const McpNodeConfig: React.FC<{
  config: NodeConfig;
  onChange: (next: NodeConfig) => void;
}> = ({ config, onChange }) => {
  const [form, setForm] = useState<McpFormState>({
    ...EMPTY_MCP_FORM,
    name: String(config.name ?? ""),
    description: String(config.description ?? ""),
    icon: String(config.icon ?? ""),
    transport_type: String(config.transport_type ?? "streamable_http"),
    endpoint_url: String(config.endpoint_url ?? ""),
    headers:
      config.headers &&
      typeof config.headers === "object" &&
      !Array.isArray(config.headers)
        ? (config.headers as Record<string, string>)
        : {},
    timeout: Number(config.timeout ?? 30),
    enabled: config.enabled !== false,
    command: String(config.command ?? ""),
    args: Array.isArray(config.args) ? (config.args as string[]) : [],
    env_vars:
      config.env_vars &&
      typeof config.env_vars === "object" &&
      !Array.isArray(config.env_vars)
        ? (config.env_vars as Record<string, string>)
        : {},
    working_dir: String(config.working_dir ?? ""),
    shell: Boolean(config.shell),
    auth_type: String(config.auth_type ?? "none"),
    auth: {},
  });

  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ ok: boolean; msg: string } | null>(
    null,
  );

  const update = <K extends keyof McpFormState>(
    key: K,
    value: McpFormState[K],
  ) => setForm((prev) => ({ ...prev, [key]: value }));

  const setAuthType = (authType: string) =>
    setForm((prev) => ({ ...prev, auth_type: authType, auth: {} }));

  const updateAuth = (field: string, value: unknown) =>
    setForm((prev) => ({ ...prev, auth: { ...prev.auth, [field]: value } }));

  const handleSave = async () => {
    if (!form.name.trim()) {
      setNotice({ ok: false, msg: "Name is required." });
      return;
    }
    const isStdio = form.transport_type === "stdio";
    if (!isStdio && !form.endpoint_url.trim()) {
      setNotice({ ok: false, msg: "Server URL is required." });
      return;
    }
    if (isStdio && !form.command.trim()) {
      setNotice({ ok: false, msg: "Command is required for stdio transport." });
      return;
    }
    setSaving(true);
    setNotice(null);
    try {
      const payload = buildMcpPayload(form);
      const result = await connectorsService.createMCPConnector(payload);
      onChange({
        ...config,
        ...payload,
        connector_id: (result as { id?: string })?.id ?? undefined,
      });
      setNotice({ ok: true, msg: "MCP connector saved." });
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Failed to save connector.";
      setNotice({ ok: false, msg: message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={s.connectorNodeWrap}>
      <div className={s.connectorNodeBody}>
        <McpConnectorForm
          form={form}
          update={update}
          onAuthTypeChange={setAuthType}
          onAuthValueChange={updateAuth}
        />
      </div>
      <div className={s.connectorNodeFoot}>
        {notice && (
          <p className={notice.ok ? s.saveNoticeOk : s.saveNoticeErr}>
            {notice.msg}
          </p>
        )}
        <button
          type="button"
          className={s.primaryBtn}
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? "Saving…" : "Save connector"}
        </button>
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════
   EXPORTED CONNECTOR NODE CONFIG
══════════════════════════════════════════════════════════════ */
export const ConnectorNodeConfig: React.FC<ConnectorNodeConfigProps> = ({
  kind,
  config,
  onChange,
}) => {
  if (kind === "api") {
    return <ApiNodeConfig config={config} onChange={onChange} />;
  }
  return <McpNodeConfig config={config} onChange={onChange} />;
};
