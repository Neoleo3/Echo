"use client";

import React from "react";
import type {
  AgentResolution,
  NodeOutput,
  WorkflowRunStatus,
} from "@/types/workflow.types";
import s from "./workflows.module.css";

interface RunOutputsProps {
  status: WorkflowRunStatus | null;
  nodeOutputs: NodeOutput[];
}

const asText = (value: unknown): string => {
  if (value == null) return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
};

const NodeBody: React.FC<{ node: NodeOutput }> = ({ node }) => {
  if (node.node_type === "hitl" && node.decision) {
    const { action, actor, rationale, reviewed_node } = node.decision;
    return (
      <p className={s.nodeNote}>
        <strong>{action}</strong>
        {actor ? ` by ${actor}` : ""}
        {reviewed_node ? ` on ${reviewed_node}` : ""}
        {rationale ? ` — ${rationale}` : ""}
      </p>
    );
  }

  if (node.node_type === "review") {
    return (
      <div className={s.nodeNote}>
        <p>
          <strong>{node.passed ? "Passed" : "Did not pass"}</strong>
          {typeof node.confidence === "number"
            ? ` · confidence ${node.confidence}`
            : ""}
        </p>
        {node.feedback && <p>{node.feedback}</p>}
        {node.issues && node.issues.length > 0 && (
          <ul className={s.issueList}>
            {node.issues.map((issue, i) => (
              <li key={i}>{asText(issue)}</li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  const body = asText(node.output);
  return body ? <pre className={s.outputBlock}>{body}</pre> : null;
};

export const RunOutputs: React.FC<RunOutputsProps> = ({
  status,
  nodeOutputs,
}) => {
  const rejected = status?.status === "hitl_rejected";
  const editing = status?.hitl_outcome === "editing";
  const resolution = (status?.agent_resolution ?? {}) as Record<
    string,
    AgentResolution
  >;
  const resolutionEntries = Object.entries(resolution);

  return (
    <div className={s.run}>
      {rejected && (
        <div className={s.rejected}>
          <h3 className={s.rejectedTitle}>Rejected at review</h3>
          <p className={s.hint}>
            A reviewer stopped this run. It did not fail — it was declined.
          </p>
        </div>
      )}

      {editing && (
        <p className={s.hint}>
          Changes were requested. The previous step is re-running and will
          return to the same checkpoint.
        </p>
      )}

      {nodeOutputs.length === 0 ? (
        <p className={s.hint}>No step output yet.</p>
      ) : (
        nodeOutputs.map((node, index) => (
          <section
            key={`${node.node_id ?? node.node_name ?? index}-${index}`}
            className={s.node}
          >
            <div className={s.nodeHead}>
              <h4 className={s.nodeName}>
                {node.node_name || node.node_id || `Step ${index + 1}`}
              </h4>
              {node.node_type && (
                <span className={s.nodeKind}>{node.node_type}</span>
              )}
            </div>
            <NodeBody node={node} />
          </section>
        ))
      )}

      {resolutionEntries.length > 0 && (
        <section className={s.attribution}>
          <h4 className={s.subHead}>Agents used</h4>
          <ul className={s.attrList}>
            {resolutionEntries.map(([key, entry]) => (
              <li key={key} className={s.attrRow}>
                <span className={s.attrName}>{entry.name || key}</span>
                <span className={s.attrMeta}>
                  {entry.source === "embedded" ? "saved copy" : entry.source}
                  {entry.config_version ? ` · v${entry.config_version}` : ""}
                </span>
                {entry.source === "embedded" && (
                  <span className={s.warnBadge}>Referenced agent missing</span>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};
