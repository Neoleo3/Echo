"use client";

import React, { useCallback, useEffect, useState } from "react";
import { extractAgentItems, agentsService } from "@/services/agents.service";
import { AgentConfigureForm, useAgentDraft } from "@/features/agents";
import type { CanvasNodeConfig, CanvasNode } from "@/types/workflow.types";
import s from "./workflows.module.css";
import { AgentDefinition } from "@/types/agents.types";

interface AgentNodeConfigProps {
  node: CanvasNode;
  onChange: (config: CanvasNodeConfig) => void;
  onRename: (name: string) => void;
  onClose: () => void;
}

const firstId = (value: unknown): string | null =>
  typeof value === "string" && value.trim() ? value : null;

const mirrorOntoNode = (
  config: CanvasNodeConfig,
  agent: AgentDefinition,
): CanvasNodeConfig => {
  const model = agent.model_config ?? {};
  return {
    ...config,
    agent_id: agent.agent_id,
    description: agent.description ?? "",
    prompt: agent.instructions ?? agent.prompt ?? "",
    icon: agent.icon ?? config.icon,
    // tools: Array.isArray(agent.tools) ? agent.tools : [],
    tools: Array.isArray(agent.tools)
      ? agent.tools
          .map((t) =>
            typeof t === "string"
              ? t
              : ((t as { tool_id?: string }).tool_id ?? ""),
          )
          .filter(Boolean)
      : [],
    model: {
      modelName: model.model ?? "",
      provider: model.provider ?? "",
      credentialId: agent.credential_id ?? "",
    },
    temperature: model.temperature,
    topP: model.top_p,
    maxTokens: model.max_tokens,
  };
};

export const AgentNodeConfig: React.FC<AgentNodeConfigProps> = ({
  node,
  onChange,
  onRename,
  onClose,
}) => {
  const config = node.config ?? {};

  const linkedId =
    firstId(config.agent_id) ??
    firstId(node.backend_id) ??
    firstId(node.agentId);

  const [agents, setAgents] = useState<AgentDefinition[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const draft = useAgentDraft();

  useEffect(() => {
    let cancelled = false;
    agentsService.listAgents().then((response) => {
      if (cancelled) return;
      if (response.success) {
        setAgents(extractAgentItems(response.data));
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!linkedId) {
      const model =
        config.model && typeof config.model === "object"
          ? (config.model as Record<string, unknown>)
          : {};

      draft.loadDraft({
        agent_id: undefined,
        name: node.name ?? "",
        description:
          typeof config.description === "string" ? config.description : "",
        instructions:
          typeof config.prompt === "string"
            ? config.prompt
            : typeof (config as Record<string, unknown>).instructions ===
                "string"
              ? String((config as Record<string, unknown>).instructions)
              : "",
        icon: typeof config.icon === "string" ? config.icon : "",
        // tools: Array.isArray(config.tools) ? (config.tools as string[]) : [],
        tools: Array.isArray(config.tools)
          ? (config.tools as unknown[])
              .map((t) =>
                typeof t === "string"
                  ? t
                  : ((t as { tool_id?: string }).tool_id ?? ""),
              )
              .filter(Boolean)
          : [],
        credential_id:
          typeof model.credentialId === "string" ? model.credentialId : "",
        model_config: {
          model: typeof model.modelName === "string" ? model.modelName : "",
          provider: typeof model.provider === "string" ? model.provider : "",
          temperature:
            typeof config.temperature === "number" ? config.temperature : 0.7,
          top_p: typeof config.topP === "number" ? config.topP : 0.9,
          ...(typeof config.maxTokens === "number"
            ? { max_tokens: config.maxTokens }
            : {}),
        },
      });
      return;
    }

    let cancelled = false;
    setLoading(true);
    setLoadError(null);

    agentsService.getAgent(linkedId).then((response) => {
      if (cancelled) return;
      setLoading(false);
      if (!response.success || !response.data) {
        setLoadError(
          response.error ??
            "That agent could not be read. It may have been deleted.",
        );
        return;
      }
      draft.loadFrom(response.data);

      onChange(mirrorOntoNode(config, response.data));
    });

    return () => {
      cancelled = true;
    };
  }, [linkedId, node.id]);

  const chooseAgent = (agentId: string) => {
    setNotice(null);
    setLoadError(null);
    if (!agentId) {
      draft.reset();
      onChange({ ...config, agent_id: "" });
      return;
    }
    const picked = agents.find((entry) => entry.agent_id === agentId);
    onChange({ ...config, agent_id: agentId });
    if (picked?.name) onRename(picked.name);
  };

  const adopt = useCallback(
    async (agentId: string) => {
      const saved = await agentsService.getAgent(agentId);
      if (!saved.success || !saved.data) {
        onChange({ ...config, agent_id: agentId });
        return;
      }
      onChange(mirrorOntoNode(config, saved.data));
      if (saved.data.name) onRename(saved.data.name);
      setAgents((prev) =>
        prev.some((entry) => entry.agent_id === agentId)
          ? prev.map((entry) =>
              entry.agent_id === agentId ? saved.data! : entry,
            )
          : [...prev, saved.data!],
      );
    },
    [config, onChange, onRename],
  );

  const handleSave = async () => {
    setNotice(null);
    const agentId = await draft.save();
    if (!agentId) return;
    await adopt(agentId);
    setNotice("Agent saved.");
    onClose();
  };

  const handleEnsureAgent = async (): Promise<string | null> => {
    const agentId = await draft.ensureSaved();
    if (agentId) await adopt(agentId);
    return agentId;
  };

  const agentId = draft.savedId ?? linkedId;

  return (
    <>
      <label className={s.field}>
        <span className={s.fieldLabel}>Agent</span>
        <select
          value={linkedId ?? ""}
          onChange={(e) => chooseAgent(e.target.value)}
        >
          <option value="">New agent — describe it below</option>
          {agents.map((agent) => (
            <option key={agent.agent_id} value={agent.agent_id}>
              {agent.name}
            </option>
          ))}
        </select>
        <span className={s.hint}>
          Pick an agent you already have, or leave this on <em>New agent</em>{" "}
          and define one here. Either way it becomes a normal agent you can
          reuse anywhere.
        </span>
      </label>

      {loading && <p className={s.hint}>Loading agent…</p>}
      {loadError && <p className={s.errText}>{loadError}</p>}
      {notice && <p className={s.noticeText}>{notice}</p>}

      {!loading && !loadError && !linkedId && (
        <p className={s.hint}>
          This step isn’t linked to a saved agent yet. Pick one above, or fill
          this in and save to create one.
        </p>
      )}

      {!loading && (
        <AgentConfigureForm
          form={draft.form}
          update={draft.update}
          updateModelConfig={draft.updateModelConfig}
          onSave={handleSave}
          onCancel={onClose}
          saving={draft.saving}
          error={draft.error}
          agentId={agentId}
          ensureAgent={handleEnsureAgent}
        />
      )}
    </>
  );
};
