"use client";

import React, { useEffect, useRef } from "react";
import { AgentNodeConfig } from "./AgentNodeConfig";
import { ConnectorNodeConfig } from "./ConnectorNodeConfig";
import { RETIRED_NODE_TYPES } from "../nodeCatalog";
import type {
  CanvasNode,
  CanvasNodeConfig,
  CanvasVariable,
} from "@/types/workflow.types";
import s from "./workflows.module.css";

interface NodeInspectorProps {
  node: CanvasNode;
  onChange: (config: CanvasNodeConfig) => void;
  onRename: (name: string) => void;
  onClose: () => void;
}

const VariableList: React.FC<{
  label: string;
  variables: CanvasVariable[];
  onChange: (next: CanvasVariable[]) => void;
}> = ({ label, variables, onChange }) => (
  <div className={s.field}>
    <span className={s.fieldLabel}>{label}</span>
    {variables.map((variable, index) => (
      <div key={index} className={s.varRow}>
        <input
          type="text"
          value={variable.name}
          placeholder="name"
          onChange={(e) =>
            onChange(
              variables.map((item, i) =>
                i === index ? { ...item, name: e.target.value } : item,
              ),
            )
          }
        />
        <button
          type="button"
          className={s.ghostBtn}
          onClick={() => onChange(variables.filter((_, i) => i !== index))}
        >
          Remove
        </button>
      </div>
    ))}
    <button
      type="button"
      className={s.ghostBtn}
      onClick={() => onChange([...variables, { name: "" }])}
    >
      + Add
    </button>
  </div>
);

export const NodeInspector: React.FC<NodeInspectorProps> = ({
  node,
  onChange,
  onRename,
  onClose,
}) => {
  const config = node.config ?? {};
  const patch = (changes: CanvasNodeConfig) =>
    onChange({ ...config, ...changes });

  const needsAgent = node.type === "Agent" || node.type === "Subagent";
  const retired = RETIRED_NODE_TYPES[node.type as string];
  const panelRef = useRef<HTMLDivElement>(null);

  /* Close on Escape */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  /* Trap focus inside the modal */
  useEffect(() => {
    panelRef.current?.focus();
  }, []);

  return (
    /* Backdrop */
    <div
      className={s.inspectorOverlay}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={`Configure ${node.type} node`}
    >
      {/* Modal card */}
      <div
        className={s.inspectorModal}
        ref={panelRef}
        tabIndex={-1}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className={s.inspectorModalHead}>
          <div className={s.inspectorModalHeadLeft}>
            <span className={s.inspectorTypeBadge}>{node.type}</span>
            <h3 className={s.inspectorTitle}>{node.name || node.label}</h3>
          </div>
          <button
            type="button"
            className={s.inspectorCloseBtn}
            onClick={onClose}
            aria-label="Close"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Modal body — scrollable */}
        <div className={s.inspectorModalBody}>
          {retired && <p className={s.warnText}>{retired}</p>}

          {/* Name field (not for agent-typed nodes — agent form owns the name) */}
          {!needsAgent && (
            <label className={s.field}>
              <span className={s.fieldLabel}>Name</span>
              <input
                type="text"
                value={node.name}
                onChange={(e) => onRename(e.target.value)}
              />
            </label>
          )}

          {/* ---- Start ---- */}
          {node.type === "Start" && (
            <>
              <VariableList
                label="Input variables"
                variables={config.inputVariables ?? []}
                onChange={(next) => patch({ inputVariables: next })}
              />
              <label className={s.checkRow}>
                <input
                  type="checkbox"
                  checked={Boolean(config.fileUploadConfig?.enabled)}
                  onChange={(e) =>
                    patch({
                      fileUploadConfig: {
                        ...(config.fileUploadConfig ?? {}),
                        enabled: e.target.checked,
                      },
                    })
                  }
                />
                <span>
                  <span className={s.radioLabel}>Accept file uploads</span>
                  <span className={s.radioHint}>
                    Lets a run start with a document attached.
                  </span>
                </span>
              </label>
            </>
          )}

          {/* ---- End ---- */}
          {node.type === "End" && (
            <VariableList
              label="Output variables"
              variables={config.outputVariables ?? []}
              onChange={(next) => patch({ outputVariables: next })}
            />
          )}

          {/* ---- Agent / Subagent ---- */}
          {needsAgent && (
            <AgentNodeConfig
              node={node}
              onChange={onChange}
              onRename={onRename}
              onClose={onClose}
            />
          )}

          {/* ---- Conditional ---- */}
          {node.type === "Conditional" && (
            <div className={s.field}>
              <span className={s.fieldLabel}>Branches</span>
              {(config.branches ?? []).map((branch, index) => (
                <div key={index} className={s.varRow}>
                  <input
                    type="text"
                    placeholder="label"
                    value={branch.label ?? ""}
                    onChange={(e) =>
                      patch({
                        branches: (config.branches ?? []).map((item, i) =>
                          i === index
                            ? { ...item, label: e.target.value }
                            : item,
                        ),
                      })
                    }
                  />
                  <input
                    type="text"
                    placeholder="condition"
                    value={branch.condition ?? ""}
                    onChange={(e) =>
                      patch({
                        branches: (config.branches ?? []).map((item, i) =>
                          i === index
                            ? { ...item, condition: e.target.value }
                            : item,
                        ),
                      })
                    }
                  />
                  <button
                    type="button"
                    className={s.ghostBtn}
                    onClick={() =>
                      patch({
                        branches: (config.branches ?? []).filter(
                          (_, i) => i !== index,
                        ),
                      })
                    }
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                type="button"
                className={s.ghostBtn}
                onClick={() =>
                  patch({
                    branches: [
                      ...(config.branches ?? []),
                      { label: "", condition: "" },
                    ],
                  })
                }
              >
                + Add branch
              </button>
            </div>
          )}

          {/* ---- HITL ---- */}
          {node.type === "HITL" && (
            <>
              <label className={s.field}>
                <span className={s.fieldLabel}>Title</span>
                <input
                  type="text"
                  value={config.title ?? ""}
                  onChange={(e) => patch({ title: e.target.value })}
                />
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Message to the reviewer</span>
                <textarea
                  rows={3}
                  value={config.message ?? ""}
                  onChange={(e) => patch({ message: e.target.value })}
                />
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Priority</span>
                <select
                  value={config.priority ?? "medium"}
                  onChange={(e) => patch({ priority: e.target.value })}
                >
                  {["low", "medium", "high"].map((level) => (
                    <option key={level} value={level}>
                      {level}
                    </option>
                  ))}
                </select>
              </label>
              <label className={s.checkRow}>
                <input
                  type="checkbox"
                  checked={config.allowEdit !== false}
                  onChange={(e) => patch({ allowEdit: e.target.checked })}
                />
                <span>
                  <span className={s.radioLabel}>
                    Allow &quot;request changes&quot;
                  </span>
                  <span className={s.radioHint}>
                    Approve and reject are always offered. There is no defer.
                  </span>
                </span>
              </label>
            </>
          )}

          {/* ---- Self-Review ---- */}
          {node.type === "Self-Review" && (
            <>
              <label className={s.checkRow}>
                <input
                  type="checkbox"
                  checked={config.checkCompleteness !== false}
                  onChange={(e) =>
                    patch({ checkCompleteness: e.target.checked })
                  }
                />
                <span>
                  <span className={s.radioLabel}>Check completeness</span>
                </span>
              </label>
              <label className={s.checkRow}>
                <input
                  type="checkbox"
                  checked={config.checkAccuracy !== false}
                  onChange={(e) => patch({ checkAccuracy: e.target.checked })}
                />
                <span>
                  <span className={s.radioLabel}>Check accuracy</span>
                </span>
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>
                  Confidence threshold (
                  {(config.confidenceThreshold ?? 0.8).toFixed(2)})
                </span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={config.confidenceThreshold ?? 0.8}
                  onChange={(e) =>
                    patch({ confidenceThreshold: +e.target.value })
                  }
                />
              </label>
            </>
          )}

          {/* ---- Loop ---- */}
          {node.type === "Loop" && (
            <>
              <label className={s.field}>
                <span className={s.fieldLabel}>Loop type</span>
                <select
                  value={config.loopType ?? "for-each"}
                  onChange={(e) => patch({ loopType: e.target.value })}
                >
                  <option value="for-each">For each</option>
                  <option value="while">While</option>
                </select>
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Array variable</span>
                <input
                  type="text"
                  value={config.arrayVariable ?? ""}
                  onChange={(e) => patch({ arrayVariable: e.target.value })}
                />
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Max iterations</span>
                <input
                  type="number"
                  min={1}
                  value={config.maxIterations ?? 100}
                  onChange={(e) => patch({ maxIterations: +e.target.value })}
                />
              </label>
            </>
          )}

          {/* ---- Map ---- */}
          {node.type === "Map" && (
            <>
              <label className={s.field}>
                <span className={s.fieldLabel}>Operation</span>
                <input
                  type="text"
                  value={config.operation ?? ""}
                  onChange={(e) => patch({ operation: e.target.value })}
                />
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Max concurrency</span>
                <input
                  type="number"
                  min={1}
                  value={config.maxConcurrency ?? 5}
                  onChange={(e) => patch({ maxConcurrency: +e.target.value })}
                />
              </label>
            </>
          )}

          {/* ---- Code ---- */}
          {node.type === "Code" && (
            <>
              <label className={s.field}>
                <span className={s.fieldLabel}>Language</span>
                <select
                  value={config.language ?? "python"}
                  onChange={(e) => patch({ language: e.target.value })}
                >
                  <option value="python">Python</option>
                  <option value="javascript">JavaScript</option>
                </select>
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Code</span>
                <textarea
                  rows={8}
                  className={s.codeArea}
                  value={config.code ?? ""}
                  onChange={(e) => patch({ code: e.target.value })}
                />
              </label>
              <label className={s.field}>
                <span className={s.fieldLabel}>Packages</span>
                <input
                  type="text"
                  placeholder="comma separated"
                  value={config.packages ?? ""}
                  onChange={(e) => patch({ packages: e.target.value })}
                />
              </label>
            </>
          )}

          {/* ---- API / MCP ---- */}
          {(node.type === "API" || node.type === "MCP") && (
            <ConnectorNodeConfig
              kind={node.type === "API" ? "api" : "mcp"}
              config={config as Record<string, unknown>}
              onChange={(next) => onChange(next as CanvasNodeConfig)}
            />
          )}
        </div>
      </div>
    </div>
  );
};
