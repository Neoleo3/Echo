"use client";

import React from "react";

const PATHS: Record<string, React.ReactNode> = {
  /* Start — lightning bolt / zap */
  play: (
    <path
      d="M13 2L4.09 12.36A1 1 0 0 0 5 14h6v8l8.91-10.36A1 1 0 0 0 19 10h-6V2z"
      fill="currentColor"
      stroke="none"
    />
  ),

  /* End — flag */
  stop: (
    <>
      <path d="M4 22V4" strokeLinecap="round" />
      <path
        d="M4 4h12l-2 5 2 5H4"
        fill="currentColor"
        fillOpacity="0.25"
        strokeLinejoin="round"
      />
    </>
  ),

  /* Agent — CPU / brain chip */
  robot: (
    <>
      <rect
        x="4"
        y="4"
        width="16"
        height="16"
        rx="2"
        fill="currentColor"
        fillOpacity="0.2"
      />
      <rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor" />
      <path
        d="M9 2v2M15 2v2M9 20v2M15 20v2M2 9h2M2 15h2M20 9h2M20 15h2"
        strokeLinecap="round"
      />
    </>
  ),

  /* Conditional — git-branch */
  branch: (
    <>
      <circle cx="6" cy="5" r="2" fill="currentColor" />
      <circle cx="18" cy="8" r="2" fill="currentColor" />
      <circle cx="6" cy="19" r="2" fill="currentColor" />
      <path d="M6 7v10M6 10c0 0 4 0 6-2s6-3 6 0" />
    </>
  ),

  /* Loop — arrows-clockwise */
  repeat: (
    <>
      <path d="M21 12a9 9 0 1 1-1.6-5.1" strokeLinecap="round" />
      <path d="M21 3v4h-4" strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),

  /* Map — layers */
  grid: (
    <>
      <path
        d="M2 8l10-5 10 5-10 5-10-5z"
        fill="currentColor"
        fillOpacity="0.25"
        strokeLinejoin="round"
      />
      <path d="M2 16l10 5 10-5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),

  /* HITL — user with checkmark */
  user: (
    <>
      <path
        d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="7" r="4" />
      <path
        d="M16 3.5l1.5 1.5 3-3"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </>
  ),

  /* Self-Review — shield with checkmark */
  check: (
    <>
      <path
        d="M12 2l8 4v6c0 5-3.5 9.3-8 11-4.5-1.7-8-6-8-11V6l8-4z"
        fill="currentColor"
        fillOpacity="0.2"
        strokeLinejoin="round"
      />
      <path
        d="M8.5 12l2.5 2.5 4-4.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </>
  ),

  /* API — globe/network */
  globe: (
    <>
      <circle cx="12" cy="12" r="9" fill="currentColor" fillOpacity="0.1" />
      <path d="M3 12h18" />
      <path d="M12 3c-3.3 4.5-3.3 13.5 0 18" />
      <path d="M12 3c3.3 4.5 3.3 13.5 0 18" />
    </>
  ),

  /* MCP — server */
  plug: (
    <>
      <rect
        x="2"
        y="3"
        width="20"
        height="5"
        rx="2"
        fill="currentColor"
        fillOpacity="0.2"
        strokeLinejoin="round"
      />
      <rect
        x="2"
        y="10"
        width="20"
        height="5"
        rx="2"
        fill="currentColor"
        fillOpacity="0.2"
        strokeLinejoin="round"
      />
      <rect
        x="2"
        y="17"
        width="20"
        height="4"
        rx="2"
        fill="currentColor"
        fillOpacity="0.2"
        strokeLinejoin="round"
      />
      <circle cx="6" cy="5.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="6" cy="12.5" r="1" fill="currentColor" stroke="none" />
    </>
  ),

  /* Code — terminal */
  code: (
    <>
      <rect
        x="2"
        y="4"
        width="20"
        height="16"
        rx="2"
        fill="currentColor"
        fillOpacity="0.1"
      />
      <path
        d="M8 9l-3 3 3 3M16 9l3 3-3 3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M11 18l2-12" strokeLinecap="round" />
    </>
  ),

  /* workflow (generic / fallback) */
  workflow: (
    <>
      <rect
        x="2"
        y="5"
        width="7"
        height="5"
        rx="1.5"
        fill="currentColor"
        fillOpacity="0.25"
      />
      <rect
        x="9"
        y="14"
        width="7"
        height="5"
        rx="1.5"
        fill="currentColor"
        fillOpacity="0.25"
      />
      <rect
        x="16"
        y="5"
        width="6"
        height="5"
        rx="1.5"
        fill="currentColor"
        fillOpacity="0.25"
      />
      <path d="M9 7.5h3.5a1 1 0 0 1 1 1V13" strokeLinecap="round" />
      <path d="M19 10v3.5a1 1 0 0 1-1 1H16" strokeLinecap="round" />
    </>
  ),

  /* agent (person icon) */
  agent: (
    <>
      <circle cx="12" cy="7" r="4" fill="currentColor" fillOpacity="0.25" />
      <path
        d="M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2"
        strokeLinecap="round"
      />
    </>
  ),
};

interface NodeIconProps {
  name: string;
  size?: number;
}

export const NodeIcon: React.FC<NodeIconProps> = ({ name, size = 18 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {PATHS[name] ?? PATHS.workflow}
  </svg>
);
