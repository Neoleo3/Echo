import React, { useState } from "react";
import { Workflow } from "lucide-react";
import { nodeCountOf } from "../hooks/useWorkflows";
import s from "./workflows.module.css";

export interface WorkflowItem {
  workflow_id: string;
  name?: string;
  execution_model?: string;
  agent_count?: number;
}

interface LoadWorkflowModalProps {
  open: boolean;
  onClose: () => void;

  manualWorkflowId: string;
  onManualWorkflowIdChange: (value: string) => void;
  onLoadManualId: (id: string) => void;

  workflows: any[];
  isLoading: boolean;

  selectedWorkflowId: string | null;
  onSelectWorkflow: (workflowId: string) => void;

  onLoadSelectedWorkflow: () => void;
}

export const LoadWorkflowModal: React.FC<LoadWorkflowModalProps> = ({
  open,
  onClose,
  manualWorkflowId,
  onManualWorkflowIdChange,
  onLoadManualId,
  workflows,
  isLoading,
  selectedWorkflowId,
  onSelectWorkflow,
  onLoadSelectedWorkflow,
}) => {
  const [manualId, setManualID] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  if (!open) return null;

  const filteredWorkflows = workflows.filter((wf) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      (wf.name ?? "").toLowerCase().includes(q) ||
      wf.workflow_id.toLowerCase().includes(q)
    );
  });

  return (
    <div
      className={s.lwOverlay}
      onClick={(e) => {
        if (e.target !== e.currentTarget) return;
        onClose();
      }}
    >
      <div className={s.lwModal}>
        <div className={s.lwHeader}>
          <div className={s.lwHeaderLeft}>
            <div className={s.lwIconWrap}>
              <Workflow size={20} />
            </div>

            <div>
              <p className={s.lwTitle}>Load Workflow</p>
              <p className={s.lwSubtitle}>
                Open a saved workflow or load using Workflow ID
              </p>
            </div>
          </div>

          <button className={s.lwCloseBtn} onClick={onClose}>
            ✕
          </button>
        </div>

        {/* Manual Load */}
        <div className={s.lwManual}>
          <p className={s.lwSectionLabel}>Load By Workflow ID</p>
          <div className={s.lwRow}>
            <input
              className={s.lwInput}
              value={manualId}
              onChange={(e) => setManualID(e.target.value)}
              placeholder="wf_abc123…"
            />

            <button
              onClick={() => onLoadManualId(manualId)}
              disabled={!manualId.trim()}
              className={s.lwBtnPrimary}
            >
              Load
            </button>
          </div>
        </div>

        {/* Workflow List */}
        <div className={s.lwListSection}>
          <p className={s.lwSectionLabel}>Saved Drafts</p>

          {/* Search */}
          <div className={s.lwSearch}>
            <svg
              className={s.lwSearchIcon}
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name or ID…"
              className={s.lwSearchInput}
            />
            {searchQuery && (
              <button
                className={s.lwSearchClear}
                onClick={() => setSearchQuery("")}
              >
                ✕
              </button>
            )}
          </div>

          {isLoading ? (
            <div className={s.lwLoading}>
              <div className={s.lwSpinner} />
              <span className={s.lwLoadingText}>Loading workflows…</span>
            </div>
          ) : filteredWorkflows.length === 0 ? (
            <div className={s.lwEmpty}>
              <p className={s.lwEmptyTitle}>
                {workflows.length === 0
                  ? "No draft workflows found"
                  : "No workflows match your search"}
              </p>

              <p className={s.lwEmptySub}>
                {workflows.length === 0
                  ? "Create and save a workflow first."
                  : "Try a different search term."}
              </p>
            </div>
          ) : (
            <div className={s.lwCards}>
              {filteredWorkflows.map((wf) => (
                <div
                  key={wf.workflow_id}
                  className={`${s.lwCard}${selectedWorkflowId === wf.workflow_id ? ` ${s.lwCardSelected}` : ""}`}
                  onClick={() => onSelectWorkflow(wf.workflow_id)}
                >
                  <div className={s.lwCardTop}>
                    <div>
                      <p className={s.lwCardName}>
                        {wf.name || "Untitled Workflow"}
                      </p>
                      <p className={s.lwCardId}>{wf.workflow_id}</p>
                    </div>
                    {wf.execution_model && (
                      <span className={s.lwBadge}>{wf.execution_model}</span>
                    )}
                  </div>
                  <div className={s.lwCardFooter}>
                    <span className={s.lwCardMeta}>
                      {nodeCountOf(wf)} agent(s)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={s.lwFooter}>
          <p className={s.lwFooterHint}>
            Select a workflow and load it into the IDE.
          </p>
          <button
            className={s.lwBtnPrimary}
            onClick={onLoadSelectedWorkflow}
            disabled={!selectedWorkflowId}
          >
            Load Selected Workflow
          </button>
        </div>
      </div>
    </div>
  );
};
