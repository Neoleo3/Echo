"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { HitlReviewPanel } from "./HitlReviewPanel";
import { useWorkflowChat } from "../hooks/useWorkflowChat";
import {
  useWorkflowDesignChat,
  type DesignedCanvas,
} from "../hooks/useWorkflowDesignChat";
import type { HitlDecision } from "@/types/workflow.types";
import s from "./workflows.module.css";
import { STORAGE_KEYS } from "@/config";
import { ENV } from "@/config";

interface WorkflowSidePanelProps {
  workflowId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDesign: (canvas: DesignedCanvas) => void;
  onRequireSaved: () => Promise<string | null>;
  onDecideHitl: (
    runId: string,
    action: HitlDecision | string,
    options?: { rationale?: string; editFeedback?: string },
  ) => Promise<void>;
}

const MIN_WIDTH = 260;
const MAX_WIDTH = 680;
const DEFAULT_WIDTH = 320;

/* ── Mock history entries (replace with real API when available) ── */
interface HistoryEntry {
  id: string;
  title: string;
  ts: string;
}

export const WorkflowSidePanel: React.FC<WorkflowSidePanelProps> = ({
  workflowId,
  open,
  onOpenChange,
  onDesign,
  onRequireSaved,
  onDecideHitl,
}) => {
  const design = useWorkflowDesignChat();
  const chat = useWorkflowChat(workflowId);
  const [input, setInput] = useState("");
  const [deciding, setDeciding] = useState(false);
  const threadRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  /* ── Resizable width ── */
  const [width, setWidth] = useState(DEFAULT_WIDTH);
  const draggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, w: DEFAULT_WIDTH });

  /* ── History panel ── */
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState<any[]>([]);

  const designing = !workflowId;
  const busy = designing ? design.busy : chat.sending || chat.awaiting;

  /* ── Resume a session from history ── */
  const resumeSession = async (session: any) => {
    try {
      const response = await authenticatedFetch(
        `${ENV.API_BASE_URL}/sessions/${session.session_id}`,
        { credentials: "include" },
      );
      if (!response.ok) {
        throw new Error(`Failed to load session: ${response.status}`);
      }
      const fullSession = await response.json();

      // Inject messages into the chat hook
      chat.loadFromSession(fullSession.session_id, fullSession.messages ?? []);

      setHistoryOpen(false);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : String(error);
      console.error("❌ Failed to resume session:", msg);
      alert(`Failed to resume session: ${msg}`);
    }
  };

  /* ── Delete a session from history ── */
  const deleteSession = async (sessionId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    if (!confirm("Are you sure you want to delete this chat session?")) return;

    try {
      const response = await authenticatedFetch(
        `${ENV.API_BASE_URL}/sessions/${sessionId}`,
        { method: "DELETE", credentials: "include" },
      );
      if (!response.ok) {
        throw new Error(`Failed to delete session: ${response.status}`);
      }

      // Remove from local history list
      setHistory((prev) => prev.filter((s) => s.session_id !== sessionId));

      // If the deleted session is the one currently loaded, clear the chat
      if (chat.sessionId === sessionId) {
        chat.reset();
      }
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : String(error);
      console.error("❌ Failed to delete session:", msg);
      alert(`Failed to delete session: ${msg}`);
    }
  };

  /* Auto-scroll */
  useEffect(() => {
    if (threadRef.current) {
      threadRef.current.scrollTop = threadRef.current.scrollHeight;
    }
  }, [design.turns.length, chat.messages.length, busy]);

  /* Auto-resize textarea */
  useEffect(() => {
    if (!textareaRef.current) return;
    textareaRef.current.style.height = "auto";
    textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
  }, [input]);

  /* ── Drag-to-resize handler ── */
  const startResize = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      draggingRef.current = true;
      dragStartRef.current = { x: e.clientX, w: width };

      const onMove = (ev: MouseEvent) => {
        if (!draggingRef.current) return;
        const delta = ev.clientX - dragStartRef.current.x;
        setWidth(
          Math.min(
            MAX_WIDTH,
            Math.max(MIN_WIDTH, dragStartRef.current.w + delta),
          ),
        );
      };
      const onUp = () => {
        draggingRef.current = false;
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    },
    [width],
  );

  const submit = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setHistoryOpen(false);

    if (designing) {
      const canvas = await design.send(text);
      if (canvas) onDesign(canvas);
      return;
    }

    const savedId = await onRequireSaved();
    if (!savedId) return;
    await chat.send(text);
  };

  const handleDecide = async (
    action: string,
    options?: { rationale?: string; editFeedback?: string },
  ) => {
    if (!chat.runId) return;
    setDeciding(true);
    await onDecideHitl(chat.runId, action, options);
    setDeciding(false);
  };

  const authenticatedFetch = (
    input: RequestInfo | URL,
    init: RequestInit = {},
  ) => {
    const headers = new Headers(init.headers ?? {});
    const requestUrl =
      typeof input === "string"
        ? input
        : input instanceof URL
          ? input.toString()
          : input.url;

    if (typeof window !== "undefined") {
      const accessToken = sessionStorage.getItem("EchoAccessToken");
      if (accessToken && !headers.has("Authorization")) {
        headers.set("Authorization", `Bearer ${accessToken}`);
      }
    }

    return window.fetch(input, {
      ...init,
      headers,
      credentials: init.credentials ?? "include",
    });
  };

  // Load session history from database (workflow-scoped)
  const loadSessionHistory = async () => {
    try {
      if (!workflowId) {
        setHistory([]);
        return;
      }

      const response = await authenticatedFetch(
        `${ENV.API_BASE_URL}/workflows/${workflowId}/chat/history?limit=20`,
        {
          headers: {},
          credentials: "include",
        },
      );
      if (!response.ok) {
        throw new Error(`Failed to load sessions: ${response.status}`);
      }

      const data = await response.json();
      setHistory(data.sessions || data || []);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : String(error);
      console.warn("Could not load session history:", msg);
      setHistory([]);
    } finally {
      // session loading complete
    }
  };

  const hasHistory = designing
    ? design.turns.length > 0
    : chat.messages.length > 0;

  /* ── Collapsed tab ── */
  if (!open) {
    return (
      <button
        type="button"
        className={s.railTab}
        onClick={() => onOpenChange(true)}
        title={designing ? "Build with a prompt" : "Chat with this workflow"}
      >
        <svg
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
        <span className={s.railTabLabel}>{designing ? "Build" : "Chat"}</span>
      </button>
    );
  }

  return (
    <aside
      className={s.rail}
      aria-label="Workflow assistant"
      style={{ width, minWidth: MIN_WIDTH, maxWidth: MAX_WIDTH }}
    >
      {/* ── Header ── */}
      <div className={s.railHead}>
        <div className={s.railHeadLeft}>
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ color: "var(--accent)" }}
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <span className={s.railTitle}>
            {designing ? "Spawn Agent" : "Chat"}
          </span>
        </div>

        <div className={s.railActions}>
          {/* Chat history button */}
          <button
            type="button"
            className={`${s.railIconBtn}${historyOpen ? ` ${s.railIconBtnActive}` : ""}`}
            title="Chat history"
            onClick={() => {
              setHistoryOpen((v) => !v);
              loadSessionHistory();
            }}
            aria-label="Chat history"
          >
            {/* clock / history icon */}
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="9" />
              <polyline points="12 7 12 12 15 14" />
            </svg>
          </button>

          {/* New chat */}
          {hasHistory && (
            <button
              type="button"
              className={s.railIconBtn}
              title="New chat"
              onClick={() => {
                designing ? design.reset() : chat.reset();
                setHistoryOpen(false);
              }}
              aria-label="New chat"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
              </svg>
            </button>
          )}

          {/* Collapse */}
          <button
            type="button"
            className={s.railIconBtn}
            onClick={() => onOpenChange(false)}
            aria-label="Collapse panel"
            title="Collapse"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
        </div>
      </div>

      {/* ── History panel (dropdown) ── */}
      {historyOpen && (
        <div className={s.railHistory}>
          <div className={s.railHistoryHead}>
            <span className={s.railHistoryTitle}>Recent chats</span>
          </div>
          {history.length === 0 ? (
            <p className={s.railHistoryEmpty}>No history yet.</p>
          ) : (
            <ul className={s.railHistoryList}>
              {history.map((session) => (
                <li key={session.session_id}>
                  <button
                    type="button"
                    className={s.railHistoryItem}
                    onClick={() => resumeSession(session)}
                  >
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                    >
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                    </svg>
                    <span className={s.railHistoryItemText}>
                      {session.title ?? session.session_id}
                    </span>
                    <span className={s.railHistoryItemTs}>
                      {session.ts
                        ? session.ts
                        : session.created_at
                          ? new Date(session.created_at).toLocaleTimeString(
                              [],
                              { hour: "2-digit", minute: "2-digit" },
                            )
                          : ""}
                    </span>
                    <button
                      type="button"
                      className={s.railHistoryDeleteBtn}
                      title="Delete session"
                      aria-label="Delete session"
                      onClick={(e) => deleteSession(session.session_id, e)}
                    >
                      <svg
                        width="12"
                        height="12"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                        <path d="M10 11v6M14 11v6" />
                        <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                      </svg>
                    </button>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* ── Thread ── */}
      <div className={s.railThread} ref={threadRef}>
        {/* Empty states */}
        {designing && design.turns.length === 0 && (
          <div className={s.railEmptyState}>
            <div className={s.railEmptyIc}>
              <svg
                width="28"
                height="28"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
              </svg>
            </div>
            <p className={s.railEmptyTitle}>How can I help you today?</p>
            <p className={s.railEmptyHint}>
              Describe what this workflow should do. You&apos;ll get a real,
              editable canvas — nothing is saved until you save it.
            </p>
          </div>
        )}

        {!designing && chat.messages.length === 0 && (
          <div className={s.railEmptyState}>
            <div className={s.railEmptyIc}>
              <svg
                width="28"
                height="28"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </div>
            <p className={s.railEmptyTitle}>How can I help you today?</p>
            <p className={s.railEmptyHint}>
              Send a message to run this workflow and see what it produces.
            </p>
          </div>
        )}

        {/* Design turns */}
        {designing &&
          design.turns.map((turn) => (
            <div
              key={turn.id}
              className={turn.role === "user" ? s.turnUser : s.turnAssistant}
            >
              <p className={turn.failed ? s.errText : s.turnText}>
                {turn.text}
              </p>
              {turn.degradedNotice && (
                <p className={s.warnText}>{turn.degradedNotice}</p>
              )}
              {turn.questions && turn.questions.length > 0 && (
                <div className={s.railQuestions}>
                  <span className={s.railQuestionsLabel}>
                    Optional — answering these would sharpen it:
                  </span>
                  <ul>
                    {turn.questions.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}

        {/* Chat messages */}
        {!designing &&
          chat.messages.map((message) => (
            <div
              key={message.id}
              className={message.role === "user" ? s.turnUser : s.turnAssistant}
            >
              {message.pending && !message.content ? (
                <span className={s.typingDots}>
                  <span />
                  <span />
                  <span />
                </span>
              ) : (
                <p className={message.failed ? s.errText : s.turnText}>
                  {message.content}
                </p>
              )}
            </div>
          ))}

        {/* Live steps */}
        {!designing && chat.awaiting && chat.steps.length > 0 && (
          <ul className={s.railSteps}>
            {chat.steps.map((step) => (
              <li key={step.stepId} className={s.railStep}>
                <span className={s.railStepName}>
                  {step.name || step.stepId}
                </span>
                <span className={s.railStepState}>{step.status}</span>
              </li>
            ))}
          </ul>
        )}

        {/* Typing indicators */}
        {designing && design.busy && (
          <div className={s.turnAssistant}>
            <span className={s.typingDots}>
              <span />
              <span />
              <span />
            </span>
          </div>
        )}
        {!designing && chat.sending && (
          <div className={s.turnAssistant}>
            <span className={s.typingDots}>
              <span />
              <span />
              <span />
            </span>
          </div>
        )}

        {design.error && <p className={s.errText}>{design.error}</p>}
        {chat.error && <p className={s.errText}>{chat.error}</p>}

        {chat.interrupt && (
          <HitlReviewPanel
            interrupt={chat.interrupt}
            onDecide={handleDecide}
            busy={deciding}
          />
        )}
      </div>

      {/* ── Composer ── */}
      <div className={s.railComposer}>
        <textarea
          ref={textareaRef}
          rows={1}
          value={input}
          placeholder={
            designing
              ? "e.g. Review a contract, flag risky clauses, then summarise them"
              : "Ask this workflow to do something…"
          }
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
        />
        <button
          type="button"
          className={s.railSendBtn}
          onClick={submit}
          disabled={!input.trim() || busy}
          aria-label="Send"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="12" y1="19" x2="12" y2="5" />
            <polyline points="5 12 12 5 19 12" />
          </svg>
        </button>
      </div>

      {/* ── Resize handle (right edge) ── */}
      <div
        className={s.railResizeHandle}
        onMouseDown={startResize}
        title="Drag to resize"
      />
    </aside>
  );
};
