"use client";

import React, { useState } from "react";
import { useWorkflowRun } from "../hooks/useWorkflowRun";
import { HitlReviewPanel } from "./HitlReviewPanel";
import { LiveStepsPanel } from "./LiveStepsPanel";
import { RunOutputs } from "./RunOutputs";
import s from "./workflows.module.css";

interface WorkflowRunViewProps {
  runId: string | null;
  onRunIdChange: (runId: string | null) => void;
  onBack?: () => void;
}

export const WorkflowRunView: React.FC<WorkflowRunViewProps> = ({
  runId,
  onRunIdChange,
  onBack,
}) => {
  const { status, interrupt, nodeOutputs, loading, error, reload, decide } =
    useWorkflowRun(runId);
  const [draftRunId, setDraftRunId] = useState(runId ?? "");
  const [busy, setBusy] = useState(false);

  const handleDecide = async (
    action: string,
    options?: { rationale?: string; editFeedback?: string },
  ) => {
    setBusy(true);
    await decide(action, options);
    setBusy(false);
  };

  return (
    <div className={s.wrap}>
      <div className={s.topRow}>
        {onBack && (
          <button className={s.ghostBtn} onClick={onBack}>
            Back
          </button>
        )}
        <input
          className={s.runInput}
          type="text"
          placeholder="run_…"
          value={draftRunId}
          onChange={(e) => setDraftRunId(e.target.value)}
        />
        <button
          className={s.ghostBtn}
          onClick={() => onRunIdChange(draftRunId.trim() || null)}
        >
          Open run
        </button>
        {runId && (
          <button className={s.ghostBtn} onClick={reload} disabled={loading}>
            {loading ? "Loading…" : "Refresh"}
          </button>
        )}
        {status?.status && (
          <span className={s.statusChip}>{status.status}</span>
        )}
      </div>

      {error && <p className={s.errText}>{error}</p>}

      {!runId && (
        <p className={s.hint}>
          Enter a run id to see its steps, outputs and any pending review.
        </p>
      )}

      {runId && interrupt && (
        <HitlReviewPanel
          interrupt={interrupt}
          onDecide={handleDecide}
          busy={busy}
        />
      )}

      {/* Live model output while the run is in flight. */}
      <LiveStepsPanel runId={runId} />

      {runId && <RunOutputs status={status} nodeOutputs={nodeOutputs} />}
    </div>
  );
};
