"use client";

import React, { useState, useRef, useEffect } from "react";
import { useWorkflows, workflowIdOf, nodeCountOf } from "../hooks/useWorkflows";
import { Pagination } from "@/components/common/Pagination";
import type { WorkflowSummary } from "@/types/workflow.types";
import s from "./workflows.module.css";

interface WorkflowListProps {
  onCreate: () => void;
  onOpen: (workflowId: string, name: string) => void;
  refreshKey?: number;
}

const relativeTime = (value?: string): string => {
  if (!value) return "";
  const then = new Date(value).getTime();
  if (Number.isNaN(then)) return "";
  const seconds = Math.max(0, (Date.now() - then) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
};

const GridIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
  </svg>
);

const ListIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);

const DotsIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="12" cy="5" r="1" fill="currentColor" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <circle cx="12" cy="19" r="1" fill="currentColor" />
  </svg>
);

const RowMenu: React.FC<{
  onOpen: () => void;
  onDelete: () => void;
  disabled?: boolean;
}> = ({ onOpen, onDelete, disabled }) => {
  const [open, setOpen] = useState(false);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(
    null,
  );
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        btnRef.current &&
        !btnRef.current.contains(target) &&
        menuRef.current &&
        !menuRef.current.contains(target)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  // Reposition on scroll / resize while open
  useEffect(() => {
    if (!open) return;
    const reposition = () => {
      if (btnRef.current) {
        const rect = btnRef.current.getBoundingClientRect();
        setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
      }
    };
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [open]);

  const handleToggle = () => {
    if (!open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
    }
    setOpen((o) => !o);
  };

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        className={s.dotsBtn}
        onClick={handleToggle}
        disabled={disabled}
        aria-label="Actions"
      >
        <DotsIcon />
      </button>
      {open && menuPos && (
        <div
          ref={menuRef}
          className={s.rowMenu}
          style={{ top: menuPos.top, left: menuPos.left }}
        >
          <button
            type="button"
            className={s.rowMenuItem}
            onClick={() => {
              setOpen(false);
              onOpen();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" />
              <line x1="10" y1="14" x2="21" y2="3" />
            </svg>
            Open
          </button>
          <button
            type="button"
            className={`${s.rowMenuItem} ${s.rowMenuItemDanger}`}
            onClick={() => {
              setOpen(false);
              onDelete();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
              <path d="M10 11v6" />
              <path d="M14 11v6" />
              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </>
  );
};

export const WorkflowList: React.FC<WorkflowListProps> = ({
  onCreate,
  onOpen,
  refreshKey,
}) => {
  const {
    workflows,
    loading,
    error,
    reload,
    remove,
    page,
    pageSize,
    total,
    search,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = useWorkflows();
  const [statusFilter, setStatusFilter] = useState("all");
  const [view, setView] = useState<"list" | "grid">("grid");
  const [confirmId, setConfirmId] = useState<string | null>(null);

  React.useEffect(() => {
    if (refreshKey !== undefined) reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  const query = search.trim().toLowerCase();
  const filtered = workflows.filter((workflow: WorkflowSummary) => {
    const matchesSearch =
      !query ||
      (workflow.name ?? "").toLowerCase().includes(query) ||
      (workflow.description ?? "").toLowerCase().includes(query);
    const matchesStatus =
      statusFilter === "all" ||
      (workflow.status ?? "draft").toLowerCase() === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className={s.listWrap}>
      <div className={s.listTop}>
        <input
          type="text"
          className={s.listSearch}
          placeholder="Search workflows…"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
        />

        <div className={s.viewToggle}>
          <button
            type="button"
            className={`${s.viewBtn}${view === "list" ? ` ${s.viewBtnActive}` : ""}`}
            onClick={() => setView("list")}
            aria-label="List view"
            title="List view"
          >
            <ListIcon />
          </button>
          <button
            type="button"
            className={`${s.viewBtn}${view === "grid" ? ` ${s.viewBtnActive}` : ""}`}
            onClick={() => setView("grid")}
            aria-label="Grid view"
            title="Grid view"
          >
            <GridIcon />
          </button>
        </div>

        <button type="button" className={s.primaryBtn} onClick={onCreate}>
          + New Workflow
        </button>
      </div>

      {error && <p className={s.errText}>{error}</p>}
      {loading && workflows.length === 0 && (
        <p className={s.hint}>Loading workflows…</p>
      )}

      {!loading && workflows.length === 0 && !error && (
        <div className={s.emptyState}>
          <p>No workflows yet.</p>
          <span>Click New Workflow to build your first one.</span>
        </div>
      )}

      {filtered.length === 0 && workflows.length > 0 && (
        <p className={s.hint}>No workflows match &quot;{search}&quot;.</p>
      )}

      {view === "list" ? (
        /* Table view */
        <div className={s.wfTableWrap}>
          <table className={s.wfTable}>
            <thead>
              <tr>
                <th>Name</th>
                {/* <th>Status</th> */}
                <th>Nodes</th>
                <th>Updated</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((workflow) => {
                const id = workflowIdOf(workflow);
                const nodes = nodeCountOf(workflow);
                return (
                  <tr key={id || workflow.name}>
                    <td>
                      <div style={{ fontWeight: 600 }}>
                        {workflow.name || "Untitled workflow"}
                      </div>
                      {workflow.description && (
                        <div
                          style={{
                            fontSize: "11.5px",
                            color: "var(--text-soft)",
                            marginTop: 1,
                          }}
                        >
                          {workflow.description}
                        </div>
                      )}
                    </td>
                    {/* <td>
                      <span className={s.wfStatus}>
                        {workflow.status || "draft"}
                      </span>
                    </td> */}
                    <td>
                      {nodes} node{nodes === 1 ? "" : "s"}
                    </td>
                    <td
                      style={{ fontSize: "12px", color: "var(--text-faint)" }}
                    >
                      {relativeTime(workflow.updated_at) || "—"}
                    </td>
                    <td>
                      {confirmId === id ? (
                        <div className={s.tableActions}>
                          <span className={s.hint} style={{ margin: 0 }}>
                            Delete?
                          </span>
                          <button
                            type="button"
                            className={s.dangerBtn}
                            style={{ fontSize: "12px", padding: "5px 10px" }}
                            onClick={async () => {
                              await remove(id);
                              setConfirmId(null);
                            }}
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            className={s.ghostBtn}
                            style={{ fontSize: "12px", padding: "5px 10px" }}
                            onClick={() => setConfirmId(null)}
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <RowMenu
                          disabled={!id}
                          onOpen={() =>
                            onOpen(id, workflow.name ?? "Untitled workflow")
                          }
                          onDelete={() => setConfirmId(id)}
                        />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* Grid (card) view */
        <div className={s.wfCards}>
          {filtered.map((workflow) => {
            const id = workflowIdOf(workflow);
            const nodes = nodeCountOf(workflow);
            return (
              <div key={id || workflow.name} className={s.wfCard}>
                {/* <div className={s.wfCardHead}>
                  <span className={s.wfStatus}>{workflow.status || "draft"}</span>
                </div> */}
                <h3 className={s.wfCardName}>
                  {workflow.name || "Untitled workflow"}
                </h3>
                <p className={s.wfCardDesc}>
                  {workflow.description || "No description."}
                </p>
                <div className={s.wfCardMeta}>
                  <span>
                    {nodes} node{nodes === 1 ? "" : "s"}
                  </span>
                  {relativeTime(workflow.updated_at) && (
                    <span>{relativeTime(workflow.updated_at)}</span>
                  )}
                </div>
                <div className={s.wfCardFoot}>
                  {confirmId === id ? (
                    <>
                      <span className={s.hint} style={{ margin: 0, flex: 1 }}>
                        Delete?
                      </span>
                      <button
                        type="button"
                        className={s.dangerBtn}
                        onClick={async () => {
                          await remove(id);
                          setConfirmId(null);
                        }}
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        className={s.ghostBtn}
                        onClick={() => setConfirmId(null)}
                      >
                        Keep
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        className={s.cardActionBtn}
                        onClick={() =>
                          onOpen(id, workflow.name ?? "Untitled workflow")
                        }
                        disabled={!id}
                      >
                        <svg
                          width="13"
                          height="13"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        >
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                          <polyline points="15 3 21 3 21 9" />
                          <line x1="10" y1="14" x2="21" y2="3" />
                        </svg>
                        Open
                      </button>
                      <button
                        type="button"
                        className={s.cardDelBtn}
                        onClick={() => setConfirmId(id)}
                        disabled={!id}
                      >
                        <svg
                          width="13"
                          height="13"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        >
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                          <path d="M10 11v6" />
                          <path d="M14 11v6" />
                          <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                        </svg>
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {total > 0 && (
        <Pagination
          currentPage={page}
          pageSize={pageSize}
          total={total}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      )}
    </div>
  );
};
