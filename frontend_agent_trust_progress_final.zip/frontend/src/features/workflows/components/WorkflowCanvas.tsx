"use client";

import React, { useCallback, useRef, useState } from "react";
import { catalogFor, NODE_CATALOG } from "../nodeCatalog";
import { NodeIcon } from "./NodeIcon";
import type {
  CanvasConnection,
  CanvasNode,
  WorkflowNodeType,
} from "@/types/workflow.types";
import type { NodeCatalogEntry } from "../nodeCatalog";
import s from "./workflows.module.css";

const NODE_WIDTH = 220;
const NODE_HEIGHT = 100;

interface WorkflowCanvasProps {
  nodes: CanvasNode[];
  connections: CanvasConnection[];
  selectedId: number | null;
  onSelect: (id: number | null) => void;
  onMove: (id: number, x: number, y: number) => void;
  onConnect: (from: number, to: number) => void;
  onDisconnect: (id: number) => void;
  onRemove: (id: number) => void;
  onAddAt: (
    entry: NodeCatalogEntry,
    position: { x: number; y: number },
  ) => void;
  onClearCanvas: () => void;
  problemNodeIds?: number[];
}

const outPort = (node: CanvasNode) => ({
  x: node.x + NODE_WIDTH,
  y: node.y + NODE_HEIGHT / 2,
});
const inPort = (node: CanvasNode) => ({
  x: node.x,
  y: node.y + NODE_HEIGHT / 2,
});

const edgePath = (
  from: { x: number; y: number },
  to: { x: number; y: number },
): string => {
  const dx = Math.max(40, Math.abs(to.x - from.x) / 2);
  return `M ${from.x} ${from.y} C ${from.x + dx} ${from.y}, ${to.x - dx} ${to.y}, ${to.x} ${to.y}`;
};

const ZOOM_MIN = 0.25;
const ZOOM_MAX = 2;
const ZOOM_STEP = 0.1;

export const WorkflowCanvas: React.FC<WorkflowCanvasProps> = ({
  nodes,
  connections,
  selectedId,
  onSelect,
  onMove,
  onConnect,
  onDisconnect,
  onRemove,
  onAddAt,
  onClearCanvas,
  problemNodeIds = [],
}) => {
  const outerRef = useRef<HTMLDivElement | null>(null);

  const [pan, setPan] = useState({ x: 40, y: 40 });
  const [zoom, setZoom] = useState(1);

  const panRef = useRef<{
    startX: number;
    startY: number;
    panX: number;
    panY: number;
  } | null>(null);
  const dragRef = useRef<{ id: number; dx: number; dy: number } | null>(null);
  const [linking, setLinking] = useState<{
    from: number;
    x: number;
    y: number;
  } | null>(null);

  const pointIn = useCallback(
    (clientX: number, clientY: number) => {
      const box = outerRef.current?.getBoundingClientRect();
      if (!box) return { x: 0, y: 0 };
      return {
        x: (clientX - box.left - pan.x) / zoom,
        y: (clientY - box.top - pan.y) / zoom,
      };
    },
    [pan, zoom],
  );

  const startDrag = (e: React.MouseEvent, node: CanvasNode) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    const pt = pointIn(e.clientX, e.clientY);
    dragRef.current = { id: node.id, dx: pt.x - node.x, dy: pt.y - node.y };
  };

  const startPan = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    // Only pan when clicking the canvas bg (not a node)
    if ((e.target as HTMLElement).closest("[data-node]")) return;
    panRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      panX: pan.x,
      panY: pan.y,
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (dragRef.current) {
      const { id, dx, dy } = dragRef.current;
      const pt = pointIn(e.clientX, e.clientY);
      onMove(id, Math.max(0, pt.x - dx), Math.max(0, pt.y - dy));
      return;
    }
    if (panRef.current) {
      const dx = e.clientX - panRef.current.startX;
      const dy = e.clientY - panRef.current.startY;
      setPan({ x: panRef.current.panX + dx, y: panRef.current.panY + dy });
      return;
    }
    if (linking) {
      const pt = pointIn(e.clientX, e.clientY);
      setLinking({ ...linking, x: pt.x, y: pt.y });
    }
  };

  const endInteraction = () => {
    dragRef.current = null;
    panRef.current = null;
    setLinking(null);
  };

  /* ---- Linking ---- */
  const startLink = (e: React.MouseEvent, node: CanvasNode) => {
    e.stopPropagation();
    const pt = pointIn(e.clientX, e.clientY);
    setLinking({ from: node.id, x: pt.x, y: pt.y });
  };

  const completeLink = (e: React.MouseEvent, node: CanvasNode) => {
    if (!linking) return;
    e.stopPropagation();
    onConnect(linking.from, node.id);
    setLinking(null);
  };

  /* ---- Palette drop ---- */
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData("application/x-node-type");
    const entry = NODE_CATALOG[type as WorkflowNodeType];
    if (!entry) return;
    const pt = pointIn(e.clientX, e.clientY);
    onAddAt(entry, {
      x: Math.max(0, pt.x - NODE_WIDTH / 2),
      y: Math.max(0, pt.y - NODE_HEIGHT / 2),
    });
  };

  /* ---- Zoom ---- */
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP;
    setZoom((z) =>
      Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, +(z + delta).toFixed(2))),
    );
  };

  const zoomIn = () =>
    setZoom((z) => Math.min(ZOOM_MAX, +(z + ZOOM_STEP).toFixed(2)));
  const zoomOut = () =>
    setZoom((z) => Math.max(ZOOM_MIN, +(z - ZOOM_STEP).toFixed(2)));
  const resetView = () => {
    setPan({ x: 40, y: 40 });
    setZoom(1);
  };

  const isPanning = Boolean(panRef.current);
  const nodeById = (id: number) => nodes.find((n) => n.id === id);
  const linkingFrom = linking ? nodeById(linking.from) : null;

  return (
    <div
      ref={outerRef}
      className={s.canvas}
      style={{ cursor: isPanning ? "grabbing" : "grab" }}
      onMouseDown={startPan}
      onMouseMove={handleMouseMove}
      onMouseUp={endInteraction}
      onMouseLeave={endInteraction}
      onClick={() => onSelect(null)}
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
      onWheel={handleWheel}
    >
      {/* ---- transformed inner canvas ---- */}
      <div
        className={s.canvasInner}
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: "0 0",
        }}
      >
        {/* SVG edges layer */}
        <svg className={s.edges}>
          {connections.map((edge) => {
            const from = nodeById(edge.from);
            const to = nodeById(edge.to);
            if (!from || !to) return null;
            return (
              <g key={edge.id} className={s.edgeGroup}>
                <path
                  className={s.edgeHit}
                  d={edgePath(outPort(from), inPort(to))}
                  onClick={(e) => {
                    e.stopPropagation();
                    onDisconnect(edge.id);
                  }}
                >
                  <title>Click to remove this connection</title>
                </path>
                <path
                  className={s.edge}
                  d={edgePath(outPort(from), inPort(to))}
                />
              </g>
            );
          })}

          {/* Draft link while drawing */}
          {linking && linkingFrom && (
            <path
              className={s.edgeDraft}
              d={edgePath(outPort(linkingFrom), { x: linking.x, y: linking.y })}
            />
          )}
        </svg>

        {/* Nodes */}
        {nodes.map((node) => {
          const entry = catalogFor(node.type);
          const removable = entry?.removable ?? true;
          const hasProblem = problemNodeIds.includes(node.id);

          return (
            <div
              key={node.id}
              data-node="true"
              className={[
                s.nodeCard,
                selectedId === node.id ? s.nodeCardSelected : "",
                hasProblem ? s.nodeCardProblem : "",
              ]
                .filter(Boolean)
                .join(" ")}
              style={{
                left: node.x,
                top: node.y,
                width: NODE_WIDTH,
              }}
              onMouseDown={(e) => startDrag(e, node)}
              onMouseUp={(e) => completeLink(e, node)}
              onClick={(e) => e.stopPropagation()}
              onDoubleClick={(e) => {
                e.stopPropagation();
                onSelect(node.id);
              }}
            >
              {/* Badge row */}
              <div className={s.nodeCardTop}>
                <span
                  className={s.nodeCardBadge}
                  style={{
                    background: `color-mix(in srgb, ${node.color ?? entry?.color ?? "#6366f1"} 16%, transparent)`,
                    color: node.color ?? entry?.color ?? "#6366f1",
                    borderColor: `color-mix(in srgb, ${node.color ?? entry?.color ?? "#6366f1"} 30%, transparent)`,
                  }}
                >
                  {node.type}
                </span>

                {removable && (
                  <button
                    type="button"
                    className={s.nodeCardDel}
                    title="Delete node"
                    aria-label={`Delete ${node.name}`}
                    onMouseDown={(e) => e.stopPropagation()}
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemove(node.id);
                    }}
                  >
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                    >
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                )}
              </div>

              {/* Icon + name row */}
              <div className={s.nodeCardBody}>
                <span
                  className={s.nodeCardIc}
                  style={{
                    background: `color-mix(in srgb, ${node.color ?? entry?.color ?? "#6366f1"} 14%, transparent)`,
                    color: node.color ?? entry?.color ?? "#6366f1",
                  }}
                >
                  <NodeIcon
                    name={node.icon || entry?.icon || "workflow"}
                    size={18}
                  />
                </span>
                <div className={s.nodeCardMeta}>
                  <span className={s.nodeCardName}>
                    {node.name || node.label}
                  </span>
                  {node.description && (
                    <span className={s.nodeCardDesc}>{node.description}</span>
                  )}
                </div>
              </div>

              {/* Status dot */}
              <span
                className={s.nodeCardStatus}
                title={node.status ?? "draft"}
                style={{
                  background:
                    node.status === "configured"
                      ? "#22c55e"
                      : node.status === "running"
                        ? "#f59e0b"
                        : "#94a3b8",
                }}
              />

              {/* Connection ports */}
              <span
                className={`${s.port} ${s.portIn}`}
                onMouseUp={(e) => completeLink(e, node)}
                title="Drop a connection here"
              />
              <span
                className={`${s.port} ${s.portOut}`}
                onMouseDown={(e) => {
                  e.stopPropagation();
                  startLink(e, node);
                }}
                title="Drag to connect"
              />
            </div>
          );
        })}

        {nodes.length === 0 && (
          <p className={s.canvasEmpty}>
            Drag a node from the palette, or click one to add it.
          </p>
        )}
      </div>

      {/* ---- Floating canvas controls (center-bottom) ---- */}
      <div className={s.canvasControls}>
        <button
          type="button"
          className={s.canvasCtrlBtn}
          onClick={zoomOut}
          title="Zoom out"
          aria-label="Zoom out"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </button>
        <span className={s.canvasZoomLabel}>{Math.round(zoom * 100)}%</span>
        <button
          type="button"
          className={s.canvasCtrlBtn}
          onClick={zoomIn}
          title="Zoom in"
          aria-label="Zoom in"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </button>
        <div className={s.canvasCtrlSep} />
        <button
          type="button"
          className={s.canvasCtrlBtn}
          onClick={resetView}
          title="Reset view"
          aria-label="Reset view"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
            <path d="M3 3v5h5" />
          </svg>
        </button>
      </div>

      {/* ---- Clear canvas floating button (bottom-right) ---- */}
      <button
        type="button"
        className={s.clearCanvasBtn}
        onClick={(e) => {
          e.stopPropagation();
          onClearCanvas();
        }}
        title="Clear canvas"
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        >
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
          <path d="M10 11v6M14 11v6" />
          <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
        </svg>
        Clear Canvas
      </button>
    </div>
  );
};
