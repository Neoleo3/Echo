"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  NODE_CATALOG,
  PALETTE_ORDER,
  type NodeCatalogEntry,
} from "../nodeCatalog";
import { NodeIcon } from "./NodeIcon";
import { agentsService, extractAgentItems } from "@/services/agents.service";
import type { AgentDefinition } from "@/types/agents.types";
import s from "./workflows.module.css";

interface NodePaletteProps {
  onAdd: (entry: NodeCatalogEntry) => void;
  onAddAgent?: (agent: AgentDefinition) => void;
}

type PaletteTab = "nodes" | "agents";

/* ── Grouped node sections matching the HTML reference ── */
const NODE_SECTIONS: Array<{ label: string; types: string[] }> = [
  { label: "Entry / Exit", types: ["Start", "End"] },
  { label: "Agents", types: ["Agent"] },
  { label: "Logic", types: ["Conditional"] },
  { label: "Quality", types: ["Self-Review", "HITL"] },
  { label: "Integration", types: ["API", "MCP"] },
  { label: "Code", types: ["Code"] },
];

export const NodePalette: React.FC<NodePaletteProps> = ({
  onAdd,
  onAddAgent,
}) => {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<PaletteTab>("nodes");
  const [search, setSearch] = useState("");
  const [agents, setAgents] = useState<AgentDefinition[]>([]);
  const [agentsLoading, setAgentsLoading] = useState(false);
  const popupRef = useRef<HTMLDivElement>(null);

  const loadAgents = React.useCallback(async () => {
    setAgentsLoading(true);
    const response = await agentsService.listAgents();
    if (response.success) {
      setAgents(extractAgentItems(response.data));
    }
    setAgentsLoading(false);
  }, []);

  /* Close on outside click */
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  /* Close on Escape */
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open]);

  /* Lazy-load agents */
  useEffect(() => {
    if (tab !== "agents" || agents.length > 0) return;
    void loadAgents();
  }, [tab, agents.length, loadAgents]);

  const query = search.trim().toLowerCase();

  /* ── Filtered node entries ── */
  const allEntries = PALETTE_ORDER.map((t) => NODE_CATALOG[t]);
  const filteredNodes = allEntries.filter(
    (e) =>
      !query ||
      e.label.toLowerCase().includes(query) ||
      e.description.toLowerCase().includes(query),
  );

  /* ── Filtered agents ── */
  const filteredAgents = agents.filter(
    (a) =>
      !query ||
      (a.name ?? "").toLowerCase().includes(query) ||
      (a.description ?? "").toLowerCase().includes(query),
  );

  const agentCatalogEntry = NODE_CATALOG["Agent"];

  const handleNodeClick = (entry: NodeCatalogEntry) => {
    onAdd(entry);
    setOpen(false);
  };

  const handleAgentClick = (agent: AgentDefinition) => {
    if (onAddAgent) {
      onAddAgent(agent);
    } else {
      onAdd({
        ...agentCatalogEntry,
        label: agent.name ?? "Agent",
        defaultConfig: {
          ...agentCatalogEntry.defaultConfig,
          agent_id: agent.agent_id ?? "",
        },
      });
    }
    setOpen(false);
  };

  const handleAgentDragStart = (e: React.DragEvent, agent: AgentDefinition) => {
    e.dataTransfer.setData("application/x-node-type", "Agent");
    e.dataTransfer.setData("application/x-agent-id", agent.agent_id ?? "");
    e.dataTransfer.setData("application/x-agent-name", agent.name ?? "Agent");
    e.dataTransfer.effectAllowed = "copy";
  };

  /* ── Build grouped sections for nodes tab ── */
  const nodeSections = NODE_SECTIONS.map((sec) => ({
    ...sec,
    entries: sec.types
      .map((t) => NODE_CATALOG[t as keyof typeof NODE_CATALOG])
      .filter(Boolean)
      .filter(
        (e) =>
          !query ||
          e.label.toLowerCase().includes(query) ||
          e.description.toLowerCase().includes(query),
      ),
  })).filter((sec) => sec.entries.length > 0);

  /* When searching, collapse sections into a flat list */
  const flatSearch = query.length > 0;

  return (
    /* The wrapper sits on the canvas, positioned absolutely via CSS */
    <div className={s.paletteFab} ref={popupRef}>
      {/* ── Floating + button ── */}
      <button
        type="button"
        className={`${s.paletteFabBtn}${open ? ` ${s.paletteFabBtnActive}` : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? "Close node palette" : "Add node"}
        title="Add node"
      >
        <svg
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          style={{
            transition: "transform 0.2s",
            transform: open ? "rotate(45deg)" : "none",
          }}
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
      </button>

      {/* ── Popup panel ── */}
      {open && (
        <div
          className={s.palettePopup}
          onMouseDown={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className={s.palettePopupHead}>
            {/* Tabs */}
            <div className={s.palettePopupTabs}>
              <button
                type="button"
                className={`${s.palettePopupTab}${tab === "nodes" ? ` ${s.palettePopupTabActive}` : ""}`}
                onClick={() => setTab("nodes")}
              >
                <svg
                  width="13"
                  height="13"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <rect x="3" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="3" width="7" height="7" rx="1.5" />
                  <rect x="3" y="14" width="7" height="7" rx="1.5" />
                  <rect x="14" y="14" width="7" height="7" rx="1.5" />
                </svg>
                Nodes
              </button>
              <button
                type="button"
                className={`${s.palettePopupTab}${tab === "agents" ? ` ${s.palettePopupTabActive}` : ""}`}
                onClick={() => setTab("agents")}
              >
                <svg
                  width="13"
                  height="13"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <circle cx="12" cy="7" r="4" />
                  <path d="M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2" />
                </svg>
                Agents
              </button>
            </div>

            {/* Search */}
            <div className={s.palettePopupSearch}>
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                autoFocus
                placeholder={
                  tab === "nodes" ? "Search nodes…" : "Search agents…"
                }
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          {/* ── Content ── */}
          <div className={s.palettePopupBody}>
            {/* NODES TAB */}
            {tab === "nodes" && (
              <>
                {flatSearch ? (
                  /* Flat search results */
                  filteredNodes.length === 0 ? (
                    <p className={s.palettePopupEmpty}>
                      No nodes match &ldquo;{search}&rdquo;.
                    </p>
                  ) : (
                    <div className={s.palettePopupList}>
                      {filteredNodes.map((entry) => (
                        <NodeItem
                          key={entry.type}
                          entry={entry}
                          onClick={handleNodeClick}
                        />
                      ))}
                    </div>
                  )
                ) : (
                  /* Grouped sections */
                  nodeSections.map((sec) => (
                    <div key={sec.label} className={s.palettePopupSection}>
                      <div className={s.palettePopupSectionLabel}>
                        {sec.label}
                      </div>
                      <div className={s.palettePopupList}>
                        {sec.entries.map((entry) => (
                          <NodeItem
                            key={entry.type}
                            entry={entry}
                            onClick={handleNodeClick}
                          />
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </>
            )}

            {/* AGENTS TAB */}
            {tab === "agents" && (
              <>
                {agentsLoading && (
                  <div className={s.palettePopupLoadingWrap}>
                    <span className={s.palettePopupSpinner} />
                    <span>Loading agents…</span>
                  </div>
                )}

                {!agentsLoading && filteredAgents.length === 0 && (
                  <p className={s.palettePopupEmpty}>
                    {agents.length === 0
                      ? "No agents found. Create one in Configuration."
                      : `No agents match "${search}".`}
                  </p>
                )}

                {!agentsLoading && filteredAgents.length > 0 && (
                  <>
                    <div
                      className={s.palettePopupSectionLabel}
                      style={{ padding: "0 14px 6px" }}
                    >
                      My Agents
                      <button
                        type="button"
                        className={s.palettePopupRefresh}
                        title="Refresh"
                        onClick={() => {
                          setAgents([]);
                          void loadAgents();
                        }}
                      >
                        <svg
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2.2"
                          strokeLinecap="round"
                        >
                          <path d="M21 12a9 9 0 1 1-1.6-5.1" />
                          <path d="M21 3v4h-4" />
                        </svg>
                        Refresh
                      </button>
                    </div>
                    <div className={s.palettePopupList}>
                      {filteredAgents.map((agent) => (
                        <button
                          key={agent.agent_id}
                          type="button"
                          className={s.palettePopupAgentItem}
                          onClick={() => handleAgentClick(agent)}
                          draggable
                          onDragStart={(e) => handleAgentDragStart(e, agent)}
                        >
                          <span className={s.palettePopupAgentIc}>
                            <NodeIcon name="agent" size={15} />
                          </span>
                          <span className={s.palettePopupAgentMeta}>
                            <span className={s.palettePopupAgentName}>
                              {agent.name ?? "Unnamed agent"}
                            </span>
                            <span className={s.palettePopupAgentDesc}>
                              {agent.description
                                ? agent.description.slice(0, 72) +
                                  (agent.description.length > 72 ? "…" : "")
                                : "Autonomous AI agent — complete the task"}
                            </span>
                          </span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </>
            )}
          </div>

          {/* Footer hint */}
          <div className={s.palettePopupFoot}>
            <svg
              width="11"
              height="11"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
              <polyline points="10 17 15 12 10 7" />
              <line x1="15" y1="12" x2="3" y2="12" />
            </svg>
            Drag onto the canvas, or click to add
          </div>
        </div>
      )}
    </div>
  );
};

/* ── Reusable node item row ── */
const NodeItem: React.FC<{
  entry: NodeCatalogEntry;
  onClick: (e: NodeCatalogEntry) => void;
}> = ({ entry, onClick }) => (
  <button
    type="button"
    className={s.palettePopupNodeItem}
    onClick={() => onClick(entry)}
    draggable
    onDragStart={(e) => {
      e.dataTransfer.setData("application/x-node-type", entry.type);
      e.dataTransfer.effectAllowed = "copy";
    }}
    title={entry.description}
  >
    <span
      className={s.palettePopupNodeIc}
      style={{
        background: `color-mix(in srgb, ${entry.color} 15%, transparent)`,
        color: entry.color,
      }}
    >
      <NodeIcon name={entry.icon} size={15} />
    </span>
    <span className={s.palettePopupNodeMeta}>
      <span className={s.palettePopupNodeName}>{entry.label}</span>
      <span className={s.palettePopupNodeDesc}>{entry.description}</span>
    </span>
  </button>
);
