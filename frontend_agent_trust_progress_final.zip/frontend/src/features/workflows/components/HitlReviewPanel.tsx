"use client";

import React, { useState } from "react";
import type { HitlDecision, HitlInterrupt } from "@/types/workflow.types";
import s from "./workflows.module.css";

interface HitlReviewPanelProps {
  interrupt: HitlInterrupt;
  onDecide: (
    action: string,
    options?: { rationale?: string; editFeedback?: string },
  ) => void;
  busy?: boolean;
}

const DECISION_LABELS: Record<HitlDecision, string> = {
  approve: "Approve",
  reject: "Reject",
  edit: "Request changes",
};

const asText = (value: unknown): string => {
  if (value == null) return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
};

export const HitlReviewPanel: React.FC<HitlReviewPanelProps> = ({
  interrupt,
  onDecide,
  busy,
}) => {
  const [rationale, setRationale] = useState("");
  const [editFeedback, setEditFeedback] = useState("");

  if (interrupt.interrupt_type && interrupt.interrupt_type !== "hitl_review") {
    return null;
  }

  const allowed = (interrupt.allowed_decisions ?? []) as HitlDecision[];
  const canEdit = allowed.includes("edit");
  const preceding = asText(interrupt.preceding_output);

  return (
    <section className={s.review} aria-label="Review checkpoint">
      <div className={s.reviewHead}>
        <h3 className={s.reviewTitle}>{interrupt.title || "Review needed"}</h3>
        {interrupt.priority && (
          <span className={s.priority}>{interrupt.priority}</span>
        )}
      </div>

      {interrupt.message && <p className={s.reviewMsg}>{interrupt.message}</p>}

      {preceding && (
        <>
          <h4 className={s.subHead}>
            {interrupt.preceding_node_name
              ? `Output from ${interrupt.preceding_node_name}`
              : "Under review"}
          </h4>
          <pre className={s.outputBlock}>{preceding}</pre>
        </>
      )}

      <label className={s.field}>
        <span className={s.fieldLabel}>Comment (optional)</span>
        <textarea
          rows={2}
          value={rationale}
          onChange={(e) => setRationale(e.target.value)}
          placeholder="Why are you approving or rejecting?"
        />
      </label>

      {canEdit && (
        <label className={s.field}>
          <span className={s.fieldLabel}>What should change?</span>
          <textarea
            rows={2}
            value={editFeedback}
            onChange={(e) => setEditFeedback(e.target.value)}
            placeholder="Sent back to the previous step, which re-runs and returns here."
          />
        </label>
      )}

      <div className={s.actions}>
        {allowed.map((action) => (
          <button
            key={action}
            type="button"
            className={
              action === "approve"
                ? s.approveBtn
                : action === "reject"
                  ? s.rejectBtn
                  : s.editBtn
            }
            disabled={busy || (action === "edit" && !editFeedback.trim())}
            onClick={() =>
              onDecide(action, {
                rationale: rationale.trim() || undefined,
                editFeedback: editFeedback.trim() || undefined,
              })
            }
          >
            {DECISION_LABELS[action] ?? action}
          </button>
        ))}
      </div>

      {canEdit && (
        <p className={s.hint}>
          Requesting changes sends the work back to the previous step. It will
          re-run and return to this same checkpoint for another round.
        </p>
      )}
    </section>
  );
};
