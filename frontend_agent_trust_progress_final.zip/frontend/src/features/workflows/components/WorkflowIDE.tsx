"use client";

import React, { Dispatch, SetStateAction, useRef, useState } from "react";
import { useWorkflowCanvas } from "../hooks/useWorkflowCanvas";
import { useWorkflowRunner } from "../hooks/useWorkflowRunner";
import { workflowsService } from "@/services/workflows.service";
import { NodePalette } from "./NodePalette";
import { WorkflowCanvas } from "./WorkflowCanvas";
import { NodeInspector } from "./NodeInspector";
import { WorkflowRunView } from "./WorkflowRunView";
import { WorkflowSidePanel } from "./WorkflowSidePanel";
import type { DesignedCanvas } from "../hooks/useWorkflowDesignChat";
import type { CanvasNode, HitlDecision } from "@/types/workflow.types";
import s from "./workflows.module.css";
import { LoadWorkflowModal } from "./LoadWorkflow";
import { useWorkflows } from "../hooks/useWorkflows";

interface WorkflowIDEProps {
  /** Null for a brand-new workflow. */
  workflowId: string | null;
  workflowName: string;
  setIdeWorkflowId: Dispatch<SetStateAction<string | null>>;
  setIdeWorkflowName: Dispatch<SetStateAction<string>>;
  onClose: () => void;
  onSaved?: (workflowId: string) => void;
}

export const WorkflowIDE: React.FC<WorkflowIDEProps> = ({
  workflowId,
  workflowName,
  setIdeWorkflowId,
  setIdeWorkflowName,
  onClose,
  onSaved,
}) => {
  const canvas = useWorkflowCanvas(workflowId, workflowName);
  const runner = useWorkflowRunner();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showRun, setShowRun] = useState(false);
  const [railOpen, setRailOpen] = useState(!workflowId);
  const importRef = useRef<HTMLInputElement | null>(null);

  const selectedNode =
    canvas.nodes.find((node) => node.id === selectedId) ?? null;

  const { workflows } = useWorkflows();
  const [showLoadModal, setShowLoadModal] = useState<boolean>(false);
  const [manualWorkflowId, setManualWorkflowId] = useState<string>("");
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string | null>(
    null,
  );
  const [isLoadingDrafts] = useState<boolean>(false);

  const handleLoadSelectedWorkflow = () => {
    if (!selectedWorkflowId) return;
    const wf: any = workflows.find(
      (w: any) => w.workflow_id === selectedWorkflowId,
    );
    setIdeWorkflowId(selectedWorkflowId);
    setIdeWorkflowName(wf?.name ?? "");
    setShowLoadModal(false);
  };

  const handleLoadManualId = async (id: string) => {
    // const id = manualWorkflowId.trim();
    if (!id) return;
    const response = await workflowsService.getWorkflow(id);
    const wfName =
      (response.data as any)?.name ??
      (response.data as any)?.workflow_name ??
      "Loaded Workflow";
    setIdeWorkflowId(id);
    setIdeWorkflowName(wfName);
    setManualWorkflowId("");
    setShowLoadModal(false);
  };

  const handleSave = async () => {
    setNotice(null);
    const id = await canvas.save();
    if (id) {
      setNotice("Saved.");
      onSaved?.(id);
    }
  };

  const ensureSaved = async (): Promise<string | null> => {
    if (canvas.savedId && !canvas.dirty) return canvas.savedId;
    const id = await canvas.save();
    if (id) onSaved?.(id);
    return id;
  };

  const applyDesign = (designed: DesignedCanvas) => {
    canvas.replaceCanvas({
      nodes: designed.nodes,
      connections: designed.connections,
    });
    if (designed.name) canvas.setName(designed.name);
    setSelectedId(null);
    setNotice("Design applied. Review it, then save.");
  };

  const decideHitl = async (
    runId: string,
    action: HitlDecision | string,
    options?: { rationale?: string; editFeedback?: string },
  ) => {
    const response = await workflowsService.decideHitl({
      run_id: runId,
      action,
      rationale: options?.rationale,
      ...(options?.editFeedback
        ? { payload: { changes: { edit_feedback: options.editFeedback } } }
        : {}),
    });
    if (!response.success) {
      setNotice(response.error ?? "That decision was not accepted.");
    }
  };

  const handleRun = async () => {
    setNotice(null);
    let id = canvas.savedId;
    if (!id || canvas.dirty) {
      id = await canvas.save();
      if (!id) return;
      onSaved?.(id);
    }
    const startedRunId = await runner.run(id);
    if (startedRunId) setShowRun(true);
  };

  const handleDeploy = async () => {
    setNotice(null);
    let id = canvas.savedId;
    if (!id || canvas.dirty) {
      id = await canvas.save();
      if (!id) return;
      onSaved?.(id);
    }
    const response = await workflowsService.saveFinal(id);
    setNotice(
      response.success ? "Deployed." : (response.error ?? "Could not deploy."),
    );
  };

  const handleExport = () => {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            workflow_name: canvas.name,
            icon: canvas.icon,
            canvas_nodes: canvas.nodes,
            connections: canvas.connections,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${canvas.name || "workflow"}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const stripIdentity = (node: Record<string, unknown>) => {
    const { backend_id, agentId, config, ...rest } = node;
    void backend_id;
    void agentId;
    const nextConfig =
      config && typeof config === "object"
        ? (() => {
            const { agent_id, ...restConfig } = config as Record<
              string,
              unknown
            >;
            void agent_id;
            return restConfig;
          })()
        : config;
    return { ...rest, config: nextConfig };
  };

  const handleImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const imported: Record<string, unknown>[] =
        parsed.canvas_nodes ?? parsed.nodes ?? [];
      canvas.replaceCanvas({
        nodes: imported.map(stripIdentity) as CanvasNode[],
        connections: parsed.connections ?? [],
      });
      if (parsed.workflow_name) canvas.setName(parsed.workflow_name);
      if (parsed.canvas_nodes) console.log("NodeS: ", parsed.canvas_nodes);
      setNotice(
        "Imported as a copy. Saving the canvas will create its agents here.",
      );
    } catch {
      setNotice("That file is not a workflow export.");
    }
  };

  // Mirror the page-level theme so the fixed IDE overlay inherits dark/light CSS vars.
  const currentTheme =
    typeof document !== "undefined"
      ? (document.documentElement.getAttribute("data-theme") ?? "light")
      : "light";

  return (
    <div className={s.ide} data-theme={currentTheme}>
      {/* ---------- top bar ---------- */}
      <div className={s.ideTop}>
        {/* Left: Back + branding */}
        <button className={s.ghostBtn} onClick={onClose} aria-label="Close IDE">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>

        {/* Workflow icon */}
        <div className={s.ideIconWrap}>
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polygon
              points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"
              fill="currentColor"
              fillOpacity="0.15"
            />
          </svg>
        </div>

        <div className={s.ideName}>
          <span className={s.ideNameLabel}>Workflow:</span>
          <input
            className={s.ideNameInput}
            value={canvas.name}
            onChange={(e) => canvas.setName(e.target.value)}
            placeholder="untitled_workflow"
          />

          <button
            className={s.ghostBtn}
            onClick={() => importRef.current?.click()}
          >
            Import
          </button>
          <input
            ref={importRef}
            type="file"
            accept="application/json"
            hidden
            onChange={(e) => handleImport(e.target.files?.[0])}
          />
          <button className={s.ghostBtn} onClick={handleExport}>
            Export
          </button>
        </div>

        <div className={s.ideActions}>
          <button
            className={s.ghostBtn}
            type="button"
            onClick={() => setShowLoadModal(true)}
          >
            Load
          </button>

          <button
            className={s.runBtn}
            onClick={handleSave}
            disabled={canvas.saving}
          >
            {canvas.saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>

      {/* ---------- validation / notice bar ---------- */}
      {(canvas.error ||
        canvas.errors.length > 0 ||
        canvas.warnings.length > 0 ||
        runner.error ||
        notice) && (
        <div className={s.ideMessages}>
          {notice && <p className={s.noticeText}>{notice}</p>}
          {canvas.error && <p className={s.errText}>{canvas.error}</p>}
          {runner.error && <p className={s.errText}>{runner.error}</p>}
          {canvas.errors.map((message, i) => (
            <p key={`e-${i}`} className={s.errText}>
              {message}
            </p>
          ))}
          {canvas.warnings.map((message, i) => (
            <p key={`w-${i}`} className={s.warnText}>
              {message}
            </p>
          ))}
        </div>
      )}

      {/* ---------- body ---------- */}
      <div className={s.ideBody}>
        {/* Chat rail (left) */}
        <WorkflowSidePanel
          workflowId={canvas.savedId}
          open={railOpen}
          onOpenChange={setRailOpen}
          onDesign={applyDesign}
          onRequireSaved={ensureSaved}
          onDecideHitl={decideHitl}
        />

        {/* Canvas — NodePalette floats inside as a top-left overlay */}
        {canvas.loading ? (
          <div className={s.canvas}>
            <p className={s.canvasEmpty}>Loading workflow…</p>
          </div>
        ) : (
          <div
            style={{
              flex: 1,
              minWidth: 0,
              position: "relative",
              display: "flex",
              flexDirection: "column",
              minHeight: 0,
            }}
          >
            {/* Floating palette button + popup */}
            <NodePalette onAdd={(entry) => canvas.addNode(entry)} />

            <WorkflowCanvas
              nodes={canvas.nodes}
              connections={canvas.connections}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onMove={canvas.moveNode}
              onConnect={canvas.connect}
              onDisconnect={canvas.disconnect}
              onRemove={(id) => {
                canvas.removeNode(id);
                if (selectedId === id) setSelectedId(null);
              }}
              onAddAt={(entry, position) => canvas.addNode(entry, position)}
              onClearCanvas={canvas.clear}
            />
          </div>
        )}
      </div>

      {/* ---------- node inspector popup (outside ideBody so it overlays everything) ---------- */}
      {selectedNode && (
        <NodeInspector
          key={selectedNode.id}
          node={selectedNode}
          onChange={(config) =>
            canvas.updateNodeConfig(selectedNode.id, config)
          }
          onRename={(name) => canvas.renameNode(selectedNode.id, name)}
          onClose={() => setSelectedId(null)}
        />
      )}

      {/* ---------- run drawer ---------- */}
      {showRun && runner.runId && (
        <div className={s.runDrawer}>
          <div className={s.runDrawerHead}>
            <h3 className={s.inspectorTitle}>Test run</h3>
            <button className={s.ghostBtn} onClick={() => setShowRun(false)}>
              Close
            </button>
          </div>
          <WorkflowRunView
            runId={runner.runId}
            onRunIdChange={() => undefined}
          />
        </div>
      )}

      <LoadWorkflowModal
        open={showLoadModal}
        onClose={() => setShowLoadModal(false)}
        manualWorkflowId={manualWorkflowId}
        onManualWorkflowIdChange={setManualWorkflowId}
        onLoadManualId={(id) => {
          handleLoadManualId(id);
        }}
        workflows={workflows}
        isLoading={isLoadingDrafts}
        selectedWorkflowId={selectedWorkflowId}
        onSelectWorkflow={setSelectedWorkflowId}
        onLoadSelectedWorkflow={handleLoadSelectedWorkflow}
      />
    </div>
  );
};
