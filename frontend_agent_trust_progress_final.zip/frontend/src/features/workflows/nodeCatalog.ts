import type {
  CanvasNodeConfig,
  WorkflowNodeType,
} from "@/types/workflow.types";

export interface NodeCatalogEntry {
  type: WorkflowNodeType;
  label: string;
  description: string;
  color: string;
  icon: string;
  removable: boolean;
  defaultConfig: CanvasNodeConfig;
}

export const NODE_CATALOG: Record<WorkflowNodeType, NodeCatalogEntry> = {
  Start: {
    type: "Start",
    label: "Start",
    description: "Workflow entry point and its inputs.",
    color: "#16a34a",
    icon: "play",
    removable: false,
    defaultConfig: { inputVariables: [] },
  },
  End: {
    type: "End",
    label: "End",
    description: "Workflow exit point and its outputs.",
    color: "#475569",
    icon: "stop",
    removable: true,
    defaultConfig: { outputVariables: [] },
  },
  Agent: {
    type: "Agent",
    label: "Agent",
    description: "Run an AI agent step.",
    color: "#2563eb",
    icon: "robot",
    removable: true,
    defaultConfig: { prompt: "", tools: [] },
  },
  Subagent: {
    type: "Subagent",
    label: "Subagent",
    description: "An agent that may call other agents.",
    color: "#4f46e5",
    icon: "robot",
    removable: true,
    defaultConfig: { prompt: "", tools: [] },
  },
  Conditional: {
    type: "Conditional",
    label: "Conditional",
    description: "Branch on a condition.",
    color: "#8b5cf6",
    icon: "branch",
    removable: true,
    defaultConfig: { branches: [] },
  },
  Loop: {
    type: "Loop",
    label: "Loop",
    description: "Repeat over a collection.",
    color: "#a855f7",
    icon: "repeat",
    removable: true,
    defaultConfig: { loopType: "for-each", maxIterations: 100 },
  },
  Map: {
    type: "Map",
    label: "Map",
    description: "Run an operation across items in parallel.",
    color: "#7c3aed",
    icon: "grid",
    removable: true,
    defaultConfig: { maxConcurrency: 5 },
  },
  HITL: {
    type: "HITL",
    label: "Human Review",
    description: "Pause for a person to approve, reject or request changes.",
    color: "#3b82f6",
    icon: "user",
    removable: true,
    defaultConfig: {
      title: "",
      message: "",
      priority: "medium",
      allowEdit: true,
    },
  },
  // "Self-Review": {
  //   type: "Self-Review",
  //   label: "Self-Review",
  //   description: "Model-checked quality gate.",
  //   color: "#10b981",
  //   icon: "check",
  //   removable: true,
  //   defaultConfig: {
  //     checkCompleteness: true,
  //     checkAccuracy: true,
  //     confidenceThreshold: 0.8,
  //   },
  // },
  API: {
    type: "API",
    label: "API Request",
    description: "Call a REST endpoint.",
    color: "#06b6d4",
    icon: "globe",
    removable: true,
    defaultConfig: { method: "GET", url: "" },
  },
  MCP: {
    type: "MCP",
    label: "MCP Server",
    description: "Call a tool on a Model Context Protocol server.",
    color: "#6366f1",
    icon: "plug",
    removable: true,
    defaultConfig: { toolName: "", transport_type: "http", timeout: 30 },
  },
  Code: {
    type: "Code",
    label: "Code",
    description: "Run a snippet of code.",
    color: "#0ea5e9",
    icon: "code",
    removable: true,
    defaultConfig: { language: "python", code: "" },
  },
};

/**
 * Palette order — entry and exit first, then the common steps.
 *
 * **Every entry here compiles to a node that does what its name says.** The
 * compiler's dispatcher has a dedicated factory for each one; anything else
 * falls through to the agent factory and runs as a plain LLM step.
 *
 * Three types are therefore deliberately absent — see {@link RETIRED_NODE_TYPES}.
 */
export const PALETTE_ORDER: WorkflowNodeType[] = [
  "Start",
  "Agent",
  "Conditional",
  "HITL",
  // "Self-Review",
  "API",
  "MCP",
  "Code",
  "End",
];

export const RETIRED_NODE_TYPES: Partial<Record<string, string>> = {
  Loop: "Loop steps are not executed yet — this node runs as a single agent step. It is kept so existing workflows still load, but it is no longer offered.",
  Map: "Map steps are not executed yet — this node runs as a single agent step. It is kept so existing workflows still load, but it is no longer offered.",
  Subagent:
    "Subagent has been withdrawn. It runs as an ordinary agent step; use an Agent node instead.",
};

export const catalogFor = (type: string): NodeCatalogEntry | undefined =>
  NODE_CATALOG[type as WorkflowNodeType];
