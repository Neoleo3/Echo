"use client";

import React, { useMemo, useState } from "react";
import type { LLMModel, LlmProviderCatalogEntry } from "@/types";
import {
  DEFAULT_PROVIDER,
  FIELD_META,
  LLM_ICONS,
  LLM_MODEL_FAMILIES,
  LLM_PROVIDERS,
  LLM_REASONING_EFFORTS,
  PROVIDER_SCOPED_FIELDS,
  USAGE_LIMIT_DURATIONS,
  WORKBENCH_PROVIDER_OPTIONS,
  requiredVisibleFieldsFor,
  visibleFieldsFor,
  type LlmFieldKey,
  type LlmMode,
} from "./llmFormConfig";
import s from "@/styles/config.module.css";
import { LlmFormValues } from "@/hooks/useLLMs";

interface LlmFormDialogProps {
  mode: LlmMode;
  editing: LLMModel | null;
  form: LlmFormValues;
  providers: LlmProviderCatalogEntry[] | null;
  submitting: boolean;
  error: string | null;
  onFieldChange: (key: string, value: unknown) => void;
  onPatch: (patch: LlmFormValues) => void;
  onModeChange: (mode: LlmMode) => void;
  onSubmit: () => void;
  onClose: () => void;
  onTest?: () => Promise<{ ok: boolean; message: string }>;
}

const isPositiveInteger = (raw: string): boolean =>
  /^\d+$/.test(raw.trim()) && Number(raw.trim()) > 0;

const isTemperature = (raw: string): boolean => {
  const value = Number(raw.trim());
  return /^\d*\.?\d+$/.test(raw.trim()) && value >= 0 && value <= 2;
};

export const LlmFormDialog: React.FC<LlmFormDialogProps> = ({
  mode,
  editing,
  form,
  providers,
  submitting,
  error,
  onFieldChange,
  onPatch,
  onModeChange,
  onSubmit,
  onClose,
  onTest,
}) => {
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [testState, setTestState] = useState<{
    running: boolean;
    ok?: boolean;
    message?: string;
  }>({ running: false });

  const isMarketplace = mode === "marketplace";
  const provider = form.provider || (isMarketplace ? DEFAULT_PROVIDER : "");

  const visibleFields = useMemo(
    () => visibleFieldsFor(mode, provider, providers),
    [mode, provider, providers],
  );

  const requiredFields = useMemo(
    () => requiredVisibleFieldsFor(mode, provider, providers, !!editing),
    [mode, provider, providers, editing],
  );

  const fieldErrors = useMemo(() => {
    const errors: Partial<Record<LlmFieldKey, string>> = {};

    requiredFields.forEach((field) => {
      const value = (form as Record<string, unknown>)[field];
      if (typeof value === "string" ? !value.trim() : value == null) {
        errors[field] = `${FIELD_META[field].label} is required.`;
      }
    });

    const ctx = (form.context_window ?? "").trim();
    if (ctx && !isPositiveInteger(ctx)) {
      errors.context_window = "Enter a whole number of tokens, e.g. 128000.";
    }

    const maxOut = (form.max_output_tokens ?? "").trim();
    if (maxOut && !isPositiveInteger(maxOut)) {
      errors.max_output_tokens = "Enter a whole number of tokens, e.g. 4096.";
    }

    const temp = (form.temperature ?? "").trim();
    if (temp && !isTemperature(temp)) {
      errors.temperature = "Enter a number between 0 and 2, e.g. 0.7.";
    }

    return errors;
  }, [form, requiredFields]);

  const isValid = Object.keys(fieldErrors).length === 0;

  const handleProviderChange = (next: string) => {
    const nextVisible = visibleFieldsFor(mode, next, providers);
    const cleared: LlmFormValues = { provider: next };

    PROVIDER_SCOPED_FIELDS.forEach((field) => {
      if (!nextVisible.includes(field)) {
        (cleared as Record<string, unknown>)[field] = "";
      }
    });

    onPatch(cleared);
  };

  const handleTest = async () => {
    if (!onTest) return;
    setTestState({ running: true });
    const result = await onTest();
    setTestState({ running: false, ok: result.ok, message: result.message });
  };

  const title = editing
    ? `Edit ${editing.name || "LLM"}`
    : isMarketplace
      ? "Add Marketplace Model"
      : provider === "workbench"
        ? "Add KPMG Workbench Model"
        : "Add via Workbench";

  const subtitle = editing
    ? "Update this model's connection details."
    : isMarketplace
      ? "Register a model from a known provider."
      : provider === "workbench"
        ? "Connect a model through the KPMG Workbench gateway."
        : "Connect a custom or on-prem model endpoint.";

  const renderField = (field: LlmFieldKey) => {
    const meta = FIELD_META[field];
    const required = requiredFields.includes(field);
    const invalid = touched[field] && fieldErrors[field];
    const value = (form as Record<string, unknown>)[field];

    const label =
      field === "provider" && !isMarketplace && provider !== "workbench"
        ? "Endpoint Type"
        : meta.label;

    const apiKeyLabel = editing
      ? editing.api_key_set
        ? "API Key (a key is saved — leave blank to keep it)"
        : "API Key (none saved yet)"
      : label;

    const labelNode = (
      <label htmlFor={`lf-${field}`}>
        {field === "api_key" ? apiKeyLabel : label}
        {required && <span className={s.req}> *</span>}
      </label>
    );

    const markTouched = () =>
      setTouched((prev) => ({ ...prev, [field]: true }));

    let control: React.ReactNode;

    if (field === "enabled") {
      return (
        <div key={field} className={`${s.llmFormField} ${s.llmFormFull}`}>
          <label className={s.llmCheckLabel}>
            <input
              id={`lf-${field}`}
              type="checkbox"
              className={s.llmCheckbox}
              checked={form.enabled !== false}
              onChange={(e) => onFieldChange("enabled", e.target.checked)}
            />
            Enabled — offer this model when choosing an LLM
          </label>
        </div>
      );
    }

    if (field === "is_embedding") {
      return (
        <div key={field} className={`${s.llmFormField} ${s.llmFormFull}`}>
          <label className={s.llmCheckLabel}>
            <input
              id={`lf-${field}`}
              type="checkbox"
              className={s.llmCheckbox}
              checked={!!form.is_embedding}
              onChange={(e) => onFieldChange("is_embedding", e.target.checked)}
            />
            {FIELD_META.is_embedding.label} — {FIELD_META.is_embedding.hint}
          </label>
        </div>
      );
    }

    if (field === "provider") {
      control = (
        <select
          id={`lf-${field}`}
          value={provider}
          onChange={(e) => handleProviderChange(e.target.value)}
          onBlur={markTouched}
        >
          {!provider && <option value="">Select a provider…</option>}
          {LLM_PROVIDERS.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
        </select>
      );
    } else if (field === "workbench_provider") {
      control = (
        <select
          id={`lf-${field}`}
          value={(value as string) || ""}
          onChange={(e) => onFieldChange("workbench_provider", e.target.value)}
          onBlur={markTouched}
        >
          <option value="">Select underlying provider…</option>
          {WORKBENCH_PROVIDER_OPTIONS.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
        </select>
      );
    } else if (field === "usage_limit_duration") {
      control = (
        <select
          id={`lf-${field}`}
          value={(value as string) || ""}
          onChange={(e) =>
            onFieldChange("usage_limit_duration", e.target.value)
          }
          onBlur={markTouched}
        >
          {USAGE_LIMIT_DURATIONS.map((entry) => (
            <option key={entry.value || "none"} value={entry.value}>
              {entry.label}
            </option>
          ))}
        </select>
      );
    } else if (field === "icon") {
      control = (
        <select
          id={`lf-${field}`}
          value={(value as string) || "default"}
          onChange={(e) => onFieldChange("icon", e.target.value)}
        >
          {LLM_ICONS.map((icon) => (
            <option key={icon.value} value={icon.value}>
              {icon.label}
            </option>
          ))}
        </select>
      );
    } else if (field === "model_family") {
      control = (
        <select
          id={`lf-${field}`}
          value={(value as string) || "auto"}
          onChange={(e) => onFieldChange("model_family", e.target.value)}
        >
          {LLM_MODEL_FAMILIES.map((entry) => (
            <option key={entry.value} value={entry.value}>
              {entry.label}
            </option>
          ))}
        </select>
      );
    } else if (field === "reasoning_effort") {
      control = (
        <select
          id={`lf-${field}`}
          value={(value as string) ?? ""}
          onChange={(e) => onFieldChange("reasoning_effort", e.target.value)}
          disabled={form.model_family === "gpt4"}
        >
          {LLM_REASONING_EFFORTS.map((entry) => (
            <option key={entry.value || "default"} value={entry.value}>
              {entry.label}
            </option>
          ))}
        </select>
      );
    } else if (meta.type === "textarea") {
      control = (
        <textarea
          id={`lf-${field}`}
          placeholder={meta.placeholder}
          value={(value as string) || ""}
          onChange={(e) => onFieldChange(field, e.target.value)}
          onBlur={markTouched}
        />
      );
    } else {
      control = (
        <input
          id={`lf-${field}`}
          type={meta.type === "password" ? "password" : "text"}
          inputMode={
            field === "temperature"
              ? "decimal"
              : meta.type === "number"
                ? "numeric"
                : undefined
          }
          placeholder={
            field === "api_key" && editing?.api_key_set
              ? "••••••••  (leave blank to keep the saved key)"
              : meta.placeholder
          }
          value={(value as string) || ""}
          onChange={(e) => onFieldChange(field, e.target.value)}
          onBlur={markTouched}
          autoFocus={field === "name"}
        />
      );
    }

    return (
      <div
        key={field}
        className={`${s.llmFormField}${meta.full ? ` ${s.llmFormFull}` : ""}`}
      >
        {labelNode}
        {control}
        {invalid ? (
          <span className={s.fieldError}>{fieldErrors[field]}</span>
        ) : (
          meta.hint && <span className={s.fieldHint}>{meta.hint}</span>
        )}
      </div>
    );
  };

  const handleSubmit = () => {
    if (!isValid) {
      setTouched(
        visibleFields.reduce<Record<string, boolean>>((acc, f) => {
          acc[f] = true;
          return acc;
        }, {}),
      );
      return;
    }
    onSubmit();
  };

  return (
    <div className={s.overlay} onClick={onClose}>
      <div className={s.llmFormDialog} onClick={(e) => e.stopPropagation()}>
        <div className={s.dialogHead}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div className={s.llmFormIcon}>
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="2" y="3" width="20" height="14" rx="2" />
                <polyline points="8 21 12 17 16 21" />
              </svg>
            </div>
            <div>
              <h3 style={{ margin: 0, fontSize: 18 }}>{title}</h3>
              <p
                style={{
                  margin: "2px 0 0",
                  fontSize: 12.5,
                  color: "var(--text-soft)",
                }}
              >
                {subtitle}
              </p>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {!editing && (
              <button
                type="button"
                className={s.llmSwapBtn}
                title={`Switch to ${isMarketplace ? "Workbench" : "Marketplace"}`}
                onClick={() =>
                  onModeChange(isMarketplace ? "workbench" : "marketplace")
                }
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M7 16V4m0 0L3 8m4-4 4 4" />
                  <path d="M17 8v12m0 0 4-4m-4 4-4-4" />
                </svg>
              </button>
            )}
            <button
              type="button"
              className={s.dialogClose}
              onClick={onClose}
              aria-label="Close"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
              >
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>

        <div className={s.dialogBodyLlm}>
          {error && (
            <div className={s.formError} role="alert">
              {error}
            </div>
          )}

          <div className={s.llmFormGrid}>{visibleFields.map(renderField)}</div>

          {editing && onTest && (
            <div className={s.llmTestRow}>
              <button
                type="button"
                className={s.llmBtn}
                onClick={handleTest}
                disabled={testState.running}
              >
                {testState.running ? "Testing…" : "Test connection"}
              </button>
              {testState.message && (
                <span
                  className={testState.ok ? s.testOk : s.testFail}
                  role="status"
                >
                  {testState.message}
                </span>
              )}
            </div>
          )}
        </div>

        <div className={s.dialogFoot}>
          <button type="button" className={s.btnGhost} onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className={s.btnPrimary}
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? "Saving…" : editing ? "Save LLM" : "Create LLM"}
          </button>
        </div>
      </div>
    </div>
  );
};
