import type {
  LlmModelFamily,
  LlmProviderCatalogEntry,
  LlmReasoningEffort,
} from "@/types";

export type LlmFieldKey =
  | "name"
  | "icon"
  | "provider"
  | "model_name"
  | "base_url"
  | "api_key"
  | "api_version"
  | "deployment_name"
  | "model_family"
  | "reasoning_effort"
  | "context_window"
  | "max_output_tokens"
  | "temperature"
  | "description"
  | "enabled"
  | "is_embedding"
  // Workbench-specific fields
  | "credential_name"
  | "workbench_provider"
  | "charge_code"
  | "region_override"
  | "azureml_model_deployment"
  // Token usage limit fields (marketplace / non-workbench only)
  | "token_usage_limit"
  | "usage_limit_duration";

export type LlmMode = "marketplace" | "workbench";

export const LLM_PROVIDERS: ReadonlyArray<{ id: string; label: string }> = [
  { id: "azure", label: "Azure OpenAI" },
  { id: "openai", label: "OpenAI" },
  { id: "anthropic", label: "Anthropic" },
  { id: "gemini", label: "Google Gemini" },
  { id: "ollama", label: "Ollama (On-Prem)" },
  { id: "workbench", label: "KPMG Workbench" },
];

export const WORKBENCH_PROVIDER_OPTIONS: ReadonlyArray<{
  id: string;
  label: string;
}> = [
  { id: "openai", label: "OpenAI" },
  { id: "azure", label: "Azure OpenAI" },
  { id: "anthropic", label: "Anthropic" },
  { id: "gemini", label: "Google Gemini" },
];

export const DEFAULT_PROVIDER = "azure";

export const LLM_ICONS: ReadonlyArray<{ value: string; label: string }> = [
  { value: "default", label: "Generic LLM" },
  { value: "openAI", label: "OpenAI" },
  { value: "claudeAI", label: "Claude AI" },
  { value: "meta_llama", label: "LLAMA" },
  { value: "nomicAI", label: "Nomic AI" },
  { value: "qwen3", label: "Qwen 3" },
  { value: "mistralAI", label: "Mistral AI" },
];

const CORE_FIELDS: readonly LlmFieldKey[] = [
  "name",
  "icon",
  "provider",
  "model_name",
  "base_url",
];

const CONDITIONAL_FIELDS: readonly LlmFieldKey[] = [
  "api_version",
  "deployment_name",
  "api_key",
];

export const MODEL_FAMILY_PROVIDERS: readonly string[] = ["azure", "openai"];

const FAMILY_FIELDS: readonly LlmFieldKey[] = [
  "model_family",
  "reasoning_effort",
];

const TUNING_FIELDS: readonly LlmFieldKey[] = [
  "context_window",
  "max_output_tokens",
  "temperature",
];

const LIMIT_FIELDS: readonly LlmFieldKey[] = [
  "token_usage_limit",
  "usage_limit_duration",
];

export const LLM_MODEL_FAMILIES: ReadonlyArray<{
  value: LlmModelFamily;
  label: string;
}> = [
  { value: "auto", label: "Auto-detect from the model name" },
  { value: "gpt4", label: "GPT-4 family and earlier" },
  { value: "gpt5", label: "GPT-5 family / o-series (reasoning)" },
];

export const LLM_REASONING_EFFORTS: ReadonlyArray<{
  value: LlmReasoningEffort | "";
  label: string;
}> = [
  { value: "", label: "Provider default" },
  {
    value: "none",
    label: "None — no reasoning (required with tools on gpt-5.6+)",
  },
  { value: "minimal", label: "Minimal" },
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "xhigh", label: "Extra high" },
  { value: "max", label: "Max" },
];

/** Full-width trailing fields. */
const TRAILING_FIELDS: readonly LlmFieldKey[] = [
  "description",
  "enabled",
  "is_embedding",
];

export const FALLBACK_REQUIRED_FIELDS: Readonly<Record<string, string[]>> = {
  azure: ["api_key", "base_url", "deployment_name", "api_version"],
  openai: ["api_key"],
  anthropic: ["api_key"],
  gemini: ["api_key"],
  ollama: ["base_url"],
};

const ALWAYS_REQUIRED: readonly LlmFieldKey[] = ["name", "model_name"];

export function requiredFieldsFor(
  providerId: string,
  catalog: readonly LlmProviderCatalogEntry[] | null,
): string[] {
  const fromCatalog = catalog?.find((p) => p.id === providerId);
  if (fromCatalog?.requires_fields?.length) {
    return [...fromCatalog.requires_fields];
  }
  return [...(FALLBACK_REQUIRED_FIELDS[providerId] ?? [])];
}

export function visibleFieldsFor(
  mode: LlmMode,
  providerId: string,
  catalog: readonly LlmProviderCatalogEntry[] | null,
): LlmFieldKey[] {
  if (mode === "workbench") {
    if (providerId === "workbench") {
      return [
        "name",
        "icon",
        "provider",
        "credential_name",
        "api_key",
        "base_url",
        "api_version",
        "deployment_name",
        "workbench_provider",
        "charge_code",
        "region_override",
        "azureml_model_deployment",
        "model_name",
        ...TUNING_FIELDS,
        ...TRAILING_FIELDS,
      ];
    }

    return [
      "name",
      "icon",
      "provider",
      "model_name",
      "base_url",
      "api_key",
      ...familyFieldsFor(providerId),
      ...TUNING_FIELDS,
      ...TRAILING_FIELDS,
    ];
  }

  const required = requiredFieldsFor(providerId, catalog);
  const conditional = CONDITIONAL_FIELDS.filter((f) => required.includes(f));

  return [
    ...CORE_FIELDS,
    ...conditional,
    ...familyFieldsFor(providerId),
    ...TUNING_FIELDS,
    ...LIMIT_FIELDS,
    ...TRAILING_FIELDS,
  ];
}

/**
 * The family fields, for the two providers where they change the request.
 *
 * Anthropic, Gemini and Ollama have no reasoning-parameter restrictions, so
 * offering the choice there would be a control that does nothing — which is
 * exactly the defect the Top P slider had.
 */
function familyFieldsFor(providerId: string): LlmFieldKey[] {
  return MODEL_FAMILY_PROVIDERS.includes(providerId) ? [...FAMILY_FIELDS] : [];
}

/**
 * Which visible fields the user must fill before the form can be submitted.
 *
 * In edit mode `api_key` drops out: the backend never returns a stored key, so
 * a blank input means "keep the current one", not "no key".
 */
export function requiredVisibleFieldsFor(
  mode: LlmMode,
  providerId: string,
  catalog: readonly LlmProviderCatalogEntry[] | null,
  isEditing: boolean,
): LlmFieldKey[] {
  const visible = visibleFieldsFor(mode, providerId, catalog);
  const required = requiredFieldsFor(providerId, catalog);

  // Workbench (KPMG gateway) has its own fixed required set.
  const workbenchRequired: LlmFieldKey[] = [
    "name",
    "provider",
    "credential_name",
    "api_key",
    "workbench_provider",
    "charge_code",
  ];

  const result = visible.filter(
    (field) =>
      ALWAYS_REQUIRED.includes(field) ||
      field === "provider" ||
      // Workbench points at an arbitrary endpoint, so its URL is the one thing
      // that cannot be inferred.
      (mode === "workbench" &&
        providerId !== "workbench" &&
        field === "base_url") ||
      (mode === "workbench" &&
        providerId === "workbench" &&
        workbenchRequired.includes(field)) ||
      (mode === "marketplace" && required.includes(field)),
  );

  return isEditing ? result.filter((f) => f !== "api_key") : result;
}

/** Per-field presentation. Kept beside the field list so a new field cannot be
 *  rendered without a label. */
export const FIELD_META: Readonly<
  Record<
    LlmFieldKey,
    {
      label: string;
      placeholder?: string;
      hint?: string;
      type?:
        | "text"
        | "password"
        | "number"
        | "textarea"
        | "select"
        | "checkbox";
      full?: boolean;
    }
  >
> = {
  name: {
    label: "Name",
    placeholder: "e.g., Azure/gpt-4o-mini",
    hint: "Shown on the model card. Must be unique in this workspace.",
    type: "text",
  },
  icon: { label: "Logo", type: "select" },
  provider: {
    label: "Provider",
    type: "select",
    hint: "Decides which connection details this model needs.",
  },
  model_name: {
    label: "Model Name",
    placeholder: "e.g., gpt-4o-mini",
    hint: "The model identifier as the provider knows it.",
    type: "text",
  },
  base_url: {
    label: "Base URL",
    placeholder: "https://your-endpoint/v1",
    type: "text",
  },
  api_key: {
    label: "API Key",
    placeholder: "Paste the provider API key…",
    hint: "Stored in Key Vault. Never returned by the API once saved.",
    type: "password",
  },
  api_version: {
    label: "API Version",
    placeholder: "e.g., 2024-02-15-preview",
    type: "text",
  },
  deployment_name: {
    label: "Deployment Name",
    placeholder: "Your Azure deployment",
    hint: "Azure routes by deployment, not by model name.",
    type: "text",
  },
  model_family: {
    label: "Model Family",
    type: "select",
    hint:
      "GPT-5 and the o-series reject temperature and top-p. Leave on auto-detect " +
      "unless your Azure deployment is named something that does not say which " +
      "model it serves.",
  },
  reasoning_effort: {
    label: "Reasoning Effort",
    type: "select",
    // Newer reasoning models refuse function tools alongside any effort other
    // than "none" on Chat Completions. The backend routes those builds to the
    // Responses API automatically so the configured effort survives — but only
    // when the API Version is recent enough to address that surface, which is
    // why it is called out here rather than left to fail at run time.
    hint:
      "GPT-5 family only; ignored by GPT-4 and earlier. Agents with tools are " +
      "routed to the Responses API automatically so this setting is kept — " +
      "that needs an API Version of 2025-03-01-preview or later, otherwise " +
      "effort drops to 'none' for those agents.",
  },
  context_window: {
    label: "Context Window",
    placeholder: "e.g., 128000",
    hint: "Optional. Tokens of input this model accepts.",
    type: "number",
  },
  max_output_tokens: {
    label: "Default Output Tokens",
    placeholder: "Leave blank for the model's full length",
    // Says what the field actually does. It was labelled "Max Output Tokens"
    // and hinted "Caps generated tokens", which promised a hard ceiling it has
    // never been: an agent carrying its own larger value still overrides it.
    hint:
      "Optional. Used when an agent sets no limit of its own, and caps the " +
      "platform minimum. An agent with a higher limit still overrides it. " +
      "Blank means the model's full output length.",
    type: "number",
  },
  temperature: {
    label: "Default Temperature",
    placeholder: "e.g., 0.7",
    hint: "Optional. Used only when a caller states none.",
    type: "number",
  },
  description: {
    label: "Description",
    placeholder: "Short description shown on the card.",
    type: "textarea",
    full: true,
  },
  enabled: { label: "Enabled", type: "checkbox", full: true },
  is_embedding: {
    label: "This is an embedding model",
    hint: "Used wherever an embedding model is required — knowledge base ingestion and search.",
    type: "checkbox",
    full: true,
  },
  // ── Workbench (KPMG gateway) fields ────────────────────────────────────
  credential_name: {
    label: "Credential Name",
    placeholder: "e.g., KPMG Workbench GPT-4o",
    hint: "A human-readable name for this Workbench credential.",
    type: "text",
  },
  workbench_provider: {
    label: "Workbench Provider",
    type: "select",
    hint: "The underlying model provider routed through the Workbench gateway.",
  },
  charge_code: {
    label: "Charge Code",
    placeholder: "e.g., 00000",
    hint: "Billing charge code for Workbench usage tracking.",
    type: "text",
  },
  region_override: {
    label: "Region Override",
    placeholder: "e.g., westeurope",
    hint: "Optional. Override the default Azure region for this credential.",
    type: "text",
  },
  azureml_model_deployment: {
    label: "AzureML Model Deployment",
    placeholder: "e.g., gpt-4o-deployment",
    hint: "Optional. Specific AzureML deployment name if applicable.",
    type: "text",
  },
  // ── Token usage limits ────────────────────────────────────────────────────
  token_usage_limit: {
    label: "Token Usage Limit",
    placeholder: "e.g., 100000",
    hint: "Optional. Maximum tokens allowed per duration window. Leave blank for no limit.",
    type: "number",
  },
  usage_limit_duration: {
    label: "Limit Duration",
    type: "select",
    hint: "The time window over which the token usage limit is enforced.",
  },
};

/** Options for the token usage limit duration window. */
export const USAGE_LIMIT_DURATIONS: ReadonlyArray<{
  value: "minute" | "hour" | "day" | "";
  label: string;
}> = [
  { value: "", label: "No limit" },
  { value: "minute", label: "Per minute" },
  { value: "hour", label: "Per hour" },
  { value: "day", label: "Per day" },
];

/** Fields that carry a value only for some providers. When one stops being
 *  visible its value must be dropped, or a stale Azure deployment name would
 *  be submitted alongside an OpenAI credential — or a `gpt5` family left over
 *  from an Azure deployment would follow the user to an Anthropic model, where
 *  the backend would ignore it but the form would still show it. */
export const PROVIDER_SCOPED_FIELDS: readonly LlmFieldKey[] = [
  "api_version",
  "deployment_name",
  "api_key",
  "model_family",
  "reasoning_effort",
  "credential_name",
  "workbench_provider",
  "charge_code",
  "region_override",
  "azureml_model_deployment",
];
