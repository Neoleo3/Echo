"use client";

import { useCallback, useEffect, useState } from "react";
import {
  agentsService,
  extractAgentItems,
  extractAgentMeta,
} from "@/services/agents.service";
import type { AgentDefinition } from "@/types/agents.types";

export const agentIdOf = (agent: AgentDefinition): string =>
  agent.agent_id ?? "";

export function useAgents() {
  const [agents, setAgents] = useState<AgentDefinition[]>([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const response = await agentsService.listAgents(page, pageSize, search);
    setLoading(false);
    if (response.success) {
      const items = extractAgentItems(response.data);
      const meta = extractAgentMeta(response.data, page, pageSize);
      setAgents(items);
      setTotal(meta.total);
      setError(null);
      return;
    }
    setError(response.error ?? "Could not load agents.");
  }, [page, pageSize, search]);

  useEffect(() => {
    load();
  }, [load]);

  const remove = useCallback(
    async (agentId: string) => {
      const response = await agentsService.deleteAgent(agentId);
      if (!response.success) {
        setError(response.error ?? "Could not delete that agent.");
        return false;
      }
      await load();
      return true;
    },
    [load],
  );

  const onSearchChange = useCallback((value: string) => {
    setSearch(value);
    setPage(1);
  }, []);

  const onPageSizeChange = useCallback((value: number) => {
    setPageSize(value);
    setPage(1);
  }, []);

  return {
    agents,
    loading,
    error,
    page,
    pageSize,
    total,
    search,
    reload: load,
    remove,
    onPageChange: setPage,
    onPageSizeChange,
    onSearchChange,
  };
}
