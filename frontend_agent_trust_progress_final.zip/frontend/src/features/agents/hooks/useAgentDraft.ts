"use client";

import { useCallback, useState } from "react";
import { agentsService } from "@/services/agents.service";
import type {
  AgentDefinition,
  AgentDraft,
  AgentModelConfig,
} from "@/types/agents.types";

export interface AgentDraftForm {
  agent_id?: string;
  name: string;
  description: string;
  instructions: string;
  icon: string;
  tools: string[];
  credential_id: string;
  model_config: AgentModelConfig;
}

export const EMPTY_DRAFT: AgentDraftForm = {
  name: "",
  description: "",
  instructions: "",
  icon: "",
  tools: [],
  credential_id: "",
  model_config: { model: "", temperature: 0.7, top_p: 0.9 },
};

export function definitionToDraft(agent: AgentDefinition): AgentDraftForm {
  return {
    agent_id: agent.agent_id,
    name: agent.name ?? "",
    description: agent.description ?? agent.goal ?? "",
    instructions: agent.instructions ?? agent.prompt ?? "",
    icon: agent.icon ?? "",
    // tools: Array.isArray(agent.tools) ? agent.tools : [],
    tools: Array.isArray(agent.tools)
      ? agent.tools
          .map((t) =>
            typeof t === "string"
              ? t
              : ((t as { tool_id?: string }).tool_id ?? ""),
          )
          .filter(Boolean)
      : [],
    credential_id: agent.credential_id ?? "",
    model_config: {
      ...EMPTY_DRAFT.model_config,
      ...(agent.model_config ?? {}),
    },
  };
}

export function draftToPayload(form: AgentDraftForm): AgentDraft {
  const payload: AgentDraft = {
    schema_version: "agent_builder_v2",
    name: form.name.trim(),
    description: form.description.trim(),
    instructions: form.instructions.trim(),
    tools: form.tools,
    model_config: form.model_config,
  };
  if (form.agent_id) payload.agent_id = form.agent_id;
  if (form.icon) payload.icon = form.icon;
  if (form.credential_id) payload.credential_id = form.credential_id;
  return payload;
}

export function useAgentDraft(initial: AgentDraftForm = EMPTY_DRAFT) {
  const [form, setForm] = useState<AgentDraftForm>(initial);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(
    initial.agent_id ?? null,
  );

  const update = useCallback(
    <K extends keyof AgentDraftForm>(key: K, value: AgentDraftForm[K]) => {
      setForm((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  const updateModelConfig = useCallback(
    (changes: Partial<AgentModelConfig>) => {
      setForm((prev) => ({
        ...prev,
        model_config: { ...prev.model_config, ...changes },
      }));
    },
    [],
  );

  const loadFrom = useCallback((agent: AgentDefinition) => {
    const next = definitionToDraft(agent);
    setForm(next);
    setSavedId(next.agent_id ?? null);
    setError(null);
  }, []);

  const loadDraft = useCallback((next: AgentDraftForm) => {
    setForm(next);
    setSavedId(null);
    setError(null);
  }, []);

  const reset = useCallback(() => {
    setForm(EMPTY_DRAFT);
    setSavedId(null);
    setError(null);
  }, []);

  const save = useCallback(
    async (override?: AgentDraftForm): Promise<string | null> => {
      const source = override ?? form;
      if (!source.name.trim()) {
        setError("Give the agent a name first.");
        return null;
      }

      setSaving(true);
      setError(null);

      const response = await agentsService.registerAgent(
        draftToPayload(source),
      );
      setSaving(false);

      if (!response.success || !response.data) {
        setError(response.error ?? "Could not save the agent.");
        return null;
      }

      const agentId =
        response.data.agent_id ?? response.data.saved_agent?.agent_id ?? null;
      if (agentId) {
        setSavedId(agentId);
        setForm((prev) => ({ ...prev, agent_id: agentId }));
      }
      return agentId;
    },
    [form],
  );

  const ensureSaved = useCallback(async (): Promise<string | null> => {
    if (savedId) return savedId;
    return save();
  }, [savedId, save]);

  return {
    form,
    update,
    updateModelConfig,
    loadFrom,
    loadDraft,
    reset,
    save,
    ensureSaved,
    saving,
    error,
    setError,
    savedId,
  };
}
