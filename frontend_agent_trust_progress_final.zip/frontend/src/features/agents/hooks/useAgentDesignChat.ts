"use client";

import { useCallback, useState } from "react";
import { agentsService } from "@/services/agents.service";
import type { AgentDesignResponse, DesignStep } from "@/types/agents.types";

export interface DesignTurn {
  id: string;
  role: "user" | "assistant";
  text: string;
  changedFields?: string[];
}

export function useAgentDesignChat() {
  const [turns, setTurns] = useState<DesignTurn[]>([]);
  const [step, setStep] = useState<DesignStep | string>("initial");
  const [agentState, setAgentState] = useState<Record<string, unknown>>({});
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reset = useCallback(() => {
    setTurns([]);
    setStep("initial");
    setAgentState({});
    setError(null);
  }, []);

  const send = useCallback(
    async (message: string) => {
      const text = message.trim();
      if (!text || sending) return;

      setError(null);
      setSending(true);
      setTurns((prev) => [
        ...prev,
        { id: `u-${Date.now()}`, role: "user", text },
      ]);

      const response = await agentsService.designChat({
        message: text,
        step,
        agent_state: agentState,
      });

      setSending(false);

      if (!response.success || !response.data) {
        setError(response.error ?? "The builder could not respond.");
        return;
      }

      const data = response.data as AgentDesignResponse;

      const metadata = (data.agent_state?.metadata ?? {}) as {
        changed_fields?: unknown;
      };
      const changed = Array.isArray(metadata.changed_fields)
        ? metadata.changed_fields.map((entry) =>
            typeof entry === "string"
              ? entry
              : String((entry as { field?: unknown })?.field ?? entry),
          )
        : undefined;
      setTurns((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: "assistant",
          text: data.reply,
          changedFields: changed,
        },
      ]);
      if (data.step) setStep(data.step);
      if (data.agent_state) setAgentState(data.agent_state);
    },
    [agentState, sending, step],
  );

  const agentId =
    typeof agentState.agent_id === "string" ? agentState.agent_id : null;

  return { turns, step, agentState, agentId, sending, error, send, reset };
}
