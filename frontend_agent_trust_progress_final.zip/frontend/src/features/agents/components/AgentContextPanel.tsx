"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { agentsService } from "@/services/agents.service";
import { ConnectorPickerModal } from "./ConnectorPickerModal";
import type {
  AgentFile,
  AgentKnowledgeBase,
  AttachedConnector,
  MarkitdownStatus,
} from "@/types/agents.types";
import s from "./agents.module.css";

interface AgentContextPanelProps {
  agentId: string | null;
  ensureAgent: () => Promise<string | null>;
}

type SourceRow =
  | { rowType: "connector"; key: string; connector: AttachedConnector }
  | { rowType: "file"; key: string; file: AgentFile }
  | { rowType: "knowledge"; key: string; base: AgentKnowledgeBase };

const isInFlight = (file: AgentFile): boolean =>
  file.status === "pending" || file.status === "processing";

const looksLikeUrl = (value: string): boolean =>
  /^https?:\/\//i.test(value) || /^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(value);

const fileStatusText = (file: AgentFile): string => {
  switch (file.status) {
    case "pending":
      return "Queued";
    case "processing":
      return "Reading…";
    case "ready":
      return file.ingest_mode === "inline"
        ? "Included in full"
        : `${file.chunk_count ?? 0} passages`;
    case "failed":
      return file.error_message || "Failed";
    default:
      return String(file.status ?? "");
  }
};

export const AgentContextPanel: React.FC<AgentContextPanelProps> = ({
  agentId,
  ensureAgent,
}) => {
  const [gateEnabled, setGateEnabled] = useState(false);
  const [connectors, setConnectors] = useState<AttachedConnector[]>([]);
  const [files, setFiles] = useState<AgentFile[]>([]);
  const [bases, setBases] = useState<AgentKnowledgeBase[]>([]);
  const [availableBases, setAvailableBases] = useState<AgentKnowledgeBase[]>(
    [],
  );
  const [environment, setEnvironment] = useState<MarkitdownStatus | null>(null);

  const [sourceText, setSourceText] = useState("");
  const [dragging, setDragging] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerAgentId, setPickerAgentId] = useState<string | null>(null);
  const [kbOpen, setKbOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileRef = useRef<HTMLInputElement | null>(null);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const delayRef = useRef(2000);

  /* ---------------- loading ---------------- */

  const load = useCallback(async (id: string) => {
    const [filesRes, connectorsRes, basesRes] = await Promise.all([
      agentsService.getFiles(id),
      agentsService.getConnectors(id),
      agentsService.getKnowledgeBases(id),
    ]);

    if (filesRes.success && filesRes.data) {
      setFiles(filesRes.data.files ?? []);
      setGateEnabled(Boolean(filesRes.data.connector_settings?.enabled));
    }

    if (connectorsRes.success && connectorsRes.data) {
      setConnectors(connectorsRes.data.connectors ?? []);
    }
    if (basesRes.success && basesRes.data) {
      setBases(basesRes.data.knowledge_bases ?? []);
    }
  }, []);

  useEffect(() => {
    if (agentId) load(agentId);
  }, [agentId, load]);

  useEffect(() => {
    agentsService.getMarkitdownStatus().then((response) => {
      if (response.success && response.data) setEnvironment(response.data);
    });
  }, []);

  useEffect(() => {
    if (pollRef.current) clearTimeout(pollRef.current);
    if (!agentId || !files.some(isInFlight)) {
      delayRef.current = 2000;
      return;
    }
    pollRef.current = setTimeout(() => {
      delayRef.current = Math.min(delayRef.current * 1.5, 15000);
      load(agentId);
    }, delayRef.current);
    return () => {
      if (pollRef.current) clearTimeout(pollRef.current);
    };
  }, [agentId, files, load]);

  const withAgent = async (action: (id: string) => Promise<void>) => {
    setError(null);
    setBusy(true);
    const id = agentId ?? (await ensureAgent());
    if (!id) {
      setBusy(false);
      setError("Give the agent a name first.");
      return;
    }
    await action(id);
    await load(id);
    setBusy(false);
  };

  const toggleGate = (enabled: boolean) => {
    const previous = gateEnabled;
    if (!agentId) {
      withAgent(async (id) => {
        const response = await agentsService.setConnectorSettings(id, enabled);
        if (!response.success) {
          setError(response.error ?? "Could not change connector settings.");
        } else {
          setGateEnabled(enabled);
        }
      });
      return;
    }

    setGateEnabled(enabled);
    withAgent(async (id) => {
      const response = await agentsService.setConnectorSettings(id, enabled);
      if (!response.success) {
        setGateEnabled(previous);
        setError(response.error ?? "Could not change connector settings.");
      }
    });
  };

  const uploadFiles = (list: FileList | null) => {
    const selected = Array.from(list ?? []);
    if (selected.length === 0) return;
    return withAgent(async (id) => {
      const response = await agentsService.uploadFiles(id, selected);
      if (!response.success) setError(response.error ?? "Upload failed.");
    });
  };

  const submitSourceText = () =>
    withAgent(async (id) => {
      const value = sourceText.trim();
      if (!value) return;
      const response = looksLikeUrl(value)
        ? await agentsService.attachUrl(id, value)
        : await agentsService.attachUrl(id, value, value);
      if (!response.success) {
        setError(response.error ?? "That address was refused.");
        return;
      }
      setSourceText("");
    });

  const removeFile = (fileId: string) =>
    withAgent(async (id) => {
      await agentsService.deleteFile(id, fileId);
    });

  const refreshFile = (fileId: string) =>
    withAgent(async (id) => {
      await agentsService.refreshFile(id, fileId);
    });

  const detachConnector = (connectorId: string) =>
    withAgent(async (id) => {
      await agentsService.detachConnector(id, connectorId);
    });

  const unlinkBase = (baseId: string) =>
    withAgent(async (id) => {
      await agentsService.unlinkKnowledgeBase(id, baseId);
    });

  const openKnowledgePicker = () =>
    withAgent(async (id) => {
      const response = await agentsService.getAvailableKnowledgeBases(id);
      if (response.success && response.data) {
        setAvailableBases(response.data.knowledge_bases ?? []);
        setKbOpen(true);
      } else {
        setError(response.error ?? "Could not list knowledge bases.");
      }
    });

  const linkBase = (baseId: string) =>
    withAgent(async (id) => {
      await agentsService.linkKnowledgeBase(id, baseId);
      setKbOpen(false);
    });

  const openConnectorPicker = async () => {
    setError(null);
    const id = agentId ?? (await ensureAgent());
    if (!id) {
      setError("Give the agent a name first");
      return;
    }
    setPickerAgentId(id);
    setPickerOpen(true);
  };

  const rows: SourceRow[] = [
    ...connectors.map((connector) => ({
      rowType: "connector" as const,
      key: `c-${connector.connector_id}`,
      connector,
    })),
    ...files.map((file) => ({
      rowType: "file" as const,
      key: `f-${file.file_id}`,
      file,
    })),
    ...bases.map((base) => ({
      rowType: "knowledge" as const,
      key: `k-${base.knowledge_base_id}`,
      base,
    })),
  ];

  return (
    <div className={s.contextPanel}>
      <label className={s.gateToggle}>
        <input
          type="checkbox"
          checked={gateEnabled}
          disabled={busy}
          onChange={(e) => toggleGate(e.target.checked)}
        />
        <span className={s.gateTrack}>
          <span className={s.gateDot} />
        </span>
        <span className={s.gateLabel}>
          Allow this agent to use external connectors &amp; sources
        </span>
      </label>

      {environment?.markitdown_installed === false && (
        <p className={s.errText}>
          Document conversion is unavailable on this server, so uploads will
          fail.
        </p>
      )}

      <div
        className={`${s.contextBody}${gateEnabled ? "" : ` ${s.contextLocked}`}`}
      >
        <div
          className={`${s.sourceRow}${dragging ? ` ${s.sourceRowDrag}` : ""}`}
          onDragEnter={(e) => {
            e.preventDefault();
            if (gateEnabled) setDragging(true);
          }}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            if (gateEnabled) uploadFiles(e.dataTransfer.files);
          }}
        >
          <input
            type="text"
            className={s.sourceInput}
            placeholder="Enter a URL or name, or drop the files here"
            value={sourceText}
            disabled={!gateEnabled || busy}
            onChange={(e) => setSourceText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                submitSourceText();
              }
            }}
          />
          <button
            type="button"
            className={s.sourceUpload}
            title="Upload files"
            aria-label="Upload files"
            disabled={!gateEnabled || busy}
            onClick={() => fileRef.current?.click()}
          >
            ↑
          </button>
          <input
            ref={fileRef}
            type="file"
            multiple
            hidden
            onChange={(e) => uploadFiles(e.target.files)}
          />
        </div>

        {error && <p className={s.errText}>{error}</p>}

        <div className={s.contextList}>
          {rows.length === 0 && (
            <div className={s.contextEmpty}>
              Nothing added yet — connect an API, MCP server or database, or
              attach a URL, file or knowledge base.
            </div>
          )}

          {rows.map((row) => {
            if (row.rowType === "connector") {
              const { connector } = row;
              return (
                <div key={row.key} className={s.contextItem}>
                  <span className={s.contextMeta}>
                    <span className={s.contextName}>{connector.name}</span>
                    <span className={s.contextType}>
                      {connector.access_level ?? "connector"}
                    </span>
                  </span>
                  <span
                    className={
                      connector.resolved === false ? s.statusBad : s.statusOk
                    }
                  >
                    {connector.resolved === false
                      ? connector.error || "Unavailable"
                      : "Connected"}
                  </span>
                  <button
                    type="button"
                    className={s.contextDel}
                    disabled={busy}
                    onClick={() => detachConnector(connector.connector_id)}
                    aria-label={`Remove ${connector.name}`}
                  >
                    ×
                  </button>
                </div>
              );
            }

            if (row.rowType === "file") {
              const { file } = row;
              return (
                <div key={row.key} className={s.contextItem}>
                  <span className={s.contextMeta}>
                    <span className={s.contextName}>{file.name}</span>
                    <span className={s.contextType}>
                      {file.source_type === "url" ? "URL" : "File"}
                    </span>
                    {file.ocr_skipped_reason && (
                      <span className={s.contextNote}>
                        Images in this document were not read
                        {file.ocr_skipped_reason === "model_not_vision_capable"
                          ? " — your default model cannot read images."
                          : "."}
                      </span>
                    )}

                    {file.status === "ready" &&
                      file.ingest_mode !== "inline" && (
                        <span className={s.contextChunks}>
                          {(file.chunk_count ?? 0) === 0
                            ? "No passages extracted"
                            : `${file.chunk_count} passage${file.chunk_count === 1 ? "" : "s"} extracted`}
                        </span>
                      )}
                    {file.status === "ready" &&
                      file.ingest_mode === "inline" && (
                        <span className={s.contextChunks}>
                          Included in full
                        </span>
                      )}
                  </span>
                  <span
                    className={
                      file.status === "failed"
                        ? s.statusBad
                        : file.status === "ready"
                          ? s.statusOk
                          : s.statusIdle
                    }
                  >
                    {fileStatusText(file)}
                  </span>
                  <button
                    type="button"
                    className={s.ghostBtn}
                    disabled={busy}
                    onClick={() => refreshFile(file.file_id)}
                  >
                    {file.source_type === "url" ? "Re-fetch" : "Re-read"}
                  </button>
                  <button
                    type="button"
                    className={s.contextDel}
                    disabled={busy}
                    onClick={() => removeFile(file.file_id)}
                    aria-label={`Remove ${file.name}`}
                  >
                    ×
                  </button>
                </div>
              );
            }

            const { base } = row;
            return (
              <div key={row.key} className={s.contextItem}>
                <span className={s.contextMeta}>
                  <span className={s.contextName}>
                    {base.name ?? base.alias ?? base.knowledge_base_id}
                  </span>
                  <span className={s.contextType}>Knowledge base</span>
                </span>
                <span className={s.statusOk}>Linked</span>
                <button
                  type="button"
                  className={s.contextDel}
                  disabled={busy}
                  onClick={() => unlinkBase(base.knowledge_base_id)}
                  aria-label="Unlink knowledge base"
                >
                  ×
                </button>
              </div>
            );
          })}
        </div>

        <div className={s.contextActions}>
          <button
            type="button"
            className={s.ghostBtn}
            disabled={!gateEnabled || busy}
            onClick={openConnectorPicker}
          >
            + Add connector
          </button>
          <button
            type="button"
            className={s.ghostBtn}
            disabled={!gateEnabled || busy}
            onClick={openKnowledgePicker}
          >
            + Link knowledge base
          </button>
        </div>
      </div>

      {pickerOpen && pickerAgentId && (
        <ConnectorPickerModal
          agentId={pickerAgentId}
          onClose={() => {
            setPickerOpen(false);
            setPickerAgentId(null);
          }}
          onAttached={() => load(pickerAgentId)}
        />
      )}

      {kbOpen && (
        <div className={s.modalOverlay} onClick={() => setKbOpen(false)}>
          <div className={s.modal} onClick={(e) => e.stopPropagation()}>
            <div className={s.modalHead}>
              <h3 className={s.modalTitle}>Link a knowledge base</h3>
              <button
                className={s.modalClose}
                onClick={() => setKbOpen(false)}
                aria-label="Close"
              >
                ×
              </button>
            </div>
            <div className={s.modalBody}>
              {availableBases.length === 0 ? (
                <p className={s.hint}>No synced knowledge bases available.</p>
              ) : (
                <ul className={s.instanceList}>
                  {availableBases.map((base) => (
                    <li key={base.knowledge_base_id} className={s.instanceRow}>
                      <span className={s.instanceMeta}>
                        <span className={s.instanceName}>
                          {base.name ?? base.knowledge_base_id}
                        </span>
                      </span>
                      <button
                        type="button"
                        className={s.ghostBtn}
                        disabled={busy}
                        onClick={() => linkBase(base.knowledge_base_id)}
                      >
                        Link
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
