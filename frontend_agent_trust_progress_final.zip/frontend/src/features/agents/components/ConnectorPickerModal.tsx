"use client";

import React, { useEffect, useState } from "react";
import { agentsService } from "@/services/agents.service";
import type {
  AccessLevel,
  AvailableConnector,
  AvailableConnectorGroups,
  ConnectorGroup,
} from "@/types/agents.types";
import s from "./agents.module.css";

interface ConnectorPickerModalProps {
  agentId: string;
  onClose: () => void;
  onAttached: () => void;
}

const TYPES: Array<{ key: ConnectorGroup; label: string; blurb: string }> = [
  { key: "api", label: "API", blurb: "Connect a REST or HTTP endpoint." },
  {
    key: "mcp",
    label: "MCP",
    blurb: "Connect a Model Context Protocol server.",
  },
  { key: "database", label: "Database", blurb: "Query a connected database." },
];

const ACCESS_OPTIONS: Array<{ value: AccessLevel; label: string }> = [
  { value: "read_only", label: "Read only" },
  { value: "read_write", label: "Read & Write" },
  { value: "full_access", label: "Full Access" },
];

const supportsAccessLevel = (kind: string): boolean =>
  kind === "database" || kind === "mcp";

export const ConnectorPickerModal: React.FC<ConnectorPickerModalProps> = ({
  agentId,
  onClose,
  onAttached,
}) => {
  const [available, setAvailable] = useState<AvailableConnectorGroups | null>(
    null,
  );
  const [group, setGroup] = useState<ConnectorGroup | null>(null);
  const [levels, setLevels] = useState<Record<string, AccessLevel>>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    agentsService.getAvailableConnectors(agentId).then((response) => {
      setLoading(false);
      if (response.success && response.data) setAvailable(response.data);
      else setError(response.error ?? "Could not list your connectors.");
    });
  }, [agentId]);

  const items = (key: ConnectorGroup): AvailableConnector[] =>
    (available?.[key] ?? []) as AvailableConnector[];

  const attach = async (connector: AvailableConnector) => {
    setBusy(true);
    setError(null);
    const response = await agentsService.attachConnector(agentId, {
      connector_id: connector.connector_id,
      kind: connector.kind,
      access_level: supportsAccessLevel(connector.kind)
        ? (levels[connector.connector_id] ?? "read_only")
        : undefined,
    });
    setBusy(false);

    if (!response.success) {
      setError(response.error ?? "Could not attach that connector.");
      return;
    }
    onAttached();
    onClose();
  };

  return (
    <div className={s.modalOverlay} onClick={onClose}>
      <div className={s.modal} onClick={(e) => e.stopPropagation()}>
        <div className={s.modalHead}>
          <h3 className={s.modalTitle}>
            {group
              ? `Choose a ${TYPES.find((t) => t.key === group)?.label}`
              : "Add a connector"}
          </h3>
          <button className={s.modalClose} onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <div className={s.modalBody}>
          {error && <p className={s.errText}>{error}</p>}
          {loading && <p className={s.hint}>Loading your connectors…</p>}

          {!group && !loading && (
            <div className={s.pickList}>
              {TYPES.map((type) => (
                <button
                  key={type.key}
                  type="button"
                  className={s.pickItem}
                  onClick={() => setGroup(type.key)}
                >
                  <span className={s.pickMeta}>
                    <span className={s.pickName}>{type.label}</span>
                    <span className={s.pickDesc}>{type.blurb}</span>
                  </span>
                  <span className={s.pickCount}>{items(type.key).length}</span>
                </button>
              ))}
            </div>
          )}

          {group && (
            <>
              <button className={s.ghostBtn} onClick={() => setGroup(null)}>
                Back to types
              </button>

              {items(group).length === 0 ? (
                <p className={s.hint}>
                  You have no {TYPES.find((t) => t.key === group)?.label}{" "}
                  connectors yet. Create one under Configuration → Connectors.
                </p>
              ) : (
                <ul className={s.instanceList}>
                  {items(group).map((connector) => (
                    <li key={connector.connector_id} className={s.instanceRow}>
                      <span className={s.instanceMeta}>
                        <span className={s.instanceName}>{connector.name}</span>
                        {connector.detail && (
                          <span className={s.instanceDetail}>
                            {connector.detail}
                          </span>
                        )}
                      </span>

                      {supportsAccessLevel(connector.kind) && (
                        <select
                          className={s.levelSelect}
                          value={levels[connector.connector_id] ?? "read_only"}
                          onChange={(e) =>
                            setLevels((prev) => ({
                              ...prev,
                              [connector.connector_id]: e.target
                                .value as AccessLevel,
                            }))
                          }
                        >
                          {ACCESS_OPTIONS.map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      )}

                      <button
                        type="button"
                        className={s.ghostBtn}
                        disabled={busy}
                        onClick={() => attach(connector)}
                      >
                        Add
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
