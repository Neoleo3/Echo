"use client";

import React, { useEffect, useState } from "react";
import { llmsService } from "@/services/llms.service";
import { AgentToolsPicker } from "./AgentToolsPicker";
import { AgentContextPanel } from "./AgentContextPanel";
import type { AgentDraftForm } from "../hooks/useAgentDraft";
import type { AgentModelConfig } from "@/types/agents.types";
import s from "./agents.module.css";
import { LLMModel } from "@/types";
import {
  isReasoningModel,
  REASONING_SAMPLING_NOTE,
} from "@/utils/model-family.utils";

interface AgentConfigureFormProps {
  form: AgentDraftForm;
  update: <K extends keyof AgentDraftForm>(
    key: K,
    value: AgentDraftForm[K],
  ) => void;
  updateModelConfig: (changes: Partial<AgentModelConfig>) => void;
  onSave: () => void;
  onCancel: () => void;
  saving: boolean;
  error: string | null;
  agentId: string | null;
  ensureAgent: () => Promise<string | null>;
}

/* ── Section icons ── */
const InfoIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="16"
    height="16"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="16" x2="12" y2="12" />
    <line x1="12" y1="8" x2="12.01" y2="8" />
  </svg>
);

const ToolSectionIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="16"
    height="16"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
  </svg>
);

const ConnectorIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="16"
    height="16"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
  </svg>
);

const ModelIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="16"
    height="16"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="3" />
    <path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83" />
  </svg>
);

const SectionHead: React.FC<{
  title: string;
  blurb: string;
  icon?: React.ReactNode;
}> = ({ title, blurb, icon }) => (
  <div className={s.secHead}>
    {icon && <span className={s.secIcon}>{icon}</span>}
    <div>
      <h3 className={s.secTitle}>{title}</h3>
      <p className={s.secBlurb}>{blurb}</p>
    </div>
  </div>
);

const modelKey = (model: Partial<LLMModel>): string =>
  model.credential_id ?? model.id ?? model.model_name ?? "";

export const AgentConfigureForm: React.FC<AgentConfigureFormProps> = ({
  form,
  update,
  updateModelConfig,
  onSave,
  onCancel,
  saving,
  error,
  agentId,
  ensureAgent,
}) => {
  const [models, setModels] = useState<LLMModel[]>([]);

  useEffect(() => {
    llmsService.getModels().then((response: any) => {
      if (response.success && response.data)
        setModels(response.data.models ?? []);
    });
  }, []);

  const selectableModels = models.filter(
    (entry) =>
      entry.enabled !== false ||
      (!!form.credential_id && entry.credential_id === form.credential_id),
  );

  const chooseModel = (key: string) => {
    const model = selectableModels.find((entry) => modelKey(entry) === key);
    if (!model) {
      update("credential_id", "");
      updateModelConfig({ model: "", provider: "" });
      return;
    }
    update("credential_id", model.credential_id ?? "");
    updateModelConfig({
      model: model.model_name || model.id || model.name,
      provider: model.provider,
    });
  };

  const selectedModelKey =
    selectableModels.find(
      (entry) =>
        (form.credential_id && entry.credential_id === form.credential_id) ||
        (!form.credential_id &&
          form.model_config.model &&
          (entry.model_name === form.model_config.model ||
            entry.id === form.model_config.model)),
    ) ?? null;

  const config = form.model_config;

  const samplingDisabled = isReasoningModel(selectedModelKey);

  const REASONING_TOKEN_FLOOR = 4096;
  const effectiveMaxTokens = samplingDisabled
    ? Math.max(config.max_tokens ?? 2000, REASONING_TOKEN_FLOOR)
    : (config.max_tokens ?? 2000);

  return (
    <div className={s.configForm}>
      {/* ---------- 1. Basic Information ---------- */}
      <section className={s.sec}>
        <SectionHead
          title="Basic Information"
          blurb="Define the core identity and purpose of your agent."
          icon={<InfoIcon />}
        />
        <div className={s.grid}>
          <div className={s.field}>
            <label htmlFor="ag-name">
              Agent Name <span className={s.req}>*</span>
            </label>
            <input
              id="ag-name"
              type="text"
              placeholder="e.g., Research Assistant"
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
            />
          </div>

          <div className={s.field}>
            <label htmlFor="ag-icon">Icon</label>
            <input
              id="ag-icon"
              type="text"
              placeholder="e.g., robot"
              value={form.icon}
              onChange={(e) => update("icon", e.target.value)}
            />
          </div>

          <div className={`${s.field} ${s.full}`}>
            <label htmlFor="ag-desc">Description</label>
            <textarea
              id="ag-desc"
              placeholder="What is this agent for? Shown wherever the agent is listed."
              value={form.description}
              onChange={(e) => update("description", e.target.value)}
            />
          </div>

          <div className={`${s.field} ${s.full}`}>
            <label htmlFor="ag-instructions">
              Instructions <span className={s.req}>*</span>
            </label>
            <textarea
              id="ag-instructions"
              style={{ minHeight: 160 }}
              placeholder="How should this agent behave? Describe its purpose, responsibilities and decision-making."
              value={form.instructions}
              onChange={(e) => update("instructions", e.target.value)}
            />
            <p className={s.hint}>
              This is the agent&apos;s system prompt — everything it is told
              about how to work.
            </p>
          </div>
        </div>
      </section>

      {/* ---------- 2. Agent Tools ---------- */}
      <section className={s.sec}>
        <SectionHead
          title="Agent Tools"
          blurb="Equip your agent with tools to extend its capabilities."
          icon={<ToolSectionIcon />}
        />
        <AgentToolsPicker
          selected={form.tools}
          onChange={(tools) => update("tools", tools)}
        />
      </section>

      {/* ---------- 3. Connectors ---------- */}
      <section className={s.sec}>
        <SectionHead
          title="Connectors"
          blurb="Connect this agent to external tools and data sources."
          icon={<ConnectorIcon />}
        />
        <AgentContextPanel agentId={agentId} ensureAgent={ensureAgent} />
      </section>

      {/* ---------- 4. AI Configuration ---------- */}
      <section className={s.sec}>
        <SectionHead
          title="AI Configuration"
          blurb="Fine-tune the AI model parameters for optimal performance."
          icon={<ModelIcon />}
        />
        <div className={s.field} style={{ marginBottom: 16 }}>
          <label htmlFor="ag-model">Model</label>
          <select
            id="ag-model"
            value={selectedModelKey ? modelKey(selectedModelKey) : ""}
            onChange={(e) => chooseModel(e.target.value)}
          >
            <option value="">
              {selectableModels.length === 0
                ? "No models available…"
                : "Use the platform default"}
            </option>
            {selectableModels.map((model) => (
              <option key={modelKey(model)} value={modelKey(model)}>
                {model.name}
                {model.provider ? ` — ${model.provider}` : ""}
                {model.is_default ? " (default)" : ""}
              </option>
            ))}
          </select>
        </div>

        <div className={s.sliderRow}>
          <label htmlFor="ag-temp">Temperature</label>
          <span>
            {samplingDisabled ? "—" : (config.temperature ?? 0).toFixed(2)}
          </span>
        </div>
        <input
          id="ag-temp"
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={config.temperature ?? 0.7}
          onChange={(e) => updateModelConfig({ temperature: +e.target.value })}
          className={s.slider}
          disabled={samplingDisabled}
        />
        <p className={s.hint}>
          {samplingDisabled
            ? REASONING_SAMPLING_NOTE
            : "Higher values are more creative, lower are more focused."}
        </p>

        <div className={s.sliderRow}>
          <label htmlFor="ag-tokens">Max Tokens</label>
          <span>{effectiveMaxTokens}</span>
        </div>
        <input
          id="ag-tokens"
          type="range"
          min="200"
          max="8000"
          step="100"
          value={effectiveMaxTokens}
          onChange={(e) => updateModelConfig({ max_tokens: +e.target.value })}
          className={s.slider}
        />
        <p className={s.hint}>
          {samplingDisabled
            ? `Maximum response length. This model spends part of this budget reasoning, so anything below ${REASONING_TOKEN_FLOOR} is raised to it.`
            : "Maximum response length."}
        </p>

        <div className={s.sliderRow}>
          <label htmlFor="ag-topp">Top P</label>
          <span>{samplingDisabled ? "—" : (config.top_p ?? 0).toFixed(2)}</span>
        </div>
        <input
          id="ag-topp"
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={config.top_p ?? 0.9}
          onChange={(e) => updateModelConfig({ top_p: +e.target.value })}
          className={s.slider}
          disabled={samplingDisabled}
        />
        <p className={s.hint}>
          {samplingDisabled
            ? REASONING_SAMPLING_NOTE
            : "Nucleus sampling threshold. Sent to the provider with every request."}
        </p>
      </section>

      {error && <p className={s.errText}>{error}</p>}

      <div className={s.formFoot}>
        <button type="button" className={s.ghostBtn} onClick={onCancel}>
          Cancel
        </button>
        <button
          type="button"
          className={s.primaryBtn}
          onClick={onSave}
          disabled={saving}
        >
          {saving ? "Saving…" : "Save Agent"}
        </button>
      </div>
    </div>
  );
};
