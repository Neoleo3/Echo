"use client";

import React, { useCallback, useEffect, useState } from "react";
import { agentsService } from "@/services/agents.service";
import type { ReadinessMode, ReadinessReport } from "@/types/agents.types";
import s from "./agents.module.css";

interface ReadinessPanelProps {
  agentId: string;
}

const MODE_OPTIONS: Array<{
  value: ReadinessMode;
  label: string;
  hint: string;
}> = [
  { value: "warn", label: "Warn me", hint: "Flag problems but still run." },
  {
    value: "block",
    label: "Block the run",
    hint: "Refuse to run until they are fixed.",
  },
  { value: "off", label: "Don't check", hint: "Skip the check entirely." },
];

const toneFor = (report: ReadinessReport): string => {
  if (report.blocked) return s.rdRed;
  if (!report.ready || report.findings.length > 0) return s.rdAmber;
  return s.rdGreen;
};

const labelFor = (report: ReadinessReport): string => {
  if (report.blocked) return "Blocked";
  if (!report.ready || report.findings.length > 0) return "Needs attention";
  return "Ready";
};

export const ReadinessPanel: React.FC<ReadinessPanelProps> = ({ agentId }) => {
  const [report, setReport] = useState<ReadinessReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const load = useCallback(
    async (grade = false) => {
      setLoading(true);
      const response = await agentsService.getReadiness(agentId, { grade });
      setLoading(false);
      if (response.success && response.data) {
        setReport(response.data);
        setError(null);
        return;
      }
      setError(response.error ?? "Could not check readiness.");
    },
    [agentId],
  );

  useEffect(() => {
    load();
  }, [load]);

  const setMode = async (mode: ReadinessMode) => {
    setSaving(true);
    await agentsService.updateReadiness(agentId, { mode });
    setSaving(false);
    await load();
  };

  const setGrading = async (enabled: boolean) => {
    setSaving(true);
    await agentsService.updateReadiness(agentId, { grading_enabled: enabled });
    setSaving(false);
    await load();
  };

  const blocking = report?.findings.filter((f) => f.severity === "block") ?? [];
  const warnings = report?.findings.filter((f) => f.severity !== "block") ?? [];

  return (
    <div className={s.panel}>
      <div className={s.panelHead}>
        <h3 className={s.panelTitle}>Readiness</h3>
        {report && (
          <span className={`${s.rdBadge} ${toneFor(report)}`}>
            {labelFor(report)}
          </span>
        )}
        <button
          type="button"
          className={s.ghostBtn}
          onClick={() => load()}
          disabled={loading}
        >
          {loading ? "Checking…" : "Recheck"}
        </button>
        <button
          type="button"
          className={s.ghostBtn}
          onClick={() => setExpanded((prev) => !prev)}
          aria-expanded={expanded}
          aria-label={
            expanded ? "Collapse readiness options" : "Expand readiness options"
          }
          style={{ marginLeft: "auto", padding: "7px 10px", fontSize: "10px" }}
        >
          {expanded ? "▲" : "▼"}
        </button>
      </div>

      {expanded && (
        <>
          {error && <p className={s.errText}>{error}</p>}

          {report?.message && <p className={s.rdMessage}>{report.message}</p>}

          {blocking.length > 0 && (
            <>
              <h4 className={s.subHead}>Blocking</h4>
              <ul className={s.findingList}>
                {blocking.map((finding, i) => (
                  <li key={`${finding.code}-${i}`} className={s.findingBlock}>
                    {finding.message}
                  </li>
                ))}
              </ul>
            </>
          )}

          {warnings.length > 0 && (
            <>
              <h4 className={s.subHead}>Warnings</h4>
              <ul className={s.findingList}>
                {warnings.map((finding, i) => (
                  <li key={`${finding.code}-${i}`} className={s.findingWarn}>
                    {finding.message}
                  </li>
                ))}
              </ul>
            </>
          )}

          {report && report.findings.length === 0 && !error && (
            <p className={s.hint}>Nothing is missing. This agent can run.</p>
          )}

          <h4 className={s.subHead}>When something is missing</h4>
          <div className={s.radioGroup}>
            {MODE_OPTIONS.map((option) => (
              <label key={option.value} className={s.radioRow}>
                <input
                  type="radio"
                  name="readiness-mode"
                  checked={report?.mode === option.value}
                  disabled={saving}
                  onChange={() => setMode(option.value)}
                />
                <span>
                  <span className={s.radioLabel}>{option.label}</span>
                  <span className={s.radioHint}>{option.hint}</span>
                </span>
              </label>
            ))}
          </div>

          <label className={s.checkRow}>
            <input
              type="checkbox"
              checked={Boolean(report?.graded)}
              disabled={saving}
              onChange={(e) => setGrading(e.target.checked)}
            />
            <span>
              <span className={s.radioLabel}>Evidence check</span>
              <span className={s.radioHint}>
                Adds one model call per run. Off by default.
              </span>
            </span>
          </label>
        </>
      )}
    </div>
  );
};
