"use client";

import React, { useState, useRef, useEffect } from "react";
import { useAgents, agentIdOf } from "../hooks/useAgents";
import { Pagination } from "@/components/common/Pagination";
import type { AgentDefinition } from "@/types/agents.types";
import s from "./agents.module.css";
import { MultiDropdown } from "@/components/common/MultiDropdown";

type View = "grid" | "list";

interface AgentListProps {
  onCreate: () => void;
  onEdit: (agent: AgentDefinition) => void;
  type?: View;
  refreshKey?: number;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
}

const summaryOf = (agent: AgentDefinition): string =>
  agent.description || agent.goal || "No description.";

const modelOf = (agent: AgentDefinition): string =>
  agent.model_config?.model || agent.model || "Platform default";

const GridIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
  </svg>
);

const ListIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
  >
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);

const DotsIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="12" cy="5" r="1" fill="currentColor" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <circle cx="12" cy="19" r="1" fill="currentColor" />
  </svg>
);

const RowMenu: React.FC<{
  onConfigure: () => void;
  onDelete: () => void;
  disabled?: boolean;
}> = ({ onConfigure, onDelete, disabled }) => {
  const [open, setOpen] = useState(false);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(
    null,
  );
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        btnRef.current &&
        !btnRef.current.contains(target) &&
        menuRef.current &&
        !menuRef.current.contains(target)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const reposition = () => {
      if (btnRef.current) {
        const rect = btnRef.current.getBoundingClientRect();
        setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
      }
    };
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [open]);
  const handleToggle = () => {
    if (!open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setMenuPos({ top: rect.bottom + 4, left: rect.right - 164 });
    }
    setOpen((o) => !o);
  };

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        className={s.dotsBtn}
        onClick={handleToggle}
        disabled={disabled}
        aria-label="Actions"
      >
        <DotsIcon />
      </button>
      {open && menuPos && (
        <div
          ref={menuRef}
          className={s.rowMenu}
          style={{ position: "fixed", top: menuPos.top, left: menuPos.left }}
        >
          <button
            type="button"
            className={s.rowMenuItem}
            onClick={() => {
              setOpen(false);
              onConfigure();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
            Configure
          </button>
          <button
            type="button"
            className={`${s.rowMenuItem} ${s.rowMenuItemDanger}`}
            onClick={() => {
              setOpen(false);
              onDelete();
            }}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
              <path d="M10 11v6" />
              <path d="M14 11v6" />
              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </>
  );
};

export const AgentList: React.FC<AgentListProps> = ({
  onCreate,
  onEdit,
  type,
  refreshKey,
  searchValue,
  onSearchChange,
}) => {
  const {
    agents,
    loading,
    error,
    reload,
    remove,
    page,
    pageSize,
    total,
    search,
    onPageChange,
    onPageSizeChange,
    onSearchChange: onServerSearchChange,
  } = useAgents();
  const [modelFilter, setModelFilter] = useState("all");
  const [internalView, setInternalView] = useState<View>("grid");
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const view = type ?? internalView;

  const activeSearch = searchValue !== undefined ? searchValue : search;
  const handleSearchChange = (value: string) => {
    if (onSearchChange) onSearchChange(value);
    onServerSearchChange(value);
  };

  React.useEffect(() => {
    if (searchValue !== undefined) {
      onServerSearchChange(searchValue);
    }
  }, [searchValue]);

  React.useEffect(() => {
    if (refreshKey !== undefined) reload();
  }, [refreshKey]);

  const modelOptions = React.useMemo(() => {
    const models = new Set(agents.map((a) => modelOf(a)).filter(Boolean));
    return Array.from(models).sort();
  }, [agents]);

  const filtered = agents.filter((agent) => {
    const matchesModel =
      modelFilter === "all" || modelOf(agent) === modelFilter;
    return matchesModel;
  });

  return (
    <div className={s.listWrap}>
      <div className={s.listTop}>
        <input
          type="text"
          className={s.listSearch}
          placeholder="Search agents…"
          value={activeSearch}
          onChange={(e) => handleSearchChange(e.target.value)}
        />
        {modelOptions.length > 0 && (
          <div style={{ minWidth: "200px" }}>
            <MultiDropdown
              label=""
              placeholder="Select Models"
              options={modelOptions.map((m: string) => {
                return { id: m, name: m };
              })}
              selectedIds={[modelFilter]}
              onToggle={(o) => setModelFilter(o.id)}
              single
            />
          </div>
        )}

        {type === undefined && (
          <div className={s.viewToggle}>
            <button
              type="button"
              className={`${s.viewBtn}${view === "grid" ? ` ${s.viewBtnActive}` : ""}`}
              onClick={() => setInternalView("grid")}
              aria-label="Grid view"
              title="Grid view"
            >
              <GridIcon />
            </button>
            <button
              type="button"
              className={`${s.viewBtn}${view === "list" ? ` ${s.viewBtnActive}` : ""}`}
              onClick={() => setInternalView("list")}
              aria-label="Table view"
              title="Table view"
            >
              <ListIcon />
            </button>
          </div>
        )}

        <button type="button" className={s.primaryBtn} onClick={onCreate}>
          + Create Agent
        </button>
      </div>

      {error && <p className={s.errText}>{error}</p>}
      {loading && agents.length === 0 && (
        <p className={s.hint}>Loading agents…</p>
      )}

      {!loading && agents.length === 0 && !error && (
        <div className={s.emptyState}>
          <p>No agents yet.</p>
          <span>Click Create Agent to build your first one.</span>
        </div>
      )}

      {filtered.length === 0 && agents.length > 0 && (
        <p className={s.hint}>No agents match the current filter.</p>
      )}

      {view === "grid" ? (
        <div className={s.cards}>
          {filtered.map((agent) => {
            const id = agentIdOf(agent);
            return (
              <div key={id || agent.name} className={s.card}>
                <div className={s.cardTop}>
                  <h3 className={s.cardName}>{agent.name}</h3>
                  {/* <span className={s.badgeQuiet}>{modelOf(agent)}</span> */}
                </div>
                <p className={s.cardDesc}>{summaryOf(agent)}</p>
                <div className={s.cardStats}>
                  <span>
                    {agent.tools?.length ?? 0} tool
                    {(agent.tools?.length ?? 0) === 1 ? "" : "s"}
                  </span>
                  <span>
                    {agent.connectors?.length ?? 0} connector
                    {(agent.connectors?.length ?? 0) === 1 ? "" : "s"}
                  </span>
                  {agent.connector_settings?.enabled === false && (
                    <span className={s.mutedTag}>connectors off</span>
                  )}
                </div>
                <div className={s.cardFoot}>
                  {confirmId === id ? (
                    <>
                      <span className={s.hint}>Delete this agent?</span>
                      <button
                        type="button"
                        className={s.dangerBtn}
                        onClick={async () => {
                          await remove(id);
                          setConfirmId(null);
                        }}
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        className={s.ghostBtn}
                        onClick={() => setConfirmId(null)}
                      >
                        Keep
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        className={s.cardActionBtn}
                        onClick={() => onEdit(agent)}
                        disabled={!id}
                      >
                        <svg
                          width="13"
                          height="13"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        >
                          <circle cx="12" cy="12" r="3" />
                          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                        </svg>
                        Configure
                      </button>
                      <button
                        type="button"
                        className={s.cardDelBtn}
                        onClick={() => setConfirmId(id)}
                        disabled={!id}
                      >
                        <svg
                          width="13"
                          height="13"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        >
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                          <path d="M10 11v6" />
                          <path d="M14 11v6" />
                          <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                        </svg>
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className={s.tableWrap}>
          <table className={s.dataTable}>
            <thead>
              <tr>
                <th>Name</th>
                {/* <th>Model</th> */}
                <th>Summary</th>
                <th>Tools</th>
                <th>Connectors</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((agent) => {
                const id = agentIdOf(agent);
                return (
                  <tr key={id ?? agent.name}>
                    <td style={{ fontWeight: 600 }}>{agent.name}</td>
                    {/* <td>
                      <span className={s.badgeQuiet}>{modelOf(agent)}</span>
                    </td> */}
                    <td>{summaryOf(agent)}</td>
                    <td>{agent.tools?.length ?? 0}</td>
                    <td>{agent.connectors?.length ?? 0}</td>
                    <td>
                      {confirmId === id ? (
                        <div className={s.tableActions}>
                          <span className={s.hint} style={{ margin: 0 }}>
                            Delete?
                          </span>
                          <button
                            type="button"
                            className={s.dangerBtn}
                            style={{ fontSize: 12, padding: "5px 10px" }}
                            onClick={async () => {
                              if (!id) return;
                              await remove(id);
                              setConfirmId(null);
                            }}
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            className={s.ghostBtn}
                            style={{ fontSize: 12, padding: "5px 10px" }}
                            onClick={() => setConfirmId(null)}
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <RowMenu
                          disabled={!id}
                          onConfigure={() => onEdit(agent)}
                          onDelete={() => setConfirmId(id)}
                        />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {total > 0 && (
        <Pagination
          currentPage={page}
          pageSize={pageSize}
          total={total}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      )}
    </div>
  );
};
