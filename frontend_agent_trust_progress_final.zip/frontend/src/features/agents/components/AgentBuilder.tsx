"use client";

import React, { useEffect, useRef, useState } from "react";
import { useAgentDesignChat } from "../hooks/useAgentDesignChat";
import { useAgentDraft, definitionToDraft } from "../hooks/useAgentDraft";
import { AgentCreateChoice } from "./AgentCreateChoice";
import { AgentConfigureForm } from "./AgentConfigureForm";
import { ReadinessPanel } from "./ReadinessPanel";
import s from "./agents.module.css";
import { AgentDefinition } from "@/types/agents.types";
import { agentsService } from "@/services/agents.service";

type BuilderView = "choose" | "describe" | "configure";

interface AgentBuilderProps {
  /** Set when configuring an existing agent; null starts the create flow. */
  agent?: AgentDefinition | null;
  onClose: () => void;
  /** Called after a successful save so the list can refetch. */
  onSaved?: (agentId: string) => void;
}

/**
 * The agent builder.
 *
 * Two routes to the same agent: describe it and let the backend draft it, or
 * fill the four sections in yourself. The conversation is owned entirely by
 * the backend — every refine message is routed to the design endpoint, and
 * nothing is applied locally, because a local shortcut is how the
 * instruction-duplication defect happened in the first place.
 */
export const AgentBuilder: React.FC<AgentBuilderProps> = ({
  agent,
  onClose,
  onSaved,
}) => {
  const design = useAgentDesignChat();
  const draft = useAgentDraft(agent ? definitionToDraft(agent) : undefined);
  const [view, setView] = useState<BuilderView>(agent ? "configure" : "choose");
  const [input, setInput] = useState("");
  const threadRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  /* Auto-scroll to bottom as turns arrive */
  useEffect(() => {
    if (threadRef.current) {
      threadRef.current.scrollTop = threadRef.current.scrollHeight;
    }
  }, [design.turns.length, design.sending]);

  /* Auto-grow textarea */
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [input]);

  /* The AI route produces a real agent; load it so the form can refine it. */
  useEffect(() => {
    if (!design.agentId) return;
    let cancelled = false;
    agentsService.getAgent(design.agentId).then((response) => {
      if (cancelled || !response.success || !response.data) return;
      draft.loadFrom(response.data);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [design.agentId]);

  const submitPrompt = () => {
    if (!input.trim() || design.sending) return;
    design.send(input);
    setInput("");
  };

  const handleSave = async () => {
    const agentId = await draft.save();
    if (agentId) {
      onSaved?.(agentId);
      onClose();
    }
  };

  /**
   * Give an attachment something to attach to.
   *
   * Connectors, files and knowledge bases are children of an agent, so the
   * first one the user reaches for writes the agent. Only a name is needed
   * to create it, so nothing nameless is ever persisted.
   */
  const handleEnsureAgent = async () => {
    const id = await draft.ensureSaved();
    if (id) onSaved?.(id);
    return id;
  };

  const agentId = draft.savedId ?? design.agentId;
  const heading = draft.form.name || agent?.name || "New agent";

  return (
    <div
      className={`${s.builder}${view === "describe" ? ` ${s.builderChat}` : ""}`}
    >
      {/* ── Top bar — always visible ── */}
      <div className={s.builderTop}>
        <button className={s.ghostBtn} onClick={onClose}>
          <svg
            viewBox="0 0 24 24"
            width="13"
            height="13"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>

        {view !== "choose" && (
          <div className={s.tabs}>
            <button
              className={`${s.tab}${view === "configure" ? ` ${s.tabOn}` : ""}`}
              onClick={() => setView("configure")}
            >
              Configure
            </button>
            <button
              className={`${s.tab}${view === "describe" ? ` ${s.tabOn}` : ""}`}
              onClick={() => setView("describe")}
            >
              Create with AI
            </button>
          </div>
        )}

        {view !== "choose" && <span className={s.builderName}>{heading}</span>}

        {/* "Open Configure" shortcut — only visible after a draft exists */}
        {view === "describe" && agentId && (
          <button
            className={s.ghostBtn}
            onClick={() => setView("configure")}
            title="Review and save the drafted agent"
          >
            <svg
              viewBox="0 0 24 24"
              width="13"
              height="13"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ marginRight: 3 }}
            >
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
            Open Configure
          </button>
        )}
      </div>

      {/* ── Choose path ── */}
      {view === "choose" && (
        <AgentCreateChoice
          onChooseAi={() => setView("describe")}
          onChooseManual={() => setView("configure")}
        />
      )}

      {/* ── Create with AI — full-page chat UI ── */}
      {view === "describe" && (
        <div className={s.aiChatShell}>
          {/* Thread — scrollable, grows to fill */}
          <div className={s.aiThread} ref={threadRef}>
            {/* Empty state — centred hero */}
            {design.turns.length === 0 && !design.sending && (
              <div className={s.aiEmptyState}>
                <div className={s.aiEmptyIcon}>
                  <svg
                    viewBox="0 0 24 24"
                    width="28"
                    height="28"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
                    <path d="M20 3v4M22 5h-4M4 17v2M5 18H3" />
                  </svg>
                </div>
                <h3 className={s.aiEmptyTitle}>Spawn Agent</h3>
                <p className={s.aiEmptyDesc}>
                  Describe the agent you want — what it should do, who it&apos;s
                  for, and any tools it needs. I&apos;ll draft the full
                  configuration.
                </p>
                <div className={s.aiSuggestions}>
                  {[
                    "Review contracts and flag risky clauses",
                    "Answer customer support questions using the knowledge base",
                    "Summarise research papers into executive briefings",
                  ].map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      className={s.aiSuggestion}
                      onClick={() => {
                        setInput(suggestion);
                        textareaRef.current?.focus();
                      }}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Message turns */}
            {design.turns.map((turn) => (
              <div
                key={turn.id}
                className={`${s.aiMsg} ${turn.role === "user" ? s.aiMsgUser : s.aiMsgAgent}`}
              >
                {turn.role === "assistant" && (
                  <span className={s.aiAvatar}>
                    <svg
                      viewBox="0 0 24 24"
                      width="15"
                      height="15"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
                    </svg>
                  </span>
                )}
                <div className={s.aiBubble}>
                  <p className={s.aiBubbleText}>{turn.text}</p>
                  {turn.changedFields && turn.changedFields.length > 0 && (
                    <p className={s.aiChangedFields}>
                      <svg
                        viewBox="0 0 24 24"
                        width="11"
                        height="11"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        style={{ marginRight: 4 }}
                      >
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                      Updated: {turn.changedFields.join(", ")}
                    </p>
                  )}
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {design.sending && (
              <div className={`${s.aiMsg} ${s.aiMsgAgent}`}>
                <span className={s.aiAvatar}>
                  <svg
                    viewBox="0 0 24 24"
                    width="15"
                    height="15"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
                  </svg>
                </span>
                <div className={s.aiBubble}>
                  <span className={s.aiTyping}>
                    <i />
                    <i />
                    <i />
                  </span>
                </div>
              </div>
            )}

            {design.error && (
              <p className={s.errText} style={{ padding: "0 20px" }}>
                {design.error}
              </p>
            )}

            {/* "Draft ready" callout */}
            {agentId && !design.sending && (
              <div className={s.aiDraftReady}>
                <svg
                  viewBox="0 0 24 24"
                  width="15"
                  height="15"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  style={{ flexShrink: 0 }}
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>
                Draft ready — switch to <strong>Configure</strong> to review and
                save.
              </div>
            )}
          </div>

          {/* Composer dock — pinned to bottom */}
          <div className={s.aiDock}>
            <div className={s.aiComposer}>
              <textarea
                ref={textareaRef}
                rows={1}
                placeholder="e.g. Review contracts and flag risky clauses…"
                value={input}
                disabled={design.sending}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submitPrompt();
                  }
                }}
              />
              <button
                type="button"
                className={s.aiSendBtn}
                aria-label="Send"
                disabled={!input.trim() || design.sending}
                onClick={submitPrompt}
              >
                <svg
                  viewBox="0 0 24 24"
                  width="18"
                  height="18"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="12" y1="19" x2="12" y2="5" />
                  <polyline points="5 12 12 5 19 12" />
                </svg>
              </button>
            </div>
            <p className={s.aiComposerHint}>
              Press <kbd>Enter</kbd> to send · <kbd>Shift+Enter</kbd> for new
              line
            </p>
          </div>
        </div>
      )}

      {/* ── Configure ── */}
      {view === "configure" && (
        <>
          {agentId && <ReadinessPanel agentId={agentId} />}
          <AgentConfigureForm
            form={draft.form}
            update={draft.update}
            updateModelConfig={draft.updateModelConfig}
            onSave={handleSave}
            onCancel={onClose}
            saving={draft.saving}
            error={draft.error}
            agentId={agentId}
            ensureAgent={handleEnsureAgent}
          />
        </>
      )}
    </div>
  );
};
