"use client";

import React, { useEffect, useMemo, useState } from "react";
import { agentsService } from "@/services/agents.service";
import type { AgentTool } from "@/types/agents.types";
import s from "./agents.module.css";

interface AgentToolsPickerProps {
  selected: string[];
  onChange: (tools: string[]) => void;
}

const ToolIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="15"
    height="15"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
  </svg>
);

const SearchIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="14"
    height="14"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
  >
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

/** Tools the agent may call. An agent with none is perfectly valid — it
 *  simply answers from its instructions and whatever context it is given. */
export const AgentToolsPicker: React.FC<AgentToolsPickerProps> = ({
  selected,
  onChange,
}) => {
  const [tools, setTools] = useState<AgentTool[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    setLoading(true);
    agentsService.getAvailableTools().then((response) => {
      setLoading(false);
      if (response.success && response.data)
        setTools(response.data.tools ?? []);
    });
  }, []);

  const byId = useMemo(() => {
    const map = new Map<string, AgentTool>();
    tools.forEach((tool) => map.set(tool.tool_id, tool));
    return map;
  }, [tools]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return tools;
    return tools.filter(
      (tool) =>
        tool.name.toLowerCase().includes(query) ||
        (tool.description ?? "").toLowerCase().includes(query),
    );
  }, [tools, search]);

  const toggle = (toolId: string) => {
    const next = selected.includes(toolId)
      ? selected.filter((id) => id !== toolId)
      : [...selected, toolId];
    onChange(next);
  };

  const openModal = () => {
    setSearch("");
    setModalOpen(true);
  };

  return (
    <div>
      <div className={s.toolTags}>
        {selected.length === 0 ? (
          <span className={s.emptyTools}>
            No tools added yet — click &ldquo;Add tools&rdquo; to browse.
          </span>
        ) : (
          selected.map((toolId) => {
            const tool = byId.get(toolId);
            return (
              <span key={toolId} className={s.toolTag}>
                <ToolIcon />
                {tool?.name ?? toolId}
                <button
                  type="button"
                  onClick={() => toggle(toolId)}
                  title="Remove"
                  aria-label={`Remove ${tool?.name ?? toolId}`}
                >
                  ×
                </button>
              </span>
            );
          })
        )}
      </div>

      <button type="button" className={s.addToolBtn} onClick={openModal}>
        <svg
          viewBox="0 0 24 24"
          width="13"
          height="13"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        Add tools
        {tools.length > 0 && (
          <span className={s.toolCountBadge}>{tools.length} available</span>
        )}
      </button>

      {modalOpen && (
        <div className={s.modalOverlay} onClick={() => setModalOpen(false)}>
          <div className={s.modal} onClick={(e) => e.stopPropagation()}>
            <div className={s.modalHead}>
              <div className={s.modalHeadLeft}>
                <span className={s.modalHeadIcon}>
                  <ToolIcon />
                </span>
                <div>
                  <h3 className={s.modalTitle}>Available Tools</h3>
                  <p className={s.modalSubtitle}>
                    {selected.length} selected &middot; {tools.length} available
                  </p>
                </div>
              </div>
              <button
                className={s.modalClose}
                onClick={() => setModalOpen(false)}
                aria-label="Close"
              >
                &times;
              </button>
            </div>

            <div className={s.modalSearch}>
              <span className={s.modalSearchIcon}>
                <SearchIcon />
              </span>
              <input
                type="text"
                placeholder="Search tools…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
              />
            </div>

            <div className={s.modalBody}>
              {loading && <p className={s.hint}>Loading tools…</p>}
              {!loading && filtered.length === 0 && (
                <p className={s.hint}>No tools match &ldquo;{search}&rdquo;.</p>
              )}
              {!loading && filtered.length > 0 && (
                <div className={s.toolModalList}>
                  {filtered.map((tool) => {
                    const isSelected = selected.includes(tool.tool_id);
                    return (
                      <label
                        key={tool.tool_id}
                        className={`${s.toolModalRow}${isSelected ? ` ${s.toolModalRowOn}` : ""}`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggle(tool.tool_id)}
                        />
                        <span className={s.toolModalIcon}>
                          <ToolIcon />
                        </span>
                        <span className={s.toolMeta}>
                          <span className={s.toolName}>
                            {tool.name}
                            {tool.source && (
                              <span
                                className={`${s.badgeQuiet} ${s.toolSourceBadge}`}
                              >
                                {tool.source}
                              </span>
                            )}
                          </span>
                          {tool.description && (
                            <span className={s.toolDesc}>
                              {tool.description}
                            </span>
                          )}
                        </span>
                        <span className={s.toolModalCheck}>
                          {isSelected && (
                            <svg
                              viewBox="0 0 24 24"
                              width="14"
                              height="14"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2.5"
                              strokeLinecap="round"
                            >
                              <polyline points="20 6 9 17 4 12" />
                            </svg>
                          )}
                        </span>
                      </label>
                    );
                  })}
                </div>
              )}
            </div>

            <div className={s.modalFoot}>
              <span className={s.hint} style={{ margin: 0 }}>
                {selected.length} tool{selected.length !== 1 ? "s" : ""}{" "}
                selected
              </span>
              <button
                type="button"
                className={s.primaryBtn}
                onClick={() => setModalOpen(false)}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
