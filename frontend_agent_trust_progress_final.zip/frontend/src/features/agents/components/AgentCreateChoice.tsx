"use client";

import React from "react";
import s from "./agents.module.css";

interface AgentCreateChoiceProps {
  onChooseAi: () => void;
  onChooseManual: () => void;
}

export const AgentCreateChoice: React.FC<AgentCreateChoiceProps> = ({
  onChooseAi,
  onChooseManual,
}) => (
  <div className={s.choice}>
    <div className={s.choiceHead}>
      <h2>Create an agent</h2>
      <p>
        Describe what you need and let AI draft it, or fill in the details
        yourself.
      </p>
    </div>

    <div className={s.choiceCards}>
      {/* ── Create with AI ── */}
      <button type="button" className={s.choiceCard} onClick={onChooseAi}>
        <span className={`${s.choiceIc} ${s.choiceAi}`}>
          <svg
            viewBox="0 0 24 24"
            width="22"
            height="22"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
            <path d="M20 3v4" />
            <path d="M22 5h-4" />
            <path d="M4 17v2" />
            <path d="M5 18H3" />
          </svg>
        </span>
        <div className={s.choiceCardBody}>
          <span className={s.choiceTitle}>Create with AI</span>
          <span className={s.choiceDesc}>
            Say what the agent should do. It drafts the configuration, and you
            refine it by talking to it.
          </span>
        </div>
        <span className={s.choiceArrow}>
          <svg
            viewBox="0 0 24 24"
            width="16"
            height="16"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </span>
      </button>

      {/* ── Configure manually ── */}
      <button type="button" className={s.choiceCard} onClick={onChooseManual}>
        <span className={`${s.choiceIc} ${s.choiceManual}`}>
          <svg
            viewBox="0 0 24 24"
            width="22"
            height="22"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="4" y1="6" x2="20" y2="6" />
            <line x1="4" y1="12" x2="20" y2="12" />
            <line x1="4" y1="18" x2="20" y2="18" />
            <circle cx="9" cy="6" r="2" fill="var(--surface-2)" />
            <circle cx="15" cy="12" r="2" fill="var(--surface-2)" />
            <circle cx="9" cy="18" r="2" fill="var(--surface-2)" />
          </svg>
        </span>
        <div className={s.choiceCardBody}>
          <span className={s.choiceTitle}>Configure manually</span>
          <span className={s.choiceDesc}>
            Fill in the identity, instructions, tools, connectors and model
            settings yourself.
          </span>
        </div>
        <span className={s.choiceArrow}>
          <svg
            viewBox="0 0 24 24"
            width="16"
            height="16"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </span>
      </button>
    </div>
  </div>
);
