"use client";

import { Dispatch, useState } from "react";
import styles from "@/styles/auth.module.css";
import { useToast } from "@/hooks/use-toast";
import { AuthView } from "@/app/page";
import { ENV, STORAGE_KEYS } from "@/config";
import { useAuth } from "@/hooks/useAuth";

interface Props {
  setAuthView: Dispatch<React.SetStateAction<AuthView>>;
}

export default function LoginPage({ setAuthView }: Props) {
  const [loginId, setLoginId] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem(STORAGE_KEYS.LOGIN_ID) ?? "";
    }
    return "";
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const { toast } = useToast();

  const handleSSOLogin = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${ENV.API_BASE_URL}/sessions/sso/login`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || "SSO is not available");
      }
      const { authorization_url } = await res.json();
      window.location.href = authorization_url;
    } catch (e) {
      toast({
        title: "SSO Error",
        description: e instanceof Error ? e.message : "SSO login failed",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const value = loginId.trim();
    if (!value) {
      setError("Enter your Login ID to continue");
      return;
    }

    if (!value.toLowerCase().endsWith("@kpmg.com")) {
      setError("Only KPMG Email are allowed to login");
      return;
    }

    setError("");
    setLoading(true);

    try {
      if (!login) throw new Error("Service Unavailable");

      const result = await login(value);
      if (result?.success) {
        toast({
          title: "Success",
          description: "Login Success",
          variant: "success",
        });
        setAuthView("agreement");
      } else {
        throw new Error(result?.message || "Unexpected Error");
      }
    } catch (err) {
      toast({
        title: "",
        description: err instanceof Error ? err.message : "Generic Error",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className={styles.cardWrap}>
        <form className={styles.card} onSubmit={handleSubmit} noValidate>
          <div className={styles.cardBrand}>
            <div className={styles.wordmark}>Echo AI</div>
            <h1>Your AI workspace.</h1>
            <p className={styles.lede}>
              One sign-in for every EchoAI agent, document and workflow across
              the firm.
            </p>
          </div>

          <div className={styles.cardForm}>
            <p className={styles.eyebrow}>Secure Sign-In</p>
            <h2>Welcome back</h2>
            <p className={styles.sub}>Log in with your EchoAI credentials</p>

            <div className={styles.field}>
              <label htmlFor="loginId">Login ID</label>
              <div className={`${styles.input} ${error ? styles.invalid : ""}`}>
                <input
                  id="loginId"
                  value={loginId}
                  onChange={(e) => {
                    setLoginId(e.target.value);
                    setError("");
                  }}
                  placeholder="Type here"
                  autoComplete="username"
                  aria-describedby={error ? "login-error" : undefined}
                  aria-invalid={Boolean(error)}
                />
              </div>
            </div>

            {error && (
              <div
                id="login-error"
                className={`${styles.err} ${styles.show}`}
                role="alert"
              >
                {error}
              </div>
            )}

            <button
              className={`${styles.btn} ${styles.btnPrimary}`}
              disabled={loading}
            >
              <span>{loading ? "Signing in…" : "Login"}</span>
            </button>

            <div className={styles.or}>or</div>

            <button
              type="button"
              className={`${styles.btn} ${styles.btnGhost}`}
              disabled={loading}
              onClick={handleSSOLogin}
            >
              Single Sign On
            </button>
          </div>
        </form>
      </div>
      <p className={styles.legal}>
        By continuing you agree to the Acceptable Use Policy.
      </p>
    </>
  );
}
