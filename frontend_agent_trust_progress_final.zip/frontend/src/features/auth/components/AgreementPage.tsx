"use client";
import { useState } from "react";
import styles from "@/styles/auth.module.css";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

interface Props {}

export default function AgreementPage({}: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const { Agreement } = useAuth();

  const handleContinue = () => {
    Agreement();
    setLoading(true);
    setTimeout(() => router.push("/echo"), 500);
  };

  return (
    <>
      <div className={styles.cardWrap} style={{ maxWidth: "700px" }}>
        <main className={styles.cardAgreement}>
          <div className={styles.cardHead}>
            <div className={styles.headText}>
              <h1>User Agreement</h1>
              <p>Please review before continuing</p>
            </div>
            <div className={styles.headBrand}>Echo AI</div>
          </div>

          <section className={styles.sec}>
            <div className={styles.secHead}>
              <svg
                width="17"
                height="17"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="9" />
                <path d="m8.5 12.2 2.3 2.3 4.7-4.9" />
              </svg>
              <h2>AI-Powered Service Delivery</h2>
            </div>

            <p>We may leverage AI models to enhance service delivery by:</p>

            <ul className={styles.list}>
              <li>
                Responding to your queries with customised responses or
                greetings
              </li>
              <li>Generating recommendations based on historical data</li>
              <li>Providing actionable insights</li>
              <li>Assisting in automated decision-making processes</li>
            </ul>

            <div className={styles.note}>
              <p>
                To ensure fairness, accuracy, and appropriateness, all
                AI-assisted outputs and decisions are subject to review by
                experienced professionals. While AI contributes to greater
                efficiency and personalization, it may also present certain
                risks, such as:
              </p>
            </div>

            <ul className={`${styles.list} ${styles.mt16}`}>
              <li>Potential inaccuracies in AI-generated responses</li>
              <li>
                Over-reliance on historical data which may reduce adaptability
                to evolving contexts
              </li>
            </ul>

            <div className={`${styles.note} ${styles.plain}`}>
              <p>
                By using Echo AI, You agree and acknowledge that ECHO AI may
                process your personal data in accordance to the KPMG Privacy
                Policies <a href="#">KPMG People Privacy Notice</a> and{" "}
                <a href="#">KPMG Privacy Statements</a>
              </p>
              <p>
                For any further clarification or assistance, please reach out to
                the concerned departments or raise an incident on Incident
                Management System (<a href="#">Support Central</a>).
              </p>
            </div>
          </section>

          <div className={styles.actions}>
            <button
              className={`${styles.btn} ${loading ? styles.loading : ""}`}
              disabled={loading}
              onClick={handleContinue}
            >
              {loading ? "Continuing…" : "Continue"}
            </button>
          </div>
        </main>
      </div>
    </>
  );
}
