import { ArrowDown } from "lucide-react";
import { useEffect, useState } from "react";
import s from "@/styles/convobi.module.css";
import { Skeleton } from "@/components/ui/skeleton";
import { SchemaSummary } from "@/types/convobi.types";

export default function SchemaResponse({
  schemaResponse,
  loading,
}: {
  schemaResponse: SchemaSummary | null;
  loading: boolean;
}) {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [tableData, setTableData] = useState<any[]>([]);
  useEffect(() => {
    if (schemaResponse) {
      setTableData([]);
      Object.entries(schemaResponse.tables).map(
        ([name, values]: [string, any]) => {
          const data = {
            row_count: values.row_count,
            columns_count: Object.entries(values.columns[0])
              .map(([name, values]) => {
                return name;
              })
              .filter(
                (name: string) =>
                  name !== "confidence" &&
                  name !== "source" &&
                  name !== "examples",
              ).length,
          };
          setTableData((prev) => [...prev, { name: name, data: data }]);
        },
      );
    }
  }, [schemaResponse]);

  const LoadingSkeleton = () => {
    return (
      <div className="w-full p-4 flex flex-col gap-3">
        <Skeleton className="w-[50%] h-4" />
        <Skeleton className="w-[50%] h-4" />
        <Skeleton className="w-full h-5" />
        <Skeleton className="w-full h-5" />
      </div>
    );
  };

  return (
    <div className={s.biSchemaCard}>
      <div className={s.biAHead}>
        <ArrowDown
          className={`${s.expandIcon} ${showTable ? s.expanded : ""}`}
          onClick={() => setShowTable(!showTable)}
        />
        Schema Summary
      </div>
      {loading ? (
        <LoadingSkeleton />
      ) : (
        showTable && (
          <div className="p-3 flex flex-col gap-6 text-[13px]">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: "16px",
                padding: "12px",
                background: "var(--surface-2)",
                borderRadius: "10px",
              }}
            >
              <span>Total Tables</span>
              <strong>{schemaResponse?.total_tables ?? 0}</strong>
            </div>

            <div className="flex flex-col gap-2">
              <span className="text-[var(--text-muted)]">Tables: </span>
              {/* <table className="w-full border-collapse"> */}
              <div className={s.biTablewrap}>
                <table className={s.biTable}>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Table</th>
                      <th>Rows</th>
                      <th>Columns</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableData.map((table: any, ind: number) => (
                      <tr key={ind}>
                        <td>{ind}</td>
                        <td>{table.name}</td>
                        <td>{table.data.row_count}</td>
                        <td>{table.data.columns_count}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )
      )}
    </div>
  );
}
