import { ArrowDown } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import s from "@/styles/convobi.module.css";
import { Skeleton } from "@/components/ui/skeleton";
import { SchemaDoc } from "@/types/convobi.types";
import { convoBIService } from "@/services/convobi.service";
function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

export default function SchemaDocument({
  schemaDocument,
  connector_id,
  file_id,
  loading,
}: {
  schemaDocument: SchemaDoc | null;
  connector_id: string;
  file_id: string | null;
  loading: boolean;
}) {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [dropTableValues, setDropTableValues] = useState<string[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>("");
  const [columns, setColumns] = useState<string[]>([]);
  const [editableDoc, setEditableDoc] = useState<SchemaDoc | null>(null);
  const [originalDoc, setOriginalDoc] = useState<SchemaDoc | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  // 1) Initialize local editable copy when schemaDocument changes.
  useEffect(() => {
    if (!schemaDocument) {
      setEditableDoc(null);
      setDropTableValues([]);
      setSelectedTable("");
      setColumns([]);
      return;
    }
    const copy = deepClone(schemaDocument);
    setEditableDoc(copy);
    setOriginalDoc(deepClone(schemaDocument));

    // populate table dropdown
    const tableNames = Object.keys(copy?.doc?.tables ?? {});
    setDropTableValues(tableNames);

    // pick first table by default
    setSelectedTable((prev) => prev || tableNames[0] || "");
  }, [schemaDocument]);

  // 2) Derive column keys for the selected table
  useEffect(() => {
    if (!editableDoc || !selectedTable) {
      setColumns([]);
      return;
    }

    const rows = editableDoc?.doc?.tables?.[selectedTable]?.columns ?? [];
    const firstRow = rows[0] ?? {};
    const keys = Object.keys(firstRow).filter(
      (name) =>
        name !== "confidence" && name !== "source" && name !== "examples",
    );
    setColumns(keys);
  }, [editableDoc, selectedTable]);

  const tableRows = useMemo(() => {
    if (!editableDoc || !selectedTable) return [];
    return editableDoc.doc?.tables?.[selectedTable]?.columns ?? [];
  }, [editableDoc, selectedTable]);

  // 3) Update handlers (immutably)
  const handleCellChange = (
    rowIndex: number,
    colName: string,
    value: string,
  ) => {
    setEditableDoc((prev: any) => {
      if (!prev) return prev;
      const next = deepClone(prev);

      // Try to preserve original types (number/boolean/null)
      const original =
        next.doc.tables?.[selectedTable]?.columns?.[rowIndex]?.[colName];

      let parsed: any = value;
      if (value === "") {
        // Optionally treat empty string as null; adjust if you want to keep ""
        parsed = null;
      } else if (typeof original === "number" && !isNaN(Number(value))) {
        parsed = Number(value);
      } else if (original === null) {
        // keep as string or null based on your needs
        parsed = value;
      } else if (typeof original === "boolean") {
        // booleans handled in handleCheckboxChange
      }

      next.doc.tables[selectedTable].columns[rowIndex][colName] = parsed;
      return next;
    });
  };

  const handleCheckboxChange = (
    rowIndex: number,
    colName: string,
    checked: boolean,
  ) => {
    setEditableDoc((prev: any) => {
      if (!prev) return prev;
      const next = deepClone(prev);
      next.doc.tables[selectedTable].columns[rowIndex][colName] = checked;
      return next;
    });
  };

  const handleSave = async () => {
    if (!editableDoc) return;
    try {
      setSaving(true);

      const originalRows =
        originalDoc?.doc?.tables?.[selectedTable]?.columns ?? [];

      const cols = editableDoc?.doc?.tables?.[selectedTable]?.columns.map(
        (col: any, idx: number) => {
          const originalName = originalRows?.[idx]?.name;
          const currentName = col?.name;
          const nameChanged =
            String(currentName ?? "") !== String(originalName ?? "");

          const { column: _discardColumn, name: _discardName, ...rest } = col;

          return {
            column: nameChanged ? (originalName ?? "") : originalName,
            name: nameChanged ? col.name : "",
            ...rest,
          };
        },
      );
      const payload = file_id
        ? {
            edits: [
              {
                table: selectedTable,
                columns: cols,
              },
            ],
            fileId: connector_id,
          }
        : {
            edits: [
              {
                table: selectedTable,
                columns: cols,
              },
            ],
            connectionId: connector_id,
          };

      await convoBIService.editSchemaDoc(
        connector_id,
        file_id || null,
        payload,
      );
    } finally {
      setSaving(false);
    }
  };

  const doc = editableDoc?.doc;

  const LoadingSkeleton = () => {
    return (
      <div className="w-full p-4 flex flex-col gap-3">
        <Skeleton className="w-[50%] h-4" />
        <Skeleton className="w-[50%] h-4" />
        <Skeleton className="w-full h-6" />
        <Skeleton className="w-full h-6" />
      </div>
    );
  };

  return (
    <div className={s.biSchemaCard}>
      <div className={s.biAHead}>
        <ArrowDown
          className={`${s.expandIcon} ${showTable ? s.expanded : ""}`}
          onClick={() => setShowTable(!showTable)}
        />
        Schema Documentation
      </div>

      {loading ? (
        <LoadingSkeleton />
      ) : (
        showTable &&
        selectedTable !== "" &&
        editableDoc && (
          <div
            style={{
              padding: "20px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
              fontSize: "13px",
            }}
          >
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: "20px",
                padding: "12px",
                background: "var(--surface-2)",
                borderRadius: "10px",
              }}
            >
              <span>Dialect: </span>
              <span>{doc?.dialect}</span>

              <span>Generated At: </span>
              <span>
                {new Date(doc?.generated_at).toLocaleString("en-US", {
                  timeZone: "Asia/Kolkata",
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                  hour: "numeric",
                  minute: "2-digit",
                  hour12: true,
                })}
              </span>
              {/* <span>{formatIsoDate(doc?.generated_at)}</span> */}
            </div>

            <div className="flex flex-col gap-2">
              <label>Select a Table</label>
              <select
                className={s.biAsk}
                style={{
                  height: "42px",
                  border: "1px solid var(--line)",
                  borderRadius: "10px",
                  padding: "0 12px",
                  width: "280px",
                  background: "var(--paper)",
                }}
                onChange={(e) => setSelectedTable(e.target.value)}
              >
                {dropTableValues.map((table: string, ind: number) => (
                  <option key={ind} value={table}>
                    {table}
                  </option>
                ))}
              </select>
            </div>

            <div
              style={{
                background: "var(--surface-2)",
                borderRadius: "12px",
                padding: "16px",
              }}
            >
              <div style={{ marginBottom: "8px" }}>
                <strong>Overview</strong>
              </div>

              <div style={{ color: "var(--text-soft)" }}>
                {doc?.tables?.[selectedTable]?.overview}
              </div>

              <div style={{ marginTop: "12px" }}>
                <strong>Rows:</strong> {doc?.tables?.[selectedTable]?.row_count}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <span className="font-semibold">Columns: </span>
              <div
                className={s.biTablewrap}
                style={{
                  maxHeight: "500px",
                  overflow: "auto",
                }}
              >
                <table className={s.biTable}>
                  <thead>
                    <tr>
                      <th>ID</th>
                      {columns.map((col: string, ind: number) => (
                        <th style={{ textTransform: "capitalize" }} key={ind}>
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {tableRows.map((row: any, rowIndex: number) => (
                      <tr key={rowIndex}>
                        <td>{rowIndex}</td>

                        {columns.map((colName: string, colIndex: number) => {
                          const cell = row?.[colName];
                          const isBoolean = typeof cell === "boolean";

                          return (
                            <td key={`${rowIndex}-${colName}-${colIndex}`}>
                              {isBoolean ? (
                                <input
                                  name="col"
                                  type="checkbox"
                                  checked={Boolean(cell)}
                                  onChange={(e) =>
                                    handleCheckboxChange(
                                      rowIndex,
                                      colName,
                                      e.target.checked,
                                    )
                                  }
                                />
                              ) : (
                                <input
                                  name="col"
                                  type="text"
                                  style={{
                                    width: "100%",
                                    background: "transparent",
                                    border: "none",
                                    outline: "none",
                                    padding: "6px",
                                    color: "var(--text)",
                                  }}
                                  value={
                                    cell === null || typeof cell === "undefined"
                                      ? ""
                                      : String(cell)
                                  }
                                  onChange={(e) =>
                                    handleCellChange(
                                      rowIndex,
                                      colName,
                                      e.target.value,
                                    )
                                  }
                                />
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <button
              className={s.btnPrimary}
              onClick={handleSave}
              disabled={!editableDoc || saving}
            >
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </div>
        )
      )}
    </div>
  );
}
