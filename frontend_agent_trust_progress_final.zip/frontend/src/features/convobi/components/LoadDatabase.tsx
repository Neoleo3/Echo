"use client";

import { CloseIcon, DBIcon } from "@/components/common/Icons";
import s from "@/styles/convobi.module.css";
import { DBList } from "@/types/convobi.types";
import { useState } from "react";

interface Props {
  activeDb: DBList | null;
  list: DBList[];
  onClose: () => void;
  onSelect: (db: DBList) => void;
}

export const LoadDatabase = ({ activeDb, list, onClose, onSelect }: Props) => {
  const [selected, setSelected] = useState<DBList | null>(activeDb);
  return (
    <div className={s.overlay} onClick={() => onClose()}>
      <div className={s.dialog} onClick={(e) => e.stopPropagation()}>
        <div className={s.dialogHead}>
          <h3>Connect a Database</h3>
          <button
            className={s.dialogClose}
            onClick={() => onClose()}
            aria-label="Close"
          >
            <CloseIcon />
          </button>
        </div>
        <div className={s.dialogBody}>
          <div className={s.biDblist}>
            {list.map((db: DBList) => (
              <button
                key={db.id}
                className={`${s.biDb}${selected === db ? ` ${s.sel}` : ""}`}
                onClick={() => {
                  setSelected(db);
                }}
              >
                <div className={s.ic}>
                  <DBIcon />
                </div>
                <div>
                  <div className={s.n}>{db.name}</div>
                  <div className={s.u}>{db.connection_string_masked}</div>
                </div>
                <div className={s.tb}>{db.tables_count} tables</div>
              </button>
            ))}
          </div>
        </div>
        <div className={s.dialogFoot}>
          <button className={s.btnGhost} onClick={() => onClose()}>
            Cancel
          </button>
          <button
            className={s.btnPrimary}
            onClick={() => (selected ? onSelect(selected) : () => {})}
            disabled={!selected}
          >
            Connect
          </button>
        </div>
      </div>
    </div>
  );
};
