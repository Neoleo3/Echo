"use client";

import { useState } from "react";
import s from "@/styles/convobi.module.css";
import ReactMarkdown from "react-markdown";
import rehypeKatex from "rehype-katex";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import { convoBIService } from "@/services/convobi.service";
import { ConvoBIResponse } from "@/types/convobi.types";
import { CustomRenderers } from "@/features/chat/components/CustomRenders";
import PlotlyChart from "@/features/chat/components/PlotlyChat";
import { useToast } from "@/hooks/use-toast";

interface Props {
  activeDb: any;
  question: string;
  setQuestion: (value: string) => void;
  sampleQuestions: string[];
  connector_id: string;
  file_id: boolean;
}

export const generateUUID = (): string => {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

export default function ConvoBIChat({
  activeDb,
  question,
  setQuestion,
  sampleQuestions,
  connector_id,
  file_id,
}: Props) {
  const [showSql, setShowSql] = useState(false);
  const [session_id, setSessionID] = useState("");
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<ConvoBIResponse | null>(null);
  const [lastQuestion, setLastQuestion] = useState<string>("");

  const { toast } = useToast();

  const HandleSend = async (q?: string) => {
    if (connector_id === "") {
      toast({
        title: "No connector selected",
        description: "Please select select the DB or upload the file",
        variant: "warning",
      });
      console.warn("[ConvoBIChat] No connector selected.");
      return;
    }
    if (question === "" && q === "") {
      toast({
        title: "Empty Query",
        description: "Cannot send empty query.",
        variant: "warning",
      });
      console.warn("[ConvoBIChat] Cannot send empty query.");
      return;
    }
    const query = q ? q : question;
    let session = session_id;
    if (session_id === "") {
      session = generateUUID();
      setSessionID(session);
    }
    setLastQuestion(query);
    try {
      setResponse(null);
      setLoading(true);
      const data = file_id
        ? {
            message: query,
            session_id: session,
            file_id: connector_id,
          }
        : {
            message: query,
            session_id: session,
            connection_id: connector_id,
          };

      const svcResponse = await convoBIService.invoke(
        data as Record<string, unknown>,
      );
      console.log("Convobi Response: ", svcResponse);
      if (svcResponse.success) setResponse(svcResponse.data as ConvoBIResponse);
    } catch (err) {
      console.error("Error: ", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={s.biResponseWrap}>
      {/* Query Card */}
      <div className={s.biCard}>
        <label htmlFor="bi-question">Ask a question about your data</label>

        <div className={s.biAsk}>
          <input
            id="bi-question"
            type="text"
            placeholder={
              activeDb
                ? `Ask about ${activeDb.name}...`
                : "Connect a database first or upload a file..."
            }
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                HandleSend();
              }
            }}
          />

          <button
            className={s.biRun}
            onClick={() => HandleSend()}
            disabled={!question.trim() || loading}
          >
            {loading ? (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className={s.biSpin}
              >
                <path d="M21 12a9 9 0 1 1-9-9" />
              </svg>
            ) : (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            )}
            Run
          </button>
        </div>

        <div className={s.biChips}>
          {sampleQuestions.map((q) => (
            <button key={q} className={s.biChip} onClick={() => HandleSend(q)}>
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {!loading && !response && (
        <div className={s.biEmpty}>
          <svg
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
          >
            <line x1="18" y1="20" x2="18" y2="10" />
            <line x1="12" y1="20" x2="12" y2="4" />
            <line x1="6" y1="20" x2="6" y2="14" />
          </svg>

          <p>No query executed yet</p>

          <span>
            Connect a database or upload a file and start asking questions.
          </span>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className={s.biLoadingCard}>
          <div className={s.biLoadingHeader}>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              // style={{ animation: "spin 0.9s linear infinite", flexShrink: 0 }}
              className={s.biSpin}
            >
              <path d="M21 12a9 9 0 1 1-9-9" />
            </svg>
            Generating SQL and fetching results…
          </div>
          <div className={s.biLoadingBody}>
            <div className={s.biPulse} style={{ width: "70%", height: 14 }} />
            <div className={s.biPulse} style={{ width: "90%", height: 14 }} />
            <div className={s.biPulse} style={{ width: "55%", height: 14 }} />
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={s.biPulse}
                  style={{ flex: 1, height: 56, borderRadius: 10 }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Latest Result */}
      {response && !loading && (
        <>
          {/* Question bubble */}
          {lastQuestion && <div className={s.biQ}>{lastQuestion}</div>}
          <div className={s.biA}>
            {/* Header */}
            <div className={s.biAHead}>
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <ellipse cx="12" cy="5" rx="9" ry="3" />
                <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
              </svg>
              Query Result
              <button
                className={s.biSqlToggle}
                onClick={() => setShowSql(!showSql)}
              >
                {showSql ? "Hide SQL" : "Show SQL"}
              </button>
              <span className={s.biMs}>
                {response?.execution_time_ms ?? 0} ms
              </span>
            </div>

            {/* KPI CARDS */}

            <div className={s.biMetricGrid}>
              <div className={s.biMetricCard}>
                <span>Rows</span>
                <strong>{response?.row_count ?? 0}</strong>
              </div>

              <div className={s.biMetricCard}>
                <span>Columns</span>
                <strong>{response?.columns?.length ?? 0}</strong>
              </div>

              <div className={s.biMetricCard}>
                <span>Confidence</span>
                <strong>{response?.confidence ?? 0}</strong>
              </div>

              <div className={s.biMetricCard}>
                <span>Latency</span>
                <strong>{response?.execution_time_ms ?? 0} ms</strong>
              </div>
            </div>

            {/* SQL */}

            {showSql && response?.sql && (
              <pre className={s.biSql}>{response.sql}</pre>
            )}

            {/* Explanation */}

            {response?.explanation && (
              <div className={s.biSection}>
                <div className={s.biSectionTitle}>Explanation</div>

                <div className={s.biSectionBody}>{response.explanation}</div>
              </div>
            )}

            {/* Response */}

            {response?.response && (
              <div className={s.biSection}>
                <div className={s.biSectionTitle}>Response</div>

                <ReactMarkdown
                  children={response.response}
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={{
                    ...CustomRenderers,
                  }}
                />
              </div>
            )}

            {/* Summary */}

            {response?.summary && (
              <div className={s.biSection}>
                <div className={s.biSectionTitle}>Summary</div>

                <ReactMarkdown
                  children={response.summary}
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={{
                    ...CustomRenderers,
                  }}
                />
              </div>
            )}

            {/* Warnings */}

            {(response?.warnings?.length ?? 0) > 0 && (
              <div className={s.biWarn}>
                <div className={s.biSectionTitle}>
                  Warnings ({response?.warnings?.length ?? 0})
                </div>
                <ul>
                  {response?.warnings?.map((warn: string, ind: number) => (
                    <li key={ind}>{warn}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Optimizations */}

            {(response?.optimizations?.length ?? 0) > 0 && (
              <div className={s.biSuccess}>
                <div className={s.biSectionTitle}>
                  Optimizations ({response?.optimizations?.length ?? 0})
                </div>
                <ul>
                  {response?.optimizations?.map(
                    (optimization: string, ind: number) => (
                      <li key={ind}>{optimization}</li>
                    ),
                  )}
                </ul>
              </div>
            )}

            {/* Error */}

            {response?.error && (
              <div className={s.biError}>
                <div className={s.biSectionTitle}>Error</div>

                {response.error}
              </div>
            )}

            {/* Visualization */}

            {response?.visualization && (
              <div className={s.biSection}>
                <div className={s.biSectionTitle}>Visualization</div>

                <PlotlyChart visualization={response.visualization} />
              </div>
            )}

            {/* Table */}

            {(response?.data?.length ?? 0) > 0 && (
              <div className={s.biSection}>
                <div className={s.biSectionTitle}>Result Table</div>

                <div className={s.biTablewrap}>
                  <table className={s.biTable}>
                    <thead>
                      <tr>
                        <th>#</th>

                        {(response?.columns ?? []).map((column: string) => (
                          <th key={column}>{column}</th>
                        ))}
                      </tr>
                    </thead>

                    <tbody>
                      {(response?.data ?? []).map(
                        (row: Record<string, unknown>, rowIndex: number) => (
                          <tr key={rowIndex}>
                            <td>{rowIndex + 1}</td>

                            {(response?.columns ?? []).map((column: string) => (
                              <td key={column}>
                                {row[column] === null ? (
                                  "Null"
                                ) : typeof row[column] === "boolean" ? (
                                  <input
                                    type="checkbox"
                                    checked={row[column] as boolean}
                                    readOnly
                                  />
                                ) : (
                                  String(row[column])
                                )}
                              </td>
                            ))}
                          </tr>
                        ),
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className={s.biFoot}>
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <circle cx="12" cy="12" r="9" />
                <path d="M12 8v4l3 3" />
              </svg>

              {new Date().toLocaleString(undefined, {
                dateStyle: "medium",
                timeStyle: "short",
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
