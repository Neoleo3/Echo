export type MissingKind =
  | "document"
  | "spreadsheet"
  | "database"
  | "knowledge"
  | "connector";

export type MissingAction = "upload" | "connect" | "describe";

export interface MissingItem {
  kind: MissingKind | string;
  label: string;
  why?: string;
  accepts?: string[];
  blocking?: boolean;
}

export interface MissingContext {
  reason: string;
  intent?: string;
  skill_considered?: string;
  missing: MissingItem[];
  optional?: MissingItem[];
  available?: string[];
  action?: MissingAction | string;
}

export interface ClarificationState {
  round: number;
  max_rounds: number;
  asked?: number;
  known?: number;
  exhausted?: boolean;
}

export interface OrchestrationLlm {
  source: "credential" | "model_id" | "kv" | "none" | string;
  credential_id?: string | null;
  model_id?: string | null;
}

export interface ApplicationContextTrace {
  bound_connectors?: number;
  bound_knowledge_bases?: number;
  searchable_documents?: number;
}

export interface EvidenceGateTrace {
  outcome: "proceed" | "stop" | string;
  required?: unknown[];
  suppressed?: unknown[];
  resolved_from_history?: unknown[];
  planned_steps?: number;
  execution_strategy?: string;
  duration_ms?: number;
}

export interface OrchestratorPlanTrace {
  intent?: string;
  task_summary?: string;
  produces_new_content?: boolean;
  decision?: string;
  reasoning?: string;
  evidence_required?: unknown[];
  information_required?: unknown[];
}

export interface ExecutionTrace {
  missing_context?: MissingContext;
  assumptions?: string[];
  clarification?: ClarificationState;
  orchestration_llm?: OrchestrationLlm;
  application_context?: ApplicationContextTrace;
  evidence_gate?: EvidenceGateTrace;
  orchestrator_plan?: OrchestratorPlanTrace;
  [key: string]: unknown;
}

export interface ChatMessageResponse {
  message_id: string;
  role: string;
  content: string;
  enhanced_prompt?: string | null;
  execution_trace?: ExecutionTrace | null;
  guardrail_flags?: Record<string, unknown> | null;
  created_at: string;
}

export interface LedgerSource {
  source_id: string;
  kind: string;
  name: string;
  reachable: boolean;
  detail?: string;
  error?: string | null;
}

export interface LedgerDocument {
  document_id: string;
  filename: string;
  mime_type?: string;
  status: string;
}

export interface LedgerCounts {
  connectors: number;
  connectors_reachable: number;
  knowledge_bases: number;
  indexed_documents: number;
  session_documents: number;
  tabular_files: number;
}

export interface ContextLedger {
  application_id: string;
  chat_session_id?: string | null;
  resolved_at?: number;
  age_seconds?: number;
  connectors: LedgerSource[];
  knowledge: LedgerSource[];
  session_documents: LedgerDocument[];
  tabular_files: LedgerDocument[];
  counts: LedgerCounts;
  errors: string[];
}
