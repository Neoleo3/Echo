/**
 * Authentication types
 */

import { AUTH_ROLES } from "@/config";

export type UserRole = (typeof AUTH_ROLES)[keyof typeof AUTH_ROLES];

export interface User {
  token: string;
  refresh_token: string;
  user_id: string;
  email: string;
  display_name: string;
  role: string;
  session_id: string;
  session?: unknown;
}

export interface Session {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  // lastActivity: number;
  lastRefreshAt: number;
  // pageState?: {
  //   route?: string;
  //   module?: string;
  //   data?: Record<string, unknown>;
  // };
}

/** Shape returned by /sessions/sso/login */
export interface SSOLoginResponse {
  authorization_url: string;
  state: string;
}

/** Shape returned by /sessions/sso/callback */
export interface SSOCallbackResponse {
  user_name: string;
  user_role: string;
  designation: string;
  user_login_id: string;
  access_token: string;
  refresh_token: string;
  api_key?: string;
  user_uuid: string;
  email_id: string;
  department: string;
  location: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  isAuthError?: boolean;
}
