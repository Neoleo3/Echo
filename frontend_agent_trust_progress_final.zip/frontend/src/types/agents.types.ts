export interface AgentModelConfig {
  model?: string;
  provider?: string;
  temperature?: number;
  top_p?: number;
  max_tokens?: number;
}

export interface AgentDefinition {
  agent_id?: string;
  name: string;
  description?: string;
  instructions?: string;
  tools?: string[];
  knowledge_sources?: unknown[];
  model_config?: AgentModelConfig;
  icon?: string;
  credential_id?: string;
  connectors?: unknown[];
  connector_settings?: { enabled: boolean };
  files?: unknown[];
  readiness?: ReadinessSettings;
  created_via?: string;
  config_version?: string | number;
  metadata?: Record<string, unknown>;
  prompt?: string;
  settings?: Record<string, unknown>;
  model?: string;

  role?: string;
  goal?: string;
  backstory?: string;
}

export interface AgentDraft {
  schema_version?: string;
  agent_id?: string;
  name: string;
  description?: string;
  instructions?: string;
  tools?: string[] | { selected?: string[]; [key: string]: unknown };
  model_config?: AgentModelConfig;
  credential_id?: string;
  icon?: string;
  metadata?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface AgentRegisterResponse {
  agent_id?: string;
  saved_agent?: AgentDefinition;
  status?: string;
  schema_version?: string;
  [key: string]: unknown;
}

export interface AgentTool {
  tool_id: string;
  name: string;
  description?: string;
  tool_type?: string;
  tags?: string[];
  /** `builtin` or a connector-derived source. */
  source?: string;
  status?: string;
  version?: string;
}

export interface AvailableToolsResponse {
  tools: AgentTool[];
  builtin_count?: number;
  connector_count?: number;
  total?: number;
}

export type DesignStep = "initial" | "name" | "refine" | "done";

export interface AgentDesignRequest {
  message: string;
  step: DesignStep | string;
  agent_state?: Record<string, unknown>;
  model?: string;
}

export interface AgentDesignResponse {
  reply: string;
  step: DesignStep | string;
  action: string;
  agent_state: Record<string, unknown>;
  tools_available?: unknown[];
  draft_changed?: boolean;

  changed_fields?: string[];
}

export type ConnectorGroup = "api" | "mcp" | "database";

export type AccessLevel = "read_only" | "read_write" | "full_access";

export interface AvailableConnector {
  connector_id: string;
  kind: ConnectorGroup | string;
  name: string;
  description?: string;
  detail?: string;
  status?: string;
  enabled?: boolean;
  operations_detail?: ConnectorOperation[];
  access_level_preview?: Record<string, unknown>;
}

export interface AvailableConnectorGroups {
  api: AvailableConnector[];
  mcp: AvailableConnector[];
  database: AvailableConnector[];
  total?: number;
}

export interface ConnectorOperation {
  name: string;
  description?: string;
  access?: "read" | "write" | "destructive" | string;
  annotated?: boolean;
}

export interface AttachedConnector {
  connector_id: string;
  name: string;
  access_level?: AccessLevel;
  resolved?: boolean;
  error?: string;
  operations_detail?: ConnectorOperation[];
  effective_operations?: string[];
}

export interface AttachConnectorRequest {
  connector_id: string;
  kind?: ConnectorGroup | string;
  alias?: string;
  access_level?: AccessLevel;
  allowed_operations?: string[];
}

export type AgentFileStatus = "pending" | "processing" | "ready" | "failed";

export interface AgentFile {
  file_id: string;
  agent_id?: string;
  name: string;
  url?: string | null;
  format?: string;
  mime_type?: string;
  source_type?: string;
  status: AgentFileStatus | string;
  size_bytes?: number;
  char_count?: number;
  chunk_count?: number;
  converted_by?: string;
  embedding_model?: string;
  enabled?: boolean;
  ingest_mode?: "inline" | "retrieval" | string;
  error_message?: string;
  ocr_skipped_reason?: string;
  deduplicated?: boolean;
}

export interface AgentFilesResponse {
  agent_id: string;
  connector_settings: { enabled: boolean };
  files: AgentFile[];
  count: number;
}

export interface AgentConnectorsResponse {
  agent_id?: string;
  connector_settings?: { enabled: boolean };
  connectors: AttachedConnector[];
  count?: number;
}

export interface AgentKnowledgeBasesResponse {
  agent_id?: string;
  connector_settings?: { enabled: boolean };
  knowledge_bases: AgentKnowledgeBase[];
  count?: number;
}

export interface AgentKnowledgeBase {
  knowledge_base_id: string;
  name?: string;
  alias?: string;
  description?: string;
  status?: string;
  document_count?: number;
  processing_type?: string;
}

export interface MarkitdownStatus {
  markitdown_installed: boolean;
  vision_model_resolved?: boolean;
  vision_model_reason?: string;
}

export type ReadinessMode = "warn" | "block" | "off";
export type FindingSeverity = "block" | "warn";
export type FindingStage = "precheck" | "heuristic" | "grading";

export interface ReadinessFinding {
  code: string;
  /** Written for the user — safe to show verbatim. */
  message: string;
  severity: FindingSeverity | string;
  stage: FindingStage | string;
  subject?: string;
}

export interface ReadinessReport {
  agent_id?: string;
  mode: ReadinessMode | string;
  ready: boolean;
  blocked: boolean;
  checked?: boolean;
  graded?: boolean;
  verdict?: string | null;
  confidence?: number | null;
  findings: ReadinessFinding[];
  message?: string;
}

export interface ReadinessSettings {
  mode?: ReadinessMode;
  grading_enabled?: boolean;
}
