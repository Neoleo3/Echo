export interface ModelUsageWindow {
  used: number;
  limit: number | null;
  remaining: number | null;
  utilization_pct: number | null;
}

export interface ModelUsage {
  credential_id: string;
  credential_name: string;
  model: string;
  provider: string;
  billing_source: string;
  daily: ModelUsageWindow;
  monthly: ModelUsageWindow;
  lifetime_tokens: number;
  total_calls: number;
}
