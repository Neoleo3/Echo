declare module "crypto-js"
