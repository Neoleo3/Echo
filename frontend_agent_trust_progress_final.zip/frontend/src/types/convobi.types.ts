import { Visualization } from "@/features/chat/components/PlotlyChat";

export interface DBList {
  connection_string_masked: string;
  db_type: string;
  dialect: string;
  id: string;
  name: string;
  ssh_host: string | null;
  ssh_tunnel_enabled: boolean;
  tables_count: number;
  uploaded_file_name: string | null;
  views_count: number;
}

export interface LoadDB {
  show: boolean;
  activeDb: DBList | null;
  list: DBList[];
}

export interface DBConnectionsResponse {
  connections: DBList[];
}

export interface SchemaDoc {
  doc: {
    tables: any;
    total_tables: number;
    dialect: string;
    generated_at: any;
  };
  tables: string[];
  markdown: string;
  markdown_by_table: any;
}

export interface SchemaSummary {
  tables: any;
  total_tables: number;
  summary: string;
}

export interface loadSchema {
  document: SchemaDoc | null;
  summary: SchemaSummary | null;
  loading: boolean;
}

export interface ConvoBIResponse {
  response?: string;
  summary?: string;
  sql?: string;
  warnings?: string[];
  optimizations?: string[];
  error?: string;
  visualization?: Visualization;
  data?: Record<string, unknown>[];
  columns?: string[];
  row_count?: number;
  execution_time_ms?: number;
  confidence?: number;
  explanation?: string;
}

export interface BiChartBar {
  label: string;
  value: number;
}

export interface BiRow {
  [key: string]: string | number;
}
