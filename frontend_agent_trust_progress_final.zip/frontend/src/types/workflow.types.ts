export type HitlDecision = "approve" | "reject" | "edit";

export interface HitlInterrupt {
  interrupt_type: "hitl_review" | "file_upload" | string;
  title?: string;
  message?: string;
  priority?: string;
  allowed_decisions: HitlDecision[] | string[];
  preceding_output?: unknown;
  preceding_node_name?: string;
  state_snapshot?: Record<string, unknown>;
}

export interface HitlResumeRequest {
  action: HitlDecision | string;
  payload?: {
    changes?: { edit_feedback?: string; [key: string]: unknown };
    [key: string]: unknown;
  };
}

export type HitlOutcome = "approved" | "rejected" | "editing" | string;

export interface HitlDecisionRecord {
  action: HitlDecision | string;
  actor?: string;
  rationale?: string;
  reviewed_node?: string;
}

export interface NodeOutput {
  node_id?: string;
  node_name?: string;
  node_type?: "agent" | "hitl" | "review" | string;
  seq?: number;
  output?: unknown;
  decision?: HitlDecisionRecord;
  passed?: boolean;
  confidence?: number;
  feedback?: string;
  issues?: unknown[];
}

export interface AgentResolution {
  source: "registry" | "embedded" | string;
  config_version?: string | number;
  name?: string;
}

export interface CollaborationContext {
  inherit_upstream?: boolean;
  publish_downstream?: boolean;
  max_context_chars?: number;
}

export interface WorkflowRunStatus {
  run_id: string;
  status: "running" | "completed" | "failed" | "hitl_rejected" | string;
  hitl_outcome?: HitlOutcome;
  all_node_outputs?: NodeOutput[];
  agent_resolution?: Record<string, AgentResolution>;
  interrupt?: HitlInterrupt;
}

export interface StepTokenEvent {
  event: "step_token";
  run_id: string;
  step_id: string;
  payload: { text: string; seq: number; step_name?: string };
}

export const WORKFLOW_NODE_TYPES = [
  "Start",
  "End",
  "Agent",
  "Subagent",
  "Conditional",
  "Loop",
  "Map",
  "HITL",
  // "Self-Review",
  "API",
  "MCP",
  "Code",
] as const;

export type WorkflowNodeType = (typeof WORKFLOW_NODE_TYPES)[number];

export interface CanvasVariable {
  name: string;
  type?: string;
  description?: string;
  required?: boolean;
}

export interface AgentNodeModel {
  modelName?: string;
  displayName?: string;
  provider?: string;
  credentialId?: string;
}

export interface CanvasBranch {
  label?: string;
  condition?: string;
  target?: number | string;
}

export interface CanvasNodeConfig {
  agent_id?: string;
  prompt?: string;
  description?: string;
  icon?: string;
  model?: string | AgentNodeModel;
  /** `tool_id` strings, exactly what `AgentToolsPicker` emits. */
  tools?: unknown[];
  temperature?: number;
  topP?: number;
  maxTokens?: number;
  maxIterations?: number;
  variables?: CanvasVariable[];

  /* Start / End */
  inputVariables?: CanvasVariable[];
  outputVariables?: CanvasVariable[];
  fileUploadConfig?: { enabled?: boolean; [key: string]: unknown };

  /* Conditional */
  branches?: CanvasBranch[];

  /* Loop */
  loopType?: string;
  arrayVariable?: string;

  /* Map */
  operation?: string;
  maxConcurrency?: number;

  /* HITL — note there is no `allowDefer`; a checkpoint offers approve,
     reject and edit, and the backend drops the flag if a canvas sends it. */
  title?: string;
  message?: string;
  priority?: string;
  allowEdit?: boolean;

  /* API */
  method?: string;
  url?: string;
  headers?: Record<string, unknown> | string;
  auth?: Record<string, unknown>;
  body?: unknown;
  query_params?: Record<string, unknown>;

  /* MCP */
  serverId?: string;
  serverName?: string;
  toolName?: string;
  endpoint_url?: string;
  auth_config?: Record<string, unknown>;
  connector_id?: string;
  connectorId?: string;
  transport_type?: string;
  command?: string;
  timeout?: number;
  /** JSON typed into the arguments textarea; parsed server-side. */
  argumentsRaw?: string;

  /* Code */
  language?: string;
  code?: string;
  packages?: string;

  /* Self-Review */
  checkCompleteness?: boolean;
  checkAccuracy?: boolean;
  confidenceThreshold?: number;

  [key: string]: unknown;
}

export interface CanvasNode {
  id: number;
  type: WorkflowNodeType | string;
  name: string;
  label: string;
  icon: string;
  color: string;
  description?: string;
  x: number;
  y: number;
  status: string;
  config: CanvasNodeConfig;
  backend_id?: string;
  agentId?: string;
}

export interface CanvasConnection {
  id: number;
  from: number;
  to: number;
}

export interface CanvasSaveResponse {
  success?: boolean;
  errors?: string[];
  warnings?: string[];
  workflow_id?: string;
  workflow?: Record<string, unknown>;
  db_saved?: boolean;
  [key: string]: unknown;
}

export interface CanvasLoadResponse {
  canvas_nodes: CanvasNode[];
  connections: CanvasConnection[];
  workflow_name: string;
  workflow_icon?: string;
}

export interface WorkflowSummary {
  workflow_id?: string;
  id?: string;
  name?: string;
  description?: string;
  status?: string;
  icon?: string;
  agents?: unknown[];
  updated_at?: string;
  created_at?: string;
  [key: string]: unknown;
}

export interface WorkflowRunHandle {
  session_id: string;
  run_id: string;
  status?: string;
  message?: string;
}

export interface CatalogEntry {
  id: string;
  name: string;
  description?: string;
  category?: string;
}

export interface DesignCatalog {
  skills: CatalogEntry[];
  tools: CatalogEntry[];
}

export interface AuraAgent {
  name?: string;
  role?: string;
  goal?: string;
  skills?: string[];
  tools?: string[];
  depends_on?: string[];
  [key: string]: unknown;
}

export interface WorkflowDesignResult {
  final_event?: string;
  status?: string;
  reason?: string;
  workflow_name?: string;
  workflow_type?: string;
  agents?: AuraAgent[];
  agent_count?: number;
  dag_levels?: string[][];
  dag_evaluation?: { score?: number; verdict?: string; [k: string]: unknown };
  degraded?: boolean;
  notice?: string | null;
  clarification_questions?: string[];
  echo_spec?: {
    workflow?: Record<string, unknown>;
    agents?: Record<string, unknown>;
  };
  catalog?: DesignCatalog;
  [key: string]: unknown;
}

export interface DesignStageEvent {
  event: string;
  data: Record<string, unknown>;
}

export interface WorkflowChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
  run_id?: string | null;
  pending?: boolean;
  failed?: boolean;
}

export interface WorkflowChatHistory {
  session_id?: string;
  workflow_id?: string;
  messages?: Array<Record<string, unknown>>;
  context?: Record<string, unknown>;
  [key: string]: unknown;
}
