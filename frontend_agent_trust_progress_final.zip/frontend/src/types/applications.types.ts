import { DataSourceRef, LlmLink, SkillLink } from "./chat.types";

/** Application (from /api/applications) */
export interface Application {
  application_id: string;
  user_id: string;
  name: string;
  description: string;
  status: string;
  error_message: string | null;
  available_for_all_users: boolean;
  upload_enabled: boolean;
  welcome_prompt: string | null;
  disclaimer: string | null;
  sorry_message: string | null;
  starter_questions: string[];
  persona_id: string | null;
  persona_text: string;
  guardrail_text: string;
  logo_url: string | null;
  created_at: string;
  updated_at: string;
  approval_status: string;
  approved_by: string;
  rejection_reason: null;
  llm_links: LlmLink[];
  skill_links: SkillLink[];
  data_source_ids: DataSourceRef[];
  designation_ids: string[];
  business_unit_ids: string[];
  tag_ids: string[];
  guardrail_category_ids: string[];
  designation_names: string[];
  business_unit_names: string[];
  tag_names: string[];
}

/** Application (from /api/applications/visible) */
export interface ApplicationList {
  application_id: string;
  name: string;
  status: string;
  description: string;
  logo_url: string | null;
  llm_count: number;
  data_source_count: number;
  skill_count: number;
  error_message: string | null;
  approval_status: string;
  approved_by: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}
