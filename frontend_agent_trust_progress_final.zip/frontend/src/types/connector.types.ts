export type ConnectorKind = "mcp" | "api" | "db" | "channel";

export type ApiAuthType =
  | "none"
  | "api_key"
  | "bearer"
  | "basic"
  | "oauth2_client_credentials"
  | "oauth2_authorization_code"
  | "custom_header";

export type McpAuthType =
  | "none"
  | "api_key"
  | "bearer"
  | "basic"
  | "oauth2"
  | "custom_header";

export type AddTo = "header" | "query";

export type AuthValues = Record<string, unknown>;

export interface AuthPayload {
  auth_type: string;
  auth_config: Record<string, unknown>;
}

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export type ContentType =
  | "application/json"
  | "application/x-www-form-urlencoded"
  | "multipart/form-data"
  | "text/plain";

export interface ApiConnectorPayload {
  name: string;
  description?: string;
  logo?: string;
  endpoint_url: string;
  method?: HttpMethod | string;
  headers?: Record<string, string>;
  query_params?: Record<string, string>;
  default_body?: Record<string, unknown> | null;
  content_type?: ContentType | string;
  timeout?: number;
  retry_count?: number;
  verify_ssl?: boolean;
  auth_type?: ApiAuthType | string;
  auth_config?: Record<string, unknown>;
}

export type McpTransport = "streamable_http" | "stdio";

export interface McpConnectorPayload {
  name: string;
  description?: string;
  icon?: string;
  transport_type: McpTransport | string;
  endpoint_url?: string;
  headers?: Record<string, string>;
  timeout?: number;
  enabled?: boolean;
  command?: string;
  args?: string[];
  env_vars?: Record<string, string>;
  working_dir?: string;
  shell?: boolean;
  auth_type?: McpAuthType | string;
  auth_config?: Record<string, unknown>;
}

export interface DbConnectorPayload {
  db_type: string;
  name?: string;
  host?: string;
  port?: number;
  database_name?: string;
  username?: string;
  password?: string;
  account_url?: string;
  odbc_connection_string?: string;
  database_file_path?: string;
  uploaded_db_file_id?: string;
}

export interface SupportedDatabase {
  db_type: string;
  label: string;
  default_port?: number | null;
  default_driver?: string | null;
  drivers_available?: boolean;
  placeholder_host?: string;
  supports_file_upload?: boolean;
}
