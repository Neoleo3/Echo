/**
 * Chat / conversation types
 */

export type MessageRole = "user" | "agent";

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  agentId?: string;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  agentId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Agent {
  id: string;
  name: string;
  description: string;
  icon?: string;
  category: "featured" | "productivity" | "analytics" | "custom";
  owner?: string;
  isFeatured?: boolean;
}

export interface ChatCompletionRequest {
  agentId: string;
  conversationId?: string;
  message: string;
}

export interface ChatCompletionResponse {
  message: Message;
  conversationId: string;
}

export interface LlmLink {
  llm_id: string;
  role?: "orchestrator" | "enhancer" | "general";
  name?: string;
}

/** One skill (agent or workflow) bound to an application. */
export interface SkillLink {
  skill_id: string;
  skill_type?: string;
  skill_name?: string;
  skill_description?: string;
}

export type DataSourceRef =
  | string
  | { data_source_id: string; kind: "database" | "mcp" | "api" | "knowledge" };

export interface StreamStep {
  id: string;
  icon: string;
  label: string;
  detail?: string;
  status:
    | "pending"
    | "running"
    | "completed"
    | "failed"
    | "interrupted"
    | "skipped";
  output?: string;
}

/** LLM model, as returned by `GET /LLMs/models/list`. */
export interface LLMModel {
  id?: string;
  credential_id?: string;
  is_default?: boolean;
  is_default_embedding?: boolean;
  is_embedding?: boolean;
  is_system?: boolean;
  model_id?: string;
  name: string;
  provider: string;
  base_url: string;
  api_key: string;
  model_name: string;
  description: string;
  icon?: string;
  api_version?: string;
  deployment_name?: string;
  api_key_set?: boolean;
  context_window?: number | null;
  max_output_tokens?: number | null;
  temperature?: number | null;
  model_family?: LlmModelFamily;
  reasoning_effort?: LlmReasoningEffort | null;
  enabled?: boolean;
  credential_name?: string;
  workbench_provider?: string;
  charge_code?: string;
  region_override?: string;
  azureml_model_deployment?: string;
  token_usage_limit?: number | null;
  usage_limit_duration?: "minute" | "hour" | "day" | null;
}

export type LlmModelFamily = "auto" | "gpt4" | "gpt5";

export type LlmReasoningEffort =
  | "none"
  | "minimal"
  | "low"
  | "medium"
  | "high"
  | "xhigh"
  | "max";

export interface LlmProviderCatalogEntry {
  id: string;
  name: string;
  requires_fields: string[];
  known_models?: string[];
  allow_custom_model?: boolean;
}

export interface LlmTestResult {
  success: boolean;
  model_response?: string | null;
  error?: string | null;
}

export interface Connector {
  connector_id?: string;
  id?: string;
  connector_name?: string;
  name: string;
  description: string;
  connector_type?: string;
  integration_type?: string;
  transport_type?: string;
  endpoint_url?: string;
  status?: string;
  validation_status?: string;
  creation_payload?: Record<string, unknown>;
  server_info?: Record<string, unknown>;
  capabilities?: Record<string, unknown>;
  discovery?: Record<string, unknown>;
  created_at?: string;
  updated_at?: string;
}

export interface KnowledgeSource {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  source: string;
  processing: string;
  status: "synced" | "syncing" | "error";
  files?: number;
  chunkSize?: number;
  chunkOverlap?: number;
  /** Snake-case aliases returned by some API responses. */
  document_count?: number;
  chunk_size?: number;
  chunk_overlap?: number;
  source_type?: string;
}

export interface LookupItem {
  id: string;
  name: string;
}
export interface AdminUser {
  user_id?: string;
  id?: string;
  email: string;
  display_name: string;
  role: string;
  designation_ids?: string[];
  business_unit_ids?: string[];
  designations?: LookupItem[];
  business_units?: LookupItem[];
  is_active?: boolean;
}

export interface ApprovalQueueItem {
  application_id: string;
  app_type: string;
  name: string;
  description?: string | null;
  status: string;
  approval_status: string;
  approved_by?: string | null;
  rejection_reason?: string | null;
  logo_url?: string | null;
  llm_count: number;
  skill_count: number;
  data_source_count: number;
  user_id: string;
  created_at?: string;
  updated_at?: string;
}

export interface ApprovalFocus {
  applicationId: string | null;
  nonce: number;
}

export interface AppNotification {
  notification_id: string;
  type: string;
  title: string;
  message: string;
  reference_id?: string | null;
  reference_type?: string | null;
  is_read: boolean;
  created_at: string;
}

// Chat Stream ueEchoChat interfaces

export interface MessageAttachment {
  document_id: string;
  original_filename: string;
  size_bytes?: number;
  mime_type?: string;
}

export interface EchoMessage {
  role: "user" | "agent";
  content: string;
  execution_trace?: Record<string, unknown>;
  attachments?: MessageAttachment[];
}

export interface PendingUploadFile {
  name: string;
  size: number;
}

export interface SessionDocument {
  document_id: string;
  original_filename: string;
  processing_status: string;
  chunk_count?: number;
  size_bytes?: number;
  mime_type?: string;
}

export interface Step {
  id: string;
  icon: string;
  label: string;
  detail?: string;
  status:
    | "pending"
    | "running"
    | "completed"
    | "failed"
    | "interrupted"
    | "skipped";
  output?: string;
}

/** Shape of events emitted by the SSE chat stream. */
export interface OutputDelta {
  seq?: number;
  text?: string;
}

export interface DataModelUpdate {
  steps?: Step[];
  output_delta?: OutputDelta;
  chat_session_id?: string;
  final_output?: string;
}

export interface StreamEvent {
  type: string;
  data?: DataModelUpdate;
  message?: string;
}

/** Raw message row returned by the session-history endpoint. */
export interface RawMessage {
  role: string;
  content: string;
  execution_trace?: Record<string, unknown>;
}

/** Shape of the chat-upload response. */
export interface ChatUploadResponse {
  session_id?: string;
  // documents?: Array<{
  //   document_id?: string;
  //   processing_status?: string;
  // }>;
  documents?: SessionDocument[];
}

/** Shape of the session-documents response. */
export interface SessionDocumentsResponse {
  documents?: SessionDocument[];
}
