"use client";

import { useEffect, useState } from "react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const isDev = process.env.NODE_ENV === "development";
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div
      role="alert"
      className="flex min-h-[70vh] flex-col items-center justify-center text-center px-6"
    >
      <h1 className="text-2xl font-semibold text-red-600 mb-2">
        Something Went Wrong
      </h1>
      <p className="text-gray-600 mb-6">
        This page encountered an unexpected error.
        {error.digest && (
          <span className="block text-sm text-gray-400 mt-1">
            Reference: {error.digest}
          </span>
        )}
      </p>

      <button
        className="px-4 py-2 rounded-lg bg-black text-white hover:opacity-80"
        onClick={() => reset()}
      >
        Try Again
      </button>

      {isDev && (
        <>
          <button
            className="mt-4 px-4 py-2 rounded-lg bg-black text-white hover:opacity-80"
            onClick={() => setShowDetails((v) => !v)}
          >
            {showDetails ? "Hide Details" : "Show Details"}
          </button>

          {showDetails && (
            <div className="mt-5 text-left bg-gray-100 p-4 rounded-lg overflow-x-auto max-w-2xl w-full">
              <p className="font-semibold mb-1">Error Message</p>
              <pre className="text-sm whitespace-pre-wrap break-all">
                {error?.message ?? ""}
              </pre>
              {error?.stack && (
                <>
                  <p className="font-semibold mt-4 mb-1">Stack Trace</p>
                  <pre className="text-xs whitespace-pre-wrap break-all">
                    {error.stack}
                  </pre>
                </>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
