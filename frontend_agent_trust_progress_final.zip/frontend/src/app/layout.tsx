import type { Metadata } from "next";
import "./globals.css";
import localFont from "next/font/local";
import { connection } from "next/server";
import { Toaster } from "@/components/ui/toaster";

const inter = localFont({
  src: "../../public/fonts/InterRegular.ttf",
  style: "normal",
});

export const metadata: Metadata = {
  title: "Echo AI",
  description:
    "Your AI assistant for documents, conversations, and data—all in one place.",
  generator: "development",
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  await connection();

  return (
    <html suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('echoai-theme');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-theme',t);}catch(e){}})();`,
          }}
        />
      </head>
      <body className={inter.className}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
