"use client";
import { ROUTES } from "@/config";
import { useAuth } from "@/hooks/useAuth";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, {
  Suspense,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

const BACKEND_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ??
  "https://ecoapilwebapp02-ash2f8e6fcgzexgq.centralindia-01.azurewebsites.net";
const CALLBACK_TIMEOUT_MS = 35_000;
const RETRY_DELAY_MS = 2_000;
const MAX_RETRIES = 1;

async function fetchWithTimeout(
  url: string,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      signal: controller.signal,
      credentials: "include",
    });
  } finally {
    clearTimeout(timer);
  }
}

function SSOCallbackContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const calledRef = useRef(false);
  const [error, setError] = useState("");

  const { callbackHandler } = useAuth();

  const HandleSSO = async () => {
    if (calledRef.current) return;
    calledRef.current = true;

    const code = searchParams.get("code");
    const state = searchParams.get("state");
    const msError = searchParams.get("error");
    const msErrorDesc = searchParams.get("error_description");

    if (msError) {
      setError(msErrorDesc || msError);
      return;
    }

    if (!code) {
      setError("No authorization code received from Microsoft.");
      return;
    }

    const params = new URLSearchParams({ code });
    if (state) params.append("state", state);

    if (!BACKEND_URL) {
      setError("Backend URL is not configured for SSO callback.");
      return;
    }

    // Use the backend host directly so auth cookies are stored for the same
    // host that serves subsequent authenticated API requests.
    const url = `${BACKEND_URL}/sessions/sso/callback?${params}`;

    let lastError = "";
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        if (attempt > 0) {
          await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
        }

        const res = await fetchWithTimeout(url, CALLBACK_TIMEOUT_MS);

        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          // Do not retry HTTP errors — they are deterministic
          setError(err.detail || "SSO login failed. Please try again.");
          return;
        }

        const data = await res.json();
        if (data?.token) {
          const response = await callbackHandler(data);
          if (response) {
            router.push(ROUTES.AGREEMENT);
          }
        }
        return;
      } catch (e: unknown) {
        const isAbort = e instanceof DOMException && e.name === "AbortError";

        if (isAbort) {
          lastError =
            "The login request timed out. Please check your network and try again.";
        } else {
          lastError =
            "Unable to reach the login server. Please check your network connection and try again.";
        }
      }
    }

    // All retries exhausted
    setError(lastError);
  };

  useEffect(() => {
    HandleSSO();
  }, [searchParams, callbackHandler]);

  if (error) {
    return (
      <div style={{ maxWidth: 400, margin: "100px auto", textAlign: "center" }}>
        <h2>SSO Login Failed</h2>
        <p style={{ color: "red" }}>{error}</p>
        <Link href="/">Back to Login</Link>
      </div>
    );
  }

  return (
    <div className="relative flex w-full h-screen flex-col items-center justify-center bg-white p-0 bg-no-repeat bg-center">
      <div className="absolute top-5 left-5">
        <div className="text-[22px] font-medium text-[var(--text-primary)] flex flex-row gap-1">
          Echo
          <div className="w-[30px] h-[30px] bg-[var(--text-primary)] rounded-[3px] flex items-center justify-center font-semibold text-[22px] text-white">
            AI
          </div>
        </div>
      </div>
      <div>Processing SSO login...</div>
    </div>
  );
}

export default function CallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="relative flex w-full h-screen flex-col items-center justify-center bg-white">
          <div>Processing SSO login...</div>
        </div>
      }
    >
      <SSOCallbackContent />
    </Suspense>
  );
}
