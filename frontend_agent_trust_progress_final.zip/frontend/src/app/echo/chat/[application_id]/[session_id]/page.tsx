"use client";

import { Icon } from "@/components/common/Icons";
import MissingContextCard from "@/components/common/MissingContextCard";
import Composer from "@/features/chat/components/Composer";
import { CustomRenderers } from "@/features/chat/components/CustomRenders";
import ProgressSteps from "@/features/chat/components/ProgressSteps";
import { useAppSelection } from "@/hooks/useAppSelection";
import { useEchoChat } from "@/hooks/useEchoChat";
import { formatSize } from "@/lib/utils";
import { MessageAttachment, PendingUploadFile } from "@/types";
import { escapeCurrencyDollars } from "@/utils/markdown-currency.utils";
import { useParams, usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeKatex from "rehype-katex";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";

const TOKEN_LIMIT_PHRASE = "daily token allocation exhausted";

function isTokenLimitMessage(content: string): boolean {
  return content.toLowerCase().includes(TOKEN_LIMIT_PHRASE);
}

function CopyButton({ content }: { content: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard not available
    }
  };
  return (
    <button
      className="msg-copy-btn"
      onClick={copy}
      title="Copy message"
      aria-label="Copy message"
    >
      {copied ? (
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="20 6 9 17 4 12" />
        </svg>
      ) : (
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
        </svg>
      )}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

export default function Page() {
  const path = usePathname();
  const params = useParams();
  const application_id = params.application_id as string;
  const session_id = params.session_id as string;

  const { selectedApp, selectApp } = useAppSelection(path);

  const endRef = useRef<HTMLDivElement>(null);
  const icon = "sparkle";

  const chat = useEchoChat();

  useEffect(() => {
    if (application_id && session_id) {
      selectApp(null, application_id);
      chat.setSessionId(session_id);
      chat.fetchHistory(application_id, session_id);
    }
  }, [session_id, application_id]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [
    chat.messages,
    chat.streamingText,
    chat.steps,
    chat.surfaceVisible,
    chat.isFileUploading,
  ]);

  return (
    <>
      <div className="stream">
        <section className="thread">
          {/* {chat.sessionDocuments.length > 0 && (
            <section
              className="upload-history-panel"
              aria-label="Session attachments"
            >
              <div className="upload-history-head">
                <span>Session Attachments</span>
                <span>{chat.sessionDocuments.length}</span>
              </div>
              <div className="upload-history-list">
                {chat.sessionDocuments.map((doc) => {
                  const status = (
                    doc.processing_status || "unknown"
                  ).toLowerCase();
                  return (
                    <div className="upload-history-row" key={doc.document_id}>
                      <div className="upload-history-meta">
                        <span
                          className="upload-history-name"
                          title={doc.original_filename}
                        >
                          {doc.original_filename}
                        </span>
                        <span className="upload-history-detail">
                          {formatSize(doc.size_bytes)}
                          {status === "ready" &&
                            typeof doc.chunk_count === "number" && (
                              <span className="upload-history-chunks">
                                {doc.chunk_count === 0
                                  ? "No passages extracted"
                                  : `, ${doc.chunk_count} passage${doc.chunk_count === 1 ? "" : "s"} extracted`}
                              </span>
                            )}
                        </span>
                      </div>
                      <span
                        className={`upload-history-status upload-status-${status}`}
                      >
                        {status}
                      </span>
                    </div>
                  );
                })}
              </div>
            </section>
          )} */}
          {chat.messages.map((m, i) => {
            if (m.role === "user") {
              const doc: any =
                m.execution_trace?.type === "file_upload_event"
                  ? m.execution_trace?.file_upload
                  : null;

              const sessionDoc = chat.sessionDocuments.find(
                (d) => d.document_id === doc?.document_id,
              );

              const status =
                sessionDoc?.processing_status ?? doc?.processing_status ?? null;

              console.log("status:", status);
              // const doc: any =
              //   m.execution_trace?.type === "file_upload_event"
              //     ? m.execution_trace?.file_upload
              //     : null;
              // const status = doc ? doc.processing_status : null;
              // console.log(
              //   "status: ",
              //   chat.sessionDocuments.filter(
              //     (d) => d.document_id === doc?.document_id,
              //   ),
              // );
              return (
                <div className="msg user msg-new" key={i}>
                  {!doc ? (
                    <div className="bubble">
                      {/* {m.attachments && m.attachments.length > 0 && (
                        <MessageAttachmentCards attachments={m.attachments} />
                      )} */}
                      {m.content}
                      {/* <div className="msg-actions">
                        <CopyButton content={m.content} />
                      </div> */}
                    </div>
                  ) : (
                    <div className="upload-history-row" key={doc?.document_id}>
                      <div className="upload-history-meta">
                        <span
                          className="upload-history-name"
                          title={doc.filename}
                        >
                          {doc.filename}
                        </span>
                        <span className="upload-history-detail">
                          {formatSize(doc.size_bytes)}
                          {status === "ready" &&
                            typeof doc.chunk_count === "number" && (
                              <span className="upload-history-chunks">
                                {doc.chunk_count === 0
                                  ? "No passages extracted"
                                  : `, ${doc.chunk_count} passage${doc.chunk_count === 1 ? "" : "s"} extracted`}
                              </span>
                            )}
                        </span>
                      </div>
                      <span
                        className={`upload-history-status upload-status-${status}`}
                      >
                        {status}
                      </span>
                    </div>
                  )}
                </div>
              );
            }
            const trace = m.execution_trace || {};
            const isClarification =
              trace?.type === "clarification" ||
              trace?.conversation_state === "awaiting_clarification";
            const missingContext = trace?.missing_context;
            const isTokenLimit = isTokenLimitMessage(m.content);
            return (
              <div
                className={`msg agent msg-new${isTokenLimit ? " msg-token-limit" : ""}`}
                key={i}
              >
                <span className="av">
                  <Icon name={icon} size={17} />
                </span>
                <div
                  className={`bubble${isTokenLimit ? " bubble-token-limit" : ""}`}
                >
                  {isClarification && (
                    <span className="clar-pill">Needs clarification</span>
                  )}
                  {isTokenLimit ? (
                    <div className="token-limit-msg">
                      <strong>Daily Token Limit Exhausted</strong>
                      <span>
                        {" "}
                        AI usage limit reached for today. Your usage allocation
                        will refresh automatically at the start of the next day.
                      </span>
                    </div>
                  ) : missingContext ? (
                    <div className="mc-card">
                      <MissingContextCard
                        data={missingContext}
                        canUpload={selectedApp?.upload_enabled}
                      />
                    </div>
                  ) : (
                    <ReactMarkdown
                      children={escapeCurrencyDollars(m.content)}
                      remarkPlugins={[remarkGfm, remarkMath]}
                      rehypePlugins={[rehypeKatex]}
                      components={{
                        ...CustomRenderers,
                      }}
                    />
                  )}
                  {!isTokenLimit && <TraceExtras trace={trace} />}
                  <div className="msg-actions">
                    <CopyButton content={m.content} />
                  </div>
                </div>
              </div>
            );
          })}
          {chat.surfaceVisible && <ProgressSteps steps={chat.steps} />}
          {chat.isStreaming && chat.streamingText && (
            <div className="msg agent msg-streaming">
              <span className="av">
                <Icon name={icon} size={17} />
              </span>
              <div className="bubble">
                <ReactMarkdown
                  children={escapeCurrencyDollars(chat.streamingText)}
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={{
                    ...CustomRenderers,
                  }}
                />
              </div>
            </div>
          )}
          {chat.isStreaming &&
            !chat.surfaceVisible &&
            !chat.streamingText &&
            !chat.surfaceVisible && (
              <div className="msg agent msg-streaming">
                <span className="av">
                  <Icon name={icon} size={17} />
                </span>
                <div className="bubble">
                  <span className="typing">
                    <i />
                    <i />
                    <i />
                  </span>
                </div>
              </div>
            )}
          {chat.isFileUploading && (
            <UploadProgressBubble files={chat.pendingUploadFiles} />
          )}

          <div ref={endRef} />
        </section>
      </div>
      <div className="dock">
        <div className="inner">
          <Composer selectedApp={selectedApp} disabled={chat.isStreaming} />
        </div>
      </div>
    </>
  );
}

function UploadProgressBubble({ files }: { files: PendingUploadFile[] }) {
  return (
    <div
      className="upload-progress-bubble"
      aria-live="polite"
      aria-label="Uploading files"
    >
      <div className="upload-progress-head">
        {/* Animated spinner */}
        <span className="upload-progress-spinner" aria-hidden="true" />
        <span className="upload-progress-label">
          Uploading {files.length === 1 ? "file" : `${files.length} files`}…
        </span>
      </div>

      {files.length > 0 && (
        <div className="upload-progress-list">
          {files.map((f, i) => (
            <div className="upload-progress-row" key={i}>
              {/* File type icon */}
              <span className="upload-progress-file-icon" aria-hidden="true">
                <FileTypeIcon name={f.name} />
              </span>
              <div className="upload-progress-file-meta">
                <span className="upload-progress-file-name" title={f.name}>
                  {f.name}
                </span>
                <span className="upload-progress-file-size">
                  {formatSize(f.size)}
                </span>
              </div>
              {/* Indeterminate bar */}
              {/* <span className="upload-progress-bar-wrap" aria-hidden="true">
                <span className="upload-progress-bar-track">
                  <span className="upload-progress-bar-fill" />
                </span>
              </span> */}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MessageAttachmentCards({
  attachments,
}: {
  attachments: MessageAttachment[];
}) {
  return (
    <div className="msg-attachments">
      {attachments.map((a) => (
        <div className="msg-attachment-card" key={a.document_id}>
          <span className="msg-attachment-icon" aria-hidden="true">
            <FileTypeIcon name={a.original_filename} />
          </span>
          <div className="msg-attachment-meta">
            <span className="msg-attachment-name" title={a.original_filename}>
              {a.original_filename}
            </span>
            {a.size_bytes != null && (
              <span className="msg-attachment-size">
                {formatSize(a.size_bytes)}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function FileTypeIcon({ name }: { name: string }) {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";

  // PDF → red
  if (ext === "pdf") {
    return (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect
          x="3"
          y="1"
          width="14"
          height="18"
          rx="2"
          fill="#fee2e2"
          stroke="#f87171"
          strokeWidth="1.4"
        />
        <rect x="13" y="1" width="4" height="4" rx="1" fill="#fca5a5" />
        <path d="M13 1 L17 5" stroke="#f87171" strokeWidth="1.2" />
        <text
          x="5"
          y="15"
          fontSize="5.5"
          fontWeight="700"
          fill="#dc2626"
          fontFamily="sans-serif"
        >
          PDF
        </text>
      </svg>
    );
  }

  // Excel / CSV → green
  if (["xlsx", "xls", "csv"].includes(ext)) {
    return (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect
          x="3"
          y="1"
          width="14"
          height="18"
          rx="2"
          fill="#dcfce7"
          stroke="#4ade80"
          strokeWidth="1.4"
        />
        <rect x="13" y="1" width="4" height="4" rx="1" fill="#86efac" />
        <path d="M13 1 L17 5" stroke="#4ade80" strokeWidth="1.2" />
        <text
          x="4"
          y="15"
          fontSize="4.5"
          fontWeight="700"
          fill="#16a34a"
          fontFamily="sans-serif"
        >
          XLS
        </text>
      </svg>
    );
  }

  // Word / Doc → blue
  if (["docx", "doc"].includes(ext)) {
    return (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect
          x="3"
          y="1"
          width="14"
          height="18"
          rx="2"
          fill="#dbeafe"
          stroke="#60a5fa"
          strokeWidth="1.4"
        />
        <rect x="13" y="1" width="4" height="4" rx="1" fill="#93c5fd" />
        <path d="M13 1 L17 5" stroke="#60a5fa" strokeWidth="1.2" />
        <text
          x="3.5"
          y="15"
          fontSize="4.5"
          fontWeight="700"
          fill="#2563eb"
          fontFamily="sans-serif"
        >
          DOC
        </text>
      </svg>
    );
  }

  // Image → purple
  if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) {
    return (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect
          x="3"
          y="1"
          width="14"
          height="18"
          rx="2"
          fill="#f3e8ff"
          stroke="#c084fc"
          strokeWidth="1.4"
        />
        <rect x="13" y="1" width="4" height="4" rx="1" fill="#d8b4fe" />
        <path d="M13 1 L17 5" stroke="#c084fc" strokeWidth="1.2" />
        <text
          x="3.5"
          y="15"
          fontSize="4.5"
          fontWeight="700"
          fill="#9333ea"
          fontFamily="sans-serif"
        >
          IMG
        </text>
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect
        x="3"
        y="1"
        width="14"
        height="18"
        rx="2"
        fill="#f1f5f9"
        stroke="#94a3b8"
        strokeWidth="1.4"
      />
      <rect x="13" y="1" width="4" height="4" rx="1" fill="#cbd5e1" />
      <path d="M13 1 L17 5" stroke="#94a3b8" strokeWidth="1.2" />
      <line
        x1="6"
        y1="10"
        x2="14"
        y2="10"
        stroke="#94a3b8"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <line
        x1="6"
        y1="13"
        x2="12"
        y2="13"
        stroke="#94a3b8"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function TraceExtras({
  trace,
}: {
  trace: Record<string, unknown> | undefined;
}) {
  if (!trace || typeof trace !== "object") return null;
  const assumptions: string[] = Array.isArray(trace?.assumptions)
    ? (trace.assumptions as string[])
    : Array.isArray(
          (trace?.clarification as Record<string, unknown>)?.assumptions,
        )
      ? ((trace.clarification as Record<string, unknown>)
          .assumptions as string[])
      : [];
  const llm = (trace?.orchestration_llm || {}) as Record<string, string>;
  const llmLabel: string =
    llm?.model_id || llm?.credential_id || llm?.source || "";
  const satisfiedBy = (trace?.evidence_gate as Record<string, unknown>)
    ?.satisfied_by;
  const sources: string[] = [];
  if (satisfiedBy && typeof satisfiedBy === "object") {
    for (const k of Object.keys(satisfiedBy as Record<string, unknown>)) {
      const v = (satisfiedBy as Record<string, string>)[k];
      if (typeof v === "string" && v) sources.push(v);
    }
  }
  if (!assumptions.length && !llmLabel && !sources.length) return null;
  return (
    <div className="trace-chips">
      {assumptions.length > 0 && (
        <span className="trace-chip">
          Proceeding on stated assumptions: {assumptions.join("; ")}
        </span>
      )}
      {sources.map((s, i) => (
        <span className="trace-chip" key={i}>
          Source: {s}
        </span>
      ))}
      {llmLabel && <span className="trace-chip">LLM: {llmLabel}</span>}
    </div>
  );
}
