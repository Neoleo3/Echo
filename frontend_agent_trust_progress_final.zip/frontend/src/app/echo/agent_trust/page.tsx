import { AgentTrust } from "@/features/agent-trust";

export default function Page() {
  return (
    <div className="stream">
      <AgentTrust />
    </div>
  );
}
