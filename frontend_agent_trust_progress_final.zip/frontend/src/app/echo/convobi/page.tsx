"use client";

import { DBIcon } from "@/components/common/Icons";
import ConvoBIChat from "@/features/convobi/components/ConvoBIChat";
import { LoadDatabase } from "@/features/convobi/components/LoadDatabase";
import SchemaDocument from "@/features/convobi/components/SchemaDocument";
import SchemaResponse from "@/features/convobi/components/SchemaResponse";
import { useToast } from "@/hooks/use-toast";
import { convoBIService } from "@/services/convobi.service";
import s from "@/styles/convobi.module.css";
import { DBList, LoadDB, loadSchema } from "@/types/convobi.types";
import { validateFile } from "@/utils/file-validation.utils";
import { Loader2, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface FileInfo {
  file: File | null;
  loading: boolean;
  id: string | null;
}

export default function Page() {
  const [loadDB, setLoadDB] = useState<LoadDB>({
    show: false,
    activeDb: null,
    list: [],
  });
  const [fileInfo, setFileInfo] = useState<FileInfo>({
    file: null,
    loading: false,
    id: null,
  });
  const [recommendedQuestions, setRecommendedQuestions] = useState<{
    show: boolean;
    loading: boolean;
    questions: string[];
  }>({
    show: false,
    loading: false,
    questions: [],
  });
  const [schema, setSchema] = useState<loadSchema>({
    document: null,
    summary: null,
    loading: false,
  });
  const [question, setQuestion] = useState<string>("");
  const [isDragOver, setIsDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();

  const fetchRecommendedQuestions = async () => {
    setRecommendedQuestions((prev) => ({
      ...prev,
      loading: true,
      show: true,
    }));
    try {
      const payload: Record<string, unknown> = { force_refresh: true };
      if (loadDB.activeDb) payload.connection_id = loadDB.activeDb.id;
      else if (fileInfo.id) payload.file_id = fileInfo.id;
      const response = await convoBIService.getRecommendedQuestions(payload);
      const d = response.data as Record<string, unknown> | null;
      if (
        response.success &&
        Array.isArray(d?.questions) &&
        (d!.questions as unknown[]).length
      ) {
        setRecommendedQuestions((prev) => ({
          ...prev,
          questions: d!.questions as string[],
          loading: false,
        }));
      }
    } catch {
      setRecommendedQuestions((prev) => ({
        ...prev,
        questions: [],
        loading: false,
      }));
    }
  };

  const FetchDataList = async () => {
    const response = await convoBIService.getDBConnectors();
    if (response.success && response?.data) {
      setLoadDB((prev) => ({
        ...prev,
        list: response?.data?.connections ?? [],
      }));
    }
  };

  const SubmitFile = async () => {
    setFileInfo((prev) => ({
      ...prev,
      loading: true,
    }));
    setRecommendedQuestions((prev) => ({
      ...prev,
      questions: [],
      show: false,
    }));
    setLoadDB((prev) => ({
      ...prev,
      activeDb: null,
    }));
    const data = new FormData();
    if (fileInfo.file) data.append("file", fileInfo.file);
    const response = await convoBIService.uploadFile(data);
    if (
      response.success &&
      (response.data as Record<string, unknown>)?.file_id
    ) {
      const fid = (response.data as Record<string, unknown>).file_id as string;
      setFileInfo((prev) => ({
        ...prev,
        loading: false,
        id: fid,
      }));
    }
    setFileInfo((prev) => ({
      ...prev,
      loading: false,
    }));
  };

  const UploadFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = event.target.files?.[0];
      if (!file) {
        console.warn(
          "[ConversationalBI] File selection issue - please try again.",
        );

        if (fileRef.current) fileRef.current.value = "";
        return;
      }

      const validationError = validateFile(file);
      if (validationError) {
        console.warn(
          `[ConversationalBI] File validation failed: "${file.name}" ${validationError}.`,
        );
        if (fileRef.current) fileRef.current.value = "";
        return;
      }

      setFileInfo((prev) => ({
        ...prev,
        file: file,
      }));
    } catch (err) {
      console.error("Error While Uploading the File", err);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const fetchSchema = async () => {
    setSchema((prev) => ({
      ...prev,
      document: null,
      summary: null,
      loading: true,
    }));
    const id = fileInfo.id ?? loadDB.activeDb?.id ?? "";
    const type = fileInfo.id ? "file" : "db";
    const [documentResponse, summaryResponse] = await Promise.all([
      convoBIService.getSchemaDoc(id, type),
      convoBIService.getSchema(id, type),
    ]);
    console.log("Schema", documentResponse, summaryResponse);
    const errormsg = !documentResponse.success
      ? documentResponse.error
      : !summaryResponse.success
        ? summaryResponse.error
        : null;

    if (errormsg)
      toast({
        title: "Error while fetching Schema",
        description: errormsg,
        variant: "destructive",
      });
    else
      setSchema((prev) => ({
        ...prev,
        summary: summaryResponse.success
          ? (summaryResponse.data ?? null)
          : null,
        document: documentResponse.success
          ? (documentResponse.data ?? null)
          : null,
        loading: false,
      }));
  };

  useEffect(() => {
    if (!loadDB.activeDb && !fileInfo.id) FetchDataList();
    else {
      fetchSchema();
      fetchRecommendedQuestions();
    }
  }, [loadDB.activeDb, fileInfo.id]);

  return (
    <div className={s.biView}>
      <div className={s.biWrap}>
        {/* ===== LEFT SIDEBAR ===== */}
        <aside className={s.biSide}>
          {/* Database Detail Section */}
          <button
            className={s.biLoad}
            onClick={() =>
              setLoadDB((prev) => ({
                ...prev,
                show: true,
              }))
            }
          >
            <DBIcon />
            {loadDB.activeDb ? "Change Database" : "Load Database"}
          </button>
          {loadDB.activeDb && (
            <div className={s.biStatRow}>
              <div>
                <span className={`${s.biLed} ${s.on}`} />
                <b>Connected</b>
              </div>
              <div>
                <DBIcon />
                {loadDB.activeDb.name}
              </div>
              <div style={{ fontSize: "11px", color: "var(--text-faint)" }}>
                {loadDB.activeDb.tables_count} tables available
              </div>
            </div>
          )}

          {/* Suggested Questions */}
          {(loadDB.activeDb || fileInfo.id) && (
            <div className={s.biBlock}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: 6,
                }}
              >
                <h4>Suggested Questions</h4>
                <button
                  className={s.biLoad}
                  style={{
                    width: "auto",
                    padding: "4px 9px",
                    fontSize: "11px",
                  }}
                  title="Refresh suggestions"
                  disabled={recommendedQuestions.loading}
                  onClick={() => fetchRecommendedQuestions()}
                >
                  {recommendedQuestions.loading ? (
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      style={{ animation: "spin 1s linear infinite" }}
                    >
                      <path d="M21 12a9 9 0 1 1-9-9" />
                    </svg>
                  ) : (
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                    >
                      <polyline points="1 4 1 10 7 10" />
                      <path d="M3.51 15a9 9 0 1 0 .49-4.5" />
                    </svg>
                  )}
                  Refresh
                </button>
                <button
                  onClick={() =>
                    setRecommendedQuestions((prev) => ({
                      ...prev,
                      show: !prev.show,
                    }))
                  }
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    style={{
                      marginLeft: "auto",
                      transform: recommendedQuestions.show
                        ? "rotate(180deg)"
                        : "none",
                      transition: "transform .2s ease",
                    }}
                  >
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </button>
              </div>
              {recommendedQuestions.show &&
                (recommendedQuestions.loading ? (
                  <p className={s.biSub}>Loading suggestions…</p>
                ) : (
                  <div
                    style={{ display: "flex", flexDirection: "column", gap: 5 }}
                  >
                    {recommendedQuestions.questions.slice(0, 5).map((q) => (
                      <button
                        key={q}
                        className={s.biLoad}
                        style={{
                          justifyContent: "flex-start",
                          textAlign: "left",
                          fontSize: "11.5px",
                          padding: "7px 10px",
                          fontWeight: 400,
                        }}
                        onClick={() => setQuestion(q)}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                ))}
            </div>
          )}

          {/* File upload */}
          <div className={s.biBlock}>
            <h4>Data Files</h4>
            <p className={s.biSub}>Upload CSV / Excel to analyse</p>
            <div
              className={`${s.biDrop}${isDragOver ? ` ${s.over}` : ""}`}
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragOver(true);
              }}
              onDragEnter={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragOver(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setIsDragOver(false);
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragOver(false);
                const droppedFile = e.dataTransfer.files?.[0];
                if (!droppedFile) return;
                const validationError = validateFile(droppedFile);
                if (validationError) {
                  console.warn(
                    `[ConversationalBI] Drop validation failed: "${droppedFile.name}" ${validationError}.`,
                  );
                  return;
                }
                setFileInfo((prev) => ({
                  ...prev,
                  file: droppedFile,
                }));
              }}
              onClick={() => fileRef.current?.click()}
            >
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{
                  color: "var(--text-faint)",
                  margin: "0 auto 4px",
                  display: "block",
                }}
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
              <p>Drop files here</p>
              <span>CSV, XLSX — max 50 MB</span>
            </div>
            <button
              className={s.biUpload}
              onClick={() => SubmitFile()}
              disabled={!fileInfo.file || fileInfo.loading}
              style={{
                opacity: !fileInfo.file || fileInfo.loading ? 0.5 : 1,
                cursor:
                  !fileInfo.file || fileInfo.loading
                    ? "not-allowed"
                    : "pointer",
              }}
            >
              {fileInfo.loading ? (
                <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" />
              ) : (
                <Upload className="w-3 h-3 mr-1" />
              )}

              {fileInfo.loading ? "Uploading File" : "Upload File"}
            </button>

            <input
              ref={fileRef}
              id="file-upload"
              type="file"
              accept=".csv,.xlsx"
              className="hidden"
              onChange={UploadFile}
            />

            {fileInfo.file && fileInfo.file.name && (
              <ul className={s.biFiles}>
                <li>
                  <svg
                    width="13"
                    height="13"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  {fileInfo.file.name}

                  {fileInfo.loading && (
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      style={{
                        animation: "spin 1s linear infinite",
                        marginLeft: "auto",
                        flexShrink: 0,
                      }}
                    >
                      <path d="M21 12a9 9 0 1 1-9-9" />
                    </svg>
                  )}
                  {!fileInfo.loading && (
                    <button
                      title="delete"
                      onClick={() => {
                        if (fileRef.current) fileRef.current.value = "";
                        setFileInfo((prev) => ({
                          ...prev,
                          file: null,
                          id: null,
                        }));
                        setSchema((prev) => ({
                          ...prev,
                          summary: null,
                          document: null,
                        }));
                      }}
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      >
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                        <path d="M10 11v6" />
                        <path d="M14 11v6" />
                        <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                      </svg>
                    </button>
                  )}
                </li>
              </ul>
            )}
          </div>
        </aside>

        {/* ===== MAIN PANEL ===== */}
        <div className={s.biMain}>
          {/* Title */}
          <div className={s.biTitle}>
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="20" x2="18" y2="10" />
              <line x1="12" y1="20" x2="12" y2="4" />
              <line x1="6" y1="20" x2="6" y2="14" />
            </svg>
            Conversational BI
          </div>

          <div className="pt-2 pb-5 px-5 gap-4 flex flex-col w-full">
            {/* Schema loading indicator shown before data arrives */}
            {schema.loading && !schema.summary && !schema.document && (
              <div className={s.biLoadingBanner}>
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  style={{
                    animation: "spin 1s linear infinite",
                    flexShrink: 0,
                  }}
                >
                  <path d="M21 12a9 9 0 1 1-9-9" />
                </svg>
                Loading schema — this may take a moment…
              </div>
            )}

            {(schema.summary || schema.loading) && (
              <SchemaResponse
                schemaResponse={schema.summary}
                loading={schema.loading}
              />
            )}
            {(schema.document || schema.loading) && (
              <SchemaDocument
                schemaDocument={schema.document}
                connector_id={loadDB.activeDb ? loadDB.activeDb.id : ""}
                file_id={fileInfo.id ?? null}
                loading={schema.loading}
              />
            )}

            <ConvoBIChat
              activeDb={loadDB.activeDb}
              question={question}
              setQuestion={(value) => setQuestion(value)}
              sampleQuestions={recommendedQuestions.questions}
              connector_id={
                loadDB.activeDb ? loadDB.activeDb.id : (fileInfo.id ?? "")
              }
              file_id={fileInfo.id ? true : false}
            />
          </div>
        </div>
      </div>

      {/* ===== DB PICKER MODAL ===== */}
      {loadDB.show && (
        <LoadDatabase
          activeDb={loadDB.activeDb}
          list={loadDB.list}
          onClose={() =>
            setLoadDB((prev) => ({
              ...prev,
              show: false,
            }))
          }
          onSelect={(db: DBList) => {
            setLoadDB((prev) => ({
              ...prev,
              activeDb: db,
              show: false,
            }));
            setFileInfo((prev) => ({
              ...prev,
              file: null,
              id: null,
            }));
          }}
        />
      )}
    </div>
  );
}
