import Monitoring from "@/features/monitoring/components/Monitoring";

export default function Page() {
  return (
    <div className="stream">
      <Monitoring />
    </div>
  );
}
