import { FileText, ShieldCheck } from "lucide-react";

export default function Page() {
  return (
    <div className="w-full px-6 py-4" style={{ overflowY: "auto" }}>
      {/* Hero */}
      <div
        className="
          bg-[var(--surface)]
          border border-[var(--line)]
          rounded-2xl
          shadow-sm
          p-6
          mb-6
          flex gap-4
        "
      >
        <div
          className="
            w-12 h-12
            rounded-xl
            bg-[var(--surface-2)]
            flex items-center justify-center
            text-[var(--text-soft)]
            shrink-0
          "
        >
          <FileText className="w-6 h-6" />
        </div>

        <div>
          <h1 className="text-2xl font-bold text-[var(--text)]">
            Documentation Center
          </h1>

          <p className="mt-2 text-sm text-[var(--text-soft)]">
            Access privacy guidelines and standard operating procedures for the
            platform.
          </p>
        </div>
      </div>

      {/* Documents */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 min-h-[90vh]">
        {/* Privacy */}
        <div
          className="
            bg-[var(--surface)]
            border border-[var(--line)]
            rounded-2xl
            overflow-hidden
            shadow-sm
            hover:shadow-lg
            transition-all
          "
        >
          <div
            className="
              flex items-center justify-between
              px-5 py-4
              border-b border-[var(--line)]
              bg-[var(--surface-2)]
            "
          >
            <div>
              <h2 className="font-semibold text-[var(--text)]">
                Privacy Document
              </h2>

              <p className="text-xs text-[var(--text-faint)] mt-1">
                Privacy policies and governance guidelines
              </p>
            </div>

            <div
              className="
                w-10 h-10
                rounded-xl
                bg-[var(--surface)]
                border border-[var(--line)]
                flex items-center justify-center
              "
            >
              <ShieldCheck className="w-5 h-5 text-[var(--accent)]" />
            </div>
          </div>

          <iframe
            src="/Privacy.pdf"
            className="w-full h-[100vh]"
            style={{ border: "none" }}
          />
        </div>

        {/* SOP */}
        <div
          className="
            bg-[var(--surface)]
            border border-[var(--line)]
            rounded-2xl
            overflow-hidden
            shadow-sm
            hover:shadow-lg
            transition-all
          "
        >
          <div
            className="
              flex items-center justify-between
              px-5 py-4
              border-b border-[var(--line)]
              bg-[var(--surface-2)]
            "
          >
            <div>
              <h2 className="font-semibold text-[var(--text)]">SOP Document</h2>

              <p className="text-xs text-[var(--text-faint)] mt-1">
                Standard operating procedures and usage instructions
              </p>
            </div>

            <div
              className="
                w-10 h-10
                rounded-xl
                bg-[var(--surface)]
                border border-[var(--line)]
                flex items-center justify-center
              "
            >
              <FileText className="w-5 h-5 text-[var(--accent)]" />
            </div>
          </div>

          <iframe
            src="/SOP_v2.pdf"
            className="w-full h-[100vh]"
            style={{ border: "none" }}
          />
        </div>
      </div>
    </div>
  );
}
