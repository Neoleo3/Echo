"use client";

import { Headset, Users, Mail } from "lucide-react";

const supportData = [
  {
    level: "L1 Support",
    tone: "blue",
    members: [
      { name: "Sathya", email: "sathyajitga@kpmg.com" },
      { name: "Sagar", email: "sagarhegde@kpmg.com" },
      { name: "Ashna", email: "ashnamuthappa@kpmg.com" },
    ],
  },
  {
    level: "L2 Support",
    tone: "violet",
    members: [
      { name: "Vanshika", email: "vanshikamahajan@kpmg.com" },
      { name: "Shashank", email: "shashanksingh12@kpmg.com" },
    ],
  },
  {
    level: "L3 Support",
    tone: "amber",
    members: [
      { name: "Neha", email: "nehabehl@kpmg.com" },
      { name: "Shreyan", email: "shreyanf@kpmg.com" },
    ],
  },
];

const TONE_STYLES: Record<
  string,
  { wash: string; text: string; ring: string }
> = {
  blue: {
    wash: "bg-[color-mix(in_srgb,var(--accent)_14%,transparent)]",
    text: "text-[var(--accent)]",
    ring: "ring-[var(--accent)]",
  },
  violet: {
    wash: "bg-[color-mix(in_srgb,var(--violet,#7c3aed)_14%,transparent)]",
    text: "text-[var(--violet,#7c3aed)]",
    ring: "ring-[var(--violet,#7c3aed)]",
  },
  amber: {
    wash: "bg-[color-mix(in_srgb,var(--warning,#d97706)_14%,transparent)]",
    text: "text-[var(--warning,#d97706)]",
    ring: "ring-[var(--warning,#d97706)]",
  },
};

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default function SupportPage() {
  return (
    <div
      className="p-8"
      style={{ background: "var(--bg, var(--surface-2))", minHeight: "100%" }}
    >
      {/* Hero */}
      <div
        style={{
          background: "var(--surface)",
          border: "1px solid var(--line)",
          borderRadius: 18,
          boxShadow: "var(--shadow)",
          padding: "24px",
          marginBottom: 24,
          display: "flex",
          gap: 16,
        }}
      >
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: 14,
            background: "var(--surface-2)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--text-soft)",
            flexShrink: 0,
          }}
        >
          <Headset size={24} />
        </div>
        <div>
          <h1
            style={{
              margin: 0,
              fontSize: 22,
              fontWeight: 700,
              color: "var(--text)",
            }}
          >
            Support Contacts
          </h1>
          <p
            style={{
              margin: "6px 0 0",
              fontSize: 13.5,
              color: "var(--text-soft)",
              lineHeight: 1.55,
            }}
          >
            Reach out to the right tier for help — escalate from L1 through L3
            as needed.
          </p>
        </div>
      </div>

      {/* Tier cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 16,
        }}
      >
        {supportData.map((group, index) => {
          const tone = TONE_STYLES[group.tone] || TONE_STYLES.blue;
          return (
            <div
              key={index}
              style={{
                background: "var(--surface)",
                border: "1px solid var(--line)",
                borderRadius: 16,
                overflow: "hidden",
                boxShadow: "var(--shadow)",
              }}
            >
              {/* Card header */}
              <div
                style={{
                  padding: "12px 16px",
                  background: "var(--surface-2)",
                  borderBottom: "1px solid var(--line)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <div>
                  <h2
                    style={{
                      margin: 0,
                      fontSize: 15,
                      fontWeight: 700,
                      color: "var(--text)",
                    }}
                  >
                    {group.level}
                  </h2>
                  <p
                    style={{
                      margin: "2px 0 0",
                      fontSize: 11.5,
                      color: "var(--text-faint)",
                    }}
                  >
                    {group.members.length} member
                    {group.members.length !== 1 ? "s" : ""}
                  </p>
                </div>
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${tone.wash} ${tone.text}`}
                >
                  <Users size={16} />
                </div>
              </div>

              {/* Members list */}
              <div
                style={{
                  padding: "12px 16px",
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                }}
              >
                {group.members.map((member, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      padding: "7px 10px",
                      borderRadius: 10,
                      transition: "background 0.12s",
                    }}
                    className="hover:bg-[var(--surface-2)]"
                  >
                    {/* Avatar */}
                    <div
                      className={`${tone.wash} ${tone.text}`}
                      style={{
                        width: 34,
                        height: 34,
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                        fontSize: 12,
                        fontWeight: 700,
                      }}
                    >
                      {initials(member.name)}
                    </div>

                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div
                        style={{
                          fontSize: 13.5,
                          fontWeight: 600,
                          color: "var(--text)",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {member.name}
                      </div>
                      <a
                        href={`mailto:${member.email}`}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 4,
                          fontSize: 12,
                          color: "var(--text-soft)",
                          textDecoration: "none",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                        onMouseEnter={(e) =>
                          ((e.currentTarget as HTMLAnchorElement).style.color =
                            "var(--accent)")
                        }
                        onMouseLeave={(e) =>
                          ((e.currentTarget as HTMLAnchorElement).style.color =
                            "var(--text-soft)")
                        }
                      >
                        <Mail size={12} style={{ flexShrink: 0 }} />
                        <span
                          style={{
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                        >
                          {member.email}
                        </span>
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
