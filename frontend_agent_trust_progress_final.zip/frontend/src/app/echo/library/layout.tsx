"use client";

import type React from "react";
import "../echo.css";

export default function Layout({ children }: { children: React.ReactNode }) {
  return <div className="stream">{children}</div>;
}
