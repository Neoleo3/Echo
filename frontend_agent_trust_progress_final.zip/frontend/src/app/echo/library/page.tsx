"use client";

import { ROUTES } from "@/config";
import { useAppSelection } from "@/hooks/useAppSelection";
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/navigation";
import { useState } from "react";
import "@/styles/chat.css";

export default function Page() {
  const router = useRouter();
  const { user } = useAuth();
  const { applications, selectApp } = useAppSelection(ROUTES.LIBRARY);
  const [libSearch, setLibSearch] = useState<string>("");

  const libQuery = libSearch.trim().toLowerCase();
  const filteredApps = libQuery
    ? applications.filter(
        (a) =>
          (a.name ?? "").toLowerCase().includes(libQuery) ||
          (a.description ?? "").toLowerCase().includes(libQuery),
      )
    : applications;
  return (
    <section className="library">
      <div className="libWelcome">
        <div className="wcIc">
          <svg width="22" height="22" viewBox="0 0 256 256" fill="currentColor">
            <path d="M231.65,194.55,198.46,36.75a16,16,0,0,0-19-12.39L132.65,34.42a16.08,16.08,0,0,0-12.3,19l33.19,157.8A16,16,0,0,0,169.16,224a16.25,16.25,0,0,0,3.38-.36l46.81-10.06A16.09,16.09,0,0,0,231.65,194.55ZM136,50.15l46.8-10,3.33,15.87L139.33,66Zm6.62,31.47,46.82-10.05,3.34,15.9L146,97.53Zm6.64,31.57,46.82-10.06,13.3,63.24-46.82,10.06ZM216,197.94l-46.8,10-3.33-15.87L212.67,182ZM104,32H56A16,16,0,0,0,40,48V208a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V48A16,16,0,0,0,104,32ZM56,48h48V64H56Zm0,32h48v96H56Zm48,128H56V192h48v16Z" />
          </svg>
        </div>
        <div>
          <h1>Welcome to your Library, {user?.display_name}</h1>
          <p>
            Every AI app you&apos;re cleared to use, in one place. Each is a
            ready-made assistant built for a single job — open one and just say
            what you need in plain English.
          </p>
          <div className="libLegend">
            <span>
              <span className="k">
                <svg
                  viewBox="0 0 256 256"
                  fill="currentColor"
                  aria-hidden="true"
                  width="14"
                  height="14"
                >
                  <path d="M232.07,186.76a80,80,0,0,0-62.5-114.17A80,80,0,1,0,23.93,138.76l-7.27,24.71a16,16,0,0,0,19.87,19.87l24.71-7.27a80.39,80.39,0,0,0,25.18,7.35,80,80,0,0,0,108.34,40.65l24.71,7.27a16,16,0,0,0,19.87-19.86ZM62,159.5a8.28,8.28,0,0,0-2.26.32L32,168l8.17-27.76a8,8,0,0,0-.63-6,64,64,0,1,1,26.26,26.26A8,8,0,0,0,62,159.5Z" />
                </svg>
              </span>{" "}
              Copilot — chat with it like a messaging app
            </span>
            <span>
              <span className="k">
                <svg
                  viewBox="0 0 256 256"
                  fill="currentColor"
                  aria-hidden="true"
                  width="14"
                  height="14"
                >
                  <path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,160H40V56H216V200ZM80,84A12,12,0,1,1,68,72,12,12,0,0,1,80,84Zm40,0a12,12,0,1,1-12-12A12,12,0,0,1,120,84Z" />
                </svg>
              </span>{" "}
              Web app — a full page with forms, tables &amp; charts
            </span>
            <span>
              <span className="k">
                <svg
                  viewBox="0 0 256 256"
                  fill="currentColor"
                  aria-hidden="true"
                  width="14"
                  height="14"
                >
                  <path d="M229.66,58.34l-32-32a8,8,0,0,0-11.32,0l-96,96A8,8,0,0,0,88,128v32a8,8,0,0,0,8,8h32a8,8,0,0,0,5.66-2.34l96-96A8,8,0,0,0,229.66,58.34ZM124.69,152H104V131.31l64-64L188.69,88ZM200,76.69,179.31,56,192,43.31,212.69,64Z" />
                </svg>
              </span>{" "}
              Note — a private reminder only you can see
            </span>
          </div>
        </div>
      </div>

      <div className="libSec">
        {/* Header row: title + count + search */}
        <div className="libSecHeader">
          <h2 className="libSecTitle">
            Applications{" "}
            <span className="cnt">
              {filteredApps.length}
              {libQuery ? ` of ${applications.length}` : ""}
            </span>
          </h2>
          <div className="libSearchWrap">
            <span className="libSearchIc">
              <svg
                width="15"
                height="15"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </span>
            <input
              className="libSearchInput"
              type="text"
              placeholder="Search applications…"
              value={libSearch}
              onChange={(e) => setLibSearch(e.target.value)}
              autoComplete="off"
              aria-label="Search applications"
            />
            {libSearch && (
              <button
                type="button"
                style={{
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  color: "var(--text-faint)",
                  display: "grid",
                  placeItems: "center",
                  padding: 0,
                }}
                onClick={() => setLibSearch("")}
                aria-label="Clear search"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {applications.length === 0 && (
          <p className="emptyNote">No applications are available to you yet.</p>
        )}

        <div className="cards">
          {filteredApps.length === 0 && applications.length > 0 && (
            <div className="libEmpty">
              No applications match &ldquo;{libSearch}&rdquo;.
            </div>
          )}
          {filteredApps.map((application, ind) => (
            <div
              key={application.application_id ?? `${application?.name}-${ind}`}
              className="card"
              role="button"
              tabIndex={0}
              aria-label={`Open ${application.name}`}
              onClick={() =>
                selectApp(application, null, () =>
                  router.push(`${ROUTES.HOME}/${application.application_id}`),
                )
              }
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ")
                  selectApp(application, null, () =>
                    router.push(`${ROUTES.HOME}/${application.application_id}`),
                  );
              }}
            >
              {/* Quick-launch — stops propagation so it doesn't double-fire */}
              <button
                className="openInNewTab"
                title="Open in chat"
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  selectApp(application, null, () =>
                    router.push(`${ROUTES.HOME}/${application.application_id}`),
                  );
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M14 3h7v7" />
                  <path d="M10 14L21 3" />
                  <path d="M21 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                </svg>
              </button>

              <div className="cardTop">
                <div className="g">
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                  </svg>
                </div>
                <div>
                  <h3>{application.name}</h3>
                </div>
              </div>

              <p className="desc">{application.description}</p>

              <div className="cardFoot">
                <span className="owner">
                  LLM: {application.llm_count ?? "0"}
                </span>
                <span className="owner">
                  Skills: {application.skill_count ?? "0"}
                </span>
                <span className="owner">
                  Data: {application.data_source_count ?? "0"}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
