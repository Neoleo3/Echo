"use client";

import LoadingComponent from "@/components/common/LoadingComponent";
import { ROUTES } from "@/config";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Page() {
  const router = useRouter();

  useEffect(() => {
    router.push(ROUTES.HOME);
  }, [router]);

  return <LoadingComponent />;
}
