"use client";

import type React from "react";
import AuthCheck from "@/helpers/AuthCheck";
import { useTheme } from "@/hooks/theme.hook";
import { Suspense, useState } from "react";
import Sidebar from "@/features/layout/components/Sidebar";
import Navbar from "@/features/layout/components/Navbar";
import "./echo.css";

export default function EchoLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // ── Layout state ──────────────────────────────────────────────────────────
  const [collapsed, setCollapsed] = useState(false);
  const { theme } = useTheme();

  const HandleToggle = () => {
    setCollapsed(!collapsed);
  };

  return (
    <AuthCheck>
      <div
        className={`echo-root mode-${collapsed ? " nav-collapsed" : ""}`}
        data-theme={theme}
      >
        <div className="shell">
          <Sidebar />
          <div className="content">
            <Navbar HandleToggle={HandleToggle} />
            <Suspense>{children}</Suspense>
          </div>
        </div>
      </div>
    </AuthCheck>
  );
}
