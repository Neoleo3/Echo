"use client";

import { ConnectorList } from "@/features/connectors";
import s from "@/styles/config.module.css";

export default function Page() {
  return (
    <>
      {" "}
      <div className={s.cfgDetailHead}>
        <div className={s.cfgIc}>
          <svg
            width="26"
            height="26"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0zM12 17v5" />
          </svg>
        </div>
        <div>
          <h2>Connectors</h2>
          <p>APIs, databases and MCP servers connected to your workspace</p>
        </div>
      </div>
      <ConnectorList />
    </>
  );
}
