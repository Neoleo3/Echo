"use client";

import type React from "react";
import style from "@/styles/config.module.css";
import { usePathname, useRouter } from "next/navigation";
import { ROUTES } from "@/config";

export default function EchoLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const path = usePathname();
  const renderBack = (label: string) => (
    <button
      className={style.cfgBack}
      onClick={() => router.push(ROUTES.CONFIG)}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <polyline points="15 18 9 12 15 6" />
      </svg>
      {label}
    </button>
  );

  return (
    <div className={style.configView}>
      {!path.endsWith(ROUTES.CONFIG) &&
        !path.endsWith(ROUTES.APPLICATION) &&
        renderBack("Back to Configuration")}{" "}
      {children}
    </div>
  );
}
