"use client";

import { AgentBuilder, AgentList } from "@/features/agents";
import s from "@/styles/config.module.css";
import { AgentDefinition } from "@/types/agents.types";
import { useState } from "react";

export default function Page() {
  const [agentView, setAgentView] = useState<"grid" | "list">("grid");
  const [agentSearch, setAgentSearch] = useState("");
  const [showAgentBuilder, setShowAgentBuilder] = useState(false);
  const [editingAgent, setEditingAgent] = useState<AgentDefinition | null>(
    null,
  );
  const [agentsRefreshKey, setAgentsRefreshKey] = useState(0);

  return (
    <>
      <div className="flex flex-wrap justify-between items-center">
        <div className={s.cfgDetailHead}>
          <div className={s.cfgIc}>
            <svg
              width="26"
              height="26"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="8" r="4" />
              <path d="M20 21a8 8 0 1 0-16 0" />
            </svg>
          </div>
          <div>
            <h2>Agents</h2>
            <p>Configure AI agents available in this workspace</p>
          </div>
        </div>

        <div className={s.kbSeg}>
          <button
            className={agentView === "grid" ? s.kbSegActive : ""}
            onClick={() => setAgentView("grid")}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
            </svg>
          </button>

          <button
            className={agentView === "list" ? s.kbSegActive : ""}
            onClick={() => setAgentView("list")}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      <AgentList
        onCreate={() => {
          setEditingAgent(null);
          setShowAgentBuilder(true);
        }}
        onEdit={(agent) => {
          setEditingAgent(agent);
          setShowAgentBuilder(true);
        }}
        type={agentView}
        refreshKey={agentsRefreshKey}
        searchValue={agentSearch}
        onSearchChange={setAgentSearch}
      />

      {showAgentBuilder && (
        <div className={s.overlay} onClick={() => setShowAgentBuilder(false)}>
          <div
            className={s.agBuilderDialog}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={s.dialogHead}>
              <h3>{editingAgent ? "Configure Agent" : "Create Agent"}</h3>
              <button
                className={s.dialogClose}
                onClick={() => setShowAgentBuilder(false)}
                aria-label="Close"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <div className={s.agBuilderBody}>
              <AgentBuilder
                agent={editingAgent}
                onClose={() => setShowAgentBuilder(false)}
                onSaved={() => setAgentsRefreshKey((k) => k + 1)}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
