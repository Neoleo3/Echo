"use client";
import { AUTH_ROLES } from "@/config";
import { useAuth } from "@/hooks/useAuth";
import s from "@/styles/config.module.css";
import { LLMModel } from "@/types";
import { useCallback, useRef, useState } from "react";
import {
  DEFAULT_PROVIDER,
  LlmMode,
} from "@/features/llm-config/components/llmFormConfig";
import { useLLMs } from "@/hooks/useLLMs";
import { LlmRowMenu } from "@/features/llm-config/components/LlmRowMenu";
import { LlmFormDialog } from "@/features/llm-config/components/LlmFormDialog";
import { MultiDropdown } from "@/components/common/MultiDropdown";

const PROVIDER_LABELS: Record<string, string> = {
  azure: "Azure OpenAI",
  openai: "OpenAI",
  anthropic: "Anthropic",
  gemini: "Google Gemini",
  ollama: "Ollama (On-Prem)",
};

const providers_list: { id: string; name: string }[] = [
  { id: "all", name: "All Providers" },
  { id: "azure", name: "Azure" },
  { id: "openai", name: "OpenAI" },
  { id: "anthropic", name: "Anthropic" },
  { id: "gemini", name: "Gemini" },
  { id: "ollama", name: "Ollama" },
];

export default function Page() {
  const {
    llmsData: models,
    providers: llmProviders,
    loading: llmLoading,
    submitting: llmSubmitting,
    error: llmError,
    setError: setLlmError,
    form: llmForm,
    updateField: updateLlmField,
    patchForm: patchLlmForm,
    resetForm: resetLlmForm,
    populateForEdit: populateLlmForEdit,
    addModel: addLlmModel,
    editModel: editLlmModel,
    deleteModel: deleteLlmModel,
    setDefaultModel: setDefaultLlmModel,
    setDefaultEmbeddingModel,
    testConnection: testLlmConnection,
    getLLMs,
  } = useLLMs();
  const { user } = useAuth();
  const [llmView, setLlmView] = useState<"grid" | "list">("grid");
  const [llmSearch, setLlmSearch] = useState("");
  const [llmProviderFilter, setLlmProviderFilter] = useState("all");
  const canManageLlms =
    user?.role === AUTH_ROLES.ADMIN || user?.role === AUTH_ROLES.SUPER_ADMIN;
  const [llmAddOpen, setLlmAddOpen] = useState(false);
  const [llmMode, setLlmMode] = useState<LlmMode>("marketplace");
  const [showLlmForm, setShowLlmForm] = useState(false);
  const [editingLlm, setEditingLlm] = useState<LLMModel | null>(null);
  const [pendingDefault, setPendingDefault] = useState<string | null>(null);
  const llmAddRef = useRef<HTMLDivElement>(null);

  const filteredModels = models.filter((m) => {
    const searchMatch = m.name?.toLowerCase().includes(llmSearch.toLowerCase());

    const providerMatch =
      llmProviderFilter === "all" || m.provider === llmProviderFilter;

    return searchMatch && providerMatch;
  });

  const openLlmForm = useCallback(
    (mode: LlmMode, existing?: LLMModel) => {
      setLlmError(null);
      setLlmMode(mode);
      setEditingLlm(existing ?? null);

      if (existing) {
        populateLlmForEdit(existing);
      } else {
        resetLlmForm();

        patchLlmForm({
          provider: mode === "marketplace" ? DEFAULT_PROVIDER : "",
          icon: "default",
          enabled: true,
        });
      }

      setLlmAddOpen(false);
      setShowLlmForm(true);
    },
    [patchLlmForm, populateLlmForEdit, resetLlmForm, setLlmError],
  );

  const closeLlmForm = useCallback(() => {
    setShowLlmForm(false);
    setEditingLlm(null);
    setLlmError(null);
    resetLlmForm();
  }, [resetLlmForm, setLlmError]);

  const saveLlm = useCallback(async () => {
    const response = editingLlm
      ? await editLlmModel(editingLlm.model_id || editingLlm.id || "")
      : await addLlmModel();

    if (!response.success) return;

    await getLLMs();
    closeLlmForm();
  }, [addLlmModel, closeLlmForm, editLlmModel, editingLlm, getLLMs]);

  const removeLlm = useCallback(
    async (model: LLMModel) => {
      const id = model.model_id || model.id;
      if (!id) return;
      await deleteLlmModel(id);
      await getLLMs();
    },
    [deleteLlmModel, getLLMs],
  );

  const promoteLlm = useCallback(
    async (model: LLMModel) => {
      if (!model.credential_id || model.is_default) return;
      setPendingDefault(model.credential_id);
      await setDefaultLlmModel(model.credential_id);
      setPendingDefault(null);
    },
    [setDefaultLlmModel],
  );

  const promoteEmbeddingModel = useCallback(
    async (model: LLMModel) => {
      if (!model.credential_id || model.is_default_embedding) return;
      setPendingDefault(model.credential_id);
      await setDefaultEmbeddingModel(model.credential_id);
      setPendingDefault(null);
    },
    [setDefaultEmbeddingModel],
  );

  const testEditingLlm = useCallback(async () => {
    const credentialId = editingLlm?.credential_id;
    if (!credentialId) {
      return {
        ok: false,
        message: "Save this model before testing its connection.",
      };
    }
    const response = await testLlmConnection(credentialId);
    if (!response.success) {
      return {
        ok: false,
        message: response.error ?? "The test call failed.",
      };
    }
    const result = response.data;
    return result?.success
      ? { ok: true, message: "Connection succeeded." }
      : {
          ok: false,
          message: result?.error ?? "The provider rejected the call.",
        };
  }, [editingLlm, testLlmConnection]);

  const modelKind = (model: LLMModel): LlmMode =>
    model.provider === "ollama" ||
    (!!model.base_url && model.provider !== "azure")
      ? "workbench"
      : "marketplace";

  const kindOf = (m: LLMModel) => modelKind(m);

  return (
    <>
      <div className={s.cfgDetailHead}>
        <div className={s.cfgIc}>
          <svg
            width="26"
            height="26"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect x="2" y="3" width="20" height="14" rx="2" />
            <polyline points="8 21 12 17 16 21" />
          </svg>
        </div>
        <div>
          <h2>LLM Configuration</h2>
          <p>Manage the language models registered in this tenant</p>
        </div>
      </div>
      <div className={s.moduleToolbar}>
        <div className={s.searchWrap}>
          <input
            className={s.searchInput}
            placeholder="Search Models"
            value={llmSearch}
            onChange={(e) => setLlmSearch(e.target.value)}
          />
        </div>

        <div style={{ minWidth: "200px" }}>
          <MultiDropdown
            label=""
            placeholder="Select Providers"
            options={providers_list}
            selectedIds={[llmProviderFilter]}
            onToggle={(o) => setLlmProviderFilter(o.id)}
            single
          />
        </div>

        {/* <select
          className={s.umSelect}
          value={llmProviderFilter}
          onChange={(e) => setLlmProviderFilter(e.target.value)}
        >
          <option value="all">All Providers</option>
          <option value="azure">Azure</option>
          <option value="openai">OpenAI</option>
          <option value="anthropic">Anthropic</option>
          <option value="gemini">Gemini</option>
          <option value="ollama">Ollama</option>
        </select> */}

        {/* View toggle */}
        <div className={s.umViewToggle}>
          <button
            type="button"
            className={`${s.umViewBtn}${llmView === "grid" ? ` ${s.umViewBtnActive}` : ""}`}
            onClick={() => setLlmView("grid")}
            aria-label="Grid view"
            title="Grid view"
          >
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
            </svg>
          </button>
          <button
            type="button"
            className={`${s.umViewBtn}${llmView === "list" ? ` ${s.umViewBtnActive}` : ""}`}
            onClick={() => setLlmView("list")}
            aria-label="Table view"
            title="Table view"
          >
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      <div className={s.rowBetween}>
        <h2 style={{ margin: 0 }}>Registered Models</h2>
        {canManageLlms && (
          <div className={s.llmAddWrap} ref={llmAddRef}>
            <button
              className={`${s.llmAdd}${llmAddOpen ? ` ${s.llmAddOn}` : ""}`}
              onClick={() => setLlmAddOpen((o) => !o)}
              aria-label="Add LLM"
              title="Add LLM"
            >
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
            {llmAddOpen && (
              <div className={s.llmAddMenu} role="menu">
                <button
                  className={s.llmAddOpt}
                  role="menuitem"
                  onClick={() => openLlmForm("marketplace")}
                >
                  <span className={s.laoIc}>
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M4 5v14" />
                      <path d="M9 5v14" />
                      <rect
                        x="13"
                        y="4"
                        width="7"
                        height="16"
                        rx="1.5"
                        transform="rotate(6 16 12)"
                      />
                    </svg>
                  </span>
                  <span className={s.laoTxt}>
                    <span className={s.laoName}>Marketplace Model</span>
                    <span className={s.laoDesc}>
                      Add a model from a known provider.
                    </span>
                  </span>
                </button>
                <button
                  className={s.llmAddOpt}
                  role="menuitem"
                  onClick={() => openLlmForm("workbench")}
                >
                  <span className={s.laoIc}>
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                    </svg>
                  </span>
                  <span className={s.laoTxt}>
                    <span className={s.laoName}>Workbench</span>
                    <span className={s.laoDesc}>
                      Connect a custom endpoint &mdash; name, URL &amp; API key.
                    </span>
                  </span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {llmError && !showLlmForm && (
        <div className={s.formError} role="alert">
          {llmError}
        </div>
      )}

      {llmLoading && filteredModels.length === 0 && (
        <p className={s.llmEmpty}>Loading registered models&hellip;</p>
      )}

      {!llmLoading && filteredModels.length === 0 && (
        <p className={s.llmEmpty}>
          No models registered yet. Add one to make it available to agents.
        </p>
      )}

      {llmView === "grid" ? (
        <div className={s.llmGrid}>
          {filteredModels.map((m) => {
            const key = m.credential_id || m.model_id || m.id || m.name;
            const modelId = m.model_id || m.id || "";
            const kind = kindOf(m);
            const disabled = m.enabled === false;
            // const canPromote =
            //   canManageLlms && !!m.credential_id && !m.is_system;
            const canPromote =
              canManageLlms && !!m.credential_id && !m.is_system;
            // Which default this card's checkbox drives — the chat default
            // for a normal model, the embedding default for one flagged
            // `is_embedding` — decided purely by the existing model-type
            // flag, not by anything specific to this card.
            const isDefault = m.is_embedding
              ? !!m.is_default_embedding
              : !!m.is_default;
            const promote = m.is_embedding ? promoteEmbeddingModel : promoteLlm;
            const defaultLabel = m.is_embedding
              ? "default embedding"
              : "default";

            return (
              <div
                key={key}
                className={[
                  s.llmCard,
                  disabled ? s.llmCardOff : "",
                  isDefault ? s.llmCardDefault : "",
                ]
                  .filter(Boolean)
                  .join(" ")}
              >
                {/* ── Header ── */}
                <div className={s.llmCardInner}>
                  <div className={s.llmTop}>
                    <div
                      className={`${s.llmIc}${m.is_embedding ? ` ${s.llmIcEmbed}` : ""}`}
                    >
                      {m.is_embedding ? (
                        /* Embedding icon */
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M12 2L2 7l10 5 10-5-10-5z" />
                          <path d="M2 17l10 5 10-5" />
                          <path d="M2 12l10 5 10-5" />
                        </svg>
                      ) : (
                        /* LLM icon */
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <rect x="2" y="3" width="20" height="14" rx="2" />
                          <polyline points="8 21 12 17 16 21" />
                        </svg>
                      )}
                    </div>
                    <div className={s.llmHead}>
                      <span className={s.llmName} title={m.name}>
                        {m.name}
                      </span>
                      <div className={s.llmBadges}>
                        {isDefault && (
                          <span className={s.llmDefault}>
                            {m.is_embedding ? "Default Embedding" : "Default"}
                          </span>
                        )}
                        {m.is_system && (
                          <span className={s.llmSys}>System</span>
                        )}
                        {kind === "workbench" && (
                          <span className={s.llmKindWb}>Workbench</span>
                        )}
                        {disabled && <span className={s.llmOff}>Disabled</span>}
                      </div>
                      <div className={s.llmProvRow}>
                        <span className={s.llmProvDot} />
                        <span className={s.llmProv}>
                          {PROVIDER_LABELS[m.provider] ||
                            m.provider ||
                            "Custom"}
                          {m.model_name ? ` · ${m.model_name}` : ""}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── Body ── */}
                <div className={s.llmBody}>
                  {m.description && (
                    <p className={s.llmDesc}>{m.description}</p>
                  )}

                  {(m.context_window ||
                    m.max_output_tokens ||
                    m.temperature != null) && (
                    <div className={s.llmMeta}>
                      {!!m.context_window && (
                        <span title="Context window">
                          <svg
                            width="10"
                            height="10"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                          >
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                          </svg>
                          {m.context_window.toLocaleString()} ctx
                        </span>
                      )}
                      {!!m.max_output_tokens && (
                        <span title="Max output tokens">
                          <svg
                            width="10"
                            height="10"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                          >
                            <line x1="12" y1="20" x2="12" y2="10" />
                            <line x1="18" y1="20" x2="18" y2="4" />
                            <line x1="6" y1="20" x2="6" y2="16" />
                          </svg>
                          {m.max_output_tokens.toLocaleString()} out
                        </span>
                      )}
                      {m.temperature != null && (
                        <span title="Default temperature">
                          <svg
                            width="10"
                            height="10"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                          >
                            <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z" />
                          </svg>
                          {m.temperature} temp
                        </span>
                      )}
                    </div>
                  )}
                </div>
                {/* ── Footer ── */}
                <div className={s.llmFoot}>
                  {(isDefault || canPromote) && (
                    <label
                      className={s.llmDefaultCheckLabel}
                      title={
                        isDefault
                          ? `This is the workspace ${defaultLabel} model`
                          : `Set as workspace ${defaultLabel}`
                      }
                      style={{ pointerEvents: isDefault ? "none" : "auto" }}
                    >
                      <input
                        type="checkbox"
                        className={s.llmDefaultCheckbox}
                        checked={isDefault}
                        disabled={
                          pendingDefault === m.credential_id || isDefault
                        }
                        onChange={() => {
                          if (!isDefault) promote(m);
                        }}
                        aria-label={
                          isDefault
                            ? `Default ${defaultLabel} model`
                            : `Set as ${defaultLabel}`
                        }
                      />
                      {pendingDefault === m.credential_id
                        ? "Setting…"
                        : isDefault
                          ? m.is_embedding
                            ? "Default Embedding"
                            : "Default"
                          : m.is_embedding
                            ? "Set default embedding"
                            : "Set dafault"}
                    </label>
                  )}
                  {canManageLlms && !m.is_system && (
                    <button
                      className={s.llmEditBtn}
                      onClick={() => openLlmForm(kind, m)}
                      title="Edit model"
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      >
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                      </svg>
                      Edit
                    </button>
                  )}
                  {canManageLlms && !m.is_system && (
                    <button
                      className={s.kbDelBtn}
                      onClick={() => removeLlm(m)}
                      title={
                        m.is_default
                          ? "Removing the default promotes the next oldest model"
                          : "Delete model"
                      }
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      >
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                        <path d="M10 11v6" />
                        <path d="M14 11v6" />
                        <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                      </svg>
                      Delete
                    </button>
                  )}
                </div>

                {!modelId && (
                  <span
                    className={s.fieldError}
                    style={{ padding: "0 18px 14px" }}
                  >
                    This model has no identifier and cannot be edited.
                    Re-register it.
                  </span>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Table view */
        <div className={s.llmTableWrap}>
          <table className={s.llmTable}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Provider</th>
                <th>Model</th>
                <th>Context</th>
                <th>Status</th>
                {canManageLlms && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filteredModels.map((m) => {
                const key = m.credential_id || m.model_id || m.id || m.name;
                const kind = kindOf(m);
                const disabled = m.enabled === false;
                // const canPromote =
                //   canManageLlms && !!m.credential_id && !m.is_system;
                const canPromote =
                  canManageLlms && !!m.credential_id && !m.is_system;
                // Which default this card's checkbox drives — the chat default
                // for a normal model, the embedding default for one flagged
                // `is_embedding` — decided purely by the existing model-type
                // flag, not by anything specific to this card.
                const isDefault = m.is_embedding
                  ? !!m.is_default_embedding
                  : !!m.is_default;
                const promote = m.is_embedding
                  ? promoteEmbeddingModel
                  : promoteLlm;
                const defaultLabel = m.is_embedding
                  ? "default embedding"
                  : "default";

                return (
                  <tr key={key}>
                    <td>
                      <span style={{ fontWeight: 600 }}>{m.name}</span>
                      {(m.is_embedding
                        ? m.is_default_embedding
                        : m.is_default) && (
                        <span
                          className={s.llmDefault}
                          style={{ marginLeft: 6 }}
                        >
                          {m.is_embedding ? "Default embedding" : "Default"}
                        </span>
                      )}
                      {m.is_system && (
                        <span className={s.llmSys} style={{ marginLeft: 6 }}>
                          System
                        </span>
                      )}
                    </td>
                    <td>
                      {PROVIDER_LABELS[m.provider] || m.provider || "Custom"}
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-soft)" }}>
                      {m.model_name || "—"}
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-soft)" }}>
                      {m.context_window
                        ? m.context_window.toLocaleString()
                        : "—"}
                    </td>
                    <td>
                      {disabled ? (
                        <span className={s.llmOff}>Disabled</span>
                      ) : (
                        <span className={s.llmManaged}>Active</span>
                      )}
                    </td>
                    {canManageLlms && (
                      <td>
                        <LlmRowMenu
                          m={m}
                          kind={kind}
                          canPromote={canPromote}
                          pendingDefault={pendingDefault}
                          onPromote={() =>
                            m.is_embedding
                              ? promoteEmbeddingModel(m)
                              : promoteLlm(m)
                          }
                          onEdit={() => openLlmForm(kind, m)}
                          onRemove={() => removeLlm(m)}
                        />
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {showLlmForm && (
        <LlmFormDialog
          mode={llmMode}
          editing={editingLlm}
          form={llmForm}
          providers={llmProviders}
          submitting={llmSubmitting}
          error={llmError}
          onFieldChange={updateLlmField}
          onPatch={patchLlmForm}
          onModeChange={(next) => {
            setLlmMode(next);
            patchLlmForm({
              provider: next === "marketplace" ? DEFAULT_PROVIDER : "",
            });
          }}
          onSubmit={saveLlm}
          onClose={closeLlmForm}
          onTest={editingLlm ? testEditingLlm : undefined}
        />
      )}
    </>
  );
}
