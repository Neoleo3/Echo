"use client";

import { WorkflowIDE, WorkflowList } from "@/features/workflows";
import s from "@/styles/config.module.css";
import { useState } from "react";

export default function Page() {
  const [showWorkflowIDE, setShowWorkflowIDE] = useState(false);
  const [ideWorkflowId, setIdeWorkflowId] = useState<string | null>(null);
  const [workflowsRefreshKey, setWorkflowsRefreshKey] = useState(0);
  const [ideWorkflowName, setIdeWorkflowName] = useState("untitled_workflow");
  return (
    <>
      <div className={s.cfgDetailHead}>
        <div className={s.cfgIc}>
          <svg
            width="26"
            height="26"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
          </svg>
        </div>
        <div>
          <h2>Workflows</h2>
          <p>Automate multi-step agent pipelines across your workspace</p>
        </div>
      </div>

      <WorkflowList
        onCreate={() => {
          setIdeWorkflowId(null);
          setIdeWorkflowName("Untitled workflow");
          setShowWorkflowIDE(true);
        }}
        onOpen={(id, name) => {
          setIdeWorkflowId(id);
          setIdeWorkflowName(name);
          setShowWorkflowIDE(true);
        }}
        refreshKey={workflowsRefreshKey}
      />

      {showWorkflowIDE && (
        <WorkflowIDE
          workflowId={ideWorkflowId}
          workflowName={ideWorkflowName}
          setIdeWorkflowName={setIdeWorkflowName}
          setIdeWorkflowId={setIdeWorkflowId}
          onClose={() => setShowWorkflowIDE(false)}
          onSaved={(id) => {
            setIdeWorkflowId(id);
            setWorkflowsRefreshKey((k) => k + 1);
          }}
        />
      )}
    </>
  );
}
