"use client";

import { AppStudio } from "@/features/app";
import { useAppStore } from "@/stores/app-store";

export default function Page() {
  const approvalFocus = useAppStore((s) => s.approvalFocus);

  return (
    <div className="stream">
      <AppStudio approvalFocus={approvalFocus} />
    </div>
  );
}
