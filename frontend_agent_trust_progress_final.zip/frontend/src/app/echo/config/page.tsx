"use client";

import { ROUTES } from "@/config";
import { NotificationBell } from "@/features/layout/components/NotificationBell";
import { useAppStore } from "@/stores/app-store";
import s from "@/styles/config.module.css";
import { useRouter } from "next/navigation";

const TILES: Array<{
  name: string;
  badge?: string;
  description: string;
  nav: string;
  icon: React.ReactNode;
}> = [
  {
    name: "LLM Config",
    // badge: "Admin",
    description:
      "Register and manage the language models available to agents in your tenant.",
    nav: ROUTES.LLM,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <polyline points="8 21 12 17 16 21" />
      </svg>
    ),
  },
  {
    name: "Agents",
    description:
      "Build, configure and publish AI agents for any use case across your workspace.",
    nav: ROUTES.AGENTS,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="12" cy="8" r="4" />
        <path d="M20 21a8 8 0 1 0-16 0" />
      </svg>
    ),
  },
  {
    name: "Workflows",
    description:
      "Create automated pipelines that connect agents, data sources and actions.",
    nav: ROUTES.WORKFLOW,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
      </svg>
    ),
  },
  {
    name: "Connectors",
    // badge: "Admin",
    description:
      "Integrate external APIs, databases and MCP servers as data sources for agents.",
    nav: ROUTES.CONNECTORS,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
      </svg>
    ),
  },
  {
    name: "Users",
    // badge: "Admin",
    description:
      "Manage workspace members, roles and access permissions for EchoAI.",
    nav: ROUTES.USER,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
  },
  {
    name: "Knowledge Base",
    description:
      "Manage data sources, file uploads and RAG configuration for your agents.",
    nav: ROUTES.KNOWELDGE,
    icon: (
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
      </svg>
    ),
  },
];

export default function Page() {
  const router = useRouter();
  const openApprovals = useAppStore((s) => s.openApprovals);
  return (
    <>
      <div className={s.cfgHeadRow}>
        <div className={s.cfgHead}>
          <h1>Configuration</h1>
          <p>
            Manage agents, models, workflows and integrations for your
            workspace.
          </p>
        </div>
        <NotificationBell enabled={true} onOpenApplication={openApprovals} />
      </div>
      <div className={s.cfgGrid}>
        {TILES.map((tile) => (
          <button
            key={tile.name}
            className={s.cfgTile}
            onClick={() => router.push(tile.nav)}
          >
            <div className={s.cfgIc}>{tile.icon}</div>
            <div className={s.cfgTileBody}>
              <span className={s.cfgName}>
                {tile.name}
                {tile.badge && <span className={s.cfgBadge}>{tile.badge}</span>}
              </span>
              <span className={s.cfgDesc}>{tile.description}</span>
            </div>
            <svg
              className={s.cfgArrow}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>
        ))}
      </div>
    </>
  );
}
