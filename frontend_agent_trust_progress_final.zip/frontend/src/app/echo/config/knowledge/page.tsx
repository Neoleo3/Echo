"use client";

import { KnowledgeSource } from "@/types";
import { useEffect, useRef, useState } from "react";
import s from "@/styles/config.module.css";
import { useKnowledgeForm } from "@/hooks/use-knowledge";
import { MultiDropdown } from "@/components/common/MultiDropdown";

type KbTab = "all" | "synced" | "syncing" | "errors";
type KbView = "grid" | "list";

const KB_NUM_FIELDS: {
  key: string;
  label: string;
  min: number;
  max: number;
  step: number;
  defaultVal: number;
}[] = [
  {
    key: "top_k",
    label: "Top K",
    min: 1,
    max: 100,
    step: 1,
    defaultVal: 5,
  },
  {
    key: "chunk_size",
    label: "Chunk Size",
    min: 100,
    max: 10000,
    step: 1,
    defaultVal: 1000,
  },
  {
    key: "chunk_overlap",
    label: "Chunk Overlap",
    min: 0,
    max: 5000,
    step: 1,
    defaultVal: 200,
  },
  {
    key: "vector_weight",
    label: "Vector Weight",
    min: 0,
    max: 1,
    step: 0.1,
    defaultVal: 0.5,
  },
  {
    key: "keyword_weight",
    label: "Keyword Weight",
    min: 0,
    max: 1,
    step: 0.1,
    defaultVal: 0.5,
  },
];

export default function Page() {
  const [showKbForm, setShowKbForm] = useState(false);
  const [editKnowledge, setEditKnowledge] = useState<KnowledgeSource | null>(
    null,
  );

  const [kbSources, setKbSources] = useState<KnowledgeSource[]>([]);
  const [kbTab, setKbTab] = useState<KbTab>("all");
  const [kbView, setKbView] = useState<KbView>("grid");
  const [kbRailFilter, setKbRailFilter] = useState<string>("all");

  const [kbRaw, setKbRaw] = useState<Record<string, string>>({});

  const [kbErrors, setKbErrors] = useState<Record<string, string>>({});
  const [kbRefreshing, setKbRefreshing] = useState(false);

  const handleKbNumChange = (
    key: string,
    raw: string,
    min: number,
    max: number,
  ) => {
    setKbRaw((prev) => ({ ...prev, [key]: raw }));
    if (raw === "" || raw === "-") {
      setKbErrors((prev) => ({
        ...prev,
        [key]: `Value must be between ${min} and ${max}`,
      }));
      return;
    }
    const n = Number(raw);
    if (isNaN(n)) {
      setKbErrors((prev) => ({ ...prev, [key]: "Must be a valid number" }));
      return;
    }
    if (n < min) {
      setKbErrors((prev) => ({
        ...prev,
        [key]: `Minimum value is ${min}`,
      }));
      updateField(key, n);
      return;
    }
    if (n > max) {
      setKbErrors((prev) => ({
        ...prev,
        [key]: `Maximum value is ${max}`,
      }));
      updateField(key, n);
      return;
    }
    setKbErrors((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
    updateField(key, n);
  };

  const resetKbNumFields = () => {
    setKbRaw({});
    setKbErrors({});
  };

  const hasKbErrors = Object.keys(kbErrors).length > 0;

  const {
    knowledgeStats,
    GetKnowledge,
    SaveKnowledge,
    DeleteKnowledge,
    ResetForm,
    form,
    updateField,
    kModels,
  } = useKnowledgeForm();

  const fileRef = useRef<HTMLInputElement>(null);
  const FetchKB = async (silent = false) => {
    if (silent) setKbRefreshing(true);
    const response = await GetKnowledge();
    setKbSources(response ?? []);
    if (silent) setKbRefreshing(false);
  };

  useEffect(() => {
    FetchKB();
  }, []);

  const allSources = kbSources;
  const synced = kbSources.filter((k) => k?.status?.toLowerCase() === "synced");

  const syncing = kbSources.filter(
    (k) => k?.status?.toLowerCase() === "processing",
  );

  const errors = kbSources.filter((k) => k?.status?.toLowerCase() === "error");
  const tabMap: Record<KbTab, KnowledgeSource[]> = {
    all: allSources,
    synced,
    syncing,
    errors,
  };
  const visible =
    kbRailFilter === "all"
      ? tabMap[kbTab]
      : tabMap[kbTab].filter((k) => k.source_type === kbRailFilter);

  return (
    <>
      <div className={s.kbTop}>
        <div>
          <h2 className={s.kbH1}>Knowledge Base</h2>
          <p className={s.kbSub}>Data sources &amp; RAG</p>
        </div>
        <div className={s.kbActions}>
          <div className={s.kbSeg}>
            <button
              className={kbView === "grid" ? s.kbSegActive : ""}
              onClick={() => setKbView("grid")}
              aria-label="Grid"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <rect x="3" y="3" width="7" height="7" />
                <rect x="14" y="3" width="7" height="7" />
                <rect x="3" y="14" width="7" height="7" />
                <rect x="14" y="14" width="7" height="7" />
              </svg>
            </button>
            <button
              className={kbView === "list" ? s.kbSegActive : ""}
              onClick={() => setKbView("list")}
              aria-label="List"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <line x1="8" y1="6" x2="21" y2="6" />
                <line x1="8" y1="12" x2="21" y2="12" />
                <line x1="8" y1="18" x2="21" y2="18" />
                <line x1="3" y1="6" x2="3.01" y2="6" />
                <line x1="3" y1="12" x2="3.01" y2="12" />
                <line x1="3" y1="18" x2="3.01" y2="18" />
              </svg>
            </button>
          </div>

          <button
            className={s.kbBtnGhost}
            onClick={() => FetchKB(true)}
            disabled={kbRefreshing}
            aria-label="Refresh knowledge bases"
            title="Refresh"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{
                animation: kbRefreshing
                  ? "kb-spin 0.8s linear infinite"
                  : undefined,
              }}
            >
              <polyline points="23 4 23 10 17 10" />
              <polyline points="1 20 1 14 7 14" />
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
            </svg>
            Refresh
          </button>

          <button
            className={s.kbBtnPrimary}
            onClick={() => {
              setEditKnowledge(null);
              ResetForm();
              resetKbNumFields();
              setShowKbForm(true);
            }}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            Add Source
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className={s.kbStats}>
        {[
          {
            label: "TOTAL RESOURCES",
            icon: (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              </svg>
            ),
            value: knowledgeStats?.total ?? 0,
          },
          {
            label: "SYNCED",
            icon: (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
            ),
            value: knowledgeStats?.synced ?? 0,
          },
          {
            label: "TOTAL DOCUMENTS",
            icon: (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
            ),
            value: knowledgeStats?.total_documents ?? 0,
          },
          {
            label: "TOTAL CHUNKS",
            icon: (
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              >
                <rect x="2" y="3" width="20" height="14" rx="2" />
                <polyline points="8 21 12 17 16 21" />
              </svg>
            ),
            value: knowledgeStats?.total_chunks ?? 0,
          },
        ].map((stat) => (
          <div key={stat.label} className={s.kbStat}>
            <div className={s.kbStatLabel}>
              {stat.icon}
              {stat.label}
            </div>
            <div className={s.kbStatVal}>{stat.value}</div>
          </div>
        ))}
      </div>

      {/* Body: sidebar rail + main */}
      <div className={s.kbBody}>
        {/* Left rail */}
        <div className={s.kbRail}>
          <div className={s.kbRailTitle}>SOURCE TYPES</div>
          {[
            {
              id: "all",
              label: "All Sources",
              icon: (
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                >
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                </svg>
              ),
              count: allSources.length,
            },
            {
              id: "file_upload",
              label: "File Uploads",
              icon: (
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                >
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                </svg>
              ),
              count: allSources.filter((k) => k.source_type === "file_upload")
                .length,
            },
          ].map((item) => (
            <button
              key={item.id}
              className={`${s.kbRailBtn}${kbRailFilter === item.id ? ` ${s.kbRailBtnActive}` : ""}`}
              onClick={() => setKbRailFilter(item.id)}
            >
              {item.icon}
              {item.label}
              <span className={s.kbRailCount}>{item.count}</span>
            </button>
          ))}
        </div>

        {/* Main content */}
        <div>
          {/* Tabs */}
          <div className={s.kbTabs}>
            {(
              [
                ["all", "All Sources"],
                ["synced", "Synced"],
                ["syncing", "Syncing"],
                ["errors", "Errors"],
              ] as [KbTab, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                className={`${s.kbTab}${kbTab === id ? ` ${s.kbTabActive}` : ""}`}
                onClick={() => setKbTab(id)}
              >
                {label} ({tabMap[id].length})
              </button>
            ))}
          </div>

          {/* Source grid / table */}
          {visible.length === 0 ? (
            <div className={s.cfgEmpty}>
              <p>No sources</p>
              <span>Add a source to get started.</span>
            </div>
          ) : kbView === "grid" ? (
            <div className={s.kbGrid}>
              {visible.map((src) => (
                <div key={src.id} className={s.kbCard}>
                  <div className={s.kbCardHead}>
                    <div className={s.kbIc}>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      >
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                      </svg>
                    </div>
                    <div>
                      <div className={s.kbCardName}>{src.name}</div>
                      <div className={s.kbCardType}>{src.source_type}</div>
                    </div>
                  </div>
                  {src.description && (
                    <p className={s.kbCardDesc}>{src.description}</p>
                  )}
                  <span
                    className={`${s.kbStatusBadge} ${src.status === "synced" ? s.kbStatusSynced : src.status === "syncing" ? s.kbStatusSyncing : s.kbStatusError}`}
                  >
                    <span
                      className={`${s.kbDot} ${src.status === "syncing" ? s.kbDotSyncing : src.status === "error" ? s.kbDotError : ""}`}
                    />
                    {src.status}
                  </span>
                  <div className={s.kbMeta}>
                    <div>
                      Files <b>{src.document_count ?? 0}</b>
                    </div>
                    <div>
                      Chunk Size <b>{src.chunk_size ?? 0}</b>
                    </div>
                    <div>
                      Chunk Overlap <b>{src.chunk_overlap ?? 0}</b>
                    </div>
                  </div>
                  <div className={s.kbCardFoot}>
                    <button
                      className={s.kbDelBtn}
                      onClick={async () => {
                        await DeleteKnowledge(src.id);
                        await FetchKB();
                      }}
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      >
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                        <path d="M10 11v6" />
                        <path d="M14 11v6" />
                        <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                      </svg>
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className={s.cfgTableWrap}>
              <table className={s.cfgDataTable}>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Files</th>
                    <th>Chunk Size</th>
                    <th>Chunk Overlap</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((src) => (
                    <tr key={src.id}>
                      <td style={{ fontWeight: 600 }}>{src.name}</td>
                      <td>
                        <span className={s.kbCardType}>{src.source_type}</span>
                      </td>
                      <td
                        style={{
                          fontSize: 12.5,
                          color: "var(--text-soft)",
                        }}
                      >
                        {src.description || "—"}
                      </td>
                      <td>
                        <span
                          className={`${s.kbStatusBadge} ${src.status === "synced" ? s.kbStatusSynced : src.status === "syncing" ? s.kbStatusSyncing : s.kbStatusError}`}
                        >
                          <span
                            className={`${s.kbDot} ${src.status === "syncing" ? s.kbDotSyncing : src.status === "error" ? s.kbDotError : ""}`}
                          />
                          {src.status}
                        </span>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {src.document_count ?? 0}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {src.chunk_size ?? 0}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {src.chunk_overlap ?? 0}
                      </td>
                      <td>
                        <div className={s.cfgTableActions}>
                          <button
                            className={s.kbDelBtn}
                            onClick={async () => {
                              await DeleteKnowledge(src.id);
                              await FetchKB();
                            }}
                          >
                            <svg
                              width="13"
                              height="13"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="1.8"
                              strokeLinecap="round"
                            >
                              <polyline points="3 6 5 6 21 6" />
                              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                              <path d="M10 11v6" />
                              <path d="M14 11v6" />
                              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                            </svg>
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Create KB Modal */}
      {showKbForm && (
        <div
          className={s.overlay}
          onClick={() => {
            setShowKbForm(false);
            setEditKnowledge(null);
            ResetForm();
            resetKbNumFields();
          }}
        >
          <div className={s.kbDialog} onClick={(e) => e.stopPropagation()}>
            <div className={s.dialogHead}>
              <h3>
                {editKnowledge
                  ? "Edit Knowledge Base"
                  : "Create New Knowledge Base"}
              </h3>

              <button
                className={s.dialogClose}
                onClick={() => {
                  setShowKbForm(false);
                  setEditKnowledge(null);
                  ResetForm();
                  resetKbNumFields();
                }}
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className={`${s.dialogBody} ${s.kbDialogBody}`}>
              {/* BASIC DETAILS */}

              <div className={s.kbFormSec}>Basic Details</div>

              <div className={s.llmFormField} style={{ marginBottom: 14 }}>
                <label>Name</label>

                <input
                  type="text"
                  placeholder="Knowledge Base Name"
                  value={form.name || ""}
                  onChange={(e) => updateField("name", e.target.value)}
                />
              </div>

              <div className={s.llmFormField} style={{ marginBottom: 14 }}>
                <label>Description</label>

                <textarea
                  className={s.kbTextarea}
                  placeholder="Description"
                  value={form.description || ""}
                  onChange={(e) => updateField("description", e.target.value)}
                />
              </div>

              {/* FILES */}

              <div className={s.kbFormSec}>Upload Files</div>

              <input
                ref={fileRef}
                type="file"
                multiple
                hidden
                onChange={(event) => {
                  const files = Array.from(event.target.files || []);

                  updateField("files", [...(form.files || []), ...files]);
                  if (fileRef.current) fileRef.current.value = "";
                }}
              />

              <div
                className={s.kbDropzone}
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.currentTarget.classList.add(s.kbDropzoneOver);
                }}
                onDragEnter={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.currentTarget.classList.add(s.kbDropzoneOver);
                }}
                onDragLeave={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.currentTarget.classList.remove(s.kbDropzoneOver);
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.currentTarget.classList.remove(s.kbDropzoneOver);
                  const dropped = Array.from(e.dataTransfer.files);
                  if (dropped.length > 0) {
                    updateField("files", [...(form.files || []), ...dropped]);
                  }
                }}
              >
                <svg
                  width="30"
                  height="30"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                >
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                </svg>

                <p>Drag and drop files here</p>

                <span>PDF, DOCX, CSV, XLSX, PNG, JPG</span>
              </div>

              {(form.files ? Array.from(form.files as FileList | File[]) : [])
                .length > 0 && (
                <div
                  style={{
                    marginTop: 12,
                    display: "flex",
                    flexDirection: "column",
                    gap: 8,
                  }}
                >
                  {Array.from(form.files as FileList | File[]).map(
                    (file: File, index: number) => (
                      <div
                        key={index}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <span>{file.name}</span>

                        <button
                          type="button"
                          className={s.kbDelBtn}
                          onClick={() =>
                            updateField(
                              "files",
                              Array.from(
                                form.files as FileList | File[],
                              ).filter((_: File, i: number) => i !== index),
                            )
                          }
                        >
                          Remove
                        </button>
                      </div>
                    ),
                  )}
                </div>
              )}

              {/* PROCESSING */}

              <div className={s.kbFormSec}>Processing Configuration</div>

              <div className={s.kbModes}>
                {[
                  {
                    id: "vector",
                    label: "Vector",
                    desc: "Vector Embeddings",
                  },
                  {
                    id: "graph",
                    label: "Knowledge Graph",
                    desc: "Graph Search",
                  },
                  {
                    id: "hybrid",
                    label: "Hybrid",
                    desc: "Vector + Graph",
                  },
                ].map((mode: any) => (
                  <button
                    key={mode.id}
                    type="button"
                    className={`${s.kbModeBtn}${
                      form.processing === mode.id ? ` ${s.kbModeBtnSel}` : ""
                    }`}
                    onClick={() => updateField("processing", mode.id)}
                  >
                    <b>{mode.label}</b>
                    <span>{mode.desc}</span>
                  </button>
                ))}
              </div>

              {/* OCR */}

              <div className={s.kbFormRow}>
                {/* <div className={s.llmFormField}>
                    <label>OCR Method</label>

                    <select
                      value={form.ocr_method || "docling"}
                      onChange={(e) =>
                        updateField("ocr_method", e.target.value)
                      }
                    >
                      <option value="docling">Docling</option>

                      <option value="tesseract">Tesseract</option>
                    </select>
                  </div> */}

                <MultiDropdown
                  label="Search Type"
                  placeholder="Select Search Type"
                  options={[
                    { id: "similarity", name: "Similarity" },
                    { id: "hybrid", name: "Hybrid" },
                  ]}
                  selectedIds={[form.search_type || "hybrid"]}
                  onToggle={(o) => updateField("search_type", o.id)}
                  single
                />
              </div>

              {/* EMBEDDING MODEL */}

              {(form.processing === "vector" ||
                form.processing === "hybrid" ||
                form.processing === "graph") && (
                <MultiDropdown
                  label="Embedding Model"
                  placeholder="Select Embedding Model"
                  options={kModels?.filter((m: any) => m.is_embedding)}
                  selectedIds={[form.embedding_model || ""]}
                  onToggle={(o) => updateField("embedding_model", o.id)}
                  single
                />
              )}

              {/* GRAPH MODEL */}

              {(form.processing === "graph" ||
                form.processing === "hybrid") && (
                <MultiDropdown
                  label="Graph Model"
                  placeholder="Select Graph Model"
                  options={kModels?.filter((m: any) => m.is_embedding)}
                  selectedIds={[form.graph_model || ""]}
                  onToggle={(o) => updateField("graph_model", o.id)}
                  single
                />
              )}

              {/* BASIC CONFIG */}

              <div
                className={s.kbFormSec}
                style={{
                  marginTop: 20,
                }}
              >
                Basic Configuration
              </div>

              <div className={s.kbFormRow}>
                {KB_NUM_FIELDS.map(
                  ({ key, label, min, max, step, defaultVal }) => {
                    const rawVal =
                      kbRaw[key] !== undefined
                        ? kbRaw[key]
                        : String(form[key] ?? defaultVal);
                    const errMsg = kbErrors[key];
                    return (
                      <div key={key} className={s.llmFormField}>
                        <label>{label}</label>
                        <input
                          type="number"
                          min={min}
                          max={max}
                          step={step}
                          value={rawVal}
                          onChange={(e) =>
                            handleKbNumChange(key, e.target.value, min, max)
                          }
                          onBlur={(e) => {
                            const raw = e.target.value;
                            const n = Number(raw);
                            if (raw === "" || isNaN(n) || n < min || n > max) {
                            }
                          }}
                          style={
                            errMsg ? { borderColor: "var(--error)" } : undefined
                          }
                        />
                        {errMsg && (
                          <span
                            style={{
                              fontSize: 11,
                              color: "var(--error, #dc2626)",
                              marginTop: 2,
                              display: "block",
                              lineHeight: 1.4,
                            }}
                          >
                            {errMsg}
                          </span>
                        )}
                      </div>
                    );
                  },
                )}
              </div>
            </div>

            {/* FOOTER */}

            <div className={s.dialogFoot}>
              <button
                className={s.btnGhost}
                onClick={() => {
                  setShowKbForm(false);
                  setEditKnowledge(null);
                  ResetForm();
                  resetKbNumFields();
                }}
              >
                Cancel
              </button>

              <button
                className={s.kbCreateBtn}
                disabled={hasKbErrors}
                title={
                  hasKbErrors
                    ? "Fix validation errors before saving"
                    : undefined
                }
                onClick={async () => {
                  const response = await SaveKnowledge();

                  if (response) {
                    await FetchKB();

                    setShowKbForm(false);

                    setEditKnowledge(null);

                    ResetForm();
                    resetKbNumFields();
                  }
                }}
              >
                {editKnowledge
                  ? "Update Knowledge Base"
                  : "Create Knowledge Base"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
