"use client";

import { MultiDropdown } from "@/components/common/MultiDropdown";
import {
  useUsers,
  isUserActive,
  resolveAssigned,
  roleLabel,
  userKey,
} from "@/hooks/useUsers";
import s from "@/styles/config.module.css";
import { AdminUser } from "@/types";
import { useState } from "react";

type UmView = "grid" | "list";

export default function Page() {
  const {
    users,
    dropdowns: userDropdowns,
    form: userForm,
    loading: usersLoading,
    submitting: userSubmitting,
    error: umError,
    setError: setUmError,
    pagination: umPagination,
    setPage: setUmPage,
    setPageSize: setUmPageSize,
    filters: userFilters,
    updateFilters: updateUserFilters,
    updateField: updateUserField,
    toggleFormId: toggleUserFormId,
    resetForm: resetUserForm,
    populateForEdit: populateUserForEdit,
    submitUser,
    toggleUserStatus,
  } = useUsers();

  const [showCreateUser, setShowCreateUser] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [umView, setUmView] = useState<UmView>("grid");

  const { page, size: page_size, total } = umPagination;
  const totalPages = Math.max(1, Math.ceil(total / page_size));
  const pageStart = (page - 1) * page_size + 1;
  const pageEnd = Math.min(page * page_size, total);

  const openUserForm = (existing?: AdminUser) => {
    setUmError(null);
    setEditingUser(existing ?? null);
    if (existing) populateUserForEdit(existing);
    else resetUserForm();
    setShowCreateUser(true);
  };

  const saveUser = async () => {
    if (!userForm.email.trim()) return;
    const ok = await submitUser(editingUser);
    if (ok) setShowCreateUser(false);
  };

  const handleToggleUser = async (user: AdminUser) => {
    await toggleUserStatus(userKey(user), !isUserActive(user));
  };

  const avatarColors = [
    "#2563EB",
    "#7C3AED",
    "#0891B2",
    "#16A34A",
    "#D97706",
    "#DC2626",
    "#9333EA",
  ];
  const avatarColor = (username: string) =>
    avatarColors[(username.charCodeAt(0) || 0) % avatarColors.length];

  const userName = (user: AdminUser) =>
    user.display_name?.trim() || user.email?.split("@")[0] || "";

  return (
    <>
      {" "}
      <div className={s.umTopRow}>
        <div className={s.cfgDetailHead} style={{ margin: 0 }}>
          <div className={s.cfgIc}>
            <svg
              width="26"
              height="26"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>
              User Management
            </h2>
            <p
              style={{
                margin: "3px 0 0",
                fontSize: 13.5,
                color: "var(--text-soft)",
              }}
            >
              Manage members, roles and access.
            </p>
          </div>
        </div>
        <button className={s.umCreateBtn} onClick={() => openUserForm()}>
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          >
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          Create User
        </button>
      </div>
      {/* Toolbar */}
      <div className={s.umToolbar}>
        <div className={s.searchWrap} style={{ flex: 1, maxWidth: 340 }}>
          <svg width="14" height="14" viewBox="0 0 256 256" fill="currentColor">
            <path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z" />
          </svg>
          <input
            className={s.searchInput}
            placeholder="Search users by name or email…"
            value={userFilters.search}
            onChange={(e) => updateUserFilters({ search: e.target.value })}
          />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ color: "var(--text-faint)" }}
          >
            <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
          </svg>
          <span
            style={{
              fontSize: 12.5,
              fontWeight: 600,
              color: "var(--text-faint)",
            }}
          >
            Filter
          </span>
        </div>

        <div style={{ minWidth: "200px" }}>
          <MultiDropdown
            label=""
            placeholder="Select Role"
            options={userDropdowns.roles.map((r) => ({
              id: r.value,
              name: r.label,
            }))}
            selectedIds={userForm.role ? [userForm.role] : []}
            onToggle={(o) => updateUserFilters({ role: o.id })}
            single
          />
        </div>
        <div style={{ minWidth: "200px" }}>
          <MultiDropdown
            label=""
            placeholder="Select Business Units"
            options={userDropdowns.business_units.map((r) => ({
              id: r.id,
              name: r.name,
            }))}
            selectedIds={[userFilters.businessUnitId]}
            onToggle={(o) => updateUserFilters({ businessUnitId: o.id })}
            single
          />
        </div>
        <div style={{ minWidth: "200px" }}>
          <MultiDropdown
            label=""
            placeholder="Select designations"
            options={userDropdowns.designations.map((r) => ({
              id: r.id,
              name: r.name,
            }))}
            selectedIds={userForm.role ? [userForm.role] : []}
            onToggle={(o) => updateUserFilters({ designationId: o.id })}
            single
          />
        </div>
        {/* View toggle */}
        <div className={s.umViewToggle}>
          <button
            className={`${s.umViewBtn}${umView === "grid" ? ` ${s.umViewBtnActive}` : ""}`}
            onClick={() => setUmView("grid")}
            aria-label="Grid view"
          >
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
            </svg>
          </button>
          <button
            className={`${s.umViewBtn}${umView === "list" ? ` ${s.umViewBtnActive}` : ""}`}
            onClick={() => setUmView("list")}
            aria-label="List view"
          >
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            >
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          </button>
        </div>
      </div>
      {umError && (
        <p
          style={{
            margin: "0 0 12px",
            fontSize: 12.5,
            color: "var(--error, #dc2626)",
          }}
        >
          {umError}
        </p>
      )}
      {usersLoading && (
        <p
          style={{
            margin: "0 0 12px",
            fontSize: 12.5,
            color: "var(--text-soft)",
          }}
        >
          Loading users…
        </p>
      )}
      {!usersLoading && total > 0 && (
        <p
          style={{
            margin: "0 0 10px",
            fontSize: 12.5,
            color: "var(--text-soft)",
          }}
        >
          Showing {pageStart} - {pageEnd} of {total} user
          {total !== 1 ? "s" : ""}
        </p>
      )}
      {!usersLoading && users.length === 0 ? (
        <div className={s.cfgEmpty}>
          <div className={s.cfgIc}>
            <svg
              width="26"
              height="26"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <p>No users found</p>
          <span>Try adjusting your search or filters.</span>
        </div>
      ) : umView === "grid" ? (
        <div className={s.umCards}>
          {users.map((user) => {
            const name = userName(user);
            const active = isUserActive(user);
            const designations = resolveAssigned(
              user.designations,
              user.designation_ids,
              userDropdowns.designations,
            );
            const businessUnits = resolveAssigned(
              user.business_units,
              user.business_unit_ids,
              userDropdowns.business_units,
            );
            return (
              <div key={userKey(user)} className={s.umCard}>
                <div className={s.umCardTop}>
                  <div
                    className={s.umAvatar}
                    style={{ background: avatarColor(name) }}
                  >
                    {name.charAt(0).toUpperCase()}
                  </div>
                  <div className={s.umMeta}>
                    <div className={s.umName}>{name}</div>
                    <div className={s.umEmail}>{user.email}</div>
                  </div>
                </div>
                <div className={s.umTags}>
                  <span
                    className={`${s.umRole} ${user.role === "admin" ? s.umRoleAdmin : user.role === "super_admin" ? s.umRoleSAdmin : ""}`}
                  >
                    {roleLabel(user.role)}
                  </span>
                  <span
                    className={`${s.umStatus} ${active ? s.umStatusOn : s.umStatusOff}`}
                  >
                    {active ? "Active" : "Inactive"}
                  </span>
                </div>
                {(designations.length > 0 || businessUnits.length > 0) && (
                  <div className={s.umExtra}>
                    {designations.length > 0 && (
                      <div>
                        <b>Designations:</b> {designations.join(", ")}
                      </div>
                    )}
                    {businessUnits.length > 0 && (
                      <div>
                        <b>Business Units:</b> {businessUnits.join(", ")}
                      </div>
                    )}
                  </div>
                )}
                <div className={s.umFoot}>
                  <button
                    className={s.umBtn}
                    onClick={() => openUserForm(user)}
                  >
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                    >
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                    Edit
                  </button>
                  <button
                    className={`${s.umBtn} ${active ? s.umBtnWarn : ""}`}
                    onClick={() => handleToggleUser(user)}
                  >
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                    >
                      <path d="M18.36 6.64a9 9 0 1 1-12.73 0" />
                      <line x1="12" y1="2" x2="12" y2="12" />
                    </svg>
                    {active ? "Deactivate" : "Activate"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className={s.cfgTableWrap}>
          <table className={s.cfgDataTable}>
            <thead>
              <tr>
                <th>User</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Designations</th>
                <th>Business Units</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => {
                const name = userName(user);
                const active = isUserActive(user);
                const designations = resolveAssigned(
                  user.designations,
                  user.designation_ids,
                  userDropdowns.designations,
                );
                const businessUnits = resolveAssigned(
                  user.business_units,
                  user.business_unit_ids,
                  userDropdowns.business_units,
                );
                return (
                  <tr key={userKey(user)}>
                    <td>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <div
                          className={s.umAvatar}
                          style={{
                            background: avatarColor(name),
                            width: 32,
                            height: 32,
                            fontSize: 13,
                          }}
                        >
                          {name.charAt(0).toUpperCase()}
                        </div>
                        <span style={{ fontWeight: 600 }}>{name}</span>
                      </div>
                    </td>
                    <td style={{ fontSize: 12.5, color: "var(--text-soft)" }}>
                      {user.email}
                    </td>
                    <td>
                      <span
                        className={`${s.umRole} ${user.role === "admin" ? s.umRoleAdmin : user.role === "super_admin" ? s.umRoleSAdmin : ""}`}
                      >
                        {roleLabel(user.role)}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`${s.umStatus} ${active ? s.umStatusOn : s.umStatusOff}`}
                      >
                        {active ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td style={{ fontSize: 12.5, color: "var(--text-soft)" }}>
                      {designations.join(", ") || "—"}
                    </td>
                    <td style={{ fontSize: 12.5, color: "var(--text-soft)" }}>
                      {businessUnits.join(", ") || "—"}
                    </td>
                    <td>
                      <div className={s.cfgTableActions}>
                        <button
                          className={s.umBtn}
                          onClick={() => openUserForm(user)}
                        >
                          <svg
                            width="13"
                            height="13"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                          >
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                          Edit
                        </button>
                        <button
                          className={`${s.umBtn} ${active ? s.umBtnWarn : ""}`}
                          onClick={() => handleToggleUser(user)}
                        >
                          {active ? "Deactivate" : "Activate"}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      {/* Pagination */}
      {!usersLoading && totalPages > 1 && (
        <div className={s.userPagination}>
          <button
            className={s.umPageBtn}
            onClick={() => setUmPage(Math.max(1, page - 1))}
            disabled={page === 1}
            aria-label="Previous page"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter(
              (p) => p === 1 || p === totalPages || Math.abs(p - page) <= 1,
            )
            .reduce<(number | "…")[]>((acc, p, i, arr) => {
              if (i > 0 && (p as number) - (arr[i - 1] as number) > 1)
                acc.push("…");
              acc.push(p);
              return acc;
            }, [])
            .map((item, idx) =>
              item === "…" ? (
                <span key={`ellipsis-${idx}`} className={s.umPageEllipsis}>
                  …
                </span>
              ) : (
                <button
                  key={item}
                  className={`${s.umPageBtn}${page === item ? ` ${s.umPageBtnActive}` : ""}`}
                  onClick={() => setUmPage(item as number)}
                  aria-current={page === item ? "page" : undefined}
                >
                  {item}
                </button>
              ),
            )}

          <button
            className={s.umPageBtn}
            onClick={() => setUmPage(Math.min(totalPages, page + 1))}
            disabled={page === totalPages}
            aria-label="Next page"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>

          <span className={s.umPageInfo}>
            {pageStart} - {pageEnd} of {total}
          </span>

          <div className={s.umPageSizeWrap}>
            <label className={s.umPageSizeLabel} htmlFor="um-page-size">
              Rows:
            </label>
            <select
              id="um-page-size"
              className={s.umPageSizeSelect}
              value={page_size}
              onChange={(e) => setUmPageSize(Number(e.target.value))}
            >
              {[10, 20, 50, 100].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
      {showCreateUser && (
        <div className={s.overlay} onClick={() => setShowCreateUser(false)}>
          <div className={s.dialog} onClick={(e) => e.stopPropagation()}>
            <div className={s.dialogHead}>
              <h3>{editingUser ? "Edit User" : "Create User"}</h3>
              <button
                className={s.dialogClose}
                onClick={() => setShowCreateUser(false)}
                aria-label="Close"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <div className={s.dialogBody}>
              {umError && (
                <p
                  style={{
                    margin: "0 0 12px",
                    fontSize: 12.5,
                    color: "var(--error, #dc2626)",
                  }}
                >
                  {umError}
                </p>
              )}
              <div className={s.umFormGrid}>
                <div className={s.llmFormField}>
                  <label>Email</label>
                  <input
                    type="email"
                    placeholder="name@kpmg.com"
                    value={userForm.email}
                    onChange={(e) => updateUserField("email", e.target.value)}
                    disabled={Boolean(editingUser)}
                    autoFocus={!editingUser}
                  />
                </div>
                <div className={s.llmFormField}>
                  <label>Display Name</label>
                  <input
                    type="text"
                    placeholder="Display name"
                    value={userForm.display_name}
                    onChange={(e) =>
                      updateUserField("display_name", e.target.value)
                    }
                  />
                </div>
                <MultiDropdown
                  label="Role"
                  placeholder="Select Role"
                  options={userDropdowns.roles.map((r) => ({
                    id: r.value,
                    name: r.label,
                  }))}
                  selectedIds={userForm.role ? [userForm.role] : []}
                  onToggle={(o) =>
                    updateUserField("role", userForm.role === o.id ? "" : o.id)
                  }
                  single
                />
                <MultiDropdown
                  label="Designations"
                  placeholder="Select Designations"
                  options={userDropdowns.designations}
                  selectedIds={userForm.designation_ids}
                  onToggle={(o) => toggleUserFormId("designation_ids", o.id)}
                />
                <MultiDropdown
                  label="Business Units"
                  placeholder="Select Business Units"
                  options={userDropdowns.business_units}
                  selectedIds={userForm.business_unit_ids}
                  onToggle={(o) => toggleUserFormId("business_unit_ids", o.id)}
                />
              </div>
            </div>
            <div className={s.dialogFoot}>
              <button
                className={s.btnGhost}
                onClick={() => setShowCreateUser(false)}
              >
                Cancel
              </button>
              <button
                className={s.btnPrimary}
                onClick={saveUser}
                disabled={userSubmitting || !userForm.email.trim()}
              >
                {userSubmitting
                  ? "Saving…"
                  : editingUser
                    ? "Save User"
                    : "Create User"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
