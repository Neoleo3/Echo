"use client";

import { useState } from "react";
import { useSettings } from "@/hooks/useSettings";
import type { LookupItem } from "@/services/settings.service";
import s from "@/styles/config.module.css";

// ─── Reusable section panel ────────────────────────────────────────────────────

interface SectionPanelProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  items: LookupItem[];
  loading: boolean;
  submitting: boolean;
  error: string | null;
  emptyText: string;
  inputPlaceholder: string;
  onAdd: (name: string) => Promise<boolean>;
  onDelete: (id: string) => Promise<boolean>;
  onClearError: () => void;
}

function SectionPanel({
  title,
  description,
  icon,
  items,
  loading,
  submitting,
  error,
  emptyText,
  inputPlaceholder,
  onAdd,
  onDelete,
  onClearError,
}: SectionPanelProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<LookupItem | null>(null);
  const openDialog = () => {
    setInputValue("");
    onClearError();
    setShowDialog(true);
  };

  const closeDialog = () => {
    setShowDialog(false);
    setInputValue("");
    onClearError();
  };

  const handleSubmit = async () => {
    if (!inputValue.trim()) return;
    const ok = await onAdd(inputValue);
    if (ok) closeDialog();
  };

  return (
    <>
      {/* Panel card */}
      <div
        style={{
          border: "1px solid var(--line)",
          borderRadius: 16,
          background: "var(--surface)",
          boxShadow: "var(--shadow)",
          overflow: "hidden",
          flex: 1,
          minWidth: 0,
        }}
      >
        {/* Card header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "18px 20px 14px",
            borderBottom: "1px solid var(--line)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div
              className={s.cfgIc}
              style={{ width: 40, height: 40, borderRadius: 11 }}
            >
              {icon}
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{title}</div>
              <div
                style={{
                  fontSize: 12.5,
                  color: "var(--text-soft)",
                  marginTop: 2,
                }}
              >
                {description}
              </div>
            </div>
          </div>
          <button className={s.umCreateBtn} onClick={openDialog}>
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            Add
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: "10px 0" }}>
          {loading && (
            <p
              style={{
                padding: "16px 20px",
                fontSize: 13,
                color: "var(--text-soft)",
                margin: 0,
              }}
            >
              Loading…
            </p>
          )}

          {!loading && items.length === 0 && (
            <div
              className={s.cfgEmpty}
              style={{ margin: "12px 20px", padding: "32px 16px" }}
            >
              <p style={{ fontSize: 14 }}>{emptyText}</p>
              <span>Click "Add" to create the first one.</span>
            </div>
          )}

          {!loading && items.length > 0 && (
            <div className={s.cfgTableWrap}>
              <table className={s.cfgDataTable}>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>ID</th>
                    <th style={{ width: 48 }} />
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, idx) => (
                    <tr key={item.id}>
                      <td
                        style={{
                          color: "var(--text-faint)",
                          fontSize: 12,
                          width: 40,
                        }}
                      >
                        {idx + 1}
                      </td>
                      <td style={{ fontWeight: 600 }}>{item.name}</td>
                      <td
                        style={{
                          fontSize: 11.5,
                          color: "var(--text-faint)",
                          fontFamily: "monospace",
                        }}
                      >
                        {item.id}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <button
                          aria-label={`Delete ${item.name}`}
                          onClick={() => setDeleteTarget(item)}
                          style={{
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                            padding: "4px 6px",
                            borderRadius: 6,
                            color: "var(--text-faint)",
                            display: "inline-flex",
                            alignItems: "center",
                            transition: "color 0.15s, background 0.15s",
                          }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "var(--error, #dc2626)";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "rgba(220,38,38,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "var(--text-faint)";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "none";
                          }}
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                            <path d="M10 11v6M14 11v6" />
                            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Create dialog */}
      {showDialog && (
        <div className={s.overlay} onClick={closeDialog}>
          <div className={s.dialog} onClick={(e) => e.stopPropagation()}>
            <div className={s.dialogHead}>
              <h3>Add {title.replace(/s$/, "")}</h3>
              <button
                className={s.dialogClose}
                onClick={closeDialog}
                aria-label="Close"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className={s.dialogBody} style={{ paddingTop: 14 }}>
              {error && (
                <p
                  style={{
                    margin: "0 0 14px",
                    fontSize: 12.5,
                    color: "var(--error, #dc2626)",
                  }}
                >
                  {error}
                </p>
              )}
              <div className={s.llmFormField}>
                <label>Name</label>
                <input
                  type="text"
                  placeholder={inputPlaceholder}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSubmit();
                  }}
                  autoFocus
                />
              </div>
            </div>

            <div className={s.dialogFoot}>
              <button className={s.btnGhost} onClick={closeDialog}>
                Cancel
              </button>
              <button
                className={s.btnPrimary}
                onClick={handleSubmit}
                disabled={submitting || !inputValue.trim()}
              >
                {submitting ? "Saving…" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirmation dialog */}
      {deleteTarget && (
        <div className={s.overlay} onClick={() => setDeleteTarget(null)}>
          <div className={s.dialog} onClick={(e) => e.stopPropagation()}>
            <div className={s.dialogHead}>
              <h3>Delete {title.replace(/s$/, "")}</h3>
              <button
                className={s.dialogClose}
                onClick={() => setDeleteTarget(null)}
                aria-label="Close"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className={s.dialogBody} style={{ paddingTop: 14 }}>
              {error && (
                <p
                  style={{
                    margin: "0 0 14px",
                    fontSize: 12.5,
                    color: "var(--error, #dc2626)",
                  }}
                >
                  {error}
                </p>
              )}
              <p style={{ margin: 0, fontSize: 13.5 }}>
                Are you sure you want to delete{" "}
                <strong>&ldquo;{deleteTarget.name}&rdquo;</strong>? This action
                cannot be undone.
              </p>
            </div>

            <div className={s.dialogFoot}>
              <button
                className={s.btnGhost}
                onClick={() => setDeleteTarget(null)}
              >
                Cancel
              </button>
              <button
                style={{
                  background: "var(--error, #dc2626)",
                  color: "#fff",
                  border: "none",
                  borderRadius: 8,
                  padding: "7px 18px",
                  fontSize: 13.5,
                  fontWeight: 600,
                  cursor: submitting ? "not-allowed" : "pointer",
                  opacity: submitting ? 0.7 : 1,
                }}
                onClick={async () => {
                  const ok = await onDelete(deleteTarget.id);
                  if (ok) {
                    setDeleteTarget(null);
                    onClearError();
                  }
                }}
                disabled={submitting}
              >
                {submitting ? "Deleting…" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function SettingPage() {
  const {
    designations,
    businessUnits,
    loading,
    submitting,
    error,
    setError,
    createDesignation,
    createBusinessUnit,
    deleteBusinessUnit,
    deleteDesignation,
  } = useSettings();
  return (
    <div className="stream" style={{ padding: "40px" }}>
      {/* Page header */}
      <div className={s.umTopRow}>
        <div className={s.cfgDetailHead} style={{ margin: 0 }}>
          <div className={s.cfgIc}>
            <svg
              width="26"
              height="26"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>
              User Dropdown Settings
            </h2>
            <p
              style={{
                margin: "3px 0 0",
                fontSize: 13.5,
                color: "var(--text-soft)",
              }}
            >
              Manage designations and business units available when creating
              users.
            </p>
          </div>
        </div>
      </div>

      {/* Two-column panels */}
      <div
        style={{
          display: "flex",
          gap: 20,
          alignItems: "flex-start",
          flexWrap: "wrap",
        }}
      >
        {/* Designations */}
        <SectionPanel
          title="Designations"
          description="Job titles assigned to users"
          icon={
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="2" y="7" width="20" height="14" rx="2" />
              <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" />
              <line x1="12" y1="12" x2="12" y2="16" />
              <line x1="10" y1="14" x2="14" y2="14" />
            </svg>
          }
          items={designations}
          loading={loading}
          submitting={submitting}
          error={error}
          emptyText="No designations yet"
          inputPlaceholder="e.g. Senior Analyst"
          onAdd={createDesignation}
          onDelete={deleteDesignation}
          onClearError={() => setError(null)}
        />

        {/* Business Units */}
        <SectionPanel
          title="Business Units"
          description="Organisational units for grouping users"
          icon={
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
          }
          items={businessUnits}
          loading={loading}
          submitting={submitting}
          error={error}
          emptyText="No business units yet"
          inputPlaceholder="e.g. Advisory"
          onAdd={createBusinessUnit}
          onDelete={deleteBusinessUnit}
          onClearError={() => setError(null)}
        />
      </div>
    </div>
  );
}
