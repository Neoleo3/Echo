"use client";

import { Icon } from "@/components/common/Icons";
import { ROUTES } from "@/config";
import Composer from "@/features/chat/components/Composer";
import { useAppSelection } from "@/hooks/useAppSelection";
import { useAuth } from "@/hooks/useAuth";
import { useEchoChat } from "@/hooks/useEchoChat";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function Page() {
  const router = useRouter();
  const path = usePathname();
  const { user } = useAuth();
  const [input, setInput] = useState("");
  const { selectedApp, applications, selectApp } = useAppSelection(path);
  let starterQuestions = selectedApp?.starter_questions;
  let welcomePrompt = selectedApp?.welcome_prompt;
  const chips =
    starterQuestions && starterQuestions.length > 0
      ? starterQuestions.map((q) => ({
          label: q,
          icon: "sparkle",
          prompt: q,
        }))
      : [];

  useEffect(() => {
    if (applications.length > 0 && path.endsWith(ROUTES.HOME))
      selectApp(applications[0], null, () =>
        router.push(`${ROUTES.HOME}/${applications[0].application_id}`),
      );
  }, [applications]);

  const chat = useEchoChat();

  return (
    <section className="home">
      <div className="hero-bg" />

      <div className="welcome-section">
        <h2 className="welcome-user">Hi, {user?.display_name ?? ""}</h2>
        <h1 className="hero-title">
          {welcomePrompt?.trim()
            ? welcomePrompt
            : "What's going in your mind today?"}
        </h1>
      </div>
      <div id="homeSlot">
        <Composer
          selectedApp={selectedApp}
          disabled={true}
          autoFocus
          prompt={input}
        />
      </div>
      <div className="prompt-templates" aria-label="Prompt templates">
        {chips.map((c, i) => (
          <button
            key={i}
            type="button"
            className="pt-chip"
            onClick={
              async () => setInput(c.prompt)
              // chat.send(selectedApp?.application_id ?? "", c.prompt)
            }
          >
            <Icon name={c.icon} size={15} />
            {c.label}
          </button>
        ))}
      </div>
    </section>
  );
}
