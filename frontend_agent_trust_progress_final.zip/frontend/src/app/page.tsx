"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import ThemeSwitcher from "@/components/common/ThemeSwitcher";
import LoadingComponent from "@/components/common/LoadingComponent";
import styles from "@/styles/auth.module.css";
import Image from "next/image";
import { useTheme } from "@/hooks/theme.hook";
import { useAuth } from "@/hooks/useAuth";
import LoginPage from "@/features/auth/components/LoginPage";
import AgreementPage from "@/features/auth/components/AgreementPage";
import { ROUTES } from "@/config";

export type AuthView = "login" | "agreement";

export default function Login() {
  const router = useRouter();
  const [AuthView, setAuthView] = useState<AuthView>("login");
  const { theme } = useTheme();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (isLoading) return;
    if (!isAuthenticated) {
      setAuthView("login");
      return;
    }
    // if (!agreementcheck) {
    //   setAuthView("agreement");
    //   return;
    // }
    // logout();
    router.push(ROUTES.HOME);
  }, [isLoading, isAuthenticated, router]);

  const AuthViewer = () => {
    switch (AuthView) {
      case "login":
        return <LoginPage setAuthView={setAuthView} />;
      case "agreement":
        return <AgreementPage />;
    }
  };

  return (
    <div className={styles.stage}>
      <div className={styles.heroBg}>
        <div className={styles.heroGrid} />
      </div>
      <Image
        src={theme === "dark" ? "/kpmg-logo-white.svg" : "/kpmg-logo.svg"}
        alt="KPMG"
        width={112}
        height={40}
        className={styles.pageLogo}
        priority
      />
      {isLoading ? <LoadingComponent /> : AuthViewer()}
      <ThemeSwitcher />
    </div>
  );
}
