import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type { AdminUser } from "@/types";

export interface UserListResponse {
  items: AdminUser[];
  total: number;
  page: number;
  page_size: number;
}

export interface CreateUserPayload {
  email: string;
  display_name: string;
  role: string;
  designation_ids: string[];
  business_unit_ids: string[];
}

export const usersService = {
  async getUsers(page = 1, pageSize = 10, search?: string, role?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    if (role?.trim()) {
      params.append("role", role.trim());
    }
    return baseService.get<UserListResponse>(
      `${API_ROUTES.USERS.LIST}?${params.toString()}`,
    );
  },

  async createUser(data: CreateUserPayload) {
    return baseService.post<AdminUser>(API_ROUTES.USERS.CREATE, data);
  },

  async updateUser(id: string, data: Partial<CreateUserPayload>) {
    return baseService.patch<AdminUser>(API_ROUTES.USERS.UPDATE(id), data);
  },

  async toggleUserStatus(id: string, isActive: boolean) {
    return baseService.patch(API_ROUTES.USERS.UPDATE(id), {
      is_active: isActive,
    });
  },

  async deleteUser(id: string) {
    return baseService.delete(API_ROUTES.USERS.DELETE(id));
  },

  /** Token allocations (analytics) */
  // async getTokenAllocations() {
  //   return baseService.get<unknown[]>(API_ROUTES.USERS.TOKEN_ALLOCATIONS);
  // },

  // async getTokenFormOptions() {
  //   return baseService.get<unknown>(API_ROUTES.USERS.TOKEN_FORM_OPTIONS);
  // },

  // async deleteTokenAllocation(id: string) {
  //   return baseService.delete(API_ROUTES.USERS.TOKEN_DELETE(id));
  // },
};
