import { ENV } from "@/config";
import { ApiResponse } from "@/types";

interface RequestOptions extends RequestInit {
  skipAuth?: boolean;
  handlepass?: boolean;
}

interface FastApiValidationError {
  loc?: Array<string | number>;
  msg?: string;
}

interface StructuredDetail {
  message?: string;
  errors?: string[];
}

function normalizeDetail(detail: unknown): string {
  if (typeof detail === "string") return detail;

  if (Array.isArray(detail)) {
    return detail
      .map((entry: FastApiValidationError) => {
        const field = entry?.loc?.filter((p) => p !== "body").join(".");
        const message = entry?.msg ?? "is invalid";
        return field ? `${field}: ${message}` : message;
      })
      .filter(Boolean)
      .join("; ");
  }

  if (detail && typeof detail === "object") {
    const { message, errors } = detail as StructuredDetail;
    const listed = Array.isArray(errors)
      ? errors.filter(Boolean).join("; ")
      : "";
    if (message && listed) return `${message}: ${listed}`;
    return listed || message || "";
  }

  return "";
}

class BaseService {
  private readonly baseURL: string;

  constructor() {
    this.baseURL = ENV.API_BASE_URL;
  }

  private getHeaders(isFormData = false): HeadersInit {
    const headers: Record<string, string> = {
      accept: "application/json",
    };
    if (!isFormData) {
      headers["Content-Type"] = "application/json";
    }
    return headers;
  }

  private serializeBody(data: unknown): BodyInit | undefined {
    if (data === undefined || data === null) return undefined;
    if (data instanceof FormData) return data;
    return JSON.stringify(data);
  }

  private async handleResponse<T>(
    response: Response,
    handlepass?: boolean,
  ): Promise<ApiResponse<T>> {
    if (response.status === 401) {
      globalThis.window.dispatchEvent(new CustomEvent("session-expired"));

      return { success: false, data: undefined, isAuthError: true };
    }

    const data = await response.json().catch(() => ({}));
    if (handlepass) {
      return { success: true, data: data };
    }
    const apiSuccess =
      typeof data?.success === "boolean" ? data.success : data?.status;
    const isError = data?.status === "error" || apiSuccess === false;

    if (!response.ok || isError) {
      const errorMessage =
        data.error ||
        data.message ||
        normalizeDetail(data.detail) ||
        `HTTP ${response.status}`;
      const msg =
        typeof errorMessage === "string" ? errorMessage.toLowerCase() : "";
      const isAuthError =
        response.status === 401 ||
        msg.includes("expired token") ||
        msg.includes("token expired") ||
        msg.includes("invalid token");

      if (isAuthError && globalThis.window) {
        globalThis.window.dispatchEvent(new CustomEvent("session-expired"));

        return { success: false, data: undefined, isAuthError: true };
      }

      return { success: false, error: errorMessage, data: undefined };
    }

    return { success: true, data: data.data || data, message: data.message };
  }

  async get<T>(url: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${this.baseURL}${url}`, {
        method: "GET",
        headers: this.getHeaders(),
        credentials: "include",
        ...options,
      });
      return this.handleResponse<T>(response);
    } catch (err: any) {
      console.error("Error while calling API with get method: ", err);
      return this.handleResponse<T>(err);
    }
  }

  async post<T>(
    url: string,
    data?: unknown,
    options?: RequestOptions,
  ): Promise<ApiResponse<T>> {
    const isFormData = data instanceof FormData;
    const response = await fetch(`${this.baseURL}${url}`, {
      method: "POST",
      headers: this.getHeaders(isFormData),
      body: this.serializeBody(data),
      credentials: "include",
      ...options,
    });
    return this.handleResponse<T>(
      response,
      options?.handlepass ? options?.handlepass : false,
    );
  }

  async put<T>(
    url: string,
    data?: unknown,
    options?: RequestOptions,
  ): Promise<ApiResponse<T>> {
    const isFormData = data instanceof FormData;
    const response = await fetch(`${this.baseURL}${url}`, {
      method: "PUT",
      headers: this.getHeaders(isFormData),
      body: this.serializeBody(data),
      credentials: "include",
      ...options,
    });
    return this.handleResponse<T>(response);
  }

  async patch<T>(
    url: string,
    data?: unknown,
    options?: RequestOptions,
  ): Promise<ApiResponse<T>> {
    const isFormData = data instanceof FormData;
    const response = await fetch(`${this.baseURL}${url}`, {
      method: "PATCH",
      headers: this.getHeaders(isFormData),
      body: this.serializeBody(data),
      credentials: "include",
      ...options,
    });
    return this.handleResponse<T>(response);
  }

  async delete<T>(
    url: string,
    options?: RequestOptions,
  ): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseURL}${url}`, {
      method: "DELETE",
      headers: this.getHeaders(),
      credentials: "include",
      ...options,
    });
    return this.handleResponse<T>(response);
  }
}

export const baseService = new BaseService();
