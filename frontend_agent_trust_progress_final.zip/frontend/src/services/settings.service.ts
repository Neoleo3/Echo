import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";

export interface LookupItem {
  id: string;
  name: string;
}

export const settingsService = {
  // ── Designations ──────────────────────────────────────────────
  async getDesignations() {
    return baseService.get<LookupItem[]>(API_ROUTES.DESIGNATIONS.LIST);
  },

  async createDesignation(name: string) {
    return baseService.post<LookupItem>(API_ROUTES.DESIGNATIONS.CREATE, {
      name,
    });
  },

  async deleteDesignation(id: string) {
    return baseService.delete<void>(API_ROUTES.DESIGNATIONS.DELETE(id));
  },

  // ── Business Units ────────────────────────────────────────────
  async getBusinessUnits() {
    return baseService.get<LookupItem[]>(API_ROUTES.BUSINESS_UNITS.LIST);
  },
  async createBusinessUnit(name: string) {
    return baseService.post<LookupItem>(API_ROUTES.BUSINESS_UNITS.CREATE, {
      name,
    });
  },

  async deleteBusinessUnit(id: string) {
    return baseService.delete<void>(API_ROUTES.BUSINESS_UNITS.DELETE(id));
  },
};
