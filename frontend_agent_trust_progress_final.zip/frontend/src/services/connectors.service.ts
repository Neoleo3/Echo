import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type { Connector } from "@/types";

export interface LegacyConnectorListResponse {
  connectors?: Connector[];
  connections?: Connector[];
  count?: number;
}

export type ConnectorListResponse = LegacyConnectorListResponse;

export interface PaginatedResponse<T> {
  page: number;
  page_size: number;
  total: number;
  items: T[];
}

export type ConnectorListPayload =
  | PaginatedResponse<Connector>
  | LegacyConnectorListResponse
  | Connector[];

const isPaginatedConnectorResponse = (
  payload: ConnectorListPayload,
): payload is PaginatedResponse<Connector> =>
  !Array.isArray(payload) &&
  Array.isArray((payload as { items?: unknown }).items);

const isLegacyConnectorListResponse = (
  payload: ConnectorListPayload,
): payload is LegacyConnectorListResponse =>
  !Array.isArray(payload) &&
  (Array.isArray((payload as { connectors?: unknown }).connectors) ||
    Array.isArray((payload as { connections?: unknown }).connections));

export const extractConnectorItems = (
  payload: ConnectorListPayload | undefined,
): Connector[] => {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  if (isPaginatedConnectorResponse(payload)) return payload.items;
  if (isLegacyConnectorListResponse(payload)) {
    return payload.connectors ?? payload.connections ?? [];
  }
  return [];
};

export interface DBConnectPayload {
  db_type: string;
  name?: string;
  host?: string;
  port?: number;
  database_name?: string;
  username?: string;
  password?: string;
  account_url?: string;
  odbc_connection_string?: string;
  database_file_path?: string;
}

export interface ChannelPayload {
  name: string;
  channel_type: string;
  config: Record<string, unknown>;
  is_active: boolean;
}

export const connectorsService = {
  async getMCPConnectors(page = 1, pageSize = 20, search?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    return baseService.get<PaginatedResponse<Connector>>(
      `${API_ROUTES.CONNECTORS.MCP.LIST}?${params.toString()}`,
    );
  },
  async createMCPConnector(data: Partial<Connector>) {
    return baseService.post<Connector>(API_ROUTES.CONNECTORS.MCP.CREATE, data);
  },

  async updateMCPConnector(id: string, data: Partial<Connector>) {
    return baseService.put<Connector>(API_ROUTES.CONNECTORS.MCP.UPDATE, {
      connector_id: id,
      updates: data,
    });
  },

  async deleteMCPConnector(connectorId: string) {
    return baseService.delete(API_ROUTES.CONNECTORS.MCP.DELETE, {
      body: JSON.stringify({ connector_id: connectorId }),
    });
  },

  async refreshMCPDiscovery(connectorId: string) {
    return baseService.post(API_ROUTES.CONNECTORS.MCP.REFRESH(connectorId), {});
  },

  async getMCPPoolStatus() {
    return baseService.get<{ mode: string; active_sessions: number }>(
      API_ROUTES.CONNECTORS.MCP.POOL_STATUS,
    );
  },

  /* ---- API connectors ---- */
  async getAPIConnectors(page = 1, pageSize = 20, search?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    return baseService.get<PaginatedResponse<Connector>>(
      `${API_ROUTES.CONNECTORS.API.LIST}?${params.toString()}`,
    );
  },

  async createAPIConnector(data: Partial<Connector>) {
    return baseService.post<Connector>(API_ROUTES.CONNECTORS.API.CREATE, data);
  },

  async updateAPIConnector(id: string, data: Partial<Connector>) {
    return baseService.put<Connector>(`/connectors/api/${id}`, data);
  },

  async deleteAPIConnector(connectorId: string) {
    return baseService.delete(API_ROUTES.CONNECTORS.API.DELETE, {
      body: JSON.stringify({ connector_id: connectorId }),
    });
  },

  async testAPIConnector(data: unknown) {
    return baseService.post(API_ROUTES.CONNECTORS.API.TEST, data);
  },

  async getDBConnectors() {
    return baseService.get<ConnectorListResponse>(
      API_ROUTES.CONNECTORS.DB.LIST,
    );
  },

  async getSupportedDatabases() {
    return baseService.get<{ databases: string[] }>(
      API_ROUTES.CONNECTORS.DB.SUPPORTED,
    );
  },

  async connectDB(data: DBConnectPayload) {
    return baseService.post<Connector>(API_ROUTES.CONNECTORS.DB.CONNECT, data);
  },

  async connectDBWithFile(formData: FormData) {
    return baseService.post<Connector>(
      API_ROUTES.CONNECTORS.DB.CONNECT_FILE,
      formData,
    );
  },

  async updateDBConnector(id: string, data: DBConnectPayload) {
    return baseService.put<Connector>(`/connectors/db/${id}`, data);
  },

  async updateDBConnectorWithFile(id: string, formData: FormData) {
    return baseService.put<Connector>(
      `/connectors/db/${id}/connect-with-file`,
      formData,
    );
  },

  async deleteDBConnector(id: string) {
    return baseService.delete(API_ROUTES.CONNECTORS.DB.DELETE(id));
  },

  async testDBConnection(connectionId: string) {
    return baseService.post(API_ROUTES.CONNECTORS.DB.TEST, {
      connection_id: connectionId,
    });
  },

  async getChannelConnectors() {
    return baseService.get<Connector[]>(API_ROUTES.CONNECTORS.CHANNEL.LIST);
  },

  async createChannelConnector(data: ChannelPayload) {
    return baseService.post(API_ROUTES.CONNECTORS.CHANNEL.CREATE, data);
  },

  async updateChannelConnector(id: string, data: Partial<ChannelPayload>) {
    return baseService.put(API_ROUTES.CONNECTORS.CHANNEL.DELETE(id), data);
  },

  async deleteChannelConnector(id: string) {
    return baseService.delete(API_ROUTES.CONNECTORS.CHANNEL.DELETE(id));
  },
};
