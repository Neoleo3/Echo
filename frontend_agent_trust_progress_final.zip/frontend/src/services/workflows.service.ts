import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type {
  CanvasConnection,
  CanvasLoadResponse,
  CanvasNode,
  CanvasSaveResponse,
  DesignCatalog,
  HitlDecision,
  HitlInterrupt,
  NodeOutput,
  WorkflowChatHistory,
  WorkflowDesignResult,
  WorkflowRunHandle,
  WorkflowRunStatus,
  WorkflowSummary,
} from "@/types/workflow.types";

interface PaginatedResponse<T> {
  page: number;
  page_size: number;
  total: number;
  items: T[];
}

export interface LegacyWorkflowListResponse {
  workflows?: WorkflowSummary[];
  total?: number;
}

export type WorkflowListPayload =
  | PaginatedResponse<WorkflowSummary>
  | LegacyWorkflowListResponse;

const isPaginatedWorkflowList = (
  payload: WorkflowListPayload,
): payload is PaginatedResponse<WorkflowSummary> =>
  Array.isArray((payload as { items?: unknown }).items);

export const extractWorkflowItems = (
  payload: WorkflowListPayload | undefined,
): WorkflowSummary[] => {
  if (!payload) return [];
  if (isPaginatedWorkflowList(payload)) return payload.items;
  return payload.workflows ?? [];
};

export interface WorkflowListMeta {
  page: number;
  pageSize: number;
  total: number;
}

export const extractWorkflowMeta = (
  payload: WorkflowListPayload | undefined,
  fallbackPage = 1,
  fallbackPageSize = 20,
): WorkflowListMeta => {
  if (!payload) {
    return { page: fallbackPage, pageSize: fallbackPageSize, total: 0 };
  }
  if (isPaginatedWorkflowList(payload)) {
    return {
      page: payload.page ?? fallbackPage,
      pageSize: payload.page_size ?? fallbackPageSize,
      total: payload.total ?? payload.items.length,
    };
  }
  return {
    page: fallbackPage,
    pageSize: fallbackPageSize,
    total: payload.total ?? payload.workflows?.length ?? 0,
  };
};

export interface CanvasSaveRequest {
  canvas_nodes: CanvasNode[];
  connections: CanvasConnection[];
  workflow_name?: string | null;
  /** `draft` keeps it editable; `temp` is treated as a validated draft. */
  save_as?: "draft" | "temp";
  execution_model?: string;
  /** Pass the existing id so a re-save updates rather than creating a copy. */
  workflow_id?: string | null;
  icon?: string;
}

export interface HitlDecideRequest {
  run_id: string;
  action: HitlDecision | string;
  actor?: string;
  rationale?: string;
  payload?: Record<string, unknown>;
}

export const workflowsService = {
  async designFromPrompt(prompt: string) {
    return baseService.post<WorkflowDesignResult>(
      API_ROUTES.WORKFLOWS.DESIGN_PROMPT,
      { prompt },
    );
  },

  async modifyDesign(agents: unknown[], instruction: string) {
    return baseService.post<WorkflowDesignResult>(
      API_ROUTES.WORKFLOWS.DESIGN_MODIFY,
      { agents, instruction },
    );
  },

  async getDesignCatalog() {
    return baseService.post<{ catalog: DesignCatalog }>(
      API_ROUTES.WORKFLOWS.DESIGN_CATALOG,
      { catalog_only: true },
    );
  },

  /* ---------------- Authoring ---------------- */

  async listDraftWorkflows(page = 1, pageSize = 20, search?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    return baseService.get<WorkflowListPayload>(
      `${API_ROUTES.WORKFLOWS.DRAFT_LIST}?${params.toString()}`,
    );
  },

  async saveCanvas(payload: CanvasSaveRequest) {
    return baseService.post<CanvasSaveResponse>(
      API_ROUTES.WORKFLOWS.CANVAS_SAVE,
      {
        save_as: "draft",
        execution_model: "sequential",
        ...payload,
      },
    );
  },

  async toCanvas(workflow: unknown, agents: unknown) {
    return baseService.post<CanvasLoadResponse>(
      API_ROUTES.WORKFLOWS.TO_CANVAS,
      { workflow, agents: agents ?? {} },
    );
  },

  async saveFinal(workflowId: string) {
    return baseService.post(API_ROUTES.WORKFLOWS.FINAL_SAVE, {
      workflow_id: workflowId,
    });
  },

  /* ---------------- Running ---------------- */

  async execute(
    workflowId: string,
    payload?: {
      mode?: string;
      version?: string | null;
      input_payload?: Record<string, unknown>;
    },
  ) {
    return baseService.post<Record<string, unknown>>(
      API_ROUTES.WORKFLOWS.EXECUTE(workflowId),
      { mode: "test", input_payload: {}, ...payload },
    );
  },

  async startChatSession(workflowId: string, mode = "test") {
    return baseService.post<{ session_id: string; [key: string]: unknown }>(
      API_ROUTES.WORKFLOWS.CHAT_START,
      { workflow_id: workflowId, mode },
    );
  },

  async sendChatMessage(sessionId: string, message: string) {
    return baseService.post<WorkflowRunHandle>(API_ROUTES.WORKFLOWS.CHAT_SEND, {
      session_id: sessionId,
      message,
      execute_workflow: true,
    });
  },

  async getChatHistory(sessionId: string) {
    return baseService.get<WorkflowChatHistory>(
      API_ROUTES.WORKFLOWS.CHAT_HISTORY(sessionId),
    );
  },

  async getWorkflow(id: string) {
    return baseService.get<Record<string, unknown>>(
      API_ROUTES.WORKFLOWS.DETAIL(id),
    );
  },

  async deleteWorkflow(id: string) {
    return baseService.delete(API_ROUTES.WORKFLOWS.DELETE(id));
  },

  async getExecutionSteps(runId: string) {
    return baseService.get<{ steps: NodeOutput[] }>(
      API_ROUTES.WORKFLOWS.EXECUTION_STEPS(runId),
    );
  },

  /* ---------------- HITL (Phase 8.1) ---------------- */

  async getHitlStatus(runId: string) {
    return baseService.get<WorkflowRunStatus>(
      API_ROUTES.WORKFLOWS.HITL_STATUS(runId),
    );
  },

  async getHitlContext(runId: string) {
    return baseService.get<HitlInterrupt>(
      API_ROUTES.WORKFLOWS.HITL_CONTEXT(runId),
    );
  },

  async decideHitl(payload: HitlDecideRequest) {
    return baseService.post<WorkflowRunStatus>(
      API_ROUTES.WORKFLOWS.HITL_DECIDE,
      payload,
    );
  },

  async getHitlDecisions(runId: string) {
    return baseService.get<unknown[]>(
      API_ROUTES.WORKFLOWS.HITL_DECISIONS(runId),
    );
  },

  async getPendingHitl() {
    return baseService.get<unknown[]>(API_ROUTES.WORKFLOWS.HITL_PENDING);
  },
};
