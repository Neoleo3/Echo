/**
 * Applications API service
 */

import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import { stream, upload } from "@/lib/client";
import type {
  Application,
  ApplicationList,
  ApprovalQueueItem,
  ChatMessageResponse,
  ContextLedger,
  DataSourceRef,
  LlmLink,
  SkillLink,
} from "@/types";

export interface ApplicationListResponse {
  items: ApplicationList[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ApplicationSetupUpdate {
  llm_links?: LlmLink[];
  skill_links?: SkillLink[];
  data_source_ids?: DataSourceRef[];
}

export const applicationsService = {
  async getApplications(page = 1, pageSize = 100) {
    return baseService.get<ApplicationListResponse>(
      `${API_ROUTES.APPLICATIONS.LIST}?page=${page}&pageSize=${pageSize}`,
    );
  },

  async getVisibleApplications(page = 1, pageSize = 100) {
    return baseService.get<ApplicationListResponse>(
      `${API_ROUTES.APPLICATIONS.VISIBLE}?page=${page}&pageSize=${pageSize}`,
    );
  },

  async getApplication(id: string) {
    return baseService.get<Application>(
      `${API_ROUTES.APPLICATIONS.LIST}/${id}`,
    );
  },

  async createApplication(data: Partial<Application>) {
    return baseService.post<Application>(API_ROUTES.APPLICATIONS.LIST, data);
  },

  async updateApplication(id: string, data: Partial<Application>) {
    return baseService.put<Application>(
      `${API_ROUTES.APPLICATIONS.LIST}/${id}`,
      data,
    );
  },

  async deleteApplication(id: string) {
    return baseService.delete(`${API_ROUTES.APPLICATIONS.LIST}/${id}`);
  },

  // Chat Session Services
  async sessionDocuments(id: string, sessionId: string) {
    return baseService.get(
      API_ROUTES.APPLICATIONS.Chat_SESSION_DOC(id, sessionId),
    );
  },

  async sessionFileUpload(
    id: string,
    files: FileList | File[],
    sessionId?: string | undefined,
  ) {
    const f = new FormData();
    Array.from(files).forEach((file) => f.append("file", file));
    return upload(API_ROUTES.APPLICATIONS.CHAT_UPLOAD(id), f, {
      query: { session_id: sessionId ?? undefined },
    });
  },

  async chatSessionStream(
    id: string,
    body: {
      message: string;
      session_id?: string | null;
      attachment_ids?: string[];
    },
    onEvent: (msg: Record<string, unknown>) => void,
    signal?: AbortSignal,
  ) {
    return stream(API_ROUTES.APPLICATIONS.CHAT_STREAM(id), body, onEvent, {
      signal,
    });
  },

  async getChatMessages(appId: string, sessionId: string) {
    return baseService.get<ChatMessageResponse[]>(
      API_ROUTES.APPLICATIONS.CHAT_SESSION(appId, sessionId),
    );
  },

  async getChatSessions(appId: string) {
    return baseService.get<
      Array<{ chat_session_id: string; title: string | null }>
    >(`${API_ROUTES.APPLICATIONS.LIST}/${appId}/chat/history`);
  },

  async publishApplication(appId: string) {
    return baseService.post(API_ROUTES.APPLICATIONS.PUBLISH(appId), null);
  },

  /** Upload logo as multipart/form-data — FormData detected automatically by base service */
  async uploadLogo(appId: string, file: File) {
    const formData = new FormData();
    formData.append("file", file);
    return baseService.post(API_ROUTES.APPLICATIONS.LOGO(appId), formData);
  },

  async deleteChatSession(appId: string, sessionId: string) {
    return baseService.delete(
      API_ROUTES.APPLICATIONS.CHAT_SESSION(appId, sessionId),
    );
  },

  async renameChatSession(appId: string, sessionId: string, title: string) {
    return baseService.patch(
      API_ROUTES.APPLICATIONS.CHAT_SESSION_TITLE(appId, sessionId),
      { title },
    );
  },

  /** Catalog lookups (designations, business-units, skills, tags, etc.) */
  async getCatalog(name: string) {
    return baseService.get<unknown[]>(API_ROUTES.APPLICATIONS.CATALOG(name));
  },

  async getApprovalQueue() {
    return baseService.get<ApprovalQueueItem[]>(
      API_ROUTES.APPLICATIONS.APPROVAL_QUEUE,
    );
  },

  async approveApplication(appId: string) {
    return baseService.post<Application>(
      API_ROUTES.APPLICATIONS.APPROVE(appId),
      null,
    );
  },

  async rejectApplication(appId: string, comment?: string) {
    return baseService.post<Application>(
      API_ROUTES.APPLICATIONS.REJECT(appId),
      {
        comment: comment ?? null,
      },
    );
  },

  async getContextLedger(
    appId: string,
    options?: { sessionId?: string; refresh?: boolean },
  ) {
    const params = new URLSearchParams();
    if (options?.sessionId) params.set("session_id", options.sessionId);
    if (options?.refresh) params.set("refresh", "true");
    const query = params.toString();
    return baseService.get<ContextLedger>(
      `${API_ROUTES.APPLICATIONS.CONTEXT_LEDGER(appId)}${query ? `?${query}` : ""}`,
    );
  },

  // /** Owner action — puts a rejected application back in the queue. */
  // async resubmitApplication(appId: string) {
  //   return baseService.post<Application>(
  //     API_ROUTES.APPLICATIONS.RESUBMIT(appId),
  //     null,
  //   );
  // },
};
