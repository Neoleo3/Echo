/**
 * Authentication API service
 */

import { API_ROUTES } from "@/config";
import { baseService } from "./base.service";
import type { User } from "@/types";

export const authService = {
  async login(credentials: string) {
    return baseService.post<User>(
      `${API_ROUTES.AUTH.LOGIN}${credentials}`,
      null,
    );
  },

  async logout() {
    return baseService.post(API_ROUTES.AUTH.LOGOUT);
  },

  async refreshToken() {
    return baseService.post<User>(API_ROUTES.AUTH.REFRESH, {
      additionalProp1: {},
    });
  },
};
