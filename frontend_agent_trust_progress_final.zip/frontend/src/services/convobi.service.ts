import {
  ConvoBIResponse,
  DBConnectionsResponse,
  SchemaDoc,
  SchemaSummary,
} from "@/types/convobi.types";
import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";

type schematype = "db" | "file";

export const convoBIService = {
  async getDBConnectors() {
    return baseService.get<DBConnectionsResponse>(API_ROUTES.CONVOBI.DB_LIST);
  },
  async getRecommendedQuestions(payload: Record<string, unknown>) {
    return baseService.post<unknown>(API_ROUTES.CONVOBI.RECOMMENDED, payload);
  },
  async uploadFile(formData: FormData) {
    return baseService.post<{ file_id: string }>(
      API_ROUTES.CONVOBI.UPLOAD,
      formData,
    );
  },
  async getSchema(id: string, type: schematype) {
    return baseService.post<SchemaSummary>(
      API_ROUTES.CONVOBI.SCHEMA.SUMMARY,
      type === "file"
        ? {
            file_id: id,
          }
        : {
            connector_id: id,
          },
    );
  },
  async getSchemaDoc(id: string, type: schematype) {
    return baseService.post<SchemaDoc>(
      API_ROUTES.CONVOBI.SCHEMA.DOCUMENT,
      type === "file"
        ? {
            file_id: id,
          }
        : {
            connector_id: id,
          },
    );
  },
  async editSchemaDoc(
    connectorId: string,
    fileId: string | null,
    payload: Record<string, unknown>,
  ) {
    const param = fileId ? `file_id=${fileId}` : `connection_id=${connectorId}`;
    return baseService.put<unknown>(
      `${API_ROUTES.CONVOBI.SCHEMA.DOC_EDIT}?${param}`,
      payload,
    );
  },
  async invoke(payload: Record<string, unknown>) {
    return baseService.post<ConvoBIResponse>(
      API_ROUTES.CONVOBI.INVOKE,
      payload,
      { handlepass: true },
    );
  },
};
