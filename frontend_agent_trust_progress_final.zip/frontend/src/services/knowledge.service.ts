import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type { KnowledgeSource } from "@/types";

interface PaginatedResponse<T> {
  page: number;
  page_size: number;
  total: number;
  items: T[];
}

export interface KnowledgeListResponse {
  items: KnowledgeSource[];
  total?: number;
}

export type KnowledgeListPayload =
  | PaginatedResponse<KnowledgeSource>
  | KnowledgeListResponse
  | KnowledgeSource[];

const isPaginatedKnowledgeList = (
  payload: KnowledgeListPayload,
): payload is PaginatedResponse<KnowledgeSource> =>
  typeof payload === "object" &&
  payload !== null &&
  Array.isArray((payload as { items?: unknown }).items) &&
  typeof (payload as { page?: unknown }).page === "number";

export interface KnowledgeListMeta {
  page: number;
  pageSize: number;
  total: number;
}

export const extractKnowledgeItems = (
  payload: KnowledgeListPayload | undefined,
): KnowledgeSource[] => {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  return payload.items ?? [];
};

export const extractKnowledgeMeta = (
  payload: KnowledgeListPayload | undefined,
  fallbackPage = 1,
  fallbackPageSize = 20,
): KnowledgeListMeta => {
  if (!payload) {
    return { page: fallbackPage, pageSize: fallbackPageSize, total: 0 };
  }
  if (Array.isArray(payload)) {
    return {
      page: fallbackPage,
      pageSize: fallbackPageSize,
      total: payload.length,
    };
  }
  if (isPaginatedKnowledgeList(payload)) {
    return {
      page: payload.page,
      pageSize: payload.page_size,
      total: payload.total ?? payload.items.length,
    };
  }
  return {
    page: fallbackPage,
    pageSize: fallbackPageSize,
    total: payload.total ?? payload.items.length,
  };
};

export interface KnowledgeStats {
  total_sources: number;
  synced: number;
  total_documents: number;
  total_chunks: number;
}

export const knowledgeService = {
  async getKnowledge(page = 1, pageSize = 20, search?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    return baseService.get<KnowledgeListPayload>(
      `${API_ROUTES.KNOWLEDGE.LIST}?${params.toString()}`,
    );
  },

  async getStats() {
    return baseService.get<KnowledgeStats>(API_ROUTES.KNOWLEDGE.STATS);
  },

  async getModels() {
    return baseService.get<{ models: unknown[] }>(API_ROUTES.KNOWLEDGE.MODELS);
  },

  /** FormData detected automatically by base service */
  async createKnowledge(formData: FormData) {
    return baseService.post<{ id: string; message?: string }>(
      API_ROUTES.KNOWLEDGE.LIST,
      formData,
    );
  },

  async deleteKnowledge(id: string) {
    return baseService.delete(API_ROUTES.KNOWLEDGE.DELETE(id));
  },
};
