import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type { AppNotification } from "@/types";

export const notificationsService = {
  async getNotifications() {
    return baseService.get<AppNotification[]>(API_ROUTES.NOTIFICATIONS.LIST);
  },

  async getUnreadCount() {
    return baseService.get<{ count: number }>(
      API_ROUTES.NOTIFICATIONS.UNREAD_COUNT,
    );
  },

  async markRead(notificationId: string) {
    return baseService.post<{ ok: boolean }>(
      API_ROUTES.NOTIFICATIONS.MARK_READ(notificationId),
      null,
    );
  },

  async markAllRead() {
    return baseService.post<{ marked: number }>(
      API_ROUTES.NOTIFICATIONS.MARK_ALL_READ,
      null,
    );
  },
};
