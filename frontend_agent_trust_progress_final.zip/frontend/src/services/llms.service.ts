import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";
import type { LLMModel, LlmProviderCatalogEntry, LlmTestResult } from "@/types";

export interface AddModelResult {
  success: boolean;
  message: string;
  model_id: string;
  credential_id: string;
  is_default: boolean;
}

export const llmsService = {
  async getModels() {
    return baseService.get<{
      models: LLMModel[];
      providers?: LlmProviderCatalogEntry[];
    }>(API_ROUTES.LLMS.LIST);
  },

  async getProviderCatalog() {
    return baseService.get<{ providers: LlmProviderCatalogEntry[] }>(
      API_ROUTES.LLMS.PROVIDER_CATALOG,
    );
  },

  async addModel(data: Partial<LLMModel>) {
    return baseService.post<AddModelResult>(API_ROUTES.LLMS.ADD, data);
  },

  async updateModel(id: string, data: Partial<LLMModel>) {
    return baseService.put<{ success: boolean; is_default: boolean }>(
      API_ROUTES.LLMS.UPDATE(id),
      data,
    );
  },

  async deleteModel(id: string) {
    return baseService.delete(API_ROUTES.LLMS.DELETE(id));
  },

  async setDefault(credentialId: string) {
    return baseService.patch<{ credential_id: string; is_default: boolean }>(
      API_ROUTES.LLMS.SET_DEFAULT(credentialId),
      {},
    );
  },

  async setDefaultEmbedding(credentialId: string) {
    return baseService.patch<{
      credential_id: string;
      is_default_embedding: boolean;
    }>(API_ROUTES.LLMS.SET_DEFAULT_EMBEDDING(credentialId), {});
  },

  async testConnection(credentialId: string, prompt?: string) {
    return baseService.post<LlmTestResult>(
      API_ROUTES.LLMS.TEST(credentialId),
      prompt ? { prompt } : {},
    );
  },
};
