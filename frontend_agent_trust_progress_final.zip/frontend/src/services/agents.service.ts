/**
 * Agents API service
 */

import {
  AgentDefinition,
  AgentDesignRequest,
  AgentDesignResponse,
  AgentDraft,
  AgentFile,
  AgentFilesResponse,
  AgentConnectorsResponse,
  AgentKnowledgeBasesResponse,
  AgentRegisterResponse,
  AttachConnectorRequest,
  AttachedConnector,
  AvailableConnectorGroups,
  AvailableToolsResponse,
  MarkitdownStatus,
  ReadinessReport,
  ReadinessSettings,
} from "@/types/agents.types";
import { baseService } from "./base.service";
import { API_ROUTES } from "@/config";

interface PaginatedResponse<T> {
  page: number;
  page_size: number;
  total: number;
  items: T[];
}

export interface LegacyAgentListResponse {
  agents?: AgentDefinition[];
  total?: number;
}

export type AgentListPayload =
  | PaginatedResponse<AgentDefinition>
  | LegacyAgentListResponse
  | AgentDefinition[];

const isPaginatedAgentList = (
  payload: AgentListPayload,
): payload is PaginatedResponse<AgentDefinition> =>
  typeof payload === "object" &&
  payload !== null &&
  Array.isArray((payload as { items?: unknown }).items);

const isLegacyAgentList = (
  payload: AgentListPayload,
): payload is LegacyAgentListResponse =>
  typeof payload === "object" &&
  payload !== null &&
  Array.isArray((payload as { agents?: unknown }).agents);

export interface AgentListMeta {
  page: number;
  pageSize: number;
  total: number;
}

export const extractAgentItems = (
  payload: AgentListPayload | undefined,
): AgentDefinition[] => {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  if (isPaginatedAgentList(payload)) return payload.items;
  if (isLegacyAgentList(payload)) return payload.agents ?? [];
  return [];
};

export const extractAgentMeta = (
  payload: AgentListPayload | undefined,
  fallbackPage = 1,
  fallbackPageSize = 20,
): AgentListMeta => {
  if (!payload) {
    return { page: fallbackPage, pageSize: fallbackPageSize, total: 0 };
  }
  if (Array.isArray(payload)) {
    return {
      page: fallbackPage,
      pageSize: fallbackPageSize,
      total: payload.length,
    };
  }
  if (isPaginatedAgentList(payload)) {
    return {
      page: payload.page ?? fallbackPage,
      pageSize: payload.page_size ?? fallbackPageSize,
      total: payload.total ?? payload.items.length,
    };
  }
  return {
    page: fallbackPage,
    pageSize: fallbackPageSize,
    total: payload.total ?? payload.agents?.length ?? 0,
  };
};

/**
 * Fold the builder's fields onto the stored definition.
 *
 * The builder owns Tier 1 — name, description, instructions, tools and the
 * model binding. Everything else on the definition belongs to another surface
 * (connectors, the connector gate, files, knowledge bases, readiness,
 * required inputs) or to the backend itself (`metadata.config_chat`, which is
 * the builder conversation transcript). None of it may be dropped just
 * because the form that triggered the save does not display it.
 *
 * `metadata` merges rather than replaces, so a save never truncates the
 * config-chat history the backend keeps there.
 */
function mergeAgentDraft(
  stored: AgentDefinition,
  draft: AgentDraft,
): AgentDraft {
  const storedMetadata =
    stored.metadata && typeof stored.metadata === "object"
      ? stored.metadata
      : {};
  const draftMetadata =
    draft.metadata && typeof draft.metadata === "object" ? draft.metadata : {};

  return {
    ...stored,
    ...draft,
    metadata: { ...storedMetadata, ...draftMetadata },
  };
}

export const agentsService = {
  /** Every agent this user owns. */
  async listAgents(page = 1, pageSize = 20, search?: string) {
    const params = new URLSearchParams();
    params.append("page", String(page));
    params.append("page_size", String(pageSize));
    if (search?.trim()) {
      params.append("search", search.trim());
    }
    return baseService.get<AgentListPayload>(
      `${API_ROUTES.AGENTS.LIST}?${params.toString()}`,
    );
  },

  async getAgent(id: string) {
    return baseService.get<AgentDefinition>(API_ROUTES.AGENTS.DETAIL(id));
  },

  /**
   * Drive the agent-builder conversation.
   *
   * The frontend is a thin renderer here: the reply text is `reply`, and the
   * returned `agent_state` must be sent back verbatim on the next turn so the
   * conversation accumulates. Never apply instruction edits locally.
   */
  async designChat(payload: AgentDesignRequest) {
    return baseService.post<AgentDesignResponse>(
      API_ROUTES.AGENTS.DESIGN_CHAT,
      payload,
    );
  },

  /**
   * Persist an agent.
   *
   * This is the canonical persistence path — `/agents/save` wraps it, adding
   * a builder gate that also demands `output_format`, a scaffold key the
   * contract pops before writing and the user never edits. Registering
   * directly keeps the payload to what the definition actually stores.
   *
   * **A partial payload is destructive, so an existing agent is read and
   * merged first.** `normalize_agent_definition` rebuilds every capability
   * field from whatever it is handed — an absent `connector_settings` becomes
   * `{enabled: false}`, and absent `connectors` / `files` /
   * `knowledge_sources` become `[]` — and the result replaces the stored
   * definition outright. The builder only ever edits a handful of Tier 1
   * fields, so it has to send back everything else it does not own.
   */
  async registerAgent(draft: AgentDraft) {
    const agentId = typeof draft.agent_id === "string" ? draft.agent_id : "";
    if (!agentId) {
      /* A new agent has nothing to preserve. */
      return baseService.post<AgentRegisterResponse>(
        API_ROUTES.AGENTS.REGISTER,
        draft,
      );
    }

    const current = await this.getAgent(agentId);
    if (!current.success || !current.data) {
      return {
        success: false as const,
        data: undefined,
        error:
          current.error ??
          "Could not read the agent before saving it. Nothing was changed.",
      };
    }

    return baseService.post<AgentRegisterResponse>(
      API_ROUTES.AGENTS.REGISTER,
      mergeAgentDraft(current.data, draft),
    );
  },

  /** Get all tools available to be assigned to agents */
  async getAvailableTools() {
    return baseService.get<AvailableToolsResponse>(
      API_ROUTES.AGENTS.AVAILABLE_TOOLS,
    );
  },

  /**
   * Update an agent.
   *
   * `data` must be the **complete** definition, not a patch — see
   * {@link updateReadiness} for why a partial is destructive here.
   */
  async updateAgent(id: string, data: AgentDefinition) {
    return baseService.put(API_ROUTES.AGENTS.UPDATE(id), data);
  },

  async deleteAgent(id: string) {
    return baseService.delete(API_ROUTES.AGENTS.DELETE(id));
  },

  /* ---------------- Readiness (Phase 7) ---------------- */

  /** `grade` runs the LLM sufficiency stage — one model call. Off by default,
   *  because opening the builder should not spend one. */
  async getReadiness(
    id: string,
    options?: { grade?: boolean; requestText?: string },
  ) {
    const params = new URLSearchParams();
    if (options?.grade) params.set("grade", "true");
    if (options?.requestText) params.set("request_text", options.requestText);
    const query = params.toString();
    return baseService.get<ReadinessReport>(
      `${API_ROUTES.AGENTS.READINESS(id)}${query ? `?${query}` : ""}`,
    );
  },

  /**
   * Readiness is written through the normal agent update — there is no
   * dedicated endpoint. Omitting `mode` means "follow the platform default".
   *
   * **The whole definition is re-sent, never a partial.** `PUT /agents/{id}`
   * merges through the registry only on the filesystem path; with
   * `AGENT_DB_WRITE_ONLY` on — which is the default — it persists
   * `{...updates, agent_id}` verbatim, so posting `{readiness}` alone would
   * replace the agent with just that key and lose its name, instructions and
   * tools. Reading first and merging is what makes this safe.
   */
  async updateReadiness(id: string, readiness: ReadinessSettings) {
    const current = await this.getAgent(id);
    if (!current.success || !current.data) {
      return {
        success: false as const,
        data: undefined,
        error: current.error ?? "Could not read the agent before updating it.",
      };
    }
    return baseService.put(API_ROUTES.AGENTS.UPDATE(id), {
      ...current.data,
      readiness: { ...(current.data.readiness ?? {}), ...readiness },
    });
  },

  /* ---------------- Connectors (Phase 5b.2) ---------------- */

  /** The gate defaults to **off**; every attach returns 409 while it is
   *  closed, so a picker that ignores this will look broken. */
  async setConnectorSettings(id: string, enabled: boolean) {
    return baseService.put(API_ROUTES.AGENTS.CONNECTOR_SETTINGS(id), {
      enabled,
    });
  },

  /** Listing is deliberately not gated, so the picker can show the options
   *  behind a disabled control. */
  async getAvailableConnectors(id: string) {
    return baseService.get<AvailableConnectorGroups>(
      API_ROUTES.AGENTS.CONNECTORS_AVAILABLE(id),
    );
  },

  /** Returns an envelope — `{agent_id, connector_settings, connectors, count}` —
   *  not a bare array. */
  async getConnectors(id: string) {
    return baseService.get<AgentConnectorsResponse>(
      API_ROUTES.AGENTS.CONNECTORS(id),
    );
  },

  /** Attach is an idempotent upsert — editing is a re-POST of the same
   *  `connector_id`. There is no PATCH. */
  async attachConnector(id: string, payload: AttachConnectorRequest) {
    return baseService.post<AttachedConnector>(
      API_ROUTES.AGENTS.CONNECTORS(id),
      payload,
    );
  },

  async detachConnector(id: string, connectorId: string) {
    return baseService.delete(
      API_ROUTES.AGENTS.CONNECTOR_DETACH(id, connectorId),
    );
  },

  /* ---------------- Files and knowledge bases (Phase 6) ---------------- */

  /** Ingest is asynchronous — every entry returns `pending`. Poll
   *  {@link getFiles} while any entry is `pending` or `processing`. */
  async uploadFiles(id: string, files: File[]) {
    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    return baseService.post<AgentFilesResponse>(
      API_ROUTES.AGENTS.FILES(id),
      formData,
    );
  },

  /** A 422 means the address was refused; its `detail` is written for the
   *  user and can be shown verbatim. */
  async attachUrl(id: string, url: string, name?: string) {
    return baseService.post<AgentFile>(API_ROUTES.AGENTS.FILE_URL(id), {
      url,
      name,
    });
  },

  async getFiles(id: string) {
    return baseService.get<AgentFilesResponse>(API_ROUTES.AGENTS.FILES(id));
  },

  /** *Re-read* for a file, *Re-fetch* for a URL. */
  async refreshFile(id: string, fileId: string) {
    return baseService.post(API_ROUTES.AGENTS.FILE_REFRESH(id, fileId), null);
  },

  /** Works whether or not the connector-settings toggle is on. */
  async deleteFile(id: string, fileId: string) {
    return baseService.delete(API_ROUTES.AGENTS.FILE_DELETE(id, fileId));
  },

  /** Envelope: `{knowledge_bases: [...]}`. */
  async getAvailableKnowledgeBases(id: string) {
    return baseService.get<AgentKnowledgeBasesResponse>(
      API_ROUTES.AGENTS.KNOWLEDGE_BASES_AVAILABLE(id),
    );
  },

  /** Envelope: `{agent_id, connector_settings, knowledge_bases, count}`. */
  async getKnowledgeBases(id: string) {
    return baseService.get<AgentKnowledgeBasesResponse>(
      API_ROUTES.AGENTS.KNOWLEDGE_BASES(id),
    );
  },

  /** Idempotent — re-posting updates the alias. */
  async linkKnowledgeBase(id: string, knowledgeBaseId: string, alias?: string) {
    return baseService.post(API_ROUTES.AGENTS.KNOWLEDGE_BASES(id), {
      knowledge_base_id: knowledgeBaseId,
      alias,
    });
  },

  async unlinkKnowledgeBase(id: string, knowledgeBaseId: string) {
    return baseService.delete(
      API_ROUTES.AGENTS.KNOWLEDGE_BASE_DETACH(id, knowledgeBaseId),
    );
  },

  /** When `markitdown_installed` is false, uploads will fail — say so before
   *  the user drags a file in rather than after. */
  async getMarkitdownStatus() {
    return baseService.get<MarkitdownStatus>(
      API_ROUTES.AGENTS.MARKITDOWN_STATUS,
    );
  },
};
