export const ROUTES = {
  LOGIN: "/",
  AGREEMENT: "/",
  HOME: "/echo/home",
  CHAT: "/echo/chat",
  CONFIG: "/echo/config",
  APPLICATION: "/echo/config/app-studio",
  LIBRARY: "/echo/library",
  CONVOBI: "/echo/convobi",
  SUPPORT: "/echo/support",
  DOCUMENTATION: "/echo/documentation",
  MONITORING: "/echo/monitoring",
  LLM: "/echo/config/llm_config",
  AGENTS: "/echo/config/agents",
  CONNECTORS: "/echo/config/connectors",
  WORKFLOW: "/echo/config/workflows",
  KNOWELDGE: "/echo/config/knowledge",
  USER: "/echo/config/users",
  AGENT_TRUST: "/echo/agent_trust",
  SETTING: "/echo/setting",
} as const;

export const API_ROUTES = {
  AUTH: {
    LOGIN: "/sessions/login?email=",
    LOGOUT: "/sessions/logout?session_id=",
    REFRESH: "/sessions/refresh",
  },
  APPLICATIONS: {
    LIST: "/api/applications",
    VISIBLE: "/api/applications/visible",

    // Chat Session Endpoints

    Chat_SESSION_DOC: (id: string, sessionId: string) =>
      `/api/applications/${id}/chat/sessions/${sessionId}/documents`,
    CHAT_SESSION: (appId: string, sessionId: string) =>
      `/api/applications/${appId}/chat/sessions/${sessionId}`,
    CHAT_UPLOAD: (id: string) => `/api/applications/${id}/chat/upload`,
    CHAT_STREAM: (appId: string) => `/api/applications/${appId}/chat/stream`,

    CATALOG: (name: string) => `/api/${name}`,

    APPROVAL_QUEUE: "/api/applications/approval-queue",
    APPROVE: (appId: string) => `/api/applications/${appId}/approve`,
    REJECT: (appId: string) => `/api/applications/${appId}/reject`,
    // RESUBMIT: (appId: string) => `/api/applications/${appId}/resubmit-approval`,

    CONTEXT_LEDGER: (appId: string) =>
      `/api/applications/${appId}/context-ledger`,

    // DONE

    CHAT_SESSION_TITLE: (appId: string, sessionId: string) =>
      `/api/applications/${appId}/chat/sessions/${sessionId}/title`,
    LOGO: (appId: string) => `/api/applications/${appId}/logo`,
    PUBLISH: (appId: string) => `/api/applications/${appId}/publish`,
  },
  MONITORING: {
    USAGE: "/api/analytics/model-consumption",
  },
  CONVOBI: {
    DB_LIST: "/connectors/db/list",
    RECOMMENDED: "/convobi/recommended-questions",
    UPLOAD: "/convobi/files/upload",
    SCHEMA: {
      SUMMARY: "/convobi/schema",
      DOCUMENT: "/convobi/schema/doc",
      DOC_EDIT: "/convobi/schema/doc/edit",
    },
    INVOKE: "/convobi/invoke",
  },
  AGENTS: {
    DESIGN_CHAT: "/agents/design/chat",
    AVAILABLE_TOOLS: "/agents/available-tools",
    LIST: "/agents/list",
    REGISTER: "/agents/register",
    SAVE: "/agents/save",
    DESIGN_PROMPT: "/agents/design/prompt",
    DETAIL: (id: string) => `/agents/${id}`,
    UPDATE: (id: string) => `/agents/${id}`,
    DELETE: (id: string) => `/agents/${id}`,
    READINESS: (id: string) => `/agents/${id}/readiness`,
    CONNECTOR_SETTINGS: (id: string) => `/agents/${id}/connector-settings`,
    CONNECTORS_AVAILABLE: (id: string) => `/agents/${id}/connectors/available`,
    CONNECTORS: (id: string) => `/agents/${id}/connectors`,
    CONNECTOR_DETACH: (id: string, connectorId: string) =>
      `/agents/${id}/connectors/${connectorId}`,
    FILES: (id: string) => `/agents/${id}/files`,
    FILE_URL: (id: string) => `/agents/${id}/files/url`,
    FILE_DELETE: (id: string, fileId: string) =>
      `/agents/${id}/files/${fileId}`,
    FILE_REFRESH: (id: string, fileId: string) =>
      `/agents/${id}/files/${fileId}/refresh`,
    KNOWLEDGE_BASES: (id: string) => `/agents/${id}/knowledge-bases`,
    KNOWLEDGE_BASES_AVAILABLE: (id: string) =>
      `/agents/${id}/knowledge-bases/available`,
    KNOWLEDGE_BASE_DETACH: (id: string, kbId: string) =>
      `/agents/${id}/knowledge-bases/${kbId}`,
    MARKITDOWN_STATUS: "/agents/markitdown/status",
  },
  LLMS: {
    LIST: "/LLMs/models/list",
    ADD: "/LLMs/add-custom-model",
    UPDATE: (id: string) => `/LLMs/update-model/${id}`,
    DELETE: (id: string) => `/LLMs/models?model_id=${encodeURIComponent(id)}`,
    PROVIDER_CATALOG: "/LLMs/providers/catalog",
    SET_DEFAULT: (credentialId: string) =>
      `/LLMs/credentials/${credentialId}/set-default`,
    SET_DEFAULT_EMBEDDING: (credentialId: string) =>
      `/LLMs/credentials/${credentialId}/set-default-embedding`,
    TEST: (credentialId: string) => `/LLMs/credentials/${credentialId}/test`,
  },
  CONNECTORS: {
    MCP: {
      LIST: "/connectors/mcp/list",
      CREATE: "/connectors/mcp/create",
      UPDATE: "/connectors/mcp/update",
      DELETE: "/connectors/mcp/delete",
      REFRESH: (id: string) => `/connectors/mcp/${id}/refresh-discovery`,
      POOL_STATUS: "/connectors/mcp/pool/status",
    },
    API: {
      LIST: "/connectors/api/list",
      CREATE: "/connectors/api/create",
      DELETE: "/connectors/api/delete",
      TEST: "/connectors/api/test",
    },
    DB: {
      LIST: "/connectors/db/list",
      SUPPORTED: "/connectors/db/supported",
      CONNECT: "/connectors/db/connect",
      CONNECT_FILE: "/connectors/db/connect-with-file",
      DELETE: (id: string) => `/connectors/db/${id}`,
      TEST: "/connectors/db/test",
    },
    CHANNEL: {
      LIST: "/connectors/channel/list",
      CREATE: "/connectors/channel/create",
      DELETE: (id: string) => `/connectors/channel/${id}`,
    },
  },
  KNOWLEDGE: {
    LIST: "/knowledge/",
    STATS: "/knowledge/stats",
    MODELS: "/knowledge/models",
    DELETE: (id: string) => `/knowledge/${id}`,
  },
  WORKFLOWS: {
    DELETE: (id: string) => `/workflows/${id}`,
    DETAIL: (id: string) => `/workflows/${id}`,
    DRAFT_LIST: "/workflows/draft/list",
    DESIGN_PROMPT: "/workflows/design/prompt",
    DESIGN_CATALOG: "/workflows/design/prompt?catalog_only=true",
    DESIGN_MODIFY: "/workflows/design/modify",
    CANVAS_SAVE: "/workflows/canvas/save",
    TO_CANVAS: "/workflows/backend/to-canvas",
    FINAL_SAVE: "/workflows/final/save",
    GRAPH: (id: string) => `/workflows/${id}/graph`,
    VERSIONS: (id: string) => `/workflows/${id}/versions`,
    CLONE: "/workflows/clone",
    EXECUTE: (id: string) => `/workflows/${id}/execute`,
    CHAT_START: "/workflows/chat/start",
    CHAT_SEND: "/workflows/chat/send",
    CHAT_HISTORY: (sessionId: string) => `/workflows/chat/history/${sessionId}`,
    EXECUTION_STEPS: (runId: string) => `/workflows/execution/${runId}/steps`,
    HITL_DECIDE: "/workflows/hitl/decide",
    HITL_STATUS: (runId: string) => `/workflows/hitl/status/${runId}`,
    HITL_CONTEXT: (runId: string) => `/workflows/hitl/context/${runId}`,
    HITL_DECISIONS: (runId: string) => `/workflows/hitl/decisions/${runId}`,
    HITL_PENDING: "/workflows/hitl/pending",
  },
  USERS: {
    LIST: "/api/admin/users",
    CREATE: "/api/admin/users",
    UPDATE: (id: string) => `/api/admin/users/${id}`,
    DELETE: (id: string) => `/api/admin/users/${id}`,
    // TOKEN_ALLOCATIONS: "/api/analytics/user-token-allocations?active_only=true",
    // TOKEN_FORM_OPTIONS: "/api/analytics/user-token-allocations/form-options",
    // TOKEN_DELETE: (id: string) => `/api/analytics/user-token-allocations/${id}`,
  },
  NOTIFICATIONS: {
    LIST: "/api/notifications",
    UNREAD_COUNT: "/api/notifications/unread-count",
    MARK_READ: (id: string) => `/api/notifications/${id}/read`,
    MARK_ALL_READ: "/api/notifications/mark-all-read",
  },
  DESIGNATIONS: {
    LIST: "/api/designations",
    CREATE: "/api/designations",
    DELETE: (id: string) => `/api/designations/${id}`,
  },
  BUSINESS_UNITS: {
    LIST: "/api/business-units",
    CREATE: "/api/business-units",
    DELETE: (id: string) => `/api/business-units/${id}`,
  },
} as const;

export const STORAGE_KEYS = {
  SESSION: "echoai-session",
  THEME: "echoai-theme",
  AGREEMENT: "echoai-agreement-accepted",
  ACCESS_TOKEN: "EchoAccessToken",
  SESSION_EXPIRY: "EchoSessionExpiry",
  IS_EXPIRED: "EchoisExpired",
  OTP_ENTERED: "EchoAIisOtpEnter",
  LOGIN_ID: "echoai-login-id",
} as const;

export const AUTH_CONFIG = {
  SESSION_TIMEOUT: 60 * 60 * 5000, // 1hr
  REFRESH_TIMEOUT: 55 * 60 * 5000, // 55min
  SESSION_CHECK_INTERVAL: 60 * 1000, // 1min
  ACTIVITY_UPDATE_INTERVAL: 10 * 1000, // throttle
} as const;

export const AUTH_ROLES = {
  USER: "user",
  ADMIN: "admin",
  SUPER_ADMIN: "super_admin",
} as const;
