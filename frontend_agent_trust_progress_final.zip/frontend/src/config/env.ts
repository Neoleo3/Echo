const BACKEND_ORIGIN =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "https://ecoapilwebapp02-ash2f8e6fcgzexgq.centralindia-01.azurewebsites.net";

const ENCRYPTION_KEY =
  process.env.NEXT_PUBLIC_ENCRYPTION_KEY ?? "CHANGE-ME-IN-PRODUCTION";

export const ENV = {
  API_BASE_URL: BACKEND_ORIGIN,
  BACKEND_BASE_URL: `${BACKEND_ORIGIN}/api/v1`,
  WS_BASE_URL: BACKEND_ORIGIN.replace(/^http/, "ws"),
  ENCRYPTION_KEY,
  ENVIRONMENT: process.env.NODE_ENV ?? "development",
} as const;