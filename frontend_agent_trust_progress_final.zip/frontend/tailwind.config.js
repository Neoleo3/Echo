// tailwind.config.js
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef2ff",
          100: "#e0e7ff",
          200: "#c7d2fe",
          300: "#a5b4fc",
          400: "#818cf8",
          500: "#6366f1",
          600: "#4f46e5",
        },
      },
      keyframes: {
        shimmer: {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(100%)" },
        },
        "spin-slow": {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" },
        },
        wave: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "pulse-soft": {
          "0%,100%": { opacity: 0.35 },
          "50%": { opacity: 1 },
        },
      },
      animation: {
        shimmer: "shimmer 1.8s ease-in-out infinite",
        "spin-slow": "spin-slow 6s linear infinite",
        float: "float 3s ease-in-out infinite",
        wave: "wave 8s linear infinite",
        "wave-slow": "wave 14s linear infinite",
        "pulse-soft": "pulse-soft 2.4s ease-in-out infinite",
      },
      // fontfamily: {
      //   courier: ['"Courier New"', "Courier", "monospce"],
      // },
    },
  },
  plugins: [],
};
