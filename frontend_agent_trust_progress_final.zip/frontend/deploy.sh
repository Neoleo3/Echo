#!/bin/bash

# Navigate to the code directory
cd  /home/ubuntu/ECHO/APP/echo-app || { echo "Failed to navigate to code folder"; exit 1; }

# Install npm dependencies
npm install || { echo "npm install failed"; exit 1; }

# Build the application
npm run build || { echo "npm run build failed"; exit 1; }

# Check if the application is already running with PM2
pm2 describe ECHO-APP > /dev/null

if [ $? -eq 0 ]; then
  # If the application is running, reload it
  pm2 reload ECHO-APP || { echo "pm2 reload failed"; exit 1; }
else
  # If the application is not running, start it
  pm2 start npm --name ECHO-APP -- run start || { echo "pm2 start failed"; exit 1; }
fi

echo "Deployment completed successfully."