# Agent Trust backend bundle (incremental review + SSE)

This bundle contains only the Agent Trust service and app modules. It does not include or replace other EchoAI backend packages.

## Main changes

- Incremental review logic in `echolib/service/agent_trust/review_service.py`:
  - unchanged, fully passing reviews are skipped;
  - failed functional cases/security probes and failed policy evaluations can be retried;
  - passing functional cases, security probes, and policy evaluations are reused where the existing data supports it;
  - applicable policies and a grounded functional suite are selected/generated automatically on first review when absent.
- `testing_service.py`: review-triggered functional generation requests exactly one grounded question; review-triggered security testing generates one grounded prompt per security category, reusing those prompts while the agent evidence fingerprint is unchanged. Manual red-team execution keeps its existing static payload behavior.
- `policy_service.py`: persists per-agent policy/judge prompts with AI assignments, excludes Cost Governance from prompt generation, invalidates affected review state when policy definitions/assignments change, and uses nested savepoints for policy-result writes to avoid rolling back the caller's full session.
- `echolib/models/agent_trust.py`: includes the targeted Agent Trust model correction for `PolicyEvaluation` so it does not map inherited timestamp columns that are absent from that table.
- `apps/agent_trust/routes/actions.py`: adds SSE and status endpoints without changing the existing POST `/agent-trust/review` response contract.

## Review API

1. `POST /agent-trust/review` returns `202` with a `correlation_id` immediately.
2. `GET /agent-trust/reviews/{correlation_id}/events` streams Server-Sent Events (`review`, `progress`, `completed`, `failed`).
3. `GET /agent-trust/reviews/{correlation_id}` returns the current status/latest progress/result.

Progress events include fields such as `stage`, `status`, `agent_id`, and optionally `message`, `trust_score`, or `trust_state`. Status values include `running`, `completed`, `failed`, `skipped`, and `not_verified` depending on the stage.

The SSE route is protected with the same `require_admin_or_above` dependency and additionally checks that the requesting user initiated the review and still has ownership access to its agents. When using bearer-token authentication, the frontend should use `fetch()` streaming so it can attach the Authorization header; native `EventSource` cannot set arbitrary authorization headers.

## Important deployment limitation

Progress/status history is held in process memory to avoid introducing a database table or migration outside the supplied Agent Trust modules. Live SSE and reconnect replay work while the review remains in the same application process. If the service runs multiple workers/instances or must survive process restarts, use a shared broker or durable status store (e.g. Redis or a dedicated Agent Trust review-run table) before relying on cross-worker reconnect recovery.

## Scope and safety

No non-Agent-Trust routes, scoring implementation, general telemetry modules, migrations, or other backend functionality are included in this bundle. The only model file included is the targeted Agent Trust model file noted above. Existing production execution safety checks are retained. Review callbacks are best-effort and do not fail the review if progress delivery fails.
