"""
Agent Trust dependency injection.

Mirrors the lightweight ``container.resolve('x.y')`` pattern used by
``apps/chat`` and other apps -- no framework, just a tiny registry so routes
don't construct services inline. All business logic lives in
``echolib/service/agent_trust`` (shared library, reusable outside this app).
"""

from __future__ import annotations

from typing import Dict

from echolib.service.agent_trust.agent_registry_service import AgentRegistryService
from echolib.service.agent_trust.audit_service import AuditService
from echolib.service.agent_trust.cost_service import CostService
from echolib.service.agent_trust.identity_service import IdentityService
from echolib.service.agent_trust.policy_service import PolicyService
from echolib.service.agent_trust.review_service import ReviewService
from echolib.service.agent_trust.testing_service import TestingService

_services: Dict[str, object] = {}


def _build() -> None:
    if _services:
        return
    _services["agent_trust.registry"] = AgentRegistryService()
    _services["agent_trust.policy"] = PolicyService()
    _services["agent_trust.identity"] = IdentityService()
    _services["agent_trust.testing"] = TestingService()
    _services["agent_trust.cost"] = CostService()
    _services["agent_trust.audit"] = AuditService()
    _services["agent_trust.review"] = ReviewService()


def resolve(name: str):
    _build()
    return _services[name]
