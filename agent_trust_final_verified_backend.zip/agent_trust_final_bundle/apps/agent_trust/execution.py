"""Agent Trust execution and production-like context reconstruction.

Agent Trust never executes a workflow or application just to test one agent.
It reconstructs the input contract that the target agent would receive and
then invokes the existing AgentRuntime/AgentFactory chat path.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from uuid import uuid4
import asyncio

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent, Application, ApplicationSkillLink, Workflow
from echolib.models.connectors import APIConnectorRecord
from echolib.service.agent_trust.judge_llm import ask_judge, JudgeParseError
from echolib.telemetry_context import telemetry_context

logger = logging.getLogger(__name__)
AGENT_TRUST_EXECUTION_TIMEOUT_SECONDS = 20


@dataclass
class AgentTestContext:
    message: str
    runtime_context: Dict[str, Any] = field(default_factory=dict)
    source: str = "standalone"
    source_id: Optional[str] = None
    state: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentExecutionResult:
    executed: bool
    status: str
    agent_id: str
    execution_run_id: str
    response: Optional[str] = None
    source: str = "standalone"
    source_id: Optional[str] = None
    error: Optional[str] = None
    context: Optional[AgentTestContext] = None


class AgentTrustContextBuilder:
    """Builds a realistic target-agent input without running its container."""

    async def build(
        self,
        db: AsyncSession,
        *,
        agent: Agent,
        test_input: str,
        user_id: str,
        review_id: Optional[str] = None,
        test_run_id: Optional[str] = None,
    ) -> AgentTestContext:
        if agent.source_workflow_id:
            # Agent.source_workflow_id stores Workflow.workflow_id (UUID),
            # while Workflow.hexaid is the string primary key. Do not pass
            # the UUID to Session.get(), which targets hexaid and causes
            # asyncpg "expected str, got UUID" failures.
            stmt = select(Workflow).where(
                Workflow.workflow_id == agent.source_workflow_id,
                Workflow.is_deleted.is_(False),
            )
            workflow = (await db.execute(stmt)).scalar_one_or_none()
            if workflow is not None:
                return await self._build_workflow_context(
                    workflow,
                    agent,
                    test_input,
                    user_id=user_id,
                    review_id=review_id,
                    test_run_id=test_run_id,
                )

        app = await self._find_application(db, agent.hexaid)
        if app is not None:
            return await self._build_app_context(
                app,
                agent,
                test_input,
                user_id=user_id,
                review_id=review_id,
                test_run_id=test_run_id,
            )

        return AgentTestContext(
            message=test_input,
            runtime_context=self._runtime_context(
                user_id=user_id,
                review_id=review_id,
                test_run_id=test_run_id,
                source="standalone",
            ),
            source="standalone",
            state={"original_user_input": test_input},
        )

    async def _find_application(self, db: AsyncSession, agent_id: str) -> Optional[Application]:
        stmt = (
            select(Application)
            .join(ApplicationSkillLink, ApplicationSkillLink.application_id == Application.application_id)
            .where(
                ApplicationSkillLink.skill_type == "agent",
                ApplicationSkillLink.skill_id == str(agent_id),
                Application.is_deleted.is_(False),
            )
            .order_by(Application.updated_at.desc())
        )
        return (await db.execute(stmt)).scalars().first()

    async def _build_workflow_context(
        self,
        workflow: Workflow,
        agent: Agent,
        test_input: str,
        *,
        user_id: str,
        review_id: Optional[str],
        test_run_id: Optional[str],
    ) -> AgentTestContext:
        definition = workflow.definition or {}
        target = self._find_agent_config(definition, agent.hexaid, str(agent.agent_id)) or dict(agent.definition or {})
        state_schema = definition.get("state_schema") or {}
        input_schema = target.get("input_schema") or []

        state = await self._synthesize_state(
            source="workflow",
            test_input=test_input,
            agent_definition=target,
            state_schema=state_schema,
            input_schema=input_schema,
            workflow_definition=definition,
            user_id=user_id,
        )
        state["original_user_input"] = test_input
        state["user_input"] = test_input
        state["task_description"] = test_input

        # Use the exact task-construction semantics used by the workflow runtime.
        from apps.workflow.runtime.langchain_adapter import build_agent_task

        message = build_agent_task(target, state)
        runtime_context = self._runtime_context(
            user_id=user_id,
            review_id=review_id,
            test_run_id=test_run_id,
            source="workflow",
            source_id=str(workflow.workflow_id),
        )
        runtime_context["workflow_id"] = str(workflow.workflow_id)
        runtime_context["agent_trust_state"] = state

        return AgentTestContext(
            message=message,
            runtime_context=runtime_context,
            source="workflow",
            source_id=str(workflow.workflow_id),
            state=state,
        )

    async def _build_app_context(
        self,
        app: Application,
        agent: Agent,
        test_input: str,
        *,
        user_id: str,
        review_id: Optional[str],
        test_run_id: Optional[str],
    ) -> AgentTestContext:
        config = app.config or {}
        canvas = config.get("canvas_config") or config.get("canvas") or []
        target_component = None
        for component in canvas if isinstance(canvas, list) else []:
            if not isinstance(component, dict):
                continue
            props = component.get("props") or {}
            if (
                component.get("type") == "agent_trigger"
                and str(props.get("agent_id") or "") == str(agent.hexaid)
            ):
                target_component = component
                break

        state = await self._synthesize_state(
            source="app",
            test_input=test_input,
            agent_definition=agent.definition or {},
            state_schema={},
            input_schema=(target_component or {}).get("props", {}).get("input_keys", [])
            if target_component
            else [],
            workflow_definition={
                "application_name": app.name,
                "application_description": app.description,
                "welcome_prompt": app.welcome_prompt,
                "persona_text": app.persona_text,
                "guardrail_text": app.guardrail_text,
                "config": config,
            },
            user_id=user_id,
        )

        if target_component:
            props = target_component.get("props") or {}
            input_keys = props.get("input_keys") or []
            message = self._build_app_agent_input(input_keys, state)
        else:
            # Standard AppMgr applications select an agent as a skill and pass
            # the current application step input to the same standalone runtime.
            # Preserve the application-level context without pretending to run
            # the planner/orchestrator.
            message = test_input

        runtime_context = self._runtime_context(
            user_id=user_id,
            review_id=review_id,
            test_run_id=test_run_id,
            source="app",
            source_id=str(app.application_id),
        )
        runtime_context["application_context"] = {
            "application_id": str(app.application_id),
            "application_name": app.name,
            "description": app.description,
            "welcome_prompt": app.welcome_prompt,
            "persona_text": app.persona_text,
            "guardrail_text": app.guardrail_text,
        }
        runtime_context["agent_trust_state"] = state

        return AgentTestContext(
            message=message,
            runtime_context=runtime_context,
            source="app",
            source_id=str(app.application_id),
            state=state,
        )

    async def _synthesize_state(
        self,
        *,
        source: str,
        test_input: str,
        agent_definition: Dict[str, Any],
        state_schema: Dict[str, Any],
        input_schema: Any,
        workflow_definition: Dict[str, Any],
        user_id: str,
    ) -> Dict[str, Any]:
        schema_keys = list(state_schema.keys()) if isinstance(state_schema, dict) else []
        if isinstance(input_schema, list):
            schema_keys.extend(str(x) for x in input_schema if isinstance(x, str))
        schema_keys = list(dict.fromkeys(schema_keys))[:50]

        # No external data is supplied to this model. It may create only
        # synthetic values required to exercise the known contract.
        prompt = {
            "source": source,
            "test_input": test_input,
            "agent": {
                "name": agent_definition.get("name"),
                "instructions": agent_definition.get("instructions") or agent_definition.get("prompt"),
                "input_schema": agent_definition.get("input_schema", []),
                "output_schema": agent_definition.get("output_schema", []),
            },
            "known_state_schema": {k: state_schema.get(k) for k in schema_keys},
            "known_input_fields": schema_keys,
            "source_definition": workflow_definition,
        }
        system = (
            "You are generating a synthetic runtime state for an AI-agent test. "
            "Use ONLY the supplied configuration and test input. Never invent real "
            "customer records, credentials, API responses, database rows, URLs, "
            "secrets, or external-system facts. Create synthetic placeholder data "
            "only where a known field requires a value. Preserve field names, types, "
            "and relationships. Return ONLY a JSON object containing state fields. "
            "Do not add explanatory text."
        )
        try:
            result = await ask_judge(
                component="agent_trust_context_builder",
                system_prompt=system,
                user_prompt=json.dumps(prompt, default=str),
                user_id=user_id,
            )
            if isinstance(result, dict):
                return result
        except (JudgeParseError, Exception):
            logger.exception("Agent Trust synthetic context generation failed")

        # Deterministic fallback. This never fabricates external values.
        state: Dict[str, Any] = {}
        for key in schema_keys:
            schema = state_schema.get(key) if isinstance(state_schema, dict) else {}
            state[key] = self._placeholder_for(key, schema)
        return state

    @staticmethod
    def _placeholder_for(key: str, schema: Any) -> Any:
        kind = str(schema.get("type") if isinstance(schema, dict) else "string").lower()
        if kind in {"integer", "number"}:
            return 1
        if kind == "boolean":
            return True
        if kind == "array":
            return []
        if kind == "object":
            return {}
        return f"TEST_{key.upper()}"

    @staticmethod
    def _find_agent_config(value: Any, *agent_ids: str) -> Optional[Dict[str, Any]]:
        wanted = {str(x) for x in agent_ids if x}
        if isinstance(value, dict):
            if str(value.get("agent_id") or "") in wanted:
                return value
            for child in value.values():
                found = AgentTrustContextBuilder._find_agent_config(child, *agent_ids)
                if found:
                    return found
        elif isinstance(value, list):
            for child in value:
                found = AgentTrustContextBuilder._find_agent_config(child, *agent_ids)
                if found:
                    return found
        return None

    @staticmethod
    def _build_app_agent_input(input_keys: List[str], state: Dict[str, Any]) -> str:
        if input_keys:
            parts = []
            for key in input_keys:
                value = state.get(key)
                if value is not None:
                    if isinstance(value, (dict, list)):
                        parts.append(f"{key}: {json.dumps(value, indent=2)}")
                    else:
                        parts.append(f"{key}: {value}")
            return "\n".join(parts) or "No input data provided."
        return "\n".join(
            f"{k}: {json.dumps(v, indent=2) if isinstance(v, (dict, list)) else v}"
            for k, v in state.items()
            if v is not None
        ) or "No input data provided."

    @staticmethod
    def _runtime_context(*, user_id: str, review_id: Optional[str], test_run_id: Optional[str], source: str, source_id: Optional[str] = None) -> Dict[str, Any]:
        context = {
            "user_id": user_id,
            "agent_trust_review_id": review_id or str(uuid4()),
            "agent_trust_test_run_id": test_run_id,
            "agent_trust_execution_run_id": str(uuid4()),
            "agent_trust_source": source,
        }
        if source_id:
            context["agent_trust_source_id"] = source_id
        return {k: v for k, v in context.items() if v is not None}


class AgentTrustExecutor:
    """Runs the target agent through the same runtime as Agent Chat."""

    def __init__(self, context_builder: Optional[AgentTrustContextBuilder] = None) -> None:
        self._context_builder = context_builder or AgentTrustContextBuilder()

    async def execute(
        self,
        db: AsyncSession,
        *,
        agent: Agent,
        test_input: str,
        user_id: str,
        review_id: Optional[str] = None,
        test_run_id: Optional[str] = None,
    ) -> AgentExecutionResult:
        execution_id = str(uuid4())
        context = await self._context_builder.build(
            db,
            agent=agent,
            test_input=test_input,
            user_id=user_id,
            review_id=review_id,
            test_run_id=test_run_id,
        )

        safe, reason = await self._production_execution_allowed(db, agent, user_id)
        if not safe:
            logger.warning(
                "Agent Trust execution blocked: agent_id=%s source=%s reason=%s",
                agent.hexaid, context.source, reason,
            )
            return AgentExecutionResult(
                executed=False,
                status="not_verified",
                agent_id=agent.hexaid,
                execution_run_id=execution_id,
                source=context.source,
                source_id=context.source_id,
                error=reason,
                context=context,
            )

        from echolib.di import container

        factory = container.resolve("agent.factory")
        definition = agent.to_dict()
        runtime = factory.create_agent(
            definition,
            bind_tools=True,
            user_id=user_id,
        )
        # AgentRuntime.chat is the exact execution surface used by
        # POST /agents/{agent_id}/chat. No workflow or application is executed.
        context.runtime_context["agent_trust_execution_run_id"] = execution_id
        try:
            with telemetry_context(
                agent_trust_agent_id=agent.hexaid,
                agent_trust_review_id=review_id,
                agent_trust_test_run_id=test_run_id,
                agent_trust_execution_run_id=execution_id,
            ):
                response = await self._run_chat(
                    runtime,
                    message=context.message,
                    context=context.runtime_context,
                    user_id=user_id,
                )
            text = response.get("content", "") if isinstance(response, dict) else str(response)
            return AgentExecutionResult(
                executed=True,
                status="executed",
                agent_id=agent.hexaid,
                execution_run_id=execution_id,
                response=text,
                source=context.source,
                source_id=context.source_id,
                context=context,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "Agent Trust execution timed out for agent %s after %ss",
                agent.hexaid,
                AGENT_TRUST_EXECUTION_TIMEOUT_SECONDS,
            )
            return AgentExecutionResult(
                executed=False,
                status="timeout",
                agent_id=agent.hexaid,
                execution_run_id=execution_id,
                source=context.source,
                source_id=context.source_id,
                error=(
                    f"Agent execution exceeded the {AGENT_TRUST_EXECUTION_TIMEOUT_SECONDS}s "
                    "Agent Trust timeout."
                ),
                context=context,
            )
        except Exception as exc:
            logger.exception("Agent Trust execution failed for agent %s", agent.hexaid)
            return AgentExecutionResult(
                executed=False,
                status="failed",
                agent_id=agent.hexaid,
                execution_run_id=execution_id,
                source=context.source,
                source_id=context.source_id,
                error=str(exc),
                context=context,
            )

    @staticmethod
    async def _run_chat(runtime: Any, *, message: str, context: Dict[str, Any], user_id: str) -> Any:
        import asyncio
        return await asyncio.wait_for(
            asyncio.to_thread(
                runtime.chat,
                message=message,
                context=context,
                user_id=user_id,
            ),
            timeout=AGENT_TRUST_EXECUTION_TIMEOUT_SECONDS,
        )

    async def _production_execution_allowed(
        self,
        db: AsyncSession,
        agent: Agent,
        user_id: str,
    ) -> tuple[bool, str]:
        connectors = (agent.definition or {}).get("connectors") or []
        for connector in connectors:
            if not isinstance(connector, dict):
                return False, "Unknown connector configuration"
            kind = str(connector.get("kind") or "").lower()
            level = str(connector.get("access_level") or "read_only").lower()
            if kind == "mcp":
                return False, "MCP connectors are not eligible for automatic production Agent Trust execution"
            if kind == "database" and level != "read_only":
                return False, "Database connector is not explicitly read-only"
            if kind == "api":
                connector_id = connector.get("connector_id") or connector.get("id")
                if not connector_id or level != "read_only":
                    return False, "API connector is not explicitly read-only"
                stmt = select(APIConnectorRecord).where(
                    APIConnectorRecord.user_id == agent.user_id,
                    APIConnectorRecord.connector_id == str(connector_id),
                )
                record = (await db.execute(stmt)).scalars().first()
                method = str((record.config_json if record else {}).get("method") or "").upper()
                if method != "GET":
                    return False, "API connector is not explicitly GET-only"
        return True, ""
