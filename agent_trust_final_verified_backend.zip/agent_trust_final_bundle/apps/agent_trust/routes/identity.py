"""Identity & Trust routes (Phase 3) -- on-demand only."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from echolib.database import get_db_session
from echolib.security import require_admin_or_above
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import _normalize

router = APIRouter(prefix="/identity", tags=["Agent Trust"])


@router.post("/agents/{agent_id}/evaluate")
async def evaluate_identity(agent_id: str, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.identity")
    registry = container.resolve("agent_trust.registry")
    hexaid = _normalize(agent_id)
    async with get_db_session() as db:
        result = await service.evaluate(db, agent_id=hexaid)
        if result.get("error"):
            raise HTTPException(status_code=404, detail=result["error"])
        profile = await registry._get_profile(db, hexaid)  # clear staleness flag
        if profile:
            profile.identity_stale = False
        await db.commit()
        return result


@router.get("/agents/{agent_id}/latest",include_in_schema=False,)
async def latest_identity(agent_id: str, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.identity")
    hexaid = _normalize(agent_id)
    async with get_db_session() as db:
        snapshot = await service.latest_snapshot(db, agent_id=hexaid)
        if snapshot is None:
            raise HTTPException(status_code=404, detail="No identity evaluation yet")
        return snapshot.to_dict()
