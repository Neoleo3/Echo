"""Testing & QA routes (Phase 4) -- on-demand only."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from echolib.database import get_db_session
from echolib.security import require_admin_or_above
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import _normalize
from apps.agent_trust.schemas.schemas import(AcceptRecommendedSuiteRequest)

router = APIRouter(prefix="/testing", tags=["Agent Trust"])


class SuiteCreate(BaseModel):
    name: str
    description: Optional[str] = None
    suite_type: str = "functional"
    test_cases: List[Dict[str, Any]] = []


class RedTeamRequest(BaseModel):
    attack_types: Optional[List[str]] = None

@router.post(
    "/agents/{agent_id}/recommended-suite"
)
async def generate_recommended_suite(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve(
        "agent_trust.testing"
    )

    hexaid = _normalize(agent_id)

    async with get_db_session() as db:

        return await service.generate_recommended_suite(
            db,
            agent_id=hexaid,
            user_id=user.user_id,
        )
@router.post(
    "/agents/{agent_id}/recommended-suite/accept"
)
async def accept_recommended_suite(
    agent_id: str,
    payload: AcceptRecommendedSuiteRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve(
        "agent_trust.testing"
    )

    hexaid = _normalize(agent_id)

    async with get_db_session() as db:

        result = await service.accept_recommended_suite(
            db,
            agent_id=hexaid,
            questions=payload.questions,
        )

        await db.commit()

        return result
@router.get("/suites")
async def list_suites(suite_type: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    async with get_db_session() as db:
        return [s.to_dict() for s in await service.list_suites(db, suite_type=suite_type)]


@router.post("/suites")
async def create_suite(payload: SuiteCreate, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    async with get_db_session() as db:
        suite = await service.create_suite(db, **payload.model_dump())
        await db.commit()
        return suite.to_dict()


@router.post("/suites/{suite_id}/run")
async def run_suite(suite_id: UUID, agent_id: str, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    registry = container.resolve("agent_trust.registry")
    hexaid = _normalize(agent_id)
    async with get_db_session() as db:
        try:
            run = await service.run_suite(db, suite_id=suite_id, agent_id=hexaid,user_id=user.user_id, triggered_by="manual")
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        profile = await registry._get_profile(db, hexaid)
        if profile:
            profile.testing_stale = False
        await db.commit()
        return run.to_dict()


@router.post("/agents/{agent_id}/red-team")
async def run_red_team(agent_id: str, payload: RedTeamRequest, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    registry = container.resolve("agent_trust.registry")
    hexaid = _normalize(agent_id)
    async with get_db_session() as db:
        try:
            results = await service.run_red_team(db, agent_id=hexaid,user_id=user.user_id, attack_types=payload.attack_types)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        profile = await registry._get_profile(db, hexaid)
        if profile:
            profile.testing_stale = False
        await db.commit()
        return [r.to_dict() for r in results]


@router.get("/red-team/results")
async def list_red_team_results(agent_id: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    hexaid = _normalize(agent_id) if agent_id else None
    async with get_db_session() as db:
        return [r.to_dict() for r in await service.list_red_team_results(db, agent_id=hexaid)]


@router.get("/stats")
async def testing_stats(agent_id: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.testing")
    hexaid = _normalize(agent_id) if agent_id else None
    async with get_db_session() as db:
        return await service.get_stats(db, agent_id=hexaid)


@router.get("/security/catalog")
async def security_catalog():
    service = container.resolve("agent_trust.testing")
    return await service.get_security_catalog()

@router.get(
    "/agents/{agent_id}/assigned-suites"
)
async def assigned_suites(
    agent_id: str,
    user: UserContext = Depends(
        require_admin_or_above
    ),
):
    service = container.resolve(
        "agent_trust.testing"
    )

    hexaid = _normalize(agent_id)

    async with get_db_session() as db:

        suites = await service.list_agent_suites(
            db,
            hexaid,
        )

        return [
            {
                "suite_id": str(suite.id),
                "name": suite.name,
                "description": suite.description,
                "test_count": len(
                    suite.test_cases
                ),
                "is_seeded": suite.is_seeded,
            }
            for suite in suites
        ]