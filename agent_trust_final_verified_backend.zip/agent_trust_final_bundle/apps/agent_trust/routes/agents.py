"""
Agent Trust read API.

Six endpoints cover the whole product surface: a portfolio dashboard, the
agent list, and four per-agent views. Nothing here exposes a governance
module -- policies, testing, security, credentials and cost are aggregated
into the agent views they belong to.
"""

from __future__ import annotations

import logging
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query

from echolib.database import get_db_session
from echolib.id_utils import normalize_to_uuid
from echolib.security import require_admin_or_above, resolve_user_id
from echolib.service.agent_trust.audit_service import ALL_CATEGORIES
from echolib.service.agent_trust.cost_service import USAGE_WINDOWS
from echolib.types import UserContext, UserRole

from apps.agent_trust import container
from apps.agent_trust.schemas import (
    AgentListResponse,
    AgentOverviewResponse,
    AgentReviewResponse,
    AgentUsage,
    DashboardResponse,
    TimelineResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Agent Trust"])


def normalize_agent_id(agent_id: str) -> str:
    """Accept any agent id spelling used on the platform and resolve to hexaid."""
    try:
        return UUID(normalize_to_uuid(agent_id)).hex
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail=f"Invalid agent id: {agent_id}")


def _owner_scope(user: UserContext, scope: str) -> Optional[str]:
    """
    ``scope=all`` lifts the owner filter and is reserved for super admins --
    everyone else always sees only their own agents.
    """
    if scope == "all":
        if user.role != UserRole.super_admin.value:
            raise HTTPException(
                status_code=403,
                detail="scope=all is available to super admins only",
            )
        return None
    return resolve_user_id(user)


@router.get("/dashboard")
async def dashboard(
    scope: str = Query("mine", pattern="^(mine|all)$"),
    user: UserContext = Depends(require_admin_or_above),
):
    review = container.resolve("agent_trust.review")

    async with get_db_session() as db:
        data = await review.get_dashboard(
            db,
            owner_user_id=_owner_scope(user, scope),
        )

    return DashboardResponse(**data)


@router.get(
    "/agents",
    response_model=AgentListResponse,
    summary="List agents with their trust score",
)
async def list_agents(
    scope: str = Query("mine", pattern="^(mine|all)$"),
    search: Optional[str] = Query(None, max_length=255),
    trust_state: Optional[str] = Query(
        None, pattern="^(UNREVIEWED|TRUSTED|NEEDS_REVIEW|HIGH_RISK)$"
    ),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user: UserContext = Depends(require_admin_or_above),
) -> AgentListResponse:
    registry = container.resolve("agent_trust.registry")
    async with get_db_session() as db:
        data = await registry.list_agents(
            db,
            owner_user_id=_owner_scope(user, scope),
            search=search,
            trust_state=trust_state,
            limit=limit,
            offset=offset,
        )
    return AgentListResponse(**data)


@router.get(
    "/agents/{agent_id}",
    response_model=AgentOverviewResponse,
    summary="Agent overview",
)
async def agent_overview(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
) -> AgentOverviewResponse:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        review = container.resolve("agent_trust.review")

        await registry.validate_owner(db, hexaid, user)
        try:
            data = await review.get_overview(db, agent_id=hexaid)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        return AgentOverviewResponse(**data)


@router.get("/agents/{agent_id}/security")
async def agent_security(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        review = container.resolve("agent_trust.review")

        await registry.validate_owner(db, hexaid, user)
        try:
            data = await review.get_review(db, agent_id=hexaid)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        return {
            "agent_id": hexaid,
            "policies": data["policies"],
            "security": data["security"],
        }


@router.get("/agents/{agent_id}/policies")
async def agent_policies(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        review = container.resolve("agent_trust.review")

        await registry.validate_owner(db, hexaid, user)
        try:
            data = await review.get_review(db, agent_id=hexaid)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        return {
            "agent_id": hexaid,
            "policies": data["policies"],
        }


@router.get("/agents/{agent_id}/functional-tests")
async def agent_functional_tests(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
):
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        review = container.resolve("agent_trust.review")

        await registry.validate_owner(db, hexaid, user)
        try:
            data = await review.get_review(db, agent_id=hexaid)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        return {
            "agent_id": hexaid,
            "test_suites": data["test_suites"],
        }


@router.get(
    "/agents/{agent_id}/review",
    response_model=AgentReviewResponse,
    summary="Agent review workspace",
)
async def agent_review(
    agent_id: str,
    user: UserContext = Depends(require_admin_or_above),
) -> AgentReviewResponse:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        review = container.resolve("agent_trust.review")

        await registry.validate_owner(db, hexaid, user)
        try:
            data = await review.get_review(db, agent_id=hexaid)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        return AgentReviewResponse(**data)


@router.get(
    "/agents/{agent_id}/timeline",
    response_model=TimelineResponse,
    summary="Agent event chain",
)
async def agent_timeline(
    agent_id: str,
    category: Optional[List[str]] = Query(
        None,
        description=f"Any of {', '.join(ALL_CATEGORIES)}. Defaults to everything except 'run'.",
    ),
    cursor: Optional[int] = Query(None, ge=1, description="seq of the last entry already seen"),
    limit: int = Query(50, ge=1, le=200),
    user: UserContext = Depends(require_admin_or_above),
) -> TimelineResponse:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)

        if category:
            unknown = sorted(set(category) - set(ALL_CATEGORIES))
            if unknown:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unknown timeline category: {', '.join(unknown)}",
                )

        registry = container.resolve("agent_trust.registry")
        audit = container.resolve("agent_trust.audit")

        await registry.validate_owner(db, hexaid, user)
        data = await audit.get_timeline(
            db,
            agent_id=hexaid,
            categories=category,
            before_seq=cursor,
            limit=limit,
        )
        return TimelineResponse(**data)


@router.get(
    "/agents/{agent_id}/usage",
    response_model=AgentUsage,
    summary="Live token and cost consumption",
)
async def agent_usage(
    agent_id: str,
    window: str = Query("all", pattern="^(24h|7d|30d|all)$"),
    user: UserContext = Depends(require_admin_or_above),
) -> AgentUsage:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        cost = container.resolve("agent_trust.cost")

        await registry.validate_owner(db, hexaid, user)
        if window not in USAGE_WINDOWS:
            raise HTTPException(status_code=400, detail=f"Unsupported window: {window}")

        data = await cost.get_agent_usage(db, agent_id=hexaid, window=window)
        return AgentUsage(**data)
