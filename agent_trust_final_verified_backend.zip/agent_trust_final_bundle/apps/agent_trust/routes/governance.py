"""Governance Review & Score routes (Phase 7) + cross-module dashboard."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from echolib.database import get_db_session
from echolib.security import require_admin_or_above, require_super_admin
from echolib.types import UserContext

from echolib.service.agent_trust.governance_review_service import GovernanceReviewService
from apps.agent_trust import container
from apps.agent_trust.routes.agents import _normalize
import logging
from apps.agent_trust.schemas.schemas import (
    GovernanceInventoryRequest,
)
logger = logging.getLogger(__name__)
from echolib.security import (
    require_admin_or_above,
    require_super_admin,
    require_user,
)
router = APIRouter(prefix="/governance", tags=["Agent Trust"])
from apps.agent_trust.schemas.schemas import (
    ReviewAgentRequest,
    TrustAssessmentResponse,
    TrustHistoryItemResponse,
    TrustProfileResponse,
    ReviewRequest
)
from echolib.security import (
    require_admin_or_above,
    require_super_admin,
)
from sqlalchemy.ext.asyncio import AsyncSession
# @router.post("/agents/review", include_in_schema=False,)
# async def review_agents(
#     payload: ReviewAgentRequest,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     service = container.resolve(
#         "agent_trust.governance"
#     )

#     registry = container.resolve(
#         "agent_trust.registry"
#     )

#     async with get_db_session() as db:

#         normalized_ids = [
#             _normalize(agent_id)
#             for agent_id in payload.agent_ids
#         ]

#         for hexaid in normalized_ids:

#             await registry.validate_owner(
#                 db,
#                 agent_id=hexaid,
#                 user=user,
#             )

#         if len(normalized_ids) == 1:

#             result = await service.review_agent(
#                 db,
#                 agent_id=normalized_ids[0],
#                 user_id=user.user_id,
#             )

#         else:

#             result = await service.review_agents(
#                 db,
#                 agent_ids=normalized_ids,
#                 user_id=user.user_id,
#             )

#         await db.commit()

#         return result
# @router.post("/agents/{agent_id}/review", include_in_schema=False,)
# async def review_agent(
#     agent_id: str,
#     user: UserContext = Depends(require_admin_or_above),
# ):
#     service = container.resolve("agent_trust.governance")
#     registry = container.resolve("agent_trust.registry")

#     hexaid = _normalize(agent_id)

#     async with get_db_session() as db:
#         await registry.validate_owner(
#             db,
#             agent_id=hexaid,
#             user=user,
#         )

#         result = await service.review_agent(
#             db,
#             agent_id=hexaid,
#             user_id=user.user_id,
#         )

#         profile = await registry._get_profile(
#             db,
#             hexaid,
#         )

#         if profile:
#             profile.trust_score = result["score"]

#         await db.commit()

#         return result
@router.post("/review")
async def review(
    payload: ReviewRequest,
    user: UserContext = Depends(
        require_admin_or_above,
    ),
):

    governance = container.resolve(
        "agent_trust.governance"
    )

    registry = container.resolve(
        "agent_trust.registry"
    )

    async with get_db_session() as db:

        agent_ids = [
            _normalize(x)
            for x in payload.agent_ids
        ]

        logger.info(
            "agent_trust_review_started",
            extra={
                "user_id": user.user_id,
                "agent_count": len(agent_ids),
                "checks": payload.checks,
            },
        )

        for agent_id in agent_ids:

            await registry.validate_owner(
                db,
                agent_id,
                user,
            )

        result = await governance.review_agents(
            db,
            agent_ids=agent_ids,
            user_id=user.user_id,
            checks=payload.checks,
        )

        await db.commit()

        logger.info(
            "agent_trust_review_completed",
            extra={
                "user_id": user.user_id,
                "agent_count": len(agent_ids),
            },
        )

        return result
@router.get("/dashboard/stats",include_in_schema=False,)
async def dashboard_stats(user: UserContext = Depends(require_admin_or_above)):
    registry = container.resolve("agent_trust.registry")
    policy = container.resolve("agent_trust.policy")
    alert = container.resolve("agent_trust.alert")
    cost = container.resolve("agent_trust.cost")
    testing = container.resolve("agent_trust.testing")
    audit = container.resolve("agent_trust.audit")

    async with get_db_session() as db:
        return {
            "agents": await registry.get_user_stats(
                db,
                owner_user_id=user.user_id,
            ),
            "policies": await policy.get_stats(db),
            "alerts": await alert.get_stats(db),
            "cost": await cost.get_stats(db),
            "testing": await testing.get_stats(db),
            "audit": await audit.get_stats(db),
        }

@router.get("/agents/{agent_id}/security")
async def get_security_details(
    agent_id: str,
):
    service = GovernanceReviewService()

    async with get_db_session() as db:
        return await service.get_security_details(
            db,
            agent_id,
        )

@router.get(
    "/agents/{agent_id}/functional"
)
async def get_functional_details(
    agent_id: str,
):
    service = GovernanceReviewService()

    async with get_db_session() as db:
        return await service.get_functional_details(
            db,
            agent_id,
        )
@router.get("/portfolio/summary",include_in_schema=False,)
async def portfolio_summary(
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve("agent_trust.governance")

    async with get_db_session() as db:
        return await service.get_portfolio_summary(
            db,owner_user_id=user.user_id,
        )

# High risk agents
@router.get("/portfolio/high-risk",include_in_schema=False,)
async def high_risk_agents(
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve("agent_trust.governance")

    async with get_db_session() as db:
        return await service.get_high_risk_agents(
            db,owner_user_id=user.user_id,
        )
# Review required agents
@router.get("/portfolio/review-required",include_in_schema=False,)
async def review_required_agents(
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve("agent_trust.governance")

    async with get_db_session() as db:
        return await service.get_review_required_agents(
            db,owner_user_id=user.user_id,
        )

@router.post("/inventory")
async def inventory(
    payload: GovernanceInventoryRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve(
        "agent_trust.governance"
    )

    async with get_db_session() as db:
        return await service.get_inventory(
            db,
            payload.agent_ids,
        )
@router.get("/dashboard")
async def dashboard(
    page: int = 1,
    page_size: int = 25,
    user: UserContext = Depends(require_user),
):

    governance_service = container.resolve(
        "agent_trust.governance"
    )

    registry_service = container.resolve(
        "agent_trust.registry"
    )

    async with get_db_session() as db:

        logger.info(
            "agent_trust_dashboard_requested",
            extra={
                "user_id": user.user_id,
            },
        )

        summary = (
            await governance_service.get_portfolio_summary(
                db,
                owner_user_id=user.user_id,
            )
        )

        high_risk = (
            await governance_service.get_high_risk_agents(
                db,
                owner_user_id=user.user_id,
            )
        )

        review_required = (
            await governance_service.get_review_required_agents(
                db,
                owner_user_id=user.user_id,
            )
        )

        offset = (page - 1) * page_size
        agents = await registry_service.list_agents(
            db,
            owner_user_id=user.user_id,
            limit=page_size,
            offset=offset,
        )

        result = {
            "summary": summary,
            "high_risk_agents": high_risk,
            "review_required_agents": review_required,

            "pagination": {
                "page": page,
                "page_size": page_size,
                "total_records": summary["total_agents"],
                "total_pages": (
                    (
                        summary["total_agents"]
                        + page_size
                        - 1
                    )
                    // page_size
                ),
            },

            "agents": agents,
        }

        logger.info(
            "agent_trust_dashboard_generated",
            extra={
                "user_id": user.user_id,
                "total_agents": len(
                    agents,
                ),
                "high_risk": len(
                    high_risk,
                ),
                "review_required": len(
                    review_required,
                ),
            },
        )

        return result

@router.get(
    "/dashboard/trends"
)
async def dashboard_trends(
    user: UserContext = Depends(
        require_admin_or_above,
    ),
):

    service = container.resolve(
        "agent_trust.governance"
    )

    async with get_db_session() as db:

        return await service.get_portfolio_trends(
            db,
            owner_user_id=user.user_id,
        )
@router.get("/platform/agents")
async def platform_agents(
    limit: int = 1000,
    offset: int = 0,
    user: UserContext = Depends(require_super_admin),
):
    registry = container.resolve(
        "agent_trust.registry"
    )

    async with get_db_session() as db:
        return await registry.list_all_agents(
            db,
            limit=limit,
            offset=offset,
        )