"""Policy Engine + Alerts routes (Phase 2)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict

from echolib.database import get_db_session
from echolib.security import require_admin_or_above
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import normalize_agent_id
from apps.agent_trust.schemas.schemas import RecommendPoliciesRequest
from echolib.service.agent_trust.policy_service import PolicyRecommendationService
from sqlalchemy.ext.asyncio import AsyncSession
router = APIRouter(prefix="/policies", tags=["Agent Trust"])
alerts_router = APIRouter(prefix="/alerts", tags=["Agent Trust"])


class PolicyCreate(BaseModel):

    model_config = ConfigDict(
        extra="forbid"
    )

    name: str
    description: Optional[str] = None
    framework: Optional[str] = None

    severity: str = "medium"

    policy_prompt: Optional[str] = None
    judge_prompt: Optional[str] = None

    is_system_policy: bool = False
    is_active: bool = True

class PolicyUpdate(BaseModel):

    model_config = ConfigDict(
        extra="forbid"
    )

    name: Optional[str] = None
    description: Optional[str] = None
    framework: Optional[str] = None

    severity: Optional[str] = None

    policy_prompt: Optional[str] = None
    judge_prompt: Optional[str] = None

    is_active: Optional[bool] = None

class EvaluateRequest(BaseModel):
    agent_id: str
    text: str = ""
    resource: str = ""
    tools_used: List[str] = []
    model: str = ""

@router.get("/agents/{agent_id}/policies")
async def get_agent_policies(
    agent_id: str,
    user: UserContext = Depends(
        require_admin_or_above
    ),
):
    service = container.resolve(
        "agent_trust.policy"
    )
    registry = container.resolve(
        "agent_trust.registry"
    )
    hexaid = normalize_agent_id(agent_id)
    async with get_db_session() as db:

        await registry.validate_owner(
            db,
            agent_id=hexaid,
            user=user,
        )
        return await service.get_agent_policies(
            db,
            agent_id=hexaid,
        )
    
@router.get("")
async def list_policies(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    async with get_db_session() as db:
        return [p.to_dict() for p in await service.list_policies(db)]


@router.get("/rule-types",include_in_schema=False,)
async def list_rule_types(user: UserContext = Depends(require_admin_or_above)):
    from echolib.service.agent_trust.policy_service import RULE_TYPES

    return {"rule_types": list(RULE_TYPES.keys())}


@router.post("")
async def create_policy(payload: PolicyCreate, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    async with get_db_session() as db:
        policy = await service.create_policy(db, **payload.model_dump())
        await db.commit()
        return policy.to_dict()


@router.patch("/{policy_id}")
async def update_policy(policy_id: UUID, payload: PolicyUpdate, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    async with get_db_session() as db:
        policy = await service.update_policy(db, policy_id, **payload.model_dump(exclude_unset=True))
        if policy is None:
            raise HTTPException(status_code=404, detail="Policy not found")
        await db.commit()
        return policy.to_dict()


@router.delete("/{policy_id}")
async def delete_policy(policy_id: UUID, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    async with get_db_session() as db:
        ok = await service.delete_policy(db, policy_id)
        await db.commit()
        if not ok:
            raise HTTPException(status_code=404, detail="Policy not found")
        return {"status": "deleted"}


@router.post("/agents/{agent_id}/policies/recommend")
async def recommend_policies(
    agent_id: str,
    payload: RecommendPoliciesRequest,
    user: UserContext = Depends(require_admin_or_above),
):
    registry = container.resolve("agent_trust.registry")
    hexaid = normalize_agent_id(agent_id)
    async with get_db_session() as db:
        await registry.validate_owner(db, agent_id=hexaid, user=user)
        service = PolicyRecommendationService()
        return await service.recommend_policies_for_agent(
            db,
            agent_id=hexaid,
            user_id=str(user.user_id),
            force_refresh=payload.force_refresh,
        )


@router.post(
    "/agents/{agent_id}/policies/recommend/{recommendation_id}/accept"
)
async def accept_policy_recommendation(
    agent_id: str,
    recommendation_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
):
    registry = container.resolve("agent_trust.registry")
    service = PolicyRecommendationService()
    hexaid = normalize_agent_id(agent_id)

    async with get_db_session() as db:
        await registry.validate_owner(
            db,
            agent_id=hexaid,
            user=user,
        )

        try:
            recommendation = await service.accept_recommendation(
                db,
                recommendation_id,
                agent_id=hexaid,
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=404,
                detail=str(exc),
            )

        await db.commit()

        return {
            "recommendation_id": str(recommendation.id),
            "agent_id": hexaid,
            "accepted": True,
            "policy_ids": recommendation.recommended_policy_ids,
        }


@router.post("/agents/{agent_id}/policies/{policy_id}")
async def assign_policy_to_agent(
    agent_id: str,
    policy_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
):
    registry = container.resolve("agent_trust.registry")
    service = container.resolve("agent_trust.policy")
    hexaid = normalize_agent_id(agent_id)
    async with get_db_session() as db:
        await registry.validate_owner(db, agent_id=hexaid, user=user)
        link = await service.assign_policy(
            db, policy_id=policy_id, agent_id=hexaid, assigned_by="human"
        )
        await db.commit()
        return {
            "policy_id": str(policy_id),
            "agent_id": hexaid,
            "assigned_by": link.assigned_by,
            "status": "assigned",
        }


@router.delete("/agents/{agent_id}/policies/{policy_id}")
async def unassign_policy_from_agent(
    agent_id: str,
    policy_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
):
    registry = container.resolve("agent_trust.registry")
    service = container.resolve("agent_trust.policy")
    hexaid = normalize_agent_id(agent_id)
    async with get_db_session() as db:
        await registry.validate_owner(db, agent_id=hexaid, user=user)
        ok = await service.unassign_policy(db, policy_id=policy_id, agent_id=hexaid)
        await db.commit()
        if not ok:
            raise HTTPException(status_code=404, detail="Assignment not found")
        return {"status": "unassigned", "policy_id": str(policy_id), "agent_id": hexaid}




@router.post("/evaluate",include_in_schema=False,)
async def evaluate_policy(payload: EvaluateRequest, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    hexaid = normalize_agent_id(payload.agent_id)
    async with get_db_session() as db:
        result = await service.evaluate(
            db, agent_id=hexaid, text=payload.text, resource=payload.resource,
            tools_used=payload.tools_used, model=payload.model,
        )
        await db.commit()
        return result


@router.get("/violations")
async def list_violations(agent_id: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    hexaid = normalize_agent_id(agent_id) if agent_id else None
    async with get_db_session() as db:
        return [v.to_dict() for v in await service.list_violations(db, agent_id=hexaid)]


@router.get("/stats",include_in_schema=False,)
async def policy_stats(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.policy")
    async with get_db_session() as db:
        return await service.get_stats(db)


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------

class AlertAction(BaseModel):
    notes: Optional[str] = None


@alerts_router.get("")
async def list_alerts(
    status: Optional[str] = None, agent_id: Optional[str] = None,
    user: UserContext = Depends(require_admin_or_above),
):
    service = container.resolve("agent_trust.alert")
    hexaid = normalize_agent_id(agent_id) if agent_id else None
    async with get_db_session() as db:
        return [a.to_dict() for a in await service.list_alerts(db, status=status, agent_id=hexaid)]


@alerts_router.post("/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: UUID, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.alert")
    async with get_db_session() as db:
        alert = await service.acknowledge(db, alert_id, by=user.email or user.user_id)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        await db.commit()
        return alert.to_dict()


@alerts_router.post("/{alert_id}/resolve")
async def resolve_alert(alert_id: UUID, payload: AlertAction, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.alert")
    async with get_db_session() as db:
        alert = await service.resolve(db, alert_id, by=user.email or user.user_id, notes=payload.notes)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        await db.commit()
        return alert.to_dict()


@alerts_router.get("/stats")
async def alert_stats(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.alert")
    async with get_db_session() as db:
        return await service.get_stats(db)
