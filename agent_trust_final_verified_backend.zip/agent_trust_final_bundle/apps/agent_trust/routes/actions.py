"""Agent Trust write actions: one review pipeline and functional-suite management."""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Dict, List, Optional
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse

from echolib.database import get_db_session
from echolib.security import require_admin_or_above, resolve_user_id
from echolib.service.agent_trust.audit_service import EVENT_SUITE_ADDED, EVENT_SUITE_REMOVED
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import normalize_agent_id
from apps.agent_trust.schemas import (
    ReviewRequest,
    ReviewResponse,
    RecommendedSuiteResponse,
    TestSuiteCreateRequest,
    TestSuiteResponse,
    RecommendFunctionalSuiteRequest,
)

router = APIRouter(tags=["Agent Trust"])

# Keep detached review tasks strongly referenced until completion. This is
# intentionally separate from FastAPI BackgroundTasks: the HTTP response must
# return the correlation_id immediately and the review must continue after the
# request handler has returned.
_REVIEW_TASKS: set[asyncio.Task] = set()

# Lightweight in-process event broker. It does not add database tables or
# change review persistence. Review status and event history remain available
# for reconnects while this application process is alive.
_REVIEW_STATES: Dict[str, Dict[str, Any]] = {}
_REVIEW_SUBSCRIBERS: Dict[str, set[asyncio.Queue]] = {}
_REVIEW_STATE_LOCK = asyncio.Lock()
_MAX_REVIEW_STATES = 250
_MAX_REVIEW_EVENTS = 500
_TERMINAL_REVIEW_STATUSES = {"completed", "failed"}


async def _publish_review_event(
    correlation_id: str,
    event: str,
    **payload: Any,
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    async with _REVIEW_STATE_LOCK:
        state = _REVIEW_STATES.get(correlation_id)
        if state is None:
            return
        if event == "progress":
            state["status"] = "running"
        elif event in _TERMINAL_REVIEW_STATUSES:
            state["status"] = event
        elif event == "review":
            state["status"] = payload.get("status", state.get("status", "started"))
        state["updated_at"] = now
        if event in _TERMINAL_REVIEW_STATUSES:
            state["result"] = payload.get("result")
            state["error"] = payload.get("error")
        record = {
            "id": (state["events"][-1]["id"] + 1) if state["events"] else 1,
            "event": event,
            "correlation_id": correlation_id,
            "timestamp": now,
            **payload,
        }
        state["events"].append(record)
        if len(state["events"]) > _MAX_REVIEW_EVENTS:
            del state["events"][:-_MAX_REVIEW_EVENTS]
        for queue in tuple(_REVIEW_SUBSCRIBERS.get(correlation_id, set())):
            queue.put_nowait(record)


async def _initialize_review_state(
    correlation_id: str,
    *,
    agent_ids: List[str],
    user_id: str,
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    async with _REVIEW_STATE_LOCK:
        # Prune only terminal records; active reviews are never removed.
        if len(_REVIEW_STATES) >= _MAX_REVIEW_STATES:
            terminal = [
                (key, value.get("updated_at", ""))
                for key, value in _REVIEW_STATES.items()
                if value.get("status") in _TERMINAL_REVIEW_STATUSES
            ]
            for key, _ in sorted(terminal, key=lambda item: item[1])[: max(1, len(_REVIEW_STATES) - _MAX_REVIEW_STATES + 1)]:
                _REVIEW_STATES.pop(key, None)
                _REVIEW_SUBSCRIBERS.pop(key, None)
        _REVIEW_STATES[correlation_id] = {
            "correlation_id": correlation_id,
            "agent_ids": list(agent_ids),
            "user_id": user_id,
            "status": "started",
            "created_at": now,
            "updated_at": now,
            "result": None,
            "error": None,
            "events": [],
        }
        _REVIEW_SUBSCRIBERS.setdefault(correlation_id, set())
    await _publish_review_event(
        correlation_id,
        "review",
        status="started",
        agent_ids=list(agent_ids),
        message="Review accepted",
    )


async def _get_review_state(correlation_id: str) -> Optional[Dict[str, Any]]:
    async with _REVIEW_STATE_LOCK:
        state = _REVIEW_STATES.get(correlation_id)
        if state is None:
            return None
        return {**state, "events": list(state["events"])}


async def _authorize_review_state(correlation_id: str, user: UserContext) -> Dict[str, Any]:
    state = await _get_review_state(correlation_id)
    if state is None:
        raise HTTPException(
            status_code=404,
            detail="Review status is unavailable in this application process. Start a new review.",
        )
    if state["user_id"] != resolve_user_id(user):
        raise HTTPException(status_code=404, detail="Review not found")
    async with get_db_session() as db:
        registry = container.resolve("agent_trust.registry")
        for agent_id in state["agent_ids"]:
            await registry.validate_owner(db, agent_id, user)
    return state


def _retain_review_task(task: asyncio.Task) -> None:
    _REVIEW_TASKS.add(task)
    task.add_done_callback(_REVIEW_TASKS.discard)


async def _run_review_background(
    *,
    agent_ids: list[str],
    user_id: str,
    actor: str,
    correlation_id: str,
) -> None:
    """Run a review outside the client HTTP request.

    A fresh DB session is mandatory: the request session is closed as soon as
    the 202 response is returned.
    """
    logger = __import__("logging").getLogger(__name__)
    try:
        async with get_db_session() as db:
            review_service = container.resolve("agent_trust.review")
            logger.info(
                "agent_trust_review_background_started",
                extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
            )
            await _publish_review_event(
                correlation_id, "review", status="running", message="Review execution started"
            )
            result = await review_service.review_agents(
                db,
                agent_ids=agent_ids,
                user_id=user_id,
                actor=actor,
                correlation_id=correlation_id,
                progress_callback=lambda event: _publish_review_event(
                    correlation_id,
                    str(event.get("event", "progress")),
                    **{key: value for key, value in event.items() if key != "event"},
                ),
            )
            await db.commit()
            await _publish_review_event(correlation_id, "completed", result=result)
            logger.info(
                "agent_trust_review_background_completed",
                extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
            )
    except Exception as exc:
        await _publish_review_event(correlation_id, "failed", error="Review execution failed")
        logger.exception(
            "agent_trust_review_background_failed",
            extra={"correlation_id": correlation_id, "agent_ids": agent_ids},
        )


@router.post("/review", response_model=ReviewResponse, status_code=202, summary="Start review for one or many agents")
async def review(
    payload: ReviewRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> ReviewResponse:
    async with get_db_session() as db:
        registry = container.resolve("agent_trust.registry")
        agent_ids = [normalize_agent_id(value) for value in payload.agent_ids]

        for agent_id in agent_ids:
            await registry.validate_owner(db, agent_id, user)

    correlation_id = uuid4().hex
    user_id = resolve_user_id(user)
    actor = user.email or user_id
    await _initialize_review_state(
        correlation_id,
        agent_ids=agent_ids,
        user_id=user_id,
    )

    task = asyncio.create_task(
        _run_review_background(
            agent_ids=agent_ids,
            user_id=user_id,
            actor=actor,
            correlation_id=correlation_id,
        )
    )
    _retain_review_task(task)

    import logging
    logging.getLogger(__name__).info(
        "agent_trust_review_accepted",
        extra={
            "correlation_id": correlation_id,
            "agent_count": len(agent_ids),
            "agent_ids": agent_ids,
        },
    )

    return ReviewResponse(
        reviewed=0,
        failed=0,
        correlation_id=correlation_id,
        results=[],
        status="started",
    )


@router.get(
    "/reviews/{correlation_id}",
    summary="Get review status and latest result",
)
async def get_review_status(
    correlation_id: str,
    user: UserContext = Depends(require_admin_or_above),
) -> Dict[str, Any]:
    state = await _authorize_review_state(correlation_id, user)
    events = state.get("events") or []
    latest_progress = next(
        (event for event in reversed(events) if event.get("event") == "progress"),
        None,
    )
    return {
        "correlation_id": correlation_id,
        "status": state["status"],
        "agent_ids": state["agent_ids"],
        "created_at": state["created_at"],
        "updated_at": state["updated_at"],
        "latest_progress": latest_progress,
        "result": state.get("result"),
        "error": state.get("error"),
    }


@router.get(
    "/reviews/{correlation_id}/events",
    summary="Stream review progress using Server-Sent Events",
)
async def stream_review_events(
    correlation_id: str,
    request: Request,
    user: UserContext = Depends(require_admin_or_above),
) -> StreamingResponse:
    state = await _authorize_review_state(correlation_id, user)
    try:
        last_event_id = max(0, int(request.headers.get("last-event-id", "0")))
    except (TypeError, ValueError):
        last_event_id = 0

    queue: asyncio.Queue = asyncio.Queue()
    async with _REVIEW_STATE_LOCK:
        current = _REVIEW_STATES.get(correlation_id)
        if current is None:
            raise HTTPException(status_code=404, detail="Review not found")
        _REVIEW_SUBSCRIBERS.setdefault(correlation_id, set()).add(queue)
        replay = [event for event in current["events"] if event["id"] > last_event_id]
        terminal = current.get("status") in _TERMINAL_REVIEW_STATUSES

    async def event_stream() -> AsyncIterator[str]:
        last_sent = last_event_id
        try:
            for event in replay:
                if event["id"] <= last_sent:
                    continue
                yield f"id: {event['id']}\nevent: {event['event']}\ndata: {json.dumps(event, default=str, separators=(',', ':'))}\n\n"
                last_sent = event["id"]
                if event["event"] in _TERMINAL_REVIEW_STATUSES:
                    return
            if terminal:
                return
            while not await request.is_disconnected():
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15.0)
                except asyncio.TimeoutError:
                    yield ": keep-alive\n\n"
                    continue
                if event["id"] <= last_sent:
                    continue
                # If queue delivery missed an event, replay the missing sequence
                # from the retained in-process event history before this event.
                if event["id"] > last_sent + 1:
                    latest = await _get_review_state(correlation_id)
                    missing = [item for item in (latest or {}).get("events", []) if last_sent < item["id"] < event["id"]]
                    for item in missing:
                        yield f"id: {item['id']}\nevent: {item['event']}\ndata: {json.dumps(item, default=str, separators=(',', ':'))}\n\n"
                        last_sent = item["id"]
                yield f"id: {event['id']}\nevent: {event['event']}\ndata: {json.dumps(event, default=str, separators=(',', ':'))}\n\n"
                last_sent = event["id"]
                if event["event"] in _TERMINAL_REVIEW_STATUSES:
                    return
        finally:
            async with _REVIEW_STATE_LOCK:
                subscribers = _REVIEW_SUBSCRIBERS.get(correlation_id)
                if subscribers is not None:
                    subscribers.discard(queue)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@router.post(
    "/agents/{agent_id}/functional-suites/recommend",
    response_model=RecommendedSuiteResponse,
    summary="Generate a grounded functional-test recommendation",
)
async def recommend_functional_suite(
    agent_id: str,
    payload: RecommendFunctionalSuiteRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> RecommendedSuiteResponse:
    async with get_db_session() as db:

        hexaid = normalize_agent_id(agent_id)

        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")

        await registry.validate_owner(db, hexaid, user)

        try:
            result = await testing.generate_recommended_suite(
                db,
                agent_id=hexaid,
                user_id=resolve_user_id(user),
                question_count=payload.question_count,
            )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

        return RecommendedSuiteResponse(**result)


@router.post(
    "/agents/{agent_id}/functional-suites/recommend/{recommendation_id}/accept",
    response_model=TestSuiteResponse,
    summary="Accept a functional-test recommendation",
)
async def accept_functional_suite_recommendation(
    agent_id: str,
    recommendation_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
) -> TestSuiteResponse:
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")

        await registry.validate_owner(db, hexaid, user)

        try:
            suite = await testing.accept_recommended_suite(
                db,
                agent_id=hexaid,
                recommendation_id=recommendation_id,
            )
            await audit.record(
                db,
                agent_id=hexaid,
                event_type=EVENT_SUITE_ADDED,
                action="suite_added",
                actor=user.email or resolve_user_id(user),
                details={
                    "suite_id": str(suite.id),
                    "suite_name": suite.name,
                    "source": "ai",
                    "recommendation_id": str(recommendation_id),
                },
            )
            await db.commit()
        except ValueError as exc:
            await db.rollback()
            raise HTTPException(status_code=404, detail=str(exc))

        return TestSuiteResponse(
            suite_id=str(suite.id),
            agent_id=hexaid,
            name=suite.name,
            description=suite.description,
            test_count=len(suite.test_cases or []),
            source="ai",
        )


@router.post(
    "/agents/{agent_id}/functional-suites",
    response_model=TestSuiteResponse,
    summary="Add a functional test suite",
)
async def create_functional_suite(
    agent_id: str,
    payload: TestSuiteCreateRequest,
    user: UserContext = Depends(require_admin_or_above),
) -> TestSuiteResponse:
    async with get_db_session() as db:

        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")
        await registry.validate_owner(db, hexaid, user)

        try:
            suite = await testing.create_agent_suite(
                db,
                agent_id=hexaid,
                name=payload.name,
                description=payload.description,
                test_cases=[case.model_dump() for case in payload.test_cases],
                source=payload.source,
            )
            await audit.record(
                db,
                agent_id=hexaid,
                event_type=EVENT_SUITE_ADDED,
                action="suite_added",
                actor=user.email or resolve_user_id(user),
                details={"suite_id": str(suite.id), "suite_name": suite.name},
            )
            await db.commit()
        except ValueError as exc:
            await db.rollback()
            raise HTTPException(status_code=400, detail=str(exc))

        return TestSuiteResponse(
            suite_id=str(suite.id),
            agent_id=hexaid,
            name=suite.name,
            description=suite.description,
            test_count=len(suite.test_cases or []),
            source="ai" if suite.is_seeded else "user",
        )


@router.delete(
    "/agents/{agent_id}/functional-suites/{suite_id}",
    summary="Remove a functional test suite",
)
async def delete_functional_suite(
    agent_id: str,
    suite_id: UUID,
    user: UserContext = Depends(require_admin_or_above),
):
    async with get_db_session() as db:
        hexaid = normalize_agent_id(agent_id)
        registry = container.resolve("agent_trust.registry")
        testing = container.resolve("agent_trust.testing")
        audit = container.resolve("agent_trust.audit")
        await registry.validate_owner(db, hexaid, user)

        suite = await testing.delete_agent_suite(db, agent_id=hexaid, suite_id=suite_id)
        if suite is None:
            raise HTTPException(status_code=404, detail="Functional test suite not found")

        await audit.record(
            db,
            agent_id=hexaid,
            event_type=EVENT_SUITE_REMOVED,
            action="suite_removed",
            actor=user.email or resolve_user_id(user),
            details={"suite_id": str(suite.id), "suite_name": suite.name},
        )
        await db.commit()
        return {"status": "deleted", "suite_id": str(suite_id)}
