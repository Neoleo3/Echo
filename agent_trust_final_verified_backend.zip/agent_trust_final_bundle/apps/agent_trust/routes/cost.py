"""Cost Governance routes (Phase 5) -- continuous, read/manage here."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from echolib.database import get_db_session
from echolib.security import require_admin_or_above
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import _normalize

router = APIRouter(prefix="/cost", tags=["Agent Trust"])


class BudgetCreate(BaseModel):
    name: str
    scope: str  # org|department|agent
    scope_id: Optional[str] = None
    limit_usd: float
    period: str = "monthly"
    alert_threshold_pct: float = 80.0
    hard_stop: bool = False


@router.get("/records")
async def list_records(agent_id: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.cost")
    hexaid = _normalize(agent_id) if agent_id else None
    async with get_db_session() as db:
        return [r.to_dict() for r in await service.list_records(db, agent_id=hexaid)]


@router.get("/stats")
async def cost_stats(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.cost")
    async with get_db_session() as db:
        return await service.get_stats(db)


@router.get("/price-book")
async def price_book(user: UserContext = Depends(require_admin_or_above)):
    from echolib.pricing import PRICE_BOOK, DEFAULT_PRICE

    return {"models": PRICE_BOOK, "default": DEFAULT_PRICE}


@router.post("/budgets")
async def create_budget(payload: BudgetCreate, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.cost")
    async with get_db_session() as db:
        budget = await service.create_budget(db, **payload.model_dump())
        await db.commit()
        return budget.to_dict()


@router.get("/budgets")
async def list_budgets(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.cost")
    async with get_db_session() as db:
        return [b.to_dict() for b in await service.list_budgets(db)]
