"""Audit Trail routes (Phase 6)."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends

from echolib.database import get_db_session
from echolib.security import require_admin_or_above
from echolib.types import UserContext

from apps.agent_trust import container
from apps.agent_trust.routes.agents import _normalize

router = APIRouter(prefix="/audit", tags=["Agent Trust"])


@router.get("/logs")
async def list_logs(agent_id: Optional[str] = None, user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.audit")
    hexaid = _normalize(agent_id) if agent_id else None
    async with get_db_session() as db:
        return [log.to_dict() for log in await service.list_logs(db, agent_id=hexaid)]


@router.post("/verify")
async def verify_chain(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.audit")
    async with get_db_session() as db:
        return await service.verify_chain(db)


@router.get("/stats")
async def audit_stats(user: UserContext = Depends(require_admin_or_above)):
    service = container.resolve("agent_trust.audit")
    async with get_db_session() as db:
        return await service.get_stats(db)
