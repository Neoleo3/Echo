from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.database import get_db_session
from echolib.security import get_current_user

from echolib.service.agent_trust.bootstrap_service import (
    AgentTrustBootstrapService,
)

from apps.agent_trust.schemas.schemas import (
    AgentTrustInitializationResponse,
)
router = APIRouter(prefix="/agents",tags=["Agent Trust"])
bootstrap_service = AgentTrustBootstrapService()
@router.post(
    "/initialize",
    response_model=AgentTrustInitializationResponse,
)
async def initialize_agent_trust(
    current_user=Depends(get_current_user),
):
    async with get_db_session() as db:
        return await bootstrap_service.initialize(
            db,
            current_user.user_id,
        )