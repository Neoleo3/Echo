"""Agent Trust public router.

The public surface is agent-centric. Policy configuration remains available
inside an agent's Review experience while the policy catalog routes remain
for existing administrative functionality.
"""
from fastapi import APIRouter

from .actions import router as actions_router
from .agents import router as agents_router
from .policies import router as policies_router

agent_trust_router = APIRouter(prefix="/agent-trust")
agent_trust_router.include_router(agents_router)
agent_trust_router.include_router(actions_router)
agent_trust_router.include_router(policies_router)

__all__ = ["agent_trust_router"]
