"""Grounding context used by Agent Trust AI recommendations.

The recommendation models are given the agent's actual configuration and the
resolved definitions of the tools/connectors/application/workflow surfaces that
shape its behaviour. They are explicitly forbidden from inventing external
records, URLs, credentials, customer data, or capabilities that are not present
in this evidence packet.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Set
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent, Tool, Workflow
from echolib.models.agent_file import AgentFile
from echolib.models.application import Application, ApplicationSkillLink


_SECRET_RE = re.compile(
    r"(password|passwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|credential|authorization|bearer)",
    re.I,
)


def _redact(value: Any) -> Any:
    """Keep configuration shape while removing credential material."""
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            if _SECRET_RE.search(str(key)):
                out[key] = "[REDACTED]"
            else:
                out[key] = _redact(item)
        return out
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, tuple):
        return [_redact(item) for item in value]
    return value


def _tool_refs(definition: Any) -> List[str]:
    refs: List[str] = []
    seen: Set[str] = set()

    def add(value: Any) -> None:
        if isinstance(value, str) and value.strip():
            value = value.strip()
            if value not in seen:
                seen.add(value)
                refs.append(value)
        elif isinstance(value, dict):
            for key in ("tool_id", "toolId", "id", "name"):
                if value.get(key):
                    add(value[key])
                    break

    def walk(node: Any, parent_key: str = "") -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                lowered = str(key).lower()
                if lowered in {"tools", "tool_ids", "toolids", "tool_refs", "tool_references"}:
                    if isinstance(value, list):
                        for item in value:
                            add(item)
                    else:
                        add(value)
                elif lowered in {"tool_id", "toolid"}:
                    add(value)
                walk(value, lowered)
        elif isinstance(node, list):
            for item in node:
                walk(item, parent_key)

    walk(definition)
    return refs


async def _resolve_tools(db: AsyncSession, refs: Iterable[str]) -> List[Dict[str, Any]]:
    refs = list(dict.fromkeys(str(ref) for ref in refs if ref))
    if not refs:
        return []

    rows = []
    uuid_refs = []
    name_refs = []
    for ref in refs:
        try:
            uuid_refs.append(UUID(ref))
        except (ValueError, AttributeError):
            name_refs.append(ref)

    if uuid_refs:
        rows.extend(
            (await db.execute(select(Tool).where(Tool.tool_id.in_(uuid_refs)))).scalars().all()
        )
    if name_refs:
        rows.extend(
            (await db.execute(select(Tool).where(Tool.name.in_(name_refs)))).scalars().all()
        )

    result: List[Dict[str, Any]] = []
    found: Set[str] = set()
    for row in rows:
        key = str(row.tool_id)
        if key in found:
            continue
        found.add(key)
        result.append(_redact({
            "evidence_key": f"tool:{key}",
            "tool_id": key,
            "name": row.name,
            "description": row.description,
            "tool_type": row.tool_type,
            "status": row.status,
            "version": row.version,
            "tags": row.tags or [],
            "definition": row.definition or {},
        }))

    known_names = {str(item.get("name", "")) for item in result}
    known_ids = {str(item.get("tool_id", "")) for item in result}

    # Built-in tools may be filesystem/registry-backed rather than rows in the
    # tools table. Resolve those through the real ToolRegistry as a second
    # source. This is where manifest/service.json-style definitions become
    # available without duplicating the tool system inside Agent Trust.
    try:
        from apps.tool.container import get_registry
        registry = get_registry()
        for ref in refs:
            if ref in known_names or ref in known_ids:
                continue
            tool_def = await registry.get_async(ref)
            if tool_def is None:
                tool_def = await registry.get_by_name_async(ref)
            if tool_def is not None:
                if hasattr(tool_def, "model_dump"):
                    payload = tool_def.model_dump(mode="json")
                elif hasattr(tool_def, "dict"):
                    payload = tool_def.dict()
                else:
                    payload = dict(tool_def)
                payload = _redact(payload)
                payload["evidence_key"] = f"tool:{payload.get('tool_id') or ref}"
                result.append(payload)
                known_names.add(str(payload.get("name", "")))
                known_ids.add(str(payload.get("tool_id", "")))
    except Exception:
        # Recommendation generation must not fail merely because an optional
        # registry backend is unavailable; unresolved refs remain explicit.
        pass

    # Keep unresolved references visible as references rather than silently
    # pretending the tool does not exist. The model must not infer behaviour
    # from an unresolved name.
    for ref in refs:
        if ref not in known_names and ref not in known_ids:
            result.append({
                "evidence_key": f"tool-ref:{ref}",
                "reference": ref,
                "resolved": False,
                "instruction": "Do not infer capabilities from this unresolved reference.",
            })
    return result


async def collect_agent_recommendation_evidence(
    db: AsyncSession,
    agent: Agent,
) -> Dict[str, Any]:
    """Build the complete *configuration* evidence packet for recommendations."""
    definition = _redact(agent.to_dict())
    evidence: Dict[str, Any] = {
        "agent": {
            "evidence_key": "agent.definition",
            "hexaid": agent.hexaid,
            "agent_id": str(agent.agent_id),
            "name": agent.name,
            "definition": definition,
        },
        "tools": await _resolve_tools(db, _tool_refs(agent.definition or {})),
        "connectors": [],
        "workflow": None,
        "applications": [],
        "knowledge_sources": [],
        "constraints": {
            "do_not_invent_external_records": True,
            "do_not_invent_credentials": True,
            "do_not_invent_urls_or_tool_capabilities": True,
            "unresolved_references_are_not_evidence": True,
        },
    }

    connectors = definition.get("connectors") or []
    if isinstance(connectors, list):
        for index, connector in enumerate(connectors):
            if isinstance(connector, dict):
                item = _redact(dict(connector))
            else:
                item = {"reference": connector}
            item["evidence_key"] = f"connector:{item.get('alias') or item.get('connector_id') or index}"
            evidence["connectors"].append(item)

    # Workflow context is configuration-only. It gives the recommender the
    # target node, upstream/downstream contract and state schema without running
    # the workflow or querying its external systems.
    if agent.source_workflow_id:
        workflow = (await db.execute(
            select(Workflow).where(Workflow.workflow_id == agent.source_workflow_id)
        )).scalar_one_or_none()
        if workflow is not None:
            evidence["workflow"] = {
                "evidence_key": "workflow.definition",
                "workflow_id": str(workflow.workflow_id),
                "name": workflow.name,
                "status": workflow.status,
                "definition": _redact(workflow.to_dict()),
            }

    # Application context can change what an agent actually does (persona,
    # guardrails, trigger input and linked skills), so include it when present.
    link_rows = (
        await db.execute(
            select(ApplicationSkillLink).where(
                ApplicationSkillLink.skill_type == "agent",
                ApplicationSkillLink.skill_id.in_([agent.hexaid, str(agent.agent_id)]),
            )
        )
    ).scalars().all()
    app_ids = list(dict.fromkeys(row.application_id for row in link_rows))
    if app_ids:
        apps = (await db.execute(select(Application).where(Application.application_id.in_(app_ids)))).scalars().all()
        for app in apps:
            evidence["applications"].append({
                "evidence_key": f"application:{app.application_id}",
                "definition": _redact(app.to_dict()),
                "linked_skills": [
                    {
                        "skill_type": row.skill_type,
                        "skill_id": row.skill_id,
                        "name": row.skill_name,
                        "description": row.skill_description,
                    }
                    for row in link_rows if row.application_id == app.application_id
                ],
            })

    # Knowledge/file metadata is included so tests can ask about the *existence
    # and configured role* of a source, but raw customer/document contents are
    # never sent to the recommendation model.
    files = (
        await db.execute(select(AgentFile).where(AgentFile.agent_id == agent.agent_id))
    ).scalars().all()
    for item in files:
        evidence["knowledge_sources"].append(_redact({
            "evidence_key": f"knowledge:{item.id}",
            "id": str(item.id),
            "name": item.name,
            "source_type": item.source_type,
            "format": item.format,
            "mime_type": item.mime_type,
            "size_bytes": item.size_bytes,
            "content_hash": item.content_hash,
            "knowledge_base_id": str(item.knowledge_base_id) if item.knowledge_base_id else None,
            "document_id": str(item.document_id) if item.document_id else None,
            "ingest_mode": item.ingest_mode,
            "status": item.status,
        }))

    evidence["summary"] = {
        "tool_count": len(evidence["tools"]),
        "connector_count": len(evidence["connectors"]),
        "application_count": len(evidence["applications"]),
        "knowledge_source_count": len(evidence["knowledge_sources"]),
        "workflow_bound": bool(evidence["workflow"]),
    }
    return evidence


def evidence_keys(packet: Dict[str, Any]) -> Set[str]:
    keys: Set[str] = {"agent.definition"}
    for section in ("tools", "connectors", "knowledge_sources", "applications"):
        for item in packet.get(section) or []:
            if isinstance(item, dict) and item.get("evidence_key"):
                keys.add(str(item["evidence_key"]))
    if packet.get("workflow"):
        keys.add("workflow.definition")
    return keys
