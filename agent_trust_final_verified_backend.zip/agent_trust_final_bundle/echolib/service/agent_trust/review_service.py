"""
Agent review engine -- the one place an agent gets assessed and scored.

A review is a single, non-negotiable pipeline. There are no per-check toggles
in the API. Identity is refreshed when stale; security, functional and policy
checks reuse passing results and retry failures. On a first review, applicable
policies and a grounded functional suite are selected/generated automatically
when none are configured.

The same pipeline serves one agent or many; ``review_agents`` is the only
entry point.
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional
from uuid import UUID, uuid4

from sqlalchemy import cast, func, or_, select
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent, User, Workflow
from echolib.models.application import ApplicationSkillLink
from echolib.models.agent_trust import (
    AgentGovernanceProfile,
    IdentitySnapshot,
    Policy,
    PolicyAgentLink,
    PolicyEvaluation,
    PolicyViolation,
    RedTeamResult,
    TestRun,
    TestSuite,
    TrustScoreHistory,
)
from echolib.service.agent_trust import scoring
from echolib.service.agent_trust.execution_safety import (
    check_agent_test_safety,
    check_workflow_test_safety,
)
from echolib.service.agent_trust.audit_service import (
    EVENT_AGENT_REVIEWED,
    EVENT_IDENTITY_CHECK,
    EVENT_REVIEW_STAGE,
    EVENT_SECURITY_SCAN,
    EVENT_SUITE_RUN,
    AuditService,
)
from echolib.service.agent_trust.cost_service import CostService
from echolib.service.agent_trust.identity_service import IdentityService
from echolib.service.agent_trust.policy_service import PolicyService, PolicyAssignmentService
from echolib.service.agent_trust.testing_service import TestingService

logger = logging.getLogger(__name__)

MAX_BULK_REVIEW_AGENTS = 25


class ReviewService:
    def __init__(self) -> None:
        self._identity = IdentityService()
        self._audit = AuditService()
        self._testing = TestingService()
        self._policy = PolicyService()
        self._cost = CostService()

    # ==================================================================
    # Review
    # ==================================================================

    async def review_agents(
        self,
        db: AsyncSession,
        *,
        agent_ids: List[str],
        user_id: str,
        actor: Optional[str] = None,
        correlation_id: Optional[str] = None,
        progress_callback: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> Dict[str, Any]:
        """Run the review pipeline for one or many agents.

        The optional progress callback is best-effort and does not affect
        review execution if the frontend disconnects or event delivery fails.
        """
        correlation_id = correlation_id or uuid4().hex
        results: List[Dict[str, Any]] = []
        reviewed = 0
        failed = 0

        logger.info(
            "agent_trust_review_started",
            extra={
                "agent_count": len(agent_ids),
                "correlation_id": correlation_id,
                "user_id": user_id,
            },
        )

        for agent_id in agent_ids:
            try:
                results.append(
                    await self._assess(
                        db,
                        agent_id=agent_id,
                        user_id=user_id,
                        actor=actor,
                        correlation_id=correlation_id,
                        progress_callback=progress_callback,
                    )
                )
                reviewed += 1
            except Exception as exc:
                failed += 1
                logger.exception(
                    "agent_trust_review_failed",
                    extra={"agent_id": agent_id, "correlation_id": correlation_id},
                )
                results.append(
                    {"agent_id": agent_id, "status": "failed", "error": str(exc)}
                )
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "agent", "status": "failed", "agent_id": agent_id, "message": "Agent review failed"},
                )

        logger.info(
            "agent_trust_review_completed",
            extra={
                "reviewed": reviewed,
                "failed": failed,
                "correlation_id": correlation_id,
            },
        )
        return {
            "reviewed": reviewed,
            "failed": failed,
            "correlation_id": correlation_id,
            "results": results,
        }

    @staticmethod
    async def _emit_progress(
        callback: Optional[Callable[[Dict[str, Any]], Awaitable[None]]],
        event: Dict[str, Any],
    ) -> None:
        """Best-effort progress notifications; delivery must not fail a review."""
        if callback is None:
            return
        try:
            await callback(event)
        except Exception:
            logger.debug("agent_trust_progress_publish_failed", exc_info=True)

    async def _assess(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        user_id: str,
        actor: Optional[str],
        correlation_id: str,
        progress_callback: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> Dict[str, Any]:
        agent = await db.get(Agent, agent_id)
        if agent is None or agent.is_deleted:
            raise ValueError(f"Agent '{agent_id}' not found")

        profile = await self._get_or_create_profile(db, agent)
        previous_score = int(profile.trust_score) if profile.trust_score is not None else None
        await self._emit_progress(
            progress_callback,
            {"event": "progress", "stage": "agent", "status": "running", "agent_id": agent.hexaid, "agent_name": agent.name},
        )
        first_review = profile.last_evaluated_at is None
        failed_policy_exists = await self._has_failed_policy_evaluations(db, agent.hexaid)
        failed_tests_exist = await self._has_failed_test_results(db, agent.hexaid)
        config_stale = bool(
            profile.needs_policy_review or profile.identity_stale or profile.testing_stale
        )

        # An unchanged, fully passing review is a true no-op. If failed checks
        # remain, only those checks are retried; passing cases are reused below.
        if not first_review and not config_stale and not failed_policy_exists and not failed_tests_exist:
            logger.info(
                "agent_trust_review_skipped_unchanged",
                extra={
                    "agent_id": agent.hexaid,
                    "last_evaluated_at": profile.last_evaluated_at.isoformat(),
                    "correlation_id": correlation_id,
                },
            )
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "review", "status": "skipped", "agent_id": agent.hexaid, "message": "No relevant changes; existing results reused"},
            )
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "agent", "status": "completed", "agent_id": agent.hexaid, "review_status": "unchanged"},
            )
            return {
                "agent_id": agent.hexaid,
                "name": agent.name,
                "status": "reviewed",
                "trust_score": previous_score,
                "trust_state": profile.trust_state,
                "previous_score": previous_score,
            }

        logger.info(
            "agent_trust_review_agent_started",
            extra={
                "agent_id": agent.hexaid,
                "agent_name": agent.name,
                "correlation_id": correlation_id,
            },
        )

        run_identity = first_review or profile.identity_stale
        run_policy = first_review or profile.needs_policy_review or failed_policy_exists
        run_testing = (
            first_review
            or profile.testing_stale
            or profile.identity_stale
            or profile.needs_policy_review
            or failed_tests_exist
        )

        logger.info(
            "agent_trust_review_plan",
            extra={
                "agent_id": agent.hexaid,
                "correlation_id": correlation_id,
                "identity": run_identity,
                "policy": run_policy,
                "security": run_testing,
                "functional": run_testing,
                "first_review": first_review,
            },
        )

        if run_policy:
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "policy", "status": "running", "agent_id": agent.hexaid, "message": "Selecting applicable policies and evaluating outstanding checks"},
            )
        else:
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "policy", "status": "skipped", "agent_id": agent.hexaid, "message": "Policy results are current"},
            )

        policy_selection_completed = True
        if run_policy:
            try:
                assigned_policies = await self._policy.get_agent_policies(db, agent.hexaid)
                if not assigned_policies:
                    prior_evaluation = (
                        await db.execute(
                            select(PolicyEvaluation.id)
                            .where(PolicyEvaluation.agent_id == agent.hexaid)
                            .limit(1)
                        )
                    ).scalar_one_or_none()
                    # Auto-select on first review and retry a failed initial selection,
                    # but do not undo a deliberate later unassignment.
                    if first_review or prior_evaluation is None:
                        assignment = await PolicyAssignmentService().assign_policies_for_agent(
                            db,
                            agent_id=agent.hexaid,
                            user_id=user_id,
                        )
                        if assignment.get("error") not in (None, "no_active_policies"):
                            policy_selection_completed = False
                            logger.warning(
                                "agent_trust_automatic_policy_selection_failed",
                                extra={"agent_id": agent.hexaid, "correlation_id": correlation_id,
                                       "error": assignment.get("error")},
                            )
            except Exception:
                policy_selection_completed = False
                logger.warning(
                    "agent_trust_automatic_policy_selection_failed",
                    extra={"agent_id": agent.hexaid, "correlation_id": correlation_id},
                    exc_info=True,
                )

        identity_completed = True
        policy_completed = policy_selection_completed
        security_completed = True
        functional_completed = True

        if run_identity:
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "identity", "status": "running", "agent_id": agent.hexaid},
            )
            identity_completed = await self._run_identity(db, agent, correlation_id)
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "identity", "status": "completed" if identity_completed else "failed", "agent_id": agent.hexaid},
            )
        else:
            await self._emit_progress(
                progress_callback,
                {"event": "progress", "stage": "identity", "status": "skipped", "agent_id": agent.hexaid, "message": "Identity results are current"},
            )

        if not (run_policy or run_testing):
            execution_safety = None
        elif agent.source_workflow_id is not None:
            workflow = (
                await db.execute(
                    select(Workflow).where(
                        Workflow.workflow_id == agent.source_workflow_id,
                        Workflow.user_id == agent.user_id,
                        Workflow.is_deleted.is_(False),
                    )
                )
            ).scalar_one_or_none()
            if workflow is not None and isinstance(workflow.definition, dict):
                execution_safety = await check_workflow_test_safety(
                    workflow.definition,
                    owner_user_id=str(agent.user_id),
                )
            else:
                execution_safety = await check_agent_test_safety(agent)
        else:
            execution_safety = await check_agent_test_safety(agent)

        if execution_safety is not None and execution_safety.allowed:
            if run_policy:
                policy_completed = await self._run_policies(
                    db,
                    agent,
                    user_id,
                    correlation_id,
                ) and policy_selection_completed
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "policy", "status": "completed" if policy_completed else "failed", "agent_id": agent.hexaid},
                )
            if run_testing:
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "security", "status": "running", "agent_id": agent.hexaid},
                )
                security_completed = await self._run_security(db, agent, user_id, correlation_id)
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "security", "status": "completed" if security_completed else "failed", "agent_id": agent.hexaid},
                )
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "functional", "status": "running", "agent_id": agent.hexaid},
                )
                functional_completed = await self._run_functional(db, agent, user_id, correlation_id)
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "functional", "status": "completed" if functional_completed else "failed", "agent_id": agent.hexaid},
                )
            else:
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "security", "status": "skipped", "agent_id": agent.hexaid, "message": "Security results are current"},
                )
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "functional", "status": "skipped", "agent_id": agent.hexaid, "message": "Functional results are current"},
                )
        elif execution_safety is not None:
            if run_policy:
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "policy", "status": "not_verified", "agent_id": agent.hexaid, "message": "Execution safety gate blocked review execution"},
                )
            if run_testing:
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "security", "status": "not_verified", "agent_id": agent.hexaid, "message": "Execution safety gate blocked review execution"},
                )
                await self._emit_progress(
                    progress_callback,
                    {"event": "progress", "stage": "functional", "status": "not_verified", "agent_id": agent.hexaid, "message": "Execution safety gate blocked review execution"},
                )

        await self._emit_progress(
            progress_callback,
            {"event": "progress", "stage": "scoring", "status": "running", "agent_id": agent.hexaid},
        )
        checks = await self._collect_checks(db, agent)
        score = scoring.total_score(checks)
        await self._emit_progress(
            progress_callback,
            {"event": "progress", "stage": "scoring", "status": "completed", "agent_id": agent.hexaid, "trust_score": int(score)},
        )

        profile.trust_score = float(score)
        profile.trust_dimensions = scoring.build_breakdown(checks)
        if run_policy:
            profile.needs_policy_review = not policy_completed
        if run_identity:
            profile.identity_stale = not identity_completed
        if run_testing:
            profile.testing_stale = not (
                execution_safety is not None
                and execution_safety.allowed
                and security_completed
                and functional_completed
            )
        profile.last_evaluated_at = datetime.now(timezone.utc)
        remaining_stale = bool(
            profile.needs_policy_review
            or profile.identity_stale
            or profile.testing_stale
        )
        profile.trust_state = scoring.trust_state(
            score,
            reviewed=True,
            stale=remaining_stale,
        )
        await db.flush()

        db.add(
            TrustScoreHistory(
                id=uuid4(),
                agent_id=agent.hexaid,
                score=float(score),
                previous_score=float(previous_score) if previous_score is not None else None,
                band=profile.trust_state,
                factors=profile.trust_dimensions,
                is_provisional=False,
                reason="agent_review",
                recorded_at=datetime.now(timezone.utc),
            )
        )

        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_AGENT_REVIEWED,
            action="review",
            actor=actor,
            correlation_id=correlation_id,
            details={
                "trust_score": score,
                "previous_score": previous_score,
                "trust_state": profile.trust_state,
                "checks": {check.key: check.earned for check in checks},
                "execution_verified": execution_safety.allowed if execution_safety is not None else None,
                "execution_safety": {
                    "allowed": execution_safety.allowed if execution_safety is not None else None,
                    "blocked_connectors": list(execution_safety.blocked_connectors) if execution_safety is not None else [],
                    "reason": execution_safety.reason if execution_safety is not None else None,
                },
            },
        )

        if previous_score is not None and score < previous_score - 10:
            await self._audit.raise_alert(
                db,
                alert_type="trust_score_dropped",
                severity="high",
                title=f"Trust score for '{agent.name}' dropped to {score}",
                agent_id=agent.hexaid,
                details={"previous_score": previous_score, "trust_score": score},
            )

        logger.info(
            "agent_trust_review_agent_completed",
            extra={
                "agent_id": agent.hexaid,
                "trust_score": score,
                "trust_state": profile.trust_state,
                "correlation_id": correlation_id,
            },
        )
        result = {
            "agent_id": agent.hexaid,
            "name": agent.name,
            "status": "reviewed",
            "trust_score": score,
            "trust_state": profile.trust_state,
            "previous_score": previous_score,
        }
        await self._emit_progress(
            progress_callback,
            {"event": "progress", "stage": "agent", "status": "completed", "agent_id": agent.hexaid, "trust_score": int(score), "trust_state": profile.trust_state},
        )
        return result

    # ------------------------------------------------------------------
    # Pipeline stages -- each isolated so one failure cannot void the review.
    # ------------------------------------------------------------------

    async def _run_identity(self, db: AsyncSession, agent: Agent, correlation_id: str) -> bool:
        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="identity_check_started",
            correlation_id=correlation_id,
            details={"stage": "identity", "status": "started"},
        )
        logger.info("agent_trust_identity_check_started", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        try:
            async with db.begin_nested():
                result = await self._identity.evaluate(db, agent_id=agent.hexaid)
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_IDENTITY_CHECK,
                action="identity_check",
                correlation_id=correlation_id,
                details={
                    "declared": len(result.get("declared") or []),
                    "drift": len(result.get("drift_flags") or []),
                },
            )
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="identity_check_completed",
                correlation_id=correlation_id,
                details={"stage": "identity", "status": "completed"},
            )
            logger.info("agent_trust_identity_check_completed", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        except Exception:
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="identity_check_completed",
                correlation_id=correlation_id,
                outcome="failed",
                severity="warning",
                details={"stage": "identity", "status": "failed"},
            )
            logger.warning(
                "agent_trust_identity_stage_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )
            return False
        return True

    async def _run_policies(
        self,
        db: AsyncSession,
        agent: Agent,
        user_id: str,
        correlation_id: str,
    ) -> bool:
        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="policy_checks_started",
            correlation_id=correlation_id,
            details={"stage": "policy", "status": "started"},
        )
        logger.info("agent_trust_policy_checks_started", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        try:
            assigned = await self._policy.get_agent_policies(db, agent.hexaid)
        except Exception:
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="policy_checks_completed",
                correlation_id=correlation_id,
                outcome="failed",
                severity="warning",
                details={"stage": "policy", "status": "failed"},
            )
            logger.warning(
                "agent_trust_policy_lookup_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )
            return False

        stage_failed = False
        for entry in assigned:
            try:
                # A passing policy evaluation is reusable. Failed or unverified
                # evaluations are retried on the next review that reaches this stage.
                previous = (
                    await db.execute(
                        select(PolicyEvaluation)
                        .where(
                            PolicyEvaluation.agent_id == agent.hexaid,
                            PolicyEvaluation.policy_id == entry["policy_id"],
                        )
                        .order_by(PolicyEvaluation.evaluated_at.desc())
                        .limit(1)
                    )
                ).scalar_one_or_none()
                policy = await db.get(Policy, entry["policy_id"])
                fingerprint = (
                    await self._policy_fingerprint(db, agent.hexaid, policy)
                    if policy is not None
                    else None
                )
                previous_fingerprint = (
                    previous.judge_response.get("agent_trust_policy_fingerprint")
                    if previous is not None and isinstance(previous.judge_response, dict)
                    else None
                )
                if previous is not None and previous.passed is True and fingerprint is not None:
                    # Legacy passing evaluations predate fingerprint storage. Reuse
                    # them once and stamp the current fingerprint for future invalidation.
                    if previous_fingerprint is None:
                        previous.judge_response = {
                            **(previous.judge_response if isinstance(previous.judge_response, dict) else {}),
                            "agent_trust_policy_fingerprint": fingerprint,
                        }
                        continue
                    if previous_fingerprint == fingerprint:
                        continue

                async with db.begin_nested():
                    await self._policy.evaluate_policy(
                        db,
                        entry["policy_id"],
                        agent.hexaid,
                        user_id,
                        review_id=correlation_id,
                    )
                latest = (
                    await db.execute(
                        select(PolicyEvaluation)
                        .where(
                            PolicyEvaluation.agent_id == agent.hexaid,
                            PolicyEvaluation.policy_id == entry["policy_id"],
                        )
                        .order_by(PolicyEvaluation.evaluated_at.desc())
                        .limit(1)
                    )
                ).scalar_one_or_none()
                if latest is not None and fingerprint is not None:
                    latest.judge_response = {
                        **(latest.judge_response if isinstance(latest.judge_response, dict) else {}),
                        "agent_trust_policy_fingerprint": fingerprint,
                    }
            except Exception:
                stage_failed = True
                logger.warning(
                    "agent_trust_policy_evaluation_failed",
                    extra={"agent_id": agent.hexaid, "policy_id": str(entry.get("policy_id"))},
                    exc_info=True,
                )

        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="policy_checks_completed",
            correlation_id=correlation_id,
            details={"stage": "policy", "status": "completed", "policy_count": len(assigned)},
        )
        logger.info("agent_trust_policy_checks_completed", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        return not stage_failed

    async def _run_security(
        self, db: AsyncSession, agent: Agent, user_id: str, correlation_id: str
    ) -> bool:
        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="security_tests_started",
            correlation_id=correlation_id,
            details={"stage": "security", "status": "started"},
        )
        logger.info("agent_trust_security_tests_started", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        try:
            async with db.begin_nested():
                results = await self._testing.run_red_team(
                    db,
                    agent_id=agent.hexaid,
                    user_id=user_id,
                    review_id=correlation_id,
                    reuse_passed=True,
                )
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_SECURITY_SCAN,
                action="red_team",
                correlation_id=correlation_id,
                details={
                    "total": len(results),
                    "blocked": sum(1 for r in results if r.blocked),
                },
            )
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="security_tests_completed",
                correlation_id=correlation_id,
                details={"stage": "security", "status": "completed", "total": len(results), "blocked": sum(1 for r in results if r.blocked)},
            )
            logger.info("agent_trust_security_tests_completed", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
            return True
        except Exception:
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="security_tests_completed",
                correlation_id=correlation_id,
                outcome="failed",
                severity="warning",
                details={"stage": "security", "status": "failed"},
            )
            logger.warning(
                "agent_trust_security_stage_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )
            return False

    async def _run_functional(
        self, db: AsyncSession, agent: Agent, user_id: str, correlation_id: str
    ) -> bool:
        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="functional_tests_started",
            correlation_id=correlation_id,
            details={"stage": "functional", "status": "started"},
        )
        logger.info("agent_trust_functional_tests_started", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        try:
            suites = await self._testing.list_agent_suites(db, agent.hexaid)
        except Exception:
            await self._audit.record(
                db,
                agent_id=agent.hexaid,
                event_type=EVENT_REVIEW_STAGE,
                action="functional_tests_completed",
                correlation_id=correlation_id,
                outcome="failed",
                severity="warning",
                details={"stage": "functional", "status": "failed"},
            )
            logger.warning(
                "agent_trust_functional_stage_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )
            return False
        stage_failed = False
        if not suites:
            try:
                recommendation = await self._testing.generate_recommended_suite(
                    db,
                    agent_id=agent.hexaid,
                    user_id=user_id,
                    question_count=1,
                )
                suite = await self._testing.accept_recommended_suite(
                    db,
                    agent_id=agent.hexaid,
                    recommendation_id=UUID(recommendation["recommendation_id"]),
                )
                suites = [suite]
            except Exception:
                stage_failed = True
                logger.warning(
                    "agent_trust_automatic_functional_generation_failed",
                    extra={"agent_id": agent.hexaid, "correlation_id": correlation_id},
                    exc_info=True,
                )
                suites = []

        for suite in suites:
            try:
                async with db.begin_nested():
                    run = await self._testing.run_suite(
                        db,
                        suite_id=suite.id,
                        agent_id=agent.hexaid,
                        user_id=user_id,
                        triggered_by="review",
                        review_id=correlation_id,
                        reuse_passed=True,
                    )
                await self._audit.record(
                    db,
                    agent_id=agent.hexaid,
                    event_type=EVENT_SUITE_RUN,
                    action="run_suite",
                    correlation_id=correlation_id,
                    details={
                        "suite_id": str(suite.id),
                        "suite_name": suite.name,
                        "total": run.total_tests or 0,
                        "passed": run.passed_tests or 0,
                    },
                )
            except Exception:
                stage_failed = True
                logger.warning(
                    "agent_trust_functional_stage_failed",
                    extra={"agent_id": agent.hexaid, "suite_id": str(suite.id)},
                    exc_info=True,
                )
        await self._audit.record(
            db,
            agent_id=agent.hexaid,
            event_type=EVENT_REVIEW_STAGE,
            action="functional_tests_completed",
            correlation_id=correlation_id,
            details={"stage": "functional", "status": "completed", "suite_count": len(suites)},
        )
        logger.info("agent_trust_functional_tests_completed", extra={"agent_id": agent.hexaid, "correlation_id": correlation_id})
        return not stage_failed

    async def _has_failed_policy_evaluations(self, db: AsyncSession, agent_id: str) -> bool:
        """Whether any assigned policy's latest evaluation is failed/unverified."""
        try:
            assigned = await self._policy.get_agent_policies(db, agent_id)
            for entry in assigned:
                latest = (
                    await db.execute(
                        select(PolicyEvaluation)
                        .where(
                            PolicyEvaluation.agent_id == agent_id,
                            PolicyEvaluation.policy_id == entry["policy_id"],
                        )
                        .order_by(PolicyEvaluation.evaluated_at.desc())
                        .limit(1)
                    )
                ).scalar_one_or_none()
                if latest is not None and latest.passed is not True:
                    return True
        except Exception:
            logger.warning(
                "agent_trust_failed_policy_lookup_for_retry",
                extra={"agent_id": agent_id},
                exc_info=True,
            )
            # Fail closed: do not silently suppress a review when retry state
            # could not be determined.
            return True
        return False

    async def _has_failed_test_results(self, db: AsyncSession, agent_id: str) -> bool:
        """Find failed functional cases or latest failed red-team probes."""
        try:
            suites = await self._testing.list_agent_suites(db, agent_id)
            for suite in suites:
                latest_run = (
                    await db.execute(
                        select(TestRun)
                        .where(
                            TestRun.agent_id == agent_id,
                            TestRun.suite_id == suite.id,
                            TestRun.status != "running",
                        )
                        .order_by(TestRun.started_at.desc())
                        .limit(1)
                    )
                ).scalar_one_or_none()
                for result in (latest_run.results or []) if latest_run else []:
                    if isinstance(result, dict) and result.get("passed") is not True:
                        return True

            security_rows = (
                await db.execute(
                    select(RedTeamResult)
                    .where(RedTeamResult.agent_id == agent_id)
                    .order_by(RedTeamResult.created_at.desc())
                )
            ).scalars().all()
            seen = set()
            for result in security_rows:
                key = (result.attack_type, result.attack_name, result.payload)
                if key in seen:
                    continue
                seen.add(key)
                if result.blocked is not True or result.verdict not in {"blocked", "provider_blocked"}:
                    return True
        except Exception:
            logger.warning(
                "agent_trust_failed_test_lookup_for_retry",
                extra={"agent_id": agent_id},
                exc_info=True,
            )
            return True
        return False

    async def _policy_fingerprint(
        self, db: AsyncSession, agent_id: str, policy: Policy
    ) -> str:
        """Fingerprint catalog and agent-specific assignment inputs without a schema change."""
        link = (
            await db.execute(
                select(PolicyAgentLink).where(
                    PolicyAgentLink.policy_id == policy.id,
                    PolicyAgentLink.agent_id == agent_id,
                )
            )
        ).scalar_one_or_none()
        payload = {
            "policy": {
                key: getattr(policy, key, None)
                for key in (
                    "name",
                    "description",
                    "framework",
                    "severity",
                    "policy_prompt",
                    "judge_prompt",
                    "parameters",
                    "rules",
                    "is_active",
                )
            },
            "assignment": {
                "assigned_by": link.assigned_by if link is not None else None,
                "rationale": link.rationale if link is not None else None,
            },
        }
        encoded = json.dumps(payload, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(encoded.encode("utf-8")).hexdigest()

    # ==================================================================
    # Scoring inputs
    # ==================================================================

    async def _collect_checks(
        self,
        db: AsyncSession,
        agent: Agent,
    ) -> List[scoring.CheckResult]:
        # Persisted results remain authoritative for checks that were not stale
        # in this review. The profile's stale flags keep the overall state at
        # NEEDS_REVIEW when a required execution could not be safely performed.
        return [
            await self._policy_check(db, agent.hexaid),
            await self._functional_check(db, agent.hexaid),
            await self._security_check(db, agent.hexaid),
            await self._identity_check(db, agent.hexaid),
            scoring.score_design(agent.definition),
        ]

    async def _policy_check(self, db: AsyncSession, agent_id: str) -> scoring.CheckResult:
        try:
            assigned = await self._policy.get_agent_policies(db, agent_id)
        except Exception:
            logger.warning(
                "agent_trust_policy_check_failed", extra={"agent_id": agent_id}, exc_info=True
            )
            assigned = []

        cutoff = datetime.now(timezone.utc) - timedelta(days=scoring.VIOLATION_LOOKBACK_DAYS)
        violations = (
            await db.execute(
                select(func.count())
                .select_from(PolicyViolation)
                .where(
                    PolicyViolation.agent_id == agent_id,
                    PolicyViolation.occurred_at >= cutoff,
                )
            )
        ).scalar_one()

        # PolicyEvaluation is the authoritative result for the current review.
        # Keep this lookup narrow to the latest evaluation per assigned policy.
        from echolib.models.agent_trust import PolicyEvaluation
        latest_not_verified = 0
        for policy in assigned:
            row = (
                await db.execute(
                    select(PolicyEvaluation)
                    .where(
                        PolicyEvaluation.agent_id == agent_id,
                        PolicyEvaluation.policy_id == policy.get("policy_id"),
                    )
                    .order_by(PolicyEvaluation.evaluated_at.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()
            if row and isinstance(row.judge_response, dict) and row.judge_response.get("result") == "NOT_VERIFIED":
                latest_not_verified += 1

        return scoring.score_policy(
            policy_count=len(assigned),
            violation_count=int(violations or 0),
            not_verified_count=latest_not_verified,
        )

    async def _functional_check(self, db: AsyncSession, agent_id: str) -> scoring.CheckResult:
        suites = await self._testing.list_agent_suites(db, agent_id)

        total = 0
        passed = 0
        not_verified = 0
        for suite in suites:
            run = (
                await db.execute(
                    select(TestRun)
                    .where(
                        TestRun.agent_id == agent_id,
                        TestRun.suite_id == suite.id,
                    )
                    .order_by(TestRun.started_at.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()
            if run is None:
                continue
            if run.status == "not_verified":
                not_verified += 1
                continue
            if run.status not in {"passed", "failed"}:
                continue
            total += run.total_tests or 0
            passed += run.passed_tests or 0

        return scoring.score_functional(
            suite_count=len(suites),
            total_tests=total,
            passed_tests=passed,
            not_verified_count=not_verified,
        )

    async def _security_check(self, db: AsyncSession, agent_id: str) -> scoring.CheckResult:
        rows = (
            await db.execute(
                select(RedTeamResult.blocked, RedTeamResult.verdict).where(
                    RedTeamResult.agent_id == agent_id
                )
            )
        ).all()
        return scoring.score_security(
            total_probes=len(rows),
            blocked_probes=sum(1 for blocked, _ in rows if blocked),
            not_verified_count=sum(1 for _, verdict in rows if verdict == "not_executed"),
        )

    async def _identity_check(self, db: AsyncSession, agent_id: str) -> scoring.CheckResult:
        snapshot = await self._identity.latest_snapshot(db, agent_id=agent_id)
        if snapshot is None:
            return scoring.score_identity(
                declared_count=0, healthy_count=0, drift_count=0, evaluated=False
            )

        declared = snapshot.declared or []
        healthy = sum(
            1
            for entry in declared
            if entry.get("live_status") in ("active", "connected")
            and not entry.get("expiring_soon")
        )
        return scoring.score_identity(
            declared_count=len(declared),
            healthy_count=healthy,
            drift_count=len(snapshot.drift_flags or []),
            evaluated=True,
        )

    # ==================================================================
    # Reads -- overview, review workspace, dashboard
    # ==================================================================

    async def get_overview(self, db: AsyncSession, *, agent_id: str) -> Dict[str, Any]:
        record = (
            await db.execute(
                select(Agent, AgentGovernanceProfile, User.display_name, User.email)
                .outerjoin(
                    AgentGovernanceProfile,
                    AgentGovernanceProfile.agent_id == Agent.hexaid,
                )
                .outerjoin(User, User.user_id == Agent.user_id)
                .where(Agent.hexaid == agent_id, Agent.is_deleted.is_(False))
            )
        ).first()

        if record is None:
            raise ValueError(f"Agent '{agent_id}' not found")

        agent, profile, display_name, email = record
        checks = self._checks_from_profile(profile)

        return {
            "agent_id": agent.hexaid,
            "name": agent.name,
            "description": (agent.definition or {}).get("description"),
            "owner": {
                "user_id": str(agent.user_id),
                "name": display_name or email,
                "email": email,
            },
            "environment": profile.environment if profile else None,
            "tags": (profile.tags if profile else []) or [],
            "trust_score": int(profile.trust_score)
            if profile and profile.trust_score is not None
            else None,
            "trust_state": profile.trust_state if profile else "UNREVIEWED",
            "last_reviewed_at": profile.last_evaluated_at.isoformat()
            if profile and profile.last_evaluated_at
            else None,
            "stale": self._is_stale(profile),
            "created_at": agent.created_at.isoformat() if agent.created_at else None,
            "updated_at": agent.updated_at.isoformat() if agent.updated_at else None,
            "checks": checks,
            "improvements": self._improvements_from_checks(checks),
            "open_alerts": await self._audit.count_open_alerts(db, agent_id=agent.hexaid),
            "usage": await self._cost.get_agent_usage(db, agent_id=agent.hexaid),
            "used_in": await self._usage_sites(db, agent),
        }

    async def get_review(self, db: AsyncSession, *, agent_id: str) -> Dict[str, Any]:
        agent = await db.get(Agent, agent_id)
        if agent is None or agent.is_deleted:
            raise ValueError(f"Agent '{agent_id}' not found")

        profile = (
            await db.execute(
                select(AgentGovernanceProfile).where(
                    AgentGovernanceProfile.agent_id == agent_id
                )
            )
        ).scalar_one_or_none()

        try:
            policies = await self._policy.get_agent_policies(db, agent_id)
        except Exception:
            logger.warning(
                "agent_trust_review_policy_load_failed",
                extra={"agent_id": agent_id},
                exc_info=True,
            )
            policies = []

        suites = await self._testing.list_agent_suites(db, agent_id)
        checks = self._checks_from_profile(profile)
        snapshot = await self._identity.latest_snapshot(db, agent_id=agent_id)

        return {
            "agent_id": agent.hexaid,
            "name": agent.name,
            "trust_score": int(profile.trust_score)
            if profile and profile.trust_score is not None
            else None,
            "trust_state": profile.trust_state if profile else "UNREVIEWED",
            "last_reviewed_at": profile.last_evaluated_at.isoformat()
            if profile and profile.last_evaluated_at
            else None,
            "stale": self._is_stale(profile),
            "checks": checks,
            "improvements": self._improvements_from_checks(checks),
            "policies": [
                {
                    "policy_id": str(entry["policy_id"]),
                    "name": entry["name"],
                    "framework": entry["framework"],
                    "severity": entry["severity"],
                    "assigned_by": entry["assigned_by"],
                    "assigned_at": entry["assigned_at"].isoformat()
                    if entry.get("assigned_at")
                    else None,
                }
                for entry in policies
            ],
            "test_suites": [
                {
                    "suite_id": str(suite.id),
                    "name": suite.name,
                    "description": suite.description,
                    "test_count": len(suite.test_cases or []),
                    "source": "ai" if suite.description == "ai_recommended" else "user",
                    "last_run": await self._last_run_summary(db, agent_id, suite.id),
                }
                for suite in suites
            ],
            "security": await self._security_summary(db, agent_id),
            "credentials": {
                "evaluated_at": snapshot.evaluated_at.isoformat() if snapshot else None,
                "declared": (snapshot.declared if snapshot else []) or [],
                "drift": (snapshot.drift_flags if snapshot else []) or [],
            },
        }

    async def get_dashboard(
        self, db: AsyncSession, *, owner_user_id: Optional[str]
    ) -> Dict[str, Any]:
        stmt = select(Agent, AgentGovernanceProfile).outerjoin(
            AgentGovernanceProfile, AgentGovernanceProfile.agent_id == Agent.hexaid
        ).where(Agent.is_deleted.is_(False))

        if owner_user_id is not None:
            stmt = stmt.where(AgentGovernanceProfile.owner_user_id == owner_user_id)

        rows = (await db.execute(stmt)).all()

        by_state: Dict[str, int] = {}
        scores: List[int] = []
        attention: List[Dict[str, Any]] = []

        for agent, profile in rows:
            state = profile.trust_state if profile else "UNREVIEWED"
            by_state[state] = by_state.get(state, 0) + 1

            score = (
                int(profile.trust_score)
                if profile and profile.trust_score is not None
                else None
            )
            if score is not None:
                scores.append(score)

            if state in ("HIGH_RISK", "NEEDS_REVIEW", "UNREVIEWED"):
                attention.append(
                    {
                        "agent_id": agent.hexaid,
                        "name": agent.name,
                        "trust_score": score,
                        "trust_state": state,
                        "reason": self._attention_reason(state, profile),
                    }
                )

        attention.sort(key=lambda item: (item["trust_score"] is not None, item["trust_score"] or 0))

        return {
            "total_agents": len(rows),
            "average_trust_score": int(round(sum(scores) / len(scores))) if scores else None,
            "by_trust_state": by_state,
            "needs_attention": attention[:10],
            "needs_attention_total": len(attention),
            "trend": await self._score_trend(db, owner_user_id),
        }

    # ==================================================================
    # Helpers
    # ==================================================================

    @staticmethod
    def _is_stale(profile: Optional[AgentGovernanceProfile]) -> bool:
        if profile is None:
            return True
        return bool(
            profile.needs_policy_review or profile.identity_stale or profile.testing_stale
        )

    @staticmethod
    def _checks_from_profile(
        profile: Optional[AgentGovernanceProfile],
    ) -> List[Dict[str, Any]]:
        breakdown = (profile.trust_dimensions if profile else None) or {}
        checks = breakdown.get("checks")
        if isinstance(checks, list):
            return checks

        # Never reviewed, or scored by a previous format: show the full backlog.
        return [
            {
                "key": key,
                "label": scoring.CHECK_LABELS[key],
                "status": scoring.STATUS_NOT_CONFIGURED,
                "points_earned": 0,
                "points_possible": points,
                "points_available": points,
                "summary": "Not yet reviewed.",
                "fix": "Run a review on this agent.",
                "detail": {},
            }
            for key, points in scoring.CHECK_POINTS.items()
        ]

    @staticmethod
    def _improvements_from_checks(checks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        items = [
            {
                "key": check.get("key"),
                "label": check.get("label"),
                "points": check.get("points_available", 0),
                "status": check.get("status"),
                "reason": check.get("summary"),
                "action": check.get("fix"),
            }
            for check in checks
            if check.get("points_available", 0) > 0 and check.get("fix")
        ]
        items.sort(key=lambda item: item["points"], reverse=True)
        return items

    @staticmethod
    def _attention_reason(state: str, profile: Optional[AgentGovernanceProfile]) -> str:
        if state == "UNREVIEWED":
            return "Never reviewed."
        if profile and (
            profile.needs_policy_review or profile.identity_stale or profile.testing_stale
        ):
            return "The agent changed since its last review."
        if state == "HIGH_RISK":
            return "Trust score is below the safe threshold."
        return "The agent has unearned trust points."

    async def _last_run_summary(
        self, db: AsyncSession, agent_id: str, suite_id: UUID
    ) -> Optional[Dict[str, Any]]:
        run = (
            await db.execute(
                select(TestRun)
                .where(TestRun.agent_id == agent_id, TestRun.suite_id == suite_id)
                .order_by(TestRun.started_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if run is None:
            return None
        return {
            "status": run.status,
            "total": run.total_tests or 0,
            "passed": run.passed_tests or 0,
            "failed": run.failed_tests or 0,
            "results": run.results or [],
            "at": run.completed_at.isoformat() if run.completed_at else None,
        }

    async def _security_summary(self, db: AsyncSession, agent_id: str) -> Dict[str, Any]:
        rows = (
            await db.execute(
                select(RedTeamResult)
                .where(RedTeamResult.agent_id == agent_id)
                .order_by(RedTeamResult.created_at.desc())
                .limit(100)
            )
        ).scalars().all()

        return {
            "total_probes": len(rows),
            "blocked": sum(1 for row in rows if row.blocked),
            "last_scan_at": rows[0].created_at.isoformat() if rows else None,
            "probes": [
                {
                    "attack_type": row.attack_type,
                    "attack_name": row.attack_name,
                    "blocked": row.blocked,
                    "verdict": row.verdict,
                    "rationale": (row.details or {}).get("rationale"),
                }
                for row in rows
            ],
        }

    async def _usage_sites(self, db: AsyncSession, agent: Agent) -> Dict[str, Any]:
        """Workflows and apps that reference this agent. JSONB containment, no table scan."""
        agent_uuid = str(agent.agent_id)
        fragments = [
            json.dumps([{"agent_id": agent_uuid}]),
            json.dumps([{"agent_id": f"agt_{agent.hexaid}"}]),
            json.dumps([{"id": agent_uuid}]),
        ]

        workflows: List[Dict[str, Any]] = []
        try:
            rows = (
                await db.execute(
                    select(Workflow.workflow_id, Workflow.name, Workflow.status).where(
                        Workflow.is_deleted.is_(False),
                        or_(
                            *[
                                Workflow.definition["agents"].contains(cast(fragment, JSONB))
                                for fragment in fragments
                            ]
                        ),
                    )
                )
            ).all()
            workflows = [
                {"workflow_id": str(row.workflow_id), "name": row.name, "status": row.status}
                for row in rows
            ]
        except Exception:
            logger.warning(
                "agent_trust_workflow_lookup_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )

        apps: List[Dict[str, Any]] = []
        try:
            workflow_ids = [item["workflow_id"] for item in workflows]
            predicates = [
                (ApplicationSkillLink.skill_type == "agent")
                & (ApplicationSkillLink.skill_id == agent_uuid)
            ]
            if workflow_ids:
                predicates.append(
                    (ApplicationSkillLink.skill_type == "workflow")
                    & (ApplicationSkillLink.skill_id.in_(workflow_ids))
                )

            rows = (
                await db.execute(
                    select(
                        ApplicationSkillLink.application_id,
                        ApplicationSkillLink.skill_type,
                    ).where(or_(*predicates))
                )
            ).all()
            apps = [
                {
                    "application_id": str(row.application_id),
                    "link": "direct" if row.skill_type == "agent" else "via_workflow",
                }
                for row in rows
            ]
        except Exception:
            logger.warning(
                "agent_trust_app_lookup_failed",
                extra={"agent_id": agent.hexaid},
                exc_info=True,
            )

        return {"workflows": workflows, "apps": apps}

    async def _score_trend(
        self, db: AsyncSession, owner_user_id: Optional[str]
    ) -> List[Dict[str, Any]]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        stmt = (
            select(
                func.date_trunc("day", TrustScoreHistory.recorded_at).label("day"),
                func.avg(TrustScoreHistory.score).label("avg_score"),
                func.count().label("reviews"),
            )
            .where(TrustScoreHistory.recorded_at >= cutoff)
            .group_by("day")
            .order_by("day")
        )
        if owner_user_id is not None:
            stmt = stmt.join(
                AgentGovernanceProfile,
                AgentGovernanceProfile.agent_id == TrustScoreHistory.agent_id,
            ).where(AgentGovernanceProfile.owner_user_id == owner_user_id)

        rows = (await db.execute(stmt)).all()
        return [
            {
                "date": row.day.date().isoformat(),
                "average_trust_score": int(round(float(row.avg_score))),
                "reviews": row.reviews,
            }
            for row in rows
        ]

    async def _get_or_create_profile(
        self, db: AsyncSession, agent: Agent
    ) -> AgentGovernanceProfile:
        profile = (
            await db.execute(
                select(AgentGovernanceProfile).where(
                    AgentGovernanceProfile.agent_id == agent.hexaid
                )
            )
        ).scalar_one_or_none()
        if profile is not None:
            return profile

        from echolib.service.agent_trust.agent_registry_service import AgentRegistryService

        return await AgentRegistryService().register_agent(
            db, agent_id=agent.hexaid, owner_user_id=str(agent.user_id)
        )
