"""
Agent Trust governance models -- all tables in one file per project convention
(one companion module for a whole feature area, mirroring how other
single-purpose domains are kept together elsewhere in this package).

All models share the platform's single Postgres database via
``echolib.database.Base`` -- there is no separate Agent Trust database, and
none of these tables duplicate data already owned by ``agents``,
``api_connectors``/``mcp_connectors``/``oauth_connector_connections``,
``users`` or ``telemetry_events``. They only hold governance-specific state.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, DateTime
from sqlalchemy.dialects.postgresql import JSONB, UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column

from echolib.models.base import BaseModel
from echolib.database import Base

# ---------------------------------------------------------------------------
# Phase 1 -- Agent Registry
# ---------------------------------------------------------------------------

TRUST_UNREVIEWED = "UNREVIEWED"
TRUST_TRUSTED = "TRUSTED"
TRUST_NEEDS_REVIEW = "NEEDS_REVIEW"
TRUST_HIGH_RISK = "HIGH_RISK"
# ---------------------------------------------------------------------------
# Phase 1 -- Agent trust Initialization table
# ---------------------------------------------------------------------------

class AgentTrustInitialization(BaseModel):
    """
    One row per user indicating Agent Trust has completed
    first-time initialization for legacy agents.
    """

    __tablename__ = "agent_trust_initialization"

    id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
    )

    owner_user_id: Mapped[str] = mapped_column(
        String(36),
        nullable=False,
        unique=True,
        index=True,
    )

    initialization_version: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
        server_default="1",
    )

    initialized_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )
class AgentGovernanceProfile(BaseModel):
    """Governance extension row for one ``agents.hexaid`` -- never a duplicate registry."""

    __tablename__ = "agent_governance_profiles"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[str] = mapped_column(
        String(32), ForeignKey("agents.hexaid", ondelete="CASCADE"),
        nullable=False, unique=True, index=True,
    )
    owner_user_id: Mapped[str] = mapped_column(
    String(36),
    nullable=False,
    index=True,
    )

    
    environment: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)

    trust_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    trust_state: Mapped[str] = mapped_column(
    String(50),
    nullable=False,
    default=TRUST_UNREVIEWED,
    server_default=TRUST_UNREVIEWED,
    )
    trust_dimensions: Mapped[Dict[str, Any]] = mapped_column(
    JSONB,
    nullable=False,
    default=dict,
    server_default="{}",
    )
    tags: Mapped[List[str]] = mapped_column(JSONB, nullable=False, default=list)
    needs_policy_review: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    identity_stale: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    testing_stale: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_definition_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    last_evaluated_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)


# ---------------------------------------------------------------------------
# Phase 2 -- Policy Engine + Alerts
# ---------------------------------------------------------------------------

class Policy(BaseModel):

    __tablename__ = "agent_trust_policies"

    id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
    )

    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    description: Mapped[
        Optional[str]
    ] = mapped_column(
        Text,
        nullable=True,
    )

    framework: Mapped[
        Optional[str]
    ] = mapped_column(
        String(50),
        nullable=True,
    )

    severity: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="medium",
    )

    policy_prompt: Mapped[
        Optional[str]
    ] = mapped_column(
        Text,
        nullable=True,
    )

    judge_prompt: Mapped[
        Optional[str]
    ] = mapped_column(
        Text,
        nullable=True,
    )

    is_system_policy: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
    )

    version: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
    )

class PolicyAgentLink(BaseModel):
    """Assignment of a policy to an agent, human- or judge-assigned."""

    __tablename__ = "agent_trust_policy_agent_links"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    policy_id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), ForeignKey("agent_trust_policies.id", ondelete="CASCADE"), nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(String(32), ForeignKey("agents.hexaid", ondelete="CASCADE"), nullable=False, index=True)
    assigned_by: Mapped[str] = mapped_column(String(20), nullable=False, default="human")  # human|judge_llm
    rationale: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

class PolicyEvaluation(Base):

    __tablename__ = (
        "agent_trust_policy_evaluations"
    )

    id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
    )

    policy_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey(
            "agent_trust_policies.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    agent_id: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        index=True,
    )

    passed: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
    )

    score: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )

    agent_response: Mapped[
        Optional[str]
    ] = mapped_column(
        Text,
        nullable=True,
    )

    judge_response: Mapped[
        Dict[str, Any]
    ] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
    )

    evaluated_at: Mapped[
        datetime
    ] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
    )

class PolicyViolation(BaseModel):
    """One failed rule evaluation against an agent's action/content."""

    __tablename__ = "agent_trust_policy_violations"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    policy_id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), ForeignKey("agent_trust_policies.id", ondelete="CASCADE"), nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    context: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(nullable=False)


class Alert(BaseModel):
    """A governance alert -- raised by policy violations, budget breaches, red-team findings, credential expiry."""

    __tablename__ = "agent_trust_alerts"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    alert_type: Mapped[str] = mapped_column(String(50), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    source: Mapped[str] = mapped_column(String(50), nullable=False, default="agent_trust")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")  # open|acknowledged|resolved|suppressed
    details: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    acknowledged_by: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)
    resolved_by: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)
    resolution_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


# ---------------------------------------------------------------------------
# Phase 3 -- Identity & Trust
# ---------------------------------------------------------------------------

class IdentitySnapshot(BaseModel):
    """Declared-vs-observed identity evaluation for an agent, point-in-time."""

    __tablename__ = "agent_trust_identity_snapshots"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[str] = mapped_column(String(32), ForeignKey("agents.hexaid", ondelete="CASCADE"), nullable=False, index=True)
    declared: Mapped[List[Dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    observed: Mapped[List[Dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    drift_flags: Mapped[List[Dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    hygiene_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    evaluated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )


class TrustScoreHistory(BaseModel):
    """Weighted composite trust score snapshot, recorded per governance review."""

    __tablename__ = "agent_trust_score_history"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[str] = mapped_column(String(32), ForeignKey("agents.hexaid", ondelete="CASCADE"), nullable=False, index=True)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    previous_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    band: Mapped[str] = mapped_column(String(20), nullable=False)  # critical|low|moderate|high|verified
    factors: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    is_provisional: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(nullable=False)


# ---------------------------------------------------------------------------
# Phase 4 -- Testing & QA
# ---------------------------------------------------------------------------

class TestSuite(BaseModel):
    """A seeded or custom functional test suite."""

    __tablename__ = "agent_trust_test_suites"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    suite_type: Mapped[str] = mapped_column(String(30), nullable=False, default="functional")  # functional|red_team
    agent_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    test_cases: Mapped[List[Dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    is_seeded: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class TestRun(BaseModel):
    """One execution of a test suite against an agent."""

    __tablename__ = "agent_trust_test_runs"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    suite_id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), ForeignKey("agent_trust_test_suites.id", ondelete="CASCADE"), nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="queued")  # queued|running|passed|failed|error
    total_tests: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    passed_tests: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    failed_tests: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    results: Mapped[List[Dict[str, Any]]] = mapped_column(JSONB, nullable=False, default=list)
    triggered_by: Mapped[str] = mapped_column(String(20), nullable=False, default="manual")  # manual|create|modify
    started_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)


class RedTeamResult(BaseModel):
    """One adversarial probe outcome."""

    __tablename__ = "agent_trust_red_team_results"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    run_id: Mapped[Optional[UUID]] = mapped_column(PG_UUID(as_uuid=True), nullable=True, index=True)
    attack_type: Mapped[str] = mapped_column(String(50), nullable=False)
    attack_name: Mapped[str] = mapped_column(String(255), nullable=False)
    payload: Mapped[str] = mapped_column(Text, nullable=False)
    response: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    blocked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    verdict: Mapped[str] = mapped_column(String(20), nullable=False, default="unknown")  # blocked|partial|complied
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    stage: Mapped[str] = mapped_column(String(20), nullable=False, default="policy")  # policy|model
    details: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)


class EvaluationResult(BaseModel):
    """Judge LLM scoring record for one functional or red-team test case."""

    __tablename__ = "agent_trust_evaluation_results"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    run_id: Mapped[Optional[UUID]] = mapped_column(PG_UUID(as_uuid=True), nullable=True, index=True)
    evaluation_type: Mapped[str] = mapped_column(String(50), nullable=False)  # semantic_judge|red_team_verdict
    evaluator: Mapped[str] = mapped_column(String(20), nullable=False, default="judge_llm")
    score: Mapped[float] = mapped_column(Float, nullable=False)
    passed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    details: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)


# ---------------------------------------------------------------------------
# Phase 5 -- Cost Governance
# ---------------------------------------------------------------------------

class CostRecord(BaseModel):
    """One cost attribution row, derived from a telemetry_events LLM/tool call."""

    __tablename__ = "agent_trust_cost_records"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    agent_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    # Unique per source telemetry event -- makes the live-subscribe + periodic
    # reconciliation paths idempotent against each other.
    source_event_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, unique=True, index=True)
    department: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    provider: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    input_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    billing_source: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(nullable=False)


class Budget(BaseModel):
    """A spend cap at org/department/agent scope."""

    __tablename__ = "agent_trust_budgets"

    id: Mapped[UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    scope: Mapped[str] = mapped_column(String(20), nullable=False)  # org|department|agent
    scope_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    limit_usd: Mapped[float] = mapped_column(Float, nullable=False)
    period: Mapped[str] = mapped_column(String(20), nullable=False, default="monthly")  # daily|weekly|monthly
    alert_threshold_pct: Mapped[float] = mapped_column(Float, nullable=False, default=80.0)
    hard_stop: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


# ---------------------------------------------------------------------------
# Phase 6 -- Audit Trail (hash-chained)
# ---------------------------------------------------------------------------

class AuditLog(BaseModel):
    """
    Immutable, hash-chained governance audit entry.

    ``agent_id`` is intentionally NOT a foreign key -- the trail must survive
    the agent's own deletion, matching the original design intent.
    """

    __tablename__ = "agent_trust_audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agent_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    event_type: Mapped[str] = mapped_column(String(80), nullable=False)
    actor: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    action: Mapped[str] = mapped_column(String(200), nullable=False)
    resource: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    outcome: Mapped[str] = mapped_column(String(32), nullable=False, default="success")
    severity: Mapped[str] = mapped_column(String(32), nullable=False, default="info")
    details: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    correlation_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(nullable=False)
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    entry_hash: Mapped[str] = mapped_column(String(64), nullable=False)


GENESIS_HASH = "0" * 64

class PolicyRecommendation(BaseModel):
    __tablename__ = "agent_trust_policy_recommendations"

    id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
    )

    agent_id: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        index=True,
    )

    recommended_policy_ids: Mapped[list[str]] = mapped_column(
        JSONB,
        nullable=False,
        default=list,
    )

    recommendation_reasoning: Mapped[dict] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
    )

    accepted: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
    )

    created_by: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    accepted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
    )