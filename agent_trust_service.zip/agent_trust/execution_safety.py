"""Agent Trust production-execution safety checks.

Agent Trust may execute review checks through the real runtime only when the
execution surface is demonstrably safe for a verification prompt. The module
is intentionally fail-closed. It does not change connector permissions.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Dict, List, Mapping

from echolib.agent_contract import attached_connectors
from apps.connector.middleware.refs import (
    KIND_API,
    KIND_DATABASE,
    KIND_MCP,
    resolve_agent_connectors,
)

logger = logging.getLogger(__name__)

SAFE_API_METHOD = "GET"
SAFE_DB_ACCESS_LEVEL = "read_only"
BLOCKED_WORKFLOW_NODE_TYPES = frozenset({"api", "mcp", "code"})


@dataclass(frozen=True)
class ExecutionSafetyResult:
    allowed: bool
    blocked_connectors: tuple[Dict[str, Any], ...] = ()
    blocked_nodes: tuple[Dict[str, Any], ...] = ()

    @property
    def reason(self) -> str | None:
        if self.allowed:
            return None
        parts: list[str] = []
        if self.blocked_connectors:
            names = ", ".join(
                str(item.get("alias") or item.get("connector_id") or "unknown")
                for item in self.blocked_connectors
            )
            parts.append(f"connector(s): {names}")
        if self.blocked_nodes:
            names = ", ".join(
                str(item.get("name") or item.get("node_id") or "unknown")
                for item in self.blocked_nodes
            )
            parts.append(f"workflow node(s): {names}")
        return "Production verification blocked for " + " and ".join(parts) + "."


async def check_agent_test_safety(agent: Any) -> ExecutionSafetyResult:
    """Check one agent's attached connectors."""
    definition = getattr(agent, "definition", None) or {}
    owner_user_id = str(getattr(agent, "user_id", "") or "").strip()
    return await _check_definition(definition, owner_user_id=owner_user_id, agent_id=getattr(agent, "hexaid", None))


async def check_workflow_test_safety(
    workflow: Mapping[str, Any],
    *,
    owner_user_id: str,
) -> ExecutionSafetyResult:
    """
    Check the complete runtime surface of a workflow review.

    A workflow review executes the whole workflow, so every agent in that
    workflow must pass connector safety. Non-agent API/MCP/Code nodes are
    blocked because their side effects are outside the agent connector gate.
    """
    blocked_connectors: list[Dict[str, Any]] = []
    blocked_nodes: list[Dict[str, Any]] = []

    for entry in workflow.get("agents", []) or []:
        if not isinstance(entry, Mapping):
            continue
        metadata = entry.get("metadata") or {}
        node_type = str(
            entry.get("node_type")
            or metadata.get("node_type")
            or "agent"
        ).strip().lower()
        if node_type in BLOCKED_WORKFLOW_NODE_TYPES:
            blocked_nodes.append({
                "node_id": str(entry.get("agent_id") or entry.get("id") or ""),
                "name": str(entry.get("name") or entry.get("agent_id") or "unknown"),
                "node_type": node_type,
                "reason": f"workflow {node_type.upper()} nodes are not approved for production review execution",
            })

    # Resolve only actual agent nodes. Start/End/HITL/router nodes are workflow
    # control nodes and must not be treated as missing Agent rows.
    agent_entries = []
    for entry in workflow.get("agents", []) or []:
        if not isinstance(entry, Mapping):
            continue
        metadata = entry.get("metadata") or {}
        node_type = str(
            entry.get("node_type")
            or metadata.get("node_type")
            or "agent"
        ).strip().lower()
        if node_type in BLOCKED_WORKFLOW_NODE_TYPES:
            continue
        if node_type in {"start", "end", "hitl", "conditional", "router", "self-review", "review"}:
            continue
        agent_entries.append(entry)

    try:
        from apps.workflow.runtime.agent_resolution import resolve_workflow_agents

        resolved_agents = await asyncio.to_thread(
            resolve_workflow_agents,
            {"agents": agent_entries},
            owner_user_id,
        )
    except Exception as exc:
        logger.exception("agent_trust_workflow_agent_resolution_failed")
        return ExecutionSafetyResult(
            allowed=False,
            blocked_connectors=(
                {
                    "alias": "workflow",
                    "kind": "unknown",
                    "reason": f"workflow agent resolution failed: {exc}",
                },
            ),
            blocked_nodes=tuple(blocked_nodes),
        )

    for agent_id, definition in resolved_agents.items():
        if not isinstance(definition, dict):
            blocked_connectors.append({
                "connector_id": str(agent_id),
                "alias": str(agent_id),
                "kind": "unknown",
                "reason": "agent definition could not be resolved",
            })
            continue

        node_type = str(
            (definition.get("metadata") or {}).get("node_type")
            or definition.get("node_type")
            or "agent"
        ).strip().lower()
        if node_type in {"start", "end", "hitl", "conditional", "router", "self-review", "review"}:
            continue
        if node_type in BLOCKED_WORKFLOW_NODE_TYPES:
            continue

        result = await _check_definition(
            definition,
            owner_user_id=owner_user_id,
            agent_id=str(agent_id),
        )
        blocked_connectors.extend(result.blocked_connectors)

    return ExecutionSafetyResult(
        allowed=not blocked_connectors and not blocked_nodes,
        blocked_connectors=tuple(blocked_connectors),
        blocked_nodes=tuple(blocked_nodes),
    )


async def _check_definition(
    definition: Mapping[str, Any],
    *,
    owner_user_id: str,
    agent_id: str | None = None,
) -> ExecutionSafetyResult:
    entries = attached_connectors(definition)
    if not entries:
        return ExecutionSafetyResult(allowed=True)

    resolved = await asyncio.to_thread(
        resolve_agent_connectors,
        dict(definition),
        owner_user_id,
        owner_user_id=owner_user_id,
    )

    blocked: List[Dict[str, Any]] = []

    for connector in resolved:
        connector_id = str(connector.connector_id or "")
        alias = str(connector.alias or connector_id or "unknown")
        kind = str(connector.kind or "").strip().lower()

        if not connector.resolved:
            blocked.append({
                "connector_id": connector_id,
                "alias": alias,
                "kind": kind or "unknown",
                "reason": "connector could not be resolved",
                "agent_id": agent_id,
            })
            continue

        if kind == KIND_DATABASE:
            access_level = str(connector.access_level or "").strip().lower()
            allowed_operations = {
                str(operation).strip().lower()
                for operation in (connector.allowed_operations or ())
            }
            if access_level != SAFE_DB_ACCESS_LEVEL:
                blocked.append({
                    "connector_id": connector_id,
                    "alias": alias,
                    "kind": kind,
                    "reason": "database connector is not read_only",
                    "access_level": access_level or "unknown",
                    "agent_id": agent_id,
                })
            elif "write" in allowed_operations:
                blocked.append({
                    "connector_id": connector_id,
                    "alias": alias,
                    "kind": kind,
                    "reason": "database connector permits write operations",
                    "access_level": access_level,
                    "allowed_operations": sorted(allowed_operations),
                    "agent_id": agent_id,
                })
            continue

        if kind == KIND_API:
            record = connector.record or {}
            method = str(record.get("method") or "").strip().upper()
            if method != SAFE_API_METHOD:
                blocked.append({
                    "connector_id": connector_id,
                    "alias": alias,
                    "kind": kind,
                    "reason": "API connector is not GET-only",
                    "method": method or "unknown",
                    "agent_id": agent_id,
                })
            continue

        if kind == KIND_MCP:
            blocked.append({
                "connector_id": connector_id,
                "alias": alias,
                "kind": kind,
                "reason": "MCP is not approved for production review execution",
                "agent_id": agent_id,
            })
            continue

        blocked.append({
            "connector_id": connector_id,
            "alias": alias,
            "kind": kind or "unknown",
            "reason": "unknown connector type",
            "agent_id": agent_id,
        })

    result = ExecutionSafetyResult(
        allowed=not blocked,
        blocked_connectors=tuple(blocked),
    )
    if not result.allowed:
        logger.warning(
            "agent_trust_execution_blocked",
            extra={"agent_id": agent_id, "blocked_connectors": blocked},
        )
    return result
