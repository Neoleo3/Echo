"""
Agent Trust event trail -- the single append-only substrate behind the agent
timeline, plus the alert records that hang off it.

Every meaningful thing that happens to an agent lands here as one immutable,
hash-chained row: created, updated, reviewed, policy attached, suite run,
security scanned, invoked inside a workflow or app. Reading the rows back for
one agent in order produces the commit-graph style history the product shows;
each entry carries its own hash and its parent's, so the chain is both
verifiable and visibly linked.

Deliberately NOT a foreign key on ``agent_id`` -- the trail must outlive the
agent it describes.
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent
from echolib.models.agent_trust import Alert, AuditLog, GENESIS_HASH
from echolib.repositories.notification_repo import NotificationRepository

logger = logging.getLogger(__name__)

_notification_repo = NotificationRepository()

# ---------------------------------------------------------------------------
# Event vocabulary -- the only strings the timeline will ever emit.
# ---------------------------------------------------------------------------

EVENT_AGENT_CREATED = "agent.created"
EVENT_AGENT_UPDATED = "agent.updated"
EVENT_AGENT_LINKED_WORKFLOW = "agent.linked_to_workflow"
EVENT_AGENT_REVIEWED = "agent.reviewed"
EVENT_POLICY_ASSIGNED = "agent.policy_assigned"
EVENT_POLICY_REMOVED = "agent.policy_removed"
EVENT_SUITE_ADDED = "agent.suite_added"
EVENT_SUITE_REMOVED = "agent.suite_removed"
EVENT_SUITE_RUN = "agent.suite_run"
EVENT_SECURITY_SCAN = "agent.security_scan"
EVENT_IDENTITY_CHECK = "agent.identity_check"
EVENT_REVIEW_STAGE = "agent.review_stage"
EVENT_AGENT_INVOKED = "agent.invoked"
EVENT_ALERT_RAISED = "agent.alert"

# Timeline filter buckets. "run" is high-volume and excluded by default.
CATEGORY_LIFECYCLE = "lifecycle"
CATEGORY_GOVERNANCE = "governance"
CATEGORY_TESTING = "testing"
CATEGORY_SECURITY = "security"
CATEGORY_RUN = "run"

EVENT_CATEGORY: Dict[str, str] = {
    EVENT_AGENT_CREATED: CATEGORY_LIFECYCLE,
    EVENT_AGENT_UPDATED: CATEGORY_LIFECYCLE,
    EVENT_AGENT_LINKED_WORKFLOW: CATEGORY_LIFECYCLE,
    EVENT_AGENT_REVIEWED: CATEGORY_GOVERNANCE,
    EVENT_POLICY_ASSIGNED: CATEGORY_GOVERNANCE,
    EVENT_POLICY_REMOVED: CATEGORY_GOVERNANCE,
    EVENT_SUITE_ADDED: CATEGORY_TESTING,
    EVENT_SUITE_REMOVED: CATEGORY_TESTING,
    EVENT_SUITE_RUN: CATEGORY_TESTING,
    EVENT_SECURITY_SCAN: CATEGORY_SECURITY,
    EVENT_IDENTITY_CHECK: CATEGORY_SECURITY,
    EVENT_REVIEW_STAGE: CATEGORY_GOVERNANCE,
    EVENT_ALERT_RAISED: CATEGORY_SECURITY,
    EVENT_AGENT_INVOKED: CATEGORY_RUN,
}

ALL_CATEGORIES = (
    CATEGORY_LIFECYCLE,
    CATEGORY_GOVERNANCE,
    CATEGORY_TESTING,
    CATEGORY_SECURITY,
    CATEGORY_RUN,
)

DEFAULT_TIMELINE_CATEGORIES = (
    CATEGORY_LIFECYCLE,
    CATEGORY_GOVERNANCE,
    CATEGORY_TESTING,
    CATEGORY_SECURITY,
)

# Event types written before the vocabulary above existed.
_LEGACY_EVENT_ALIASES: Dict[str, str] = {
    "governance_review": EVENT_AGENT_REVIEWED,
    "agent_invocation": EVENT_AGENT_INVOKED,
}


def _canonical_timestamp(ts: datetime) -> str:
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts.astimezone(timezone.utc).isoformat()


def _chain_payload(entry: AuditLog) -> str:
    return json.dumps(
        {
            "agent_id": entry.agent_id,
            "event_type": entry.event_type,
            "actor": entry.actor,
            "action": entry.action,
            "resource": entry.resource,
            "outcome": entry.outcome,
            "severity": entry.severity,
            "details": entry.details or {},
            "correlation_id": entry.correlation_id,
            "timestamp": _canonical_timestamp(entry.timestamp),
            "prev_hash": entry.prev_hash or GENESIS_HASH,
        },
        sort_keys=True,
        default=str,
    )


def _sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class AuditService:
    """Writes the chain, reads the timeline, and owns agent alerts."""

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    async def log_event(
        self,
        db: AsyncSession,
        *,
        event_type: str,
        action: str,
        agent_id: Optional[str] = None,
        actor: Optional[str] = None,
        resource: Optional[str] = None,
        outcome: str = "success",
        severity: str = "info",
        details: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
    ) -> AuditLog:
        # The audit trail is one global hash chain. Serialize writers inside
        # the current PostgreSQL transaction so concurrent requests cannot
        # create two entries pointing at the same parent hash.
        await db.execute(text("SELECT pg_advisory_xact_lock(:lock_key)"), {"lock_key": 83421731})
        last = (
            await db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1))
        ).scalar_one_or_none()
        prev_hash = last.entry_hash if last else GENESIS_HASH

        entry = AuditLog(
            agent_id=agent_id,
            event_type=event_type,
            actor=actor,
            action=action,
            resource=resource,
            outcome=outcome,
            severity=severity,
            details=details or {},
            correlation_id=correlation_id,
            timestamp=datetime.now(timezone.utc),
            prev_hash=prev_hash,
            entry_hash="",
        )
        entry.entry_hash = _sha256_hex(_chain_payload(entry))

        db.add(entry)
        await db.flush()
        return entry

    async def record(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        event_type: str,
        action: str,
        actor: Optional[str] = None,
        severity: str = "info",
        outcome: str = "success",
        details: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
    ) -> Optional[AuditLog]:
        """
        Best-effort timeline write. A gap in the timeline is preferable to
        failing the operation being recorded, so errors are logged, not raised.
        """
        try:
            # Keep a timeline write from poisoning the review transaction if
            # the audit table/hash chain has a transient persistence error.
            async with db.begin_nested():
                return await self.log_event(
                    db,
                    event_type=event_type,
                    action=action,
                    agent_id=agent_id,
                    actor=actor,
                    severity=severity,
                    outcome=outcome,
                    details=details,
                    correlation_id=correlation_id,
                )
        except Exception:
            logger.warning(
                "agent_trust_timeline_write_failed",
                extra={"agent_id": agent_id, "event_type": event_type},
                exc_info=True,
            )
            return None

    # ------------------------------------------------------------------
    # Read -- timeline
    # ------------------------------------------------------------------

    async def get_timeline(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        categories: Optional[List[str]] = None,
        before_seq: Optional[int] = None,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """
        Newest-first slice of one agent's chain.

        Entries carry ``seq`` plus their own and their parent's hash so the
        client can render the chain as a graph; ``next_cursor`` pages backwards.
        """
        wanted = set(categories or DEFAULT_TIMELINE_CATEGORIES)
        event_types = [
            event for event, category in EVENT_CATEGORY.items() if category in wanted
        ]
        for legacy, canonical in _LEGACY_EVENT_ALIASES.items():
            if EVENT_CATEGORY.get(canonical) in wanted:
                event_types.append(legacy)

        stmt = select(AuditLog).where(
            AuditLog.agent_id == agent_id,
            AuditLog.event_type.in_(event_types),
        )
        if before_seq is not None:
            stmt = stmt.where(AuditLog.id < before_seq)

        rows = list(
            (await db.execute(stmt.order_by(AuditLog.id.desc()).limit(limit + 1)))
            .scalars()
            .all()
        )

        has_more = len(rows) > limit
        rows = rows[:limit]

        return {
            "entries": [self._to_timeline_entry(row) for row in rows],
            "next_cursor": rows[-1].id if (has_more and rows) else None,
            "has_more": has_more,
        }

    def _to_timeline_entry(self, row: AuditLog) -> Dict[str, Any]:
        event_type = _LEGACY_EVENT_ALIASES.get(row.event_type, row.event_type)
        details = row.details or {}
        return {
            "seq": row.id,
            "event": event_type,
            "category": EVENT_CATEGORY.get(event_type, CATEGORY_LIFECYCLE),
            "title": self._title_for(event_type, row, details),
            "at": _canonical_timestamp(row.timestamp),
            "actor": row.actor,
            "outcome": row.outcome,
            "severity": row.severity,
            "details": details,
            "hash": (row.entry_hash or "")[:12],
            "parent_hash": (row.prev_hash or "")[:12],
        }

    @staticmethod
    def _title_for(event_type: str, row: AuditLog, details: Dict[str, Any]) -> str:
        if event_type == EVENT_AGENT_CREATED:
            return "Agent created"
        if event_type == EVENT_AGENT_UPDATED:
            changed = details.get("changed") or []
            return f"Agent updated ({', '.join(changed)})" if changed else "Agent updated"
        if event_type == EVENT_AGENT_LINKED_WORKFLOW:
            target = details.get("workflow_name") or details.get("workflow_id") or ""
            return f"Used in workflow {target}".strip()
        if event_type == EVENT_AGENT_REVIEWED:
            score = details.get("trust_score")
            previous = details.get("previous_score")
            if score is None:
                return "Reviewed"
            if previous is not None and previous != score:
                direction = "up" if score > previous else "down"
                return f"Reviewed -- trust score {direction} from {previous} to {score}"
            return f"Reviewed -- trust score {score}"
        if event_type == EVENT_POLICY_ASSIGNED:
            return f"Policy assigned: {details.get('policy_name') or details.get('policy_id')}"
        if event_type == EVENT_POLICY_REMOVED:
            return f"Policy removed: {details.get('policy_name') or details.get('policy_id')}"
        if event_type == EVENT_SUITE_ADDED:
            return f"Test suite added: {details.get('suite_name')}"
        if event_type == EVENT_SUITE_REMOVED:
            return f"Test suite removed: {details.get('suite_name')}"
        if event_type == EVENT_SUITE_RUN:
            return f"Tests run -- {details.get('passed', 0)}/{details.get('total', 0)} passed"
        if event_type == EVENT_SECURITY_SCAN:
            return f"Security scan -- {details.get('blocked', 0)}/{details.get('total', 0)} probes blocked"
        if event_type == EVENT_IDENTITY_CHECK:
            return "Credential check completed"
        if event_type == EVENT_REVIEW_STAGE:
            stage = details.get("stage") or "review"
            status = details.get("status") or row.outcome or "completed"
            labels = {
                "identity": "Identity check",
                "policy": "Policy checks",
                "security": "Security tests",
                "functional": "Functional tests",
            }
            return f"{labels.get(stage, stage.title())} {status}"
        if event_type == EVENT_AGENT_INVOKED:
            feature = details.get("feature")
            return f"Run in {feature}" if feature else "Agent run"
        if event_type == EVENT_ALERT_RAISED:
            return str(details.get("title") or "Alert raised")
        return row.action or event_type

    # ------------------------------------------------------------------
    # Read -- integrity + counters
    # ------------------------------------------------------------------

    async def verify_chain(self, db: AsyncSession) -> Dict[str, Any]:
        entries = list(
            (await db.execute(select(AuditLog).order_by(AuditLog.id.asc()))).scalars().all()
        )

        expected_prev = GENESIS_HASH
        for entry in entries:
            if entry.prev_hash != expected_prev:
                return {"valid": False, "broken_at_id": entry.id, "reason": "prev_hash mismatch"}
            if _sha256_hex(_chain_payload(entry)) != entry.entry_hash:
                return {"valid": False, "broken_at_id": entry.id, "reason": "entry_hash mismatch"}
            expected_prev = entry.entry_hash

        return {"valid": True, "total_entries": len(entries)}

    async def get_stats(self, db: AsyncSession) -> Dict[str, Any]:
        total = (await db.execute(select(func.count()).select_from(AuditLog))).scalar_one()
        return {"total_events": total}

    # ------------------------------------------------------------------
    # Alerts -- internal only; surfaced through the agent overview and timeline.
    # ------------------------------------------------------------------

    async def raise_alert(
        self,
        db: AsyncSession,
        *,
        alert_type: str,
        severity: str,
        title: str,
        message: Optional[str] = None,
        agent_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        notify: bool = True,
    ) -> Alert:
        # One open alert per (agent, type) -- noisy sources must not flood the feed.
        existing = (
            await db.execute(
                select(Alert).where(
                    Alert.agent_id == agent_id,
                    Alert.alert_type == alert_type,
                    Alert.status == "open",
                )
            )
        ).scalar_one_or_none()
        if existing:
            return existing

        alert = Alert(
            id=uuid4(),
            agent_id=agent_id,
            alert_type=alert_type,
            severity=severity,
            title=title,
            message=message,
            details=details or {},
            status="open",
        )
        db.add(alert)
        await db.flush()

        if agent_id:
            await self.record(
                db,
                agent_id=agent_id,
                event_type=EVENT_ALERT_RAISED,
                action=alert_type,
                severity=severity,
                details={"title": title, "message": message, **(details or {})},
            )

        if notify:
            await self._notify(db, alert)

        return alert

    async def list_alerts(
        self,
        db: AsyncSession,
        *,
        status: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[Alert]:
        stmt = select(Alert)
        if status:
            stmt = stmt.where(Alert.status == status)
        if agent_id:
            stmt = stmt.where(Alert.agent_id == agent_id)
        return list(
            (await db.execute(stmt.order_by(Alert.created_at.desc()).limit(limit)))
            .scalars()
            .all()
        )

    async def count_open_alerts(self, db: AsyncSession, *, agent_id: str) -> int:
        return (
            await db.execute(
                select(func.count())
                .select_from(Alert)
                .where(Alert.agent_id == agent_id, Alert.status == "open")
            )
        ).scalar_one()

    async def get_alert_stats(self, db: AsyncSession) -> Dict[str, Any]:
        open_count = (
            await db.execute(
                select(func.count()).select_from(Alert).where(Alert.status == "open")
            )
        ).scalar_one()
        critical_count = (
            await db.execute(
                select(func.count())
                .select_from(Alert)
                .where(Alert.status == "open", Alert.severity == "critical")
            )
        ).scalar_one()
        return {"open_alerts": open_count, "critical_open_alerts": critical_count}

    async def _notify(self, db: AsyncSession, alert: Alert) -> None:
        try:
            if not alert.agent_id:
                return
            agent = await db.get(Agent, alert.agent_id)
            if agent is None:
                return

            await _notification_repo.create_bulk_notifications(
                db,
                user_ids=[str(agent.user_id)],
                type="governance_alert",
                title=alert.title,
                message=alert.message,
                reference_id=str(UUID(hex=alert.agent_id)),
                reference_type="agent",
            )
        except Exception:
            # Notification delivery is best-effort -- never fails the alert itself.
            logger.warning(
                "agent_trust_alert_notification_failed",
                extra={"alert_id": str(alert.id)},
                exc_info=True,
            )
