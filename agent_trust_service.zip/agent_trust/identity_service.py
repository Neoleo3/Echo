"""
Identity & Trust service (Phase 3) -- on-demand only.

An agent has no identity of its own: declared side reads the connector
attachments in ``agents.definition.connectors[]`` and checks each against the
OWNER's live connector/OAuth records; observed side mines what was actually
used from ``telemetry_events``. Drift between the two is itself a signal.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.agent_contract import attached_connectors
from echolib.models import Agent
from echolib.models.connectors import APIConnectorRecord, MCPConnectorRecord, OAuthConnectorConnection
from echolib.models.telemetry import TelemetryEvent
from echolib.models.agent_trust import IdentitySnapshot

OBSERVED_LOOKBACK_DAYS = 30
EXPIRING_SOON_DAYS = 7


class IdentityService:
    async def evaluate(self, db: AsyncSession, *, agent_id: str) -> Dict[str, Any]:
        agent = await db.get(Agent, agent_id)
        if agent is None:
            return {"error": "agent_not_found"}

        declared = await self._declared_attachments(db, agent)
        observed = await self._observed_usage(db, agent_id)
        drift_flags = self._detect_drift(declared, observed)
        hygiene_score = self._hygiene_score(declared, drift_flags)

        snapshot = IdentitySnapshot(
            id=uuid4(), agent_id=agent_id, declared=declared, observed=observed,
            drift_flags=drift_flags, hygiene_score=hygiene_score,
            evaluated_at=datetime.now(timezone.utc),
        )
        db.add(snapshot)
        await db.flush()

        return {
            "declared": declared,
            "observed": observed,
            "drift_flags": drift_flags,
            "hygiene_score": hygiene_score,
            "evaluated_at": snapshot.evaluated_at.isoformat(),
        }

    async def latest_snapshot(self, db: AsyncSession, *, agent_id: str) -> Optional[IdentitySnapshot]:
        stmt = (
            select(IdentitySnapshot)
            .where(IdentitySnapshot.agent_id == agent_id)
            .order_by(IdentitySnapshot.evaluated_at.desc())
            .limit(1)
        )
        return (await db.execute(stmt)).scalar_one_or_none()

    # ------------------------------------------------------------------
    # Declared side
    # ------------------------------------------------------------------

    async def _declared_attachments(self, db: AsyncSession, agent: Agent) -> List[Dict[str, Any]]:
        entries = attached_connectors(agent.definition or {})
        owner_id = agent.user_id
        results: List[Dict[str, Any]] = []

        for entry in entries:
            connector_id = entry.get("connector_id")
            kind = entry.get("kind")
            status_info: Dict[str, Any] = {"live_status": "unknown"}

            if kind == "api":
                record = (
                    await db.execute(
                        select(APIConnectorRecord).where(
                            APIConnectorRecord.user_id == owner_id,
                            APIConnectorRecord.connector_id == connector_id,
                        )
                    )
                ).scalar_one_or_none()
                if record:
                    status_info = {
                        "live_status": record.status,
                        "enabled": record.enabled,
                        "last_tested_at": record.last_tested_at.isoformat() if record.last_tested_at else None,
                    }
            elif kind == "mcp":
                record = (
                    await db.execute(
                        select(MCPConnectorRecord).where(
                            MCPConnectorRecord.user_id == owner_id,
                            MCPConnectorRecord.connector_id == connector_id,
                        )
                    )
                ).scalar_one_or_none()
                if record:
                    status_info = {"live_status": "connected" if record.connected else "disconnected"}
            elif kind == "oauth":
                record = (
                    await db.execute(
                        select(OAuthConnectorConnection).where(
                            OAuthConnectorConnection.user_id == owner_id,
                            OAuthConnectorConnection.provider == connector_id,
                        )
                    )
                ).scalar_one_or_none()
                if record:
                    expires_at = record.expires_at
                    days_left = (
                        (expires_at - datetime.now(timezone.utc)).days
                        if expires_at else None
                    )
                    status_info = {
                        "live_status": record.status,
                        "expires_at": expires_at.isoformat() if expires_at else None,
                        "days_until_expiry": days_left,
                        "expiring_soon": days_left is not None and days_left <= EXPIRING_SOON_DAYS,
                    }

            results.append(
                {
                    "connector_id": connector_id,
                    "kind": kind,
                    "alias": entry.get("alias"),
                    "access_level": entry.get("access_level"),
                    "allowed_operations": entry.get("allowed_operations", []),
                    "enabled": entry.get("enabled", True),
                    **status_info,
                }
            )

        return results

    # ------------------------------------------------------------------
    # Observed side
    # ------------------------------------------------------------------

    async def _observed_usage(self, db: AsyncSession, agent_id: str) -> List[Dict[str, Any]]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=OBSERVED_LOOKBACK_DAYS)
        stmt = (
            select(
                TelemetryEvent.credential_id,
                TelemetryEvent.credential_name,
                TelemetryEvent.provider,
                TelemetryEvent.tool_name,
                func.count().label("calls"),
                func.max(TelemetryEvent.timestamp).label("last_used_at"),
            )
            .where(TelemetryEvent.agent_id == agent_id, TelemetryEvent.timestamp >= cutoff)
            .group_by(
                TelemetryEvent.credential_id, TelemetryEvent.credential_name,
                TelemetryEvent.provider, TelemetryEvent.tool_name,
            )
        )
        rows = (await db.execute(stmt)).all()
        return [
            {
                "credential_id": row.credential_id,
                "credential_name": row.credential_name,
                "provider": row.provider,
                "tool_name": row.tool_name,
                "calls": row.calls,
                "last_used_at": row.last_used_at.isoformat() if row.last_used_at else None,
            }
            for row in rows
        ]

    # ------------------------------------------------------------------
    # Drift + scoring
    # ------------------------------------------------------------------

    def _detect_drift(
        self, declared: List[Dict[str, Any]], observed: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        declared_tools = {d.get("connector_id") for d in declared if d.get("connector_id")}
        observed_tools = {o.get("tool_name") for o in observed if o.get("tool_name")}

        flags = []
        for tool in observed_tools - declared_tools:
            flags.append({"type": "undeclared_usage", "tool": tool})
        for connector_id in declared_tools - observed_tools:
            flags.append({"type": "stale_attachment", "connector_id": connector_id})
        return flags

    def _hygiene_score(self, declared: List[Dict[str, Any]], drift_flags: List[Dict[str, Any]]) -> float:
        if not declared:
            return 100.0
        healthy = sum(
            1 for d in declared
            if d.get("live_status") in ("active", "connected") and not d.get("expiring_soon")
        )
        base = (healthy / len(declared)) * 100
        penalty = min(len(drift_flags) * 5, 40)
        return round(max(base - penalty, 0.0), 2)
