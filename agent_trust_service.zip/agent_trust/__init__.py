"""Agent Trust service layer -- shared business logic used by apps/agent_trust routes."""
