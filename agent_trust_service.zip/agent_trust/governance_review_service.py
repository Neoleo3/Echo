"""
Governance Review & Score service (Phase 7) -- on-demand, partial-aware.

Aggregates policy compliance (Phase 2), red-team/test results (Phase 4),
credential hygiene (Phase 3), and operational stability (continuous
telemetry) into one weighted trust score. Any component never evaluated for
this agent is excluded and the remaining weights are renormalized, with the
snapshot flagged ``is_provisional``.
"""

from __future__ import annotations
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from echolib.models.telemetry import TelemetryEvent
from echolib.service.agent_trust.alert_service import AlertService
from echolib.service.agent_trust.audit_service import AuditService
from echolib.service.agent_trust.policy_service import (
    PolicyService,
)
from echolib.service.agent_trust.identity_service import IdentityService
from echolib.models.agent_trust import (
    AgentGovernanceProfile,
    Budget,
    CostRecord,
    PolicyViolation,
    RedTeamResult,
    TestRun,
    TrustScoreHistory,
)
from echolib.service.agent_trust.capability_service import (
    CapabilityAnalysisService,
)
from echolib.service.agent_trust.testing_service import (
    TestingService,
)
from echolib.models import (
    Agent,
    Workflow,
    AgentFile,
    AgentKnowledgeBaseLink,
)
from echolib.service.agent_trust.security_catalog import (
SECURITY_CATALOG,
)
logger = logging.getLogger(__name__)
TRUST_WEIGHTS = {
    "identity": 0.15,
    "design": 0.20,
    "security": 0.25,
    "functional": 0.20,
    "runtime": 0.10,
    "cost": 0.10,
}
BANDS = [
    (0, 40, "critical"),
    (40, 60, "low"),
    (60, 80, "moderate"),
    (80, 95, "high"),
    (95, 101, "verified"),
]

def _trust_state(
    score: float,
    identity_stale: bool,
    testing_stale: bool,
    policy_review_required: bool = False,
) -> str:

    if (
        identity_stale
        or testing_stale
        or policy_review_required
    ):
        return "NEEDS_REVIEW"

    if score < 70:
        return "HIGH_RISK"

    return "TRUSTED"

def _band_for(score: float) -> str:
    for low, high, name in BANDS:
        if low <= score < high:
            return name
    return "critical"


class GovernanceReviewService:
    def __init__(self) -> None:
        self._identity_service = IdentityService()
        self._alert_service = AlertService()
        self._audit_service = AuditService()
        self._capability_service = CapabilityAnalysisService()
        self._testing_service = TestingService()
        self._policy_service = PolicyService() 
    async def _execute_review_pipeline(
        self,
        db: AsyncSession,
        agent: Agent,
        *,
        user_id: str,
        checks: list[str],
        review_id: Optional[str] = None,
    ):

        logger.info(
            "agent_review_pipeline_started",
            extra={
                "agent_id": agent.hexaid,
                "checks": checks,
            },
        )

        if "policy" in checks:

            await self._policy_service.evaluate(
                db,
                agent_id=agent.hexaid,
                text=(
                    agent.definition.get(
                        "instructions",
                        ""
                    )
                    if agent.definition
                    else ""
                ),
            )

        if "security" in checks:

            await self._testing_service.run_red_team(
                db,
                agent_id=agent.hexaid,
                user_id=user_id,
                review_id=review_id,
            )

        if "functional" in checks:

            suites = await self._testing_service.list_suites(
                db,
                suite_type="functional",
            )

            for suite in suites:

                if (
                    suite.agent_id
                    and suite.agent_id != agent.hexaid
                ):
                    continue

                await self._testing_service.run_suite(
                    db,
                    suite_id=suite.id,
                    agent_id=agent.hexaid,
                    user_id=user_id,
                    triggered_by="governance_review",
                    review_id=review_id,
                )

        logger.info(
            "agent_review_pipeline_completed",
            extra={
                "agent_id": agent.hexaid,
                "checks": checks,
            },
        )
    async def get_inventory(
        self,
        db: AsyncSession,
        agent_ids: list[str],
    ):
        agents = []
        for agent_id in agent_ids:

            policies = await self._policy_service.get_agent_policies(
                db,
                agent_id,
            )

            suites = await self._testing_service.list_agent_suites(
                db,
                agent_id,
            )
            agents.append(
                {
                    "agent_id": agent_id,

                    "policies": policies,

                    "security_checks": SECURITY_CATALOG,

                    "functional_suites": [
                        {
                            "suite_id": str(
                                suite.id
                            ),
                            "name": suite.name,
                            "test_count": len(
                                suite.test_cases
                            ),
                        }
                        for suite in suites
                    ],
                }
            )

        return {
            "agents": agents,
        }

    
    async def assess_agent(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        user_id: str,
        checks: list[str] | None = None,
    ) -> Dict[str, Any]:

        agent = (
            await db.execute(
                select(Agent).where(
                    Agent.hexaid == agent_id
                )
            )
        ).scalar_one_or_none()

        if agent is None:
            raise ValueError(
                f"Agent '{agent_id}' not found"
            )
        checks = checks or [
            "identity",
            "policy",
            "security",
            "functional"
        ]

        review_id = str(uuid4())
        await self._execute_review_pipeline(
            db,
            agent,
            user_id=user_id,
            checks=checks,
            review_id=review_id,
        )
        profile = (
            await db.execute(
                select(AgentGovernanceProfile)
                .where(
                    AgentGovernanceProfile.agent_id == agent_id
                )
            )
        ).scalar_one_or_none()
        snapshot = await self._identity_service.latest_snapshot(
            db,
            agent_id=agent_id,
        )

        requires_identity_refresh = (
            profile is not None
            and profile.identity_stale
        )

        if "identity" in checks:

            if (
                snapshot is None
                or requires_identity_refresh
            ):
                identity_result = await self._identity_service.evaluate(
                    db,
                    agent_id=agent_id,
                )

                identity_score = identity_result.get(
                    "hygiene_score",
                    50.0,
                )
            else:
                identity_score = snapshot.hygiene_score

        else:

            identity_score = (
                snapshot.hygiene_score
                if snapshot
                else 50.0
            )

        # Capability
        capability = self._capability_service.evaluate(
            agent.definition or {}
        )

        capability_score = capability.get(
            "score",
            50.0,
        )
        findings: list[dict[str, Any]] = []

        findings.extend(
            capability.get("findings", [])
        )
        policy_score = await self._policy_compliance(
            db,
            agent_id,
        )
        agent_policies = await self._policy_service.get_agent_policies(
            db,
            agent_id,
        )

        if not agent_policies:
            findings.append(
                {
                    "domain": "security",
                    "type": "policy_missing",
                    "severity": "high",
                    "score": 0,
                    "message": (
                        "No policies assigned to this agent"
                    ),
                }
            )

        red_team_score = await self._red_team_resilience(
            db,
            agent_id,
        )

        functional_score = await self._test_pass_rate(
            db,
            agent_id,
        )
        policy_score = policy_score or 0.0
        red_team_score = red_team_score or 0.0
        functional_score = functional_score or 0.0
        security_score = round(
            (
                policy_score +
                red_team_score 
            ) / 2,
            2,
        )
        if policy_score < 80:
            findings.append(
                {
                    "domain": "security",
                    "type": "policy_non_compliance",
                    "severity": "medium",
                    "score": policy_score,
                }
            )

        if red_team_score < 80:
            findings.append(
                {
                    "domain": "security",
                    "type": "red_team_weakness",
                    "severity": "high",
                    "score": red_team_score,
                }
            )

        if functional_score == 0:
            findings.append(
                {
                    "domain": "functional",
                    "type": "functional_suite_missing",
                    "severity": "high",
                    "score": 0,
                    "message": (
                        "No functional test suite assigned to this agent"
                    ),
                }
            )

        elif functional_score < 80:
            findings.append(
                {
                    "domain": "functional",
                    "type": "test_failures",
                    "severity": "medium",
                    "score": functional_score,
                }
            )
        runtime_score = await self._operational_stability(
            db,
            agent_id,
        )

        if runtime_score is None:
            runtime_score = 0.0

            findings.append(
                {
                    "domain": "runtime",
                    "type": "telemetry_missing",
                    "severity": "info",
                    "score": 0,
                    "message": "No runtime telemetry available",
                }
            )
        if runtime_score < 90:
            findings.append(
                {
                    "domain": "runtime",
                    "type": "runtime_instability",
                    "severity": "medium",
                    "score": runtime_score,
                }
            )

        # Phase 1 placeholder until cost analytics scoring is introduced.
        cost_score = await self._cost_efficiency(
            db,
            agent_id,
        )

        if cost_score is None:
            cost_score = 0.0

            findings.append(
                {
                    "domain": "cost",
                    "type": "budget_missing",
                    "severity": "info",
                    "score": 0,
                    "message": "No budget configured",
                }
            )
        if cost_score < 80:
            findings.append(
                {
                    "domain": "cost",
                    "type": "budget_utilization",
                    "severity": (
                        "high"
                        if cost_score < 50
                        else "medium"
                    ),
                    "score": cost_score,
                }
            )

        if identity_score < 90:
            findings.append(
                {
                    "domain": "identity",
                    "type": "credential_hygiene",
                    "severity": "medium",
                    "score": identity_score,
                }
            )
        dimensions = {
            "identity": identity_score,
            "design": capability_score,
            "security": security_score,
            "functional": functional_score,
            "runtime": runtime_score,
            "cost": cost_score,
        }
        is_partial_review = not all(
            check in checks
            for check in (
                "identity",
                "policy",
                "security",
                "functional",
            )
        )
        active_dimensions = {}
        if "identity" in checks:
            active_dimensions["identity"] = identity_score
        active_dimensions["design"] = capability_score
        if (
            "policy" in checks
            or "security" in checks
        ):
            active_dimensions["security"] = security_score
        if "functional" in checks:
            active_dimensions["functional"] = functional_score

        active_dimensions["runtime"] = runtime_score
        active_dimensions["cost"] = cost_score

        active_weight_total = sum(
            TRUST_WEIGHTS[name]
            for name in active_dimensions
        )
        score = round(
            sum(
                value *
                (
                    TRUST_WEIGHTS[name]
                    / active_weight_total
                )
                for name, value
                in active_dimensions.items()
            ),
            2,
        )

        band = _band_for(score)
        is_provisional = False

        previous = (
            await db.execute(
                select(TrustScoreHistory)
                .where(TrustScoreHistory.agent_id == agent_id)
                .order_by(TrustScoreHistory.recorded_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if profile is not None:
            profile.identity_stale = False
            profile.testing_stale = False
            profile.needs_policy_review = False

            trust_state = _trust_state(
                score=score,
                identity_stale=False,
                testing_stale=False,
                policy_review_required=False,
            )

            profile.trust_score = score
            profile.trust_state = trust_state
            profile.trust_dimensions = dimensions
            profile.last_evaluated_at = datetime.now(
                timezone.utc,
            )
        else:
            logger.warning(
                "Governance profile missing during assessment",
                extra={
                    "agent_id": agent_id,
                },
            )
            trust_state = "UNKNOWN"
        logger.info(
            "Agent trust assessment completed",
            extra={
                "agent_id": agent_id,
                "trust_score": score,
                "trust_state": trust_state,
                "identity_score": identity_score,
                "capability_score": capability_score,
                "security_score": security_score,
                "runtime_score": runtime_score,
            },
        )
        snapshot = TrustScoreHistory(
            id=uuid4(),
            agent_id=agent_id,
            score=score,
            previous_score=previous.score if previous else None,
            band=band,
            factors=dimensions,
            is_provisional=is_provisional,
            recorded_at=datetime.now(timezone.utc),
        )
        db.add(snapshot)

        if previous and _band_index(band) < _band_index(previous.band):
            await self._alert_service.raise_alert(
                db, alert_type="trust_score_band_dropped", severity="high",
                title=f"Trust score dropped to '{band}' band", agent_id=agent_id,
                details={"previous_band": previous.band, "new_band": band, "score": score},
            )

        await self._audit_service.log_event(
            db, event_type="governance_review", action="assess_agent", agent_id=agent_id,
            details={
                "score": score,
                "band": band,
                "trust_state": trust_state,
                "executed_checks": checks,
                "is_partial_review": is_partial_review,
                "dimensions": dimensions,
                "findings_count": len(findings),
            }
        )

        await db.flush()
        recommendations = []
        if not agent_policies:
            recommendations.append(
                "Assign governance policies"
            )

        if functional_score == 0:
            recommendations.append(
                "Assign functional test suites"
            )

        if runtime_score == 0:
            recommendations.append(
                "Enable telemetry collection"
            )

        if cost_score == 0:
            recommendations.append(
                "Configure cost governance budget"
            )

        
        return {
            "score": score,
            "executed_checks": checks,
            "is_partial_review": is_partial_review,
            "band": band,
            "trust_state": trust_state,
            "dimensions": dimensions,
            "findings": findings,
            "recommendations": recommendations,
            "previous_score": (
                previous.score
                if previous
                else None
            ),
        }


    async def get_functional_details(
        self,
        db: AsyncSession,
        agent_id: str,
    ) -> dict[str, Any]:

        runs = (
            await db.execute(
                select(TestRun)
                .where(
                    TestRun.agent_id == agent_id
                )
                .order_by(
                    TestRun.created_at.desc()
                )
            )
        ).scalars().all()

        return {
            "test_runs": [
                {
                    "suite_id": run.suite_id,
                    "passed_tests": run.passed_tests,
                    "failed_tests": (
                        run.total_tests
                        - run.passed_tests
                    ),
                    "total_tests": run.total_tests,
                    "created_at": run.created_at,
                }
                for run in runs
            ]
        }

    async def review_agent(
        self,
        db: AsyncSession,
        agent_id: str,
        user_id: str,
        checks: list[str] | None = None,
    ):
        return await self.assess_agent(
            db,
            agent_id=agent_id,
            user_id=user_id,
            checks=checks,
        )
    async def get_trust_profile(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
    ) -> Dict[str, Any]:

        profile = (
            await db.execute(
                select(AgentGovernanceProfile)
                .where(
                    AgentGovernanceProfile.agent_id == agent_id
                )
            )
        ).scalar_one_or_none()

        if profile is None:
            raise ValueError(
                f"Governance profile missing for agent '{agent_id}'"
            )

        return {
            "agent_id": agent_id,
            "trust_score": profile.trust_score,
            "trust_state": profile.trust_state,

            "trust_dimensions": {
                "identity": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("identity", 0)
                },

                "design": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("design", 0)
                },

                "security": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("security", 0)
                },

                "functional": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("functional", 0)
                },

                "runtime": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("runtime", 0)
                },

                "cost": {
                    "score": (
                        profile.trust_dimensions or {}
                    ).get("cost", 0)
                },
            },

            "identity_stale": profile.identity_stale,
            "testing_stale": profile.testing_stale,
            "needs_policy_review": profile.needs_policy_review,
            "last_evaluated_at": profile.last_evaluated_at,
        }
    async def review_agents(
        self,
        db: AsyncSession,
        agent_ids: list[str],
        user_id: str,
        checks:list[str],
    ) -> dict[str, Any]:
        results = []
        logger.info(
            "bulk_agent_review_started",
            extra={
                "requested": len(agent_ids),
                "checks": checks,
                "user_id": user_id,
            },
        )
        for agent_id in agent_ids:
            try:
                result = await self.assess_agent(
                    db,
                    agent_id=agent_id,
                    user_id=user_id,
                    checks=checks,
                )
                results.append(
                    {
                        "agent_id": agent_id,
                        "status": "reviewed",
                        **result,
                    }
                )
            except Exception as exc:
                logger.exception(
                    "bulk_agent_review_failed",
                    extra={
                        "agent_id": agent_id,
                    },
                )
                results.append(
                    {
                        "agent_id": agent_id,
                        "status": "failed",
                        "error": str(exc),
                    }
                )
        logger.info(
            "bulk_agent_review_completed",
            extra={
                "requested": len(agent_ids),
                "reviewed": len(
                    [
                        r
                        for r in results
                        if r["status"] == "reviewed"
                    ]
                ),
            },
        )
        return {
            "reviewed": len(
                [
                    r
                    for r in results
                    if r["status"] == "reviewed"
                ]
            ),
            "failed": len(
                [
                    r
                    for r in results
                    if r["status"] == "failed"
                ]
            ),
            "results": results,
        }
    async def get_trust_history(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:

        history = (
            await db.execute(
                select(TrustScoreHistory)
                .where(
                    TrustScoreHistory.agent_id == agent_id
                )
                .order_by(
                    TrustScoreHistory.recorded_at.desc()
                )
                .limit(limit)
            )
        ).scalars().all()

        return [
            {
                "score": item.score,
                "band": item.band,
                "previous_score": item.previous_score,
                "recorded_at": item.recorded_at,
            }
            for item in history
        ]

    # ------------------------------------------------------------------
    # Factor computation
    # ------------------------------------------------------------------

    async def _policy_compliance(
        self,
        db: AsyncSession,
        agent_id: str,
    ) -> Optional[float]:

        policies = await self._policy_service.get_agent_policies(
            db,
            agent_id,
        )

        if not policies:
            return 0.0

        cutoff = (
            datetime.now(timezone.utc)
            - timedelta(days=30)
        ).replace(
            tzinfo=None
        )

        violations = (
            await db.execute(
                select(func.count())
                .select_from(
                    PolicyViolation
                )
                .where(
                    PolicyViolation.agent_id == agent_id,
                    PolicyViolation.occurred_at >= cutoff,
                )
            )
        ).scalar_one()

        if violations == 0:
            return 100.0

        return max(
            100.0 - (violations * 5),
            0.0,
        )
    async def _red_team_resilience(self, db: AsyncSession, agent_id: str) -> Optional[float]:
        results = (
            await db.execute(select(RedTeamResult).where(RedTeamResult.agent_id == agent_id))
        ).scalars().all()
        if not results:
            return None
        blocked = sum(1 for r in results if r.blocked)
        return round((blocked / len(results)) * 100, 2)

    async def _test_pass_rate(self, db: AsyncSession, agent_id: str) -> Optional[float]:
        runs = (
            await db.execute(
                select(TestRun).where(TestRun.agent_id == agent_id).order_by(TestRun.created_at.desc()).limit(5)
            )
        ).scalars().all()
        if not runs:
            return None
        total = sum(r.total_tests for r in runs) or 1
        passed = sum(r.passed_tests for r in runs)
        return round((passed / total) * 100, 2)

    async def _credential_hygiene(self, db: AsyncSession, agent_id: str) -> Optional[float]:
        snapshot = await self._identity_service.latest_snapshot(db, agent_id=agent_id)
        if snapshot is None:
            return None
        return snapshot.hygiene_score

    async def _operational_stability(self, db: AsyncSession, agent_id: str) -> Optional[float]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=7)
        total = (
            await db.execute(
                select(func.count()).select_from(TelemetryEvent).where(
                    TelemetryEvent.agent_id == agent_id, TelemetryEvent.timestamp >= cutoff,
                )
            )
        ).scalar_one()
        if total == 0:
            return None
        errors = (
            await db.execute(
                select(func.count()).select_from(TelemetryEvent).where(
                    TelemetryEvent.agent_id == agent_id, TelemetryEvent.timestamp >= cutoff,
                    TelemetryEvent.status != "success",
                )
            )
        ).scalar_one()
        return round((1 - errors / total) * 100, 2)
    async def get_security_details(
        self,
        db: AsyncSession,
        agent_id: str,
    ) -> dict[str, Any]:

        policies = await self._policy_service.get_agent_policies(
            db,
            agent_id,
        )

        violations = await self._policy_service.list_violations(
            db,
            agent_id=agent_id,
            limit=50,
        )

        red_team_results = (
            await db.execute(
                select(RedTeamResult)
                .where(
                    RedTeamResult.agent_id == agent_id
                )
            )
        ).scalars().all()

        return {
            "assigned_policies": policies,
            "policy_violations": [
                {
                    "rule_id": v.rule_id,
                    "severity": v.severity,
                    "reason": v.reason,
                    "occurred_at": v.occurred_at,
                }
                for v in violations
            ],
            "red_team_results": [
                {
                    "name": r.attack_name,
                    "type": r.attack_type,
                    "severity": r.severity,
                    "stage": r.stage,
                    "verdict": r.verdict,
                    "blocked": r.blocked,
                }
                for r in red_team_results
            ],
        }
        
    async def _cost_efficiency(
        self,
        db: AsyncSession,
        agent_id: str,
    ) -> Optional[float]:

        budget = (
            await db.execute(
                select(Budget)
                .where(
                    Budget.scope == "agent",
                    Budget.scope_id == agent_id,
                    Budget.is_active.is_(True),
                )
                .limit(1)
            )
        ).scalar_one_or_none()

        if budget is None:
            return None

        now = datetime.now(timezone.utc)

        if budget.period == "daily":
            start = now.replace(
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )

        elif budget.period == "weekly":
            start = now - timedelta(
                days=now.weekday()
            )

        else:
            start = now.replace(
                day=1,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )

        spend = (
            await db.execute(
                select(
                    func.coalesce(
                        func.sum(CostRecord.cost_usd),
                        0.0,
                    )
                )
                .where(
                    CostRecord.agent_id == agent_id,
                    CostRecord.recorded_at >= start,
                )
            )
        ).scalar_one()

        utilization = (
            spend / budget.limit_usd * 100
            if budget.limit_usd
            else 0
        )

        return max(
            100.0 - utilization,
            0.0,
        )
    async def get_portfolio_summary(
        self,
        db: AsyncSession,owner_user_id: str,
    ) -> Dict[str, Any]:

        profiles = (
            await db.execute(
                select(
                    AgentGovernanceProfile
                ).where(
                    AgentGovernanceProfile.owner_user_id
                    == owner_user_id
                )
            )
        ).scalars().all()
        total = len(profiles)
        return {
            "total_agents": total,
            "trusted": sum(
                1
                for p in profiles
                if p.trust_state == "TRUSTED"
            ),
            "needs_review": sum(
                1
                for p in profiles
                if p.trust_state == "NEEDS_REVIEW"
            ),
            "high_risk": sum(
                1
                for p in profiles
                if p.trust_state == "HIGH_RISK"
            ),
            "average_score": round(
                (
                    sum(
                        p.trust_score or 0
                        for p in profiles
                    ) / total
                ) if total else 0,
                2,
            ),
        }
    async def get_high_risk_agents(
        self,
        db: AsyncSession,owner_user_id: str,
    ) -> list[dict[str, Any]]:

        profiles = (
            await db.execute(
                select(
                    AgentGovernanceProfile
                ).where(
                    AgentGovernanceProfile.trust_state
                    == "HIGH_RISK",
                    AgentGovernanceProfile.owner_user_id
                    == owner_user_id,
                )
            )
        ).scalars().all()

        return [
            {
                "agent_id": profile.agent_id,
                "trust_score": profile.trust_score,
                "trust_state": profile.trust_state,
            }
            for profile in profiles
        ]
    async def get_review_required_agents(
        self,
        db: AsyncSession,owner_user_id: str,
    ) -> list[dict[str, Any]]:

        profiles = (
            await db.execute(
                select(
                    AgentGovernanceProfile
                ).where(
                    AgentGovernanceProfile.trust_state
                    == "NEEDS_REVIEW",  
                    AgentGovernanceProfile.owner_user_id
                    == owner_user_id,
                )
            )
        ).scalars().all()

        return [
            {
                "agent_id": profile.agent_id,
                "trust_score": profile.trust_score,
                "identity_stale": profile.identity_stale,
                "testing_stale": profile.testing_stale,
                "needs_policy_review": profile.needs_policy_review,
            }
            for profile in profiles
        ]

    async def get_portfolio_trends(
        self,
        db: AsyncSession,
        owner_user_id: str,
    ) -> dict[str, Any]:
        cutoff = (
            datetime.now(timezone.utc)
            - timedelta(days=30)
        )

        profiles = (
            await db.execute(
                select(
                    AgentGovernanceProfile
                ).where(
                    AgentGovernanceProfile.owner_user_id
                    == owner_user_id
                )
            )
        ).scalars().all()

        review_count = (
            await db.execute(
                select(func.count())
                .select_from(
                    TrustScoreHistory
                )
                .where(
                    TrustScoreHistory.recorded_at
                    >= cutoff
                )
            )
        ).scalar_one()

        avg_score = round(
            (
                sum(
                    p.trust_score or 0
                    for p in profiles
                ) / len(profiles)
            )
            if profiles
            else 0,
            2,
        )

        high_risk = sum(
            1
            for p in profiles
            if p.trust_state == "HIGH_RISK"
        )

        return {
            "average_score": avg_score,
            "reviews_completed": review_count,
            "high_risk_agents": high_risk,
            "total_agents": len(profiles),
        }

    async def get_agent_history(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
    ) -> dict[str, Any]:
        agent = (
            await db.execute(
                select(Agent).where(
                    Agent.hexaid == agent_id
                )
            )
        ).scalar_one_or_none()

        if agent is None:
            raise ValueError(
                f"Agent '{agent_id}' not found"
            )
        trust_history = await self.get_trust_history(
            db,
            agent_id=agent_id,
            limit=100,
        )
        profile = (
            await db.execute(
                select(
                    AgentGovernanceProfile
                ).where(
                    AgentGovernanceProfile.agent_id
                    == agent_id
                )
            )
        ).scalar_one_or_none()
        files = (
            await db.execute(
                select(AgentFile)
                .where(
                    AgentFile.agent_id == agent.agent_id
                )
                .order_by(
                    AgentFile.created_at.desc()
                )
            )
        ).scalars().all()
        knowledge_links = (
            await db.execute(
                select(
                    AgentKnowledgeBaseLink
                ).where(
                    AgentKnowledgeBaseLink.agent_id
                    == agent.agent_id
                )
            )
        ).scalars().all()
        workflows = (
            await db.execute(
                select(Workflow)
                .where(
                    Workflow.is_deleted.is_(False)
                )
            )
        ).scalars().all()
        workflow_usage = []

        for workflow in workflows:

            definition = workflow.definition or {}

            payload = str(
                definition
            )

            if (
                str(agent.agent_id) in payload
                or agent.hexaid in payload
            ):

                workflow_usage.append(
                    {
                        "workflow_id": str(
                            workflow.workflow_id
                        ),
                        "workflow_name": workflow.name,
                        "status": workflow.status,
                        "updated_at": (
                            workflow.updated_at
                        ),
                    }
                )

        timeline = []
        timeline.append(
            {
                "event": "agent_created",
                "timestamp": agent.created_at,
                "details": {
                    "agent_name": agent.name,
                },
            }
        )
        timeline.append(
            {
                "event": "agent_updated",
                "timestamp": agent.updated_at,
                "details": {},
            }
        )
        for workflow in workflow_usage:

            timeline.append(
                {
                    "event": "workflow_reference",
                    "timestamp": workflow[
                        "updated_at"
                    ],
                    "details": workflow,
                }
            )
        for file in files:
            timeline.append(
                {
                    "event": "source_added",
                    "timestamp": file.created_at,
                    "details": {
                        "name": file.name,
                        "type": file.source_type,
                        "status": file.status,
                    },
                }
            )

        for review in trust_history:

            timeline.append(
                {
                    "event": "trust_review",
                    "timestamp": review[
                        "recorded_at"
                    ],
                    "details": {
                        "score": review[
                            "score"
                        ],
                        "band": review[
                            "band"
                        ],
                    },
                }
            )

        for kb in knowledge_links:
            timeline.append(
                {
                    "event": "knowledge_base_linked",
                    "timestamp": kb.created_at,
                    "details": {
                        "knowledge_base_id": str(
                            kb.knowledge_base_id
                        ),
                        "alias": kb.alias,
                    },
                }
            )

        timeline.sort(
            key=lambda x: x["timestamp"],
            reverse=True,
        )
        return {
            "agent": {
                "agent_id": str(
                    agent.agent_id
                ),
                "hexaid": agent.hexaid,
                "name": agent.name,
                "source_workflow_id": (
                str(agent.source_workflow_id)
                if agent.source_workflow_id
                else None
                ),
                "created_at": agent.created_at,
                "updated_at": agent.updated_at,
            },
            "current_review": {
                "trust_score": (
                    profile.trust_score
                    if profile
                    else None
                ),
                "trust_state": (
                    profile.trust_state
                    if profile
                    else None
                ),
                "last_evaluated_at": (
                    profile.last_evaluated_at
                    if profile
                    else None
                ),
            },

            "usage": {
                "workflow_count": len(workflow_usage),
                "knowledge_sources": len(files),
                "knowledge_bases": len(knowledge_links),
            },

            "workflows": workflow_usage,

            "knowledge_sources": [
                {
                    "file_name": file.name,
                    "status": file.status,
                    "source_type": file.source_type,
                }
                for file in files
            ],
            "knowledge_bases": [
                {
                    "knowledge_base_id": str(
                        kb.knowledge_base_id
                    ),
                    "alias": kb.alias,
                }
                for kb in knowledge_links
            ],

            "reviews": trust_history,

            "timeline": timeline,
        }
def _band_index(band: str) -> int:
    order = ["critical", "low", "moderate", "high", "verified"]
    return order.index(band) if band in order else 0
