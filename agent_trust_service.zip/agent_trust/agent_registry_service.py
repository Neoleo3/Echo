"""
Agent registry -- the governance extension row for a real ``agents`` record.

``agents`` stays the single source of truth for what an agent *is*; this
module only tracks what governance thinks of it. Profiles are created by the
save hook, so the registry is always complete without anyone pressing a button.

Workflow canvases contain pseudo-nodes (Start, End, API, Code, ...) that are
persisted as agent rows for wiring purposes but are not agents a human would
recognise. Those are filtered out here -- they must never appear in Agent
Trust, inflate counts, or sit unreviewed in the dashboard.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional

from fastapi import HTTPException
from sqlalchemy import func, or_, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.models import Agent, User
from echolib.models.agent_trust import AgentGovernanceProfile
from echolib.security import resolve_user_id
from echolib.service.agent_trust.audit_service import (
    EVENT_AGENT_CREATED,
    EVENT_AGENT_LINKED_WORKFLOW,
    EVENT_AGENT_UPDATED,
    AuditService,
)
from echolib.service.agent_trust.cost_service import CostService
from echolib.types import UserContext, UserRole

logger = logging.getLogger(__name__)

TRUST_NEEDS_REVIEW = "NEEDS_REVIEW"

# Canvas node types that are persisted as agent rows but are not real agents.
# Mirrors ``echolib.agent_contract.AGENT_NODE_TYPES`` -- anything outside that
# set is workflow plumbing.
REAL_AGENT_NODE_TYPES = frozenset({"", "agent", "hitl", "subagent"})


def _definition_hash(definition: Optional[dict]) -> str:
    canonical = json.dumps(definition or {}, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def node_type_of(definition: Optional[dict]) -> str:
    definition = definition or {}
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    raw = definition.get("type") or metadata.get("node_type") or "agent"
    return str(raw).strip().lower()


def is_real_agent(definition: Optional[dict]) -> bool:
    """
    True for agents a user would recognise as an agent.

    Start/End/API/Code canvas nodes are written to ``agents`` so workflow
    wiring can reference them; they have no instructions and no model of their
    own, and must stay out of Agent Trust entirely.
    """
    return node_type_of(definition) in REAL_AGENT_NODE_TYPES


class AgentRegistryService:
    def __init__(self) -> None:
        self._audit = AuditService()
        self._cost = CostService()

    # ------------------------------------------------------------------
    # Registration (driven by the agent save hook)
    # ------------------------------------------------------------------

    async def register_agent(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        owner_user_id: str,
    ) -> Optional[AgentGovernanceProfile]:
        """
        Idempotently create the governance profile for ``agent_id``.

        Returns ``None`` for workflow pseudo-nodes, which are never registered.
        Safe to call for an already-registered agent -- the existing row is
        returned unchanged rather than having its governance state reset.
        """
        agent = await db.get(Agent, agent_id)

        if agent is not None and not is_real_agent(agent.definition):
            logger.debug(
                "agent_trust_registration_skipped_non_agent_node",
                extra={"agent_id": agent_id, "node_type": node_type_of(agent.definition)},
            )
            return None

        existing = await self._get_profile(db, agent_id)
        if existing:
            return existing

        stmt = (
            insert(AgentGovernanceProfile)
            .values(
                agent_id=agent_id,
                owner_user_id=owner_user_id,
                last_definition_hash=_definition_hash(agent.definition if agent else None),
            )
            .on_conflict_do_nothing(index_elements=["agent_id"])
            .returning(AgentGovernanceProfile)
        )
        profile = (await db.execute(stmt)).scalar_one_or_none()
        await db.flush()

        if profile is None:
            # Lost the race -- another transaction inserted it first.
            return await self._get_profile(db, agent_id)

        logger.info(
            "agent_trust_profile_created",
            extra={"agent_id": agent_id, "owner_user_id": owner_user_id},
        )
        await self._audit.record(
            db,
            agent_id=agent_id,
            event_type=EVENT_AGENT_CREATED,
            action="register",
            details={"name": agent.name if agent else None},
        )
        if agent is not None and agent.source_workflow_id:
            await self._audit.record(
                db,
                agent_id=agent_id,
                event_type=EVENT_AGENT_LINKED_WORKFLOW,
                action="link_workflow",
                details={"workflow_id": str(agent.source_workflow_id)},
            )

        return profile

    async def mark_definition_changed(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        new_hash: str,
        changed_fields: Optional[List[str]] = None,
    ) -> Optional[AgentGovernanceProfile]:
        """Invalidate trust when the agent's definition actually changed."""
        profile = await self._get_profile(db, agent_id)
        if profile is None:
            agent = await db.get(Agent, agent_id)
            if agent is None:
                raise ValueError(f"Agent '{agent_id}' not found")
            return await self.register_agent(
                db, agent_id=agent_id, owner_user_id=str(agent.user_id)
            )

        if profile.last_definition_hash == new_hash:
            return profile  # No-op save (e.g. a re-save with identical content).

        # Invalidate only the review dimensions affected by the changed
        # definition fields. An unknown/empty change list remains fail-safe and
        # invalidates all executable checks.
        changed = {
            str(field).strip().lower().replace("-", "_")
            for field in (changed_fields or [])
            if field
        }
        joined = " ".join(sorted(changed))
        connector_change = any(
            token in joined for token in ("connector", "credential", "oauth", "mcp")
        )
        testing_change = any(
            token in joined
            for token in ("tool", "model", "instruction", "prompt", "workflow", "application", "knowledge", "document", "retrieval")
        )
        policy_change = any(
            token in joined
            for token in ("instruction", "prompt", "tool", "model", "workflow", "application")
        )

        recognized_change = connector_change or testing_change or policy_change
        if not changed or not recognized_change:
            profile.needs_policy_review = True
            profile.identity_stale = True
            profile.testing_stale = True
        else:
            if connector_change:
                profile.identity_stale = True
                profile.testing_stale = True
            if testing_change:
                profile.testing_stale = True
            if policy_change:
                profile.needs_policy_review = True

        profile.trust_state = TRUST_NEEDS_REVIEW
        profile.last_definition_hash = new_hash
        await db.flush()

        logger.info(
            "agent_trust_definition_changed",
            extra={"agent_id": agent_id, "changed": changed_fields or []},
        )
        await self._audit.record(
            db,
            agent_id=agent_id,
            event_type=EVENT_AGENT_UPDATED,
            action="definition_changed",
            details={"changed": changed_fields or []},
        )
        return profile

    async def backfill(self, db: AsyncSession) -> Dict[str, int]:
        """Create missing profiles for every real agent on the platform."""
        agents = (
            await db.execute(
                select(Agent)
                .outerjoin(
                    AgentGovernanceProfile,
                    AgentGovernanceProfile.agent_id == Agent.hexaid,
                )
                .where(
                    Agent.is_deleted.is_(False),
                    AgentGovernanceProfile.id.is_(None),
                )
            )
        ).scalars().all()

        registered = 0
        skipped = 0
        failed = 0

        for agent in agents:
            if not is_real_agent(agent.definition):
                skipped += 1
                continue
            try:
                await self.register_agent(
                    db, agent_id=agent.hexaid, owner_user_id=str(agent.user_id)
                )
                registered += 1
            except Exception:
                failed += 1
                logger.warning(
                    "agent_trust_backfill_failed",
                    extra={"agent_id": agent.hexaid},
                    exc_info=True,
                )

        logger.info(
            "agent_trust_backfill_completed",
            extra={
                "candidates": len(agents),
                "registered": registered,
                "skipped_non_agent_nodes": skipped,
                "failed": failed,
            },
        )
        return {
            "candidates": len(agents),
            "registered": registered,
            "skipped_non_agent_nodes": skipped,
            "failed": failed,
        }

    # ------------------------------------------------------------------
    # Access control
    # ------------------------------------------------------------------

    async def validate_owner(
        self, db: AsyncSession, agent_id: str, user: UserContext
    ) -> None:
        agent = await db.get(Agent, agent_id)
        if (
            agent is None
            or agent.is_deleted
            or not is_real_agent(agent.definition)
        ):
            raise HTTPException(status_code=404, detail="Agent not found")

        if user.role == UserRole.super_admin.value:
            return

        if str(agent.user_id) != resolve_user_id(user):
            raise HTTPException(status_code=403, detail="Not owner of this agent")

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    async def list_agents(
        self,
        db: AsyncSession,
        *,
        owner_user_id: Optional[str],
        search: Optional[str] = None,
        trust_state: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """
        One page of agents. ``owner_user_id=None`` means platform-wide and is
        only ever passed for a super admin.
        """
        base = (
            select(Agent, AgentGovernanceProfile, User.display_name, User.email)
            .outerjoin(
                AgentGovernanceProfile,
                AgentGovernanceProfile.agent_id == Agent.hexaid,
            )
            .outerjoin(User, User.user_id == Agent.user_id)
            .where(Agent.is_deleted.is_(False))
        )

        if owner_user_id is not None:
            base = base.where(Agent.user_id == owner_user_id)
        if search:
            base = base.where(Agent.name.ilike(f"%{search}%"))
        if trust_state:
            base = base.where(AgentGovernanceProfile.trust_state == trust_state)

        rows = (
            await db.execute(base.order_by(Agent.updated_at.desc()))
        ).all()

        # Pseudo-nodes cannot be excluded in SQL without a JSONB index, and the
        # per-user agent count is small, so the filter runs here.
        rows = [row for row in rows if is_real_agent(row[0].definition)]
        total = len(rows)
        page = rows[offset : offset + limit]

        usage_map = await self._cost.get_usage_map(db)

        return {
            "total": total,
            "limit": limit,
            "offset": offset,
            "items": [
                self._to_list_item(row, usage_map.get(row[0].hexaid, {})) for row in page
            ],
        }

    @staticmethod
    def _to_list_item(record, usage: Dict[str, Any]) -> Dict[str, Any]:
        agent: Agent = record[0]
        profile: Optional[AgentGovernanceProfile] = record[1]
        display_name = record[2]
        email = record[3]

        legacy_state_map = {
            "REVIEW_REQUIRED": "NEEDS_REVIEW",
            "TRUSTED_WITH_WARNINGS": "TRUSTED",
        }

        trust_state = (
            profile.trust_state
            if profile
            else "UNREVIEWED"
        )

        trust_state = legacy_state_map.get(
            trust_state,
            trust_state,
        )

        return {
            "agent_id": agent.hexaid,
            "name": agent.name,
            "owner": {
                "user_id": str(agent.user_id),
                "name": display_name or email,
                "email": email,
            },
            "environment": profile.environment if profile else None,
            "trust_score": (
                int(profile.trust_score)
                if profile and profile.trust_score is not None
                else None
            ),
            "trust_state": trust_state,
            "last_reviewed_at": (
                profile.last_evaluated_at.isoformat()
                if profile and profile.last_evaluated_at
                else None
            ),
            "stale": bool(
                profile is None
                or profile.needs_policy_review
                or profile.identity_stale
                or profile.testing_stale
            ),
            "total_runs": usage.get("total_runs", 0),
            "total_tokens": usage.get("total_tokens", 0),
            "total_cost_usd": usage.get("total_cost_usd", 0.0),
            "last_used_at": usage.get("last_used_at"),
            "updated_at": (
                agent.updated_at.isoformat()
                if agent.updated_at
                else None
            ),
        }
    # ------------------------------------------------------------------

    async def _get_profile(
        self, db: AsyncSession, agent_id: str
    ) -> Optional[AgentGovernanceProfile]:
        return (
            await db.execute(
                select(AgentGovernanceProfile).where(
                    AgentGovernanceProfile.agent_id == agent_id
                )
            )
        ).scalar_one_or_none()
