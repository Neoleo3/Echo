"""
Cost Governance service (Phase 5) -- continuous, no Judge LLM involved.

Two paths keep ``agent_trust_cost_records`` current:
  1. Live: subscribes to the existing ``TelemetryEventBus`` (zero changes to
     ``echolib/otel.py``) and processes each llm_call event as it happens.
  2. Reconciliation: periodically re-scans ``telemetry_events`` for rows the
     live subscriber might have missed (e.g. a restart), keyed by
     ``source_event_id`` so both paths are idempotent against each other.

Every processed event ALSO writes a hash-chained audit_logs entry
(``event_type="agent_invocation"``) in the same step, per the confirmed
design: cost and audit are tracked together for every real invocation.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from echolib.pricing import estimate_cost
from echolib.models.agent_trust import Budget, CostRecord
from echolib.models.telemetry import TelemetryEvent
from echolib.service.agent_trust.audit_service import (
    EVENT_AGENT_INVOKED,
    AuditService,
)

logger = logging.getLogger(__name__)

RECONCILE_INTERVAL_SECONDS = 300
RECONCILE_WINDOW_MINUTES = 15

# Accepted values for the ``window`` argument on usage reads.
USAGE_WINDOWS: Dict[str, Optional[int]] = {
    "24h": 1,
    "7d": 7,
    "30d": 30,
    "all": None,
}


class CostService:
    def __init__(self) -> None:
        self._audit_service = AuditService()

    async def record_from_event(self, db: AsyncSession, event: Dict[str, Any]) -> Optional[CostRecord]:
        agent_id = (event.get("agent_id") or "").strip()
        if not agent_id:
            return None  # Not agent-attributable telemetry (e.g. a bare LLM call).

        source_event_id = event.get("event_id") or event.get("session_id")
        if source_event_id:
            existing = (
                await db.execute(select(CostRecord).where(CostRecord.source_event_id == source_event_id))
            ).scalar_one_or_none()
            if existing:
                return existing  # Idempotent -- already recorded (live or reconciled).

        model = event.get("model")
        input_tokens = int(event.get("input_tokens") or 0)
        output_tokens = int(event.get("output_tokens") or 0)
        cost_usd = estimate_cost(model, input_tokens, output_tokens)

        record = CostRecord(
            id=uuid4(), agent_id=agent_id, source_event_id=source_event_id,
            model=model, provider=event.get("provider"),
            input_tokens=input_tokens, output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens, cost_usd=cost_usd,
            billing_source=event.get("billing_source"),
            recorded_at=self._event_timestamp(event),
        )
        db.add(record)

        await self._audit_service.record(
            db,
            agent_id=agent_id,
            event_type=EVENT_AGENT_INVOKED,
            action=event.get("event_type") or "llm_call",
            outcome=event.get("status", "success"),
            details={
                "model": model,
                "provider": event.get("provider"),
                "feature": event.get("feature"),
                "workflow_id": event.get("workflow_id"),
                "tokens": record.total_tokens,
                "cost_usd": cost_usd,
            },
        )

        await self._check_budgets(db, agent_id=agent_id, cost_usd=cost_usd)
        await db.flush()
        return record

    @staticmethod
    def _event_timestamp(event: Dict[str, Any]) -> datetime:
        """Cost must land in the period the call actually happened in."""
        raw = event.get("timestamp")
        if isinstance(raw, datetime):
            return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
        if isinstance(raw, (int, float)):
            return datetime.fromtimestamp(raw, tz=timezone.utc)
        return datetime.now(timezone.utc)

    async def _check_budgets(self, db: AsyncSession, *, agent_id: str, cost_usd: float) -> None:
        budgets = (
            await db.execute(
                select(Budget).where(Budget.scope == "agent", Budget.scope_id == agent_id, Budget.is_active.is_(True))
            )
        ).scalars().all()

        for budget in budgets:
            spend = await self._period_spend(db, budget)
            utilization = (spend / budget.limit_usd * 100) if budget.limit_usd else 0
            if utilization >= budget.alert_threshold_pct:
                await self._audit_service.raise_alert(
                    db, alert_type="budget_threshold_breached", severity="high" if utilization < 100 else "critical",
                    title=f"Budget '{budget.name}' at {utilization:.0f}% utilization",
                    agent_id=agent_id, details={"budget_id": str(budget.id), "spend": spend, "limit": budget.limit_usd},
                )

    async def _period_spend(self, db: AsyncSession, budget: Budget) -> float:
        now = datetime.now(timezone.utc)
        if budget.period == "daily":
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        elif budget.period == "weekly":
            start = now - timedelta(days=now.weekday())
        else:
            start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        stmt = select(func.coalesce(func.sum(CostRecord.cost_usd), 0.0)).where(CostRecord.recorded_at >= start)
        if budget.scope == "agent":
            stmt = stmt.where(CostRecord.agent_id == budget.scope_id)
        elif budget.scope == "department":
            stmt = stmt.where(CostRecord.department == budget.scope_id)
        return float((await db.execute(stmt)).scalar_one())

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    async def get_agent_usage(
        self,
        db: AsyncSession,
        *,
        agent_id: str,
        window: str = "all",
    ) -> Dict[str, Any]:
        """
        Live token + cost consumption for one agent.

        Tokens come straight from ``telemetry_events`` so the numbers move as
        soon as the agent runs; cost comes from ``agent_trust_cost_records``,
        which is priced per model by ``echolib.pricing``. When no cost record
        exists yet the cost is priced on the fly from the same telemetry rows,
        so the user never sees tokens without a cost beside them.
        """
        days = USAGE_WINDOWS.get(window, None)
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=days) if days is not None else None
        )

        telemetry_stmt = select(
            func.count(TelemetryEvent.event_id).label("total_runs"),
            func.coalesce(func.sum(TelemetryEvent.input_tokens), 0).label("input_tokens"),
            func.coalesce(func.sum(TelemetryEvent.output_tokens), 0).label("output_tokens"),
            func.coalesce(func.sum(TelemetryEvent.total_tokens), 0).label("total_tokens"),
            func.max(TelemetryEvent.timestamp).label("last_used_at"),
        ).where(TelemetryEvent.agent_id == agent_id)
        if cutoff is not None:
            telemetry_stmt = telemetry_stmt.where(TelemetryEvent.timestamp >= cutoff)

        usage = (await db.execute(telemetry_stmt)).one()

        cost_stmt = select(
            func.coalesce(func.sum(CostRecord.cost_usd), 0.0).label("total_cost_usd"),
            func.count().label("priced_calls"),
        ).where(CostRecord.agent_id == agent_id)
        if cutoff is not None:
            cost_stmt = cost_stmt.where(CostRecord.recorded_at >= cutoff)

        cost = (await db.execute(cost_stmt)).one()
        total_cost = float(cost.total_cost_usd or 0.0)
        estimated = False

        if cost.priced_calls == 0 and (usage.total_tokens or 0) > 0:
            total_cost = await self._price_from_telemetry(db, agent_id=agent_id, cutoff=cutoff)
            estimated = True

        return {
            "window": window,
            "total_runs": int(usage.total_runs or 0),
            "input_tokens": int(usage.input_tokens or 0),
            "output_tokens": int(usage.output_tokens or 0),
            "total_tokens": int(usage.total_tokens or 0),
            "total_cost_usd": round(total_cost, 6),
            "cost_is_estimated": estimated,
            "last_used_at": usage.last_used_at.isoformat() if usage.last_used_at else None,
        }

    async def _price_from_telemetry(
        self, db: AsyncSession, *, agent_id: str, cutoff: Optional[datetime]
    ) -> float:
        """Price per model directly from telemetry when no cost records exist yet."""
        stmt = (
            select(
                TelemetryEvent.model,
                func.coalesce(func.sum(TelemetryEvent.input_tokens), 0).label("input_tokens"),
                func.coalesce(func.sum(TelemetryEvent.output_tokens), 0).label("output_tokens"),
            )
            .where(TelemetryEvent.agent_id == agent_id)
            .group_by(TelemetryEvent.model)
        )
        if cutoff is not None:
            stmt = stmt.where(TelemetryEvent.timestamp >= cutoff)

        rows = (await db.execute(stmt)).all()
        return sum(
            estimate_cost(row.model, int(row.input_tokens or 0), int(row.output_tokens or 0))
            for row in rows
        )

    async def get_usage_map(self, db: AsyncSession) -> Dict[str, Dict[str, Any]]:
        """All-time tokens + cost per agent, for list views."""
        telemetry_rows = (
            await db.execute(
                select(
                    TelemetryEvent.agent_id,
                    func.count(TelemetryEvent.event_id).label("total_runs"),
                    func.coalesce(func.sum(TelemetryEvent.total_tokens), 0).label("total_tokens"),
                    func.max(TelemetryEvent.timestamp).label("last_used_at"),
                )
                .where(
                    TelemetryEvent.agent_id.is_not(None),
                    TelemetryEvent.agent_id != "",
                )
                .group_by(TelemetryEvent.agent_id)
            )
        ).all()

        cost_rows = (
            await db.execute(
                select(
                    CostRecord.agent_id,
                    func.coalesce(func.sum(CostRecord.cost_usd), 0.0).label("total_cost_usd"),
                ).group_by(CostRecord.agent_id)
            )
        ).all()
        cost_map = {row.agent_id: float(row.total_cost_usd or 0.0) for row in cost_rows}

        return {
            row.agent_id: {
                "total_runs": int(row.total_runs or 0),
                "total_tokens": int(row.total_tokens or 0),
                "total_cost_usd": round(cost_map.get(row.agent_id, 0.0), 6),
                "last_used_at": row.last_used_at.isoformat() if row.last_used_at else None,
            }
            for row in telemetry_rows
        }

    async def list_records(self, db: AsyncSession, *, agent_id: Optional[str] = None, limit: int = 100) -> List[CostRecord]:
        stmt = select(CostRecord)
        if agent_id:
            stmt = stmt.where(CostRecord.agent_id == agent_id)
        stmt = stmt.order_by(CostRecord.recorded_at.desc()).limit(limit)
        return list((await db.execute(stmt)).scalars().all())

    async def get_stats(self, db: AsyncSession) -> Dict[str, Any]:
        total_cost = (await db.execute(select(func.coalesce(func.sum(CostRecord.cost_usd), 0.0)))).scalar_one()
        total_calls = (await db.execute(select(func.count()).select_from(CostRecord))).scalar_one()
        return {"total_cost_usd": round(float(total_cost), 4), "total_calls": total_calls}

    async def create_budget(self, db: AsyncSession, **fields: Any) -> Budget:
        budget = Budget(id=uuid4(), **fields)
        db.add(budget)
        await db.flush()
        return budget

    async def list_budgets(self, db: AsyncSession) -> List[Budget]:
        return list((await db.execute(select(Budget))).scalars().all())

    # ------------------------------------------------------------------
    # Live subscription + reconciliation
    # ------------------------------------------------------------------

    async def run_live_subscriber(self) -> None:
        """Long-running loop: consumes the existing TelemetryEventBus, forever."""
        from echolib.database import get_db_session
        from echolib.telemetry_stream import get_event_bus

        bus = get_event_bus()
        queue = bus.subscribe("*")
        logger.info("Agent Trust cost subscriber attached to TelemetryEventBus")

        while True:
            event = await queue.get()
            if event.get("event_type") not in ("llm_call", "tool_call"):
                continue
            try:
                async with get_db_session() as db:
                    await self.record_from_event(db, event)
                    await db.commit()
            except Exception:
                logger.warning("Cost subscriber failed to process event", exc_info=True)

    async def run_reconciliation_loop(self) -> None:
        """Periodic backfill for anything the live subscriber missed (e.g. restart gap)."""
        from echolib.database import get_db_session

        while True:
            await asyncio.sleep(RECONCILE_INTERVAL_SECONDS)
            try:
                await self._reconcile_once()
            except Exception:
                logger.warning("Cost reconciliation iteration failed", exc_info=True)

    async def _reconcile_once(self) -> int:
        from echolib.database import get_db_session

        cutoff = datetime.now(timezone.utc) - timedelta(minutes=RECONCILE_WINDOW_MINUTES)
        backfilled = 0
        async with get_db_session() as db:
            stmt = (
                select(TelemetryEvent)
                .where(
                    TelemetryEvent.timestamp >= cutoff,
                    TelemetryEvent.event_type.in_(["llm_call", "tool_call"]),
                    TelemetryEvent.agent_id.is_not(None),
                    TelemetryEvent.agent_id != "",
                )
            )
            rows = (await db.execute(stmt)).scalars().all()
            for row in rows:
                event = {
                    "event_id": str(row.event_id), "agent_id": row.agent_id, "model": row.model,
                    "provider": row.provider, "input_tokens": row.input_tokens,
                    "output_tokens": row.output_tokens, "status": row.status,
                    "billing_source": row.billing_source, "feature": row.feature,
                    "workflow_id": row.workflow_id, "event_type": row.event_type,
                    "timestamp": row.timestamp,
                }
                record = await self.record_from_event(db, event)
                if record is not None:
                    backfilled += 1
            await db.commit()
        return backfilled

    async def backfill_from_telemetry(self, db: AsyncSession, *, since_days: int = 365) -> Dict[str, int]:
        """
        One-shot historic import of attributable telemetry into cost records.

        Only rows that already carry an ``agent_id`` can be imported -- token
        telemetry written before agent attribution existed is not recoverable.
        Idempotent via ``CostRecord.source_event_id``.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=since_days)
        rows = (
            await db.execute(
                select(TelemetryEvent).where(
                    TelemetryEvent.timestamp >= cutoff,
                    TelemetryEvent.event_type.in_(["llm_call", "tool_call"]),
                    TelemetryEvent.agent_id.is_not(None),
                    TelemetryEvent.agent_id != "",
                )
            )
        ).scalars().all()

        imported = 0
        for row in rows:
            record = await self.record_from_event(
                db,
                {
                    "event_id": str(row.event_id), "agent_id": row.agent_id, "model": row.model,
                    "provider": row.provider, "input_tokens": row.input_tokens,
                    "output_tokens": row.output_tokens, "status": row.status,
                    "billing_source": row.billing_source, "feature": row.feature,
                    "workflow_id": row.workflow_id, "event_type": row.event_type,
                    "timestamp": row.timestamp,
                },
            )
            if record is not None:
                imported += 1

        logger.info(
            "agent_trust_cost_backfill_completed",
            extra={"candidates": len(rows), "imported": imported},
        )
        return {"candidates": len(rows), "imported": imported}
