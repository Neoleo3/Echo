"""
Judge LLM -- shared wrapper for every Agent Trust call that needs an LLM
verdict (policy assignment, red-team verdicts, semantic test grading,
governance review summaries).

WHY ONE MODULE: every judge task needs the same three things -- resolve a
model via the platform's single entry point, get the response wrapped in
``trace_llm_call`` so tokens land in the same counters as every other call in
the system, and parse a structured JSON verdict robustly. Keeping this in one
place means every phase gets that for free instead of re-implementing it.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional

from echolib.llm_resolver import resolve_and_build_llm
from echolib.otel import trace_llm_call
from echolib.telemetry_context import telemetry_context

logger = logging.getLogger(__name__)

JUDGE_PASS = "PASS"
JUDGE_FAIL = "FAIL"
JUDGE_PROVIDER_BLOCKED = "PROVIDER_BLOCKED"
JUDGE_INCONCLUSIVE = "INCONCLUSIVE"
JUDGE_SYSTEM_ERROR = "SYSTEM_ERROR"

class JudgeParseError(Exception):
    """Raised when the Judge LLM's response could not be parsed as JSON."""


def _extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Judge models sometimes wrap JSON in prose or a fenced code block.
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass
    raise JudgeParseError(f"Judge LLM did not return parseable JSON: {text[:300]!r}")

def _classify_llm_failure(
    ex: Exception,
) -> dict:

    error_text = str(ex).lower()

    safety_indicators = [
        "content_filter",
        "responsibleaipolicyviolation",
        "responsible ai",
        "jailbreak",
        "prompt attack",
        "guardrail",
        "safety",
        "harmful",
        "blocked",
        "policy violation",
    ]

    if any(
        indicator in error_text
        for indicator in safety_indicators
    ):
        return {
            "status": JUDGE_PROVIDER_BLOCKED,
            "provider_intervened": True,
            "error": str(ex),
        }

    return {
        "status": JUDGE_SYSTEM_ERROR,
        "provider_intervened": False,
        "error": str(ex),
    }
async def ask_judge(
    *,
    component: str,
    system_prompt: str,
    user_prompt: str,
    user_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    temperature: float = 0.0,
) -> Dict[str, Any]:
    """
    Call the Judge LLM and return its parsed structured verdict.

    Args:
        component: KV/telemetry component label, e.g. "agent_trust_policy_judge".
        system_prompt: Instructions + rubric for the judging task.
        user_prompt: The specific content to judge (payload/response/etc).
        user_id: None for a system-level judgement (platform fallback credential);
            the agent owner's user_id when the judgement concerns their agent.
        temperature: Deterministic (0.0) by default for reproducible governance decisions.

    Raises:
        JudgeParseError: if the response cannot be parsed as JSON.
    """
    llm = await resolve_and_build_llm(
        user_id=user_id,
        allow_platform_fallback=True,
        component=component,
        temperature=temperature,
    )

    model_name = getattr(llm, "model_name", None) or getattr(llm, "model", "unknown")

    try:
        with telemetry_context(agent_trust_agent_id=agent_id):
            with trace_llm_call(
                method="ainvoke",
                model=str(model_name),
                provider="agent_trust",
                feature=component,
                user_id=user_id or "system",
            ) as ctx:
                response = await llm.ainvoke(
                    [
                        {
                            "role": "system",
                            "content": system_prompt,
                        },
                        {
                            "role": "user",
                            "content": user_prompt,
                        },
                    ]
                )

                ctx["response"] = response
        content = getattr(
            response,
            "content",
            str(response),
        )
        return _extract_json(content)
    except JudgeParseError:
        raise
    except Exception as ex:
        classification = _classify_llm_failure(
            ex
        )
        if classification["status"] != JUDGE_PROVIDER_BLOCKED:
            logger.warning(
                "judge_llm_failed",
                extra={
                    "component": component,
                    "status": classification["status"],
                },
                exc_info=True,
            )
        return classification
