# ConvoBI recommendation validator change guide

## Files in this package

- `convobi/recommendation_validator.py` — new recommendation module. This owns the recommendation prompt, one-call candidate generation, and lightweight validation.
- `convobi/main.py` — recommendation-only implementation has been removed. The rest of the production module is preserved; existing query/invoke, SQL execution, schema discovery, visualization, and response code are not intentionally changed.
- `convobi/routes.py` — the recommendation import now comes from `.recommendation_validator`; the endpoint contract and route behavior are otherwise unchanged.

## New recommendation flow

1. Resolve the active database using the existing recommendation endpoint.
2. Read ConvoBI's existing schema metadata (tables, columns, types, relationships, row counts, and available sample values).
3. Make one LLM call to generate 10 simple question/SQL candidates. The prompt explicitly describes ConvoBI's `/query` and `/invoke` JSON response fields (`data`, `columns`, `row_count`, `response`, and optional visualization fields) and asks for simple aggregate, grouped, or table-style questions suited to those outputs.
4. Validate candidates with ConvoBI's existing `validate_sql_against_schema` function and execute each candidate directly against the already-active SQLAlchemy database connection. Fetch only one row to check that the query returns data.
5. Return the first requested number of valid questions, stopping as soon as the requested count is reached. It does not invoke `invoke_convobi_agent()` and does not make a second LLM generation call if fewer candidates pass.

## Important implementation notes

- The LLM receives schema metadata, not the full contents of every table.
- This validator uses the generated SQL paired with each question so it can check real execution without running answer summarization or chart generation during validation. When the user later selects a suggestion, the existing `/query` or `/invoke` endpoint remains responsible for the final answer and visualization.
- A returned question has SQL that passed the implemented schema check and returned at least one row at validation time. This is not a guarantee of perfect semantic interpretation or future execution if data/permissions change.
- The existing `validate_sql_against_schema` helper has a permissive fallback if its own internal validation errors. For stronger production guarantees, that helper should be tightened in a separate, carefully tested change; this package does not alter it because it is shared production behavior.
- The SQL read-only guard is a defense-in-depth check, not a substitute for a read-only database role and the existing authorization model.

## Deployment

1. Back up the current `convobi/main.py` and `convobi/routes.py`.
2. Apply the included files under the existing `convobi/` package so the new module sits alongside `main.py` and `routes.py`.
3. Run Python syntax checks and the existing unit tests.
4. In staging, call `POST /recommended-questions` with `question_count=1`, `2`, and a larger allowed count. Confirm returned suggestions execute through the existing `/query` endpoint and that normal `/query` and `/invoke` behavior remains unchanged.

Syntax compilation was checked for all three Python files. Database-backed integration tests were not run in this environment.
