"""Low-token, response-aware ConvoBI recommendation generation and validation.

This module intentionally does not call ``invoke_convobi_agent``. It makes one
LLM call to generate a bounded batch of simple question/SQL pairs, then uses
ConvoBI's existing schema metadata and SQL validation plus the active SQLAlchemy
connection to reject candidates that are unsafe, invalid, fail execution, or
return no rows. The regular /query and /invoke endpoints remain responsible for
answer text and visualization rendering when a user selects a suggestion.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage
from langchain_community.utilities.sql_database import SQLDatabase
from sqlalchemy import text

from .main import _get_convobi_llm_async, get_schema_info, validate_sql_against_schema

LOG = logging.getLogger(__name__)
MAX_RECOMMENDATION_COUNT = 8
CANDIDATE_BATCH_SIZE = 10


def _normalize_question(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", (value or "").lower())).strip()


def _schema_context(tables: Dict[str, Any]) -> str:
    """Serialize available schema metadata, never full table records."""
    blocks: List[str] = []
    for table_name, info in sorted(tables.items(), key=lambda item: item[0].lower()):
        lines = [f"TABLE: {table_name}", f"ROW COUNT: {info.get('row_count', 'unknown')}", "COLUMNS:"]
        for col in info.get("columns", []):
            name = col.get("name")
            if not name:
                continue
            parts = [f"{name} ({col.get('type', 'unknown')})"]
            if col.get("primary_key"):
                parts.append("primary key")
            if col.get("foreign_key"):
                parts.append(f"foreign key -> {col['foreign_key']}")
            meaning = col.get("meaning") or col.get("description")
            if meaning:
                parts.append(f"meaning: {str(meaning)[:180]}")
            examples = col.get("examples") or col.get("example_values") or []
            if examples:
                parts.append("sample values: " + ", ".join(str(v)[:40] for v in examples[:3]))
            lines.append("- " + " | ".join(parts))
        relationships = info.get("relationships") or []
        if relationships:
            lines.append("RELATIONSHIPS:")
            for relation in relationships[:20]:
                lines.append(f"- {relation}")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


def _parse_candidates(content: Any) -> List[Dict[str, str]]:
    if isinstance(content, list):
        content = "".join(str(part.get("text", "")) if isinstance(part, dict) else str(part) for part in content)
    raw = str(content or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE).strip()
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            raise ValueError("LLM returned no JSON candidate object")
        payload = json.loads(match.group(0))

    items = payload.get("candidates", []) if isinstance(payload, dict) else []
    output: List[Dict[str, str]] = []
    seen: set[str] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        question = str(item.get("question") or "").strip()
        sql = str(item.get("sql") or "").strip()
        key = _normalize_question(question)
        if not key or key in seen or not sql:
            continue
        seen.add(key)
        output.append({"question": question, "sql": sql})
        if len(output) >= CANDIDATE_BATCH_SIZE:
            break
    return output


def _is_read_only_single_select(sql: str) -> bool:
    statement = (sql or "").strip()
    if not statement or "\x00" in statement:
        return False
    if statement.endswith(";"):
        statement = statement[:-1].rstrip()
    if ";" in statement or not re.match(r"^(SELECT|WITH)\b", statement, re.IGNORECASE):
        return False
    if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|MERGE|GRANT|REVOKE|CALL|EXEC(?:UTE)?)\b", statement, re.IGNORECASE):
        return False
    return True


def _execute_and_check_rows(db: SQLDatabase, sql: str) -> bool:
    """Execute a candidate and fetch only one row; do not materialize result sets."""
    engine = getattr(db, "_engine", None)
    if engine is None:
        raise RuntimeError("Active ConvoBI SQLDatabase has no SQLAlchemy engine")
    with engine.connect() as connection:
        result = connection.execute(text(sql.strip().rstrip(";")))
        try:
            return result.fetchone() is not None
        finally:
            result.close()


async def _generate_candidates(user_id: Optional[str], schema: str) -> List[Dict[str, str]]:
    llm = await _get_convobi_llm_async(user_id)
    prompt = f"""You generate starter questions for ConvoBI, an existing natural-language-to-SQL BI application.

Generate exactly {CANDIDATE_BATCH_SIZE} distinct, SIMPLE questions and the read-only SQL that answers each one.
The application will execute the SQL to validate each suggestion. Do not generate explanations, answers, charts, or markdown.

IMPORTANT: questions must fit ConvoBI's existing /query and /invoke response contract. Successful responses contain fields such as:
- success: whether query execution succeeded
- sql: the executed SQL
- data: rows represented as JSON objects keyed by column name
- row_count: number of returned rows
- columns: returned column names
- response/summary: natural-language answer text
- visualization / visualization_spec / visualization_html: optional chart output produced by ConvoBI's existing visualization pipeline

Generate questions whose results are straightforward tabular data that ConvoBI can summarize and, when suitable, chart. Examples of good patterns (ONLY if schema supports them):
- "How many orders are there?" (single COUNT result / KPI-style answer)
- "How many products are there?" (single COUNT result / KPI-style answer)
- "How many orders are there for each status?" (small category + numeric result suitable for a bar/pie chart)
- "Show the latest orders" (a simple ordered table)
- "How many records are there for each category?" (small grouped result suitable for a chart)

Rules:
1. Use only tables and columns explicitly present in the schema below. Never invent a table, column, metric, relationship, or business concept.
2. Prefer simple single-table queries, COUNT/SUM where the meaning is clear, and small GROUP BY results. Use joins only when necessary and clearly supported by declared relationships.
3. Avoid compound questions, multiple unrelated entities in one question, complex rankings, anomaly detection, multi-step calculations, and unsupported time-series questions.
4. Make questions concise and natural. Each question must describe what its SQL actually returns.
5. Use the connected database's SQL dialect. Produce one read-only SELECT (a WITH clause is allowed only when it leads to a single SELECT). Never produce multiple statements or write operations.
6. Do not use SELECT * for aggregate questions. For record-list questions, return a small, useful set of existing columns.
7. Do not include any sample records in the question. Schema metadata and limited sample categorical values are supplied only to ground the wording.
8. Return exactly one JSON object, with this shape and no extra keys:
{{"candidates":[{{"question":"How many orders are there?","sql":"SELECT COUNT(*) AS total_orders FROM orders"}}]}}

DATABASE SCHEMA AND METADATA:
{schema}
"""
    response = await asyncio.to_thread(llm.invoke, [HumanMessage(content=prompt)])
    return _parse_candidates(getattr(response, "content", ""))


async def generate_recommended_questions(
    *, user_id: str, db: SQLDatabase, question_count: int = 5, force_refresh: bool = False,
) -> Dict[str, Any]:
    """Generate one batch, validate candidates cheaply, and return verified questions.

    ``force_refresh`` remains accepted for compatibility with the existing route.
    No second generation call is made if some candidates fail validation.
    """
    del force_refresh
    requested = max(1, min(MAX_RECOMMENDATION_COUNT, int(question_count or 5)))
    generated_at = datetime.now(timezone.utc).isoformat()

    try:
        tables = get_schema_info(db)
        schema = _schema_context(tables)
        if not schema.strip():
            return {"success": False, "questions": [], "generated_at": generated_at, "source": "no_schema"}
        candidates = await _generate_candidates(user_id, schema)
    except Exception:
        LOG.exception("[RECOMMEND] candidate generation failed")
        return {"success": False, "questions": [], "generated_at": generated_at, "source": "generation_failed"}

    selected: List[Dict[str, Any]] = []
    seen_sql: set[str] = set()
    for candidate in candidates:
        if len(selected) >= requested:
            break
        question, sql = candidate["question"], candidate["sql"].strip()
        fingerprint = re.sub(r"\s+", " ", sql).lower().rstrip(";")
        if fingerprint in seen_sql:
            continue
        seen_sql.add(fingerprint)
        if not _is_read_only_single_select(sql):
            continue
        try:
            valid, _reason = validate_sql_against_schema(sql, tables)
            if not valid:
                continue
            has_rows = await asyncio.to_thread(_execute_and_check_rows, db, sql)
            if not has_rows:
                continue
        except Exception as exc:
            LOG.debug("[RECOMMEND] candidate rejected (%s)", type(exc).__name__)
            continue
        selected.append({"question": question, "sql": sql, "execution_success": True, "has_rows": True})

    LOG.info("[RECOMMEND] generated=%s returned=%s requested=%s", len(candidates), len(selected), requested)
    return {
        "success": bool(selected),
        "questions": [item["question"] for item in selected],
        "generated_at": generated_at,
        "source": "lightweight_sql_validated",
    }
