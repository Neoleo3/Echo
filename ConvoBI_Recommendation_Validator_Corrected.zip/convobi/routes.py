"""
Convobi API Routes — LangGraph Edition
=======================================
All endpoint paths, request bodies and response shapes are **identical**
to the legacy version so the UI and Echo-Agent integration remain unchanged.

New endpoint:
  POST /invoke  — direct LangGraph agent invocation with session memory.
"""

from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Form, Body, Depends
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from sqlalchemy import text, inspect, create_engine
import pandas as pd
import os
import shutil
import time
import re
import json
import uuid
from pathlib import Path
import logging
import socket

from echolib.security import get_current_user
from echolib.types import UserContext
from echolib.blob_storage import download_from_blob, upload_to_blob, derive_blob_name_from_path
from apps.analytics.token_limit import (
    TokenLimitExceededException,
)
from apps.analytics.token_governance_handler import handle_token_limit_exception
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_core.messages import HumanMessage

router = APIRouter(tags=["Convobi / NLP DB"])

# ---------------------------------------------------------------------------
# Import everything from new main.py
# ---------------------------------------------------------------------------
import asyncio

from .main import (
    app_state, CURRENT_DIALECT, CURRENT_CONNECTOR,
    generate_ddl_for_schema_edit,
    QueryRequest, QueryResponse, SchemaResponse, SummarizeRequest,
    InvokeRequest, InvokeResponse,
    _get_convobi_llm_async,
    CONVOBI_AGENT_VERBOSE,
    invoke_convobi_agent,
    activate_connection,
    _normalize_connection_string, _dialect_from_connection_string,
    _resolve_connection_string,
    get_connection_string_for_file_id, get_saved_connection_string,
    compute_db_id,
    get_schema_info, build_schema_summary, _format_schema_hint_for_question,
    build_plotly_visualization,
    build_plotly_html,
    build_agent, _build_checkpointer,
    _parse_agent_results, _extract_agent_steps, _extract_tables_used,
    ensure_connection_active,
    user_has_write_access, execute_ddl,
    refresh_glossary_from_db,
    get_glossary_path_for_file_id,
    get_glossary_path_for_connection_id,
    get_file_upload_info,
    load_schema_metadata_for_file,
    export_sqlite_to_csv_excel,
    _save_file_id_registry_to_disk,
    _is_itsm_connection,
    update_glossary_column_description,
    update_schema_column_metadata,
    apply_schema_metadata_overrides,
    UPLOADS_DIR,
    LOG,
    _summarize_visualization_html_for_log,
)

from .recommendation_validator import generate_recommended_questions

# OTel metrics — soft import
try:
    from echolib.otel import get_metrics_collector as _get_mc
except ImportError:
    _get_mc = None


LOG = logging.getLogger(__name__)
FILE_SYSTEM_THRESHOLD_BYTES = 1 * 1024 * 1024  # 1 MB
# ---------------------------------------------------------------------------
# Shared request bodies (same as legacy)
# ---------------------------------------------------------------------------


class ConnectionIdBody(BaseModel):
    connection_id: Optional[str] = Field(None, alias="connectionId",
        description="ID of the DB connection from POST /connectors/plugin/load")
    file_id: Optional[str] = Field(None, alias="fileId",
        description="ID of an uploaded file from POST /convobi/files/upload")

    class Config:
        populate_by_name = True


class EditSchemaColumnBody(BaseModel):
    """Single column edit within a table."""
    column: str = Field(..., description="Column name")
    description: Optional[str] = None
    nullable: Optional[bool] = None
    primary_key: Optional[bool] = None
    foreign_key: Optional[str] = Field(None, alias="foreignKey")
    type: Optional[str] = None
    name: Optional[str] = None

    class Config:
        populate_by_name = True


class EditSchemaTableBody(BaseModel):
    """Table with its column edits."""
    table: str = Field(..., description="Table name")
    columns: List[EditSchemaColumnBody] = Field(..., description="Columns to edit for this table")

    class Config:
        populate_by_name = True


class EditSchemaBulkBody(BaseModel):
    """Bulk schema edit request - array of tables, each with its columns."""
    edits: List[EditSchemaTableBody] = Field(
        ...,
        description="List of table objects, each containing columns to edit",
    )
    connection_id: Optional[str] = Field(None, alias="connectionId")
    file_id: Optional[str] = Field(None, alias="fileId")

    class Config:
        populate_by_name = True


class DdlRequest(BaseModel):
    ddl: str = Field(..., description="DDL SQL statement")
    connection_id: Optional[str] = Field(None, alias="connectionId")
    file_id: Optional[str] = Field(None, alias="fileId")
    refresh_schema: bool = Field(True)

    class Config:
        populate_by_name = True


class PluginLoadBody(BaseModel):
    connection_string: str = Field(..., description="SQLAlchemy connection string")
    connector: str = Field("sql", description="Connector type")
# --------- Classes used for recommending questions for ConvoBI -------------
class RecommendedQuestionsRequest(BaseModel):
    connection_id: Optional[str] = Field(
        None,
        description="Database connection id",
    )
    file_id: Optional[str] = Field(
        None,
        description="Uploaded file id",
    )
    question_count: int = Field(
        5,
        ge=1,
        le=8,
        description="Number of validated recommendations to return (1-8)",
    )
    force_refresh: bool = Field(
        False,
        description="Ignore cache and regenerate questions",
    )


class RecommendedQuestionsResponse(BaseModel):
    success: bool
    questions: List[str]
    generated_at: str
    source: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_connection_and_schema(connection_id: Optional[str] = None, file_id: Optional[str] = None):
    """Resolve connection_id / file_id, activate if needed, ensure DB ready."""
    
    LOG.info(
        "[ENSURE] connection_id=%s file_id=%s",
        connection_id,
        file_id,
    )

    LOG.info(
        "[ENSURE] active_connection_id=%s active_file_id=%s db_exists=%s",
        app_state.get("active_connection_id"),
        app_state.get("active_file_id"),
        app_state.get("db") is not None,
    )

    if connection_id and file_id:
        raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")

    if file_id:
        cs = get_connection_string_for_file_id(file_id)
        
        LOG.info(
            "[ENSURE] file_mode file_id=%s connection_string_found=%s",
            file_id,
            bool(cs),
        )

        if not cs:
            raise HTTPException(status_code=404,
                detail=f"Uploaded file '{file_id}' not found. Use POST /convobi/files/upload first.")
        active_fid = app_state.get("active_file_id")
        if active_fid != file_id or app_state.get("db") is None:
            activate_connection(cs)
            app_state["active_file_id"] = file_id

    elif connection_id:
        active_cid = app_state.get("active_connection_id")
        
        LOG.info(
        "[ENSURE] requested_connection_id=%s active_connection_id=%s",
        connection_id,
        active_cid,
        )

        if active_cid != connection_id or app_state.get("db") is None:
            
            LOG.info(
            "[ENSURE] loading connection_id=%s",
            connection_id,
            )

            cs = get_saved_connection_string(connection_id)
            
            LOG.info(
            "[ENSURE] connection_string_found=%s",
            bool(cs),
            )

            if not cs:
                
                LOG.error(
                "[ENSURE] connection_id=%s NOT FOUND",
                connection_id,
                )

                raise HTTPException(status_code=404,
                    detail=f"Connection '{connection_id}' not found.")
            activate_connection(cs, connection_id=connection_id)
            
            LOG.info(
            "[ENSURE] activated connection_id=%s",
            connection_id,
            )

        app_state["active_file_id"] = None

    else:
        app_state["active_file_id"] = None
        ensure_connection_active()

    if app_state.get("db") is None:
        raise HTTPException(status_code=400,
            detail="No database connected. Use POST /convobi/plugins/load to connect.")


def _strip_schema_api_fields(tables: Dict[str, Any]) -> Dict[str, Any]:
    """Remove meaning and example_values from column objects for schema/schema-doc API responses."""
    out = {}
    for tname, tbl in tables.items():
        cols = []
        for c in tbl.get("columns", []):
            col = {k: v for k, v in c.items() if k not in ("meaning", "example_values")}
            cols.append(col)
        out[tname] = {**tbl, "columns": cols}
    return out


def _is_ddl_statement(sql: str) -> bool:
    s = (sql or "").strip().upper()
    for line in s.split("\n"):
        line = line.strip()
        if line.startswith("--") or line.startswith("/*") or not line:
            continue
        parts = line.split()
        if not parts:
            continue
        first = parts[0]
        return first in ("CREATE", "ALTER", "DROP", "TRUNCATE", "RENAME", "COMMENT", "GRANT", "REVOKE")
    return False


# ===========================================================================
# ENDPOINTS (same paths, same request/response models)
# ===========================================================================

@router.get("/")
async def root():
    db = app_state.get("db")
    table_count = len(db.get_usable_table_names()) if db else 0
    return {
        "status": "healthy",
        "service": "NLP Database Interface (LangGraph + SQLDatabaseToolkit)",
        "version": "2.0.0",
        "llm_model": "Per-user LLM resolution (lazy)",
        "tables_loaded": table_count,
        "dialect": CURRENT_DIALECT,
        "connector": CURRENT_CONNECTOR,
        "connection_id": app_state.get("active_connection_id"),
        "file_id": app_state.get("active_file_id"),
    }


# ---------- POST /schema ----------
@router.post("/schema", response_model=SchemaResponse,
    summary="Get schema structure and short summary")
async def get_schema(request: Optional[ConnectionIdBody] = Body(None)):
    cid = request.connection_id if request else None
    fid = request.file_id if request else None
    _ensure_connection_and_schema(connection_id=cid, file_id=fid)
    db: SQLDatabase = app_state["db"]
    tables = get_schema_info(db)
    fid = fid or app_state.get("active_file_id")
    cid = cid or app_state.get("active_connection_id")
    tables = apply_schema_metadata_overrides(tables, file_id=fid, connection_id=cid)
    tables = _strip_schema_api_fields(tables)
    summary = build_schema_summary(tables)
    return SchemaResponse(tables=tables, total_tables=len(tables), summary=summary)

# ---------- POST / recommended-questions  ----------
@router.post(
    "/recommended-questions",
    response_model=RecommendedQuestionsResponse,
    summary="Generate starter questions for a database",
)
async def recommended_questions(
    request: RecommendedQuestionsRequest,
    user: UserContext = Depends(
        get_current_user,
    ),
):
    LOG.info(
        "[RECOMMEND] request connection_id=%s file_id=%s question_count=%s force_refresh=%s user_id=%s",
        request.connection_id,
        request.file_id,
        request.question_count,
        request.force_refresh,
        user.user_id,
    )

    try:
        _ensure_connection_and_schema(
            connection_id=request.connection_id,
            file_id=request.file_id,
        )
        LOG.info(
            "[RECOMMEND] connection ready connection_id=%s file_id=%s active_connection_id=%s active_file_id=%s",
            request.connection_id,
            request.file_id,
            app_state.get("active_connection_id"),
            app_state.get("active_file_id"),
        )
        db: SQLDatabase = app_state[
            "db"
        ]
        LOG.info(
            "[RECOMMEND] generating questions"
        )
        result = (
            await generate_recommended_questions(
                user_id=user.user_id,
                db=db,
                question_count=request.question_count,
                force_refresh=request.force_refresh,
            )
        )
        LOG.info(
            "[RECOMMEND] returning source=%s count=%s",
            result["source"],
            len(result["questions"]),
        )

        return RecommendedQuestionsResponse(
            success=result["success"],
            questions=result[
                "questions"
            ],
            generated_at=result[
                "generated_at"
            ],
            source=result[
                "source"
            ],
        )
    except HTTPException:
        raise
    except Exception:
        LOG.exception(
            "recommended_questions failed"
        )
        return RecommendedQuestionsResponse(
            success=False,
            questions=[],
            generated_at=datetime.utcnow().isoformat(),source="error",)


# ---------- POST /query ----------
@router.post("/query", response_model=QueryResponse)
async def execute_query(
    request: QueryRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Main NL-to-SQL pipeline using LangGraph agent with SQLDatabaseToolkit.
    """
    try:
        LOG.info(
            "[QUERY] connector_id=%s file_id=%s",
            request.connector_id,
            request.file_id,
        )

        LOG.info(
            "[QUERY] app_state_keys=%s",
            list(app_state.keys()),
        )
        _ensure_connection_and_schema(connection_id=request.connector_id, file_id=request.file_id)
        
        LOG.info(
            "[QUERY] connection loaded successfully connector_id=%s",
            request.connector_id,
        )


        if not request.question or not request.question.strip():
            raise HTTPException(status_code=422, detail="Question must not be empty.")
        if request.max_results is not None and request.max_results < 0:
            raise HTTPException(status_code=422, detail="max_results must be non-negative (0 = unlimited).")
        if request.language != "sql":
            raise HTTPException(status_code=422, detail="Only 'sql' is supported.")

        db: SQLDatabase = app_state.get("db")
        if not db:
            raise HTTPException(status_code=400,
                detail="No database connected. Use POST /convobi/plugins/load.")

        try:
            convobi_llm = await _get_convobi_llm_async(user.user_id)

        except TokenLimitExceededException as ex:

            LOG.warning(
                "[QUERY] token limit exceeded user=%s limit_type=%s usage=%s limit=%s",
                user.user_id,
                ex.limit_type,
                ex.current_usage,
                ex.limit_value,
            )

            raise HTTPException(
                status_code=429,
                detail={
                    "error": "token_limit_exceeded",
                    "message": ex.message,
                    "limit_type": ex.limit_type,
                    "current_usage": ex.current_usage,
                    "limit_value": ex.limit_value,
                },
            )

        except Exception:
            LOG.exception(
                "LLM resolution failed for user=%s",
                user.user_id,
            )

            raise HTTPException(
                status_code=502,
                detail="LLM not configured for Convobi agent.",
            )

        start_ms = time.time() * 1000

        # Always build agent with the current user's resolved LLM so each
        # user gets their own credential / model (Option B: per-request build).
        checkpointer = app_state.get("checkpointer") or _build_checkpointer()
        agent = build_agent(
            convobi_llm, db, CURRENT_DIALECT,
            glossary_hint="",
            checkpointer=checkpointer,
        )

        tables = get_schema_info(db)
        schema_hint = _format_schema_hint_for_question(tables, request.question)
        limit_hint = f" (return at most {request.max_results} rows)" if request.max_results and request.max_results > 0 else ""
        user_msg = f"{schema_hint}\n\nQuestion: {request.question}{limit_hint}" if schema_hint else f"{request.question}{limit_hint}"

        session_id = str(uuid.uuid4())
        config = {"configurable": {"thread_id": session_id}}

        result = agent.invoke({"messages": [HumanMessage(content=user_msg)]}, config)

        elapsed_ms = time.time() * 1000 - start_ms
        parsed = _parse_agent_results(result["messages"], db, request.question)

        viz_payload = None
        viz_html = None
        if parsed["columns"] and parsed["data"]:
            viz_payload = build_plotly_visualization(
                parsed["columns"], parsed["data"], request.question,
            )
            viz_html = build_plotly_html(
                parsed["columns"], parsed["data"], request.question,
                visualization=viz_payload,
            )

        LOG.info(
            "[QUERY] visualization prepared: %s",
            _summarize_visualization_html_for_log(viz_html),
        )

        # Tables used — sample data (only relevant columns) from tables in the SQL
        tables_used = _extract_tables_used(
            parsed.get("sql"), db,
            result_columns=parsed.get("columns"),
            sample_rows=5,
        )

        # Agent steps (only when verbose)
        steps = _extract_agent_steps(result["messages"]) if CONVOBI_AGENT_VERBOSE else None

        success = parsed.get("data") is not None or parsed.get("explanation") is not None

        # Record OTel metrics for convobi query
        if _get_mc:
            try:
                mc = _get_mc()
                mc.record_feature_use(feature="convobi_query", duration_ms=elapsed_ms, success=success)
            except Exception:
                pass

        app_state["conversation_history"].append({
            "timestamp": datetime.now().isoformat(),
            "question": request.question,
            "sql": parsed.get("sql"),
            "success": success,
            "row_count": parsed.get("row_count"),
        })
        if len(app_state["conversation_history"]) > 50:
            app_state["conversation_history"] = app_state["conversation_history"][-50:]

        LOG.info(
            "[QUERY] returning response: success=%s row_count=%s visualization=%s",
            success,
            parsed.get("row_count"),
            _summarize_visualization_html_for_log(viz_html),
        )

        return QueryResponse(
            success=success,
            response=parsed.get("response") or "",
            sql=parsed.get("sql"),
            explanation=parsed.get("explanation"),
            data=parsed.get("data"),
            row_count=parsed.get("row_count"),
            columns=parsed.get("columns"),
            visualization_hints=None,
            execution_time_ms=elapsed_ms,
            confidence=parsed.get("confidence"),
            optimizations=parsed.get("optimizations"),
            warnings=parsed.get("warnings"),
            error=None if parsed.get("data") is not None else parsed.get("raw_result"),
            summary=parsed.get("summary"),
            visualization=viz_payload,
            visualization_spec=None,
            visualization_html=viz_html,
            optimized_question=None,
            feedback_attempts=1,
            tables_used=tables_used,
            agent_steps=steps,
        )
    except HTTPException:
        raise
    except Exception as e:
        LOG.exception("Query pipeline failed")
        return QueryResponse(success=False, error=str(e))


# ---------- POST /invoke (NEW) ----------
@router.post("/invoke", response_model=InvokeResponse,
    summary="Direct LangGraph agent invocation with session memory")
async def invoke_agent(
    request: InvokeRequest,
    user: UserContext = Depends(get_current_user),
):
    """
    Invoke the Convi BI LangGraph agent directly.
    Supports session continuity via session_id.
    Used by Echo Agent, workflows, and standalone.
    """

    try:
        _ensure_connection_and_schema(connection_id=request.connection_id, file_id=request.file_id)

        cs = app_state.get("active_connection_string")
        # Run in worker thread: invoke_convobi_agent is sync and internally
        # calls resolve_and_build_llm_sync which would deadlock if run on
        # the event-loop thread.
        LOG.info(
        "[INVOKE] hostname=%s file_id=%s connection_id=%s",
        socket.gethostname(),
        request.file_id,
        request.connection_id,
        )
        result = await asyncio.to_thread(
            invoke_convobi_agent,
            question=request.message,
            connection_string=cs,
            session_id=request.session_id,
            max_results=request.max_results,
            user_id=user.user_id,
        )

        LOG.info(
            "[INVOKE] returning response: success=%s row_count=%s visualization=%s",
            result.get("success", False),
            result.get("row_count"),
            _summarize_visualization_html_for_log(result.get("visualization_html")),
        )

        return InvokeResponse(
            success=result.get("success", False),
            response=result.get("response") or "",
            sql=result.get("sql"),
            explanation=result.get("explanation"),
            data=result.get("data"),
            row_count=result.get("row_count"),
            columns=result.get("columns"),
            execution_time_ms=result.get("execution_time_ms"),
            confidence=result.get("confidence"),
            optimizations=result.get("optimizations"),
            warnings=result.get("warnings"),
            error=result.get("error"),
            summary=result.get("summary"),
            visualization=result.get("visualization"),
            visualization_html=result.get("visualization_html"),
            optimized_question=None,
            session_id=result.get("session_id", request.session_id or ""),
            tables_used=result.get("tables_used"),
            agent_steps=result.get("agent_steps"),
        )
    except TokenLimitExceededException as ex:
        handle_token_limit_exception(ex, "CONVOBI_INVOKE", user.user_id)
    except HTTPException:
        raise
    except Exception as e:
        LOG.exception("Invoke failed")
        return InvokeResponse(success=False, error=str(e), session_id=request.session_id or "")


# ---------- POST /summarize ----------
@router.post("/summarize")
async def summarize(
    req: SummarizeRequest,
    user: UserContext = Depends(get_current_user),
):
    try:
        convobi_llm = await _get_convobi_llm_async(user.user_id)
    except TokenLimitExceededException as ex:
        handle_token_limit_exception(ex, "CONVOBI_SUMMARIZE", user.user_id)
    except Exception as exc:
        LOG.exception("LLM resolution failed for summarize, user=%s", user.user_id)
        raise HTTPException(status_code=502, detail="LLM not configured.")
    try:
        data_str = json.dumps(req.data[:50], default=str)
        prompt = (
            f"Question: {req.question}\n"
            f"Columns: {req.columns}\n"
            f"Data (first 50 rows): {data_str}\n\n"
            "Provide a concise, natural-language summary of the data that answers the question. "
            "Use markdown formatting."
        )
        response = convobi_llm.invoke([HumanMessage(content=prompt)])
        summary = getattr(response, "content", str(response))
        return {"summary": summary}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"summarizer_error: {e}")


# ---------- GET /columns/meaning ----------
@router.get("/columns/meaning")
async def get_column_meaning(
    table: str = Query(...),
    column: str = Query(...),
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    from .column_glossary import get_column_glossary_description
    desc = get_column_glossary_description(column)
    if not desc:
        return {"found": False}
    return {
        "found": True,
        "meaning": desc,
        "description": desc,
        "confidence": 0.8,
        "source": "glossary",
        "examples": [],
    }


# ---------- POST /config/dialect ----------
@router.post("/config/dialect")
async def set_dialect(
    dialect: str,
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    global CURRENT_DIALECT
    d = (dialect or "").strip().lower()
    from .main import SUPPORTED_DIALECTS
    if d not in SUPPORTED_DIALECTS:
        raise HTTPException(status_code=400, detail=f"Unsupported dialect '{d}'")
    CURRENT_DIALECT = d
    app_state["agent"] = None
    return {"ok": True, "dialect": CURRENT_DIALECT}


# ---------- POST /schema/refresh ----------
@router.post("/schema/refresh")
async def refresh_schema(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    db: SQLDatabase = app_state["db"]
    tables = get_schema_info(db)
    app_state["agent"] = None
    return {"ok": True, "tables_loaded": len(tables)}


# ---------- POST /schema/glossary/refresh ----------
@router.post("/schema/glossary/refresh",
    summary="Refresh column glossary from DB unique column examples")
async def refresh_glossary(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    """
    Fetch unique values from each column in the connected database,
    merge with existing glossary descriptions, and write to column_glossary.json.
    Enriches the LLM so it picks the right columns (e.g. SALESSTAGECODE with Win/Loss examples).
    """
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    db: SQLDatabase = app_state["db"]
    result = refresh_glossary_from_db(db)
    app_state["agent"] = None
    return {"ok": True, **result}


# ---------- PUT /schema/edit and PUT /schema/doc/edit ----------
@router.put("/schema/edit",
    summary="Edit schema metadata (uploaded files and small SQLite DBs only)")
@router.put("/schema/doc/edit",
    summary="Edit schema documentation (alias)")
async def edit_schema(
    body: EditSchemaBulkBody,
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    cid = connection_id or body.connection_id
    fid = file_id or body.file_id
    if cid and fid:
        raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")
    # Flatten table->columns into list of (table, column_edit) for processing
    flat_edits: List[tuple[str, EditSchemaColumnBody]] = []
    for table_edit in body.edits:
        if not table_edit.columns:
            raise HTTPException(
                status_code=422,
                detail=f"Table '{table_edit.table}' must have at least one column in 'columns' array.",
            )
        for col_edit in table_edit.columns:
            flat_edits.append((table_edit.table, col_edit))

    if not flat_edits:
        raise HTTPException(status_code=422, detail="edits array is required and must not be empty")
    _ensure_connection_and_schema(connection_id=cid, file_id=fid)
    fid = fid or app_state.get("active_file_id")
    cid = cid or app_state.get("active_connection_id")
    # Editable: file uploads, or small SQLite/other DBs (connection_id) — NOT ITSM/CRM
    if fid is None and cid is None:
        raise HTTPException(
            status_code=400,
            detail="Provide either connection_id or file_id.",
        )
    if fid is None and cid and _is_itsm_connection():
        raise HTTPException(
            status_code=403,
            detail="Schema documentation is read-only for ITSM and CRM. "
                   "Editing is supported for uploaded files or small SQLite/other DBs.",
        )
    db: SQLDatabase = app_state["db"]
    table_names = db.get_usable_table_names()
    if fid:
        glossary_path = get_glossary_path_for_file_id(fid)
        if not glossary_path:
            raise HTTPException(status_code=404, detail=f"File '{fid}' not found in registry.")
    else:
        glossary_path = get_glossary_path_for_connection_id(cid)

    tables_info = get_schema_info(db)
    dialect = CURRENT_DIALECT

    applied: List[Dict[str, str]] = []
    ddl_errors: List[str] = []

    for table_name, edit in flat_edits:
        if table_name not in table_names:
            raise HTTPException(status_code=404, detail=f"table_not_found: {table_name}")
        if not edit.column:
            raise HTTPException(status_code=422, detail="column is required")

        # Find current column info for DDL generation
        tbl = tables_info.get(table_name, {})
        cols = tbl.get("columns", [])
        current_col = next((c for c in cols if c.get("name") == edit.column), {"name": edit.column, "type": "", "nullable": True, "primary_key": False, "foreign_key": None})

        # Generate and execute DDL to apply changes in the actual database
        ddl_statements = generate_ddl_for_schema_edit(
            table=table_name,
            column=edit.column,
            current_col=current_col,
            new_name=edit.name,
            new_type=edit.type,
            new_nullable=edit.nullable,
            new_primary_key=edit.primary_key,
            new_foreign_key=edit.foreign_key,
            dialect=dialect,
        )
        for ddl in ddl_statements:
            success, err, _ = execute_ddl(ddl)
            if not success:
                ddl_errors.append(f"{table_name}.{edit.column}: {err}")

        # Final column name (after possible rename) for glossary/metadata
        final_column = (edit.name or edit.column).strip() if (edit.name and str(edit.name).strip()) else edit.column

        update_glossary_column_description(
            glossary_path,
            final_column,
            None,  # meaning removed
            edit.description,
            remove_old_key=edit.column if final_column != edit.column else None,
        )
        update_schema_column_metadata(
            file_id=fid,
            connection_id=cid if fid is None else None,
            table=table_name,
            column=final_column,
            nullable=edit.nullable,
            primary_key=edit.primary_key,
            foreign_key=edit.foreign_key,
            type_=edit.type,
            name=edit.name,
            meaning=None,
            description=edit.description,
            remove_old_column=edit.column if final_column != edit.column else None,
            original_name=edit.column if final_column != edit.column else None,
        )
        applied.append({"table": table_name, "column": final_column})

    if ddl_errors:
        raise HTTPException(status_code=500, detail="DDL execution failed: " + "; ".join(ddl_errors[:5]))

    # Export SQLite back to the uploaded CSV/Excel file so changes are saved in the file itself
    info = get_file_upload_info(fid) if fid else None
    if fid and info and info.get("original_path") and info.get("format") in ("csv", "xlsx"):
        schema_meta = load_schema_metadata_for_file(fid)
        export_ok = export_sqlite_to_csv_excel(
            db_path=info["db_path"],
            output_path=info["original_path"],
            format_type=info["format"],
            sheets=info.get("sheets"),
            schema_metadata=schema_meta,
        )
        if not export_ok:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to save changes to {os.path.basename(info['original_path'])}. "
                       "Database updated but file export failed.",
            )

    app_state["agent"] = None
    file_saved = bool(fid and info and info.get("original_path") and info.get("format") in ("csv", "xlsx"))
    return {"ok": True, "applied": applied, "file_saved": file_saved}


# ---------- POST /schema/ddl ----------
@router.post("/schema/ddl",
    summary="Execute DDL on the database schema")
async def execute_schema_ddl(
    body: DdlRequest,
    user: UserContext = Depends(get_current_user),
):
    if body.connection_id and body.file_id:
        raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")
    _ensure_connection_and_schema(connection_id=body.connection_id, file_id=body.file_id)
    connection_id = app_state.get("active_connection_id") if not body.file_id else None
    file_id = app_state.get("active_file_id") if body.file_id else body.file_id
    if not user_has_write_access(connection_id, file_id, user.user_id or "", user.email or ""):
        raise HTTPException(status_code=403, detail="Write access required to perform DDL.")
    if not _is_ddl_statement(body.ddl):
        raise HTTPException(status_code=400, detail="Only DDL statements are allowed.")
    success, error, rows_affected = execute_ddl(body.ddl)
    if not success:
        raise HTTPException(status_code=500, detail=error or "DDL execution failed")
    out: Dict[str, Any] = {"ok": True, "message": "DDL executed successfully", "rows_affected": rows_affected}
    if body.refresh_schema:
        app_state["agent"] = None
        out["schema_refreshed"] = True
    return out


# ---------- POST /cache/clear ----------
@router.post("/cache/clear")
async def clear_caches(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    app_state["agent"] = None
    return {"ok": True}


# ---------- POST /visualize ----------
@router.post("/visualize")
async def visualize(
    payload: Dict[str, Any],
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    cols = payload.get("columns") or []
    dat = payload.get("data") or []
    html = build_plotly_html(cols, dat, payload.get("question", ""))
    return {"spec": None, "hints": {}, "html": html}


# ---------- POST /visualize/html ----------
@router.post("/visualize/html")
async def visualize_html(
    payload: Dict[str, Any],
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    cols = payload.get("columns") or []
    dat = payload.get("data") or []
    html = build_plotly_html(cols, dat, payload.get("question", ""))
    return {"html": html or ""}


# ---------- GET /tables/describe ----------
@router.get("/tables/describe")
async def describe_table(
    table: str = Query(...),
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    db: SQLDatabase = app_state["db"]
    tables = get_schema_info(db)
    if table not in tables:
        raise HTTPException(status_code=404, detail=f"table_not_found: {table}")
    t = tables[table]
    return {"table": table, "row_count": t.get("row_count"), "columns": t.get("columns", [])}


# ---------------------------------------------------------------------------
# File Upload Endpoints
# ---------------------------------------------------------------------------

def _sanitize_table_name(filename_or_sheet: str) -> str:
    base = os.path.splitext(os.path.basename(filename_or_sheet))[0]
    base = re.sub(r"[^A-Za-z0-9_]", "_", base).lower()
    return base or "uploaded_table"


def _uploads_db_path_for_file(filename: str) -> str:
    base = os.path.splitext(os.path.basename(filename))[0]
    safe = re.sub(r"[^A-Za-z0-9_]", "_", base).lower() or "uploaded_db"
    return os.path.join(UPLOADS_DIR, f"{safe}.db")


def _uploads_original_path_for_file(filename: str) -> str:
    """Original CSV/Excel path in uploads dir (for saving edits back)."""
    return os.path.join(UPLOADS_DIR, os.path.basename(filename))


@router.post("/files/upload")
async def upload_tabular_file(
    file: UploadFile = File(...),
    activate_source: bool = Form(True),
    sheet: Optional[str] = Form(None),
    table_name: Optional[str] = Form(None),
):
    if not file or not file.filename:
        raise HTTPException(status_code=422, detail="No file provided")
    ext = os.path.splitext(file.filename)[1].lower()
    tmp_path = os.path.join(UPLOADS_DIR, f"tmp_{int(time.time())}_{file.filename}")
    db_path = _uploads_db_path_for_file(file.filename)
    original_path = _uploads_original_path_for_file(file.filename)
    try:
        with open(tmp_path, "wb") as out:
            content = await file.read()
            out.write(content)
        tables_loaded = []
        sheets_info: List[Dict[str, str]] = []
        eng = create_engine(f"sqlite:///{db_path}", pool_pre_ping=True)
        if ext == ".csv":
            df = pd.read_csv(tmp_path)
            tname = table_name or _sanitize_table_name(file.filename)
            with eng.begin() as conn:
                df.to_sql(tname, con=conn, if_exists="replace", index=False)
            tables_loaded.append({"name": tname, "rows": int(df.shape[0]), "columns": list(df.columns)})
        elif ext == ".xlsx":
            xls = pd.ExcelFile(tmp_path, engine="openpyxl")
            sheet_names = [sheet] if sheet else xls.sheet_names
            for sh in sheet_names:
                df = pd.read_excel(tmp_path, sheet_name=sh, engine="openpyxl")
                tname = (table_name or _sanitize_table_name(sh)) if len(sheet_names) == 1 else _sanitize_table_name(sh)
                with eng.begin() as conn:
                    df.to_sql(tname, con=conn, if_exists="replace", index=False)
                tables_loaded.append({"name": tname, "rows": int(df.shape[0]), "columns": list(df.columns)})
                sheets_info.append({"sheet_name": sh, "table_name": tname})
        else:
            raise HTTPException(status_code=415, detail=f"Unsupported file type: {ext}. Use CSV or XLSX")

        # Save original file to uploads/ so edits can be written back
        shutil.copy2(tmp_path, original_path)
        
        LOG.info(
            "[FILE_STORAGE] Saved to filesystem original=%s sqlite=%s",
            original_path,
            db_path,
        )

        file_size = os.path.getsize(original_path)

        keep_local_copy = (
            file_size <= FILE_SYSTEM_THRESHOLD_BYTES
        )

        LOG.info(
            "[ConvoBI] file_size=%s keep_local_copy=%s",
            file_size,
            keep_local_copy,
        )
        # Upload generated SQLite DB to Azure Blob Storage
        try:
            blob_name = derive_blob_name_from_path(db_path)

            LOG.info(
                "[ConvoBI] Uploading DB file to Azure Blob. "
                "local=%s blob=%s",
                db_path,
                blob_name,
            )

            uploaded = upload_to_blob(
                db_path,
                blob_name,
            )

            if uploaded:
                LOG.info(
                    "[ConvoBI] DB file uploaded to Azure Blob successfully. "
                    "blob=%s",
                    blob_name,
                )
                LOG.info(
                    "[FILE_STORAGE] Uploaded to blob local=%s blob=%s size=%s",
                    db_path,
                    blob_name,
                    file_size,
                )

                if not keep_local_copy:

                    try:
                        if os.path.exists(db_path):
                            os.remove(db_path)

                        if os.path.exists(original_path):
                            os.remove(original_path)

                        LOG.info(
                            "[FILE_STORAGE] Removed local files db=%s original=%s size=%s threshold=%s source=blob_only",
                            db_path,
                            original_path,
                            file_size,
                            FILE_SYSTEM_THRESHOLD_BYTES,
                        )

                    except Exception:
                        LOG.exception(
                            "[ConvoBI] Failed removing local files"
                        )
            else:
                LOG.warning(
                    "[ConvoBI] Azure Blob upload failed. "
                    "blob=%s",
                    blob_name,
                )

        except Exception:
            LOG.exception(
                "[ConvoBI] Error uploading DB file to Azure Blob: %s",
                db_path,
            )

        activated = False
        if activate_source:
            cs = f"sqlite:///{db_path}"
            activate_connection(cs)
            activated = True

        file_id = str(uuid.uuid4())
        try:
            blob_name = derive_blob_name_from_path(db_path)
            from apps.convobi.main import save_uploaded_file_record
            save_uploaded_file_record(
                file_id=file_id,
                db_path=db_path,
                blob_name=blob_name,
                original_path=original_path,
                format_type="csv" if ext == ".csv" else "xlsx",
                sheets=sheets_info,
                stored_locally=keep_local_copy,
                file_size=file_size,
            )

            LOG.info(
                "[UPLOAD][DB_REGISTRY] saved file_id=%s blob=%s",
                file_id,
                blob_name,
            )

        except Exception:
            LOG.exception(
                "[UPLOAD][DB_REGISTRY] failed saving uploaded file metadata"
            )
        if "file_id_registry" not in app_state:
            app_state["file_id_registry"] = {}
        app_state["file_id_registry"][file_id] = {
            "db_path": db_path,
            "original_path": original_path,
            "stored_locally": keep_local_copy,
            "file_size": file_size,
            "format": "csv" if ext == ".csv" else "xlsx",
            "sheets": sheets_info,
        }
        _save_file_id_registry_to_disk()
        
        LOG.info(
            "[UPLOAD] hostname=%s file_id=%s db_path=%s",
            socket.gethostname(),
            file_id,
            db_path,
        )

        LOG.info(
            "[UPLOAD] registry_keys=%s",
            list((app_state.get("file_id_registry") or {}).keys()),
        )

        return {
            "ok": True,
            "file_id": file_id,
            "filename": file.filename,
            "database": db_path,
            "dialect": "sqlite",
            "tables": tables_loaded,
            "activated": activated,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"upload_error: {e}")
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


@router.get("/files/list")
async def list_uploaded_tables(
    db: Optional[str] = None,
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    try:
        _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
        if not db:
            db_files = [f for f in os.listdir(UPLOADS_DIR) if f.endswith(".db")]
            return {"databases": [os.path.join(UPLOADS_DIR, f) for f in db_files]}
        db_path = db if db.endswith(".db") else os.path.join(UPLOADS_DIR, f"{db}.db")
        eng = create_engine(f"sqlite:///{db_path}", pool_pre_ping=True)
        insp = inspect(eng)
        tables = insp.get_table_names()
        sizes: Dict[str, Any] = {}
        with eng.connect() as conn:
            for t in tables:
                try:
                    rc = conn.execute(text(f'SELECT COUNT(*) AS c FROM "{t}"')).scalar()
                    sizes[t] = int(rc or 0)
                except Exception:
                    sizes[t] = None
        return {"database": db_path, "tables": [{"name": t, "rows": sizes.get(t)} for t in tables]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"list_error: {e}")


# ---------- POST /plugins/load ----------
@router.post("/plugins/load",
    summary="Connect a database (any DB plugin)")
async def plugins_load(body: PluginLoadBody):
    cs = (body.connection_string or "").strip()
    if not cs:
        raise HTTPException(status_code=422, detail="connection_string is required")
    cs = _normalize_connection_string(cs)
    try:
        out = activate_connection(cs)
        connection_id = str(uuid.uuid4())
        if "inline_connections" not in app_state:
            app_state["inline_connections"] = {}
        app_state["inline_connections"][connection_id] = cs
        app_state["active_connection_id"] = connection_id
        app_state["active_file_id"] = None
        out["connection_id"] = connection_id
        return out
    except Exception as e:
        LOG.exception("Plugin load failed")
        raise HTTPException(status_code=400, detail=f"plugin_load_error: {e}")


# ---------------------------------------------------------------------------
# Schema Documentation Endpoints
# ---------------------------------------------------------------------------

@router.post("/schema/doc",
    summary="Get schema documentation (full)")
async def get_schema_doc(
    request: Optional[ConnectionIdBody] = Body(None),
    table: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(
        connection_id=request.connection_id if request else None,
        file_id=request.file_id if request else None,
    )
    db_inst: SQLDatabase = app_state["db"]
    tables_info = get_schema_info(db_inst)
    fid = (request.file_id if request else None) or app_state.get("active_file_id")
    cid = (request.connection_id if request else None) or app_state.get("active_connection_id")
    tables_info = apply_schema_metadata_overrides(tables_info, file_id=fid, connection_id=cid)
    tables_info = _strip_schema_api_fields(tables_info)
    table_names = sorted(tables_info.keys())
    markdown_full = build_schema_summary(tables_info)

    markdown_by_table: Dict[str, str] = {}
    for tn in table_names:
        t = tables_info[tn]
        lines = [f"# Table: {tn}", ""]
        lines.append(f"- **Rows:** {t.get('row_count', 'N/A')}")
        if t.get("relationships"):
            lines.append(f"- **Relationships:** {', '.join(t['relationships'])}")
        lines.append("")
        lines.append("## Columns")
        lines.append("")
        lines.append("| Column | Type | Nullable | PK | FK | Description |")
        lines.append("|--------|------|----------|-----|-----|-------------|")
        for c in t.get("columns", []):
            lines.append(
                f"| {c['name']} | {c['type']} | {'Yes' if c.get('nullable') else 'No'} "
                f"| {'Yes' if c.get('primary_key') else ''} "
                f"| {c.get('foreign_key') or ''} "
                f"| {(c.get('description') or '')[:50]} |"
            )
        markdown_by_table[tn] = "\n".join(lines)

    response: Dict[str, Any] = {
        "doc": {
            "tables": tables_info,
            "total_tables": len(tables_info),
            "dialect": CURRENT_DIALECT,
            "generated_at": datetime.now().isoformat(),
        },
        "tables": table_names,
        "markdown": markdown_full,
        "markdown_by_table": markdown_by_table,
    }
    if table:
        response["markdown_selected"] = markdown_by_table.get(table, f"*Table '{table}' not found.*")
    return response


@router.post("/schema/doc/refresh")
async def refresh_schema_doc(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    db_inst: SQLDatabase = app_state["db"]
    tables_info = get_schema_info(db_inst)
    return {"ok": True, "generated_at": datetime.now().isoformat(), "total_tables": len(tables_info)}


@router.get("/schema/doc/cache")
async def schema_doc_cache_status(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    return {"cached": False, "db_id": app_state.get("db_id")}


@router.post("/schema/doc/cache/clear")
async def schema_doc_cache_clear(
    connection_id: Optional[str] = Query(None),
    file_id: Optional[str] = Query(None),
):
    _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
    app_state["agent"] = None
    return {"ok": True}

# """
# Convobi API Routes — LangGraph Edition
# =======================================
# All endpoint paths, request bodies and response shapes are **identical**
# to the legacy version so the UI and Echo-Agent integration remain unchanged.

# New endpoint:
#   POST /invoke  — direct LangGraph agent invocation with session memory.
# """

# from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Form, Body, Depends
# from typing import Optional, List, Dict, Any
# from pydantic import BaseModel, Field
# from datetime import datetime
# from sqlalchemy import text, inspect, create_engine
# import pandas as pd
# import os
# import shutil
# import time
# import re
# import json
# import uuid
# from pathlib import Path

# from echolib.security import get_current_user
# from echolib.types import UserContext

# from langchain_community.utilities.sql_database import SQLDatabase
# from langchain_core.messages import HumanMessage

# router = APIRouter(tags=["Convobi / NLP DB"])

# # ---------------------------------------------------------------------------
# # Import everything from new main.py
# # ---------------------------------------------------------------------------
# from .main import (
#     app_state, CURRENT_DIALECT, CURRENT_CONNECTOR,
#     generate_ddl_for_schema_edit,
#     QueryRequest, QueryResponse, SchemaResponse, SummarizeRequest,
#     InvokeRequest, InvokeResponse,
#     _get_convobi_llm,
#     CONVOBI_AGENT_VERBOSE,
#     invoke_convobi_agent,
#     activate_connection,
#     _normalize_connection_string, _dialect_from_connection_string,
#     _resolve_connection_string,
#     get_connection_string_for_file_id, get_saved_connection_string,
#     compute_db_id,
#     get_schema_info, build_schema_summary, _format_schema_hint_for_question,
#     build_plotly_html,
#     build_agent, _build_checkpointer,
#     _parse_agent_results, _extract_agent_steps, _extract_tables_used,
#     ensure_connection_active,
#     user_has_write_access, execute_ddl,
#     refresh_glossary_from_db,
#     get_glossary_path_for_file_id,
#     get_glossary_path_for_connection_id,
#     get_file_upload_info,
#     load_schema_metadata_for_file,
#     export_sqlite_to_csv_excel,
#     _save_file_id_registry_to_disk,
#     _is_itsm_connection,
#     update_glossary_column_description,
#     update_schema_column_metadata,
#     apply_schema_metadata_overrides,
#     UPLOADS_DIR,
#     LOG,
# )

# # OTel metrics — soft import
# try:
#     from echolib.otel import get_metrics_collector as _get_mc
# except ImportError:
#     _get_mc = None

# # ---------------------------------------------------------------------------
# # Shared request bodies (same as legacy)
# # ---------------------------------------------------------------------------


# class ConnectionIdBody(BaseModel):
#     connection_id: Optional[str] = Field(None, alias="connectionId",
#         description="ID of the DB connection from POST /connectors/plugin/load")
#     file_id: Optional[str] = Field(None, alias="fileId",
#         description="ID of an uploaded file from POST /convobi/files/upload")

#     class Config:
#         populate_by_name = True


# class EditSchemaColumnBody(BaseModel):
#     """Single column edit within a table."""
#     column: str = Field(..., description="Column name")
#     description: Optional[str] = None
#     nullable: Optional[bool] = None
#     primary_key: Optional[bool] = None
#     foreign_key: Optional[str] = Field(None, alias="foreignKey")
#     type: Optional[str] = None
#     name: Optional[str] = None

#     class Config:
#         populate_by_name = True


# class EditSchemaTableBody(BaseModel):
#     """Table with its column edits."""
#     table: str = Field(..., description="Table name")
#     columns: List[EditSchemaColumnBody] = Field(..., description="Columns to edit for this table")

#     class Config:
#         populate_by_name = True


# class EditSchemaBulkBody(BaseModel):
#     """Bulk schema edit request - array of tables, each with its columns."""
#     edits: List[EditSchemaTableBody] = Field(
#         ...,
#         description="List of table objects, each containing columns to edit",
#     )
#     connection_id: Optional[str] = Field(None, alias="connectionId")
#     file_id: Optional[str] = Field(None, alias="fileId")

#     class Config:
#         populate_by_name = True


# class DdlRequest(BaseModel):
#     ddl: str = Field(..., description="DDL SQL statement")
#     connection_id: Optional[str] = Field(None, alias="connectionId")
#     file_id: Optional[str] = Field(None, alias="fileId")
#     refresh_schema: bool = Field(True)

#     class Config:
#         populate_by_name = True


# class PluginLoadBody(BaseModel):
#     connection_string: str = Field(..., description="SQLAlchemy connection string")
#     connector: str = Field("sql", description="Connector type")


# # ---------------------------------------------------------------------------
# # Helpers
# # ---------------------------------------------------------------------------

# def _ensure_connection_and_schema(connection_id: Optional[str] = None, file_id: Optional[str] = None):
#     """Resolve connection_id / file_id, activate if needed, ensure DB ready."""
#     if connection_id and file_id:
#         raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")

#     if file_id:
#         cs = get_connection_string_for_file_id(file_id)
#         if not cs:
#             raise HTTPException(status_code=404,
#                 detail=f"Uploaded file '{file_id}' not found. Use POST /convobi/files/upload first.")
#         active_fid = app_state.get("active_file_id")
#         if active_fid != file_id or app_state.get("db") is None:
#             activate_connection(cs)
#             app_state["active_file_id"] = file_id

#     elif connection_id:
#         active_cid = app_state.get("active_connection_id")
#         if active_cid != connection_id or app_state.get("db") is None:
#             cs = get_saved_connection_string(connection_id)
#             if not cs:
#                 raise HTTPException(status_code=404,
#                     detail=f"Connection '{connection_id}' not found.")
#             activate_connection(cs, connection_id=connection_id)
#         app_state["active_file_id"] = None

#     else:
#         app_state["active_file_id"] = None
#         ensure_connection_active()

#     if app_state.get("db") is None:
#         raise HTTPException(status_code=400,
#             detail="No database connected. Use POST /convobi/plugins/load to connect.")


# def _strip_schema_api_fields(tables: Dict[str, Any]) -> Dict[str, Any]:
#     """Remove meaning and example_values from column objects for schema/schema-doc API responses."""
#     out = {}
#     for tname, tbl in tables.items():
#         cols = []
#         for c in tbl.get("columns", []):
#             col = {k: v for k, v in c.items() if k not in ("meaning", "example_values")}
#             cols.append(col)
#         out[tname] = {**tbl, "columns": cols}
#     return out


# def _is_ddl_statement(sql: str) -> bool:
#     s = (sql or "").strip().upper()
#     for line in s.split("\n"):
#         line = line.strip()
#         if line.startswith("--") or line.startswith("/*") or not line:
#             continue
#         parts = line.split()
#         if not parts:
#             continue
#         first = parts[0]
#         return first in ("CREATE", "ALTER", "DROP", "TRUNCATE", "RENAME", "COMMENT", "GRANT", "REVOKE")
#     return False


# # ===========================================================================
# # ENDPOINTS (same paths, same request/response models)
# # ===========================================================================

# @router.get("/")
# async def root():
#     db = app_state.get("db")
#     table_count = len(db.get_usable_table_names()) if db else 0
#     return {
#         "status": "healthy",
#         "service": "NLP Database Interface (LangGraph + SQLDatabaseToolkit)",
#         "version": "2.0.0",
#         "llm_model": "Per-user LLM resolution (lazy)",
#         "tables_loaded": table_count,
#         "dialect": CURRENT_DIALECT,
#         "connector": CURRENT_CONNECTOR,
#         "connection_id": app_state.get("active_connection_id"),
#         "file_id": app_state.get("active_file_id"),
#     }


# # ---------- POST /schema ----------
# @router.post("/schema", response_model=SchemaResponse,
#     summary="Get schema structure and short summary")
# async def get_schema(request: Optional[ConnectionIdBody] = Body(None)):
#     cid = request.connection_id if request else None
#     fid = request.file_id if request else None
#     _ensure_connection_and_schema(connection_id=cid, file_id=fid)
#     db: SQLDatabase = app_state["db"]
#     tables = get_schema_info(db)
#     fid = fid or app_state.get("active_file_id")
#     cid = cid or app_state.get("active_connection_id")
#     tables = apply_schema_metadata_overrides(tables, file_id=fid, connection_id=cid)
#     tables = _strip_schema_api_fields(tables)
#     summary = build_schema_summary(tables)
#     return SchemaResponse(tables=tables, total_tables=len(tables), summary=summary)


# # ---------- POST /query ----------
# @router.post("/query", response_model=QueryResponse)
# async def execute_query(
#     request: QueryRequest,
#     user: UserContext = Depends(get_current_user),
# ):
#     """
#     Main NL-to-SQL pipeline using LangGraph agent with SQLDatabaseToolkit.
#     """
#     try:
#         _ensure_connection_and_schema(connection_id=request.connector_id, file_id=request.file_id)

#         if not request.question or not request.question.strip():
#             raise HTTPException(status_code=422, detail="Question must not be empty.")
#         if request.max_results is not None and request.max_results < 0:
#             raise HTTPException(status_code=422, detail="max_results must be non-negative (0 = unlimited).")
#         if request.language != "sql":
#             raise HTTPException(status_code=422, detail="Only 'sql' is supported.")

#         db: SQLDatabase = app_state.get("db")
#         if not db:
#             raise HTTPException(status_code=400,
#                 detail="No database connected. Use POST /convobi/plugins/load.")

#         try:
#             convobi_llm = _get_convobi_llm(user.user_id)
#         except Exception:
#             raise HTTPException(status_code=502, detail="LLM not configured for Convobi agent.")

#         start_ms = time.time() * 1000

#         agent = app_state.get("agent")
#         if agent is None:
#             checkpointer = app_state.get("checkpointer") or _build_checkpointer()
#             agent = build_agent(
#                 convobi_llm, db, CURRENT_DIALECT,
#                 glossary_hint="",
#                 checkpointer=checkpointer,
#             )
#             app_state["agent"] = agent

#         tables = get_schema_info(db)
#         schema_hint = _format_schema_hint_for_question(tables, request.question)
#         limit_hint = f" (return at most {request.max_results} rows)" if request.max_results and request.max_results > 0 else ""
#         user_msg = f"{schema_hint}\n\nQuestion: {request.question}{limit_hint}" if schema_hint else f"{request.question}{limit_hint}"

#         session_id = str(uuid.uuid4())
#         config = {"configurable": {"thread_id": session_id}}

#         result = agent.invoke({"messages": [HumanMessage(content=user_msg)]}, config)

#         elapsed_ms = time.time() * 1000 - start_ms
#         parsed = _parse_agent_results(result["messages"], db, request.question)

#         viz_html = None
#         if parsed["columns"] and parsed["data"]:
#             viz_html = build_plotly_html(parsed["columns"], parsed["data"], request.question)

#         # Tables used — sample data (only relevant columns) from tables in the SQL
#         tables_used = _extract_tables_used(
#             parsed.get("sql"), db,
#             result_columns=parsed.get("columns"),
#             sample_rows=5,
#         )

#         # Agent steps (only when verbose)
#         steps = _extract_agent_steps(result["messages"]) if CONVOBI_AGENT_VERBOSE else None

#         success = parsed.get("data") is not None or parsed.get("explanation") is not None

#         # Record OTel metrics for convobi query
#         if _get_mc:
#             try:
#                 mc = _get_mc()
#                 mc.record_feature_use(feature="convobi_query", duration_ms=elapsed_ms, success=success)
#             except Exception:
#                 pass

#         app_state["conversation_history"].append({
#             "timestamp": datetime.now().isoformat(),
#             "question": request.question,
#             "sql": parsed.get("sql"),
#             "success": success,
#             "row_count": parsed.get("row_count"),
#         })
#         if len(app_state["conversation_history"]) > 50:
#             app_state["conversation_history"] = app_state["conversation_history"][-50:]

#         return QueryResponse(
#             success=success,
#             response=parsed.get("response") or "",
#             sql=parsed.get("sql"),
#             explanation=parsed.get("explanation"),
#             data=parsed.get("data"),
#             row_count=parsed.get("row_count"),
#             columns=parsed.get("columns"),
#             visualization_hints=None,
#             execution_time_ms=elapsed_ms,
#             confidence=parsed.get("confidence"),
#             optimizations=parsed.get("optimizations"),
#             warnings=parsed.get("warnings"),
#             error=None if parsed.get("data") is not None else parsed.get("raw_result"),
#             summary=parsed.get("summary"),
#             visualization_spec=None,
#             visualization_html=viz_html,
#             optimized_question=None,
#             feedback_attempts=1,
#             tables_used=tables_used,
#             agent_steps=steps,
#         )
#     except HTTPException:
#         raise
#     except Exception as e:
#         LOG.exception("Query pipeline failed")
#         return QueryResponse(success=False, error=str(e))


# # ---------- POST /invoke (NEW) ----------
# @router.post("/invoke", response_model=InvokeResponse,
#     summary="Direct LangGraph agent invocation with session memory")
# async def invoke_agent(
#     request: InvokeRequest,
#     user: UserContext = Depends(get_current_user),
# ):
#     """
#     Invoke the Convi BI LangGraph agent directly.
#     Supports session continuity via session_id.
#     Used by Echo Agent, workflows, and standalone.
#     """
#     try:
#         _ensure_connection_and_schema(connection_id=request.connection_id, file_id=request.file_id)

#         cs = app_state.get("active_connection_string")
#         result = invoke_convobi_agent(
#             question=request.message,
#             connection_string=cs,
#             session_id=request.session_id,
#             max_results=request.max_results,
#             user_id=user.user_id,
#         )

#         return InvokeResponse(
#             success=result.get("success", False),
#             response=result.get("response") or "",
#             sql=result.get("sql"),
#             explanation=result.get("explanation"),
#             data=result.get("data"),
#             row_count=result.get("row_count"),
#             columns=result.get("columns"),
#             execution_time_ms=result.get("execution_time_ms"),
#             confidence=result.get("confidence"),
#             optimizations=result.get("optimizations"),
#             warnings=result.get("warnings"),
#             error=result.get("error"),
#             summary=result.get("summary"),
#             visualization_html=result.get("visualization_html"),
#             optimized_question=None,
#             session_id=result.get("session_id", request.session_id or ""),
#             tables_used=result.get("tables_used"),
#             agent_steps=result.get("agent_steps"),
#         )
#     except HTTPException:
#         raise
#     except Exception as e:
#         LOG.exception("Invoke failed")
#         return InvokeResponse(success=False, error=str(e), session_id=request.session_id or "")


# # ---------- POST /summarize ----------
# @router.post("/summarize")
# async def summarize(
#     req: SummarizeRequest,
#     user: UserContext = Depends(get_current_user),
# ):
#     try:
#         convobi_llm = _get_convobi_llm(user.user_id)
#     except Exception:
#         raise HTTPException(status_code=502, detail="LLM not configured.")
#     try:
#         data_str = json.dumps(req.data[:50], default=str)
#         prompt = (
#             f"Question: {req.question}\n"
#             f"Columns: {req.columns}\n"
#             f"Data (first 50 rows): {data_str}\n\n"
#             "Provide a concise, natural-language summary of the data that answers the question. "
#             "Use markdown formatting."
#         )
#         response = convobi_llm.invoke([HumanMessage(content=prompt)])
#         summary = getattr(response, "content", str(response))
#         return {"summary": summary}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"summarizer_error: {e}")


# # ---------- GET /columns/meaning ----------
# @router.get("/columns/meaning")
# async def get_column_meaning(
#     table: str = Query(...),
#     column: str = Query(...),
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     from .column_glossary import get_column_glossary_description
#     desc = get_column_glossary_description(column)
#     if not desc:
#         return {"found": False}
#     return {
#         "found": True,
#         "meaning": desc,
#         "description": desc,
#         "confidence": 0.8,
#         "source": "glossary",
#         "examples": [],
#     }


# # ---------- POST /config/dialect ----------
# @router.post("/config/dialect")
# async def set_dialect(
#     dialect: str,
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     global CURRENT_DIALECT
#     d = (dialect or "").strip().lower()
#     from .main import SUPPORTED_DIALECTS
#     if d not in SUPPORTED_DIALECTS:
#         raise HTTPException(status_code=400, detail=f"Unsupported dialect '{d}'")
#     CURRENT_DIALECT = d
#     app_state["agent"] = None
#     return {"ok": True, "dialect": CURRENT_DIALECT}


# # ---------- POST /schema/refresh ----------
# @router.post("/schema/refresh")
# async def refresh_schema(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     db: SQLDatabase = app_state["db"]
#     tables = get_schema_info(db)
#     app_state["agent"] = None
#     return {"ok": True, "tables_loaded": len(tables)}


# # ---------- POST /schema/glossary/refresh ----------
# @router.post("/schema/glossary/refresh",
#     summary="Refresh column glossary from DB unique column examples")
# async def refresh_glossary(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     """
#     Fetch unique values from each column in the connected database,
#     merge with existing glossary descriptions, and write to column_glossary.json.
#     Enriches the LLM so it picks the right columns (e.g. SALESSTAGECODE with Win/Loss examples).
#     """
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     db: SQLDatabase = app_state["db"]
#     result = refresh_glossary_from_db(db)
#     app_state["agent"] = None
#     return {"ok": True, **result}


# # ---------- PUT /schema/edit and PUT /schema/doc/edit ----------
# @router.put("/schema/edit",
#     summary="Edit schema metadata (uploaded files and small SQLite DBs only)")
# @router.put("/schema/doc/edit",
#     summary="Edit schema documentation (alias)")
# async def edit_schema(
#     body: EditSchemaBulkBody,
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     cid = connection_id or body.connection_id
#     fid = file_id or body.file_id
#     if cid and fid:
#         raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")
#     # Flatten table->columns into list of (table, column_edit) for processing
#     flat_edits: List[tuple[str, EditSchemaColumnBody]] = []
#     for table_edit in body.edits:
#         if not table_edit.columns:
#             raise HTTPException(
#                 status_code=422,
#                 detail=f"Table '{table_edit.table}' must have at least one column in 'columns' array.",
#             )
#         for col_edit in table_edit.columns:
#             flat_edits.append((table_edit.table, col_edit))

#     if not flat_edits:
#         raise HTTPException(status_code=422, detail="edits array is required and must not be empty")
#     _ensure_connection_and_schema(connection_id=cid, file_id=fid)
#     fid = fid or app_state.get("active_file_id")
#     cid = cid or app_state.get("active_connection_id")
#     # Editable: file uploads, or small SQLite/other DBs (connection_id) — NOT ITSM/CRM
#     if fid is None and cid is None:
#         raise HTTPException(
#             status_code=400,
#             detail="Provide either connection_id or file_id.",
#         )
#     if fid is None and cid and _is_itsm_connection():
#         raise HTTPException(
#             status_code=403,
#             detail="Schema documentation is read-only for ITSM and CRM. "
#                    "Editing is supported for uploaded files or small SQLite/other DBs.",
#         )
#     db: SQLDatabase = app_state["db"]
#     table_names = db.get_usable_table_names()
#     if fid:
#         glossary_path = get_glossary_path_for_file_id(fid)
#         if not glossary_path:
#             raise HTTPException(status_code=404, detail=f"File '{fid}' not found in registry.")
#     else:
#         glossary_path = get_glossary_path_for_connection_id(cid)

#     tables_info = get_schema_info(db)
#     dialect = CURRENT_DIALECT

#     applied: List[Dict[str, str]] = []
#     ddl_errors: List[str] = []

#     for table_name, edit in flat_edits:
#         if table_name not in table_names:
#             raise HTTPException(status_code=404, detail=f"table_not_found: {table_name}")
#         if not edit.column:
#             raise HTTPException(status_code=422, detail="column is required")

#         # Find current column info for DDL generation
#         tbl = tables_info.get(table_name, {})
#         cols = tbl.get("columns", [])
#         current_col = next((c for c in cols if c.get("name") == edit.column), {"name": edit.column, "type": "", "nullable": True, "primary_key": False, "foreign_key": None})

#         # Generate and execute DDL to apply changes in the actual database
#         ddl_statements = generate_ddl_for_schema_edit(
#             table=table_name,
#             column=edit.column,
#             current_col=current_col,
#             new_name=edit.name,
#             new_type=edit.type,
#             new_nullable=edit.nullable,
#             new_primary_key=edit.primary_key,
#             new_foreign_key=edit.foreign_key,
#             dialect=dialect,
#         )
#         for ddl in ddl_statements:
#             success, err, _ = execute_ddl(ddl)
#             if not success:
#                 ddl_errors.append(f"{table_name}.{edit.column}: {err}")

#         # Final column name (after possible rename) for glossary/metadata
#         final_column = (edit.name or edit.column).strip() if (edit.name and str(edit.name).strip()) else edit.column

#         update_glossary_column_description(
#             glossary_path,
#             final_column,
#             None,  # meaning removed
#             edit.description,
#             remove_old_key=edit.column if final_column != edit.column else None,
#         )
#         update_schema_column_metadata(
#             file_id=fid,
#             connection_id=cid if fid is None else None,
#             table=table_name,
#             column=final_column,
#             nullable=edit.nullable,
#             primary_key=edit.primary_key,
#             foreign_key=edit.foreign_key,
#             type_=edit.type,
#             name=edit.name,
#             meaning=None,
#             description=edit.description,
#             remove_old_column=edit.column if final_column != edit.column else None,
#             original_name=edit.column if final_column != edit.column else None,
#         )
#         applied.append({"table": table_name, "column": final_column})

#     if ddl_errors:
#         raise HTTPException(status_code=500, detail="DDL execution failed: " + "; ".join(ddl_errors[:5]))

#     # Export SQLite back to the uploaded CSV/Excel file so changes are saved in the file itself
#     info = get_file_upload_info(fid) if fid else None
#     if fid and info and info.get("original_path") and info.get("format") in ("csv", "xlsx"):
#         schema_meta = load_schema_metadata_for_file(fid)
#         export_ok = export_sqlite_to_csv_excel(
#             db_path=info["db_path"],
#             output_path=info["original_path"],
#             format_type=info["format"],
#             sheets=info.get("sheets"),
#             schema_metadata=schema_meta,
#         )
#         if not export_ok:
#             raise HTTPException(
#                 status_code=500,
#                 detail=f"Failed to save changes to {os.path.basename(info['original_path'])}. "
#                        "Database updated but file export failed.",
#             )

#     app_state["agent"] = None
#     file_saved = bool(fid and info and info.get("original_path") and info.get("format") in ("csv", "xlsx"))
#     return {"ok": True, "applied": applied, "file_saved": file_saved}


# # ---------- POST /schema/ddl ----------
# @router.post("/schema/ddl",
#     summary="Execute DDL on the database schema")
# async def execute_schema_ddl(
#     body: DdlRequest,
#     user: UserContext = Depends(get_current_user),
# ):
#     if body.connection_id and body.file_id:
#         raise HTTPException(status_code=400, detail="Provide either connection_id or file_id, not both.")
#     _ensure_connection_and_schema(connection_id=body.connection_id, file_id=body.file_id)
#     connection_id = app_state.get("active_connection_id") if not body.file_id else None
#     file_id = app_state.get("active_file_id") if body.file_id else body.file_id
#     if not user_has_write_access(connection_id, file_id, user.user_id or "", user.email or ""):
#         raise HTTPException(status_code=403, detail="Write access required to perform DDL.")
#     if not _is_ddl_statement(body.ddl):
#         raise HTTPException(status_code=400, detail="Only DDL statements are allowed.")
#     success, error, rows_affected = execute_ddl(body.ddl)
#     if not success:
#         raise HTTPException(status_code=500, detail=error or "DDL execution failed")
#     out: Dict[str, Any] = {"ok": True, "message": "DDL executed successfully", "rows_affected": rows_affected}
#     if body.refresh_schema:
#         app_state["agent"] = None
#         out["schema_refreshed"] = True
#     return out


# # ---------- POST /cache/clear ----------
# @router.post("/cache/clear")
# async def clear_caches(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     app_state["agent"] = None
#     return {"ok": True}


# # ---------- POST /visualize ----------
# @router.post("/visualize")
# async def visualize(
#     payload: Dict[str, Any],
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     cols = payload.get("columns") or []
#     dat = payload.get("data") or []
#     html = build_plotly_html(cols, dat, payload.get("question", ""))
#     return {"spec": None, "hints": {}, "html": html}


# # ---------- POST /visualize/html ----------
# @router.post("/visualize/html")
# async def visualize_html(
#     payload: Dict[str, Any],
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     cols = payload.get("columns") or []
#     dat = payload.get("data") or []
#     html = build_plotly_html(cols, dat, payload.get("question", ""))
#     return {"html": html or ""}


# # ---------- GET /tables/describe ----------
# @router.get("/tables/describe")
# async def describe_table(
#     table: str = Query(...),
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     db: SQLDatabase = app_state["db"]
#     tables = get_schema_info(db)
#     if table not in tables:
#         raise HTTPException(status_code=404, detail=f"table_not_found: {table}")
#     t = tables[table]
#     return {"table": table, "row_count": t.get("row_count"), "columns": t.get("columns", [])}


# # ---------------------------------------------------------------------------
# # File Upload Endpoints
# # ---------------------------------------------------------------------------

# def _sanitize_table_name(filename_or_sheet: str) -> str:
#     base = os.path.splitext(os.path.basename(filename_or_sheet))[0]
#     base = re.sub(r"[^A-Za-z0-9_]", "_", base).lower()
#     return base or "uploaded_table"


# def _uploads_db_path_for_file(filename: str) -> str:
#     base = os.path.splitext(os.path.basename(filename))[0]
#     safe = re.sub(r"[^A-Za-z0-9_]", "_", base).lower() or "uploaded_db"
#     return os.path.join(UPLOADS_DIR, f"{safe}.db")


# def _uploads_original_path_for_file(filename: str) -> str:
#     """Original CSV/Excel path in uploads dir (for saving edits back)."""
#     return os.path.join(UPLOADS_DIR, os.path.basename(filename))


# @router.post("/files/upload")
# async def upload_tabular_file(
#     file: UploadFile = File(...),
#     activate_source: bool = Form(True),
#     sheet: Optional[str] = Form(None),
#     table_name: Optional[str] = Form(None),
# ):
#     if not file or not file.filename:
#         raise HTTPException(status_code=422, detail="No file provided")
#     ext = os.path.splitext(file.filename)[1].lower()
#     tmp_path = os.path.join(UPLOADS_DIR, f"tmp_{int(time.time())}_{file.filename}")
#     db_path = _uploads_db_path_for_file(file.filename)
#     original_path = _uploads_original_path_for_file(file.filename)
#     try:
#         with open(tmp_path, "wb") as out:
#             content = await file.read()
#             out.write(content)
#         tables_loaded = []
#         sheets_info: List[Dict[str, str]] = []
#         eng = create_engine(f"sqlite:///{db_path}", pool_pre_ping=True)
#         if ext == ".csv":
#             df = pd.read_csv(tmp_path)
#             tname = table_name or _sanitize_table_name(file.filename)
#             with eng.begin() as conn:
#                 df.to_sql(tname, con=conn, if_exists="replace", index=False)
#             tables_loaded.append({"name": tname, "rows": int(df.shape[0]), "columns": list(df.columns)})
#         elif ext == ".xlsx":
#             xls = pd.ExcelFile(tmp_path, engine="openpyxl")
#             sheet_names = [sheet] if sheet else xls.sheet_names
#             for sh in sheet_names:
#                 df = pd.read_excel(tmp_path, sheet_name=sh, engine="openpyxl")
#                 tname = (table_name or _sanitize_table_name(sh)) if len(sheet_names) == 1 else _sanitize_table_name(sh)
#                 with eng.begin() as conn:
#                     df.to_sql(tname, con=conn, if_exists="replace", index=False)
#                 tables_loaded.append({"name": tname, "rows": int(df.shape[0]), "columns": list(df.columns)})
#                 sheets_info.append({"sheet_name": sh, "table_name": tname})
#         else:
#             raise HTTPException(status_code=415, detail=f"Unsupported file type: {ext}. Use CSV or XLSX")

#         # Save original file to uploads/ so edits can be written back
#         shutil.copy2(tmp_path, original_path)

#         activated = False
#         if activate_source:
#             cs = f"sqlite:///{db_path}"
#             activate_connection(cs)
#             activated = True

#         file_id = str(uuid.uuid4())
#         if "file_id_registry" not in app_state:
#             app_state["file_id_registry"] = {}
#         app_state["file_id_registry"][file_id] = {
#             "db_path": db_path,
#             "original_path": original_path,
#             "format": "csv" if ext == ".csv" else "xlsx",
#             "sheets": sheets_info,
#         }
#         _save_file_id_registry_to_disk()
#         return {
#             "ok": True,
#             "file_id": file_id,
#             "filename": file.filename,
#             "database": db_path,
#             "dialect": "sqlite",
#             "tables": tables_loaded,
#             "activated": activated,
#         }
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"upload_error: {e}")
#     finally:
#         try:
#             if os.path.exists(tmp_path):
#                 os.remove(tmp_path)
#         except Exception:
#             pass


# @router.get("/files/list")
# async def list_uploaded_tables(
#     db: Optional[str] = None,
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     try:
#         _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#         if not db:
#             db_files = [f for f in os.listdir(UPLOADS_DIR) if f.endswith(".db")]
#             return {"databases": [os.path.join(UPLOADS_DIR, f) for f in db_files]}
#         db_path = db if db.endswith(".db") else os.path.join(UPLOADS_DIR, f"{db}.db")
#         eng = create_engine(f"sqlite:///{db_path}", pool_pre_ping=True)
#         insp = inspect(eng)
#         tables = insp.get_table_names()
#         sizes: Dict[str, Any] = {}
#         with eng.connect() as conn:
#             for t in tables:
#                 try:
#                     rc = conn.execute(text(f'SELECT COUNT(*) AS c FROM "{t}"')).scalar()
#                     sizes[t] = int(rc or 0)
#                 except Exception:
#                     sizes[t] = None
#         return {"database": db_path, "tables": [{"name": t, "rows": sizes.get(t)} for t in tables]}
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"list_error: {e}")


# # ---------- POST /plugins/load ----------
# @router.post("/plugins/load",
#     summary="Connect a database (any DB plugin)")
# async def plugins_load(body: PluginLoadBody):
#     cs = (body.connection_string or "").strip()
#     if not cs:
#         raise HTTPException(status_code=422, detail="connection_string is required")
#     cs = _normalize_connection_string(cs)
#     try:
#         out = activate_connection(cs)
#         connection_id = str(uuid.uuid4())
#         if "inline_connections" not in app_state:
#             app_state["inline_connections"] = {}
#         app_state["inline_connections"][connection_id] = cs
#         app_state["active_connection_id"] = connection_id
#         app_state["active_file_id"] = None
#         out["connection_id"] = connection_id
#         return out
#     except Exception as e:
#         LOG.exception("Plugin load failed")
#         raise HTTPException(status_code=400, detail=f"plugin_load_error: {e}")


# # ---------------------------------------------------------------------------
# # Schema Documentation Endpoints
# # ---------------------------------------------------------------------------

# @router.post("/schema/doc",
#     summary="Get schema documentation (full)")
# async def get_schema_doc(
#     request: Optional[ConnectionIdBody] = Body(None),
#     table: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(
#         connection_id=request.connection_id if request else None,
#         file_id=request.file_id if request else None,
#     )
#     db_inst: SQLDatabase = app_state["db"]
#     tables_info = get_schema_info(db_inst)
#     fid = (request.file_id if request else None) or app_state.get("active_file_id")
#     cid = (request.connection_id if request else None) or app_state.get("active_connection_id")
#     tables_info = apply_schema_metadata_overrides(tables_info, file_id=fid, connection_id=cid)
#     tables_info = _strip_schema_api_fields(tables_info)
#     table_names = sorted(tables_info.keys())
#     markdown_full = build_schema_summary(tables_info)

#     markdown_by_table: Dict[str, str] = {}
#     for tn in table_names:
#         t = tables_info[tn]
#         lines = [f"# Table: {tn}", ""]
#         lines.append(f"- **Rows:** {t.get('row_count', 'N/A')}")
#         if t.get("relationships"):
#             lines.append(f"- **Relationships:** {', '.join(t['relationships'])}")
#         lines.append("")
#         lines.append("## Columns")
#         lines.append("")
#         lines.append("| Column | Type | Nullable | PK | FK | Description |")
#         lines.append("|--------|------|----------|-----|-----|-------------|")
#         for c in t.get("columns", []):
#             lines.append(
#                 f"| {c['name']} | {c['type']} | {'Yes' if c.get('nullable') else 'No'} "
#                 f"| {'Yes' if c.get('primary_key') else ''} "
#                 f"| {c.get('foreign_key') or ''} "
#                 f"| {(c.get('description') or '')[:50]} |"
#             )
#         markdown_by_table[tn] = "\n".join(lines)

#     response: Dict[str, Any] = {
#         "doc": {
#             "tables": tables_info,
#             "total_tables": len(tables_info),
#             "dialect": CURRENT_DIALECT,
#             "generated_at": datetime.now().isoformat(),
#         },
#         "tables": table_names,
#         "markdown": markdown_full,
#         "markdown_by_table": markdown_by_table,
#     }
#     if table:
#         response["markdown_selected"] = markdown_by_table.get(table, f"*Table '{table}' not found.*")
#     return response


# @router.post("/schema/doc/refresh")
# async def refresh_schema_doc(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     db_inst: SQLDatabase = app_state["db"]
#     tables_info = get_schema_info(db_inst)
#     return {"ok": True, "generated_at": datetime.now().isoformat(), "total_tables": len(tables_info)}


# @router.get("/schema/doc/cache")
# async def schema_doc_cache_status(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     return {"cached": False, "db_id": app_state.get("db_id")}


# @router.post("/schema/doc/cache/clear")
# async def schema_doc_cache_clear(
#     connection_id: Optional[str] = Query(None),
#     file_id: Optional[str] = Query(None),
# ):
#     _ensure_connection_and_schema(connection_id=connection_id, file_id=file_id)
#     app_state["agent"] = None
#     return {"ok": True}
